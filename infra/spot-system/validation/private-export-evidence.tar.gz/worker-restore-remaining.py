import hashlib,json,os
from pathlib import Path
import shutil,signal,subprocess,time
base=Path('/var/lib/spot-criu-recovery')
bucket='spot-experiments-runtimebucket-g8acwaz3kewm'
indexkey='checkpoints/criu/20261019T011736Z-7bad660db8bb/index.json'
def awsget(key,path):
 subprocess.run(['aws','s3','cp','s3://'+bucket+'/'+key,str(path),'--region','us-east-2','--only-show-errors'],check=True)
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
awsget(indexkey,base/'index.json')
index=json.loads((base/'index.json').read_text())
import sys
sys.path.insert(0,'/opt/spot-criu')
from criu_local import validate_generation
results=[]
for record in index['objects']:
 pid=record['pid']
 if pid==6656:continue
 root=base/str(pid)
 archive=base/(str(pid)+'.tar.zst')
 awsget(record['key'],archive)
 if sha(archive)!=record['sha256']:raise RuntimeError('Archive hash mismatch')
 root.mkdir(mode=0o700)
 subprocess.run(['tar','--zstd','-xf',str(archive),'-C',str(root)],check=True)
 manifest=validate_generation(root)
 if os.uname().release!=manifest['kernel']:raise RuntimeError('Kernel mismatch')
 if Path('/proc/'+str(pid)).exists():raise RuntimeError('Restore PID occupied')
 for name in json.loads((root/'backing-paths.json').read_text()):
  source=root/'filesystem'/name.lstrip('/')
  target=Path(name)
  if name.startswith('/usr/lib64/') or name.startswith('/lib64/'):
   if sha(source)!=sha(target):raise RuntimeError('Library hash mismatch')
  elif name.startswith('/home/ec2-user/crypto/'):
   if target.exists():
    if sha(target)!=sha(source):raise RuntimeError('Existing private backing file differs')
   else:
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,target)
    st=source.stat();os.chown(target,st.st_uid,st.st_gid)
  else:raise RuntimeError('Unexpected backing path')
 for name,meta in json.loads((root/'backing-directories.json').read_text()).items():
  if name.startswith('/home/ec2-user/crypto/') or name=='/home/ec2-user/crypto':
   os.chmod(name,meta['mode']);os.chown(name,meta['uid'],meta['gid'])
 result={'schema':'spot.criu-recovery-probe/v1','pid':pid,'application_restore_verified':False,'isolated_outputs':True,'backing_libraries_match':True,'archive_sha256_verified':True}
 start=time.time()
 with (root/'restore-command-output.log').open('wb') as output:
  p=subprocess.Popen(['/opt/spot-criu/criu','restore','-D',str(root/'images'),'--shell-job','--cpu-cap=all','--restore-detached','--pidfile',str(root/'restored.pid'),'-o','restore-worker.log','-v4'],stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   result['restore_exit_status']=p.wait(timeout=45)
   if p.returncode==0:
    if int((root/'restored.pid').read_text())!=pid:raise RuntimeError('Unexpected restore PID')
    def ticks():
     fields=Path('/proc/'+str(pid)+'/stat').read_text().rsplit(') ',1)[1].split();return int(fields[11])+int(fields[12])
    result['cpu_ticks_before']=ticks();time.sleep(10);result['cpu_ticks_after']=ticks()
    result['threads']=len(list(Path('/proc/'+str(pid)+'/task').iterdir()))
    result['application_restore_verified']=result['cpu_ticks_after']>result['cpu_ticks_before'] and result['threads']==2
  except subprocess.TimeoutExpired:result['restore_timed_out_seconds']=45
  finally:
   if Path('/proc/'+str(pid)).exists():os.kill(pid,signal.SIGKILL)
   if p.poll() is None:os.killpg(p.pid,signal.SIGKILL);p.wait()
 result['elapsed_seconds']=round(time.time()-start,3)
 (root/'probe-result.json').write_text(json.dumps(result,indent=2)+'\n')
 results.append(result)
 (base/'remaining-probe-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(result),flush=True)
