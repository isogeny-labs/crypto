import hashlib, json, os
from pathlib import Path
import shutil, signal, subprocess, time
root=Path('/var/lib/spot-criu-recovery/6656')
report=Path('/var/lib/spot-criu-recovery/probe-result.json')
result={'schema':'spot.criu-recovery-probe/v1','pid':6656,'application_restore_verified':False,'isolated_outputs':True}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
# This host is disposable. Do not overwrite existing application paths.
dest=Path('/home/ec2-user/crypto')
if dest.exists():raise RuntimeError('Application backing path already exists; refuse overwrite')
if Path('/proc/6656').exists():raise RuntimeError('Restore PID occupied; refuse to signal it')
manifest=json.loads((root/'manifest.json').read_text())
if os.uname().release != manifest['kernel']:raise RuntimeError('Kernel does not match source')
for name in json.loads((root/'backing-paths.json').read_text()):
 if name.startswith('/usr/lib64/') or name.startswith('/lib64/'):
  if sha(Path(name)) != sha(root/'filesystem'/name.lstrip('/')):
   raise RuntimeError('System backing library differs from snapshot: '+name)
shutil.copytree(root/'filesystem/home/ec2-user/crypto',dest,copy_function=shutil.copy2)
# copytree preserves modes but not owners. Restore the captured numeric owners.
for path in [dest,*dest.rglob('*')]:
 original=(root/'filesystem'/path.relative_to('/')).stat()
 os.chown(path,original.st_uid,original.st_gid)
result['backing_libraries_match']=True
start=time.time()
command=['/opt/spot-criu/criu','restore','-D',str(root/'images'),'--shell-job','--cpu-cap=all','--restore-detached','--pidfile',str(root/'restored.pid'),'-o','restore-worker.log','-v4']
with (root/'restore-command-output.log').open('wb') as output:
 process=subprocess.Popen(command,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  result['restore_exit_status']=process.wait(timeout=45)
  if process.returncode==0:
   pid=int((root/'restored.pid').read_text())
   if pid!=6656:raise RuntimeError('Unexpected restored PID')
   before=Path('/proc/6656/stat').read_text().rsplit(') ',1)[1].split()
   result['cpu_ticks_before']=int(before[11])+int(before[12])
   time.sleep(10)
   after=Path('/proc/6656/stat').read_text().rsplit(') ',1)[1].split()
   result['cpu_ticks_after']=int(after[11])+int(after[12])
   result['threads']=len(list(Path('/proc/6656/task').iterdir()))
   result['application_restore_verified']=result['cpu_ticks_after']>result['cpu_ticks_before'] and result['threads']==2
 except subprocess.TimeoutExpired:
  result['restore_timed_out_seconds']=45
 finally:
  # PID was absent before this probe. Kill only this disposable restore tree.
  if Path('/proc/6656').exists():
   result['clone_state_before_cleanup']=Path('/proc/6656/status').read_text().split('State:',1)[1].splitlines()[0].strip()
   os.kill(6656,signal.SIGKILL)
  if process.poll() is None:
   os.killpg(process.pid,signal.SIGKILL)
   process.wait()
result['elapsed_seconds']=round(time.time()-start,3)
report.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
