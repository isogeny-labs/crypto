import hashlib,json,subprocess
from pathlib import Path
root=Path('/home/ec2-user/crypto-spot-system/infra/spot-system');runtime=root/'runtime.tar.gz'
digest=hashlib.sha256(runtime.read_bytes()).hexdigest();bucket='spot-experiments-runtimebucket-g8acwaz3kewm';key='runtime/'+digest+'.tar.gz'
def aws(*args):return subprocess.check_output(['aws','--region','us-east-2',*args],text=True)
aws('s3','cp',str(runtime),'s3://'+bucket+'/'+key,'--sse','AES256','--metadata','sha256='+digest,'--only-show-errors')
aws('s3','cp','s3://'+bucket+'/'+key,'/tmp/spot-final-runtime-roundtrip.tar.gz','--only-show-errors')
assert hashlib.sha256(Path('/tmp/spot-final-runtime-roundtrip.tar.gz').read_bytes()).hexdigest()==digest
stack=json.loads(aws('cloudformation','describe-stacks','--stack-name','spot-experiments'))['Stacks'][0]
params=[{'ParameterKey':p['ParameterKey'],'ParameterValue':digest} if p['ParameterKey']=='RuntimeDigest' else {'ParameterKey':p['ParameterKey'],'UsePreviousValue':True} for p in stack['Parameters']]
Path('/tmp/spot-final-runtime-params.json').write_text(json.dumps(params))
print(json.dumps({'runtime_sha256':digest,'bytes':runtime.stat().st_size,'download_verified':True}))
print(aws('cloudformation','update-stack','--stack-name','spot-experiments','--template-body','file://'+str(root/'template.json'),'--parameters','file:///tmp/spot-final-runtime-params.json','--capabilities','CAPABILITY_IAM'))
