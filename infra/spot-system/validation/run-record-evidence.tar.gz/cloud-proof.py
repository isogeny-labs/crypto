import json,os,shutil,signal,subprocess,sys,tempfile,time
from pathlib import Path
sys.path.insert(0,'/opt/spot')
from runner import atomic_json
from wake import invoke
config=json.loads(Path('/srv/experiments/spot-worker/runner-config.json').read_text())
assert config.get('lifecycle_function')
response=invoke({'function':config['lifecycle_function'],'region':config['region']},'wake',managed_work=True)
assert response['state']=='starting'
root=Path(tempfile.mkdtemp(prefix='.record-cloud-proof-',dir='/srv/experiments/spot-worker'))
children=[];worker_pid=None
try:
 atomic_json(root/'runner-config.json',config)
 job={'id':'native','cwd':'.','argv':['/opt/spot/bin/checkpoint-selftest','--exact','native_checkpoint_worker','--nocapture'],'checkpoint_contract':'manifest-sha256-v1'}
 atomic_json(root/'jobs.json',[job])
 first_env=dict(os.environ,CLAUDE_SESSION_ID='synthetic-old-session',SYNTHETIC_INHERITED_SECRET='do-not-save')
 first_env.pop('SPOT_ACTIVITY_TABLE',None)
 with (root/'launcher.log').open('wb') as log:
  first=subprocess.Popen(['/usr/local/bin/experiment-runner','--root',str(root),'--once','--no-imds'],env=first_env,stdout=log,stderr=log)
  children.append(first)
  deadline=time.monotonic()+60
  checkpoint=root/'state/native/checkpoint'
  while len(list(checkpoint.glob('*/checkpoint-manifest.json')))<3:
   if first.poll() is not None:raise RuntimeError('Disposable initial run exited before checkpoint')
   if time.monotonic()>deadline:raise TimeoutError('Disposable checkpoint not produced')
   time.sleep(.01)
  worker_pid=int((checkpoint/'worker.pid').read_text())
  assert Path('/proc',str(worker_pid),'exe').resolve()==Path('/opt/spot/bin/checkpoint-selftest')
  assert Path('/proc',str(worker_pid),'cwd').resolve()==root
  os.kill(worker_pid,signal.SIGKILL)
  assert first.wait(timeout=20)!=0
  record=root/'state/native/run.json'
  encoded=record.read_text();assert 'synthetic-old-session' not in encoded and 'do-not-save' not in encoded
  (root/'jobs.json').unlink()
  second_env=dict(os.environ,CODEX_SESSION_ID='synthetic-new-session')
  for key in ['CLAUDE_SESSION_ID','SYNTHETIC_INHERITED_SECRET','SPOT_ACTIVITY_TABLE']:second_env.pop(key,None)
  second=subprocess.Popen(['/usr/local/bin/experiment-runner','--root',str(root),'--resume',str(record),'--once','--no-imds'],env=second_env,stdout=log,stderr=log)
  children.append(second)
  assert second.wait(timeout=90)==0, 'Disposable record resume failed'
 data=json.loads(record.read_text())
 restored=json.loads((root/'state/native/output/restored.json').read_text())
 answer=json.loads((root/'state/native/output/answer.json').read_text())
 assert data['status']['phase']=='complete' and restored>=3 and answer==12
 proof={'schema':'experiment.cloud-handoff-proof/v1','record_schema':data['schema'],'restored_progress':restored,'final_progress':answer,'original_jobs_manifest_removed':True,'launcher_session_not_required':True,'inherited_credentials_not_serialized':True,'worker_iam_and_managed_wake':'passed','runtime_config_used_without_original_environment':True,'original_source_untouched':True}
 Path('/var/lib/spot-runner-validation/cloud-handoff-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(proof))
finally:
 for child in children:
  if child.poll() is None:child.terminate();child.wait(timeout=90)
 # The restored worker is also a disposable fixture, never a real experiment.
 if worker_pid and Path('/proc',str(worker_pid)).exists():
  try:
   if Path('/proc',str(worker_pid),'exe').resolve()==Path('/opt/spot/bin/checkpoint-selftest') and Path('/proc',str(worker_pid),'cwd').resolve()==root:
    os.kill(worker_pid,signal.SIGTERM)
  except FileNotFoundError:pass
 shutil.rmtree(root)
