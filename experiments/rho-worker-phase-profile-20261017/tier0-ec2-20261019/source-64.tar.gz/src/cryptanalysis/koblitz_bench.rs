//! # Measurement harness for Koblitz-curve index-calculus decomposition.
//!
//! The decomposition oracle is the step that decides whether index
//! calculus on subfield curves can ever reach a curve anyone deploys.
//! [`crate::cryptanalysis::koblitz_index_calculus`] ships three of them
//! — exhaustive search, matrix-F4 over the Semaev system, and CDCL SAT
//! over the same system — and they agree on every instance tested.  What
//! was missing is *numbers*: how the instance grows with the field, how
//! the algebra behaves on it, and which of the three wins where.
//!
//! This module produces those numbers reproducibly, so the question can
//! be worked as an optimisation target rather than an opinion.  See
//! `research/notes/ecc2k130/RESEARCH_KOBLITZ_SCALING_TARGET.md` for the pre-registered
//! hypotheses these measurements are meant to settle.
//!
//! ## Two measurements, two reachable ranges
//!
//! **System structure** ([`profile_system`]) needs only the field and
//! the Frobenius-invariant subspace — no curve, no point counting, no
//! materialised factor base.  It therefore runs far past
//! [`crate::cryptanalysis::koblitz_index_calculus::MAX_N`], out to
//! `n = 63`, which is where the interesting scaling lives.  It reports
//! the unknown/equation counts, the degree, the Macaulay rank profile
//! and a **rank-deficiency proxy**, using the same operational definition
//! as [`crate::cryptanalysis::ffd_harness`] so the subspace-restricted
//! numbers are directly comparable with that harness's full-field ones.
//!
//! **Oracle cost** ([`bench_instance`]) needs a real curve with a
//! prime-order subgroup, so it is capped at `MAX_N`.  It runs all three
//! oracles over the same random targets, checks they agree, and reports
//! median wall-clock per target.
//!
//! ## The cost model the target attacks
//!
//! An `m`-point decomposition chains `m − 1` copies of `S₃` over `m − 2`
//! intermediate points, and those intermediates range over the *whole*
//! field rather than the subspace:
//!
//! ```text
//!     unknowns(n, ℓ, m) = m·ℓ + (m − 2)·n.
//! ```
//!
//! The first term is what the factor base costs; the second is pure
//! bookkeeping, and it dominates.  A useful attack needs `m ≈ n/ℓ`
//! summands, so the chaining term grows like `n²/ℓ` — which is why the
//! solvable instances stop where they do, and why [`n_vars_for`] is the
//! number to drive down.
//!
//! ## What this is not
//!
//! Not a claim that any of this threatens a deployed curve.  The
//! largest instance here is `n = 63` for *structure* and `n ≤ 24` for a
//! full solve; sect163k1 is far away, and the paper's own conclusion is
//! that index calculus stays worse than rho at deployed sizes.  The
//! harness exists to find out *how far* away, with measurements instead
//! of extrapolation.

use std::time::Instant;

use num_bigint::BigUint;
use rand::rngs::StdRng;
use rand::{Rng, SeedableRng};

use crate::binary_ecc::{BinaryPoint, F2mElement};
use crate::cryptanalysis::koblitz_groebner::{
    build_decomposition_system, first_fall_degree, solving_degree, system_degree, FieldStructure,
    MacaulayProfile, SolverEngine,
};
use crate::cryptanalysis::koblitz_index_calculus::{
    build_frobenius_factor_base, enumerate_decompose, groebner_decompose, invariant_subspace_basis,
    order_of_2_mod_n, sat_decompose, KoblitzCurve,
};
use crate::cryptanalysis::pq_groebner_f2::{F2BoolMono, F2BoolPoly};

/// Unknowns in the chained `m`-point decomposition system: `m·ℓ`
/// subspace coordinates plus `(m − 2)·n` for the intermediate points.
///
/// The baseline the scaling target tries to beat.
pub fn n_vars_for(n: u32, ell: u32, m: usize) -> usize {
    m * ell as usize + m.saturating_sub(2) * n as usize
}

/// Largest `m` whose system still fits the 64-variable Boolean-monomial
/// budget, or `None` if even `m = 2` does not.
pub fn max_m_within_budget(n: u32, ell: u32, budget: usize) -> Option<usize> {
    (2..=64).rfind(|&m| n_vars_for(n, ell, m) <= budget)
}

// ── System structure ───────────────────────────────────────────────

/// Structure of one decomposition system: size, degree, and how its
/// Macaulay matrices rank up.
#[derive(Clone, Debug)]
pub struct SystemProfile {
    /// Extension degree.
    pub n: u32,
    /// `ℓ = ord_n(2)`, the invariant subspace dimension.
    pub ell: u32,
    /// Summands.
    pub m: usize,
    /// Boolean unknowns.
    pub n_vars: usize,
    /// Boolean equations (`n` per `S₃` link).
    pub n_eqs: usize,
    /// Total degree of the system: 2 for `m = 2`, 3 once chained.
    pub degree: u32,
    /// Legacy name for the rank-deficiency proxy: smallest
    /// `D ≥ 2` with `rank < rows` and `rank < cols`. This does not
    /// certify mathematical first fall degree.
    pub fall_degree: Option<u32>,
    /// Per-degree Macaulay rank profile.
    pub macaulay: Vec<MacaulayProfile>,
    /// Milliseconds spent profiling.
    pub elapsed_ms: f64,
}

impl SystemProfile {
    /// Equations per unknown.  Below 1 the system is underdetermined
    /// and a refutation has to rule out a large solution space; the
    /// measured refutation blow-ups sit at the low end of this ratio.
    pub fn eq_var_ratio(&self) -> f64 {
        if self.n_vars == 0 {
            0.0
        } else {
            self.n_eqs as f64 / self.n_vars as f64
        }
    }
}

/// **Profile the decomposition system** for extension degree `n`, the
/// `factor_index`-th invariant subspace, and `m` summands.
///
/// The target abscissa is drawn from `x_seed`; `S₃` does not involve the
/// curve parameter `a`, and `b = 1` for every Koblitz curve, so no curve
/// is needed — only the field and the subspace.
///
/// Returns `None` when `n` has no non-trivial invariant subspace, when
/// the system exceeds the 64-variable Boolean budget, or when `n ≥ 64`.
pub fn profile_system(
    n: u32,
    factor_index: usize,
    m: usize,
    d_max: u32,
    x_seed: u64,
) -> Option<SystemProfile> {
    let (irr, basis) = invariant_subspace_basis(n, factor_index)?;
    let st = FieldStructure::new(n, &irr);
    let b = F2mElement::one(n);
    let mut rng = StdRng::seed_from_u64(x_seed);
    let x_r = F2mElement::from_biguint(&BigUint::from(rng.gen::<u64>()), n);

    let start = Instant::now();
    let sys = build_decomposition_system(&basis, &x_r, &b, m, &st)?;
    let degree = sys
        .equations
        .iter()
        .flat_map(|e| e.terms.iter())
        .map(|t| t.mask.count_ones())
        .max()
        .unwrap_or(0);
    let (fall_degree, macaulay) = first_fall_degree(&sys.equations, sys.n_vars, d_max);
    let elapsed_ms = start.elapsed().as_secs_f64() * 1e3;

    Some(SystemProfile {
        n,
        ell: basis.len() as u32,
        m,
        n_vars: sys.n_vars,
        n_eqs: sys.equations.len(),
        degree,
        fall_degree,
        macaulay,
        elapsed_ms,
    })
}

/// First-fall-degree statistics over several target draws.
///
/// The fall degree is a property of the *system*, and the system
/// depends on the target abscissa `x(R)`.  A single draw is therefore a
/// noisy statistic — measured on `K / F_2^9` at `m = 2`, one draw falls
/// at `D = 2` and another shows no fall to `D = 3`.  Anything built on
/// this number has to average.
#[derive(Clone, Debug)]
pub struct FfdSummary {
    /// Extension degree.
    pub n: u32,
    /// Subspace dimension.
    pub ell: u32,
    /// Summands.
    pub m: usize,
    /// Boolean unknowns.
    pub n_vars: usize,
    /// Boolean equations.
    pub n_eqs: usize,
    /// System degree.
    pub degree: u32,
    /// Draws taken.
    pub trials: usize,
    /// Smallest fall degree seen.
    pub fall_min: Option<u32>,
    /// Largest fall degree seen.
    pub fall_max: Option<u32>,
    /// Draws with no fall at or below `d_max`.
    pub no_fall: usize,
    /// Mean rank deficit `rows − rank` at `D = 2`, over the draws.
    pub mean_syzygies_d2: f64,
}

/// Profile `trials` independent target draws and summarise the fall
/// degree across them.
pub fn ffd_summary(
    n: u32,
    factor_index: usize,
    m: usize,
    d_max: u32,
    seed: u64,
    trials: usize,
) -> Option<FfdSummary> {
    let mut falls: Vec<Option<u32>> = Vec::with_capacity(trials);
    let mut syz = Vec::with_capacity(trials);
    let mut first: Option<SystemProfile> = None;
    for t in 0..trials {
        let p = profile_system(n, factor_index, m, d_max, seed.wrapping_add(t as u64))?;
        falls.push(p.fall_degree);
        if let Some(q) = p.macaulay.iter().find(|q| q.degree == 2) {
            syz.push(q.syzygies() as f64);
        }
        if first.is_none() {
            first = Some(p);
        }
    }
    let p = first?;
    let seen: Vec<u32> = falls.iter().flatten().copied().collect();
    Some(FfdSummary {
        n,
        ell: p.ell,
        m,
        n_vars: p.n_vars,
        n_eqs: p.n_eqs,
        degree: p.degree,
        trials,
        fall_min: seen.iter().copied().min(),
        fall_max: seen.iter().copied().max(),
        no_fall: falls.iter().filter(|f| f.is_none()).count(),
        mean_syzygies_d2: if syz.is_empty() {
            0.0
        } else {
            syz.iter().sum::<f64>() / syz.len() as f64
        },
    })
}

/// Summarise the fall degree for every `(n, m)` in the sweep.
pub fn sweep_ffd(
    ns: &[u32],
    ms: &[usize],
    d_max: u32,
    seed: u64,
    trials: usize,
) -> Vec<FfdSummary> {
    let mut out = Vec::new();
    for &n in ns {
        for &m in ms {
            if let Some(s) = ffd_summary(n, 0, m, d_max, seed, trials) {
                out.push(s);
            }
        }
    }
    out
}

/// Markdown table of fall-degree summaries.
pub fn format_ffd_table(rows: &[FfdSummary]) -> String {
    let mut out = String::new();
    out.push_str("| n | ℓ | m | vars | eqs | deg | FFD min | FFD max | no fall | mean syz D=2 |\n");
    out.push_str("|--:|--:|--:|-----:|----:|----:|--------:|--------:|--------:|-------------:|\n");
    for r in rows {
        let f = |v: Option<u32>| v.map(|d| d.to_string()).unwrap_or_else(|| "—".into());
        out.push_str(&format!(
            "| {} | {} | {} | {} | {} | {} | {} | {} | {}/{} | {:.2} |\n",
            r.n,
            r.ell,
            r.m,
            r.n_vars,
            r.n_eqs,
            r.degree,
            f(r.fall_min),
            f(r.fall_max),
            r.no_fall,
            r.trials,
            r.mean_syzygies_d2
        ));
    }
    out
}

/// Profile every `(n, m)` in the sweep, skipping what does not fit.
pub fn sweep_systems(ns: &[u32], ms: &[usize], d_max: u32, x_seed: u64) -> Vec<SystemProfile> {
    let mut out = Vec::new();
    for &n in ns {
        for &m in ms {
            if let Some(p) = profile_system(n, 0, m, d_max, x_seed) {
                out.push(p);
            }
        }
    }
    out
}

// ── Oracle cost ────────────────────────────────────────────────────

/// Timing and verdicts for one oracle over a set of targets.
#[derive(Clone, Debug)]
pub struct OracleRun {
    /// `"search"`, `"matrix-f4"` or `"sat"`.
    pub oracle: &'static str,
    /// Targets that decomposed.
    pub decomposed: usize,
    /// Targets proven not to decompose (an F4 certificate or an UNSAT).
    /// Exhaustive search never *proves* anything beyond its own sweep,
    /// so it reports its negatives here too.
    pub refuted: usize,
    /// Targets where the oracle ran out of budget — neither a
    /// decomposition nor a refutation.
    pub inconclusive: usize,
    /// Median milliseconds per target, over all targets.
    pub median_ms: f64,
    /// Median milliseconds over the targets that *did* decompose.
    ///
    /// Kept separate from [`Self::median_refuted_ms`] because the two
    /// regimes differ by orders of magnitude and averaging them hides
    /// it: finding one root among many is easy, proving there is no
    /// root is not.  A single median over both is a number that
    /// describes neither.
    pub median_found_ms: f64,
    /// Median milliseconds over the targets that did not decompose —
    /// the refutation cost.
    pub median_refuted_ms: f64,
    /// Total milliseconds over all targets.
    pub total_ms: f64,
}

/// One benchmarked instance: all three oracles over the same targets.
#[derive(Clone, Debug)]
pub struct InstanceBench {
    /// Curve parameter.
    pub a: u8,
    /// Extension degree.
    pub n: u32,
    /// Subspace dimension.
    pub ell: u32,
    /// Summands.
    pub m: usize,
    /// Factor-base size.
    pub fb_size: usize,
    /// `π`-orbits, i.e. linear-algebra unknowns.
    pub orbits: usize,
    /// Boolean unknowns in the decomposition system.
    pub n_vars: usize,
    /// Targets tried.
    pub targets: usize,
    /// Per-oracle results.
    pub runs: Vec<OracleRun>,
    /// Targets where the three oracles did not return the same verdict.
    /// **Must be zero**; anything else is a bug, not a measurement.
    pub disagreements: usize,
}

/// Median, or `NaN` when there is nothing to take a median of.
///
/// Deliberately not `0.0`: an empty class means the oracle never hit
/// that case, and reporting it as zero milliseconds would be a
/// measurement claim that is false.  `NaN` serialises to `null`.
fn median(mut xs: Vec<f64>) -> f64 {
    if xs.is_empty() {
        return f64::NAN;
    }
    xs.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let mid = xs.len() / 2;
    if xs.len().is_multiple_of(2) {
        (xs[mid - 1] + xs[mid]) / 2.0
    } else {
        xs[mid]
    }
}

/// **Benchmark all three oracles** on `targets` pseudo-random points of
/// `⟨G⟩`, checking they agree.
///
/// `node_budget` bounds the F4 splitting search, `max_models` the SAT
/// model enumeration, and `macaulay_degree` selects the implied rows
/// handed to the SAT solver (`Some(2)` is the default elsewhere); a `None` from either with its budget spent is
/// counted as inconclusive rather than as a refutation.
///
/// Returns `None` if the curve or the factor base cannot be built.
#[allow(clippy::too_many_arguments)]
pub fn bench_instance(
    a: u8,
    n: u32,
    factor_index: usize,
    m: usize,
    targets: usize,
    seed: u64,
    node_budget: usize,
    max_models: usize,
    macaulay_degree: Option<u32>,
) -> Option<InstanceBench> {
    let kc = KoblitzCurve::new(a, n)?;
    let fb = build_frobenius_factor_base(&kc, factor_index)?;
    let index_of = fb.index_map();
    let st = FieldStructure::new(kc.n, &kc.curve.irreducible);
    let g = kc.generator().clone();
    let n_vars = n_vars_for(n, fb.ell, m);

    let mut rng = StdRng::seed_from_u64(seed);
    let r_u64 = kc
        .subgroup_order
        .to_u64_digits()
        .first()
        .copied()
        .unwrap_or(2)
        .max(2);
    let points: Vec<BinaryPoint> = (0..targets)
        .map(|_| kc.mul(&g, &BigUint::from(rng.gen_range(1..r_u64))))
        .collect();

    // (decomposed, refuted, inconclusive, all_ms, found_ms, refuted_ms)
    type Acc = (usize, usize, usize, Vec<f64>, Vec<f64>, Vec<f64>);
    let mut search: Acc = (0, 0, 0, Vec::new(), Vec::new(), Vec::new());
    let mut f4: Acc = (0, 0, 0, Vec::new(), Vec::new(), Vec::new());
    let mut sat: Acc = (0, 0, 0, Vec::new(), Vec::new(), Vec::new());
    let mut disagreements = 0usize;

    for target in &points {
        let t = Instant::now();
        let by_search = enumerate_decompose(&kc, &fb, &index_of, target, m);
        let ms = t.elapsed().as_secs_f64() * 1e3;
        search.3.push(ms);
        if by_search.is_some() {
            search.0 += 1;
            search.4.push(ms);
        } else {
            search.1 += 1;
            search.5.push(ms);
        }

        let t = Instant::now();
        let (by_f4, f4_stats) = groebner_decompose(
            &kc,
            &fb,
            &index_of,
            &st,
            target,
            m,
            SolverEngine::default(),
            node_budget,
        );
        let ms = t.elapsed().as_secs_f64() * 1e3;
        f4.3.push(ms);
        match (&by_f4, f4_stats.exhausted) {
            (Some(_), _) => {
                f4.0 += 1;
                f4.4.push(ms);
            }
            (None, false) => {
                f4.1 += 1;
                f4.5.push(ms);
            }
            (None, true) => f4.2 += 1,
        }

        let t = Instant::now();
        let (by_sat, sat_stats) = sat_decompose(
            &kc,
            &fb,
            &index_of,
            &st,
            target,
            m,
            max_models,
            macaulay_degree,
        );
        let ms = t.elapsed().as_secs_f64() * 1e3;
        sat.3.push(ms);
        match (&by_sat, sat_stats.refuted) {
            (Some(_), _) => {
                sat.0 += 1;
                sat.4.push(ms);
            }
            (None, true) => {
                sat.1 += 1;
                sat.5.push(ms);
            }
            (None, false) => sat.2 += 1,
        }

        // Agreement gate: a decomposition found by one oracle must be
        // found by all, and every returned decomposition must be real.
        let verdicts = [by_search.is_some(), by_f4.is_some(), by_sat.is_some()];
        if !(verdicts.iter().all(|v| *v) || verdicts.iter().all(|v| !*v)) {
            disagreements += 1;
        }
        for found in [&by_search, &by_f4, &by_sat].into_iter().flatten() {
            let mut acc = BinaryPoint::Infinity;
            for i in found {
                acc = kc.add(&acc, &fb.points[*i]);
            }
            if &acc != target {
                disagreements += 1;
            }
        }
    }

    let pack =
        |name: &'static str, v: (usize, usize, usize, Vec<f64>, Vec<f64>, Vec<f64>)| OracleRun {
            oracle: name,
            decomposed: v.0,
            refuted: v.1,
            inconclusive: v.2,
            median_ms: median(v.3.clone()),
            median_found_ms: median(v.4.clone()),
            median_refuted_ms: median(v.5.clone()),
            total_ms: v.3.iter().sum(),
        };

    Some(InstanceBench {
        a,
        n,
        ell: fb.ell,
        m,
        fb_size: fb.points.len(),
        orbits: fb.unknowns(),
        n_vars,
        targets,
        runs: vec![
            pack("search", search),
            pack("matrix-f4", f4),
            pack("sat", sat),
        ],
        disagreements,
    })
}

// ── Reporting ──────────────────────────────────────────────────────

/// Markdown table of system profiles.
pub fn format_system_table(profiles: &[SystemProfile]) -> String {
    let mut out = String::new();
    out.push_str(
        "| n | ℓ | m | vars | eqs | deg | FFD | D=2 rows×cols (rank) | D=3 rows×cols (rank) |\n",
    );
    out.push_str(
        "|--:|--:|--:|-----:|----:|----:|----:|---------------------:|---------------------:|\n",
    );
    for p in profiles {
        let cell = |d: u32| match p.macaulay.iter().find(|q| q.degree == d) {
            Some(q) => format!("{}×{} ({})", q.rows, q.cols, q.rank),
            None => "—".to_string(),
        };
        out.push_str(&format!(
            "| {} | {} | {} | {} | {} | {} | {} | {} | {} |\n",
            p.n,
            p.ell,
            p.m,
            p.n_vars,
            p.n_eqs,
            p.degree,
            p.fall_degree
                .map(|d| d.to_string())
                .unwrap_or_else(|| "—".into()),
            cell(2),
            cell(3),
        ));
    }
    out
}

/// Markdown table of oracle costs.
pub fn format_oracle_table(benches: &[InstanceBench]) -> String {
    let mut out = String::new();
    out.push_str(
        "| curve | n | ℓ | m | \\|F\\| | vars | oracle | found | refuted | inconc | median ms | med found | med refuted |\n",
    );
    out.push_str(
        "|:------|--:|--:|--:|------:|-----:|:-------|------:|--------:|-------:|----------:|----------:|------------:|\n",
    );
    for b in benches {
        for r in &b.runs {
            out.push_str(&format!(
                "| K_{} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {:.3} | {:.3} | {:.3} |\n",
                b.a,
                b.n,
                b.ell,
                b.m,
                b.fb_size,
                b.n_vars,
                r.oracle,
                r.decomposed,
                r.refuted,
                r.inconclusive,
                r.median_ms,
                r.median_found_ms,
                r.median_refuted_ms
            ));
        }
    }
    out
}

/// Machine-readable dump, for autolab runs that want to diff against a
/// previous baseline rather than read a table.
pub fn to_json(profiles: &[SystemProfile], benches: &[InstanceBench]) -> String {
    let systems: Vec<serde_json::Value> = profiles
        .iter()
        .map(|p| {
            serde_json::json!({
                "n": p.n, "ell": p.ell, "m": p.m,
                "n_vars": p.n_vars, "n_eqs": p.n_eqs, "degree": p.degree,
                "eq_var_ratio": p.eq_var_ratio(),
                "fall_degree": p.fall_degree,
                "macaulay": p.macaulay.iter().map(|q| serde_json::json!({
                    "degree": q.degree, "rows": q.rows, "cols": q.cols,
                    "rank": q.rank, "syzygies": q.syzygies(),
                })).collect::<Vec<_>>(),
                "elapsed_ms": p.elapsed_ms,
            })
        })
        .collect();
    let oracles: Vec<serde_json::Value> = benches
        .iter()
        .map(|b| {
            serde_json::json!({
                "a": b.a, "n": b.n, "ell": b.ell, "m": b.m,
                "fb_size": b.fb_size, "orbits": b.orbits, "n_vars": b.n_vars,
                "targets": b.targets, "disagreements": b.disagreements,
                "runs": b.runs.iter().map(|r| serde_json::json!({
                    "oracle": r.oracle, "decomposed": r.decomposed,
                    "refuted": r.refuted, "inconclusive": r.inconclusive,
                    "median_ms": r.median_ms,
                    "median_found_ms": r.median_found_ms,
                    "median_refuted_ms": r.median_refuted_ms,
                    "total_ms": r.total_ms,
                })).collect::<Vec<_>>(),
            })
        })
        .collect();
    serde_json::json!({ "systems": systems, "oracles": oracles }).to_string()
}

/// The `n` values with a non-trivial Frobenius-invariant subspace of
/// dimension `≤ max_ell`, in range — the ladder every sweep walks.
pub fn subspace_ladder(n_max: u32, max_ell: u32) -> Vec<(u32, u32)> {
    (5..=n_max)
        .step_by(2)
        .filter_map(|n| order_of_2_mod_n(n).map(|l| (n, l)))
        .filter(|(n, l)| *l <= max_ell && *l < *n)
        .collect()
}

// ── Solving degree vs first fall degree ────────────────────────────

/// One cell of the bounded Macaulay diagnostic (legacy type name).
///
/// These are original-generator rank/refutation/pinning measurements, not
/// a completed Gröbner basis, F4/F5 solving degree, or degree of regularity.
/// Targets are field abscissas without a rational-point lifting check.
/// Both random-control arms have the all-zero solution by construction.
#[derive(Clone, Debug)]
pub struct DregSummary {
    /// Extension degree.
    pub n: u32,
    /// Subspace dimension.
    pub ell: u32,
    /// Summands.
    pub m: usize,
    /// Boolean unknowns.
    pub n_vars: usize,
    /// Boolean equations.
    pub n_eqs: usize,
    /// System total degree.
    pub degree: u32,
    /// Target draws taken.
    pub trials: usize,
    /// Mean rank-deficiency degree, conditional on detecting the proxy.
    pub fall_mean: Option<f64>,
    /// Mean bounded-Macaulay refutation degree, conditional on refutation.
    /// This is an algebraic event; targets have not been lifted to the curve.
    pub refute_mean: Option<f64>,
    /// Largest refutation degree seen.
    pub refute_max: Option<u32>,
    /// Draws refuted at or below `d_max`.
    pub refuted: usize,
    /// Mean degree at which an algebraic system had every occurring variable
    /// pinned.  Reported separately because it is a different event: a
    /// target with two or more decompositions can never be pinned, and
    /// that is a property of the target, not a failure of the algebra.
    pub pin_mean: Option<f64>,
    /// Draws resolved by pinning.
    pub pinned: usize,
    /// Draws that neither refuted nor pinned at or below `d_max`, or
    /// whose Macaulay matrix exceeded the size caps first.
    pub unresolved: usize,
    /// Highest Macaulay degree actually built on any draw.
    ///
    /// The difference between "measured, and the degree is high" and
    /// "could not be measured" lives here.  When this is below `d_max`
    /// on an unresolved cell, the sweep ran out of *matrix*, not out of
    /// degree: [`crate::cryptanalysis::koblitz_groebner::solving_profile`]
    /// returned `None` because the Macaulay matrix exceeded the size
    /// caps, and nothing about the system's solving degree has been
    /// established.
    pub max_degree_built: Option<u32>,
    /// Mean pinning degree of the shape-matched, zero-root control.
    /// Legacy field name: this is not a completed-basis solving degree.
    pub control_solve_mean: Option<f64>,
    /// Shape-matched control draws that did not pin all occurring variables.
    pub control_unresolved: usize,
    /// Legacy density heuristic `2^(n_vars - n_eqs)`. This is NOT the
    /// expected solution count of this generator, which always has zero
    /// as a root and does not sample uniformly random Boolean functions.
    pub control_expected_solutions: f64,
    /// Mean pinning degree of the extra-equation (`n_vars + 4`) control.
    /// Legacy name: this arm is always SAT, never an UNSAT control.
    pub control_unsat_mean: Option<f64>,
    /// Extra-equation control draws that did not pin all occurring variables.
    pub control_unsat_unresolved: usize,
    /// Highest Macaulay degree built on a **shape-matched** control draw.
    ///
    /// The controls need this for the same reason the real systems do:
    /// without it, "did not resolve by `d_max`" and "exceeded the size
    /// caps" are the same output, and only the first of those says
    /// anything.  Omitting it once forced the `n = 5, m = 3` attribution
    /// to be settled by hand-computing the matrix size.
    pub control_shape_max_degree_built: Option<u32>,
    /// Highest Macaulay degree built on an **extra-equation** control draw.
    ///
    /// Kept separate from the shape-matched arm rather than folded into
    /// one maximum, because the two arms have different row counts: the
    /// extra-equation arm carries `n_vars + 4` equations against the
    /// shape-matched arm's `n_eqs`, so it reaches the row cap at a
    /// *lower* degree.  A shared `max()` would report a degree the
    /// extra-equation arm never built — and that arm is precisely the one
    /// whose non-resolution carries the attribution, so the field meant
    /// to prove "not a cap artifact" would have been the field lying
    /// about it.
    pub control_unsat_max_degree_built: Option<u32>,
}

impl DregSummary {
    /// Difference of conditional means: refutation minus rank proxy.
    /// The means can use different subsets of draws; this is not a paired
    /// degree gap or evidence for the first-fall-degree assumption.
    pub fn gap(&self) -> Option<f64> {
        Some(self.refute_mean? - self.fall_mean?)
    }
}

/// A random boolean system with a prescribed shape: `n_eqs` equations
/// over `n_vars` variables, each a sum of `terms_per_eq` monomials of
/// degree at most `degree`.
///
/// Each sampled monomial has positive degree. Consequently the all-zero
/// assignment satisfies every equation, regardless of equation count.
/// This generator supplies SAT controls only; matching a pinning degree
/// cannot establish that Semaev structure has no benefit.
///
/// # Panics
///
/// Panics before sampling if `n_vars` is outside `1..=64`, or
/// `degree.max(1) > n_vars`. Squarefree monomials cannot have more
/// variables than the system; attempting to sample one would never finish.
/// Degree zero retains its historical interpretation as degree one.
pub fn random_control_system(
    n_vars: usize,
    n_eqs: usize,
    degree: u32,
    terms_per_eq: usize,
    seed: u64,
) -> Vec<F2BoolPoly> {
    assert!(
        (1..=64).contains(&n_vars),
        "random controls require 1..=64 Boolean variables"
    );
    assert!(
        degree.max(1) <= n_vars as u32,
        "random control degree cannot exceed the variable count"
    );
    let mut rng = StdRng::seed_from_u64(seed);
    (0..n_eqs)
        .map(|_| {
            let monos: Vec<F2BoolMono> = (0..terms_per_eq.max(1))
                .map(|_| {
                    let d = 1 + rng.gen::<u32>() % degree.max(1);
                    let mut mask = 0u64;
                    while mask.count_ones() < d {
                        mask |= 1u64 << (rng.gen::<u32>() % n_vars as u32);
                    }
                    F2BoolMono::from_mask(mask)
                })
                .collect();
            F2BoolPoly::from_monos(monos, n_vars)
        })
        .collect()
}

/// Measure rank-deficiency and bounded-Macaulay resolution on the same systems,
/// over `trials` independent target draws, against the matched random
/// control.
/// `with_control` runs the matched random null object as well.  It is
/// the expensive half of the sweep by a wide margin — a random system
/// of this shape may remain unpinned at every tested degree, so it pays the
/// full `binom(n_vars, d_max)` Macaulay cost on every draw, while the
/// Semaev systems resolve early and stop.  Turn it off to extend the
/// `n` ladder, on to interpret any single cell.
pub fn dreg_summary(
    n: u32,
    factor_index: usize,
    m: usize,
    d_max: u32,
    trials: usize,
    seed: u64,
    with_control: bool,
) -> Option<DregSummary> {
    let (irr, basis) = invariant_subspace_basis(n, factor_index)?;
    let st = FieldStructure::new(n, &irr);
    let b = F2mElement::one(n);
    let mut rng = StdRng::seed_from_u64(seed);

    let mut falls: Vec<u32> = Vec::new();
    let mut refutes: Vec<u32> = Vec::new();
    let mut pins: Vec<u32> = Vec::new();
    let mut unresolved = 0usize;
    let mut max_degree_built: Option<u32> = None;
    let mut shape: Option<(usize, usize, u32, usize)> = None;

    for _ in 0..trials {
        let x_r = F2mElement::from_biguint(&BigUint::from(rng.gen::<u64>()), n);
        let sys = match build_decomposition_system(&basis, &x_r, &b, m, &st) {
            Some(s) => s,
            None => continue,
        };
        let deg = system_degree(&sys.equations);
        let terms: usize =
            sys.equations.iter().map(|e| e.terms.len()).sum::<usize>() / sys.equations.len().max(1);
        shape = Some((sys.n_vars, sys.equations.len(), deg, terms));

        let (fall, _) = first_fall_degree(&sys.equations, sys.n_vars, d_max);
        if let Some(f) = fall {
            falls.push(f);
        }
        let (d, profs) = solving_degree(&sys.equations, sys.n_vars, d_max);
        if let Some(top) = profs.last().map(|p| p.degree) {
            max_degree_built = Some(max_degree_built.map_or(top, |x: u32| x.max(top)));
        }
        match d {
            Some(d) => {
                // `solving_degree` stops at the first resolving degree,
                // so the last profile is the one that resolved.
                if profs.last().map(|p| p.refuted).unwrap_or(false) {
                    refutes.push(d);
                } else {
                    pins.push(d);
                }
            }
            None => unresolved += 1,
        }
    }

    let (n_vars, n_eqs, degree, terms_per_eq) = shape?;

    // Both controls have the all-zero root. A resolving event is pinning,
    // not refutation; do not compare these means as UNSAT evidence.
    let mut control: Vec<u32> = Vec::new();
    let mut control_unresolved = 0usize;
    let mut control_unsat: Vec<u32> = Vec::new();
    let mut control_unsat_unresolved = 0usize;
    let mut control_shape_max_degree_built: Option<u32> = None;
    let mut control_unsat_max_degree_built: Option<u32> = None;
    let note_ctrl = |profs: &[crate::cryptanalysis::koblitz_groebner::SolvingProfile],
                     acc: &mut Option<u32>| {
        if let Some(top) = profs.last().map(|p| p.degree) {
            *acc = Some(acc.map_or(top, |x: u32| x.max(top)));
        }
    };
    for t in 0..(if with_control { trials } else { 0 }) {
        // A fresh control per draw, deterministically derived from the
        // sweep seed so the whole table replays.
        let control_seed = seed
            .wrapping_mul(0x9E37_79B9_7F4A_7C15)
            .wrapping_add(t as u64);
        let polys = random_control_system(n_vars, n_eqs, degree, terms_per_eq, control_seed);
        let (cd, cprofs) = solving_degree(&polys, n_vars, d_max);
        note_ctrl(&cprofs, &mut control_shape_max_degree_built);
        match cd {
            Some(d) => control.push(d),
            None => control_unresolved += 1,
        }

        // Extra equations change the shape but preserve the all-zero root.
        let unsat = random_control_system(
            n_vars,
            n_vars + 4,
            degree,
            terms_per_eq,
            control_seed.wrapping_mul(0xA24B_AED4_963E_E407),
        );
        let (ud, uprofs) = solving_degree(&unsat, n_vars, d_max);
        note_ctrl(&uprofs, &mut control_unsat_max_degree_built);
        match ud {
            Some(d) => control_unsat.push(d),
            None => control_unsat_unresolved += 1,
        }
    }

    let mean = |v: &[u32]| {
        if v.is_empty() {
            None
        } else {
            Some(v.iter().map(|&x| x as f64).sum::<f64>() / v.len() as f64)
        }
    };

    Some(DregSummary {
        n,
        ell: basis.len() as u32,
        m,
        n_vars,
        n_eqs,
        degree,
        trials,
        fall_mean: mean(&falls),
        refute_mean: mean(&refutes),
        refute_max: refutes.iter().copied().max(),
        refuted: refutes.len(),
        pin_mean: mean(&pins),
        pinned: pins.len(),
        unresolved,
        max_degree_built,
        control_solve_mean: mean(&control),
        control_unresolved,
        control_expected_solutions: 2f64.powi(n_vars as i32 - n_eqs as i32),
        control_unsat_mean: mean(&control_unsat),
        control_unsat_unresolved,
        control_shape_max_degree_built,
        control_unsat_max_degree_built,
    })
}

/// Render [`DregSummary`] rows as a markdown table.
pub fn format_dreg_table(rows: &[DregSummary]) -> String {
    let mut out = String::from(
        "| n | ℓ | m | vars | eqs | deg | D_rank_proxy | D_refute | delta_means | D_pin(shape) | D_pin(extra) | Dc(shape) | Dc(extra) | refuted | pinned | unres | D_built |\n\
         |--:|--:|--:|-----:|----:|----:|----:|---------:|----:|------------:|------------:|----------:|----------:|--------:|-------:|------:|--------:|\n",
    );
    let f = |v: Option<f64>| v.map_or("—".to_string(), |x| format!("{x:.2}"));
    // Multiple-root SAT systems may have a complete basis without pinning.
    // No degree is therefore an unresolved diagnostic, not proof of failure.
    let ctrl = |v: Option<f64>, unresolved: usize| match v {
        Some(x) => format!("{x:.2}"),
        None if unresolved > 0 => "unres".to_string(),
        None => "—".to_string(),
    };
    for r in rows {
        out.push_str(&format!(
            "| {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {}/{} | {} |\n",
            r.n,
            r.ell,
            r.m,
            r.n_vars,
            r.n_eqs,
            r.degree,
            f(r.fall_mean),
            f(r.refute_mean),
            f(r.gap()),
            ctrl(r.control_solve_mean, r.control_unresolved),
            ctrl(r.control_unsat_mean, r.control_unsat_unresolved),
            r.control_shape_max_degree_built
                .map_or("—".to_string(), |d| d.to_string()),
            r.control_unsat_max_degree_built
                .map_or("—".to_string(), |d| d.to_string()),
            r.refuted,
            r.pinned,
            r.unresolved,
            r.trials,
            r.max_degree_built
                .map_or("—".to_string(), |d| d.to_string()),
        ));
    }
    out
}

// ── Dense vs sparse elimination ────────────────────────────────────

/// Head-to-head measurement of the two elimination paths on one
/// Macaulay matrix.
///
/// The sparse path is an optimisation, so the only question about it is
/// whether it is actually faster — and the honest way to answer that is
/// to time both on the same matrix rather than to argue from the
/// representation.  `max_weight` is reported alongside because fill-in
/// is the failure mode: if elimination densifies the rows, sparse
/// storage buys the early columns and then degrades toward dense
/// behaviour, which shows up as the weight climbing toward `cols`.
#[derive(Clone, Debug)]
pub struct EliminationComparison {
    pub n: u32,
    pub m: usize,
    pub degree: u32,
    pub n_vars: usize,
    pub rows: usize,
    pub cols: usize,
    /// Columns carrying degree-≥2 monomials — the part eliminated
    /// sparsely.
    pub high_cols: usize,
    pub dense_ms: f64,
    pub sparse_ms: f64,
    /// Heaviest row reached during sparse elimination.  Compare against
    /// `cols`: equality means fill-in has won and the rows are dense.
    pub max_weight: usize,
    /// Nonzeros before elimination, as a baseline for `max_weight`.
    pub start_max_weight: usize,
    /// Whether both paths returned the same profile.
    pub agree: bool,
}

impl EliminationComparison {
    /// Sparse time as a fraction of dense; below 1 is a win.
    pub fn ratio(&self) -> f64 {
        if self.sparse_ms == 0.0 {
            f64::INFINITY
        } else {
            self.dense_ms / self.sparse_ms
        }
    }
}

/// Time both elimination paths on the decomposition system for
/// `(n, m)` at one Macaulay degree.
pub fn elimination_comparison(
    n: u32,
    factor_index: usize,
    m: usize,
    degree: u32,
    seed: u64,
) -> Option<EliminationComparison> {
    use crate::cryptanalysis::koblitz_groebner::{
        build_macaulay_sparse, solving_profile, solving_profile_sparse,
    };
    use crate::cryptanalysis::sparse_macaulay::{eliminate_high_columns, low_column_start};

    let (irr, basis) = invariant_subspace_basis(n, factor_index)?;
    let st = FieldStructure::new(n, &irr);
    let b = F2mElement::one(n);
    let mut rng = StdRng::seed_from_u64(seed);
    let x_r = F2mElement::from_biguint(&BigUint::from(rng.gen::<u64>()), n);
    let sys = build_decomposition_system(&basis, &x_r, &b, m, &st)?;

    let (cols, rows) = build_macaulay_sparse(&sys.equations, sys.n_vars, degree)?;
    let high_cols = low_column_start(&cols);
    let start_max_weight = rows.iter().map(|r| r.len()).max().unwrap_or(0);
    let elim = eliminate_high_columns(rows, cols.len(), high_cols);

    let t0 = Instant::now();
    let dense = solving_profile(&sys.equations, sys.n_vars, degree);
    let dense_ms = t0.elapsed().as_secs_f64() * 1e3;

    let t1 = Instant::now();
    let sparse = solving_profile_sparse(&sys.equations, sys.n_vars, degree);
    let sparse_ms = t1.elapsed().as_secs_f64() * 1e3;

    let agree = match (&dense, &sparse) {
        (Some(a), Some(b)) => {
            a.rank == b.rank
                && a.refuted == b.refuted
                && a.vars_determined == b.vars_determined
                && a.resolves() == b.resolves()
        }
        (None, None) => true,
        _ => false,
    };

    Some(EliminationComparison {
        n,
        m,
        degree,
        n_vars: sys.n_vars,
        rows: dense.as_ref().map(|p| p.rows).unwrap_or(0),
        cols: cols.len(),
        high_cols,
        dense_ms,
        sparse_ms,
        max_weight: elim.max_weight,
        start_max_weight,
        agree,
    })
}

// ── Fixed-surplus ladder ───────────────────────────────────────────
//
// `subspace_ladder` takes `ℓ` from the Frobenius-invariant subspaces, so
// its surplus `S = n − mℓ` jumps with `n` (−7, −2, −19, −23 at n = 5, 7,
// 11, 13).  `RESEARCH_DESCENT_CROSSOVER.md` §2.1 shows the surplus is what
// sets a target's decomposition yield, so a ladder that lets it jump
// confounds field size with yield.  These pieces hold it fixed: a random
// subspace of any dimension, an exact count of each draw's solutions so a
// non-resolving degree can be read as a lower bound only where the system
// has none, and one draw's measurement with the cap-limited case kept
// apart from the mathematical one.

/// A uniformly random `ell`-dimensional `F₂`-subspace of `F_{2^n}`, as a
/// basis in the field's polynomial representation (`n < 64`).  Not
/// required to contain `1` or to be Frobenius-stable.
pub fn random_subspace_basis(n: u32, ell: usize, rng: &mut StdRng) -> Vec<F2mElement> {
    assert!(
        ell >= 1 && (ell as u32) < n && n < 64,
        "need 1 ≤ ℓ < n < 64"
    );
    let mask = (1u64 << n) - 1;
    // Reduced vectors with distinct leading bits, kept in descending order,
    // so `r = min(r, r ^ e)` over them reduces `r` against their span.
    let mut echelon: Vec<u64> = Vec::new();
    let mut basis = Vec::with_capacity(ell);
    while basis.len() < ell {
        let v = rng.gen::<u64>() & mask;
        let r = echelon.iter().fold(v, |r, &e| r.min(r ^ e));
        if r == 0 {
            continue;
        }
        echelon.push(r);
        echelon.sort_unstable_by(|a, b| b.cmp(a));
        basis.push(F2mElement::from_biguint(&BigUint::from(v), n));
    }
    basis
}

/// **Exact** number of Boolean solutions of the `m = 3` chained system
/// [`build_decomposition_system`] builds: tuples `(x₁, x₂, x₃, u)` with
/// `x_i ∈ span(basis)`, `u ∈ F_{2^n}`, `S₃(x₁, x₂, u) = 0` and
/// `S₃(u, x₃, x_R) = 0`, where `S₃(a, c, d) = (a+c)²d² + acd + (ac)² + b`.
///
/// Each tuple is one assignment of the system's `3ℓ + n` unknowns (the
/// summand coordinates in `basis`, then `u`'s polynomial-basis bits), so
/// this is the count an exhaustive evaluation of the system would give --
/// `chained_s3_count_matches_exhaustive_evaluation` holds it to that.  Cost
/// `2^{2ℓ+n}` quadratic evaluations, then `2^ℓ` per root.
pub fn chained_s3_solution_count(
    basis: &[F2mElement],
    x_r: &F2mElement,
    b: &F2mElement,
    irr: &crate::binary_ecc::IrreduciblePoly,
) -> u64 {
    use crate::cryptanalysis::semaev_decomp::Gf2;
    let gf = Gf2::new(irr);
    let n = irr.degree;
    let word = |e: &F2mElement| e.raw_bits().first().copied().unwrap_or(0);
    let words: Vec<u64> = basis.iter().map(word).collect();
    let span: Vec<u64> = (0..1u64 << words.len())
        .map(|c| {
            (0..words.len())
                .filter(|t| (c >> t) & 1 == 1)
                .fold(0, |acc, t| acc ^ words[t])
        })
        .collect();
    let (xr, bb) = (word(x_r), word(b));
    let s3 = |a: u64, c: u64, d: u64| {
        let ac = gf.mul(a, c);
        gf.mul(gf.sqr(a ^ c), gf.sqr(d)) ^ gf.mul(ac, d) ^ gf.sqr(ac) ^ bb
    };
    let squares: Vec<u64> = (0..1u64 << n).map(|u| gf.sqr(u)).collect();
    let mut count = 0u64;
    for &x1 in &span {
        for &x2 in &span {
            let (lead, mid) = (gf.sqr(x1 ^ x2), gf.mul(x1, x2));
            let tail = gf.sqr(mid) ^ bb;
            for (u, &uu) in squares.iter().enumerate() {
                let u = u as u64;
                if gf.mul(lead, uu) ^ gf.mul(mid, u) ^ tail != 0 {
                    continue;
                }
                count += span.iter().filter(|&&x3| s3(u, x3, xr) == 0).count() as u64;
            }
        }
    }
    count
}

/// **Exact** number of Boolean solutions of the chained system
/// [`build_decomposition_system`] builds for any `m ≥ 3`: tuples
/// `(x₁, …, x_m, e₁, …, e_{m−2})` with `x_i ∈ span(basis)`, `e_i ∈
/// F_{2^n}`, `S₃(x₁, x₂, e₁) = 0`, `S₃(e_i, x_{i+2}, e_{i+1}) = 0` and
/// `S₃(e_{m−2}, x_m, x_R) = 0`.
///
/// Each link is a quadratic in its new intermediate point, so the count
/// walks the chain: every root `e₁` of the first link, then every summand
/// and root of the next, closing on the last summand.  At `m = 3` it equals
/// [`chained_s3_solution_count`]; `chained_count_matches_exhaustive_evaluation_at_m4`
/// holds `m = 4` to an exhaustive evaluation of the system.  Cost about
/// `2^{(m−1)ℓ + n + m − 2}` field operations.
pub fn chained_solution_count(
    m: usize,
    basis: &[F2mElement],
    x_r: &F2mElement,
    b: &F2mElement,
    irr: &crate::binary_ecc::IrreduciblePoly,
) -> u64 {
    use crate::cryptanalysis::semaev_decomp::Gf2;
    assert!(m >= 3, "a chained system needs m >= 3");
    let gf = Gf2::new(irr);
    let n = irr.degree;
    let word = |e: &F2mElement| e.raw_bits().first().copied().unwrap_or(0);
    let words: Vec<u64> = basis.iter().map(word).collect();
    let span: Vec<u64> = (0..1u64 << words.len())
        .map(|c| {
            (0..words.len())
                .filter(|t| (c >> t) & 1 == 1)
                .fold(0, |acc, t| acc ^ words[t])
        })
        .collect();
    let (xr, bb) = (word(x_r), word(b));
    let squares: Vec<u64> = (0..1u64 << n).map(|u| gf.sqr(u)).collect();
    // Every `d` with S₃(a, c, d) = 0: (a+c)²d² + acd + (ac)² + b = 0.
    let roots = |a: u64, c: u64| -> Vec<u64> {
        let (lead, mid) = (gf.sqr(a ^ c), gf.mul(a, c));
        let tail = gf.sqr(mid) ^ bb;
        (0..1u64 << n)
            .filter(|&d| gf.mul(lead, squares[d as usize]) ^ gf.mul(mid, d) ^ tail == 0)
            .collect()
    };
    let s3 = |a: u64, c: u64, d: u64| {
        let ac = gf.mul(a, c);
        gf.mul(gf.sqr(a ^ c), gf.sqr(d)) ^ gf.mul(ac, d) ^ gf.sqr(ac) ^ bb
    };
    // Solutions of the links after the intermediate point `e`, with `left`
    // summands still to place; the last one closes on x(R).
    type Roots<'a> = &'a dyn Fn(u64, u64) -> Vec<u64>;
    type Link<'a> = &'a dyn Fn(u64, u64, u64) -> u64;
    fn rest(e: u64, left: usize, span: &[u64], xr: u64, roots: Roots, s3: Link) -> u64 {
        if left == 1 {
            return span.iter().filter(|&&x| s3(e, x, xr) == 0).count() as u64;
        }
        span.iter()
            .flat_map(|&x| roots(e, x))
            .map(|next| rest(next, left - 1, span, xr, roots, s3))
            .sum()
    }
    let mut count = 0u64;
    for &x1 in &span {
        for &x2 in &span {
            for e1 in roots(x1, x2) {
                count += rest(e1, m - 2, &span, xr, &roots, &s3);
            }
        }
    }
    count
}

/// The semi-regular degree of regularity over F₂ with the field equations:
/// the index of the first non-positive coefficient of
/// `(1+z)^N / ∏(1+z^{d_i})` (Bardet, Faugère, Salvy and Yang), for `N =
/// n_vars` unknowns and equations of the given degrees.  `None` if no
/// coefficient up to `2·N + 8` is non-positive.  A formula, not a
/// measurement: the reference the refutation-degree studies compare with.
/// It replaces `research/dreg_degree7_ell5_20260930/semireg.py` and
/// reproduces its table exactly (`semi_regular_dreg_reproduces_the_committed_reference`).
pub fn semi_regular_dreg(n_vars: usize, degrees: &[u32]) -> Option<u32> {
    use num_bigint::BigInt;
    use num_traits::{One, Zero};
    let cap = 2 * n_vars + 8;
    // (1+z)^N, truncated at `cap`.
    let mut c: Vec<BigInt> = Vec::with_capacity(cap + 1);
    let mut binom = BigInt::one();
    for i in 0..=cap {
        c.push(if i <= n_vars {
            binom.clone()
        } else {
            BigInt::zero()
        });
        if i < n_vars {
            binom = binom * BigInt::from(n_vars - i) / BigInt::from(i + 1);
        }
    }
    // Divide by each (1 + z^d): out[i] = c[i] - out[i - d].
    for &d in degrees {
        let d = d as usize;
        for i in d..=cap {
            let prev = c[i - d].clone();
            c[i] -= prev;
        }
    }
    c.iter()
        .position(|x| x <= &BigInt::zero())
        .map(|i| i as u32)
}

/// How one draw of a ladder cell came out.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum LadderOutcome {
    /// The system has solutions, so it can never be refuted; it was not
    /// run through the Macaulay matrices.
    Satisfiable,
    /// Resolved at this degree -- `refuted` says by the constant `1`, else
    /// by every occurring variable pinned.
    Resolved { degree: u32, refuted: bool },
    /// No solutions, and the matrix at `d_max` was built in full without
    /// resolving: the resolving degree is **at least `d_max + 1`**.  A
    /// mathematical lower bound, not a resource limit.
    AtLeast(u32),
    /// No solutions, and the size caps stopped the matrices below `d_max`
    /// (`built` is the last degree built, if any).  Unknown -- a resource
    /// limit, never evidence about the degree.
    CapsHit { built: Option<u32> },
}

/// One draw of a fixed-surplus ladder cell.
#[derive(Clone, Debug)]
pub struct LadderDraw {
    /// Summands per decomposition: 3 for every cell before the `m = 4` study.
    pub m: usize,
    pub n: u32,
    pub ell: u32,
    pub n_vars: usize,
    pub n_eqs: usize,
    pub v_basis: Vec<u64>,
    pub x_r: u64,
    pub solutions: u64,
    pub outcome: LadderOutcome,
    /// First fall degree, when a fall occurs by `ffd_max`; only measured on
    /// draws with no solutions.
    pub ffd: Option<u32>,
    pub secs: f64,
}

/// The random part of one ladder draw: a subspace basis, then a target
/// abscissa, consuming `rng` exactly as [`ladder_draw`] does.  Replaying it
/// reproduces a cell's draw sequence without measuring anything, so a single
/// draw can be measured on its own (`dreg_ladder --unsat-index`).
pub fn ladder_sample(n: u32, ell: usize, rng: &mut StdRng) -> (Vec<F2mElement>, F2mElement) {
    let basis = random_subspace_basis(n, ell, rng);
    let x_r = F2mElement::from_biguint(&BigUint::from(rng.gen::<u64>() & ((1u64 << n) - 1)), n);
    (basis, x_r)
}

/// Measure one sampled draw of the `m = 3` cell `(n, ℓ = basis.len())`.  The
/// exact solution count comes first; only a system with none goes through
/// [`first_fall_degree`] (to `ffd_max`) and [`solving_degree`] (to `d_max`).
pub fn ladder_measure(
    n: u32,
    basis: &[F2mElement],
    x_r: &F2mElement,
    d_max: u32,
    ffd_max: u32,
) -> Option<LadderDraw> {
    ladder_measure_from(n, basis, x_r, 1, d_max, ffd_max)
}

/// [`ladder_measure`] with the degree scan starting at `d_min`, for a draw
/// whose lower degrees are already measured not to resolve (a committed
/// run of the same draw).  `Resolved { degree }` is then the exact
/// resolving degree and `AtLeast(d_max + 1)` the bound, as before.
pub fn ladder_measure_from(
    n: u32,
    basis: &[F2mElement],
    x_r: &F2mElement,
    d_min: u32,
    d_max: u32,
    ffd_max: u32,
) -> Option<LadderDraw> {
    ladder_measure_m(3, n, basis, x_r, d_min, d_max, ffd_max)
}

/// [`ladder_measure_from`] for the chained system with `m ≥ 3` summands:
/// `m − 2` intermediate points, so `(m − 2)·n + m·ℓ` unknowns and `(m − 1)·n`
/// equations.  At `m = 3` it is exactly [`ladder_measure_from`] (the same
/// solution count, [`chained_s3_solution_count`]); at larger `m` the count
/// is [`chained_solution_count`].
pub fn ladder_measure_m(
    m: usize,
    n: u32,
    basis: &[F2mElement],
    x_r: &F2mElement,
    d_min: u32,
    d_max: u32,
    ffd_max: u32,
) -> Option<LadderDraw> {
    use crate::cryptanalysis::koblitz_groebner::solving_degree_from;
    use crate::cryptanalysis::koblitz_index_calculus::find_irreducible_sparse;
    let started = Instant::now();
    let irr = find_irreducible_sparse(n)?;
    let st = FieldStructure::new(n, &irr);
    let b = F2mElement::one(n);
    let sys = build_decomposition_system(basis, x_r, &b, m, &st)?;
    let solutions = if m == 3 {
        chained_s3_solution_count(basis, x_r, &b, &irr)
    } else {
        chained_solution_count(m, basis, x_r, &b, &irr)
    };
    let word = |e: &F2mElement| e.raw_bits().first().copied().unwrap_or(0);
    let mut ffd = None;
    let outcome = if solutions > 0 {
        LadderOutcome::Satisfiable
    } else {
        ffd = first_fall_degree(&sys.equations, sys.n_vars, ffd_max).0;
        let (d, profs) = solving_degree_from(&sys.equations, sys.n_vars, d_min, d_max);
        let built = profs.last().map(|p| p.degree);
        match d {
            Some(degree) => LadderOutcome::Resolved {
                degree,
                refuted: profs.last().map(|p| p.refuted).unwrap_or(false),
            },
            None if built == Some(d_max) => LadderOutcome::AtLeast(d_max + 1),
            None => LadderOutcome::CapsHit { built },
        }
    };
    Some(LadderDraw {
        m,
        n,
        ell: basis.len() as u32,
        n_vars: sys.n_vars,
        n_eqs: sys.equations.len(),
        v_basis: basis.iter().map(word).collect(),
        x_r: word(x_r),
        solutions,
        outcome,
        ffd,
        secs: started.elapsed().as_secs_f64(),
    })
}

/// Draw one `(V, x_R)` for the `m = 3` cell `(n, ℓ)` and measure it:
/// [`ladder_sample`] then [`ladder_measure`].
pub fn ladder_draw(
    n: u32,
    ell: usize,
    d_max: u32,
    ffd_max: u32,
    rng: &mut StdRng,
) -> Option<LadderDraw> {
    let (basis, x_r) = ladder_sample(n, ell, rng);
    ladder_measure(n, &basis, &x_r, d_max, ffd_max)
}

/// [`ladder_draw`] for `m` summands: the same sample, measured by
/// [`ladder_measure_m`].  At `m = 3` it is [`ladder_draw`].
pub fn ladder_draw_m(
    m: usize,
    n: u32,
    ell: usize,
    d_max: u32,
    ffd_max: u32,
    rng: &mut StdRng,
) -> Option<LadderDraw> {
    let (basis, x_r) = ladder_sample(n, ell, rng);
    ladder_measure_m(m, n, &basis, &x_r, 1, d_max, ffd_max)
}

/// One degree of a [`closure_refutation_scan`]: the plain degree-`D`
/// Macaulay row space (XL) and the same space saturated under MutantXL's
/// fixed-degree step (every degree fall times every monomial that keeps the
/// product within degree `D`, repeated until nothing new falls).
#[derive(Clone, Debug)]
pub struct ClosureDegree {
    pub degree: u32,
    /// The plain row space contains `1`.
    pub xl_refuted: bool,
    /// The saturated row space contains `1`.
    pub closure_refuted: bool,
    /// The closure stopped with no degree fall left unmultiplied (or on `1`).
    pub saturated: bool,
    pub xl_rank: usize,
    pub closure_rank: usize,
    pub columns: usize,
    pub closure_products: u64,
    /// Word operations the closed build charged ([`InheritCost::word_ops`]).
    pub closure_word_ops: u64,
    pub secs: f64,
}

/// The XL and the closure refutation degrees of `system`, scanned from
/// `d_min` to `d_max`: the first degree whose plain Macaulay row space
/// contains `1`, and the first whose closure under degree falls does.  Every
/// closure product lies in the ideal, so the closure degree is never above
/// the XL degree; where it is below, the system refutes at a smaller
/// matrix than XL needs.  The scan stops once both have refuted, or at the
/// first degree whose matrix exceeds the F4 size caps (the remaining
/// degrees are then not measured).  The closure is full MutantXL
/// ([`ReducedBasis::from_system_closed_full`]): linear falls are multiplied
/// out too.  Degree 1 builds no closure, so it reports XL's outcome for
/// both.
///
/// [`InheritCost::word_ops`]: crate::cryptanalysis::inherited_f4::InheritCost::word_ops
/// [`ReducedBasis::from_system_closed_full`]: crate::cryptanalysis::inherited_f4::ReducedBasis::from_system_closed_full
pub fn closure_refutation_scan(
    system: &[F2BoolPoly],
    n_vars: usize,
    d_min: u32,
    d_max: u32,
) -> Vec<ClosureDegree> {
    use crate::cryptanalysis::inherited_f4::ReducedBasis;
    const ROUNDS: u32 = 1_000_000;
    let mut out = Vec::new();
    let (mut xl_done, mut closure_done) = (false, false);
    for degree in d_min..=d_max {
        let started = Instant::now();
        // The plain basis is read and dropped before the closure is built,
        // so the two dense matrices are never held at once.
        let Some((xl_refuted, xl_rank)) = ReducedBasis::from_system(system, n_vars, degree)
            .map(|(xl, _)| (xl.is_refuted(), xl.rank()))
        else {
            break;
        };
        let Some((closed, cost)) =
            ReducedBasis::from_system_closed_full(system, n_vars, degree, ROUNDS)
        else {
            break;
        };
        out.push(ClosureDegree {
            degree,
            xl_refuted,
            closure_refuted: closed.is_refuted(),
            saturated: closed.is_refuted() || closed.pending_falls() == 0,
            xl_rank,
            closure_rank: closed.rank(),
            columns: closed.columns(),
            closure_products: cost.closure_products,
            closure_word_ops: cost.word_ops(),
            secs: started.elapsed().as_secs_f64(),
        });
        xl_done |= xl_refuted;
        closure_done |= closed.is_refuted();
        if xl_done && closure_done {
            break;
        }
    }
    out
}

/// Outcome of [`sparse_closure_refutes`] at one degree.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SparseClosure {
    pub degree: u32,
    /// `1` entered the saturated row space.
    pub refuted: bool,
    /// The worklist emptied: every fall was multiplied out (or `1` fell).
    pub saturated: bool,
    /// Rows in the echelon basis when the scan stopped.
    pub rank: usize,
    /// Falls found (basis rows whose leading monomial has degree < `degree`).
    pub falls: u64,
    /// Fall-times-monomial products inserted.
    pub products: u64,
    /// Largest number of nonzeros any stored row reached.
    pub max_weight: usize,
}

/// MutantXL's fixed-degree closure on a **sparse** echelon basis: the same
/// question [`closure_refutation_scan`] asks of the dense
/// [`ReducedBasis::from_system_closed_full`], without the dense matrix.
///
/// Rows are sorted monomial masks, leading monomial first, in an order that
/// ranks higher total degree first (ties by mask).  Every Macaulay row of
/// degree `≤ degree` is inserted, reduced by leading term against the
/// stored pivots.  A stored row whose leading monomial has degree below
/// `degree` is a **fall**.
///
/// - Because stored leading monomials are distinct, a combination of
///   stored rows has the smallest participating leading monomial (no
///   cancellation of the lead). So the stored falls span the row space's
///   intersection with degree `< degree` exactly. This is the
///   fall space the dense closure multiplies out.
/// - Each fall `f` is multiplied by every monomial `t` with
///   `1 ≤ deg t ≤ degree − deg f` over the occurring variables, and each
///   product is inserted in turn, until no fall is left unprocessed.
/// - The scan stops at `1` (a stored row equal to the constant) or when
///   `max_entries` total stored nonzeros would be exceeded. On a cap it
///   returns `None`, which is unmeasured, never a refutation.
///
/// Every product lies in the ideal, so a refutation is sound. The
/// saturated span equals the dense closure's, so the two agree on
/// refutation, which `sparse_closure_matches_the_dense_closure` checks.
///
/// [`ReducedBasis::from_system_closed_full`]: crate::cryptanalysis::inherited_f4::ReducedBasis::from_system_closed_full
pub fn sparse_closure_refutes(
    system: &[F2BoolPoly],
    n_vars: usize,
    degree: u32,
    max_entries: usize,
) -> Option<SparseClosure> {
    use crate::cryptanalysis::koblitz_groebner::build_macaulay_sparse;
    use std::cmp::Ordering;
    use std::collections::HashMap;

    // Higher degree first; ties by mask.  Rows are ascending in this order,
    // so the leading monomial is row[0].
    let cmp = |a: &u64, b: &u64| -> Ordering { b.count_ones().cmp(&a.count_ones()).then(a.cmp(b)) };
    let xor = |a: &[u64], b: &[u64]| -> Vec<u64> {
        let mut out = Vec::with_capacity(a.len() + b.len());
        let (mut i, mut j) = (0, 0);
        while i < a.len() && j < b.len() {
            match cmp(&a[i], &b[j]) {
                Ordering::Less => {
                    out.push(a[i]);
                    i += 1;
                }
                Ordering::Greater => {
                    out.push(b[j]);
                    j += 1;
                }
                Ordering::Equal => {
                    i += 1;
                    j += 1;
                }
            }
        }
        out.extend_from_slice(&a[i..]);
        out.extend_from_slice(&b[j..]);
        out
    };
    let occurring = system
        .iter()
        .flat_map(|p| p.terms.iter())
        .fold(0u64, |acc, t| acc | t.mask);
    let vars: Vec<u64> = (0..64)
        .filter(|i| occurring >> i & 1 == 1)
        .map(|i| 1u64 << i)
        .collect();
    // Monomials of degree 1..=k over the occurring variables.
    let monomials_up_to = |k: u32| -> Vec<u64> {
        let mut out = Vec::new();
        let mut frontier = vec![(0u64, 0usize)];
        for _ in 0..k {
            let mut next = Vec::new();
            for &(m, start) in &frontier {
                for (i, &v) in vars.iter().enumerate().skip(start) {
                    next.push((m | v, i + 1));
                }
            }
            out.extend(next.iter().map(|&(m, _)| m));
            frontier = next;
        }
        out
    };

    let (cols, rows) = build_macaulay_sparse(system, n_vars, degree)?;
    let mut pivots: HashMap<u64, Vec<u64>> = HashMap::new();
    let mut entries = 0usize;
    let mut out = SparseClosure {
        degree,
        refuted: false,
        saturated: false,
        rank: 0,
        falls: 0,
        products: 0,
        max_weight: 0,
    };
    let mut queue: Vec<Vec<u64>> = Vec::new();

    // Insert one row; a new fall goes on the queue.  `false` on the cap.
    let mut insert = |mut row: Vec<u64>,
                      pivots: &mut HashMap<u64, Vec<u64>>,
                      queue: &mut Vec<Vec<u64>>,
                      out: &mut SparseClosure|
     -> bool {
        row.sort_unstable_by(cmp);
        // Boolean products can repeat a monomial; equal pairs cancel.
        let mut dedup: Vec<u64> = Vec::with_capacity(row.len());
        for m in row {
            if dedup.last() == Some(&m) {
                dedup.pop();
            } else {
                dedup.push(m);
            }
        }
        let mut row = dedup;
        while let Some(&lead) = row.first() {
            match pivots.get(&lead) {
                Some(p) => row = xor(&row, p),
                None => break,
            }
        }
        let Some(&lead) = row.first() else {
            return true;
        };
        entries += row.len();
        if entries > max_entries {
            return false;
        }
        out.max_weight = out.max_weight.max(row.len());
        out.rank += 1;
        if lead == 0 {
            out.refuted = true;
        }
        if lead.count_ones() < degree {
            out.falls += 1;
            queue.push(row.clone());
        }
        pivots.insert(lead, row);
        true
    };

    for r in rows {
        let row: Vec<u64> = r.iter().map(|&c| cols[c as usize]).collect();
        if !insert(row, &mut pivots, &mut queue, &mut out) {
            return None;
        }
        if out.refuted {
            out.saturated = true;
            return Some(out);
        }
    }
    let mut multipliers: HashMap<u32, Vec<u64>> = HashMap::new();
    while let Some(fall) = queue.pop() {
        let room = degree - fall[0].count_ones();
        let ts = multipliers
            .entry(room)
            .or_insert_with(|| monomials_up_to(room))
            .clone();
        for t in ts {
            out.products += 1;
            let product: Vec<u64> = fall.iter().map(|&m| m | t).collect();
            if !insert(product, &mut pivots, &mut queue, &mut out) {
                return None;
            }
            if out.refuted {
                out.saturated = true;
                return Some(out);
            }
        }
    }
    out.saturated = true;
    Some(out)
}

/// The infeasible null object for a ladder cell: same unknowns, degree and
/// term density as the cell's systems, `n_vars + 4` equations, run to
/// `d_max` exactly like a draw.  See [`random_control_system`].
pub fn ladder_control(
    n_vars: usize,
    degree: u32,
    terms_per_eq: usize,
    d_max: u32,
    seed: u64,
) -> LadderOutcome {
    let polys = random_control_system(n_vars, n_vars + 4, degree, terms_per_eq, seed);
    let (d, profs) = solving_degree(&polys, n_vars, d_max);
    let built = profs.last().map(|p| p.degree);
    match d {
        Some(degree) => LadderOutcome::Resolved {
            degree,
            refuted: profs.last().map(|p| p.refuted).unwrap_or(false),
        },
        None if built == Some(d_max) => LadderOutcome::AtLeast(d_max + 1),
        None => LadderOutcome::CapsHit { built },
    }
}

/// The sparse elimination's cost on one cell at one degree, and nothing
/// about its outcome: matrix shape, build and elimination time, row weight
/// before and after.  For cells too large for [`elimination_comparison`]'s
/// dense pass.
#[derive(Clone, Debug)]
pub struct SparseEliminationCost {
    pub n: u32,
    pub m: usize,
    pub degree: u32,
    pub n_vars: usize,
    pub rows: usize,
    pub cols: usize,
    pub high_cols: usize,
    pub build_ms: f64,
    pub sparse_ms: f64,
    pub start_max_weight: usize,
    pub max_weight: usize,
}

/// See [`SparseEliminationCost`].  Same cell construction as
/// [`elimination_comparison`], so the two are comparable where both run.
pub fn sparse_elimination_cost(
    n: u32,
    factor_index: usize,
    m: usize,
    degree: u32,
    seed: u64,
) -> Option<SparseEliminationCost> {
    use crate::cryptanalysis::koblitz_groebner::build_macaulay_sparse;
    use crate::cryptanalysis::sparse_macaulay::{eliminate_high_columns, low_column_start};

    let (irr, basis) = invariant_subspace_basis(n, factor_index)?;
    let st = FieldStructure::new(n, &irr);
    let b = F2mElement::one(n);
    let mut rng = StdRng::seed_from_u64(seed);
    let x_r = F2mElement::from_biguint(&BigUint::from(rng.gen::<u64>()), n);
    let sys = build_decomposition_system(&basis, &x_r, &b, m, &st)?;

    let t0 = Instant::now();
    let (cols, rows) = build_macaulay_sparse(&sys.equations, sys.n_vars, degree)?;
    let build_ms = t0.elapsed().as_secs_f64() * 1e3;
    let high_cols = low_column_start(&cols);
    let start_max_weight = rows.iter().map(|r| r.len()).max().unwrap_or(0);
    let n_rows = rows.len();
    let t1 = Instant::now();
    let elim = eliminate_high_columns(rows, cols.len(), high_cols);
    let sparse_ms = t1.elapsed().as_secs_f64() * 1e3;
    Some(SparseEliminationCost {
        n,
        m,
        degree,
        n_vars: sys.n_vars,
        rows: n_rows,
        cols: cols.len(),
        high_cols,
        build_ms,
        sparse_ms,
        start_max_weight,
        max_weight: elim.max_weight,
    })
}

/// Where one degree's structured elimination spends its work, by column
/// degree band, for one ladder draw given by its recorded `(V, x_R)`.
///
/// Runs the same algorithm as
/// [`crate::cryptanalysis::sparse_macaulay::eliminate_high_columns`]
/// (lowest-weight pivot per leading column, columns in descending monomial
/// order) with counters added, so a profile describes the measured path
/// rather than a model of it.  `ladder_refutation_profile_matches_the_eliminator`
/// holds the two to the same rank, vanished rows and linear rows.
#[derive(Clone, Debug)]
pub struct RefutationBand {
    /// Monomial degree of the columns in this band.
    pub degree: u32,
    pub columns: usize,
    pub pivots: usize,
    /// Row additions performed while eliminating this band.
    pub xors: u64,
    /// Total length of the rows those additions produced: the work, in
    /// column indices written.
    pub xor_output: u64,
    /// Nonzeros left in the non-pivot rows when the band is done.
    pub active_nnz_after: u64,
    pub ms: f64,
}

/// See [`RefutationBand`].
#[derive(Clone, Debug)]
pub struct RefutationProfile {
    pub n_vars: usize,
    pub rows: usize,
    pub cols: usize,
    pub start_nnz: u64,
    pub build_ms: f64,
    pub bands: Vec<RefutationBand>,
    pub high_rank: usize,
    pub vanished: usize,
    pub linear_rows: usize,
    pub max_weight: usize,
}

/// For one degree of one ladder draw (arguments as in
/// [`ladder_refutation_profile`]): the Macaulay rows, the rows the F5
/// criterion keeps, and the milliseconds evaluating the criterion and
/// counting took.  Nothing is eliminated.
pub fn ladder_f5_row_counts(
    n: u32,
    basis: &[u64],
    x_r: u64,
    degree: u32,
) -> Option<(usize, usize, f64)> {
    use crate::cryptanalysis::koblitz_groebner::f5_row_counts;
    use crate::cryptanalysis::koblitz_index_calculus::find_irreducible_sparse;

    let irr = find_irreducible_sparse(n)?;
    let st = FieldStructure::new(n, &irr);
    let elem = |w: u64| F2mElement::from_biguint(&BigUint::from(w), n);
    let basis: Vec<F2mElement> = basis.iter().map(|&w| elem(w)).collect();
    let sys = build_decomposition_system(&basis, &elem(x_r), &F2mElement::one(n), 3, &st)?;
    let t0 = Instant::now();
    let (full, kept) = f5_row_counts(&sys.equations, sys.n_vars, degree)?;
    Some((full, kept, t0.elapsed().as_secs_f64() * 1e3))
}

/// Profile one degree of one ladder draw.  `basis` and `x_r` are the
/// recorded low words of the draw's `V` basis and `x_R`, as the ladder's
/// JSON lines print them.
pub fn ladder_refutation_profile(
    n: u32,
    basis: &[u64],
    x_r: u64,
    degree: u32,
) -> Option<RefutationProfile> {
    use crate::cryptanalysis::koblitz_groebner::build_macaulay_sparse;
    use crate::cryptanalysis::koblitz_index_calculus::find_irreducible_sparse;
    use crate::cryptanalysis::sparse_macaulay::{low_column_start, xor_sorted};
    use std::mem::take;

    let irr = find_irreducible_sparse(n)?;
    let st = FieldStructure::new(n, &irr);
    let elem = |w: u64| F2mElement::from_biguint(&BigUint::from(w), n);
    let basis: Vec<F2mElement> = basis.iter().map(|&w| elem(w)).collect();
    let sys = build_decomposition_system(&basis, &elem(x_r), &F2mElement::one(n), 3, &st)?;

    let t0 = Instant::now();
    let (cols, mut rows) = build_macaulay_sparse(&sys.equations, sys.n_vars, degree)?;
    let build_ms = t0.elapsed().as_secs_f64() * 1e3;
    let n_cols = cols.len();
    let low_start = low_column_start(&cols);
    let start_nnz = rows.iter().map(|r| r.len() as u64).sum();
    let mut max_weight = rows.iter().map(|r| r.len()).max().unwrap_or(0);
    let n_rows = rows.len();

    let mut buckets: Vec<Vec<usize>> = vec![Vec::new(); n_cols.max(1)];
    let mut vanished = 0usize;
    for (i, r) in rows.iter().enumerate() {
        match r.first() {
            Some(&lead) => buckets[lead as usize].push(i),
            None => vanished += 1,
        }
    }
    let mut is_pivot = vec![false; n_rows];
    let mut bands: Vec<RefutationBand> = Vec::new();
    let mut c = 0usize;
    while c < low_start.min(n_cols) {
        let deg = cols[c].count_ones();
        let mut band = RefutationBand {
            degree: deg,
            columns: 0,
            pivots: 0,
            xors: 0,
            xor_output: 0,
            active_nnz_after: 0,
            ms: 0.0,
        };
        let tb = Instant::now();
        while c < low_start.min(n_cols) && cols[c].count_ones() == deg {
            band.columns += 1;
            let bucket = take(&mut buckets[c]);
            if !bucket.is_empty() {
                let piv = *bucket
                    .iter()
                    .min_by_key(|&&i| rows[i].len())
                    .expect("non-empty");
                is_pivot[piv] = true;
                band.pivots += 1;
                let pivot_row = rows[piv].clone();
                for i in bucket {
                    if i == piv {
                        continue;
                    }
                    let reduced = xor_sorted(&rows[i], &pivot_row);
                    band.xors += 1;
                    band.xor_output += reduced.len() as u64;
                    max_weight = max_weight.max(reduced.len());
                    match reduced.first() {
                        Some(&lead) => buckets[lead as usize].push(i),
                        None => vanished += 1,
                    }
                    rows[i] = reduced;
                }
            }
            c += 1;
        }
        band.ms = tb.elapsed().as_secs_f64() * 1e3;
        band.active_nnz_after = rows
            .iter()
            .zip(&is_pivot)
            .filter(|(_, &p)| !p)
            .map(|(r, _)| r.len() as u64)
            .sum();
        bands.push(band);
    }
    let linear_rows = rows
        .iter()
        .zip(&is_pivot)
        .filter(|(r, &p)| !p && !r.is_empty() && r[0] as usize >= low_start)
        .count();
    Some(RefutationProfile {
        n_vars: sys.n_vars,
        rows: n_rows,
        cols: n_cols,
        start_nnz,
        build_ms,
        high_rank: bands.iter().map(|b| b.pivots).sum(),
        bands,
        vanished,
        linear_rows,
        max_weight,
    })
}

/// The dense Macaulay matrix of one frozen decomposition system, for
/// benchmarking an elimination kernel on the matrices the oracle really
/// reduces: the system `build_decomposition_system` makes for `m`
/// summands over factor-base subspace `factor_index` of `K / F_2^n`, with
/// the target abscissa drawn from `seed`, expanded to `degree`.
///
/// Returns `(variables, columns, rows)`; `None` when the cell has no
/// invariant subspace or exceeds the builder's size caps.
pub fn decomposition_macaulay(
    n: u32,
    factor_index: usize,
    m: usize,
    degree: u32,
    seed: u64,
) -> Option<(usize, usize, Vec<Vec<u64>>)> {
    use crate::cryptanalysis::koblitz_groebner::build_macaulay;

    let (irr, basis) = invariant_subspace_basis(n, factor_index)?;
    let st = FieldStructure::new(n, &irr);
    let b = F2mElement::one(n);
    let mut rng = StdRng::seed_from_u64(seed);
    let x_r = F2mElement::from_biguint(&BigUint::from(rng.gen::<u64>()), n);
    let sys = build_decomposition_system(&basis, &x_r, &b, m, &st)?;
    let (cols, matrix) = build_macaulay(&sys.equations, sys.n_vars, degree)?;
    Some((sys.n_vars, cols.len(), matrix))
}

/// The elimination kernel the Gröbner oracle used before
/// [`crate::cryptanalysis::gf2_elim`], exposed as the same-binary control
/// for it: reduced row echelon form in place, returning the rank and
/// charging the word XORs to `word_ops`.
pub fn rref_f2_legacy(matrix: &mut [Vec<u64>], n_cols: usize, word_ops: &mut u64) -> usize {
    crate::cryptanalysis::koblitz_groebner::rref_f2_legacy_counted(matrix, n_cols, word_ops)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The exact counter is the count an exhaustive evaluation of the
    /// built system gives, on every draw of every small cell -- the check
    /// that its `S₃`, its `b`, its basis map and its variable layout are the
    /// system's.  Includes satisfiable and unsatisfiable draws.
    #[test]
    fn chained_s3_count_matches_exhaustive_evaluation() {
        use crate::cryptanalysis::koblitz_index_calculus::find_irreducible_sparse;
        let mut rng = StdRng::seed_from_u64(0x1ADD_E5);
        let (mut sat, mut unsat) = (0usize, 0usize);
        for (n, ell) in [(5u32, 2usize), (5, 3), (7, 2), (7, 3), (9, 3)] {
            let irr = find_irreducible_sparse(n).unwrap();
            let st = FieldStructure::new(n, &irr);
            let b = F2mElement::one(n);
            for _ in 0..6 {
                let basis = random_subspace_basis(n, ell, &mut rng);
                let x_r = F2mElement::from_biguint(
                    &BigUint::from(rng.gen::<u64>() & ((1u64 << n) - 1)),
                    n,
                );
                let sys = build_decomposition_system(&basis, &x_r, &b, 3, &st).unwrap();
                let exhaustive = (0u64..1 << sys.n_vars)
                    .filter(|&a| sys.equations.iter().all(|p| p.eval(a) == 0))
                    .count() as u64;
                let counted = chained_s3_solution_count(&basis, &x_r, &b, &irr);
                assert_eq!(counted, exhaustive, "n={n} ℓ={ell}");
                if counted == 0 {
                    unsat += 1
                } else {
                    sat += 1
                }
            }
        }
        assert!(
            sat > 0 && unsat > 0,
            "both kinds of draw exercised: {sat} sat, {unsat} unsat"
        );
    }

    /// The `m = 4` chain's exact count is what an exhaustive evaluation of
    /// the built system gives: two intermediate points, `2n + 4ℓ` unknowns,
    /// satisfiable and unsatisfiable draws both.
    #[test]
    fn chained_count_matches_exhaustive_evaluation_at_m4() {
        use crate::cryptanalysis::koblitz_index_calculus::find_irreducible_sparse;
        let mut rng = StdRng::seed_from_u64(0x4_C4A1);
        let (mut sat, mut unsat) = (0usize, 0usize);
        for (n, ell) in [(3u32, 1usize), (4, 1), (5, 1), (4, 2), (5, 2)] {
            let irr = find_irreducible_sparse(n).unwrap();
            let st = FieldStructure::new(n, &irr);
            let b = F2mElement::one(n);
            for _ in 0..6 {
                let (basis, x_r) = ladder_sample(n, ell, &mut rng);
                let sys = build_decomposition_system(&basis, &x_r, &b, 4, &st).unwrap();
                assert_eq!(sys.n_vars, 2 * n as usize + 4 * ell);
                let exhaustive = (0u64..1 << sys.n_vars)
                    .filter(|&a| sys.equations.iter().all(|p| p.eval(a) == 0))
                    .count() as u64;
                let counted = chained_solution_count(4, &basis, &x_r, &b, &irr);
                assert_eq!(counted, exhaustive, "n={n} ℓ={ell}");
                if counted == 0 {
                    unsat += 1
                } else {
                    sat += 1
                }
            }
        }
        assert!(
            sat > 0 && unsat > 0,
            "both kinds of draw exercised: {sat} sat, {unsat} unsat"
        );
    }

    /// At `m = 3` the general chained count is the `S₃` count it generalises.
    #[test]
    fn chained_count_at_m3_is_the_s3_count() {
        use crate::cryptanalysis::koblitz_index_calculus::find_irreducible_sparse;
        let mut rng = StdRng::seed_from_u64(0x3_C4A1);
        for (n, ell) in [(5u32, 2usize), (7, 2), (7, 3), (9, 3)] {
            let irr = find_irreducible_sparse(n).unwrap();
            let b = F2mElement::one(n);
            for _ in 0..8 {
                let (basis, x_r) = ladder_sample(n, ell, &mut rng);
                assert_eq!(
                    chained_solution_count(3, &basis, &x_r, &b, &irr),
                    chained_s3_solution_count(&basis, &x_r, &b, &irr),
                    "n={n} ℓ={ell}"
                );
            }
        }
    }

    /// The native semi-regular degree reproduces the reference table the
    /// degree-7 study committed (`research/dreg_degree7_ell5_20260930/semireg.py`
    /// for the 17 measured `m = 3` cells, and the `n = 131` values its
    /// ECC2K-130 note quotes).
    #[test]
    fn semi_regular_dreg_reproduces_the_committed_reference() {
        let m3 = |n: usize, ell: usize| {
            let degrees: Vec<u32> = std::iter::repeat_n(2, n)
                .chain(std::iter::repeat_n(3, n))
                .collect();
            semi_regular_dreg(n + 3 * ell, &degrees).unwrap()
        };
        for (n, ell, want) in [
            (5, 2, 5),
            (7, 2, 5),
            (8, 2, 5),
            (10, 2, 5),
            (12, 2, 5),
            (4, 3, 5),
            (5, 3, 5),
            (7, 3, 6),
            (9, 3, 6),
            (7, 4, 6),
            (8, 4, 6),
            (11, 4, 7),
            (13, 4, 7),
            (10, 5, 7),
            (11, 5, 7),
            (13, 5, 7),
            (15, 5, 8),
            (131, 20, 25),
            (131, 26, 28),
            (131, 33, 32),
            (131, 43, 38),
        ] {
            assert_eq!(m3(n, ell), want, "({n}, {ell})");
        }
        // No equations: the first non-positive coefficient of (1+z)^N is N+1.
        assert_eq!(semi_regular_dreg(6, &[]), Some(7));
    }

    /// `ladder_measure_m` at `m = 4` builds the two-link-longer chain and
    /// sends only draws with no solutions to the Macaulay matrices.
    #[test]
    fn ladder_measure_m_builds_the_m4_chain() {
        let mut rng = StdRng::seed_from_u64(0x4_4EA5);
        let (mut sat, mut measured) = (0, 0);
        for _ in 0..24 {
            let (basis, x_r) = ladder_sample(4, 1, &mut rng);
            let d = ladder_measure_m(4, 4, &basis, &x_r, 1, 6, 4).unwrap();
            assert_eq!((d.m, d.n_vars), (4, 2 * 4 + 4));
            if d.solutions > 0 {
                assert_eq!(d.outcome, LadderOutcome::Satisfiable);
                sat += 1;
            } else {
                assert_ne!(d.outcome, LadderOutcome::Satisfiable);
                measured += 1;
            }
        }
        assert!(sat > 0 && measured > 0, "{sat} sat, {measured} measured");
    }

    /// Positive control for the closure scan: a system whose degree fall
    /// `x7 + 1` (the sum of two cubics) times `x8 x9` meets a third cubic in
    /// `1`.  The closure refutes at degree 3; plain XL needs degree 4, where
    /// `x7 · f3 = x7` is a row and meets the fall.
    #[test]
    fn closure_scan_refutes_below_xl_on_the_constructed_control() {
        let n = 9;
        let m = |vars: &[u32]| F2BoolMono::from_mask(vars.iter().fold(0, |a, &v| a | 1 << v));
        let f1 = F2BoolPoly::from_monos(vec![m(&[0, 1, 2]), m(&[3, 4, 5])], n);
        let f2 = F2BoolPoly::from_monos(
            vec![m(&[0, 1, 2]), m(&[3, 4, 5]), m(&[6]), F2BoolMono::one()],
            n,
        );
        let f3 = F2BoolPoly::from_monos(vec![m(&[6, 7, 8]), m(&[7, 8]), F2BoolMono::one()], n);
        let scan = closure_refutation_scan(&[f1.clone(), f2.clone(), f3.clone()], n, 3, 6);
        let first = |f: fn(&ClosureDegree) -> bool| scan.iter().find(|d| f(d)).map(|d| d.degree);
        assert_eq!(first(|d| d.closure_refuted), Some(3));
        assert_eq!(first(|d| d.xl_refuted), Some(4));
        // The plain basis agrees with the repository's XL engine.
        let (xl, _) = crate::cryptanalysis::koblitz_groebner::solving_degree(&[f1, f2, f3], n, 6);
        assert_eq!(xl, Some(4));
    }

    /// On unsatisfiable chained draws the closure never refutes later than
    /// XL, saturates, and the plain basis refutes exactly where the
    /// repository's XL engine does.
    #[test]
    fn sparse_closure_matches_the_dense_closure() {
        use crate::cryptanalysis::koblitz_index_calculus::find_irreducible_sparse;
        // The constructed control: closure refutes at 3, not at 2.
        let n = 9;
        let x = |i: usize| F2BoolMono { mask: 1u64 << i };
        let mono = |m: u64| F2BoolMono { mask: m };
        let poly = |terms: Vec<F2BoolMono>| F2BoolPoly { terms, n_vars: n };
        let t3 = |a: usize, b: usize, c: usize| mono((1 << a) | (1 << b) | (1 << c));
        let f1 = poly(vec![t3(0, 1, 2), t3(3, 4, 5)]);
        let f2 = poly(vec![t3(0, 1, 2), t3(3, 4, 5), x(6), F2BoolMono::one()]);
        let f3 = poly(vec![
            t3(6, 7, 8),
            mono((1 << 7) | (1 << 8)),
            F2BoolMono::one(),
        ]);
        let control = vec![f1, f2, f3];
        for d in 3..=4u32 {
            let dense = closure_refutation_scan(&control, n, d, d);
            let sparse = sparse_closure_refutes(&control, n, d, usize::MAX).unwrap();
            assert_eq!(sparse.refuted, dense[0].closure_refuted, "control at {d}");
            assert!(sparse.saturated);
        }
        // Chained draws, satisfiable and not: same refutation at every degree.
        let mut checked = (0, 0);
        for (m, n, ell, seed) in [(3usize, 5u32, 2usize, 11u64), (3, 7, 2, 12), (4, 4, 1, 13)] {
            let mut rng = StdRng::seed_from_u64(seed);
            for _ in 0..6 {
                let (basis, x_r) = ladder_sample(n, ell, &mut rng);
                let irr = find_irreducible_sparse(n).unwrap();
                let st = FieldStructure::new(n, &irr);
                let b = F2mElement::one(n);
                let sys = build_decomposition_system(&basis, &x_r, &b, m, &st).unwrap();
                for d in 3..=4u32 {
                    let dense = closure_refutation_scan(&sys.equations, sys.n_vars, d, d);
                    let sparse =
                        sparse_closure_refutes(&sys.equations, sys.n_vars, d, usize::MAX).unwrap();
                    assert!(sparse.saturated && dense[0].saturated);
                    assert_eq!(
                        sparse.refuted, dense[0].closure_refuted,
                        "m={m} n={n} ell={ell} seed={seed} degree {d}"
                    );
                    if sparse.refuted {
                        checked.0 += 1;
                    } else {
                        checked.1 += 1;
                    }
                }
            }
        }
        // Both outcomes occur, so the agreement is not vacuous.
        assert!(checked.0 > 0 && checked.1 > 0, "{checked:?}");
    }

    #[test]
    fn closure_scan_is_never_above_xl_on_chained_draws() {
        use crate::cryptanalysis::koblitz_groebner::solving_degree;
        use crate::cryptanalysis::koblitz_index_calculus::find_irreducible_sparse;
        let mut checked = 0;
        for (m, n, ell, seed) in [(3usize, 5u32, 2usize, 11u64), (3, 7, 2, 12), (4, 4, 1, 13)] {
            let irr = find_irreducible_sparse(n).unwrap();
            let st = FieldStructure::new(n, &irr);
            let b = F2mElement::one(n);
            let mut rng = StdRng::seed_from_u64(seed);
            let mut taken = 0;
            while taken < 2 {
                let (basis, x_r) = ladder_sample(n, ell, &mut rng);
                if chained_solution_count(m, &basis, &x_r, &b, &irr) > 0 {
                    continue;
                }
                let sys = build_decomposition_system(&basis, &x_r, &b, m, &st).unwrap();
                let scan = closure_refutation_scan(&sys.equations, sys.n_vars, 3, 7);
                let xl = scan.iter().find(|d| d.xl_refuted).map(|d| d.degree);
                let cl = scan.iter().find(|d| d.closure_refuted).map(|d| d.degree);
                assert!(scan.iter().all(|d| d.saturated));
                assert!(
                    cl.is_some() && cl <= xl.or(Some(u32::MAX)),
                    "m={m} n={n}: {cl:?} {xl:?}"
                );
                assert_eq!(
                    xl,
                    solving_degree(&sys.equations, sys.n_vars, 7).0,
                    "m={m} n={n}"
                );
                taken += 1;
                checked += 1;
            }
        }
        assert_eq!(checked, 6);
    }

    #[test]
    fn random_subspace_basis_is_independent_and_of_the_asked_dimension() {
        let mut rng = StdRng::seed_from_u64(7);
        for (n, ell) in [(5u32, 1usize), (7, 3), (13, 5), (19, 7), (31, 12)] {
            let basis = random_subspace_basis(n, ell, &mut rng);
            let words: Vec<u64> = basis
                .iter()
                .map(|e| e.raw_bits().first().copied().unwrap_or(0))
                .collect();
            let span: std::collections::HashSet<u64> = (0..1u64 << ell)
                .map(|c| {
                    (0..ell)
                        .filter(|t| (c >> t) & 1 == 1)
                        .fold(0, |acc, t| acc ^ words[t])
                })
                .collect();
            assert_eq!(span.len(), 1usize << ell, "n={n} ℓ={ell}");
            assert!(words.iter().all(|&w| w < 1u64 << n));
        }
    }

    /// Replaying the samples and measuring one of them is the draw
    /// `ladder_draw` would have made at that position -- same subspace, same
    /// target, same outcome -- so a cell measured one draw per process is the
    /// cell measured in one process.
    #[test]
    fn replayed_samples_measure_as_the_sequential_draws() {
        let seq: Vec<LadderDraw> = {
            let mut rng = StdRng::seed_from_u64(0x1ADD_E7);
            (0..10)
                .map(|_| ladder_draw(5, 2, 7, 4, &mut rng).unwrap())
                .collect()
        };
        let mut rng = StdRng::seed_from_u64(0x1ADD_E7);
        for want in &seq {
            let (basis, x_r) = ladder_sample(5, 2, &mut rng);
            let got = ladder_measure(5, &basis, &x_r, 7, 4).unwrap();
            assert_eq!(
                (
                    got.v_basis.clone(),
                    got.x_r,
                    got.solutions,
                    got.outcome,
                    got.ffd
                ),
                (
                    want.v_basis.clone(),
                    want.x_r,
                    want.solutions,
                    want.outcome,
                    want.ffd
                )
            );
        }
    }

    /// The profiler runs the eliminator's own algorithm: same rank, same
    /// vanished rows, same number of linear rows, same fill-in.
    #[test]
    fn ladder_refutation_profile_matches_the_eliminator() {
        use crate::cryptanalysis::koblitz_groebner::build_macaulay_sparse;
        use crate::cryptanalysis::koblitz_index_calculus::find_irreducible_sparse;
        use crate::cryptanalysis::sparse_macaulay::{eliminate_high_columns, low_column_start};

        let mut rng = StdRng::seed_from_u64(0x9F0F_11E);
        for (n, ell, degree) in [(5u32, 2usize, 5u32), (7, 2, 5), (7, 3, 5)] {
            let (basis, x_r) = ladder_sample(n, ell, &mut rng);
            let word = |e: &F2mElement| e.raw_bits().first().copied().unwrap_or(0);
            let words: Vec<u64> = basis.iter().map(word).collect();
            let p = ladder_refutation_profile(n, &words, word(&x_r), degree).unwrap();

            let irr = find_irreducible_sparse(n).unwrap();
            let st = FieldStructure::new(n, &irr);
            let sys =
                build_decomposition_system(&basis, &x_r, &F2mElement::one(n), 3, &st).unwrap();
            let (cols, rows) = build_macaulay_sparse(&sys.equations, sys.n_vars, degree).unwrap();
            let e = eliminate_high_columns(rows, cols.len(), low_column_start(&cols));
            assert_eq!(
                (p.high_rank, p.vanished, p.linear_rows, p.max_weight),
                (e.high_rank, e.vanished, e.linear_rows.len(), e.max_weight),
                "(n, ell, degree) = ({n}, {ell}, {degree})"
            );
        }
    }

    /// The dense finish keeps the row space: on ladder draws of four cells,
    /// at every degree from the system's own up, and with the switch point
    /// anywhere from the first column to the linear boundary, it finds the
    /// same high rank and linear rows spanning the same space as the
    /// sparse-only eliminator.
    #[test]
    fn dense_finish_keeps_the_high_rank_and_the_linear_span() {
        use crate::cryptanalysis::koblitz_groebner::{
            build_macaulay_sparse, rref_f2, system_degree,
        };
        use crate::cryptanalysis::koblitz_index_calculus::find_irreducible_sparse;
        use crate::cryptanalysis::sparse_macaulay::{
            eliminate_high_columns, eliminate_high_columns_dense_finish, leading_band_end,
            low_column_start,
        };

        // The reduced echelon form of a set of rows over `cols[low..]`: a
        // canonical name for the space they span.
        let span = |rows: &[Vec<u32>], low: usize, n_cols: usize| -> Vec<Vec<u64>> {
            let width = n_cols - low;
            let mut m: Vec<Vec<u64>> = rows
                .iter()
                .map(|r| {
                    let mut bits = vec![0u64; width.div_ceil(64).max(1)];
                    for &c in r {
                        let k = c as usize - low;
                        bits[k / 64] |= 1 << (k % 64);
                    }
                    bits
                })
                .collect();
            let rank = if m.is_empty() {
                0
            } else {
                rref_f2(&mut m, width)
            };
            m.truncate(rank);
            m
        };

        let mut rng = StdRng::seed_from_u64(0xDE_45E);
        let mut compared = 0;
        for (n, ell, d_top) in [(5u32, 2usize, 6u32), (7, 2, 5), (7, 3, 5), (4, 3, 6)] {
            for _ in 0..3 {
                let (basis, x_r) = ladder_sample(n, ell, &mut rng);
                let irr = find_irreducible_sparse(n).unwrap();
                let st = FieldStructure::new(n, &irr);
                let sys =
                    build_decomposition_system(&basis, &x_r, &F2mElement::one(n), 3, &st).unwrap();
                for degree in system_degree(&sys.equations)..=d_top {
                    let Some((cols, rows)) =
                        build_macaulay_sparse(&sys.equations, sys.n_vars, degree)
                    else {
                        continue;
                    };
                    let low = low_column_start(&cols);
                    let want = eliminate_high_columns(rows.clone(), cols.len(), low);
                    for until in [0, leading_band_end(&cols), low / 2, low] {
                        let got = eliminate_high_columns_dense_finish(
                            rows.clone(),
                            cols.len(),
                            low,
                            until,
                        );
                        assert_eq!(
                            got.high_rank, want.high_rank,
                            "({n}, {ell}) degree {degree}"
                        );
                        assert_eq!(
                            span(&got.linear_rows, low, cols.len()),
                            span(&want.linear_rows, low, cols.len()),
                            "({n}, {ell}) degree {degree} switch at {until}"
                        );
                        assert_eq!(
                            got.high_rank + got.vanished + got.linear_rows.len(),
                            rows.len()
                        );
                        compared += 1;
                    }
                }
            }
        }
        assert!(compared >= 100, "only {compared} comparisons ran");
    }

    /// The budgeted dense finish is the sparse path with a different switch
    /// point: at every budget from nothing to unlimited it finds the same
    /// high rank and the same linear span, and it switches after the leading
    /// band when the budget is unlimited, and not before the linear boundary
    /// when the budget is zero.
    #[test]
    fn budgeted_dense_finish_matches_the_sparse_path() {
        use crate::cryptanalysis::koblitz_groebner::{
            build_macaulay_sparse, rref_f2, system_degree,
        };
        use crate::cryptanalysis::koblitz_index_calculus::find_irreducible_sparse;
        use crate::cryptanalysis::sparse_macaulay::{
            band_ends, eliminate_high_columns, eliminate_high_columns_dense_finish_budgeted,
            leading_band_end, low_column_start,
        };

        let span = |rows: &[Vec<u32>], low: usize, n_cols: usize| -> Vec<Vec<u64>> {
            let width = n_cols - low;
            let mut m: Vec<Vec<u64>> = rows
                .iter()
                .map(|r| {
                    let mut bits = vec![0u64; width.div_ceil(64).max(1)];
                    for &c in r {
                        let k = c as usize - low;
                        bits[k / 64] |= 1 << (k % 64);
                    }
                    bits
                })
                .collect();
            let rank = if m.is_empty() {
                0
            } else {
                rref_f2(&mut m, width)
            };
            m.truncate(rank);
            m
        };

        let mut rng = StdRng::seed_from_u64(0xB0D6_E7);
        let mut compared = 0;
        for (n, ell, d_top) in [(5u32, 2usize, 6u32), (7, 3, 5), (4, 3, 6)] {
            for _ in 0..3 {
                let (basis, x_r) = ladder_sample(n, ell, &mut rng);
                let irr = find_irreducible_sparse(n).unwrap();
                let st = FieldStructure::new(n, &irr);
                let sys =
                    build_decomposition_system(&basis, &x_r, &F2mElement::one(n), 3, &st).unwrap();
                for degree in system_degree(&sys.equations)..=d_top {
                    let Some((cols, rows)) =
                        build_macaulay_sparse(&sys.equations, sys.n_vars, degree)
                    else {
                        continue;
                    };
                    let low = low_column_start(&cols);
                    let ends = band_ends(&cols);
                    let want = eliminate_high_columns(rows.clone(), cols.len(), low);
                    for budget in [0u64, 1 << 10, 1 << 16, u64::MAX] {
                        let got = eliminate_high_columns_dense_finish_budgeted(
                            rows.clone(),
                            cols.len(),
                            low,
                            &ends,
                            budget,
                        );
                        assert_eq!(got.high_rank, want.high_rank, "({n}, {ell}) d {degree}");
                        assert_eq!(
                            span(&got.linear_rows, low, cols.len()),
                            span(&want.linear_rows, low, cols.len()),
                            "({n}, {ell}) degree {degree} budget {budget}"
                        );
                        assert_eq!(
                            got.high_rank + got.vanished + got.linear_rows.len(),
                            rows.len()
                        );
                        let from = got.dense_from.expect("the dense finish records its switch");
                        assert!(from == low || ends.contains(&from));
                        if budget == u64::MAX && low > 0 {
                            assert_eq!(from, leading_band_end(&cols).min(low));
                        }
                        if budget == 0 {
                            assert!(from == low || want.linear_rows.is_empty() || from >= ends[0]);
                        }
                        compared += 1;
                    }
                }
            }
        }
        assert!(compared >= 60, "only {compared} comparisons ran");
    }

    /// The F5-pruned sparse Macaulay matrix has the full one's columns,
    /// high rank and linear span, with fewer rows: dropping rows the
    /// criterion proves redundant never changes a refutation.
    #[test]
    fn f5_rows_keep_the_sparse_refutation() {
        use crate::cryptanalysis::koblitz_groebner::{
            build_macaulay_sparse, build_macaulay_sparse_f5, rref_f2, system_degree,
        };
        use crate::cryptanalysis::koblitz_index_calculus::find_irreducible_sparse;
        use crate::cryptanalysis::sparse_macaulay::{eliminate_high_columns, low_column_start};

        let span = |rows: &[Vec<u32>], low: usize, n_cols: usize| -> Vec<Vec<u64>> {
            let width = n_cols - low;
            let mut m: Vec<Vec<u64>> = rows
                .iter()
                .map(|r| {
                    let mut bits = vec![0u64; width.div_ceil(64).max(1)];
                    for &c in r {
                        let k = c as usize - low;
                        bits[k / 64] |= 1 << (k % 64);
                    }
                    bits
                })
                .collect();
            let rank = if m.is_empty() {
                0
            } else {
                rref_f2(&mut m, width)
            };
            m.truncate(rank);
            m
        };

        let mut rng = StdRng::seed_from_u64(0xF5_0B0E);
        let (mut compared, mut pruned) = (0, 0usize);
        for (n, ell, d_top) in [(5u32, 2usize, 6u32), (7, 3, 6), (4, 3, 6), (8, 4, 5)] {
            for _ in 0..3 {
                let (basis, x_r) = ladder_sample(n, ell, &mut rng);
                let irr = find_irreducible_sparse(n).unwrap();
                let st = FieldStructure::new(n, &irr);
                let sys =
                    build_decomposition_system(&basis, &x_r, &F2mElement::one(n), 3, &st).unwrap();
                for degree in system_degree(&sys.equations)..=d_top {
                    let (Some((cols, rows)), Some((f5_cols, f5_rows))) = (
                        build_macaulay_sparse(&sys.equations, sys.n_vars, degree),
                        build_macaulay_sparse_f5(&sys.equations, sys.n_vars, degree),
                    ) else {
                        continue;
                    };
                    assert_eq!(f5_cols, cols, "({n}, {ell}) degree {degree}");
                    assert!(f5_rows.len() <= rows.len());
                    pruned += rows.len() - f5_rows.len();
                    let low = low_column_start(&cols);
                    let want = eliminate_high_columns(rows, cols.len(), low);
                    let got = eliminate_high_columns(f5_rows, cols.len(), low);
                    assert_eq!(
                        got.high_rank, want.high_rank,
                        "({n}, {ell}) degree {degree}"
                    );
                    assert_eq!(
                        span(&got.linear_rows, low, cols.len()),
                        span(&want.linear_rows, low, cols.len()),
                        "({n}, {ell}) degree {degree}"
                    );
                    compared += 1;
                }
            }
        }
        assert!(compared >= 30, "only {compared} comparisons ran");
        assert!(pruned > 0, "the criterion pruned nothing");
    }

    /// `ladder_measure_from` gives the same outcome as `ladder_measure` when
    /// the degrees it skips do not resolve, and it builds none of them.
    #[test]
    fn measuring_from_a_higher_degree_skips_only_non_resolving_degrees() {
        // (7, 2) has surplus +1, so most draws are refuted, at degree 5.
        let mut rng = StdRng::seed_from_u64(0xD_A1A);
        let mut checked = 0;
        for _ in 0..40 {
            let (basis, x_r) = ladder_sample(7, 2, &mut rng);
            let full = ladder_measure(7, &basis, &x_r, 6, 4).unwrap();
            let LadderOutcome::Resolved { degree, .. } = full.outcome else {
                continue;
            };
            let from = ladder_measure_from(7, &basis, &x_r, degree, 6, 4).unwrap();
            assert_eq!(from.outcome, full.outcome);
            assert_eq!(from.ffd, full.ffd);
            checked += 1;
        }
        assert!(checked >= 6, "only {checked} draws resolved");
    }

    /// A draw with solutions is never sent to the Macaulay path, and a
    /// small unsatisfiable draw resolves by refutation within a generous
    /// `d_max` -- the three outcomes the sweep distinguishes are reachable.
    #[test]
    fn ladder_draw_separates_satisfiable_from_refuted() {
        let mut rng = StdRng::seed_from_u64(0x1ADD_E6);
        let (mut sat, mut refuted) = (0, 0);
        for _ in 0..24 {
            let d = ladder_draw(5, 2, 8, 4, &mut rng).unwrap();
            match d.outcome {
                LadderOutcome::Satisfiable => {
                    assert!(d.solutions > 0);
                    sat += 1
                }
                LadderOutcome::Resolved { refuted: true, .. } => {
                    assert_eq!(d.solutions, 0);
                    refuted += 1
                }
                other => assert_eq!(d.solutions, 0, "{other:?}"),
            }
        }
        assert!(
            sat > 0 && refuted > 0,
            "{sat} satisfiable, {refuted} refuted"
        );
    }

    #[test]
    #[should_panic(expected = "random controls require 1..=64 Boolean variables")]
    fn control_input_rejects_zero_variables() {
        random_control_system(0, 1, 1, 1, 7);
    }

    #[test]
    #[should_panic(expected = "random controls require 1..=64 Boolean variables")]
    fn control_input_rejects_mask_overflow() {
        random_control_system(65, 1, 1, 1, 7);
    }

    #[test]
    #[should_panic(expected = "random control degree cannot exceed the variable count")]
    fn control_input_rejects_unreachable_degree() {
        random_control_system(1, 1, 2, 1, 7);
    }

    #[test]
    #[should_panic(expected = "random control degree cannot exceed the variable count")]
    fn control_input_rejects_extreme_degree_before_sampling() {
        random_control_system(2, 1, u32::MAX, 1, 7);
    }

    #[test]
    fn control_input_preserves_supported_boundaries() {
        for n_vars in [1, 64] {
            let zero = random_control_system(n_vars, 3, 0, 1, 7);
            let one = random_control_system(n_vars, 3, 1, 1, 7);
            let masks = |polys: &[F2BoolPoly]| {
                polys
                    .iter()
                    .map(|p| p.terms.iter().map(|t| t.mask).collect::<Vec<_>>())
                    .collect::<Vec<_>>()
            };
            assert_eq!(masks(&zero), masks(&one));
            assert!(one
                .iter()
                .all(|p| p.terms.len() == 1 && p.terms[0].mask.count_ones() == 1));
        }
        assert!(random_control_system(2, 0, 2, 1, 7).is_empty());
    }

    #[test]
    fn cost_model_matches_the_built_system() {
        // n_vars_for is the number the target drives down, so it had
        // better be the number the builder actually produces.
        for n in [7u32, 9, 15, 21] {
            let (_, basis) = invariant_subspace_basis(n, 0).unwrap();
            for m in [2usize, 3] {
                if let Some(p) = profile_system(n, 0, m, 2, 7) {
                    assert_eq!(
                        p.n_vars,
                        n_vars_for(n, basis.len() as u32, m),
                        "n = {n}, m = {m}"
                    );
                }
            }
        }
    }

    #[test]
    fn profiles_are_deterministic_and_structural() {
        let a = profile_system(9, 0, 2, 3, 42).unwrap();
        let b = profile_system(9, 0, 2, 3, 42).unwrap();
        assert_eq!(a.n_vars, b.n_vars);
        assert_eq!(a.fall_degree, b.fall_degree);
        assert_eq!(
            a.macaulay.iter().map(|p| p.rank).collect::<Vec<_>>(),
            b.macaulay.iter().map(|p| p.rank).collect::<Vec<_>>()
        );
        // K_a / F_2^9: ℓ = 6, so 12 unknowns, 9 equations, quadratic.
        assert_eq!((a.ell, a.n_vars, a.n_eqs, a.degree), (6, 12, 9, 2));
    }

    #[test]
    fn chaining_makes_the_system_cubic_and_much_larger() {
        let two = profile_system(9, 0, 2, 2, 1).unwrap();
        let three = profile_system(9, 0, 3, 2, 1).unwrap();
        assert_eq!(two.degree, 2);
        assert_eq!(three.degree, 3);
        // One intermediate point costs a full n unknowns.
        assert_eq!(three.n_vars - two.n_vars, 6 + 9);
    }

    #[test]
    fn the_budget_is_what_stops_the_sweep() {
        // n = 63, ℓ = 6: m = 2 fits, m = 3 needs 81 > 64 unknowns.
        assert_eq!(n_vars_for(63, 6, 2), 12);
        assert_eq!(n_vars_for(63, 6, 3), 81);
        assert_eq!(max_m_within_budget(63, 6, 64), Some(2));
        assert!(profile_system(63, 0, 3, 2, 1).is_none());
        assert!(profile_system(63, 0, 2, 2, 1).is_some());
    }

    #[test]
    fn the_ladder_is_the_n_with_small_subspaces() {
        let ladder = subspace_ladder(63, 6);
        assert!(ladder.contains(&(7, 3)));
        assert!(ladder.contains(&(15, 4)));
        assert!(ladder.contains(&(31, 5)));
        assert!(ladder.contains(&(63, 6)));
        // ord_11(2) = 10, too big for this cut.
        assert!(!ladder.iter().any(|(n, _)| *n == 11));
    }

    #[test]
    fn all_three_oracles_agree_on_a_benchmarked_instance() {
        let b = bench_instance(0, 9, 0, 2, 6, 0xB0B, 20_000, 64, Some(2)).unwrap();
        assert_eq!(b.disagreements, 0, "oracles disagreed: {b:?}");
        assert_eq!(b.runs.len(), 3);
        for r in &b.runs {
            assert_eq!(
                r.decomposed + r.refuted + r.inconclusive,
                b.targets,
                "{} lost a target",
                r.oracle
            );
        }
        // Every target of K_0/F_2^9 decomposes into 2 factor-base points.
        assert!(b.runs.iter().all(|r| r.decomposed == b.targets));
    }

    #[test]
    fn fall_degree_varies_with_the_target_draw() {
        // The reason the harness averages: one draw is not the system's
        // fall degree, it is one system's fall degree.
        let s = ffd_summary(9, 0, 2, 3, 0x5EED, 16).unwrap();
        assert_eq!(s.trials, 16);
        assert!(
            s.no_fall > 0 || s.fall_min != s.fall_max,
            "expected spread across draws, got {s:?}"
        );
        // …and the summary still describes the same system.
        assert_eq!((s.ell, s.n_vars, s.n_eqs, s.degree), (6, 12, 9, 2));
    }

    #[test]
    fn find_and_refute_costs_are_reported_separately() {
        // The two regimes differ by orders of magnitude, so the harness
        // must not average them into one number.  K_0/F_2^7 refutes
        // every target (its factor base is a single point); K_0/F_2^9
        // decomposes every target.
        let refuting = bench_instance(0, 7, 0, 2, 4, 1, 20_000, 64, Some(2)).unwrap();
        for r in &refuting.runs {
            assert_eq!(r.decomposed, 0);
            assert!(
                r.median_refuted_ms > 0.0,
                "{} has no refute median",
                r.oracle
            );
            assert!(
                r.median_found_ms.is_nan(),
                "{} invented a find median",
                r.oracle
            );
        }
        let finding = bench_instance(0, 9, 0, 2, 4, 1, 20_000, 64, Some(2)).unwrap();
        for r in &finding.runs {
            assert_eq!(r.refuted, 0);
            assert!(r.median_found_ms > 0.0, "{} has no find median", r.oracle);
            assert!(
                r.median_refuted_ms.is_nan(),
                "{} invented a refute median",
                r.oracle
            );
        }
    }

    #[test]
    fn eq_var_ratio_flags_the_underdetermined_systems() {
        // n = 9, m = 3 is the worst measured refutation instance and is
        // the underdetermined one: 18 equations in 27 unknowns.
        let hard = profile_system(9, 0, 3, 2, 1).unwrap();
        assert!(hard.eq_var_ratio() < 1.0, "{}", hard.eq_var_ratio());
        // n = 15, m = 3 has the same variable count but more equations,
        // and refutes ~400x faster.
        let easier = profile_system(15, 0, 3, 2, 1).unwrap();
        assert_eq!(hard.n_vars, easier.n_vars);
        assert!(easier.eq_var_ratio() > 1.0, "{}", easier.eq_var_ratio());
    }

    #[test]
    fn json_round_trips_as_valid_json() {
        let profiles = vec![profile_system(9, 0, 2, 3, 1).unwrap()];
        let benches = vec![bench_instance(0, 9, 0, 2, 2, 1, 20_000, 64, Some(2)).unwrap()];
        let text = to_json(&profiles, &benches);
        let parsed: serde_json::Value = serde_json::from_str(&text).unwrap();
        assert_eq!(parsed["systems"][0]["n_vars"], 12);
        assert_eq!(parsed["oracles"][0]["disagreements"], 0);
    }

    /// The control arms are tracked and reported **separately**.
    ///
    /// Two failures this pins, both found by review on #395 and both
    /// the same class as the ones the module already guards against:
    /// a `control_max_degree_built` that was computed and stored but
    /// never printed, so the sweep still could not tell a control that
    /// exhausted `d_max` from one that hit the size caps; and a single
    /// shared `max()` across both arms, which can report a degree the
    /// extra-equation arm never built, because that arm carries
    /// `n_vars + 4` equations and so reaches the row cap at a lower
    /// degree.  The extra-equation arm is the one whose non-resolution
    /// carries the attribution, so a field that averages it away is
    /// worse than no field at all.
    #[test]
    fn control_arms_are_reported_separately() {
        // n = 7, m = 2 is six unknowns: cheap enough for a unit test.
        let r = dreg_summary(7, 0, 2, 4, 2, 0x5EED, true).expect("cell builds");

        assert!(
            r.control_shape_max_degree_built.is_some(),
            "the shape-matched arm must record the degree it reached"
        );
        assert!(
            r.control_unsat_max_degree_built.is_some(),
            "so must the extra-equation arm, independently"
        );
        assert!(
            r.control_expected_solutions > 0.0,
            "the legacy density heuristic is retained for API compatibility"
        );

        let table = format_dreg_table(std::slice::from_ref(&r));
        for col in [
            "D_rank_proxy",
            "D_pin(shape)",
            "D_pin(extra)",
            "Dc(shape)",
            "Dc(extra)",
        ] {
            assert!(
                table.contains(col),
                "a field that is stored but never printed cannot do its job; \
                 missing {col} in:\n{table}"
            );
        }
    }

    #[test]
    fn degree_reporting_controls_always_have_zero_root() {
        for n_vars in [2, 4, 6] {
            for n_eqs in [n_vars / 2, n_vars + 4] {
                for seed in 0..16 {
                    let polys = random_control_system(n_vars, n_eqs, 2, 5, seed);
                    assert!(polys.iter().all(|p| p.terms.iter().all(|t| t.mask != 0)));
                    let (degree, profiles) = solving_degree(&polys, n_vars, 2);
                    assert!(profiles.iter().all(|p| !p.refuted));
                    if degree.is_some() {
                        let last = profiles.last().unwrap();
                        assert_eq!(last.vars_determined, last.vars_occurring);
                    }
                }
            }
        }
    }

    #[test]
    fn degree_reporting_does_not_infer_sat_from_density() {
        let mut row = dreg_summary(7, 0, 2, 2, 1, 7, false).unwrap();
        row.control_solve_mean = None;
        row.control_unsat_mean = None;
        row.control_unresolved = 1;
        row.control_unsat_unresolved = 1;
        row.control_expected_solutions = 1024.0;
        let table = format_dreg_table(&[row]);
        assert!(table.contains("D_rank_proxy"));
        assert!(table.contains("D_pin(extra)"));
        assert!(table.contains("unres"));
        assert!(!table.contains("n/a(sat)"));
        assert!(!table.contains("FFD"));
        assert!(!table.contains("ctrl(unsat)"));
    }
}
