//! Exact, full-width elimination of one- and two-large-prime relations.
//!
//! A candidate first proves its point equation in the prime-order subgroup.
//! Each residual point is then represented by its signed Frobenius orbit and
//! an exact coefficient modulo the subgroup order. Pivot reduction preserves
//! the coefficients of the original public target and generator. A completed
//! row is checked again as a group equation before it can enter linear
//! algebra. Bounded chained-S3 discovery uses disjoint, exact Frobenius
//! domains and checks every accepted point equation in the curve group.

use std::borrow::Cow;
use std::collections::{BTreeMap, BTreeSet, HashMap};

use num_bigint::BigUint;
use num_traits::{One, Zero};

use crate::binary_ecc::curve::point_neg;
use crate::binary_ecc::{BinaryPoint, F2mElement};
use crate::cryptanalysis::binary_semaev_chain_sat::{
    frobenius_orbit_domain_size, ChainBuildError, ChainedS3Encoding,
};
use crate::cryptanalysis::ec_index_calculus::gaussian_eliminate_mod_n_particular;
use crate::cryptanalysis::koblitz_index_calculus::{
    build_explicit_frobenius_point_factor_base, point_key, points_with_x, ChainS3Limits,
    ChainS3Stats, FrobeniusFactorBase, KoblitzCurve,
};
use crate::cryptanalysis::sat::SolveResult;
use crate::utils::mod_inverse;

type PointKey = (BigUint, BigUint);

/// A public, independently checkable partial point equation:
/// [a]G + [b]Q = sum(small points) + sum(residual points).
#[derive(Clone, Debug)]
pub struct PartialCandidate {
    pub source_id: u64,
    pub coef_a: BigUint,
    pub coef_b: BigUint,
    pub small_point_indices: Vec<usize>,
    pub residual_points: Vec<BinaryPoint>,
}

/// Two disjoint exact x-domains for small points and residual points.
/// Construction is performed once per pair of bases, outside timed queries.
pub struct MixedOrbitDomains<'a> {
    curve: &'a KoblitzCurve,
    small: &'a FrobeniusFactorBase,
    small_reps: Vec<BigUint>,
    residual_reps: Vec<BigUint>,
    small_xs: BTreeSet<BigUint>,
    residual_xs: BTreeSet<BigUint>,
    small_index: HashMap<PointKey, usize>,
    residual_index: HashMap<PointKey, usize>,
}

/// Materialise the residual signed-orbit suffix of two replayed, ordered bases.
///
/// The smaller point record and both of its orbit maps must be exact prefixes
/// of the envelope. Rebuilding the suffix independently checks its closure and
/// labels before it can be used as the second domain of `MixedOrbitDomains`.
/// This does not infer partial-relation yield from the sizes of the two bases.
pub fn build_exact_residual_suffix_factor_base(
    curve: &KoblitzCurve,
    small: &FrobeniusFactorBase,
    envelope: &FrobeniusFactorBase,
) -> Result<FrobeniusFactorBase, &'static str> {
    let prefix_points = small.points.len();
    let prefix_orbits = small.orbits.len();
    let prefix_signed = small.signed_orbits.len();
    if prefix_points == 0
        || envelope.points.len() <= prefix_points
        || envelope.orbits.len() <= prefix_orbits
        || envelope.signed_orbits.len() <= prefix_signed
        || small.orbit_of.len() != prefix_points
        || small.signed_orbit_of.len() != prefix_points
        || envelope.orbit_of.len() != envelope.points.len()
        || envelope.signed_orbit_of.len() != envelope.points.len()
        || envelope.points.get(..prefix_points) != Some(small.points.as_slice())
        || envelope.orbits.get(..prefix_orbits) != Some(small.orbits.as_slice())
        || envelope.signed_orbits.get(..prefix_signed) != Some(small.signed_orbits.as_slice())
        || envelope.orbit_of.get(..prefix_points) != Some(small.orbit_of.as_slice())
        || envelope.signed_orbit_of.get(..prefix_points) != Some(small.signed_orbit_of.as_slice())
    {
        return Err("smaller factor base is not an exact orbit-labelled prefix");
    }
    let residual = build_explicit_frobenius_point_factor_base(
        curve,
        envelope.points[prefix_points..].to_vec(),
    )
    .ok_or("residual suffix is not a complete signed-Frobenius base")?;
    if residual.orbits.len() + prefix_orbits != envelope.orbits.len()
        || residual.signed_orbits.len() + prefix_signed != envelope.signed_orbits.len()
        || residual
            .orbits
            .iter()
            .zip(&envelope.orbits[prefix_orbits..])
            .any(|(local, full)| {
                local.len() != full.len()
                    || local
                        .iter()
                        .zip(full)
                        .any(|(&index, &full_index)| index + prefix_points != full_index)
            })
        || residual
            .signed_orbits
            .iter()
            .zip(&envelope.signed_orbits[prefix_signed..])
            .any(|(local, full)| {
                local.len() != full.len()
                    || local
                        .iter()
                        .zip(full)
                        .any(|(&index, &full_index)| index + prefix_points != full_index)
            })
        || residual
            .orbit_of
            .iter()
            .zip(&envelope.orbit_of[prefix_points..])
            .any(|(&(orbit, phase), &(full_orbit, full_phase))| {
                orbit + prefix_orbits != full_orbit || phase != full_phase
            })
        || residual
            .signed_orbit_of
            .iter()
            .zip(&envelope.signed_orbit_of[prefix_points..])
            .any(
                |(&(orbit, phase, negated), &(full_orbit, full_phase, full_negated))| {
                    orbit + prefix_signed != full_orbit
                        || phase != full_phase
                        || negated != full_negated
                },
            )
    {
        return Err("residual suffix orbit labels differ from the envelope");
    }
    MixedOrbitDomains::new(curve, small, &residual)?;
    Ok(residual)
}

/// Materialise `pool \ small` at complete signed-Frobenius-orbit granularity.
///
/// The inputs may come from different public-x policies or seeds and need not
/// be nested. Reconstructing their orbit maps first prevents a corrupted map
/// from changing the set difference. A shared orbit is removed in full; a
/// partial overlap, damaged phase/sign label, or remaining x-domain overlap
/// fails closed. This is an import/adapter step, not a relation measurement.
pub fn build_exact_residual_difference_factor_base(
    curve: &KoblitzCurve,
    small: &FrobeniusFactorBase,
    pool: &FrobeniusFactorBase,
) -> Result<FrobeniusFactorBase, &'static str> {
    for base in [small, pool] {
        let replayed = build_explicit_frobenius_point_factor_base(curve, base.points.clone())
            .ok_or("cross-stream input is not a complete Frobenius base")?;
        if replayed.orbits != base.orbits
            || replayed.orbit_of != base.orbit_of
            || replayed.signed_orbits != base.signed_orbits
            || replayed.signed_orbit_of != base.signed_orbit_of
        {
            return Err("cross-stream input orbit map differs from point record");
        }
        MixedOrbitDomains::checked_domain(curve, base)?;
    }
    let small_index = small.index_map();
    let mut retained_points = Vec::new();
    let mut retained_orbits = Vec::new();
    for (orbit_index, orbit) in pool.signed_orbits.iter().enumerate() {
        let shared = orbit
            .iter()
            .filter(|&&index| small_index.contains_key(&point_key(&pool.points[index])))
            .count();
        if shared == orbit.len() {
            continue;
        }
        if shared != 0 {
            return Err("cross-stream pool has partial signed-orbit overlap");
        }
        retained_orbits.push(orbit_index);
        retained_points.extend(orbit.iter().map(|&index| pool.points[index].clone()));
    }
    let residual = build_explicit_frobenius_point_factor_base(curve, retained_points)
        .ok_or("cross-stream residual is not a complete signed-Frobenius base")?;
    if residual.signed_orbits.len() != retained_orbits.len() {
        return Err("cross-stream residual orbit count differs");
    }
    for (local_orbit, &pool_orbit) in retained_orbits.iter().enumerate() {
        let local = &residual.signed_orbits[local_orbit];
        let original = &pool.signed_orbits[pool_orbit];
        if local.len() != original.len()
            || local
                .iter()
                .zip(original)
                .any(|(&local_index, &pool_index)| {
                    residual.points[local_index] != pool.points[pool_index]
                        || residual.signed_orbit_of[local_index].0 != local_orbit
                        || residual.signed_orbit_of[local_index].1
                            != pool.signed_orbit_of[pool_index].1
                        || residual.signed_orbit_of[local_index].2
                            != pool.signed_orbit_of[pool_index].2
                })
        {
            return Err("cross-stream residual orbit labels differ from pool");
        }
    }
    MixedOrbitDomains::new(curve, small, &residual)?;
    Ok(residual)
}

impl<'a> MixedOrbitDomains<'a> {
    fn checked_domain(
        curve: &KoblitzCurve,
        base: &FrobeniusFactorBase,
    ) -> Result<(Vec<BigUint>, BTreeSet<BigUint>, HashMap<PointKey, usize>), &'static str> {
        if !base.uses_ambient_basis()
            || base.ell != curve.n
            || base.subspace_basis.len() != curve.n as usize
            || base.subspace_basis.iter().enumerate().any(|(bit, basis)| {
                *basis != F2mElement::from_bit_positions(&[bit as u32], curve.n)
            })
            || base.signed_orbit_of.len() != base.points.len()
        {
            return Err("mixed orbit search requires an ambient signed-orbit base");
        }
        let xs: BTreeSet<BigUint> = base
            .points
            .iter()
            .filter_map(|point| match point {
                BinaryPoint::Affine { x, .. } => Some(x.to_biguint()),
                BinaryPoint::Infinity => None,
            })
            .collect();
        let mut reps = Vec::with_capacity(base.signed_orbits.len());
        let mut closure = BTreeSet::new();
        for orbit in &base.signed_orbits {
            let Some(BinaryPoint::Affine { x, .. }) =
                orbit.first().and_then(|&index| base.points.get(index))
            else {
                return Err("invalid signed-orbit representative");
            };
            reps.push(x.to_biguint());
            let mut phase_x = x.clone();
            for _ in 0..curve.n {
                closure.insert(phase_x.to_biguint());
                phase_x = phase_x.square_k_times(1, &curve.curve.irreducible);
            }
        }
        reps.sort_unstable();
        reps.dedup();
        if reps.len() < 2 || reps.len() != base.signed_orbits.len() || closure != xs {
            return Err("signed-orbit representatives do not describe the exact x-domain");
        }
        let index = base.index_map();
        if index.len() != base.points.len() {
            return Err("duplicate point in mixed orbit base");
        }
        Ok((reps, xs, index))
    }

    pub fn new(
        curve: &'a KoblitzCurve,
        small: &'a FrobeniusFactorBase,
        residual: &'a FrobeniusFactorBase,
    ) -> Result<Self, &'static str> {
        if curve.k != 1
            || !curve.frobenius_is_endomorphism
            || curve
                .lambda
                .modpow(&BigUint::from(curve.n), &curve.subgroup_order)
                != BigUint::one()
        {
            return Err("mixed orbit search requires Koblitz subgroup Frobenius");
        }
        let (small_reps, small_xs, small_index) = Self::checked_domain(curve, small)?;
        let (residual_reps, residual_xs, residual_index) = Self::checked_domain(curve, residual)?;
        if !small_xs.is_disjoint(&residual_xs) {
            return Err("small and residual x-domains overlap");
        }
        Ok(Self {
            curve,
            small,
            small_reps,
            residual_reps,
            small_xs,
            residual_xs,
            small_index,
            residual_index,
        })
    }

    fn lift(
        &self,
        xs: &[F2mElement],
        small_summands: usize,
        target: &BinaryPoint,
    ) -> Option<(Vec<usize>, Vec<BinaryPoint>)> {
        fn walk(
            domains: &MixedOrbitDomains<'_>,
            xs: &[F2mElement],
            small_summands: usize,
            depth: usize,
            sum: &BinaryPoint,
            small: &mut Vec<usize>,
            residual: &mut Vec<BinaryPoint>,
            target: &BinaryPoint,
        ) -> bool {
            if depth == xs.len() {
                return sum == target
                    && small.iter().all(|&index| {
                        domains.small.points.get(index).is_some_and(|point| {
                            domains.curve.mul(point, &domains.curve.subgroup_order)
                                == BinaryPoint::Infinity
                        })
                    })
                    && residual.iter().all(|point| {
                        domains.curve.mul(point, &domains.curve.subgroup_order)
                            == BinaryPoint::Infinity
                    });
            }
            let index = if depth < small_summands {
                &domains.small_index
            } else {
                &domains.residual_index
            };
            for point in points_with_x(&domains.curve.curve, &xs[depth]) {
                let Some(&point_index) = index.get(&point_key(&point)) else {
                    continue;
                };
                let next = domains.curve.add(sum, &point);
                if depth < small_summands {
                    small.push(point_index);
                } else {
                    residual.push(point.clone());
                }
                if walk(
                    domains,
                    xs,
                    small_summands,
                    depth + 1,
                    &next,
                    small,
                    residual,
                    target,
                ) {
                    return true;
                }
                if depth < small_summands {
                    small.pop();
                } else {
                    residual.pop();
                }
            }
            false
        }
        let mut small = Vec::with_capacity(small_summands);
        let mut residual = Vec::with_capacity(xs.len() - small_summands);
        walk(
            self,
            xs,
            small_summands,
            0,
            &BinaryPoint::Infinity,
            &mut small,
            &mut residual,
            target,
        )
        .then_some((small, residual))
    }

    /// Search one public source equation with either one or two residual
    /// summands. `exhausted` means a cap or invalid model; `refuted` means
    /// every identity pattern completed UNSAT after exact group lifting.
    pub fn search(
        &self,
        source_id: u64,
        coef_a: &BigUint,
        coef_b: &BigUint,
        public_target: &BinaryPoint,
        small_summands: usize,
        residual_summands: usize,
        limits: ChainS3Limits,
        order_first_pair: bool,
    ) -> (Option<PartialCandidate>, ChainS3Stats) {
        let mut stats = ChainS3Stats::default();
        let Some(m) = small_summands.checked_add(residual_summands) else {
            stats.exhausted = true;
            return (None, stats);
        };
        if !(5..=6).contains(&m)
            || small_summands < 3
            || !(1..=2).contains(&residual_summands)
            || limits.max_models == 0
            || limits.conflict_budget == 0
            || !self.curve.curve.is_on_curve(public_target)
            || self.curve.mul(public_target, &self.curve.subgroup_order) != BinaryPoint::Infinity
        {
            stats.exhausted = true;
            return (None, stats);
        }
        let small_size =
            frobenius_orbit_domain_size(self.curve.n, small_summands, self.small_reps.len());
        let residual_size =
            frobenius_orbit_domain_size(self.curve.n, residual_summands, self.residual_reps.len());
        let Some(domain_clauses) = small_size
            .zip(residual_size)
            .and_then(|(small, residual)| small.clauses.checked_add(residual.clauses))
        else {
            stats.exhausted = true;
            return (None, stats);
        };
        if domain_clauses > limits.max_domain_clauses {
            stats.exhausted = true;
            return (None, stats);
        }
        stats.domain_clauses = domain_clauses;
        let modulus = &self.curve.subgroup_order;
        let a = coef_a % modulus;
        let b = coef_b % modulus;
        let target = self.curve.add(
            &self.curve.mul(self.curve.generator(), &a),
            &self.curve.mul(public_target, &b),
        );
        let target_x = match &target {
            BinaryPoint::Affine { x, .. } => Some(x),
            BinaryPoint::Infinity => None,
        };
        let domains: Vec<Vec<BigUint>> = (0..m)
            .map(|position| {
                if position < small_summands {
                    self.small_reps.clone()
                } else {
                    self.residual_reps.clone()
                }
            })
            .collect();
        for identity_mask in 0..(1u32 << (m - 2)) {
            if stats.conflicts >= limits.conflict_budget {
                stats.exhausted = true;
                return (None, stats);
            }
            let mut enc = match ChainedS3Encoding::build(
                m,
                &self.curve.curve.irreducible,
                &self.curve.curve.b,
                target_x,
                identity_mask,
                limits.max_variables,
            ) {
                Ok(enc) => enc,
                Err(
                    ChainBuildError::VariableCap { .. }
                    | ChainBuildError::DomainClauseCap { .. }
                    | ChainBuildError::Unsupported,
                ) => {
                    stats.exhausted = true;
                    return (None, stats);
                }
            };
            if enc
                .constrain_frobenius_orbit_domains(
                    &domains,
                    limits.max_variables,
                    limits.max_domain_clauses,
                )
                .map(|size| size.clauses)
                != Ok(domain_clauses)
                || (order_first_pair && enc.order_first_pair(limits.max_variables).is_err())
            {
                stats.exhausted = true;
                return (None, stats);
            }
            stats.patterns_attempted += 1;
            stats.peak_variables = stats.peak_variables.max(enc.solver.n_vars());
            stats.peak_clauses = stats.peak_clauses.max(enc.solver.n_clauses());
            stats.peak_xors = stats.peak_xors.max(enc.solver.n_xors());
            let earlier_conflicts = stats.conflicts;
            enc.solver.conflict_budget = limits.conflict_budget - earlier_conflicts;
            loop {
                stats.solver_calls += 1;
                let outcome = enc.solver.solve();
                stats.conflicts = earlier_conflicts.saturating_add(enc.solver.conflicts());
                match outcome {
                    SolveResult::Unsat => {
                        stats.patterns_refuted += 1;
                        break;
                    }
                    SolveResult::Unknown => {
                        stats.exhausted = true;
                        return (None, stats);
                    }
                    SolveResult::Sat => {
                        let xs = enc.decode_summands();
                        stats.models += 1;
                        if !enc.verify_model()
                            || xs.iter().enumerate().any(|(position, x)| {
                                let allowed = if position < small_summands {
                                    &self.small_xs
                                } else {
                                    &self.residual_xs
                                };
                                !allowed.contains(&x.to_biguint())
                            })
                        {
                            stats.invalid_models += 1;
                            stats.exhausted = true;
                            return (None, stats);
                        }
                        if let Some((small_point_indices, residual_points)) =
                            self.lift(&xs, small_summands, &target)
                        {
                            return (
                                Some(PartialCandidate {
                                    source_id,
                                    coef_a: a,
                                    coef_b: b,
                                    small_point_indices,
                                    residual_points,
                                }),
                                stats,
                            );
                        }
                        stats.group_rejected_models += 1;
                        if stats.models >= limits.max_models {
                            stats.exhausted = true;
                            return (None, stats);
                        }
                        let model = enc.solver.model();
                        enc.solver.reset_search();
                        let block: Vec<i32> = (0..m * self.curve.n as usize)
                            .map(|i| {
                                if model[i] {
                                    -((i + 1) as i32)
                                } else {
                                    (i + 1) as i32
                                }
                            })
                            .collect();
                        enc.solver.add_clause(block);
                    }
                }
            }
        }
        stats.refuted = true;
        (None, stats)
    }
}

/// Bounds on the graph rather than silent truncations of its algebra.
#[derive(Clone, Copy, Debug)]
pub struct LargePrimeLimits {
    pub max_merge_depth: usize,
    pub max_row_terms: usize,
    pub max_pivots: usize,
}

impl Default for LargePrimeLimits {
    fn default() -> Self {
        Self {
            max_merge_depth: 32,
            max_row_terms: 4096,
            max_pivots: 1_000_000,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CapReason {
    MergeDepth,
    RowTerms,
    PivotCount,
}

/// The graph makes no completion claim when a configured cap is reached.
#[derive(Clone, Debug)]
pub enum FeedOutcome {
    PivotStored {
        merge_depth: usize,
    },
    Full(WideFullRelation),
    UnknownCap {
        reason: CapReason,
        merge_depth: usize,
    },
}

/// A row over signed factor-base orbit representatives only.
///
/// Source coefficients make the row independently replayable from retained
/// input partials. The small coefficients and both right-hand-side scalars
/// are always reduced modulo the full subgroup order.
#[derive(Clone, Debug)]
pub struct WideFullRelation {
    pub coef_a: BigUint,
    pub coef_b: BigUint,
    pub small: BTreeMap<usize, BigUint>,
    pub source_coeffs: BTreeMap<u64, BigUint>,
    pub merge_depth: usize,
}

impl WideFullRelation {
    pub fn dense_row(&self, columns: usize) -> Result<Vec<BigUint>, &'static str> {
        let mut row = vec![BigUint::zero(); columns];
        for (&column, coefficient) in &self.small {
            let entry = row.get_mut(column).ok_or("small column out of range")?;
            *entry = coefficient.clone();
        }
        Ok(row)
    }
}

/// A full-rank solution whose orbit logs and target log passed group replay.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct WideSolvedLogs {
    pub column_logs: Vec<BigUint>,
    pub target_log: BigUint,
}

#[derive(Clone, Copy, Debug, Default)]
pub struct LargePrimeStats {
    pub accepted_candidates: u64,
    pub pivot_rows: usize,
    pub full_rows: u64,
    pub full_from_partials: u64,
    pub capped_rows: u64,
    pub pivot_reductions: u64,
}

#[derive(Clone, Debug)]
struct SparseRow {
    coef_a: BigUint,
    coef_b: BigUint,
    small: BTreeMap<usize, BigUint>,
    large: BTreeMap<PointKey, BigUint>,
    sources: BTreeMap<u64, BigUint>,
}

fn add_mod<K: Ord>(
    map: &mut BTreeMap<K, BigUint>,
    key: K,
    coefficient: &BigUint,
    modulus: &BigUint,
) {
    let value = (map.get(&key).cloned().unwrap_or_default() + coefficient) % modulus;
    if value.is_zero() {
        map.remove(&key);
    } else {
        map.insert(key, value);
    }
}

fn sub_mod(a: &BigUint, b: &BigUint, modulus: &BigUint) -> BigUint {
    (a + modulus - b) % modulus
}

impl SparseRow {
    fn term_count(&self) -> usize {
        self.small.len() + self.large.len() + self.sources.len()
    }

    fn scale(&mut self, factor: &BigUint, modulus: &BigUint) {
        self.coef_a = (&self.coef_a * factor) % modulus;
        self.coef_b = (&self.coef_b * factor) % modulus;
        for value in self.small.values_mut() {
            *value = (&*value * factor) % modulus;
        }
        for value in self.sources.values_mut() {
            *value = (&*value * factor) % modulus;
        }
        for value in self.large.values_mut() {
            *value = (&*value * factor) % modulus;
        }
    }

    fn subtract_scaled(&mut self, pivot: &SparseRow, factor: &BigUint, modulus: &BigUint) {
        self.coef_a = sub_mod(&self.coef_a, &((&pivot.coef_a * factor) % modulus), modulus);
        self.coef_b = sub_mod(&self.coef_b, &((&pivot.coef_b * factor) % modulus), modulus);
        for (&key, value) in &pivot.small {
            let neg = sub_mod(&BigUint::zero(), &((value * factor) % modulus), modulus);
            add_mod(&mut self.small, key, &neg, modulus);
        }
        for (key, value) in &pivot.large {
            let neg = sub_mod(&BigUint::zero(), &((value * factor) % modulus), modulus);
            add_mod(&mut self.large, key.clone(), &neg, modulus);
        }
        for (&key, value) in &pivot.sources {
            let neg = sub_mod(&BigUint::zero(), &((value * factor) % modulus), modulus);
            add_mod(&mut self.sources, key, &neg, modulus);
        }
    }
}

enum Reduced {
    Pivot(PointKey, usize),
    Full(SparseRow, usize),
    Capped(CapReason, usize),
}

struct Reducer {
    modulus: BigUint,
    limits: LargePrimeLimits,
    pivots: BTreeMap<PointKey, SparseRow>,
    reductions: u64,
}

impl Reducer {
    fn new(modulus: BigUint, limits: LargePrimeLimits) -> Result<Self, &'static str> {
        if modulus < BigUint::from(2u32)
            || limits.max_merge_depth == 0
            || limits.max_row_terms == 0
            || limits.max_pivots == 0
        {
            return Err("invalid large-prime modulus or cap");
        }
        Ok(Self {
            modulus,
            limits,
            pivots: BTreeMap::new(),
            reductions: 0,
        })
    }

    fn feed(&mut self, mut row: SparseRow) -> Result<Reduced, &'static str> {
        if row.term_count() > self.limits.max_row_terms {
            return Ok(Reduced::Capped(CapReason::RowTerms, 0));
        }
        let mut depth = 0;
        loop {
            if row.large.is_empty() {
                return Ok(Reduced::Full(row, depth));
            }
            let existing = row
                .large
                .iter()
                .find(|(key, _)| self.pivots.contains_key(*key))
                .map(|(key, value)| (key.clone(), value.clone()));
            if let Some((key, factor)) = existing {
                if depth >= self.limits.max_merge_depth {
                    return Ok(Reduced::Capped(CapReason::MergeDepth, depth));
                }
                row.subtract_scaled(&self.pivots[&key], &factor, &self.modulus);
                depth += 1;
                self.reductions += 1;
                if row.term_count() > self.limits.max_row_terms {
                    return Ok(Reduced::Capped(CapReason::RowTerms, depth));
                }
                continue;
            }
            if self.pivots.len() >= self.limits.max_pivots {
                return Ok(Reduced::Capped(CapReason::PivotCount, depth));
            }
            let (key, coefficient) = row.large.iter().next().expect("nonempty row");
            let key = key.clone();
            let inverse = mod_inverse(coefficient, &self.modulus)
                .ok_or("large-prime pivot is not invertible modulo subgroup order")?;
            row.scale(&inverse, &self.modulus);
            self.pivots.insert(key.clone(), row);
            return Ok(Reduced::Pivot(key, depth));
        }
    }
}

/// A wide, signed-Frobenius large-prime adapter for subgroup point relations.
///
/// Its input is a completed decomposition with zero, one or two residual
/// points. A discovery solver and a source-pinned total-runtime harness are
/// separate gates.
pub struct WideLargePrimeEliminator<'a> {
    curve: &'a KoblitzCurve,
    base: Cow<'a, FrobeniusFactorBase>,
    target: BinaryPoint,
    base_index: HashMap<PointKey, usize>,
    reducer: Reducer,
    seen_sources: BTreeSet<u64>,
    stats: LargePrimeStats,
}

impl<'a> WideLargePrimeEliminator<'a> {
    pub fn new(
        curve: &'a KoblitzCurve,
        base: &'a FrobeniusFactorBase,
        target: BinaryPoint,
        limits: LargePrimeLimits,
    ) -> Result<Self, &'static str> {
        Self::with_base(curve, Cow::Borrowed(base), target, limits)
    }

    /// [`new`](Self::new) over a base the eliminator owns, for a caller
    /// that builds the signed-orbit base and the eliminator together
    /// (the framework's large-prime collector).
    pub fn new_owned(
        curve: &'a KoblitzCurve,
        base: FrobeniusFactorBase,
        target: BinaryPoint,
        limits: LargePrimeLimits,
    ) -> Result<Self, &'static str> {
        Self::with_base(curve, Cow::Owned(base), target, limits)
    }

    /// The signed-orbit base rows are written over.
    pub fn base(&self) -> &FrobeniusFactorBase {
        &self.base
    }

    /// The public target `Q` every row's `coef_b` multiplies.
    pub fn target(&self) -> &BinaryPoint {
        &self.target
    }

    fn with_base(
        curve: &'a KoblitzCurve,
        base: Cow<'a, FrobeniusFactorBase>,
        target: BinaryPoint,
        limits: LargePrimeLimits,
    ) -> Result<Self, &'static str> {
        let modulus = &curve.subgroup_order;
        if !curve.frobenius_is_endomorphism
            || curve.lambda.modpow(&BigUint::from(curve.n), modulus) != BigUint::one()
            || target == BinaryPoint::Infinity
            || !curve.curve.is_on_curve(&target)
            || curve.mul(&target, modulus) != BinaryPoint::Infinity
            || !curve.curve.is_on_curve(curve.generator())
            || curve.mul(curve.generator(), modulus) != BinaryPoint::Infinity
            || base.signed_orbit_of.len() != base.points.len()
            || base.signed_orbits.is_empty()
        {
            return Err("large-prime adapter requires a valid subgroup and orbit base");
        }
        for orbit in &base.signed_orbits {
            let index = *orbit.first().ok_or("empty signed orbit")?;
            let rep = base.points.get(index).ok_or("invalid signed orbit index")?;
            if *rep == BinaryPoint::Infinity
                || !curve.curve.is_on_curve(rep)
                || curve.mul(rep, modulus) != BinaryPoint::Infinity
            {
                return Err("signed orbit representative is outside the subgroup");
            }
        }
        let base_index = base.index_map();
        Ok(Self {
            curve,
            base,
            target,
            base_index,
            reducer: Reducer::new(modulus.clone(), limits)?,
            seen_sources: BTreeSet::new(),
            stats: LargePrimeStats::default(),
        })
    }

    pub fn stats(&self) -> LargePrimeStats {
        let mut stats = self.stats;
        stats.pivot_rows = self.reducer.pivots.len();
        stats.pivot_reductions = self.reducer.reductions;
        stats
    }

    /// Solve completed graph rows in the signed-orbit basis used by this
    /// eliminator. Every row is replayed before entering the matrix; every
    /// recovered orbit log and the target log is checked in the group.
    /// Missing rank returns `None`, including when Gaussian elimination can
    /// assign arbitrary values to free columns.
    pub fn solve_completed_full_rank(
        &self,
        relations: &[WideFullRelation],
    ) -> Result<Option<WideSolvedLogs>, &'static str> {
        let orbit_count = self.base.signed_orbits.len();
        let columns = orbit_count + 1;
        let modulus = &self.reducer.modulus;
        let mut matrix = Vec::with_capacity(relations.len());
        let mut rhs = Vec::with_capacity(relations.len());
        for relation in relations {
            if relation.coef_a >= *modulus
                || relation.coef_b >= *modulus
                || relation.small.values().any(|value| value >= modulus)
                || relation
                    .source_coeffs
                    .values()
                    .any(|value| value >= modulus)
            {
                return Err("completed row is not reduced modulo subgroup order");
            }
            self.verify_row(&SparseRow {
                coef_a: relation.coef_a.clone(),
                coef_b: relation.coef_b.clone(),
                small: relation.small.clone(),
                large: BTreeMap::new(),
                sources: relation.source_coeffs.clone(),
            })?;
            let mut row = relation.dense_row(orbit_count)?;
            row.push(sub_mod(&BigUint::zero(), &relation.coef_b, modulus));
            matrix.push(row);
            rhs.push(relation.coef_a.clone());
        }
        if relations.len() < columns {
            return Ok(None);
        }
        let solution = gaussian_eliminate_mod_n_particular(&mut matrix, &mut rhs, modulus)
            .ok_or("completed-row matrix has a noninvertible pivot")?;
        if solution.rank < columns || solution.determined.iter().any(|&determined| !determined) {
            return Ok(None);
        }
        let solution = solution.values;
        for (orbit, log) in solution[..orbit_count].iter().enumerate() {
            let index = *self.base.signed_orbits[orbit]
                .first()
                .ok_or("empty signed orbit")?;
            if self.curve.mul(self.curve.generator(), log) != self.base.points[index] {
                return Err("completed-row orbit log failed group replay");
            }
        }
        let target_log = solution[orbit_count].clone();
        if self.curve.mul(self.curve.generator(), &target_log) != self.target {
            return Err("completed-row target log failed group replay");
        }
        Ok(Some(WideSolvedLogs {
            column_logs: solution[..orbit_count].to_vec(),
            target_log,
        }))
    }

    fn canonical_residual(&self, point: &BinaryPoint) -> Result<(PointKey, BigUint), &'static str> {
        let modulus = &self.reducer.modulus;
        let mut walk = point.clone();
        let mut best: Option<(PointKey, BinaryPoint, u32, bool)> = None;
        for phase in 0..self.curve.n {
            for negated in [false, true] {
                let candidate = if negated {
                    point_neg(&walk)
                } else {
                    walk.clone()
                };
                let key = point_key(&candidate);
                if best.as_ref().is_none_or(|(old, _, _, _)| key < *old) {
                    best = Some((key, candidate, phase, negated));
                }
            }
            walk = self.curve.frobenius(&walk);
        }
        let (key, rep, phase, negated) = best.ok_or("empty Frobenius orbit")?;
        let phase_factor = self.curve.lambda.modpow(&BigUint::from(phase), modulus);
        let inverse =
            mod_inverse(&phase_factor, modulus).ok_or("Frobenius phase is not invertible")?;
        let coefficient = if negated {
            sub_mod(&BigUint::zero(), &inverse, modulus)
        } else {
            inverse
        };
        if self.curve.mul(&rep, &coefficient) != *point {
            return Err("residual Frobenius lifting failed");
        }
        Ok((key, coefficient))
    }

    fn point_from_key(&self, key: &PointKey) -> Result<BinaryPoint, &'static str> {
        if key.0.is_zero() {
            return Err("identity is not a large-prime column");
        }
        Ok(BinaryPoint::Affine {
            x: F2mElement::from_biguint(&(&key.0 - BigUint::one()), self.curve.n),
            y: F2mElement::from_biguint(&key.1, self.curve.n),
        })
    }

    fn verify_row(&self, row: &SparseRow) -> Result<(), &'static str> {
        let mut lhs = self.curve.mul(self.curve.generator(), &row.coef_a);
        lhs = self
            .curve
            .add(&lhs, &self.curve.mul(&self.target, &row.coef_b));
        let mut rhs = BinaryPoint::Infinity;
        for (&orbit, coefficient) in &row.small {
            let index = *self
                .base
                .signed_orbits
                .get(orbit)
                .and_then(|points| points.first())
                .ok_or("small orbit index out of range")?;
            rhs = self
                .curve
                .add(&rhs, &self.curve.mul(&self.base.points[index], coefficient));
        }
        for (key, coefficient) in &row.large {
            let rep = self.point_from_key(key)?;
            rhs = self.curve.add(&rhs, &self.curve.mul(&rep, coefficient));
        }
        if lhs != rhs {
            return Err("large-prime row failed group replay");
        }
        Ok(())
    }

    pub fn feed(&mut self, candidate: PartialCandidate) -> Result<FeedOutcome, &'static str> {
        if self.seen_sources.contains(&candidate.source_id) {
            return Err("duplicate partial source id");
        }
        if candidate.residual_points.len() > 2 {
            return Err("at most two residual points are supported");
        }
        let modulus = &self.reducer.modulus;
        let coef_a = &candidate.coef_a % modulus;
        let coef_b = &candidate.coef_b % modulus;
        let mut rhs = BinaryPoint::Infinity;
        let mut small = BTreeMap::new();
        for &index in &candidate.small_point_indices {
            let point = self
                .base
                .points
                .get(index)
                .ok_or("small point index out of range")?;
            if *point == BinaryPoint::Infinity
                || !self.curve.curve.is_on_curve(point)
                || self.curve.mul(point, modulus) != BinaryPoint::Infinity
            {
                return Err("small point is outside the subgroup");
            }
            rhs = self.curve.add(&rhs, point);
            let (orbit, phase, negated) = *self
                .base
                .signed_orbit_of
                .get(index)
                .ok_or("small point lacks signed orbit label")?;
            let rep_index = *self
                .base
                .signed_orbits
                .get(orbit)
                .and_then(|points| points.first())
                .ok_or("small point has invalid signed orbit label")?;
            let phase_factor = self.curve.lambda.modpow(&BigUint::from(phase), modulus);
            let coefficient = if negated {
                sub_mod(&BigUint::zero(), &phase_factor, modulus)
            } else {
                phase_factor
            };
            if self.curve.mul(&self.base.points[rep_index], &coefficient) != *point {
                return Err("small signed orbit label failed group replay");
            }
            add_mod(&mut small, orbit, &coefficient, modulus);
        }
        let mut large = BTreeMap::new();
        for point in &candidate.residual_points {
            if *point == BinaryPoint::Infinity
                || !self.curve.curve.is_on_curve(point)
                || self.curve.mul(point, modulus) != BinaryPoint::Infinity
                || self.base_index.contains_key(&point_key(point))
            {
                return Err("residual point is invalid or already in the factor base");
            }
            rhs = self.curve.add(&rhs, point);
            let (key, coefficient) = self.canonical_residual(point)?;
            if self.base_index.contains_key(&key) {
                return Err("residual orbit intersects the factor base");
            }
            add_mod(&mut large, key, &coefficient, modulus);
        }
        let lhs = self.curve.add(
            &self.curve.mul(self.curve.generator(), &coef_a),
            &self.curve.mul(&self.target, &coef_b),
        );
        if lhs != rhs {
            return Err("partial relation failed exact point-sum replay");
        }
        let mut sources = BTreeMap::new();
        sources.insert(candidate.source_id, BigUint::one());
        let row = SparseRow {
            coef_a,
            coef_b,
            small,
            large,
            sources,
        };
        self.verify_row(&row)?;
        let reduced = self.reducer.feed(row)?;
        let outcome = match reduced {
            Reduced::Pivot(key, merge_depth) => {
                if let Err(error) = self.verify_row(&self.reducer.pivots[&key]) {
                    self.reducer.pivots.remove(&key);
                    return Err(error);
                }
                FeedOutcome::PivotStored { merge_depth }
            }
            Reduced::Full(row, merge_depth) => {
                self.verify_row(&row)?;
                self.stats.full_rows += 1;
                if merge_depth > 0 {
                    self.stats.full_from_partials += 1;
                }
                FeedOutcome::Full(WideFullRelation {
                    coef_a: row.coef_a,
                    coef_b: row.coef_b,
                    small: row.small,
                    source_coeffs: row.sources,
                    merge_depth,
                })
            }
            Reduced::Capped(reason, merge_depth) => {
                self.stats.capped_rows += 1;
                FeedOutcome::UnknownCap {
                    reason,
                    merge_depth,
                }
            }
        };
        self.seen_sources.insert(candidate.source_id);
        self.stats.accepted_candidates += 1;
        Ok(outcome)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cryptanalysis::koblitz_index_calculus::build_explicit_frobenius_orbit_factor_base;

    fn fake_key(x: u32) -> PointKey {
        (BigUint::from(x), BigUint::zero())
    }

    fn algebra_row(id: u64, a: u64, small: usize, large: &[u32]) -> SparseRow {
        SparseRow {
            coef_a: BigUint::from(a),
            coef_b: BigUint::zero(),
            small: BTreeMap::from([(small, BigUint::one())]),
            large: large
                .iter()
                .map(|&x| (fake_key(x), BigUint::one()))
                .collect(),
            sources: BTreeMap::from([(id, BigUint::one())]),
        }
    }

    #[test]
    fn mixed_orbit_domains_lift_disjoint_partial_and_fail_closed_on_caps() {
        let curve = KoblitzCurve::new(1, 7).unwrap();
        let mut selected: Vec<(u32, F2mElement)> = Vec::new();
        let mut seen = BTreeSet::new();
        for scalar in 1..200u32 {
            let BinaryPoint::Affine { x, .. } =
                curve.mul(curve.generator(), &BigUint::from(scalar))
            else {
                continue;
            };
            let mut phase_x = x.clone();
            let mut orbit = Vec::new();
            for _ in 0..curve.n {
                orbit.push(phase_x.to_biguint());
                phase_x = curve.frobenius_x(&phase_x);
            }
            let key = orbit.into_iter().min().unwrap();
            if seen.insert(key) {
                selected.push((scalar, x));
            }
            if selected.len() == 4 {
                break;
            }
        }
        assert_eq!(selected.len(), 4);
        let small = build_explicit_frobenius_orbit_factor_base(
            &curve,
            &[selected[0].1.clone(), selected[1].1.clone()],
        )
        .unwrap();
        let residual = build_explicit_frobenius_orbit_factor_base(
            &curve,
            &[selected[2].1.clone(), selected[3].1.clone()],
        )
        .unwrap();
        let envelope = build_explicit_frobenius_point_factor_base(
            &curve,
            small
                .points
                .iter()
                .chain(&residual.points)
                .cloned()
                .collect(),
        )
        .unwrap();
        let extracted = build_exact_residual_suffix_factor_base(&curve, &small, &envelope).unwrap();
        assert_eq!(extracted.points, residual.points);
        assert_eq!(extracted.signed_orbits, residual.signed_orbits);
        let mut changed_prefix = envelope.clone();
        changed_prefix.points.swap(0, small.points.len());
        assert!(build_exact_residual_suffix_factor_base(&curve, &small, &changed_prefix).is_err());
        let mut changed_suffix_label = envelope.clone();
        changed_suffix_label.signed_orbit_of[small.points.len()].0 = 0;
        assert!(
            build_exact_residual_suffix_factor_base(&curve, &small, &changed_suffix_label).is_err()
        );
        let domains = MixedOrbitDomains::new(&curve, &small, &residual).unwrap();
        let target = curve.mul(curve.generator(), &BigUint::from(17u32));
        let xs = vec![
            selected[0].1.clone(),
            selected[1].1.clone(),
            selected[0].1.clone(),
            selected[1].1.clone(),
            selected[2].1.clone(),
        ];
        let a = BigUint::from(selected[0].0 * 2 + selected[1].0 * 2 + selected[2].0);
        let sum = curve.mul(curve.generator(), &a);
        let (small_indices, residual_points) = domains.lift(&xs, 4, &sum).unwrap();
        assert_eq!(small_indices.len(), 4);
        assert_eq!(residual_points.len(), 1);
        let mut graph = WideLargePrimeEliminator::new(
            &curve,
            &small,
            target.clone(),
            LargePrimeLimits::default(),
        )
        .unwrap();
        assert!(matches!(
            graph
                .feed(PartialCandidate {
                    source_id: 1,
                    coef_a: a.clone(),
                    coef_b: BigUint::zero(),
                    small_point_indices: small_indices,
                    residual_points,
                })
                .unwrap(),
            FeedOutcome::PivotStored { .. }
        ));
        assert!(MixedOrbitDomains::new(&curve, &small, &small).is_err());
        let capped = ChainS3Limits {
            max_variables: 1,
            max_domain_clauses: 1,
            max_models: 1,
            conflict_budget: 1,
        };
        let (candidate, stats) =
            domains.search(2, &a, &BigUint::zero(), &target, 4, 1, capped, true);
        assert!(candidate.is_none());
        assert!(stats.exhausted);
        assert!(!stats.refuted);
        assert_eq!(stats.patterns_attempted, 0);

        let bounded = ChainS3Limits {
            max_variables: 20_000,
            max_domain_clauses: 20_000,
            max_models: 100,
            conflict_budget: 100_000,
        };
        let (candidate, stats) =
            domains.search(3, &a, &BigUint::zero(), &target, 4, 1, bounded, true);
        assert!(candidate.is_some(), "bounded SAT search: {stats:?}");
        assert!(stats.models > 0);
        assert!(matches!(
            graph.feed(candidate.unwrap()).unwrap(),
            FeedOutcome::PivotStored { .. }
        ));

        let double_a =
            BigUint::from(selected[0].0 * 2 + selected[1].0 + selected[2].0 + selected[3].0);
        let double_xs = vec![
            selected[0].1.clone(),
            selected[1].1.clone(),
            selected[0].1.clone(),
            selected[2].1.clone(),
            selected[3].1.clone(),
        ];
        let double_sum = curve.mul(curve.generator(), &double_a);
        let (double_small, double_residual) = domains.lift(&double_xs, 3, &double_sum).unwrap();
        assert_eq!(double_small.len(), 3);
        assert_eq!(double_residual.len(), 2);
        graph
            .feed(PartialCandidate {
                source_id: 4,
                coef_a: double_a.clone(),
                coef_b: BigUint::zero(),
                small_point_indices: double_small,
                residual_points: double_residual,
            })
            .unwrap();

        let (candidate, stats) =
            domains.search(5, &double_a, &BigUint::zero(), &target, 3, 2, bounded, true);
        let candidate = candidate.unwrap_or_else(|| panic!("two-residual SAT search: {stats:?}"));
        assert!(stats.models > 0);
        assert_eq!(candidate.small_point_indices.len(), 3);
        assert_eq!(candidate.residual_points.len(), 2);
        graph.feed(candidate).unwrap();
    }

    #[test]
    fn cross_stream_difference_keeps_only_complete_disjoint_signed_orbits() {
        let curve = KoblitzCurve::new(1, 7).unwrap();
        let mut xs = Vec::new();
        let mut seen = BTreeSet::new();
        for scalar in 1..200u32 {
            let BinaryPoint::Affine { x, .. } =
                curve.mul(curve.generator(), &BigUint::from(scalar))
            else {
                continue;
            };
            let mut phase = x.clone();
            let mut orbit = Vec::new();
            for _ in 0..curve.n {
                orbit.push(phase.to_biguint());
                phase = curve.frobenius_x(&phase);
            }
            if seen.insert(orbit.into_iter().min().unwrap()) {
                xs.push(x);
            }
            if xs.len() == 4 {
                break;
            }
        }
        assert_eq!(xs.len(), 4);
        let base = |indices: &[usize]| {
            build_explicit_frobenius_orbit_factor_base(
                &curve,
                &indices
                    .iter()
                    .map(|&index| xs[index].clone())
                    .collect::<Vec<_>>(),
            )
            .unwrap()
        };
        let small = base(&[0, 1]);
        let cross_stream_pool = base(&[1, 2, 3]);
        let expected = base(&[2, 3]);
        assert_ne!(cross_stream_pool.points[..small.points.len()], small.points);
        let residual =
            build_exact_residual_difference_factor_base(&curve, &small, &cross_stream_pool)
                .unwrap();
        assert_eq!(residual.signed_orbits.len(), expected.signed_orbits.len());
        assert_eq!(
            residual
                .points
                .iter()
                .map(point_key)
                .collect::<BTreeSet<_>>(),
            expected
                .points
                .iter()
                .map(point_key)
                .collect::<BTreeSet<_>>()
        );
        assert!(MixedOrbitDomains::new(&curve, &small, &residual).is_ok());

        let nested_pool = build_explicit_frobenius_point_factor_base(
            &curve,
            small
                .points
                .iter()
                .chain(&expected.points)
                .cloned()
                .collect(),
        )
        .unwrap();
        let nested_difference =
            build_exact_residual_difference_factor_base(&curve, &small, &nested_pool).unwrap();
        let nested_suffix =
            build_exact_residual_suffix_factor_base(&curve, &small, &nested_pool).unwrap();
        assert_eq!(
            nested_difference
                .points
                .iter()
                .map(point_key)
                .collect::<BTreeSet<_>>(),
            nested_suffix
                .points
                .iter()
                .map(point_key)
                .collect::<BTreeSet<_>>()
        );
        assert_eq!(
            nested_difference.signed_orbits.len(),
            nested_suffix.signed_orbits.len()
        );

        let mut changed_label = cross_stream_pool.clone();
        changed_label.signed_orbit_of[0].1 ^= 1;
        assert!(
            build_exact_residual_difference_factor_base(&curve, &small, &changed_label).is_err()
        );
        let mut partial_overlap = small.clone();
        partial_overlap.points.pop();
        partial_overlap.signed_orbit_of.pop();
        assert!(build_exact_residual_difference_factor_base(
            &curve,
            &partial_overlap,
            &cross_stream_pool
        )
        .is_err());
        assert!(build_exact_residual_difference_factor_base(&curve, &small, &small).is_err());
    }

    #[test]
    fn full_width_double_large_prime_cycle_has_exact_source_coefficients() {
        let modulus: BigUint = (BigUint::one() << 81usize) - BigUint::one();
        let mut reducer = Reducer::new(modulus.clone(), LargePrimeLimits::default()).unwrap();
        assert!(matches!(
            reducer.feed(algebra_row(1, 10, 0, &[2, 3])).unwrap(),
            Reduced::Pivot(_, 0)
        ));
        assert!(matches!(
            reducer.feed(algebra_row(2, 4, 1, &[2])).unwrap(),
            Reduced::Pivot(_, 1)
        ));
        let Reduced::Full(row, depth) = reducer.feed(algebra_row(3, 7, 2, &[3])).unwrap() else {
            panic!("three partials must close the two-residual cycle");
        };
        assert!(depth > 0);
        assert!(row.large.is_empty());
        assert_eq!(row.sources.len(), 3);
        let a_from_sources = row
            .sources
            .iter()
            .fold(BigUint::zero(), |acc, (id, coeff)| {
                let input_a = match id {
                    1 => 10u32,
                    2 => 4,
                    3 => 7,
                    _ => panic!("unknown source"),
                };
                (acc + coeff * BigUint::from(input_a)) % &modulus
            });
        assert_eq!(a_from_sources, row.coef_a);
        assert!(row.coef_a.bits() <= 81);
    }

    #[test]
    fn graph_caps_are_unknown_and_do_not_store_unreduced_rows() {
        let modulus = BigUint::from(101u32);
        let limits = LargePrimeLimits {
            max_merge_depth: 1,
            max_row_terms: 20,
            max_pivots: 2,
        };
        let mut reducer = Reducer::new(modulus.clone(), limits).unwrap();
        assert!(matches!(
            reducer.feed(algebra_row(1, 1, 0, &[2])).unwrap(),
            Reduced::Pivot(_, 0)
        ));
        assert!(matches!(
            reducer.feed(algebra_row(2, 2, 1, &[3])).unwrap(),
            Reduced::Pivot(_, 0)
        ));
        assert!(matches!(
            reducer.feed(algebra_row(3, 3, 2, &[2, 3])).unwrap(),
            Reduced::Capped(CapReason::MergeDepth, 1)
        ));
        assert_eq!(reducer.pivots.len(), 2);
        assert!(matches!(
            reducer.feed(algebra_row(4, 4, 3, &[4])).unwrap(),
            Reduced::Capped(CapReason::PivotCount, 0)
        ));
        assert_eq!(reducer.pivots.len(), 2);
        let mut narrow = Reducer::new(
            modulus,
            LargePrimeLimits {
                max_row_terms: 2,
                ..LargePrimeLimits::default()
            },
        )
        .unwrap();
        assert!(matches!(
            narrow.feed(algebra_row(5, 5, 4, &[5])).unwrap(),
            Reduced::Capped(CapReason::RowTerms, 0)
        ));
        assert!(narrow.pivots.is_empty());
    }

    #[test]
    fn group_replay_closes_two_residual_orbits_and_rejects_bad_inputs() {
        let curve = KoblitzCurve::new(1, 11).unwrap();
        let BinaryPoint::Affine { x, .. } = curve.generator() else {
            panic!("generator is affine");
        };
        let base =
            build_explicit_frobenius_orbit_factor_base(&curve, std::slice::from_ref(x)).unwrap();
        let target = curve.mul(curve.generator(), &BigUint::from(17u32));
        let mut graph =
            WideLargePrimeEliminator::new(&curve, &base, target, LargePrimeLimits::default())
                .unwrap();
        let mut residuals: Vec<(u32, BinaryPoint, PointKey)> = Vec::new();
        for scalar in 2..200u32 {
            let point = curve.mul(curve.generator(), &BigUint::from(scalar));
            if base.index_map().contains_key(&point_key(&point)) {
                continue;
            }
            let (key, _) = graph.canonical_residual(&point).unwrap();
            if residuals.iter().all(|(_, _, existing)| *existing != key) {
                residuals.push((scalar, point, key));
            }
            if residuals.len() == 2 {
                break;
            }
        }
        assert_eq!(residuals.len(), 2);
        let r = &curve.subgroup_order;
        let (key, positive) = graph.canonical_residual(&residuals[0].1).unwrap();
        let (negative_key, negative) = graph
            .canonical_residual(&point_neg(&residuals[0].1))
            .unwrap();
        assert_eq!(key, negative_key);
        assert_eq!((positive + negative) % r, BigUint::zero());
        let make = |source_id: u64, b: u32, selected: &[usize]| {
            let sum = selected.iter().fold(BigUint::one(), |acc, &i| {
                acc + BigUint::from(residuals[i].0)
            });
            PartialCandidate {
                source_id,
                coef_a: (sum + r - (BigUint::from(b) * BigUint::from(17u32)) % r) % r,
                coef_b: BigUint::from(b),
                small_point_indices: vec![base.index_map()[&point_key(curve.generator())]],
                residual_points: selected.iter().map(|&i| residuals[i].1.clone()).collect(),
            }
        };
        let mut bad = make(99, 1, &[0]);
        bad.coef_a += BigUint::one();
        assert!(graph.feed(bad).is_err());
        assert!(matches!(
            graph.feed(make(1, 1, &[0, 1])).unwrap(),
            FeedOutcome::PivotStored { .. }
        ));
        assert!(matches!(
            graph.feed(make(2, 2, &[0])).unwrap(),
            FeedOutcome::PivotStored { .. }
        ));
        let FeedOutcome::Full(full) = graph.feed(make(3, 3, &[1])).unwrap() else {
            panic!("two-residual graph did not close");
        };
        assert_eq!(full.source_coeffs.len(), 3);
        assert!(full.merge_depth > 0);
        assert_eq!(
            full.dense_row(base.unknowns()).unwrap().len(),
            base.unknowns()
        );
        assert_eq!(base.unknowns(), 1);
        assert!(graph
            .solve_completed_full_rank(std::slice::from_ref(&full))
            .unwrap()
            .is_none());
        let FeedOutcome::Full(direct) = graph
            .feed(PartialCandidate {
                source_id: 4,
                coef_a: BigUint::one(),
                coef_b: BigUint::zero(),
                small_point_indices: vec![base.index_map()[&point_key(curve.generator())]],
                residual_points: vec![],
            })
            .unwrap()
        else {
            panic!("a full point relation must complete immediately");
        };
        let solution = graph
            .solve_completed_full_rank(&[direct.clone(), full.clone()])
            .unwrap()
            .expect("independent full rows must solve both logs");
        assert_eq!(solution.target_log, BigUint::from(17u32));
        assert_eq!(solution.column_logs.len(), 1);
        let FeedOutcome::Full(dependent) = graph
            .feed(PartialCandidate {
                source_id: 5,
                coef_a: BigUint::from(2u32),
                coef_b: BigUint::zero(),
                small_point_indices: vec![
                    base.index_map()[&point_key(curve.generator())],
                    base.index_map()[&point_key(curve.generator())],
                ],
                residual_points: vec![],
            })
            .unwrap()
        else {
            panic!("a second full point relation must complete immediately");
        };
        assert!(graph
            .solve_completed_full_rank(&[direct.clone(), dependent])
            .unwrap()
            .is_none());
        let mut corrupt = full.clone();
        corrupt.coef_a = (&corrupt.coef_a + BigUint::one()) % r;
        assert!(graph.solve_completed_full_rank(&[direct, corrupt]).is_err());
        let stats = graph.stats();
        assert_eq!(stats.accepted_candidates, 5);
        assert_eq!(stats.full_from_partials, 1);
        assert_eq!(stats.full_rows, 3);
        assert_eq!(stats.pivot_rows, 2);
        assert!(graph.feed(make(3, 3, &[1])).is_err(), "duplicate source id");
    }
}
