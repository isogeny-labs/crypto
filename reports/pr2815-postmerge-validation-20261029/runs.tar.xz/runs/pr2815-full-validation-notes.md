# Post-merge validation of PR #2815

Requested scope: run the previously incomplete full root-library validation on the merged source, plus affected native-package checks. This is correctness validation in the existing workspace; no new research panel or cloud job is launched.

Source: 0044aaf9dfffa0f0f73d50ee2e5d141dc05b6036 (PR #2815 merge).

Commands: `cargo test --release --locked --lib`; native package release tests, strict Clippy, and formatting. Cargo build jobs and libtest threads are four. Default features and default ignored-test behavior apply; no test filter, skip, or weakened assertion is added.

References checked before launch: repository AGENTS.md, report-evidence skill, docs/sparse-checkout.md, scripts/sparse-checkout.sh, and the official Cargo test command reference (https://doc.rust-lang.org/cargo/commands/cargo-test.html).

Input preparation uses the repository minimal sparse profile, regenerated from this exact source, with backlog/, gpu/certicom/, isogeny_algos/, and research/ecbench_bounds_challenges_20261006/ explicitly present. The original authoring worktree and previous failed logs remain untouched.

Attempt 1 was interrupted during compilation: both its supervisor and Cargo have Linux wait status 9. Container OOM-kill counter was zero at observation. No final test summary or success is claimed. Raw output and metadata are retained separately.

Attempt 2 runs in a tool-managed foreground session. Completion requires the terminal harness summary and durable exit receipt, not merely a quiet log or missing process.
