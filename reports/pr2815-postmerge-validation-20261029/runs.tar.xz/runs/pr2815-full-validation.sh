#!/usr/bin/env bash
set -u
. "$HOME/.cargo/env"
cd /workspace/crypto-full-validation-0044 || exit 2
export CARGO_TARGET_DIR=/workspace/crypto/target
export CARGO_BUILD_JOBS=4
export RUST_TEST_THREADS=4
validation_source=$(git rev-parse HEAD)
validation_tree=$(git rev-parse HEAD^{tree})
validation_started=$(date -u +%Y-%m-%dT%H:%M:%SZ)
{
  printf 'requested_scope=complete default-feature root-library suite, plus native package checks\n'
  printf 'source=%s\ntree=%s\nstarted_at=%s\n' "$validation_source" "$validation_tree" "$validation_started"
  printf 'root_command=cargo test --release --locked --lib\n'
  printf 'CARGO_BUILD_JOBS=4\nRUST_TEST_THREADS=4\n'
  rustc -Vv
  cargo -V
  git status --porcelain=v1 --untracked-files=no
} > /workspace/pr2815-full-validation-metadata.txt
cargo test --release --locked --lib > /workspace/crypto-library-tests-0044-full.log 2>&1 &
validation_child=$!
printf '%s\n' "$validation_child" > /workspace/pr2815-full-library-cargo.pid
wait "$validation_child"
validation_status=$?
validation_finished=$(date -u +%Y-%m-%dT%H:%M:%SZ)
validation_log_hash=$(sha256sum /workspace/crypto-library-tests-0044-full.log | cut -d ' ' -f 1)
printf '{"source":"%s","tree":"%s","command":"cargo test --release --locked --lib","started_at":"%s","finished_at":"%s","exit_code":%s,"log_sha256":"%s"}\n' "$validation_source" "$validation_tree" "$validation_started" "$validation_finished" "$validation_status" "$validation_log_hash" > /workspace/pr2815-full-library-exit.json.tmp
mv /workspace/pr2815-full-library-exit.json.tmp /workspace/pr2815-full-library-exit.json
{
  cargo fmt --manifest-path tools/twist-relations/Cargo.toml --check
  validation_fmt=$?
  cargo clippy --release --locked --manifest-path tools/twist-relations/Cargo.toml --all-targets -- -D warnings
  validation_clippy=$?
  cargo test --release --locked --manifest-path tools/twist-relations/Cargo.toml
  validation_native=$?
  printf 'NATIVE_EXIT_CODES fmt=%s clippy=%s test=%s\n' "$validation_fmt" "$validation_clippy" "$validation_native"
} > /workspace/pr2815-native-tests-0044-full.log 2>&1
printf '{"source":"%s","root_exit_code":%s,"native_fmt_exit_code":%s,"native_clippy_exit_code":%s,"native_test_exit_code":%s,"finished_at":"%s"}\n' "$validation_source" "$validation_status" "$validation_fmt" "$validation_clippy" "$validation_native" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > /workspace/pr2815-full-validation-exit.json.tmp
mv /workspace/pr2815-full-validation-exit.json.tmp /workspace/pr2815-full-validation-exit.json
