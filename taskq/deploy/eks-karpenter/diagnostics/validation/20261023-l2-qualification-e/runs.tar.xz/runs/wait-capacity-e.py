"""Read-only capacity watch; never changes other workloads or submits jobs."""
import datetime,json,pathlib,subprocess,time
p=pathlib.Path(__file__).parent/'qualification-e'
def call(args):return json.loads(subprocess.check_output(args,text=True,timeout=40))
types={};end=time.monotonic()+12*3600
while time.monotonic()<end:
 try:
  quota=call(['aws','service-quotas','get-service-quota','--region','us-east-2','--service-code','ec2','--quota-code','L-34B43A08'])['Quota']['Value']
  raw=call(['aws','ec2','describe-instances','--region','us-east-2','--filters','Name=instance-state-name,Values=pending,running','Name=instance-lifecycle,Values=spot'])
  rows=[x for r in raw['Reservations'] for x in r['Instances']]
  missing=sorted({x['InstanceType'] for x in rows}-types.keys())
  if missing:
   info=call(['aws','ec2','describe-instance-types','--region','us-east-2','--instance-types',*missing])
   types.update({x['InstanceType']:x['VCpuInfo']['DefaultVCpus'] for x in info['InstanceTypes']})
  # Counting every Spot family is deliberately conservative for Standard quota.
  used=sum(types[x['InstanceType']] for x in rows)
  d={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'quota':quota,'vcpus':used,'free':min(quota,96)-used,'needed':8,'instances':[{'id':x['InstanceId'],'type':x['InstanceType'],'state':x['State']['Name'],'vcpus':types[x['InstanceType']]} for x in rows]}
  (p/'capacity-current.json').write_text(json.dumps(d,indent=2)+'\n')
  with (p/'capacity-history.jsonl').open('a') as f:f.write(json.dumps(d)+'\n')
  print(d['at'],f"Spot {used:g}/{min(quota,96):g} vCPUs; free {d['free']:g}; need 8",flush=True)
  if d['free']>=8:
   (p/'capacity-ready.json').write_text(json.dumps(d,indent=2)+'\n');break
 except subprocess.SubprocessError as e:print('Capacity read failed:',e,flush=True)
 time.sleep(60)
else:raise SystemExit('Read-only capacity-watch deadline reached; nothing submitted')
