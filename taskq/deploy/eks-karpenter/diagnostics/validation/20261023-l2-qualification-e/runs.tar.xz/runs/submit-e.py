import copy,datetime,hashlib,json,pathlib,subprocess
base=pathlib.Path(__file__).parent;p=base/'qualification-e';k=['kubectl','--kubeconfig','/home/ec2-user/ops/eks-isolab/kubeconfig']
def call(args):return json.loads(subprocess.check_output(args,timeout=45))
def save(n,o):p.joinpath(n).write_text(json.dumps(o,indent=2)+'\n')
normal=call(k+['get','nodepool','cpu-spot','-o','json']);save('normal-pool-before.json',normal)
current=call(k+['get','ec2nodeclass','cpu','-o','json']);save('normal-class-before.json',current)
assert normal['spec']['limits']['cpu']=='64'
assert current['spec']==json.loads((base/'pre-trial-class.json').read_text())['spec'],'Live bootstrap changed; inspect before trial'
oldname='ecbench-periodic-tick-20261023-d';name='ecbench-periodic-tick-20261023-e'
old=(base/'qualification-d/job.json').read_text();job=json.loads(old.replace(oldname,name));save('job.json',job)
assert json.loads((p/'job.json').read_text().replace(name,oldname))==json.loads(old)
proto=json.loads((base/'qualification-d/protocol.json').read_text());proto.update({'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':name,'conditional_execution':'Probe C passed all 2000 samples. Submit only after read-only capacity watch observes at least 8 spare Standard Spot vCPUs; never pause or modify others\u2019 jobs.','previous_attempt':{'run':oldname,'outcome':'DeadlineExceeded before any container started; no timing samples or benchmark outcome','retained_at':'taskq/deploy/eks-karpenter/diagnostics/validation/20261023-l2-qualification-d'},'job_sha256':hashlib.sha256((p/'job.json').read_bytes()).hexdigest()});save('protocol.json',proto)
sha=hashlib.sha256((p/'protocol.json').read_bytes()).hexdigest()
r=call(['aws','s3api','put-object','--region','us-east-2','--bucket','isolab-results-104186811093-us-east-2','--key','recovery/validation/20261023-cpu-accounting/qualification-e-protocol-'+sha+'.json','--body',str(p/'protocol.json'),'--server-side-encryption','AES256']);save('protocol-upload.json',dict(r,sha256=sha))
# JSON Patch guards the exact snapshot before reserving only future capacity.
patch=[{'op':'test','path':'/metadata/resourceVersion','value':normal['metadata']['resourceVersion']},{'op':'test','path':'/spec/limits/cpu','value':'64'},{'op':'replace','path':'/spec/limits/cpu','value':'56'}]
save('normal-pool-cap-receipt.json',call(k+['patch','nodepool','cpu-spot','--type=json','-p',json.dumps(patch),'-o','json']))
cl=json.loads((base/'probe-c/nodeclass.json').read_text());save('nodeclass.json',cl)
pool=json.loads((base/'probe-c/nodepool.json').read_text())
for x in pool['spec']['template']['spec']['requirements']:
 if x['key']=='node.kubernetes.io/instance-type':x['values']=['c8a.2xlarge']
save('nodepool.json',pool)
save('nodeclass-created.json',call(k+['create','-f',str(p/'nodeclass.json'),'-o','json']))
save('nodepool-created.json',call(k+['create','-f',str(p/'nodepool.json'),'-o','json']))
save('submitted.json',call(k+['create','-f',str(p/'job.json'),'-o','json']))
print('Submitted',name,'with unchanged image, command, workload, resources and 0 retries')
