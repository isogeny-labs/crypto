import hashlib,json,pathlib,subprocess,zipfile
b=pathlib.Path(__file__).parent;r=pathlib.Path('/home/ec2-user/crypto-isolab-commit-images');head=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip();bucket='isolab-results-104186811093-us-east-2'
def aws(args):return json.loads(subprocess.check_output(['aws','--region','us-east-2',*args],text=True))
for kind,stackname,helper,prefix in [('remote','isolab-remote-launcher','bin/submit-job','launchers'),('recovery','isolab-recovery-controller','deploy/submit-job','recovery-controllers')]:
 d=b/(kind+'-v6-package');d.mkdir(exist_ok=False);stack=aws(['cloudformation','describe-stacks','--stack-name',stackname])['Stacks'][0];(d/'stack-before.json').write_text(json.dumps(stack,indent=2)+'\n');pars={x['ParameterKey']:x['ParameterValue'] for x in stack['Parameters']};assert stack['StackStatus']=='UPDATE_COMPLETE'
 meta=aws(['s3api','get-object','--bucket',bucket,'--key',pars['LauncherKey'],'--version-id',pars['LauncherVersion'],str(d/'before.zip')]);assert hashlib.sha256((d/'before.zip').read_bytes()).hexdigest()==pathlib.PurePosixPath(pars['LauncherKey']).stem
 with zipfile.ZipFile(d/'before.zip') as z:entries=z.infolist();payload={i.filename:z.read(i) for i in entries if not i.is_dir()}
 rows=[]
 for line in payload['SHA256SUMS'].decode().splitlines():
  digest,name=line.split(None,1);name=name.removeprefix('*');assert not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts;assert hashlib.sha256(payload[name]).hexdigest()==digest;rows.append(name)
 replacements={helper:r/'taskq/deploy/eks-karpenter/submit-job','bin/isolab-eks-mcp':r/'taskq/deploy/eks-karpenter/mcp/target/release/isolab-eks-mcp'}
 if kind=='remote':replacements['remote/check-ready']=r/'taskq/deploy/eks-karpenter/remote/check-ready'
 before={name:hashlib.sha256(x).hexdigest() for name,x in payload.items()}
 for name,source in replacements.items():assert name in rows;payload[name]=source.read_bytes()
 payload['SHA256SUMS']=(''.join(hashlib.sha256(payload[name]).hexdigest()+'  '+name+'\n' for name in rows)).encode()
 changed=[name for name,x in payload.items() if hashlib.sha256(x).hexdigest()!=before[name]];assert set(changed)==set(replacements)|{'SHA256SUMS'}
 with zipfile.ZipFile(d/'after.zip','w') as z:
  for i in entries:z.writestr(i,b'' if i.is_dir() else payload[i.filename])
 digest=hashlib.sha256((d/'after.zip').read_bytes()).hexdigest();key=f'inputs/{prefix}/{digest}.zip';up=aws(['s3api','put-object','--bucket',bucket,'--key',key,'--body',str(d/'after.zip'),'--server-side-encryption','AES256']);ver=up['VersionId'];back=aws(['s3api','get-object','--bucket',bucket,'--key',key,'--version-id',ver,str(d/'readback.zip')]);assert hashlib.sha256((d/'readback.zip').read_bytes()).hexdigest()==digest
 receipt={'bucket':bucket,'key':key,'version':ver,'sha256':digest,'source_revision':head,'changed_files':changed,'replacement_hashes':{name:hashlib.sha256(payload[name]).hexdigest() for name in replacements},'previous_key':pars['LauncherKey'],'previous_version':pars['LauncherVersion'],'upload':up,'readback':back,'readback_sha256_verified':True};(d/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');params=[{'ParameterKey':k,**({'ParameterValue':key if k=='LauncherKey' else ver} if k in ('LauncherKey','LauncherVersion') else {'UsePreviousValue':True})} for k in pars];(d/'parameters.json').write_text(json.dumps(params,indent=2)+'\n');print(kind,key,ver,flush=True)
