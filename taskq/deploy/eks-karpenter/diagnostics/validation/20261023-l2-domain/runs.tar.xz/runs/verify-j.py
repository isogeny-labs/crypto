"""Verify operational identities and native receipts; no benchmark recomputation."""
import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path('/home/ec2-user/ops/eks-isolab/l2-repair-20261023/qualification-j');a=p/'artifacts'
def rd(n):return json.loads((p/n).read_text())
proto=rd('protocol.json');pod=rd('pod-terminal.json');job=rd('job-terminal.json');submitted=rd('submitted.json');inst=rd('instance.json');node=rd('node.json');gate=rd('artifacts/l2-gate.json');audit=rd('artifacts/audit.json');control=rd('artifacts/control-comparison.json');build=rd('artifacts/build-info.json');exitdoc=rd('artifacts/job-exit.json')
assert pod['status']['phase']=='Succeeded' and exitdoc['exit_code']==0
assert job['metadata']['uid']==submitted['metadata']['uid'] and pod['metadata']['ownerReferences'][0]['uid']==job['metadata']['uid']
assert exitdoc['pod_uid']==pod['metadata']['uid'] and exitdoc['node_name']==node['metadata']['name']
assert pod['spec']['containers'][0]['image']==proto['image'] and pod['status']['containerStatuses'][0]['imageID']==proto['image']
assert build['source_revision']==proto['source_revision'] and build['ecbench_sha256']==proto['binary_sha256']
assert (a/'binary.sha256').read_text().split()[0]==proto['binary_sha256']
assert json.loads((a/'input-spec.json').read_text())==proto['spec']
assert gate['accepted'] and gate['executions']==3606 and not gate['below_l2'] and not gate['invalid_outcomes']
assert audit['ok'] and audit['regraded'] and audit['records_bound'] and audit['records']==audit['verified_records']==3606
assert len(audit['replays'])==3600 and all(x['reproduced'] for x in audit['replays'])
assert control['wall']['status']=='admitted' and control['wall']['aa_pairs']==1200 and control['wall']['pairs_below_level']==0 and control['wall']['aa_ci95'] is not None
assert inst['type']=='c8a.2xlarge' and inst['cpu']['ThreadsPerCore']==1
assert node['metadata']['labels']['isolab.dev/cpu-isolation']=='trial-benchmark-v6'
boot=(p/'boot-readback.txt').read_text();assert 'nohz_full=' not in boot and '(null)' in boot
assert 'isolcpus=domain,managed_irq,' in boot and 'cgroup_disable=pressure' in boot
for line in (a/'session/records.jsonl').open():
 r=json.loads(line)
 for phase in ('before','after'):
  assert r['isolation'][phase]['psi_cpu_some_avg10'] is not None and r['isolation'][phase]['psi_memory_some_avg10'] is not None
bt=rd('boot-readback-timing.json');duration=(datetime.datetime.fromisoformat(bt['read_completed_at'])-datetime.datetime.fromisoformat(bt['container_started_at'].replace('Z','+00:00'))).total_seconds();assert duration<60
manifest=(a/'SHA256SUMS').read_text().splitlines();assert len(manifest)==19
for line in manifest:
 digest,path=line.split(None,1);assert hashlib.sha256((a/path).read_bytes()).hexdigest()==digest
v={'schema':'isolab.l2-bootstrap-verification/v1','verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':proto['run'],'result':'passed','job_uid':job['metadata']['uid'],'pod_uid':pod['metadata']['uid'],'node':node['metadata']['name'],'instance':inst,'image':proto['image'],'source_revision':proto['source_revision'],'binary_sha256':proto['binary_sha256'],'grades':gate['grades'],'records':audit['records'],'matching_native_replays':len(audit['replays']),'aa':control['wall'],'s3_payload_hashes_verified':len(manifest),'results_uri':rd('s3-location.json')['uri'],'bootstrap':'periodic tick, scheduler-domain isolation, host PSI retained, watchdog/RCU housekeeping','measurement_retries':0,'protocol_erratum':'protocol-pair-count-erratum.json (two targets times 600 rounds gives 1200 A/A pairs)','scope':'Fresh measurement qualification; separate from CRIU restore and from the still-pending post-merge main GitHub Action'}
(p/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2))
