set -eu
D=/sys/kernel/tracing/instances/isolab-preemption-f
mkdir "$D"
trap 'echo 0 > "$D/tracing_on"; echo 0 > "$D/events/sched/sched_switch/enable"' EXIT
echo 0 > "$D/tracing_on"
echo 256 > "$D/buffer_size_kb"
echo 10 > "$D/tracing_cpumask"
echo '(prev_state == 0 || prev_state == 256) && prev_pid > 0' > "$D/events/sched/sched_switch/filter"
echo 1 > "$D/events/sched/sched_switch/enable"
echo 1 > "$D/tracing_on"
sleep 50
echo 0 > "$D/tracing_on"
cat "$D/trace"
for p in /proc/[0-9]*/comm; do
 read -r name < "$p" || continue
 case "$name" in rcu*) pid=${p%/comm}; pid=${pid##*/}; taskset -pc "$pid";; esac
done
