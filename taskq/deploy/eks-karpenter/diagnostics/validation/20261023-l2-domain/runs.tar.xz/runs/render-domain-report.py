"""Package existing native evidence; no benchmark calculations or regrading."""
import collections, hashlib, json, pathlib, shutil, subprocess
import pymupdf, typst

b = pathlib.Path(__file__).parent
repo = pathlib.Path('/home/ec2-user/crypto-isolab-commit-images')
r = repo/'taskq/deploy/eks-karpenter/diagnostics/validation/20261023-l2-domain'
r.mkdir(exist_ok=True)
v = json.loads((b/'qualification-j/verification.json').read_text())
deploy = json.loads((b/'promotion-v6/verification.json').read_text())
assert v['result'] == 'passed' and v['records'] == 3606 and v['aa']['aa_pairs'] == 1200
runs = r/'runs'; runs.mkdir(exist_ok=True)
for n in ['preemption-f','preemption-g','preemption-h','preemption-i','qualification-j','promotion-v6']:
    shutil.copytree(b/n, runs/n, dirs_exist_ok=True)
for n in ['remote-v6-package','recovery-v6-package']:
    (runs/n).mkdir(exist_ok=True)
    for f in (b/n).glob('*.json'): shutil.copy2(f, runs/n/f.name)
for n in ['prepare-i.py','watch-g.py','watch-h.py','watch-i.py','watch-j.py','verify-j.py','prepare-v6-packages.py','promote-v6.py']:
    shutil.copy2(b/n, runs/n)
for n in ['kernel-source']:
    shutil.copytree(b/n, runs/n, dirs_exist_ok=True)
shutil.copy2(__file__, runs/'render-domain-report.py')
shutil.copy2(b/'qualification-j/verification.json', r/'verification.json')
shutil.copy2(b/'promotion-v6/verification.json', r/'deployment.json')
hist = {}
for name in ['g','h','i']:
    p = runs/f'preemption-{name}'/'artifacts'
    subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=p,check=True,stdout=subprocess.DEVNULL)
    rows = [json.loads(x) for x in (p/'probe/records.jsonl').read_text().splitlines()]
    assert len(rows)==2000
    hist[name]=dict(sorted(collections.Counter(x['involuntary_switches'] for x in rows).items()))
subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=runs/'qualification-j/artifacts',check=True,stdout=subprocess.DEVNULL)
(r/'diagnostic-counts.json').write_text(json.dumps(hist,indent=2)+'\n')
subprocess.run(['tar','--sort=name','--mtime=@0','--owner=0','--group=0','--numeric-owner','-cJf',str(r/'runs.tar.xz'),'runs'],cwd=r,check=True)
assert (r/'runs.tar.xz').stat().st_size < 10*1024*1024
(r/'runs.tar.xz.sha256').write_text(hashlib.sha256((r/'runs.tar.xz').read_bytes()).hexdigest()+'  runs.tar.xz\n')
(r/'.gitignore').write_text('/runs/\n/report-*.png\n')
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="900" height="290" viewBox="0 0 900 290"><rect width="900" height="290" fill="white"/><g font-family="sans-serif" fill="#18354e"><text x="20" y="30" font-size="22">Scheduler diagnostics: children with more than one involuntary switch</text><text x="20" y="56" font-size="16">2,000 retained executions per run; diagnostic counts, not benchmark grades</text>']
for index,(name,label) in enumerate([('g','G: scheduler trace'),('h','H: workqueue trace'),('i','I: isolated domains')]):
    n=sum(count for k,count in hist[name].items() if k>1); y=90+index*50
    svg.append(f'<text x="20" y="{y+23}" font-size="18">{label}</text><rect x="250" y="{y}" width="{n*2.8}" height="30" fill="'+('#357450' if name=='i' else '#b04646')+f'"/><text x="{265+n*2.8}" y="{y+23}" font-size="18">{n}</text>')
svg.append('<text x="20" y="263" font-size="16">I retains 1,999 children with one switch and one with zero; initial placement is counted.</text></g></svg>')
(r/'diagnostics.svg').write_text(''.join(svg))
md=f'''# Dedicated benchmark workers: qualified L2 bootstrap

[Inspected PDF](report.pdf) · [native verification](verification.json) · [deployment](deployment.json) · [raw evidence](runs.tar.xz)

Qualification J passed the unchanged native gates: **3,606 verified L2 executions,
3,600 matching measured replays, 1,200 admitted A/A pairs and all 19 S3 payload
hashes verified**. The qualified bootstrap is deployed as profile v6 on the
dedicated `cpu-l2-spot` pool. Ordinary `cpu-spot` retains its previous v4 bootstrap.
The post-merge main-only GitHub Action is still pending final review and CI.

![Retained diagnostic switch counts](diagnostics.svg)

## Diagnosis and retained attempts

| Attempt | What actually ran | Outcome |
| --- | --- | --- |
| F | No Job or trace: the completed E worker had auto-consolidated | SSM InvalidInstanceId; protocol and failure retained |
| G | 2,000 native probe children, CPU4 scheduler trace | 162 children had more than one involuntary switch; no excess busy ticks above two |
| H | 2,000 children, scheduler/workqueue/timer trace | 183 children had more than one switch; no excess busy ticks above two |
| I | 2,000 children on a fresh candidate bootstrap, scheduler/workqueue trace | 0 children above one switch; 0 traced native-probe preemptions on CPU4; diagnostic only |
| J | Full untraced crypto qualification on I's worker | All native L2, replay, A/A and S3 gates passed |

Every G/H/I run retained all 2,000 samples and verified all six S3 payload hashes.
G's 30,663-byte complete trace attributed native child preemptions to kworker/4:1
(150), migration/4 (11) and ksoftirqd/4 (1). H's 199,693-byte trace retained all
1,293 entries with no buffer loss. Its workqueue events included psi_avgs_work
(183) and vmstat_update (61), plus less frequent filesystem/memory cleanup.
These event counts are not one-to-one causal attribution for every switch.
The initial RCU-only hypothesis did not explain the dominant observed work.

I's raw wait4 involuntary-switch histogram is zero: 1, one: 1,999. The probe pins
after exec, so its counters include the initial affinity transition; ecbench
pins in pre_exec. No zero-total-switch claim is made. I's complete five-entry
trace contains no native-probe preemptions; CNI switches and a check_lifetime
callback occur after the probe. Tracing overhead makes G/H/I diagnostic only.
J began after explicit readback confirmed all diagnostic tracing disabled.

## Qualified bootstrap and deployed contract

The candidate keeps periodic scheduler ticks, isolates worker scheduler domains
and managed IRQs, offloads RCU callbacks, and binds RCU threads and watchdogs to
housekeeping CPUs. `cgroup_disable=pressure` removes per-cgroup PSI work while
mandatory host `/proc/pressure/cpu` and `/proc/pressure/memory` remain enabled.
Every J record retains real before/after host pressure values. Existing strict
whole-core static CPU management, NUMA, IRQ/workqueue and service placement remain.
No native grader, threshold, correctness check or sample-admission rule changed.

Kernel sources explain why isolated domains avoid periodic vmstat shepherd work
and why per-cgroup PSI can schedule delayed work. Sources: [CPU isolation](https://docs.kernel.org/admin-guide/cpu-isolation.html),
[kernel threads](https://docs.kernel.org/admin-guide/kernel-per-CPU-kthreads.html),
[kernel parameters](https://www.kernel.org/doc/html/v6.13/admin-guide/kernel-parameters.html).
The inspected Linux v6.18 source files are retained in the evidence archive.

Domain isolation changes ordinary unaffined multithreaded scheduling, so L2 uses
its own tainted pool. `submit-job --isolation-profile l2` selects `cpu-l2-spot`,
profile v6 and its measurement toleration; standard jobs select only `cpu-spot`.
Both pools allow broad x86 C/M/R Spot families, generation six or newer, subject
to existing requirements and capacity. Each is capped at 32 vCPUs / 128 GiB:
combined limits remain 64 vCPUs / 256 GiB under the regional 96-vCPU quota.
Each node must fit its individual pool limit. Capacity is not guaranteed.

Deployment source: `{deploy['source_revision']}`. The production cpu-l2 class
spec equals the qualified I/J spec; the ordinary cpu class equals the prior v4
spec. Both classes/pools were read back Ready with current generations as the
`isolab:submitters` group. Both remote launchers were updated through CloudFormation
and verified against immutable S3 versions and full archive hashes. Runtime
checkpoint/archive pins did not change. The temporary diagnostic resources and
this task's unchanged temporary cluster-admin association were removed; other
tasks' jobs and workers were not paused, cancelled or resized.

| Launcher | Immutable S3 package version |
| --- | --- |
| Ordinary remote launcher | `{deploy['launchers']['remote']['version']}` |
| Recovery controller | `{deploy['launchers']['recovery']['version']}` |

## Full native qualification J

Public 32-bit prime_search seed 59297; two targets with target seed 20261002;
rho.negation reference, rho.plain baseline and rho.negation A/A control. Exactly
600 rounds, one warmup, alternating order, seed 1 and 120-second child timeout.
Four exclusive CPUs, 4 GiB, 1,800 seconds including provisioning, fixed 60-second
setup and zero retries. Boot readback completed during setup; no diagnostic
exec ran during measurement. The worker was c8a.2xlarge, eight cores, one thread
per core, AL2023 AMI ami-082b570a48503ea93, kernel 6.18.54, us-east-2c.

| Gate | Native outcome |
| --- | --- |
| Correctness and isolation | 3,606 / 3,606 verified and L2 |
| Measured replay | 3,600 / 3,600 matched |
| A/A | 1,200 pairs admitted, zero below L2, outside_noise=false |
| A/A median ratio | {v['aa']['aa_median_ratio']} |
| Native A/A 95% interval | [{v['aa']['aa_ci95'][0]}, {v['aa']['aa_ci95'][1]}] |
| S3 | 19 / 19 full payload hashes matched |

- Job: `{v['run']}` / `{v['job_uid']}`.
- Pod UID: `{v['pod_uid']}`.
- Worker: `{v['instance']['id']}`; node `{v['node']}`.
- Crypto source: `{v['source_revision']}`.
- Actual image: `{v['image']}`.
- Binary SHA-256: `{v['binary_sha256']}`.
- Results: `{v['results_uri']}`.

## Corrections, limits and reproduction

The frozen workload always used two targets and 600 rounds, producing 1,200 A/A
pairs. The protocol prose and operational verifier initially expected 600 pairs;
the original, exact-count correction and verifier are retained. No workload,
threshold or sample changed. The first verifier invocation also retained an old
D directory path and failed before reading evidence; that observer mistake is
explicitly recorded. Native results were neither retried nor regraded.

G/H's initial SSM stdout hit its 24,000-byte limit. Complete traces were then
retrieved as compressed data (H in two chunks) and checked against recorded
compressed/plain hashes. Partial originals remain labeled and retained. The
local MCP deployment initially hit ETXTBSY when replacing a running executable;
atomic rename installed the verified binary without killing a running client.

This qualifies one fresh crypto workload/bootstrap combination. It does not prove
all instance families, arbitrary CRIU portability, a new CRIU restore under v6,
an algorithm speedup or completion of the main GitHub Action. Prior [D provisioning](../20261023-l2-qualification-d/REPORT.md)
and [E preemption](../20261023-l2-qualification-e/REPORT.md) failures remain frozen.
Earlier recovery evidence remains separate; interrupted timing is never admitted.

Run `sha256sum -c runs.tar.xz.sha256 && tar -xJf runs.tar.xz`. The archive retains
all F/G/H/I/J protocols, raw native artifacts, full traces, manifests, instance and
Job/Pod receipts, corrections, bootstrap, source observations and deployment
receipts. Run `sha256sum -c SHA256SUMS` inside each run's artifacts directory to
verify its complete payload set. Package binaries remain in immutable S3 objects
identified by receipt; private checkpoint memory and credentials are not included.
The graph derives counts from retained native rusage records and uses a common
linear count scale; it computes no new timing statistic. Algorithm leaderboards
and curve graphics were checked for scope and left unchanged. This evidence
directory is frozen; later validation gets its own report.
'''
(r/'REPORT.md').write_text(md)
# Render the complete prose/table content in a compact, inspectable PDF.
import re
lines=[]; table=[]
def quoted(s):
    return json.dumps(s.replace('**','').replace('`',''), ensure_ascii=False)
def flush_table():
    if not table: return
    rows=[x for x in table if not all(re.fullmatch(r'[-: ]+',c) for c in x)]
    cells=',\n'.join('[#text('+quoted(c)+')]' for row in rows for c in row)
    lines.append('#block(breakable: false)[#table(columns: '+str(len(rows[0]))+', inset: 5pt, stroke: 0.4pt + rgb("#ccd5df"),\n'+cells+')]\n')
    table.clear()
for line in md.splitlines():
    if line.startswith('|'):
        table.append([x.strip() for x in line.strip('|').split('|')]);continue
    flush_table()
    if line.startswith('!['): lines.append('#image("diagnostics.svg", width: 100%)');continue
    line=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'\1 (\2)',line)
    if line.startswith('#'): line='='*len(line.split(' ')[0])+line[len(line.split(' ')[0]):]
    elif line.startswith('- '): line='- #text('+quoted(line[2:])+')'
    elif line: line='#text('+quoted(line)+')'
    lines.append(line)
flush_table()
source='#set page(paper: "a4", margin: 16mm)\n#set text(size: 9pt)\n#set par(leading: 0.45em)\n'+'\n'.join(lines)
(r/'report.typ').write_text(source)
typst.compile(str(r/'report.typ'),output=str(r/'report.pdf'))
pdf=pymupdf.open(r/'report.pdf')
for i,page in enumerate(pdf): page.get_pixmap(dpi=110).save(r/f'report-{i+1}.png')
print('Rendered',len(pdf),'pages;', (r/'runs.tar.xz').stat().st_size,'archive bytes; inspection pending.')
