import json,pathlib,subprocess,datetime,hashlib,yaml
b=pathlib.Path(__file__).parent;p=b/'preemption-i';p.mkdir();repo=pathlib.Path('/home/ec2-user/crypto-isolab-commit-images')
cl=list(yaml.safe_load_all((repo/'taskq/deploy/eks-karpenter/nodepool.yaml').read_text()))[0];cl['metadata']['name']='cpu-accounting-tick'
s=cl['spec']['userData'];s=s.replace('isolcpus=managed_irq,$worker_list','isolcpus=domain,managed_irq,$worker_list').replace('irqaffinity=$housekeeping"','irqaffinity=$housekeeping cgroup_disable=pressure"')
s=s.replace('# Keep scheduler load balancing within each pod\'s exclusive cpuset;\n# isolcpus=domain would serialize unpinned multithreaded jobs.','# Dedicated benchmark workers use explicit native per-child affinity.\n# General multithreaded jobs continue to use the separate ordinary pool.')
extra='''# Full dynticks normally excludes worker CPUs from soft-lockup watchdogs.
# With periodic ticks, explicitly keep that monitoring on housekeeping.
printf '%s\\n' "$housekeeping" > /proc/sys/kernel/watchdog_cpumask
# rcu_nocbs offloads callbacks but does not bind their kernel threads.
for comm_path in /proc/[0-9]*/comm; do
  read -r thread_name < "$comm_path" || continue
  case "$thread_name" in
    rcu*)
      thread_pid=${comm_path%/comm}; thread_pid=${thread_pid##*/}
      taskset -pc "$housekeeping" "$thread_pid"
      ;;
  esac
done
# The native preflight still requires actual host CPU and memory pressure.
for resource in cpu memory; do
  test -r "/proc/pressure/$resource"
  grep -q '^some ' "/proc/pressure/$resource"
done
'''
s=s.replace('touch /run/isolab-cpu-isolation-ready',extra+'touch /run/isolab-cpu-isolation-ready');cl['spec']['userData']=s
(p/'nodeclass.json').write_text(json.dumps(cl,indent=2)+'\n');(p/'bootstrap.sh').write_text(s);subprocess.run(['bash','-n',str(p/'bootstrap.sh')],check=True)
j=json.loads((b/'preemption-g/job.json').read_text().replace('cpu-preemption-20261023-g','cpu-preemption-20261023-i'));j['spec']['template']['spec']['nodeSelector']['isolab.dev/cpu-isolation']='trial-benchmark-v6';(p/'job.json').write_text(json.dumps(j,indent=2)+'\n')
pr={'schema':'isolab.scheduler-preemption-diagnostic/v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':'cpu-preemption-20261023-i','purpose':'Test dedicated benchmark bootstrap against identified PSI, vmstat, watchdog and RCU interference; no L2 or speed claim','worker':'Fresh c8a.2xlarge in reserved 8-vCPU diagnostic pool','image':j['spec']['template']['spec']['containers'][0]['image'],'samples':2000,'cpu':4,'memory':'4Gi','setup_sleep_seconds':60,'trace_seconds':120,'trace':'CPU4 runnable-prev sched_switch plus workqueue_execute_start only; preserve complete bounded trace and all native records','changes':['scheduler domain isolation (ordinary pool remains unchanged)','per-cgroup PSI disabled, mandatory host /proc/pressure CPU+memory remains active','watchdog cpumask and offloaded RCU threads on housekeeping','periodic tick retained; all existing CPU/IRQ/workqueue/RCU and native gates retained'],'retries':0,'job_sha256':hashlib.sha256((p/'job.json').read_bytes()).hexdigest(),'class_sha256':hashlib.sha256((p/'nodeclass.json').read_bytes()).hexdigest(),'conditional_next':'Full unchanged 600-round crypto qualification only after this diagnostic has no excess busy ticks >2, all 2000 samples retained and preemption sources removed; otherwise investigate without a benchmark retry.'}
(p/'protocol.json').write_text(json.dumps(pr,indent=2)+'\n')
k=['kubectl','--kubeconfig','/home/ec2-user/ops/eks-isolab/kubeconfig'];aws=['aws','--region','us-east-2'];claims=json.loads(subprocess.check_output(k+['get','nodeclaims','-l','karpenter.sh/nodepool=cpu-accounting-tick','-o','json']));assert len(claims['items'])==1;claim=claims['items'][0];assert claim['status']['providerID'].endswith('/i-05dfbefca6abf3e23');node=claim['status']['nodeName'];pods=json.loads(subprocess.check_output(k+['get','pods','-A','--field-selector','spec.nodeName='+node,'-o','json']));(p/'pods-before-retire.json').write_text(json.dumps(pods,indent=2)+'\n');assert all(x['status']['phase'] in ('Succeeded','Failed') or x['metadata'].get('ownerReferences',[{}])[0].get('kind')=='DaemonSet' for x in pods['items'])
u=subprocess.check_output(aws+['s3api','put-object','--bucket','isolab-results-104186811093-us-east-2','--key','recovery/validation/20261023-cpu-accounting/preemption-i-protocol.json','--body',str(p/'protocol.json'),'--server-side-encryption','AES256']);(p/'protocol-upload.json').write_bytes(u)
cur=json.loads(subprocess.check_output(k+['get','ec2nodeclass','cpu-accounting-tick','-o','json']));assert {k:v for k,v in cur['spec'].items() if k!='userData'}=={k:v for k,v in cl['spec'].items() if k!='userData'}
patch=[{'op':'test','path':'/metadata/resourceVersion','value':cur['metadata']['resourceVersion']},{'op':'replace','path':'/spec/userData','value':s}];r=subprocess.check_output(k+['patch','ec2nodeclass','cpu-accounting-tick','--type=json','-p',json.dumps(patch),'-o','json']);(p/'class-updated.json').write_bytes(r)
patch=[{'op':'test','path':'/spec/template/metadata/labels/isolab.dev~1cpu-isolation','value':'trial-periodic-tick'},{'op':'replace','path':'/spec/template/metadata/labels/isolab.dev~1cpu-isolation','value':'trial-benchmark-v6'}];r=subprocess.check_output(k+['patch','nodepool','cpu-accounting-tick','--type=json','-p',json.dumps(patch),'-o','json']);(p/'pool-updated.json').write_bytes(r)
# Retire only this task's completed diagnostic worker, with UID precondition.
opts={'apiVersion':'v1','kind':'DeleteOptions','preconditions':{'uid':claim['metadata']['uid']}};(p/'retire-options.json').write_text(json.dumps(opts))
r=subprocess.check_output(k+['delete','--raw','/apis/karpenter.sh/v1/nodeclaims/'+claim['metadata']['name'],'-f',str(p/'retire-options.json')]);(p/'claim-retired.json').write_bytes(r)
r=subprocess.check_output(k+['create','-f',str(p/'job.json'),'-o','json']);(p/'submitted.json').write_bytes(r);print('Candidate I submitted; only completed own worker retired; normal workers untouched')
