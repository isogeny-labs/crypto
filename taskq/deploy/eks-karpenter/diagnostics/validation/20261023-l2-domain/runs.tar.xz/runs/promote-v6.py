"""Guarded promotion of an exactly qualified bootstrap; preserves other workloads."""
import json,pathlib,subprocess,time,shutil,hashlib,yaml
b=pathlib.Path(__file__).parent;r=pathlib.Path('/home/ec2-user/crypto-isolab-commit-images');p=b/'promotion-v6';p.mkdir(exist_ok=False)
k=['kubectl','--kubeconfig','/home/ec2-user/ops/eks-isolab/kubeconfig'];aws=['aws','--region','us-east-2']
def call(args):return json.loads(subprocess.check_output(args,timeout=60))
def save(name,data):p.joinpath(name).write_text(json.dumps(data,indent=2)+'\n')
v=json.loads((b/'qualification-j/verification.json').read_text());assert v['result']=='passed' and v['records']==3606 and v['s3_payload_hashes_verified']==19
specs=list(yaml.safe_load_all((r/'taskq/deploy/eks-karpenter/nodepool.yaml').read_text()));classes={x['metadata']['name']:x for x in specs if x['kind']=='EC2NodeClass'};pools={x['metadata']['name']:x for x in specs if x['kind']=='NodePool'}
assert classes['cpu-l2']['spec']==json.loads((b/'preemption-i/nodeclass.json').read_text())['spec']
normal=call(k+['get','nodepool','cpu-spot','-o','json']);cl=call(k+['get','ec2nodeclass','cpu','-o','json']);save('normal-pool-before.json',normal);save('normal-class-before.json',cl)
assert normal['spec']==json.loads((b/'qualification-e/normal-pool-cap-receipt.json').read_text())['spec'];assert cl['spec']==classes['cpu']['spec']
claims=call(k+['get','nodeclaims','-l','karpenter.sh/nodepool=cpu-accounting-tick','-o','json']);save('trial-claims-before.json',claims);assert len(claims['items'])==1;claim=claims['items'][0];assert claim['status']['providerID'].endswith('/'+v['instance']['id']);pods=call(k+['get','pods','-A','--field-selector','spec.nodeName='+claim['status']['nodeName'],'-o','json']);save('trial-pods-before.json',pods)
assert all(x['status']['phase'] in ('Succeeded','Failed') or x['metadata'].get('ownerReferences',[{}])[0].get('kind')=='DaemonSet' for x in pods['items'])
def remove(resource,obj):
 name=obj['metadata']['name'];f=p/(resource+'-delete-options.json');f.write_text(json.dumps({'apiVersion':'v1','kind':'DeleteOptions','preconditions':{'uid':obj['metadata']['uid']}}));save(resource+'-delete-response.json',call(k+['delete','--raw',f'/apis/{"karpenter.k8s.aws" if resource=="ec2nodeclasses" else "karpenter.sh"}/v1/{resource}/{name}','-f',str(f)]))
remove('nodeclaims',claim)
for _ in range(30):
 claims=call(k+['get','nodeclaims','-l','karpenter.sh/nodepool=cpu-accounting-tick','-o','json'])
 if not claims['items']:break
 time.sleep(2)
else:raise RuntimeError('Own trial claim still terminating; no new pool promoted')
for resource in ('nodepools','ec2nodeclasses'):
 obj=call(k+['get',resource,'cpu-accounting-tick','-o','json']);save(resource+'-before-delete.json',obj);remove(resource,obj)
# Lower ordinary pool cap before adding the benchmark cap; never sum above 64.
patch=[{'op':'test','path':'/spec/limits/cpu','value':'56'},{'op':'test','path':'/spec/limits/memory','value':'256Gi'},{'op':'replace','path':'/spec/limits','value':pools['cpu-spot']['spec']['limits']}]
save('normal-pool-cap-update.json',call(k+['patch','nodepool','cpu-spot','--type=json','-p',json.dumps(patch),'-o','json']))
log=subprocess.check_output(k+['apply','-f',str(r/'taskq/deploy/eks-karpenter/nodepool.yaml'),'-f',str(r/'taskq/deploy/eks-karpenter/remote/readiness-rbac.yaml')],text=True);(p/'apply.log').write_text(log);print(log,flush=True)
for kind in ('remote','recovery'):
 d=b/(kind+'-v6-package');receipt=json.loads((d/'receipt.json').read_text());before=json.loads((d/'stack-before.json').read_text());stack=call(aws+['cloudformation','describe-stacks','--stack-name',before['StackName']])['Stacks'][0];pars={x['ParameterKey']:x['ParameterValue'] for x in stack['Parameters']};assert stack['StackStatus']=='UPDATE_COMPLETE' and pars['LauncherKey']==receipt['previous_key'] and pars['LauncherVersion']==receipt['previous_version']
 save(kind+'-update-request.json',call(aws+['cloudformation','update-stack','--stack-name',stack['StackName'],'--use-previous-template','--parameters','file://'+str(d/'parameters.json'),'--capabilities','CAPABILITY_NAMED_IAM']));print(kind,'versioned package deployment requested',flush=True)
local=pathlib.Path('/home/ec2-user/ops/eks-isolab/mcp');replacements={'submit-job':r/'taskq/deploy/eks-karpenter/submit-job','isolab-eks-mcp':r/'taskq/deploy/eks-karpenter/mcp/target/release/isolab-eks-mcp'}
for name,src in replacements.items():
 shutil.copy2(local/name,p/('local-before-'+name));shutil.copy2(src,local/name)
save('local-install.json',{'source_revision':subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip(),'files':{name:hashlib.sha256((local/name).read_bytes()).hexdigest() for name in replacements}})
print('Both source pools and local client promoted; CloudFormation completion verification remains',flush=True)
