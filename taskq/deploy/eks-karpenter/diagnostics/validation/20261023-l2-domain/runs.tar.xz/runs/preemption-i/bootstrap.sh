#!/bin/bash
# Karpenter wraps this in AL2023 multipart user data. nodeadm-run reads
# the dynamic drop-in after cloud-init; never invoke nodeadm init here.
set -euo pipefail
mkdir -p /etc/isolab /etc/eks/nodeadm.d /etc/systemd/system/kubelet.service.d
cat > /etc/systemd/system/kubelet.service.d/50-isolab.conf <<'UNIT'
[Unit]
Requires=isolab-cpu-isolation.service
After=isolab-cpu-isolation.service
[Service]
ExecStartPre=/usr/bin/test -f /run/isolab-cpu-isolation-ready
UNIT
# Reserve CPU 0's entire physical core, discovered rather than assuming
# that adjacent logical CPU numbers are SMT siblings.
housekeeping=$(cat /sys/devices/system/cpu/cpu0/topology/thread_siblings_list)
[[ "$housekeeping" =~ ^[0-9,-]+$ ]]
cat > /etc/eks/nodeadm.d/50-isolab.yaml <<EOF
apiVersion: node.eks.aws/v1alpha1
kind: NodeConfig
spec:
  kubelet:
    config:
      reservedSystemCPUs: "$housekeeping"
      # AL2023 sets a kubeReservedCgroup by default; Kubernetes forbids
      # combining either reserved cgroup path with reservedSystemCPUs.
      kubeReservedCgroup: ""
      systemReservedCgroup: ""
      enforceNodeAllocatable: [pods]
      cpuManagerPolicy: static
      cpuManagerPolicyOptions:
        full-pcpus-only: "true"
        strict-cpu-reservation: "true"
      topologyManagerPolicy: single-numa-node
EOF
house_mask=0
worker_list=''
for path in /sys/devices/system/cpu/cpu[0-9]*; do
  cpu=${path##*cpu}
  siblings=$(cat "$path/topology/thread_siblings_list")
  if [[ "$siblings" == "$housekeeping" ]]; then
    house_mask=$((house_mask | (1 << cpu)))
  else
    worker_list+="${worker_list:+,}$cpu"
  fi
done
# Pool members have at most 32 vCPUs; one hexadecimal mask suffices.
printf -v house_hex '%x' "$house_mask"
mkdir -p /etc/systemd/system/irqbalance.service.d
printf '[Service]\nEnvironment="IRQBALANCE_BANNED_CPULIST=%s"\n' "$worker_list" \
  > /etc/systemd/system/irqbalance.service.d/50-isolab.conf
# Dedicated benchmark workers use explicit native per-child affinity.
# General multithreaded jobs continue to use the separate ordinary pool.
# Keep the periodic tick on running CPUs. On this AL2023 kernel, the
# full-dynticks probe reported 50ms of busy time in a 25ms wall window;
# removing nohz_full eliminated that anomaly without changing L2 gates.
# IRQ, RCU and workqueue housekeeping remain isolated as before.
kernel_args="isolcpus=domain,managed_irq,$worker_list rcu_nocbs=$worker_list irqaffinity=$housekeeping cgroup_disable=pressure"
printf 'housekeeping=%q\nhouse_hex=%q\nkernel_args=%q\n' "$housekeeping" "$house_hex" "$kernel_args" \
  > /etc/isolab/cpus.env
cat > /usr/local/sbin/isolab-cpu-isolation <<'SCRIPT'
#!/bin/bash
set -euo pipefail
source /etc/isolab/cpus.env
: "${kernel_args:?}" "${housekeeping:?}" "${house_hex:?}"
# Fail before admitting pods if the kernel was not booted as configured.
cmdline=" $(cat /proc/cmdline) "
for arg in $kernel_args; do
  [[ "$cmdline" == *" $arg "* ]] || exit 1
done
# Reject workers with full dynticks still active, including an AMI default
# that would not be detected by checking our requested arguments alone.
if [[ -e /sys/devices/system/cpu/nohz_full ]]; then
  nohz_full=$(cat /sys/devices/system/cpu/nohz_full)
  nohz_full=${nohz_full//[[:space:]]/}
  [[ -z "$nohz_full" || "$nohz_full" == '(null)' ]] || exit 1
fi
# kubepods.slice is a sibling, not a descendant. Cgroup restrictions do
# not leak an inherited task affinity into workload processes.
systemctl set-property system.slice AllowedCPUs="$housekeeping"
# AL2023 puts kubelet and containerd in runtime.slice, outside system.slice.
systemctl set-property runtime.slice AllowedCPUs="$housekeeping"
systemctl set-property user.slice AllowedCPUs="$housekeeping"
systemctl set-property init.scope AllowedCPUs="$housekeeping"
printf '%s\n' "$house_hex" > /proc/irq/default_smp_affinity
for irq in /proc/irq/*/smp_affinity_list; do
  # Managed/per-CPU IRQs can refuse affinity changes. Record them;
  # ecbench must still pass its per-execution noise audit.
  if ! printf '%s\n' "$housekeeping" > "$irq" 2>/dev/null; then
    printf 'Immutable IRQ affinity: %s\n' "$irq"
  fi
done
printf '%s\n' "$house_hex" > /sys/devices/virtual/workqueue/cpumask
printf '%s\n' "$housekeeping" > /etc/isolab/housekeeping-cpus
# Full dynticks normally excludes worker CPUs from soft-lockup watchdogs.
# With periodic ticks, explicitly keep that monitoring on housekeeping.
printf '%s\n' "$housekeeping" > /proc/sys/kernel/watchdog_cpumask
# rcu_nocbs offloads callbacks but does not bind their kernel threads.
for comm_path in /proc/[0-9]*/comm; do
  read -r thread_name < "$comm_path" || continue
  case "$thread_name" in
    rcu*)
      thread_pid=${comm_path%/comm}; thread_pid=${thread_pid##*/}
      taskset -pc "$housekeeping" "$thread_pid"
      ;;
  esac
done
# The native preflight still requires actual host CPU and memory pressure.
for resource in cpu memory; do
  test -r "/proc/pressure/$resource"
  grep -q '^some ' "/proc/pressure/$resource"
done
touch /run/isolab-cpu-isolation-ready
SCRIPT
chmod 755 /usr/local/sbin/isolab-cpu-isolation
cat > /etc/systemd/system/isolab-cpu-isolation.service <<'UNIT'
[Unit]
Description=Iso Lab kernel and CPU housekeeping isolation
Before=kubelet.service
After=irqbalance.service
Wants=irqbalance.service
[Service]
Type=oneshot
ExecStart=/usr/local/sbin/isolab-cpu-isolation
RemainAfterExit=yes
UNIT
systemctl daemon-reload
# A newly launched worker reboots once before kubelet can admit a pod.
# Persistent service reapplies IRQ/workqueue placement on every reboot.
grubby --update-kernel=ALL --remove-args=nohz_full --args="$kernel_args"
systemctl --no-block reboot
