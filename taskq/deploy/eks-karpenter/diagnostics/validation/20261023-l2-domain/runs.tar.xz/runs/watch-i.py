"""Capture one frozen attempt. No retries, submissions, or timing changes."""
import datetime,json,pathlib,subprocess,time
p=pathlib.Path(__file__).parent/'preemption-i'
k=['kubectl','--kubeconfig','/home/ec2-user/ops/eks-isolab/kubeconfig'];job='cpu-preemption-20261023-i'
def now():return datetime.datetime.now(datetime.timezone.utc)
def call(args,timeout=40):return subprocess.check_output(args,timeout=timeout,text=True)
def save(n,d):p.joinpath(n).write_text(json.dumps(d,indent=2)+'\n')
seen=False;prior=None;lastpod=None;end=time.monotonic()+1950
while time.monotonic()<end:
 try:
  jobdoc=json.loads(call(k+['-n','isolab','get','job',job,'-o','json']));save('job-current.json',jobdoc)
  pods=json.loads(call(k+['-n','isolab','get','pods','-l','job-name='+job,'-o','json']));save('pods-current.json',pods)
  assert len(pods['items'])<=1,'Unexpected extra attempt'
  if pods['items']:
   pod=pods['items'][0];lastpod=pod;save('pod-last-observed.json',pod)
   phase=pod['status']['phase']
   if phase!=prior:print(now().isoformat(),phase,flush=True);prior=phase
   cs=pod['status'].get('containerStatuses',[]);node=pod['spec'].get('nodeName')
   if node and not seen and cs and cs[0].get('state',{}).get('running'):
    seen=True;save('pod-started.json',pod)
    stamp=cs[0]['state']['running']['startedAt'];age=(now()-datetime.datetime.fromisoformat(stamp.replace('Z','+00:00'))).total_seconds()
    if age<40:
     # Complete this read within the fixed 60-second pre-measurement sleep.
     txt=call(k+['-n','isolab','exec',pod['metadata']['name'],'--','/bin/bash','-c','for p in /proc/cmdline /sys/devices/system/cpu/nohz_full /sys/devices/virtual/workqueue/cpumask; do printf "%s\\n" "$p"; cat "$p"; done'],timeout=15)
     p.joinpath('boot-readback.txt').write_text(txt)
     save('boot-readback-timing.json',{'container_started_at':stamp,'read_started_age_seconds':age,'read_completed_at':now().isoformat(),'measurement_setup_sleep_seconds':60})
    else:
     save('boot-readback-missed.json',{'at':now().isoformat(),'age':age,'reason':'No exec permitted after setup window'})
    nj=json.loads(call(k+['get','node',node,'-o','json']));save('node.json',nj)
    iid=nj['spec']['providerID'].split('/')[-1]
    inst=json.loads(call(['aws','ec2','describe-instances','--region','us-east-2','--instance-ids',iid,'--query','Reservations[0].Instances[0].{id:InstanceId,type:InstanceType,state:State.Name,launch:LaunchTime,cpu:CpuOptions,image:ImageId,zone:Placement.AvailabilityZone}']));save('instance.json',inst)
    command=(p.parent/'preemption-f/trace-command.sh').read_text().replace('isolab-preemption-f','isolab-preemption-i').replace('echo 1 > "$D/tracing_on"', 'echo 1 > "$D/events/workqueue/workqueue_execute_start/enable"\necho 1 > "$D/tracing_on"').replace('sleep 50','sleep 120')
    (p/'trace-command.sh').write_text(command)
    trace=json.loads(call(['aws','ssm','send-command','--region','us-east-2','--instance-ids',iid,'--document-name','AWS-RunShellScript','--parameters',json.dumps({'commands':[command],'executionTimeout':['180']}),'--comment','Bounded CPU4 scheduler trace on isolated diagnostic worker']))
    save('trace-submitted.json',trace)
    print('Captured startup and worker; scheduler trace started',trace['Command']['CommandId'],flush=True)
   if phase in ('Succeeded','Failed'):save('pod-terminal.json',pod)
  done=any(c['status']=='True' and c['type'] in ('Complete','Failed') for c in jobdoc['status'].get('conditions',[]))
  if done:
   save('job-terminal.json',jobdoc);save('pods-terminal.json',pods)
   save('events-terminal.json',json.loads(call(k+['-n','isolab','get','events','--field-selector','involvedObject.uid='+jobdoc['metadata']['uid'],'-o','json'])))
   if lastpod:
    save('pod-events-terminal.json',json.loads(call(k+['-n','isolab','get','events','--field-selector','involvedObject.uid='+lastpod['metadata']['uid'],'-o','json'])))
   prefix='runs/'+job+'/'
   listing=json.loads(call(['aws','s3api','list-objects-v2','--region','us-east-2','--bucket','isolab-results-104186811093-us-east-2','--prefix',prefix]));save('s3-objects-terminal.json',listing)
   if lastpod and len(listing.get('Contents',[])):
    uid=lastpod['metadata']['uid'];uri=f's3://isolab-results-104186811093-us-east-2/{prefix}{uid}/'
    save('s3-location.json',{'uri':uri,'pod_uid':uid})
    subprocess.run(['aws','s3','cp',uri,str(p/'artifacts')+'/', '--recursive','--only-show-errors','--region','us-east-2'],check=True,timeout=180)
    with (p/'hash-check.txt').open('w') as f:subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=p/'artifacts',stdout=f,check=True,timeout=60)
   save('observation-outcome.json',{'at':now().isoformat(),'job_terminal':True,'container_running_observed':seen,'last_observed_pod_phase':lastpod['status']['phase'] if lastpod else None,'s3_objects':len(listing.get('Contents',[])),'resubmissions':0})
   print('Terminal Job and available evidence preserved',flush=True);break
 except subprocess.SubprocessError as e:print('Read/capture error:',e,flush=True)
 time.sleep(15)
else:raise SystemExit('Observation deadline reached; no resubmission')
