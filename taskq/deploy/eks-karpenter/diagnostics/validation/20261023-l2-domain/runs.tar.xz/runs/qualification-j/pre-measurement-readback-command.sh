set -eu
for d in /sys/kernel/tracing/instances/isolab-*; do
 test -d "$d" || continue
 echo 0 > "$d/tracing_on"
 echo 0 > "$d/events/enable"
 printf 'trace-off %s ' "$d"; cat "$d/tracing_on"
done
for f in /proc/cmdline /proc/sys/kernel/watchdog_cpumask /sys/devices/system/cpu/isolated /sys/devices/system/cpu/nohz_full /proc/pressure/cpu /proc/pressure/memory; do printf '%s\n' "$f"; cat "$f"; done
if test -e /sys/fs/cgroup/cpu.pressure; then echo unexpected-cgroup-psi; exit 1; fi
for p in /proc/[0-9]*/comm; do read -r name < "$p" || continue; case "$name" in rcu*) pid=${p%/comm}; pid=${pid##*/}; taskset -pc "$pid";; esac; done
