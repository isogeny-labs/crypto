# Automatic recovery qualification attempts

Attempt A failed in controller bootstrap before any ConfigMap, PVC or Pod was
created. The native atomic writer tried to open an empty parent path for a
relative registry filename. Both automatic CodeBuild retries retained the same
failure. No crypto computations or benchmark epochs ran. The exact original
protocol and failure log remain beside this note. A regression test now covers
relative-path atomic replacement and directory synchronization.

Attempt B was stopped before a workload Pod existed: its prelaunch protocol
captured the prior controller package while CloudFormation was finishing an
update. StartBuild reported the new package. This provenance mismatch invalidated
B before any induced failure or benchmark. The next attempt waits for deployment
completion and binds the observed package/version before submitting.
The B stop raced provisioning: a pending Pod was created before CodeBuild reached
STOPPED. Its durable state still said provisioning, with no benchmark and no
start command. The state was fenced as failed with the cancellation reason using
resourceVersion, the Pod/PVC removed, and the cancellation receipt saved to S3.
No computation was started. The stopped build cannot resume this terminal run.
C completed successfully through the automatic controller: computation archive
read back, native replay verified, distinct fresh L2 epoch and all S3 payload
hashes verified. It contains zero restored attempts and proves no failure recovery.
D's StartBuild was definitively rejected by the project's single-controller
concurrency limit while C was running; it created no build or workload. Its frozen
request remains evidence; a final test will use the completed current deployment.
