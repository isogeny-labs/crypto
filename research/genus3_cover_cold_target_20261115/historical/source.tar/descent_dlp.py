"""Explicit norm-conorm descent and factor-base DLP on the smaller field.

Run python descent_dlp.py. Requires numpy and sympy.
Polynomial lists contain coefficients in ascending order; [] is zero.
"""
import json
from pathlib import Path

import numpy as np

from smaller_field_descent import main, eval_base


class Polynomials:
    def __init__(self, k):
        self.k = k
        self.one = [k.one]

    def trim(self, a):
        a = list(a)
        while a and a[-1] == self.k.zero:
            a.pop()
        return a

    def const(self, a):
        return self.trim([self.k.elt(a)])

    def add(self, a, b):
        return self.trim([self.k.add(a[i] if i < len(a) else self.k.zero,
                                     b[i] if i < len(b) else self.k.zero)
                          for i in range(max(len(a),len(b)))])

    def scale(self, a, c):
        return self.trim([self.k.mul(x,c) for x in a])

    def neg(self, a):
        return [self.k.neg(x) for x in a]

    def sub(self, a, b):
        return self.add(a,self.neg(b))

    def mul(self, a, b):
        if not a or not b:
            return []
        out = [self.k.zero]*(len(a)+len(b)-1)
        for i,x in enumerate(a):
            for j,y in enumerate(b):
                out[i+j] = self.k.add(out[i+j],self.k.mul(x,y))
        return self.trim(out)

    def divmod(self, a, b):
        assert b
        r = self.trim(a)
        q = [self.k.zero]*max(0,len(a)-len(b)+1)
        inv = self.k.inv(b[-1])
        while r and len(r) >= len(b):
            n = len(r)-len(b)
            t = self.k.mul(r[-1],inv)
            q[n] = t
            for j,c in enumerate(b):
                r[j+n] = self.k.sub(r[j+n],self.k.mul(t,c))
            r = self.trim(r)
        return self.trim(q),r

    def mod(self, a, b):
        return self.divmod(a,b)[1]

    def quotient(self, a, b):
        q,r = self.divmod(a,b)
        assert not r
        return q

    def monic(self, a):
        return self.scale(a,self.k.inv(a[-1]))

    def egcd(self, a, b):
        s,t,ss,tt = self.one,[],[],self.one
        while b:
            q,r = self.divmod(a,b)
            a,b = b,r
            s,ss = ss,self.sub(s,self.mul(q,ss))
            t,tt = tt,self.sub(t,self.mul(q,tt))
        inv = self.k.inv(a[-1])
        return self.scale(a,inv),self.scale(s,inv),self.scale(t,inv)

    def inverse(self, a, modulus):
        d,s,_ = self.egcd(a,modulus)
        assert d == self.one
        return self.mod(s,modulus)

    def eval(self, a, x):
        r = self.k.zero
        for c in reversed(a):
            r = self.k.add(self.k.mul(r,x),c)
        return r


class Jacobian:
    def __init__(self, polynomials, f):
        self.p,self.f = polynomials,f
        self.zero = (self.p.one,[])

    def valid(self, D):
        u,v = D
        assert u and u[-1] == self.p.k.one and len(v) < len(u)
        assert not self.p.mod(self.p.sub(self.f,self.p.mul(v,v)),u)

    def reduce(self, u, v):
        p = self.p
        u = p.monic(u)
        v = p.mod(v,u)
        while len(u)-1 > 3:
            u = p.monic(p.quotient(p.sub(self.f,p.mul(v,v)),u))
            v = p.mod(p.neg(v),u)
        D = u,v
        self.valid(D)
        return D

    def add(self, A, B):
        p = self.p
        u1,v1 = A
        u2,v2 = B
        d1,e1,e2 = p.egcd(u1,u2)
        d,c1,c2 = p.egcd(d1,p.add(v1,v2))
        s1,s2,s3 = p.mul(c1,e1),p.mul(c1,e2),c2
        u = p.quotient(p.mul(u1,u2),p.mul(d,d))
        v = p.quotient(p.add(p.add(p.mul(p.mul(s1,u1),v2),
                                    p.mul(p.mul(s2,u2),v1)),
                              p.mul(s3,p.add(p.mul(v1,v2),self.f))),d)
        return self.reduce(u,v)

    def neg(self, D):
        return D[0],self.p.neg(D[1])

    def mul(self, n, D):
        if n < 0:
            return self.mul(-n,self.neg(D))
        R = self.zero
        while n:
            if n&1:
                R = self.add(R,D)
            D = self.add(D,D)
            n >>= 1
        return R


def run():
    K,E,N,F,f,cover_map,fb,images,G,ell,cofactor = main(verbose=False)
    p = K.p
    P = Polynomials(K)
    polynomial = lambda a: [K.elt(int(c)) for c in reversed(a.all_coeffs())]
    npoly,fpoly,curve_f = polynomial(N),polynomial(F),polynomial(f)
    J = Jacobian(P,curve_f)
    alpha = (0,1,0)
    beta,gamma = K.pow(alpha,p),K.pow(alpha,p*p)
    dconst = K.mul(K.sub(alpha,gamma),K.sub(beta,gamma))
    xpoly = [K.zero,K.one]
    # Exact polynomial identities for both stages of the cover, not only point
    # sampling: Y'^2=(z-alpha-beta)*(z^2-4*alpha*beta), then the 2-isogeny.
    xg = P.sub(xpoly,P.const(gamma))
    znum = P.add(P.sub(P.mul(xpoly,xpoly),P.const(K.mul(gamma,gamma))),P.const(dconst))
    sab,ab = K.add(alpha,beta),K.mul(alpha,beta)
    cleared_quotient = P.mul(xg,P.mul(P.sub(znum,P.scale(xg,sab)),
        P.sub(P.mul(znum,znum),P.scale(P.mul(xg,xg),K.scale(ab,4)))))
    assert cleared_quotient == curve_f
    xnum = P.sub(P.mul(xpoly,xpoly),P.const(K.scale(ab,4)))
    xden = P.scale(P.sub(xpoly,P.const(sab)),K.elt(4))
    ynum = P.mul(P.sub(xpoly,P.const(K.scale(alpha,2))),
                 P.sub(xpoly,P.const(K.scale(beta,2))))
    assert P.mul(ynum,ynum) == P.add(P.add(P.mul(xnum,xnum),
        P.scale(P.mul(xnum,xden),E.a2)),P.scale(P.mul(xden,xden),E.a4))

    def pullback(Q):
        if Q is None:
            return J.zero
        X,Y = Q
        # The four x-coordinates of pi^{-1}(Q).
        u = P.sub(fpoly,P.scale(npoly,K.scale(X,4)))
        xg = P.sub(xpoly,P.const(gamma))
        z = P.mod(P.add(P.add(xpoly,P.const(gamma)),
                            P.scale(P.inverse(xg,u),dconst)),u)
        dd = P.sub(z,P.const(K.add(alpha,beta)))
        numerator = P.mul(P.sub(z,P.const(K.scale(alpha,2))),
                          P.sub(z,P.const(K.scale(beta,2))))
        denominator = P.scale(P.mul(P.mul(xg,xg),P.mul(dd,dd)),K.elt(8))
        # pi_y = y * numerator / denominator modulo u.
        v = P.mod(P.scale(P.mul(denominator,P.inverse(numerator,u)),Y),u)
        assert not P.mod(P.sub(curve_f,P.mul(v,v)),u)
        # pi^{-1}(O)=infinity + the three Weierstrass points N=0.
        # Subtracting 4*infinity alone leaves a nonzero 2-torsion offset.
        pole_correction = (npoly,[])
        return J.add(J.reduce(u,v),pole_correction)

    def frob(D, exponent):
        return tuple([[K.pow(c,exponent) for c in poly] for poly in D])

    def descend(Q):
        A = pullback(Q)
        D = J.add(J.add(A,frob(A,p)),frob(A,p*p))
        assert all(c == K.pow(c,p) for poly in D for c in poly)
        return D

    DG = descend(G)
    assert DG != J.zero and J.mul(ell,DG) == J.zero, (ell,DG,J.mul(ell,DG))
    # Independently test homomorphism and norm-conorm on a nontrivial target.
    Q = E.mul(1729,G)
    DQ = descend(Q)
    assert DQ == J.mul(1729,DG)
    assert descend(E.add(G,Q)) == J.add(DG,DQ)
    assert J.add(DG,J.neg(DG)) == J.zero

    n = len(fb)
    point_divisors = [([K.elt(-x),K.one],P.const(y)) for x,y in fb]
    pivots,relations = {},[]

    def accept(row):
        check = None
        for a,point in zip(row,images):
            check = E.add(check,E.mul(int(a),point))
        assert check is None
        relations.append([int(a) for a in row])
        v = [int(a) % ell for a in row]
        for j in range(n):
            if not v[j]:
                continue
            if j in pivots:
                a = v[j]
                v = [(r-a*s) % ell for r,s in zip(v,pivots[j])]
            else:
                a = pow(v[j],-1,ell)
                pivots[j] = [a*r % ell for r in v]
                break

    for i,(_,y) in enumerate(fb):
        if y == 0:
            row = [0]*n
            row[i] = 2
            accept(row)
    xs = np.array([x for x,y in fb],dtype=np.int64)
    ys = np.array([y for x,y in fb],dtype=np.int64)
    fx = np.array([int(f.eval(int(x))) % p for x in xs])
    x2,x3 = xs*xs % p,xs**3 % p
    smooth,tested,evaluated = 0,0,0
    example = None
    for start in range(0,p**4,4096):
        ids = np.arange(start,min(start+4096,p**4),dtype=np.int64)
        a,b,c,d = ids//p**3,ids//p**2 % p,ids//p % p,ids % p
        h = (a[:,None]*x3+b[:,None]*x2+c[:,None]*xs+d[:,None]) % p
        roots = h*h % p == fx[None,:]
        evaluated += len(ids)
        for i in np.flatnonzero(roots.sum(axis=1) == 7):
            row = [0]*n
            for j in np.flatnonzero(roots[i]):
                row[j] = 1 if h[i,j] == ys[j] else -1
            accept(row)
            tested = int(ids[i])+1
            smooth += 1
            if example is None:
                example = {'h_coefficients_descending':[int(a[i]),int(b[i]),int(c[i]),int(d[i])],
                           'relation':row}
                check = J.zero
                for scalar,divisor in zip(row,point_divisors):
                    check = J.add(check,J.mul(scalar,divisor))
                assert check == J.zero
            if len(pivots) == n-1:
                break
        if len(pivots) == n-1:
            break
    assert len(pivots) == n-1, ('insufficient rank',len(pivots),n)
    free = next(i for i in range(n) if i not in pivots)
    logs = [0]*n
    logs[free] = 1
    for j in sorted(pivots,reverse=True):
        logs[j] = -sum(pivots[j][k]*logs[k] for k in range(j+1,n)) % ell
    gi = images.index(G)
    scale = pow(logs[gi],-1,ell)
    logs = [a*scale % ell for a in logs]
    assert all(E.mul(a,G) == point for a,point in zip(logs,images))

    # Standard individual descent: shift the descended target until its reduced
    # Mumford u splits completely over F_31 into distinct linear factors.
    shifted = DQ
    for shift in range(ell):
        u,v = shifted
        roots = [x for x in range(p) if P.eval(u,K.elt(x)) == K.zero]
        if len(roots) == len(u)-1:
            decomposition = []
            total_log = 0
            reconstructed = J.zero
            pushed_smooth_divisor = None
            for x in roots:
                y = P.eval(v,K.elt(x))
                assert y[1:] == (0,0)
                i = next(i for i,(xx,yy) in enumerate(fb) if xx == x)
                sign = 1 if fb[i][1] == y[0] else -1
                total_log += sign*logs[i]
                reconstructed = J.add(reconstructed,J.mul(sign,point_divisors[i]))
                pushed_smooth_divisor = E.add(pushed_smooth_divisor,
                    cover_map((K.elt(x),y)))
                decomposition.append({'point':[x,y[0]],'fb_index':i,'sign':sign})
            assert reconstructed == shifted
            # Verify the norm-conorm identity with full elliptic points, before
            # cofactor projection, on this nonzero subgroup element.
            assert pushed_smooth_divisor == E.mul(4,E.add(Q,E.mul(shift,G)))
            # pi_* Tr pi^* = [4]; images used for logs have cofactor applied.
            recovered = (total_log*pow(4*cofactor,-1,ell)-shift) % ell
            assert E.mul(recovered,G) == Q
            break
        shifted = J.add(shifted,DG)
    else:
        raise AssertionError('No smooth target found')

    def base_mumford(D):
        assert all(c[1:] == (0,0) for poly in D for c in poly)
        return {'u_ascending':[c[0] for c in D[0]],'v_ascending':[c[0] for c in D[1]]}

    output = {
        'base_field':p,'elliptic_field':p**3,'prime_subgroup':ell,'cofactor':cofactor,
        'generator':G,'target':Q,
        'descended_generator':base_mumford(DG),'descended_target':base_mumford(DQ),
        'descent_map':'Tr_(K/k) composed with pi^*; pi_* Tr pi^* = [4]',
        'descended_generator_nonzero_and_order_ell':True,
        'descent_homomorphism_checked':True,
        'cover_verified_by_exact_polynomial_identities':True,
        'norm_conorm_identity_checked_with_full_elliptic_points':True,
        'factor_base_size':n,'relation_rank':len(pivots),
        'smooth_function_relations':smooth,'branch_relations':len(relations)-smooth,
        'candidate_prefix_through_last_relation':tested,'candidates_evaluated':evaluated,
        'example_relation':example,'factor_base_logs':logs,
        'individual_descent_shifts':shift,'smooth_divisor':base_mumford(shifted),
        'smooth_decomposition':decomposition,'recovered_log':recovered,
        'verified_on_elliptic_curve':True,
        'relations':relations,
    }
    Path(__file__).with_name('descent_dlp_results.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:v for k,v in output.items() if k != 'relations'},indent=2))


if __name__ == '__main__':
    run()
