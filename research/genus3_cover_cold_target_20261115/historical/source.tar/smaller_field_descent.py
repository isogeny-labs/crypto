"""Genus-3 cover over F_31 of an elliptic curve over F_(31^3).

Construction: Joux--Vitse, Cover and Decomposition Index Calculus,
Appendix A.1, https://eprint.iacr.org/2011/020.pdf .
Tuple (a,b,c) denotes a+b*alpha+c*alpha^2, alpha^3+alpha+8=0.
"""
import itertools
import json
from pathlib import Path

from sympy import Poly, factorint, symbols


class Field:
    def __init__(self, p, modulus):
        self.p, self.modulus = p, modulus
        self.n = len(modulus)-1
        self.order = p**self.n
        self.zero, self.one = (0,)*self.n, (1,)+(0,)*(self.n-1)

    def elt(self, a):
        return (a % self.p,)+(0,)*(self.n-1) if isinstance(a, int) else tuple(a)

    def add(self, a, b):
        return tuple((x+y) % self.p for x,y in zip(a,b))

    def neg(self, a):
        return tuple(-x % self.p for x in a)

    def sub(self, a, b):
        return self.add(a,self.neg(b))

    def scale(self, a, b):
        return tuple(x*b % self.p for x in a)

    def mul(self, a, b):
        p = self.p
        if self.n == 3:
            v, u, _, _ = self.modulus
            a0,a1,a2 = a
            b0,b1,b2 = b
            t = a1*b2+a2*b1
            return ((a0*b0-v*t) % p,
                    (a0*b1+a1*b0-u*t-v*a2*b2) % p,
                    (a0*b2+a1*b1+a2*b0-u*a2*b2) % p)
        out = [0]*(2*self.n-1)
        for i,x in enumerate(a):
            for j,y in enumerate(b):
                out[i+j] += x*y
        for i in range(len(out)-1,self.n-1,-1):
            for j in range(self.n):
                out[i-self.n+j] -= out[i]*self.modulus[j]
        return tuple(x % p for x in out[:self.n])

    def pow(self, a, n):
        if n < 0:
            return self.pow(self.inv(a),-n)
        out = self.one
        while n:
            if n&1:
                out = self.mul(out,a)
            a = self.mul(a,a)
            n >>= 1
        return out

    def inv(self, a):
        assert a != self.zero
        return self.pow(a,self.order-2)

    def div(self, a, b):
        return self.mul(a,self.inv(b))

    def elements(self):
        return itertools.product(range(self.p), repeat=self.n)


class Elliptic:
    def __init__(self, field, a2, a4):
        self.k, self.a2, self.a4 = field,a2,a4

    def rhs(self, x):
        k = self.k
        return k.mul(x,k.add(k.mul(x,k.add(x,self.a2)),self.a4))

    def contains(self, P):
        return P is None or self.k.mul(P[1],P[1]) == self.rhs(P[0])

    def neg(self, P):
        return None if P is None else (P[0],self.k.neg(P[1]))

    def add(self, P, Q):
        k = self.k
        if P is None:
            return Q
        if Q is None:
            return P
        x,y = P
        u,v = Q
        if x == u and k.add(y,v) == k.zero:
            return None
        m = k.div(k.add(k.add(k.scale(k.mul(x,x),3),k.scale(k.mul(self.a2,x),2)),self.a4),k.scale(y,2)) if P == Q else k.div(k.sub(v,y),k.sub(u,x))
        z = k.sub(k.sub(k.sub(k.mul(m,m),self.a2),x),u)
        return z,k.sub(k.mul(m,k.sub(x,z)),y)

    def mul(self, n, P):
        if n < 0:
            return self.mul(-n,self.neg(P))
        R = None
        while n:
            if n&1:
                R = self.add(R,P)
            P = self.add(P,P)
            n >>= 1
        return R


def base_polynomials(p=31,u=1,v=8):
    z = symbols('z')
    N = Poly(z**3+u*z+v,z,modulus=p)
    F = Poly(z**4-2*u*z*z-8*v*z+u*u,z,modulus=p)
    f = N*F
    assert N.is_irreducible and f.gcd(f.diff()).degree() == 0
    return N,F,f


def eval_base(poly, x, k):
    out = k.zero
    for coefficient in poly.all_coeffs():
        out = k.add(k.mul(out,x),k.elt(int(coefficient)))
    return out


def curve_count(poly, field):
    squares = {field.mul(y,y) for y in field.elements()}
    total = 1  # Unique rational point at infinity (degree 7).
    for x in field.elements():
        a = eval_base(poly,x,field)
        total += 1 if a == field.zero else 2 if a in squares else 0
    return total


def main(p=31, u=1, v=8, verbose=True, persist=True):
    N,F,f = base_polynomials(p,u,v)
    K = Field(p,[v,u,0,1])
    alpha = (0,1,0)
    beta,gamma = K.pow(alpha,p),K.pow(alpha,p*p)
    assert alpha != beta != gamma != alpha
    assert K.pow(alpha,p**3) == alpha
    a2,a4 = K.neg(K.add(alpha,beta)),K.mul(alpha,beta)
    E = Elliptic(K,a2,a4)
    # j for y^2=x^3+a2*x^2+a4*x. Verify E is not a base-field curve.
    c4 = K.scale(K.sub(K.mul(a2,a2),K.scale(a4,3)),16)
    disc = K.scale(K.mul(K.mul(a4,a4),K.sub(K.mul(a2,a2),K.scale(a4,4))),16)
    j = K.div(K.pow(c4,3),disc)
    assert K.pow(j,p) != j
    roots = {}
    for y in K.elements():
        roots.setdefault(K.mul(y,y),y)
    order = 1
    for x in K.elements():
        a = E.rhs(x)
        order += 1 if a == K.zero else 2 if a in roots else 0
    ell = max(map(int,factorint(order)))
    cofactor = order//ell
    D = K.mul(K.sub(alpha,gamma),K.sub(beta,gamma))

    def cover_map(P):
        if P is None:
            return None
        x,y = P
        # The degree-2 quotient H -> E', then the degree-2 isogeny E' -> E.
        xg = K.sub(x,gamma)
        z = K.add(x,K.add(gamma,K.div(D,xg)))
        yz = K.div(y,K.mul(xg,xg))
        d = K.sub(K.sub(z,alpha),beta)
        if d == K.zero:
            return None
        X = K.div(K.sub(K.mul(z,z),K.scale(a4,4)),K.scale(d,4))
        Y = K.div(K.mul(yz,K.mul(K.sub(z,K.scale(alpha,2)),K.sub(z,K.scale(beta,2)))),K.scale(K.mul(d,d),8))
        R = X,Y
        assert E.contains(R)
        assert X == K.div(eval_base(F,x,K),K.scale(eval_base(N,x,K),4))
        return R

    fb = []
    for x in range(p):
        rhs = int(f.eval(x)) % p
        ys = [y for y in range(p) if y*y % p == rhs]
        if ys:
            fb.append((x,min(ys)))
    mapped = [cover_map((K.elt(x),K.elt(y))) for x,y in fb]
    projected = [E.mul(cofactor,P) for P in mapped]
    G = next(P for P in projected if P is not None)
    assert E.mul(ell,G) is None
    # Count over k, k^2 and k^3 and reconstruct the genus-3 Weil polynomial.
    nonsquare = next(d for d in range(2,p) if pow(d,(p-1)//2,p) == p-1)
    fields = [Field(p,[0,1]),Field(p,[-nonsquare,0,1]),K]
    counts = [curve_count(f,k) for k in fields]
    s1,s2,s3 = [p**r+1-counts[r-1] for r in range(1,4)]
    e1 = -s1
    assert (s1*s1-s2) % 2 == 0
    e2 = (s1*s1-s2)//2
    assert (s3+e1*s2+e2*s1) % 3 == 0
    e3 = -(s3+e1*s2+e2*s1)//3
    # L(T)=1+e1*T+e2*T^2+e3*T^3+p*e2*T^4+p^2*e1*T^5+p^3*T^6.
    L = [1,e1,e2,e3,p*e2,p*p*e1,p**3]
    jac_order = sum(L)
    assert jac_order == order
    output = {
        'base_field_size':p,'elliptic_field_size':p**3,
        'extension_modulus':f'alpha^3+{u}*alpha+{v}=0',
        'N':str(N.as_expr()),'F':str(F.as_expr()),'cover_f':str(f.as_expr()),
        'cover_genus':3,'cover_map_degree':4,
        'elliptic_model':f'Y^2=X*(X-alpha)*(X-alpha^{p})',
        'elliptic_a2':a2,'elliptic_a4':a4,'j_in_extension_basis':j,
        'j_not_in_base_field':True,
        'curve_point_counts_over_q_q2_q3':counts,
        'L_polynomial_coefficients_ascending':L,
        'jacobian_order':jac_order,'elliptic_order':order,
        'order_factorization':factorint(order),'prime_subgroup':ell,
        'cofactor':cofactor,'rational_factor_base':fb,
        'factor_base_size_up_to_sign':len(fb),
        'projected_factor_base':projected,'subgroup_generator':G,
        'all_factor_base_images_on_E':True,
    }
    if persist:
        Path(__file__).with_name('smaller_field_results.json').write_text(json.dumps(output,indent=2)+'\n')
    if verbose:
        print(json.dumps(output,indent=2))
    return K,E,N,F,f,cover_map,fb,projected,G,ell,cofactor


if __name__ == '__main__':
    main()
