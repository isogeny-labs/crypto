"""Independent cold single-target trials: no DLP precomputation is reused.

Shared inputs: field, elliptic curve, subgroup order, generator, target.
Each timed cover call constructs C and enumerates the factor base afresh,
collects new relations, solves them, descends one target, and verifies it.
Each timed direct call constructs and searches a fresh negation-aware BSGS
table and verifies the result. Runtime imports/target generation are excluded.
"""
import argparse
import hashlib
import json
import math
import platform
import random
import statistics
import time
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import scipy
from sympy.core.cache import clear_cache

from cold_target import ColdContext
from speedup import Context,FastExtensionField,Elliptic


def run(trials=64,p=1061,v=65):
    folder = Path(__file__).parent
    sources = ['cold_target.py','cold_target_audit.py','speedup.py',
               'smaller_field_descent.py','descent_dlp.py']
    hashes = {name:hashlib.sha256((folder/name).read_bytes()).hexdigest() for name in sources}
    reference = ColdContext(p,1,v)
    ell,order,G = reference.ell,reference.order,reference.G
    a2,a4 = reference.E.a2,reference.E.a4
    target_rng = random.Random(2026111501)
    algorithm_rng = random.Random(2026111502)
    order_rng = random.Random(2026111503)
    secrets = [target_rng.randrange(1,ell) for _ in range(trials)]
    targets = [reference.E.mul(secret,G) for secret in secrets]
    relation_seeds = [algorithm_rng.randrange(2**32) for _ in range(trials)]
    m = math.isqrt(ell//4)+1
    rows = []

    def cover(Q,seed):
        ctx = ColdContext(p,1,v,known_order=order)
        assert ctx.G == G
        stats = ctx.precompute(seed)
        answer,shifts = ctx.solve(Q)
        assert ctx.E.mul(answer,G) == Q
        return answer,{'relations':stats,'target_shifts':shifts}

    def direct(Q):
        k = FastExtensionField(p,[v,1,0,1])
        E = Elliptic(k,a2,a4)
        assert E.contains(G) and E.mul(ell,G) is None
        ctx = SimpleNamespace(E=E,G=G,ell=ell)
        solve = Context.bsgs(ctx,m)
        answer = solve(Q)
        assert E.mul(answer,G) == Q
        return answer,{'table_entries':m+1}

    for i,(Q,secret,seed) in enumerate(zip(targets,secrets,relation_seeds)):
        methods = ['cover','direct']
        if order_rng.randrange(2): methods.reverse()
        row = {'trial':i,'target':Q,'relation_seed':seed,'timing_order':methods}
        for name in methods:
            # Remove symbolic-construction caches too; no curve-specific result
            # or factor-base logarithm may carry into a timed solve.
            clear_cache()
            start = time.perf_counter()
            answer,metadata = cover(Q,seed) if name == 'cover' else direct(Q)
            row[name+'_seconds'] = time.perf_counter()-start
            assert answer == secret
            row[name+'_metadata'] = metadata
        row['recovered_log'] = secret
        rows.append(row)
        if (i+1) % 8 == 0:
            print('completed',i+1,'independent cold targets',flush=True)

    ic = np.array([r['cover_seconds'] for r in rows])
    bs = np.array([r['direct_seconds'] for r in rows])
    bootstrap_rng = np.random.default_rng(2026111504)
    indices = bootstrap_rng.integers(trials,size=(10000,trials))
    ratios = bs[indices].mean(axis=1)/ic[indices].mean(axis=1)
    summary = {
        'curve':{'q':p,'extension_modulus':f'alpha^3+alpha+{v}',
                 'E':f'Y^2=X*(X-alpha)*(X-alpha^{p})',
                 'C':f'y^2=(t^3+t+{v})*(t^4-2*t^2-{8*v}*t+1)',
                 'group_order':order,'subgroup_order':ell,'cofactor':order//ell,'generator':G},
        'trials':trials,'cover_mean_seconds':float(ic.mean()),
        'direct_mean_seconds':float(bs.mean()),
        'cover_median_seconds':float(np.median(ic)),
        'direct_median_seconds':float(np.median(bs)),
        'speedup_ratio_of_means':float(bs.mean()/ic.mean()),
        'paired_bootstrap_95_percent_interval':np.quantile(ratios,[.025,.975]).tolist(),
        'cover_faster_trials':int((ic<bs).sum()),
        'all_answers_verified':True,
        'bsgs':'fresh negation-aware BSGS; m=floor(sqrt(ell/4))+1 for one target',
        'cold_scope':'Fresh solver, curve construction, factor-base enumeration, relations, exact linear solve, target descent and answer verification for every cover trial; fresh BSGS table and verification for every direct trial. No DLP precomputation is shared. Known curve/order/generator inputs, runtime imports and shared target generation are excluded.',
        'target_seed':2026111501,'relation_seed_source':2026111502,
        'order_seed':2026111503,'source_sha256':hashes,
        'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,
        'order_certificate':reference.order_certificate,
    }
    output = {'summary':summary,'raw_trials':rows}
    path = folder/f'cold_target_audit_q{p}_v{v}.json'
    path.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(summary,indent=2),flush=True)
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--trials',type=int,default=64)
    parser.add_argument('--p',type=int,default=1061)
    parser.add_argument('--v',type=int,default=65)
    args = parser.parse_args()
    run(args.trials,args.p,args.v)
