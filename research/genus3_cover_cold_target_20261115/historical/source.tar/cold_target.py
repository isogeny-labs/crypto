"""Single-target cover DLP with an exact sparse finite-field CG solve.

The normal equations are symmetric over the prime-order field. A zero pivot
causes a fresh random diagonal, and the original equations certify the result.
"""
import json
import math
import random
import statistics
import time
from pathlib import Path

import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse._sparsetools import csr_matvec

import speedup


def cg_logs(rows,gi,ell,seed):
    n = len(rows[0])
    assert ell*ell < 2**63
    chunk = max(1,min(n,(2**63-1)//((ell-1)*(ell-1))))
    def dot(a,b):
        if chunk == n: return int(np.dot(a,b) % ell)
        # Products fit int64; reducing before summation avoids a wider sum.
        assert n*ell < 2**63
        return int(np.sum(a*b % ell) % ell)
    dense = np.array(list(rows)+[np.eye(1,n,gi,dtype=np.int64)[0]],dtype=np.int64)
    dense[dense>ell//2] -= ell
    R = csr_matrix(dense)
    if np.any(R.getnnz(axis=0) == 0):
        raise ArithmeticError('Some columns have not appeared')
    RT = R.transpose().tocsr()
    rhs = np.zeros(R.shape[0],dtype=np.int64)
    rhs[-1] = 1
    rng = np.random.default_rng(seed)
    tmp = np.zeros(R.shape[0],dtype=np.int64)
    out = np.zeros(n,dtype=np.int64)
    for attempt in range(4):
        diag = rng.integers(1,ell,size=R.shape[0],dtype=np.int64)
        def apply(x):
            tmp.fill(0)
            csr_matvec(R.shape[0],n,R.indptr,R.indices,R.data,x,tmp)
            np.remainder(tmp,ell,out=tmp)
            np.multiply(tmp,diag,out=tmp)
            np.remainder(tmp,ell,out=tmp)
            out.fill(0)
            csr_matvec(n,R.shape[0],RT.indptr,RT.indices,RT.data,tmp,out)
            np.remainder(out,ell,out=out)
            return out
        b = np.zeros(n,dtype=np.int64)
        b[gi] = diag[-1]
        x = np.zeros(n,dtype=np.int64)
        r = b.copy()
        direction = r.copy()
        norm = dot(r,r)
        for iteration in range(n):
            Ad = apply(direction)
            denominator = dot(direction,Ad)
            if not denominator or not norm: break
            alpha = norm*pow(denominator,-1,ell) % ell
            x = (x+alpha*direction) % ell
            r = (r-alpha*Ad) % ell
            if not np.any(r):
                if np.array_equal(R.dot(x) % ell,rhs):
                    return x.tolist(),{'method':'exact finite-field conjugate gradients',
                        'iterations':iteration+1,'diagonal_attempts':attempt+1,
                        'nonzero_entries':int(R.nnz),'original_equations_verified':True}
                break
            newnorm = dot(r,r)
            beta = newnorm*pow(norm,-1,ell) % ell
            direction = (r+beta*direction) % ell
            norm = newnorm
    raise ArithmeticError('More independent relations or another diagonal needed')


class ColdContext(speedup.Context):
    method = 'coverage-guided interpolation; exact finite-field sparse CG; base-field Cantor arithmetic'
    linear_solver = staticmethod(cg_logs)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--profile',action='store_true')
    args = parser.parse_args()
    ctx = ColdContext(1019,1,46)
    if args.profile:
        import cProfile,pstats
        profiler = cProfile.Profile()
        profiler.enable()
        start = time.perf_counter()
        result = ctx.precompute()
        elapsed = time.perf_counter()-start
        profiler.disable()
        pstats.Stats(profiler).sort_stats('cumtime').print_stats(15)
        print(elapsed,result)
    else:
        result = speedup.benchmark(ctx,number=1,repeats=9)
        Path(__file__).with_name('cold_cg_initial.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result,indent=2))
