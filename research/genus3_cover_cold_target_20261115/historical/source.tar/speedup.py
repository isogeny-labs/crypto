"""Fair setup/online/batch timings for cubic-extension cover index calculus.

Known curve/subgroup parameters are shared inputs. Neither solver is charged
for parameter generation or target generation. All recovered logs are checked.
"""
import json
import math
import random
import statistics
import time
from pathlib import Path

import numpy as np
from scipy.sparse import csr_matrix
from sympy import factorint

from smaller_field_descent import Field,Elliptic,base_polynomials
from descent_dlp import Polynomials,Jacobian


class FastExtensionField(Field):
    """Same polynomial basis, using a closed-form inverse instead of a^(q^3-2)."""
    def add(self,a,b):
        p = self.p
        return (a[0]+b[0]) % p,(a[1]+b[1]) % p,(a[2]+b[2]) % p
    def sub(self,a,b):
        p = self.p
        return (a[0]-b[0]) % p,(a[1]-b[1]) % p,(a[2]-b[2]) % p
    def neg(self,a):
        p = self.p
        return -a[0] % p,-a[1] % p,-a[2] % p
    def scale(self,a,b):
        p = self.p
        return a[0]*b % p,a[1]*b % p,a[2]*b % p
    def inv(self,a):
        p = self.p
        v,u,_,_ = self.modulus
        a0,a1,a2 = a
        b0 = ((a0-u*a2)**2+u*a1*a1+v*a1*a2) % p
        b1 = (-a0*a1-v*a2*a2) % p
        b2 = (a1*a1-a0*a2+u*a2*a2) % p
        norm = (a0*b0-v*a2*b1-v*a1*b2) % p
        invnorm = pow(norm,-1,p)
        return b0*invnorm % p,b1*invnorm % p,b2*invnorm % p


class PrimeField:
    def __init__(self,p):
        self.p,self.zero,self.one = p,0,1
    def elt(self,a): return int(a) % self.p
    def add(self,a,b): return (a+b) % self.p
    def sub(self,a,b): return (a-b) % self.p
    def neg(self,a): return -a % self.p
    def mul(self,a,b): return a*b % self.p
    def inv(self,a): return pow(int(a),-1,self.p)


def extension_order(p,u,v,a2,a4):
    """Exact point count with vectorized extension-field arithmetic."""
    size = p**3
    squares = np.zeros(size,dtype=np.bool_)
    def coords(ids): return ids % p,ids//p % p,ids//(p*p)
    def mul(a,b):
        a0,a1,a2 = a
        b0,b1,b2 = b
        t = a1*b2+a2*b1
        return ((a0*b0-v*t) % p,
                (a0*b1+a1*b0-u*t-v*a2*b2) % p,
                (a0*b2+a1*b1+a2*b0-u*a2*b2) % p)
    def plus(a,b): return tuple((x+y) % p for x,y in zip(a,b))
    def encode(a): return a[0]+p*a[1]+p*p*a[2]
    batch = 65536
    for start in range(0,size,batch):
        x = coords(np.arange(start,min(size,start+batch),dtype=np.int64))
        squares[encode(mul(x,x))] = True
    order = 1
    for start in range(0,size,batch):
        x = coords(np.arange(start,min(size,start+batch),dtype=np.int64))
        rhs = encode(mul(x,plus(mul(x,plus(x,a2)),a4)))
        order += int((2*squares[rhs]-(rhs == 0).astype(np.int8)).sum())
    return order


def hasse_order(E,seed=87311):
    """Exact small-instance order with a Hasse-interval point-order certificate.

    Each sampled point's exact order is certified by factoring an annihilating
    multiple. When the lcm of these orders has a unique multiple in the Hasse
    interval, Lagrange's theorem determines #E uniquely.
    """
    k = E.k
    Q = k.order
    radius = math.isqrt(4*Q)
    low,high = Q+1-radius,Q+1+radius
    width = high-low
    rng = random.Random(seed)
    def sqrt(a):
        if a == k.zero: return a
        if k.pow(a,(Q-1)//2) != k.one: return None
        if Q % 4 == 3: return k.pow(a,(Q+1)//4)
        t,s = Q-1,0
        while t % 2 == 0: t//=2; s+=1
        while True:
            z = tuple(rng.randrange(k.p) for _ in range(3))
            if z != k.zero and k.pow(z,(Q-1)//2) != k.one: break
        c = k.pow(z,t)
        x,b = k.pow(a,(t+1)//2),k.pow(a,t)
        while b != k.one:
            bb,i = b,0
            while bb != k.one: bb=k.mul(bb,bb); i+=1
            assert i<s
            d = k.pow(c,1 << (s-i-1))
            x = k.mul(x,d)
            c = k.mul(d,d)
            b = k.mul(b,c)
            s = i
        assert k.mul(x,x) == a
        return x
    lcm,certificate = 1,[]
    for attempt in range(20):
        while True:
            x = tuple(rng.randrange(k.p) for _ in range(3))
            y = sqrt(E.rhs(x))
            if y is not None: break
        P = x,y
        assert E.contains(P)
        m = math.isqrt(width)+1
        baby,R = {},None
        for j in range(m):
            baby.setdefault(R,j)
            R = E.add(R,P)
        step = E.neg(R)
        R = E.mul(-low,P)
        candidate = None
        for i in range(width//m+1):
            if R in baby:
                t = i*m+baby[R]
                if t <= width:
                    candidate = low+t
                    break
            R = E.add(R,step)
        assert candidate is not None
        d = candidate
        for prime in factorint(candidate):
            while d % prime == 0 and E.mul(d//prime,P) is None: d//=prime
        assert E.mul(d,P) is None
        assert all(E.mul(d//prime,P) is not None for prime in factorint(d))
        lcm = math.lcm(lcm,d)
        certificate.append({'point':P,'exact_point_order':d})
        first = ((low+lcm-1)//lcm)*lcm
        assert first <= high
        if first+lcm > high:
            return first,{'hasse_interval':[low,high],'certified_points':certificate,
                          'lcm_of_point_orders':lcm,'unique_group_order':first}
    raise AssertionError('Hasse certificate not resolved')


def sparse_logs(rows,gi,ell,seed):
    """Wiedemann solve of sparse principal relations plus log(F_gi)=1.

    Random diagonal normal equations handle the rectangular relation matrix.
    All products use integer arithmetic; the original equations are checked.
    """
    n = len(rows[0])
    assert n*ell*ell < 2**63
    rr = list(rows)+[np.eye(1,n,gi,dtype=np.int64)[0]]
    # Center coefficients, so the sparse matvec uses the original +/-1 signs.
    dense = np.array(rr,dtype=np.int64)
    dense[dense>ell//2] -= ell
    R = csr_matrix(dense)
    if np.any(R.getnnz(axis=0) == 0):
        raise ArithmeticError('Some factor-base elements have not appeared yet')
    RT = R.transpose().tocsr()
    rhs = np.zeros(len(rr),dtype=np.int64)
    rhs[-1] = 1
    rng = np.random.default_rng(seed)
    for attempt in range(1):
        diag = rng.integers(1,ell,size=len(rr),dtype=np.int64)
        left = rng.integers(1,ell,size=n,dtype=np.int64)
        def apply(x):
            v = R.dot(x) % ell
            return left*(RT.dot(v*diag % ell) % ell) % ell
        b = left*(RT.dot(rhs*diag) % ell) % ell
        probe = rng.integers(1,ell,size=n,dtype=np.int64)
        sequence = []
        vectors = []
        w = b.copy()
        for j in range(2*n+4):
            sequence.append(int(np.dot(probe,w) % ell))
            if j<n: vectors.append(w.copy())
            w = apply(w)
        sequence = np.array(sequence,dtype=np.int64)
        C,B = np.array([1],dtype=np.int64),np.array([1],dtype=np.int64)
        L,m,beta = 0,1,1
        for j in range(len(sequence)):
            discrepancy = (int(sequence[j])+int(np.dot(C[1:L+1],sequence[j-L:j][::-1]))) % ell
            if discrepancy == 0:
                m += 1
                continue
            old = C.copy()
            factor = discrepancy*pow(beta,-1,ell) % ell
            size = max(len(C),m+len(B))
            if len(C)<size: C = np.pad(C,(0,size-len(C)))
            C[m:m+len(B)] = (C[m:m+len(B)]-factor*B) % ell
            if 2*L<=j:
                L = j+1-L
                B,beta,m = old,discrepancy,1
            else: m += 1
        if L != n or len(C)<n+1 or not C[n]: continue
        x = np.zeros(n,dtype=np.int64)
        for j in range(n): x = (x+int(C[n-1-j])*vectors[j]) % ell
        x = -pow(int(C[n]),-1,ell)*x % ell
        if np.array_equal(R.dot(x) % ell,rhs):
            return x.tolist(),{'method':'sparse Wiedemann','degree':L,'nonzero_entries':int(R.nnz)}
    raise ArithmeticError('Sparse solve needs additional independent relations')


class Context:
    linear_solver = staticmethod(sparse_logs)

    def __init__(self,p,u,v,known_order=None):
        self.p,self.u,self.v = p,u,v
        self.N,self.F,self.f = base_polynomials(p,u,v)
        k = self.k = FastExtensionField(p,[v,u,0,1])
        a = self.alpha = (0,1,0)
        b,c = self.beta,self.gamma = k.pow(a,p),k.pow(a,p*p)
        self.E = Elliptic(k,k.neg(k.add(a,b)),k.mul(a,b))
        self.order_certificate = None
        if known_order is None:
            self.order,self.order_certificate = hasse_order(self.E)
        else:
            self.order = known_order
        self.ell = max(map(int,factorint(self.order)))
        self.cofactor = self.order//self.ell
        self.fc = [int(c) % p for c in reversed(self.f.all_coeffs())]
        self.fb = self.make_fb()
        # Fixed generator derived from the first nontrivial factor-base image.
        for i,(x,y) in enumerate(self.fb):
            G = self.E.mul(self.cofactor,self.cover((x,y)))
            if G is not None:
                self.G,self.gi = G,i
                break
        assert self.E.mul(self.ell,self.G) is None
        self.KP = Polynomials(k)
        self.KJ = Jacobian(self.KP,[k.elt(c) for c in self.fc])
        self.BP = Polynomials(PrimeField(p))
        self.BJ = Jacobian(self.BP,self.fc)
        self.base_xs = np.arange(p,dtype=np.int64)

    def evaluate(self,x):
        y = 0
        for c in reversed(self.fc): y = (y*x+c) % self.p
        return y

    def make_fb(self):
        roots = {}
        for y in range(self.p): roots.setdefault(y*y % self.p,y)
        return [(x,roots[r]) for x in range(self.p) if (r:=self.evaluate(x)) in roots]

    def cover(self,point):
        x,y = map(self.k.elt,point)
        k,a,b,c = self.k,self.alpha,self.beta,self.gamma
        D = k.mul(k.sub(a,c),k.sub(b,c))
        xc = k.sub(x,c)
        z = k.add(x,k.add(c,k.div(D,xc)))
        d = k.sub(k.sub(z,a),b)
        if d == k.zero: return None
        X = k.div(k.sub(k.mul(z,z),k.scale(k.mul(a,b),4)),k.scale(d,4))
        Y = k.div(k.mul(y,k.mul(k.sub(z,k.scale(a,2)),k.sub(z,k.scale(b,2)))),
                  k.scale(k.mul(k.mul(xc,xc),k.mul(d,d)),8))
        return X,Y

    def descend(self,Q):
        if Q is None: return self.BJ.zero
        k,P,J = self.k,self.KP,self.KJ
        a,b,c = self.alpha,self.beta,self.gamma
        N = [k.elt(int(t)) for t in reversed(self.N.all_coeffs())]
        F = [k.elt(int(t)) for t in reversed(self.F.all_coeffs())]
        X,Y = Q
        U = P.sub(F,P.scale(N,k.scale(X,4)))
        x = [k.zero,k.one]
        xc = P.sub(x,P.const(c))
        D = k.mul(k.sub(a,c),k.sub(b,c))
        z = P.mod(P.add(P.add(x,P.const(c)),P.scale(P.inverse(xc,U),D)),U)
        d = P.sub(z,P.const(k.add(a,b)))
        numerator = P.mul(P.sub(z,P.const(k.scale(a,2))),P.sub(z,P.const(k.scale(b,2))))
        denominator = P.scale(P.mul(P.mul(xc,xc),P.mul(d,d)),k.elt(8))
        V = P.mod(P.scale(P.mul(denominator,P.inverse(numerator,U)),Y),U)
        A = J.add(J.reduce(U,V),(N,[]))
        def frob(D,e): return tuple([[k.pow(c,e) for c in poly] for poly in D])
        T = J.add(J.add(A,frob(A,self.p)),frob(A,self.p*self.p))
        assert all(t[1:] == (0,0) for poly in T for t in poly)
        return tuple([[t[0] for t in poly] for poly in T])

    def precompute(self,seed=20261113):
        """Relations by interpolating through four cover points, then factoring."""
        self.fb = self.make_fb()  # Charge factor-base enumeration to setup.
        p,ell,n = self.p,self.ell,len(self.fb)
        assert ell*ell < 2**63  # Vectorized products must not overflow.
        rng = np.random.default_rng(seed)
        xs = np.array([x for x,y in self.fb],dtype=np.int64)
        ys = np.array([y for x,y in self.fb],dtype=np.int64)
        values = np.array([self.evaluate(int(x)) for x in xs],dtype=np.int64)
        negative_ys = -ys % p
        inverse_table = np.array([0]+[pow(i,-1,p) for i in range(1,p)],dtype=np.int64)
        relation_rows = []
        usage = np.zeros(n,dtype=np.int64)
        usage[self.gi] = 1  # The normalization already covers this column.
        accepted,candidates = 0,0
        def insert(row):
            row = np.array(row,dtype=np.int64) % ell
            relation_rows.append(row)
            usage[:] += row != 0
        for i,y in enumerate(ys):
            if y == 0:
                row = [0]*n
                row[i] = 2
                insert(row)
        while True:
            assert candidates < 1000000,('rank failure',n)
            batch = 128
            indices = rng.integers(n,size=(batch,4))
            # Force one of the four interpolated points to come from a lightly
            # used column. This avoids waiting for a last rare factor-base point.
            priority = np.lexsort((rng.random(n),usage))
            indices[:,0] = priority[np.arange(batch) % n]
            while True:
                ss = np.sort(indices,axis=1)
                bad = np.any(ss[:,1:] == ss[:,:-1],axis=1)
                if not bad.any(): break
                indices[bad,1:] = rng.integers(n,size=(int(bad.sum()),3))
            xx = xs[indices]
            yy = ys[indices]*(2*rng.integers(2,size=(batch,4))-1)
            h = np.zeros((batch,4),dtype=np.int64)
            for i in range(4):
                a,b,c = [xx[:,j] for j in range(4) if j != i]
                denom = ((xx[:,i]-a)*(xx[:,i]-b) % p)*(xx[:,i]-c) % p
                inverses = inverse_table[denom]
                scalar = yy[:,i]*inverses % p
                h[:,0] = (h[:,0]-scalar*(a*b % p)*c) % p
                h[:,1] = (h[:,1]+scalar*(a*b+a*c+b*c)) % p
                h[:,2] = (h[:,2]-scalar*(a+b+c)) % p
                h[:,3] = (h[:,3]+scalar) % p
            # Horner's unreduced value is below p^4. Avoid two large-array
            # remainder operations when that bound fits native integers.
            if p**4 < 2**63:
                H = (((h[:,3,None]*xs+h[:,2,None])*xs+h[:,1,None])*xs+h[:,0,None]) % p
            else:
                H = (((h[:,3,None]*xs+h[:,2,None]) % p*xs+h[:,1,None]) % p*xs+h[:,0,None]) % p
            matches = (H == ys[None,:]) | (H == negative_ys[None,:])
            candidates += batch
            for row_index in np.flatnonzero(matches.sum(axis=1) == 7):
                row = matches[row_index]*(2*(H[row_index] == ys).astype(np.int64)-1)
                insert(row)
                accepted += 1
            if len(relation_rows) >= n+8:
                try:
                    logs,linear_stats = self.linear_solver(relation_rows,self.gi,ell,seed+29)
                    break
                except ArithmeticError:
                    pass
        DG = self.descend(self.G)
        self.logs,self.DG = logs,DG
        self.fb_index = {x:(i,y) for i,(x,y) in enumerate(self.fb)}
        return {'candidates':candidates,'smooth_relations':accepted,'rank':n-1,'factor_base':n,
                'linear_algebra':linear_stats}

    def solve(self,Q):
        D = self.descend(Q)
        for shift in range(self.ell):
            u,v = D
            values = np.zeros(self.p,dtype=np.int64)
            for coefficient in reversed(u):
                values = (values*self.base_xs+coefficient) % self.p
            xs = np.flatnonzero(values == 0).tolist()
            if len(xs) == len(u)-1:
                total = 0
                known = True
                for x in xs:
                    y = self.BP.eval(v,x)
                    i,positive = self.fb_index[x]
                    if self.logs[i] is None:
                        known = False
                        break
                    total += self.logs[i]*(1 if y == positive else -1)
                if known:
                    return (total*pow(4*self.cofactor,-1,self.ell)-shift) % self.ell,shift
            D = self.BJ.add(D,self.DG)
        raise AssertionError('No smooth target')

    def bsgs(self,m=None):
        # Identify +/- baby steps by their x-coordinate. Centers spaced 2m+1
        # cover all logarithms with intervals [-m,m] around each giant step.
        m = math.isqrt(max(1,self.ell//4))+1 if m is None else m
        table,R = {None:(0,None)},None
        for j in range(1,m+1):
            R = self.E.add(R,self.G)
            table[R[0]] = (j,R[1])
        stride = 2*m+1
        step = self.E.neg(self.E.add(self.E.add(R,R),self.G))
        def solve(Q):
            R = Q
            for i in range((self.ell+m+stride-1)//stride+1):
                key = None if R is None else R[0]
                if key in table:
                    j,y = table[key]
                    if R is not None and R[1] != y: j = -j
                    return (i*stride+j) % self.ell
                R = self.E.add(R,step)
            raise AssertionError('No log')
        return solve


def timed(fn):
    start = time.perf_counter()
    out = fn()
    return time.perf_counter()-start,out


def benchmark(ctx,number=32,repeats=5):
    rng = random.Random(1897)
    secrets = [rng.randrange(ctx.ell) for _ in range(number)]
    targets = [ctx.E.mul(s,ctx.G) for s in secrets]
    samples = []
    for _ in range(repeats):
        ic_setup,stats = timed(ctx.precompute)
        ic_online,answers = timed(lambda:[ctx.solve(Q) for Q in targets])
        assert [a for a,shift in answers] == secrets
        # BSGS table size is chosen for the batch, not just a single query.
        m = min((ctx.ell-1)//2,math.isqrt(max(1,number*ctx.ell//4))+1)
        bs_setup,bs = timed(lambda:ctx.bsgs(m))
        bs_online,bs_answers = timed(lambda:[bs(Q) for Q in targets])
        assert bs_answers == secrets
        samples.append({'cover_setup':ic_setup,'cover_batch_queries':ic_online,
                        'bsgs_setup':bs_setup,'bsgs_batch_queries':bs_online,
                        'cover_total':ic_setup+ic_online,'bsgs_total':bs_setup+bs_online})
    med = {k:statistics.median([s[k] for s in samples]) for k in samples[0]}
    med['bsgs_divided_by_cover'] = med['bsgs_total']/med['cover_total']
    return {'q':ctx.p,'u':ctx.u,'v':ctx.v,'subgroup':ctx.ell,'group_order':ctx.order,
            'generator':ctx.G,'target_generation_seed':1897,
            'targets':targets,'recovered_logs':[a for a,s in answers],
            'descent_shift_counts':[s for a,s in answers],
            'batch_size':number,'bsgs_table_entries':m+1,'repeats':repeats,
            'bsgs_variant':'negation shortcut and batch-tuned table size',
            'relation_statistics':stats,'median_seconds':med,
            'all_answers_verified':True,'samples':samples,
            'order_certificate':ctx.order_certificate,
            'extension_inverse':'closed-form adjugate and prime-field modular inverse, shared by both algorithms',
            'cover_implementation':getattr(ctx,'method','coverage-guided four-point interpolation; full factor base; sparse Wiedemann; base-field Cantor arithmetic; vectorized root scans'),
            'scope':'Python implementations, shared known curve/order/generator; setup included; parameter and target generation excluded'}


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--p',type=int,default=31)
    parser.add_argument('--u',type=int,default=1)
    parser.add_argument('--v',type=int,default=8)
    parser.add_argument('--batch',type=int,default=32)
    parser.add_argument('--order',type=int,default=None)
    parser.add_argument('--batches',type=int,nargs='+',default=None)
    parser.add_argument('--repeats',type=int,default=5)
    args = parser.parse_args()
    ctx = Context(args.p,args.u,args.v,args.order)
    for batch in args.batches or [args.batch]:
        result = benchmark(ctx,batch,args.repeats)
        Path(__file__).with_name(f'speedup_q{args.p}_v{args.v}_batch{batch}.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result,indent=2),flush=True)
