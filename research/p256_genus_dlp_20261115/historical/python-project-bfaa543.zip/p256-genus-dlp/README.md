# P-256 in genus 2, 3, 4 and 5

Explicit higher-genus covers of NIST P-256, reproducible verification, and small-field discrete-log experiments.

**The transferred subgroup has the same DLP as P-256.** It has the same prime order and an efficient inverse map. Its expected classical generic attack cost remains about `2^128` group operations. This is a reduction between problems, not a proof that P-256 cannot be attacked faster.

The ambient Jacobians have additional factors. In particular, over the P-256 field,

\[
J(C_2)\sim E\times F_2,\qquad J(C_3)\sim E^2\times F_3,
\]

where `~` denotes an isogeny over that field, rather than equality of finite groups or equality of their principal polarizations. The construction and consequences are in [the hardness analysis](docs/hardness.md).

## The curves

Let `E: Y² = X³ − 3X + b`, with the standard P-256 prime `p` and coefficient `b` in [params.py](src/p256_genus/params.py). Every equation below is over the **original 256-bit field**. Use the smooth projective model in each case.

| Genus | Curve | Map to E: (X,Y) | Cover degree |
|---|---|---|---:|
| 2 | `z² = t⁶ − 3t² + b` | `(t², z)` | 2 |
| 3 | `z² = t⁷ + bt⁴ + t` | `(t + 1/t, z/t²)` | 2 |
| 4 | `z² = t⁹ − 3t³ + b` | `(t³, z)` | 3 |
| 5 | `z² = t¹² − 3t⁴ + b` | `(t⁴, z)` | 4 |

A point `P` transfers to the Jacobian divisor class `Phi(P) = pi*([P − O])`, where `pi*` means pullback. If the cover degree is `d`, pushforward gives

\[
\pi_*\Phi(P)=[d]P,\qquad
P=[d^{-1}\bmod n]\pi_*\Phi(P).
\]

Here `n` is P-256's prime group order. Consequently `Phi(kG) = k Phi(G)` and the image has exactly order `n` in all four genera.

## Reproduce

Python 3.10 or newer is required. SymPy is the only direct dependency.

```bash
python -m pip install -e .
python -m unittest discover -s tests -v
python -m p256_genus verify --output results/p256-verification.json
python -m p256_genus toy-dlp --output results/toy-dlp.json
python -m p256_genus toy-zeta --output results/toy-zeta.json
```

The repository includes the generated JSON results. The commands run:

- Map identities, squarefreeness, genera, and fiber checks for all four actual P-256-field curves.
- Independent Cantor arithmetic for genera 3 and 4, including `[n]Phi(G)=0` and scalar-multiplication checks in the actual P-256 field. These calculations do not solve a DLP.
- Baby-step/giant-step DLPs in toy elliptic subgroups and their genus-3/4 images. Jacobian arithmetic uses polynomial operations, independently of the elliptic arithmetic.
- Exact extension-field point counts and Frobenius polynomial checks for all four genera over the toy field `F_7`, using `b=1`.

### A representative toy result

Over `F_4001`, using the reduction of the P-256 coefficient, `#E = 4111` is prime. For the known test scalar `1377`, BSGS recovered `1377` independently on `E`, `J(C3)`, and `J(C4)`. Each used 86 table/search additions under the stated counting convention. Equal addition counts follow from the same subgroup and BSGS traversal; costs per addition differ. This is an algebra check, not a P-256-scale attack or a runtime extrapolation.

The separate toy zeta experiment gives

| Curve | Jacobian order over F_7, b=1 |
|---|---:|
| E | 5 |
| F2 | 11 |
| F3 | 8 |
| C2 | 55 |
| C3 | 200 |
| C4 | 1500 |
| H5 | 440 |
| C5 | 24200 |

The **full Frobenius polynomials**, not just these orders, satisfy the documented factorization identities. These are toy orders, not the orders of the actual P-256-field Jacobians. P-256's `b` is zero modulo 7, which would make some cover equations singular; the zeta experiment deliberately uses `b=1` instead.

## Implemented scope

General Jacobian arithmetic is implemented only for the odd-degree models C3/C4. The even-degree models C2/C5 have two rational infinity points and require balanced-divisor arithmetic; passing them to this Cantor implementation raises an error. Their equations, fibers, quotient maps, and toy Frobenius polynomials are verified. Full Jacobian arithmetic and actual-field complementary-factor orders are future work.

This is mathematical research code. It is variable time and has no protocol, serialization, or production cryptographic API.

## Research directions

1. Compute and factor the actual-field orders of F2 and F3, then the remaining genus-3 factors for C4/C5. This concerns the rest of each Jacobian; it cannot change the DLP equivalence on the transferred subgroup.
2. Implement balanced divisors for C2/C5 and explicitly test the norm maps on arbitrary divisor classes.
3. Compare rho implementations and field-operation costs on the same prime-order subgroup. Report constants separately from asymptotic exponents.
4. Test proposed special-curve attacks against the explicit inverse reduction: any improvement on the image must also solve the corresponding P-256 instance.
