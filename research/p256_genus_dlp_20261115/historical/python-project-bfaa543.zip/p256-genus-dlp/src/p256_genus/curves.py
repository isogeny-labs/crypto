"""Cover equations and their induced divisor classes."""

import sympy as sp

T = sp.Symbol("t")


def cover_degree(genus):
    return {2: 2, 3: 2, 4: 3, 5: 4}[genus]


def family_expression(genus, b):
    expressions = {
        2: T**6 - 3*T**2 + b,
        3: T**7 + b*T**4 + T,
        4: T**9 - 3*T**3 + b,
        5: T**12 - 3*T**4 + b,
    }
    return expressions[genus]


def equation(genus, b, p):
    return sp.Poly(family_expression(genus, b), T, modulus=p)


def affine_map(genus, t, z, p):
    """Affine formulas only: genus 3 requires t != 0; projective extension is in docs."""
    if genus == 3:
        return (t + pow(t, -1, p)) % p, z * pow(t*t % p, -1, p) % p
    return pow(t, cover_degree(genus), p), z % p


def fiber_polynomials(genus, point, p):
    """Affine fiber above (x,y): U(t)=0 and z=V(t), with multiplicities.

    This is not by itself a Jacobian representative: the reference divisor
    pi^*(O) must also be subtracted. In genus 3 it is infinity + (0,0).
    """
    x, y = point
    if genus == 3:
        u, v = T**2 - x*T + 1, y*T**2
    else:
        u, v = T**cover_degree(genus) - x, y
    return sp.Poly(u, T, modulus=p), sp.Poly(v, T, modulus=p)


def mumford_transfer(genus, point, p):
    """Reduced odd-degree Mumford coordinates (U,V) for pi^*([P-O])."""
    if genus not in (3, 4):
        raise ValueError("Even-degree genera 2/5 require balanced divisors; see docs.")
    if point is None:
        return sp.Poly(1, T, modulus=p), sp.Poly(0, T, modulus=p)
    u, v = fiber_polynomials(genus, point, p)
    if genus == 3:
        # Add T0=(0,0): [T0-infinity] has order two, so
        # [D-infinity-T0] = [D+T0-3*infinity].
        u *= sp.Poly(T, T, modulus=p)
    return u, v.rem(u)


def decode_mumford_image(genus, divisor, p):
    """Read the original public point from a canonical genus-3/4 image.

    This only accepts the image's explicit form, not arbitrary divisors.
    Curve membership is the caller's responsibility.
    """
    if genus not in (3, 4):
        raise ValueError("Only odd-degree genus 3/4 image encodings are supported.")
    u, v = divisor
    if u == sp.Poly(1, T, modulus=p) and v.is_zero:
        return None
    x_degree, y_degree = (2, 2) if genus == 3 else (0, 0)
    point = (-int(u.nth(x_degree)) % p, int(v.nth(y_degree)) % p)
    if mumford_transfer(genus, point, p) != divisor:
        raise ValueError("The divisor is not in the explicit Mumford image.")
    return point
