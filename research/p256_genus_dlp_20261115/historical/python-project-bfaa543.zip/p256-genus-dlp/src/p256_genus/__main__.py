import argparse
import json
from pathlib import Path
from .experiments import verify, toy_dlp, toy_zeta


def main():
    parser = argparse.ArgumentParser(description="Verify higher-genus covers and run toy DLP experiments")
    parser.add_argument("experiment", choices=("verify", "toy-dlp", "toy-zeta"))
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = {"verify": verify, "toy-dlp": toy_dlp, "toy-zeta": toy_zeta}[args.experiment]()
    text = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text)
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
