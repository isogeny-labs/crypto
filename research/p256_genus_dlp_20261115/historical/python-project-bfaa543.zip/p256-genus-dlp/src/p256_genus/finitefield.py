"""Minimal exact extension fields for tiny point-count experiments only."""

from itertools import product
import sympy as sp


class TinyField:
    def __init__(self, p, degree):
        self.p, self.degree, self.size = p, degree, p**degree
        x = sp.Symbol("x")
        if degree == 1:
            self.modulus = (0, 1)
        else:
            for coeff in product(range(p), repeat=degree):
                if not coeff[0]:
                    continue
                f = sp.Poly(x**degree + sum(c*x**i for i, c in enumerate(coeff)), x, modulus=p)
                if f.is_irreducible:
                    self.modulus = (*coeff, 1)
                    break
            else:
                raise RuntimeError("Could not find an irreducible polynomial")
        self.powers = [p**i for i in range(degree)]
        self.coefficients = [tuple((n//r) % p for r in self.powers) for n in range(self.size)]

    def add(self, a, b):
        return sum((x+y) % self.p*r for x, y, r in zip(
            self.coefficients[a], self.coefficients[b], self.powers))

    def scale(self, a, c):
        return sum(x*c % self.p*r for x, r in zip(self.coefficients[a], self.powers))

    def mul(self, a, b):
        if self.degree == 1:
            return a*b % self.p
        k, p = self.degree, self.p
        aa, bb = self.coefficients[a], self.coefficients[b]
        out = [0]*(2*k-1)
        for i, u in enumerate(aa):
            for j, v in enumerate(bb):
                out[i+j] += u*v
        for i in range(2*k-2, k-1, -1):
            c = out[i] % p
            if c:
                for j in range(k):
                    out[i-k+j] -= c*self.modulus[j]
        return sum(c % p*r for c, r in zip(out[:k], self.powers))

    def count_curve(self, coefficients):
        """Count the smooth curve y^2=f(x); coefficients are in descending order.

        Experiments use monic odd/even degree equations; an even monic model
        contributes two rational infinity points over every extension.
        """
        roots = [0]*self.size
        for y in range(self.size):
            roots[self.mul(y, y)] += 1
        total = 1 if (len(coefficients)-1) % 2 else 2
        for x in range(self.size):
            value = 0
            for c in coefficients:
                value = self.add(self.mul(value, x), int(c) % self.p)
            total += roots[value]
        return total


def frobenius_polynomial(q, counts):
    """Return the monic characteristic polynomial of Frobenius, degree 2g.

    Need #C(F_{q^k}) for k=1,...,g. Newton identities produce the first g
    coefficients; the functional equation produces the remaining coefficients.
    """
    g = len(counts)
    sums = [0] + [q**k+1-counts[k-1] for k in range(1, g+1)]
    c = [1]
    for k in range(1, g+1):
        numerator = -sum(c[k-i]*sums[i] for i in range(1, k+1))
        if numerator % k:
            raise ArithmeticError("Nonintegral Newton coefficient")
        c.append(numerator//k)
    c.extend(c[2*g-k]*q**(k-g) for k in range(g+1, 2*g+1))
    x = sp.Symbol("x")
    return sp.Poly.from_list(c, x)
