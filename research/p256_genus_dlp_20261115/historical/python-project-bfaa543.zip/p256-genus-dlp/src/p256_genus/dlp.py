"""Baby-step/giant-step for intentionally small, known-order groups."""

from math import isqrt


def bsgs(generator, target, order, zero, add, neg, mul, key):
    width = isqrt(order) + 1
    table, point, additions = {}, zero, 0
    for j in range(width):
        table.setdefault(key(point), j)
        point = add(point, generator)
        additions += 1
    stride = neg(mul(width, generator))
    point = target
    for i in range(width + 1):
        j = table.get(key(point))
        if j is not None:
            scalar = (i*width+j) % order
            if key(mul(scalar, generator)) == key(target):
                # This count excludes scalar multiplications and hash operations.
                return scalar, additions
        point = add(point, stride)
        additions += 1
    raise ValueError("No discrete logarithm found in the stated subgroup")
