"""Independent Cantor arithmetic on odd-degree hyperelliptic curves.

No elliptic operations are used here. The even-degree curves C2/C5 are
deliberately excluded: ordinary one-infinity Mumford arithmetic is wrong there.
"""

import sympy as sp
from .curves import T


class OddJacobian:
    def __init__(self, f):
        self.f = f
        self.p = int(f.get_modulus())
        self.g = (f.degree() - 1)//2
        if f.degree() != 2*self.g + 1:
            raise ValueError("This implementation requires an odd-degree model.")
        if sp.gcd(f, f.diff()).degree() != 0:
            raise ValueError("Singular curve")
        self.zero = (self.poly(1), self.poly(0))

    def poly(self, expression):
        return sp.Poly(expression, T, modulus=self.p)

    def valid(self, divisor):
        u, v = divisor
        return (u.LC() == 1 and u.degree() <= self.g
                and v.degree() < u.degree() and (self.f-v*v).rem(u).is_zero)

    def key(self, divisor):
        return tuple(tuple(int(c) % self.p for c in f.all_coeffs()) for f in divisor)

    def neg(self, divisor):
        u, v = divisor
        return u, (-v).rem(u)

    def bezout(self, left, right):
        # SymPy 1.14 gcdex raises on a zero second polynomial.
        if right.is_zero:
            return self.poly(pow(int(left.LC()) % self.p, -1, self.p)), self.poly(0), left.monic()
        if left.is_zero:
            return self.poly(0), self.poly(pow(int(right.LC()) % self.p, -1, self.p)), right.monic()
        return sp.gcdex(left, right)

    def add(self, left, right):
        u1, v1 = left
        u2, v2 = right
        e1, e2, d1 = self.bezout(u1, u2)
        c1, c2, d = self.bezout(d1, v1+v2)
        s1, s2, s3 = c1*e1, c1*e2, c2
        u = (u1*u2).exquo(d*d).monic()
        numerator = s1*u1*v2 + s2*u2*v1 + s3*(v1*v2+self.f)
        v = numerator.exquo(d).rem(u)
        while u.degree() > self.g:
            u = (self.f-v*v).exquo(u).monic()
            v = (-v).rem(u)
        return u, v

    def mul(self, scalar, divisor):
        if scalar < 0:
            return self.mul(-scalar, self.neg(divisor))
        result = self.zero
        while scalar:
            if scalar & 1:
                result = self.add(result, divisor)
            divisor = self.add(divisor, divisor)
            scalar >>= 1
        return result
