"""Affine toy elliptic arithmetic; variable time, with infinity represented by None."""

from dataclasses import dataclass


@dataclass(frozen=True)
class EllipticCurve:
    p: int
    b: int
    a: int = -3
    a2: int = 0

    def rhs(self, x):
        return (x**3 + self.a2*x*x + self.a*x + self.b) % self.p

    def contains(self, point):
        return point is None or point[1]**2 % self.p == self.rhs(point[0])

    def neg(self, point):
        return None if point is None else (point[0], -point[1] % self.p)

    def add(self, left, right):
        if left is None:
            return right
        if right is None:
            return left
        x, y = left
        u, v = right
        p = self.p
        if x == u and (y + v) % p == 0:
            return None
        if x == u:
            slope = (3*x*x + 2*self.a2*x + self.a) * pow(2*y, -1, p) % p
        else:
            slope = (v-y) * pow((u-x) % p, -1, p) % p
        xx = (slope*slope - self.a2 - x-u) % p
        return xx, (slope*(x-xx)-y) % p

    def mul(self, scalar, point):
        if scalar < 0:
            return self.mul(-scalar, self.neg(point))
        result = None
        while scalar:
            if scalar & 1:
                result = self.add(result, point)
            point = self.add(point, point)
            scalar >>= 1
        return result

    def count_points(self):
        """O(p) toy calculation, never call for the P-256 field."""
        total = self.p + 1
        for x in range(self.p):
            r = self.rhs(x)
            if r:
                total += 1 if pow(r, (self.p-1)//2, self.p) == 1 else -1
        return total
