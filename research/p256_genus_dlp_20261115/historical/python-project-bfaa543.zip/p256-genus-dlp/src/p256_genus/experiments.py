"""Reproducible algebra, independent toy DLPs, and exact toy zeta functions."""

from math import gcd, log2
import sympy as sp

from .params import P, B, N, G
from .elliptic import EllipticCurve
from .curves import (T, equation, family_expression, cover_degree, fiber_polynomials,
                     mumford_transfer, decode_mumford_image)
from .jacobian import OddJacobian
from .dlp import bsgs
from .finitefield import TinyField, frobenius_polynomial


def verify():
    beta = sp.Symbol("b")
    e = EllipticCurve(P, B)
    assert e.contains(G) and e.mul(N, G) is None
    assert sp.isprime(P) and sp.isprime(N)
    rows = []
    for g in (2, 3, 4, 5):
        h = family_expression(g, beta)
        x, denominator = (T+1/T, T**2) if g == 3 else (T**cover_degree(g), 1)
        # Compare mod p, so SymPy's symmetric coefficient convention is harmless.
        difference = sp.cancel(h-denominator**2*(x**3-3*x+beta))
        assert sp.Poly(difference, T, beta, modulus=P).is_zero
        f = equation(g, B, P)
        assert sp.gcd(f, f.diff()).degree() == 0
        assert (f.degree()-1)//2 == g and gcd(cover_degree(g), N) == 1
        for k in (1, 2, 17):
            point = e.mul(k, G)
            u, v = fiber_polynomials(g, point, P)
            assert (f-v*v).rem(u).is_zero
        rows.append({"genus": g, "degree": cover_degree(g), "polynomial_degree": f.degree(),
                     "squarefree": True, "map_identity": True, "fiber_checks": 3})
    arithmetic = []
    for g in (3, 4):
        j = OddJacobian(equation(g, B, P))
        image = mumford_transfer(g, G, P)
        assert j.valid(image)
        assert decode_mumford_image(g, image, P) == G
        assert j.mul(N, image) == j.zero
        for k in (2, 3, 17):
            computed = j.mul(k, image)
            assert computed == mumford_transfer(g, e.mul(k, G), P)
            assert decode_mumford_image(g, computed, P) == e.mul(k, G)
        arithmetic.append({"genus": g, "order_n_check": True, "scalar_checks": [2, 3, 17],
                           "direct_inverse_checks": True})
    # Extra quotients, with b symbolic, including the genus-5 complementary curve.
    h2 = T**6-3*T**2+beta
    u = beta/T**2
    assert sp.cancel(beta**2*h2/T**6-(u**3-3*u**2+beta**2)) == 0
    h3 = T**7+beta*T**4+T
    assert sp.expand(T**2*h3-((T**3)**3+beta*(T**3)**2+T**3)) == 0
    h5 = T**12-3*T**4+beta
    assert sp.expand(T**2*h5-((T**2)**7-3*(T**2)**3+beta*T**2)) == 0
    # The second E quotient and differential independence for genus 3.
    zeta = sp.Symbol("zeta")
    x = zeta*T+zeta**2/T
    numerator = sp.cancel(h3-T**4*(x**3-3*x+beta))
    assert sp.rem(sp.Poly(numerator, zeta), sp.Poly(zeta*zeta+zeta+1, zeta)).is_zero
    determinant = sp.Matrix([[-1, 0, 1], [-zeta**2, 0, zeta], [0, 3, 0]]).det()
    assert sp.rem(sp.Poly(determinant, zeta), sp.Poly(zeta*zeta+zeta+1, zeta)).as_expr() != 0
    assert P % 3 == 1
    return {"field_bits": P.bit_length(), "subgroup_order_hex": hex(N),
            "generic_subgroup_security_bits": log2(N)/2,
            "covers": rows, "independent_real_field_jacobian_checks": arithmetic,
            "extra_quotient_map_identities": True, "p_mod_3": P % 3}


def toy_dlp(primes=(1009, 4001, 65537)):
    rows = []
    for p in primes:
        b = B % p
        if b == 0 or (b*b-4) % p == 0:
            continue
        e = EllipticCurve(p, b)
        total = e.count_points()
        n = max(int(v) for v in sp.factorint(total))
        if n <= 5:
            continue
        generator = None
        for x in range(p):
            roots = sp.sqrt_mod(e.rhs(x), p, all_roots=True)
            if roots:
                candidate = e.mul(total//n, (x, int(roots[0])))
                if candidate is not None:
                    generator = candidate
                    break
        assert generator is not None and e.mul(n, generator) is None
        secret = (n//3+7) % n
        target = e.mul(secret, generator)
        recovered, ec_steps = bsgs(generator, target, n, None, e.add, e.neg, e.mul, lambda x: x)
        assert recovered == secret
        row = {"p": p, "b": b, "elliptic_order": total, "prime_subgroup_order": n,
               "known_test_scalar": secret, "elliptic_bsgs_additions": ec_steps, "jacobians": []}
        for g in (3, 4):
            j = OddJacobian(equation(g, b, p))
            gg, qq = mumford_transfer(g, generator, p), mumford_transfer(g, target, p)
            assert j.valid(gg) and j.valid(qq)
            assert j.mul(n, gg) == j.zero
            assert j.mul(secret, gg) == qq
            recovered, steps = bsgs(gg, qq, n, j.zero, j.add, j.neg, j.mul, j.key)
            assert recovered == secret
            row["jacobians"].append({"genus": g, "recovered_scalar": recovered,
                                     "bsgs_additions": steps, "order_n_check": True})
        rows.append(row)
    return {"scope": "Independent Cantor arithmetic for genera 3/4; toy fields only.",
            "operation_count_scope": "BSGS table/search additions; excludes scalar multiplications and hashing.",
            "experiments": rows}


def toy_zeta(q=7, b=1):
    """Small independent family member, not reduction of P-256's b (which is 0 mod 7)."""
    expressions = {f"C{g}": equation(g, b, q).as_expr() for g in (2, 3, 4, 5)}
    expressions.update(E=T**3-3*T+b, F2=T**3-3*T**2+b*b,
                       F3=T**3+b*T**2+T, H5=T**7-3*T**3+b*T)
    genera = {name: (sp.degree(f, T)-1)//2 for name, f in expressions.items()}
    counts = {name: [] for name in expressions}
    for degree in range(1, 6):
        field = TinyField(q, degree)
        for name, f in expressions.items():
            if degree <= genera[name]:
                coefficients = sp.Poly(f, T).all_coeffs()
                counts[name].append(field.count_curve(coefficients))
    frobenius = {name: frobenius_polynomial(q, c) for name, c in counts.items()}
    assert frobenius["C2"] == frobenius["E"]*frobenius["F2"]
    assert q % 3 == 1
    assert frobenius["C3"] == frobenius["E"]**2*frobenius["F3"]
    assert frobenius["C5"] == frobenius["C2"]*frobenius["H5"]
    assert frobenius["C4"].rem(frobenius["E"]).is_zero
    return {"q": q, "b": b, "scope": "Toy family member, not the actual P-256 Jacobian orders.",
            "curves": {name: {"extension_point_counts": counts[name],
                               "frobenius_coefficients_descending": [int(c) for c in f.all_coeffs()],
                               "jacobian_order": int(f.eval(1))}
                       for name, f in frobenius.items()},
            "factorization_checks": {"J(C2) ~ E x F2": True, "J(C3) ~ E^2 x F3": True,
                                     "J(C5) ~ J(C2) x J(H5)": True, "E divides J(C4)": True}}
