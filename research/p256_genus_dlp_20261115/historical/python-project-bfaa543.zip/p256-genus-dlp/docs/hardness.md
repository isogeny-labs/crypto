# What changes when P-256 is transferred to these Jacobians?

The image of P-256 in each Jacobian is an efficiently isomorphic copy of the original prime-order group. The whole Jacobian is a larger, generally composite-order group with additional algebraic factors. These are different DLP settings and need separate analysis.

## 1. The curves are well-defined

Work over the standard P-256 field, of characteristic greater than 3. Let

\[
f(X)=X^3-3X+b,\qquad E:Y^2=f(X).
\]

For the actual coefficient, `b != 0` and `b^2 != 4 mod p`. Thus `f` is separable. The polynomials `f(t^d)` for `d=2,3,4` are also separable: their derivative can vanish at a root only if `t=0` and `b=0`, or if `f` has a repeated root. These give degrees 6, 9, and 12 and genera 2, 4, and 5.

The genus-3 polynomial is `t(t^6 + b t^3 + 1)`. Its roots are distinct because `b^2 != 4` and the characteristic is neither 2 nor 3. Its degree is 7, hence genus 3. The genus-3 map follows from

\[
(t+t^{-1})^3-3(t+t^{-1})=t^3+t^{-3}.
\]

Affine map formulas extend to morphisms of the smooth projective curves.

## 2. The transfer is a group embedding, with a computable inverse

For a cover `pi:C -> E` of degree `d`, let

\[
\Phi=\pi^*:E=\operatorname{Pic}^0(E)\longrightarrow J(C).
\]

The norm/pushforward identity is

\[
\pi_*\pi^*=[d].
\]

If `Phi(P)=0` and `[n]P=0`, then `[d]P=0`. Since `gcd(d,n)=1`, this forces `P=0`. All four transfers therefore inject the entire rational P-256 group, whose order is the prime `n`. On the image, the inverse is

\[
\Psi=[d^{-1}\bmod n]\pi_*.
\]

For fixed small cover degrees, these maps can be computed using divisor arithmetic, polynomial operations, and elliptic scalar multiplication; no discrete logarithm is needed. They are defined over the original base field. Individual points in a fiber may lie in extension fields while their sum is a rational divisor.

Given a P-256 DLP `(G,Q=kG)`, computing `(Phi(G),Phi(Q))` gives a Jacobian-image DLP with the same scalar. Conversely, applying `Psi` to an image DLP returns its elliptic DLP. This establishes polynomial-time equivalence, with modest fixed-genus overheads. It does not establish a lower bound on either problem's complexity.

### Divisor representatives and infinity

For an affine point `P=(u,v)`, define its fiber divisor `D_P` by:

| Genus | Fiber polynomial U(t) | z on the fiber | Pullback of O |
|---|---|---|---|
| 2 | `t^2-u` | `v` | `infinity+ + infinity-` |
| 3 | `t^2-u*t+1` | `v*t^2` | `infinity + T0`, with `T0=(0,0)` |
| 4 | `t^3-u` | `v` | `3*infinity` |
| 5 | `t^4-u` | `v` | `2*infinity+ + 2*infinity-` |

Fibers include multiplicities. The transferred class is `[D_P-pi^*(O)]`.

In genus 3, `[T0-infinity]` has order two, since `div(t)=2*T0-2*infinity`. This gives the reduced Mumford pair

\[
\Phi_3(u,v)=(t^3-ut^2+t,\ vt^2).
\]

For genus 4, the pair is simply

\[
\Phi_4(u,v)=(t^3-u,\ v).
\]

The identity maps to `(1,0)`. Ordinary one-infinity Mumford arithmetic must not be applied unchanged to the even-degree models C2/C5.

For these canonical genus-3/4 image representatives, inversion is even simpler than the general norm formula: read `u` and `v` from the displayed polynomial coefficients. `decode_mumford_image` implements this direct inverse and rejects divisors outside the explicit encoding. Thus these encodings expose the original elliptic public point directly; recovering the private scalar remains its DLP.

## 3. Classical attack costs

The subgroup order stays approximately `2^256`. Pollard rho therefore has expected work on the order of `sqrt(n)`, conventionally about `2^128` group operations. One may use the inverse map and run rho directly on P-256. Performing rho in a larger Jacobian generally increases the cost of a group operation.

The full Jacobian has order approximately `p^g`, but its size does not increase the order of the embedded subgroup. Furthermore, the Jacobians in this project split up to isogeny, as shown below. Applying a square-root estimate to the entire composite group order would ignore its factorization and the Pohlig-Hellman reduction.

For comparison, a standard fixed-genus double-large-prime hyperelliptic index-calculus estimate is heuristically

\[
\widetilde O(p^{2-2/g}),\qquad g\ge 3.
\]

The genus-2 comparison has exponent one. These estimates have smoothness and algorithm-model assumptions, suppressed constants, memory costs, and logarithmic factors. They are not exact costs or universal lower bounds for these specially structured curves.

| Genus | Approximate ambient order bits | Inherited P-256 attack exponent in base 2 | Standard field-size index-calculus comparison |
|---|---:|---:|---:|
| 2 | 512 | 128 | 256 |
| 3 | 768 | 128 | 341.3 |
| 4 | 1024 | 128 | 384 |
| 5 | 1280 | 128 | 409.6 |

The index-calculus column is much more expensive than attacking the known elliptic factor. The earlier rule of thumb `log2(q) ~ 256/g` concerns choosing a different, smaller field to match an ambient Jacobian size. It does not describe these maps: here `q=p` remains 256 bits.

Nonhyperelliptic genus-3 plane-quartic attack estimates should not be substituted for a hyperelliptic genus-3 model. Weil descent to a proper smaller subfield is also unavailable for this prime base field. The existence of extension-field fiber points does not change that fact.

## 4. Additional quotient factors

Write `~` for an isogeny over the stated field. This implies multiplication of Frobenius characteristic polynomials, and therefore multiplication of rational group orders, but does not mean an isomorphism of finite groups.

### Genus 2: two elliptic factors

In addition to the map to E, there is a second elliptic quotient

\[
F_2:v^2=u^3-3u^2+b^2,\qquad
(u,v)=\left(\frac b{t^2},\frac{bz}{t^3}\right).
\]

Pullbacks of `dX/Y` and `du/v` are `2t dt/z` and `-2 dt/z`. They span the two-dimensional differential space, giving

\[
J(C_2)\sim E\times F_2.
\]

### Genus 3: two copies of P-256's elliptic factor

For P-256, `p = 1 mod 3`, so a primitive cube root of unity `zeta` belongs to the base field. Two elliptic quotient maps to E are

\[
(X,Y)=\left(t+t^{-1},\frac z{t^2}\right),\qquad
(X,Y)=\left(\zeta t+\frac{\zeta^2}{t},\frac z{t^2}\right).
\]

A third quotient is

\[
F_3:v^2=u^3+bu^2+u,\qquad (u,v)=(t^3,tz).
\]

The three differential pullbacks are

\[
(t^2-1)\frac{dt}{z},\quad
(\zeta t^2-\zeta^2)\frac{dt}{z},\quad
3t\frac{dt}{z}.
\]

They are independent, so the induced homomorphism to `E x E x F3` is a separable isogeny:

\[
\boxed{J(C_3)\sim E^2\times F_3.}
\]

The base-field condition matters: this particular decomposition into two copies of E is not claimed over fields without cube roots of unity. Multiple copies of the same elliptic group do not yield independent secret scalars when all public points are images of a single P-256 instance.

### Genus 4: elliptic factor and a three-dimensional complement

For the degree-three cover to E, the connected component of the norm kernel is an abelian variety A3 of dimension three. The pullback-norm identities give

\[
J(C_4)\sim E\times A_3.
\]

The project does not claim A3 is simple, identify its actual-field order, or assign it a security level.

### Genus 5: two elliptic factors and a genus-3 Jacobian

The involutions `(t,z) -> (-t,z)` and `(t,z) -> (-t,-z)` give quotients C2 and

\[
H_5:v^2=u^7-3u^3+bu,
\]

using `(u,v)=(t^2,z)` for C2 and `(u,v)=(t^2,tz)` for H5. Their differential pullbacks span the odd-indexed and even-indexed monomials in the genus-5 differential basis, respectively. Thus

\[
J(C_5)\sim J(C_2)\times J(H_5)
           \sim E\times F_2\times J(H_5).
\]

Further splitting and the actual-field subgroup structure of J(H5) are not determined here.

### Consequences for actual-field group orders

Let `n = #E(F_p)`, the known P-256 prime order. The proven isogenies imply the exact identities

| Jacobian | Rational group order |
|---|---|
| J(C2) | `n * #F2(F_p)` |
| J(C3) | `n^2 * #F3(F_p)` |
| J(C4) | `n * #A3(F_p)` |
| J(C5) | `n * #F2(F_p) * #J(H5)(F_p)` |

These are identities for the actual P-256 field, even though the complementary orders have not been computed numerically. An `n^2` factor in the ambient order does not imply a cyclic subgroup of order `n^2`; group order and group structure are distinct.

## 5. What the experiments establish

The `verify` experiment checks all four maps, genera, fibers, and parameter sanity conditions in the actual P-256 field. For genera 3/4 it independently computes Jacobian scalar multiples and checks the order of the nonzero transferred generator. It never attempts a P-256 DLP.

The `toy-dlp` experiment computes elliptic group orders over small primes, selects prime-order subgroups, and solves the same known-scalar instance with BSGS independently on E and on the genus-3/4 Jacobians. The Cantor implementation uses polynomial arithmetic and does not delegate its group law to E. BSGS addition counts exclude scalar multiplication used for the stride and verification, as well as hashing; they should not be interpreted as total field-operation counts.

The `toy-zeta` experiment counts points over extension fields through degree g, uses Newton identities plus the functional equation to recover each Frobenius polynomial, and checks the isogeny factorizations. Its parameters are `q=7,b=1`, a nonsingular member of the same family. They are deliberately not a reduction of P-256's coefficient. Finite tests support the implementation; the algebraic arguments above establish the general reductions and isogenies.

No actual-field order or factorization has been computed for the complementary factors. Their DLP hardness remains unassessed. The known P-256 image is the part whose hardness transfers exactly.

For a DLP with a different base point elsewhere in a Jacobian, first determine its subgroup order and projections onto these factors. The genus and approximate size of the full Jacobian alone do not determine that instance's security. In particular, a subgroup supported only on a complementary factor needs its own analysis.

## References

- [SEC 2, version 2, section 2.4.2](https://www.secg.org/sec2-v2.pdf): secp256r1 parameters.
- [NIST SP 800-57 Part 1 Revision 5](https://doi.org/10.6028/NIST.SP.800-57pt1r5): conventional security-strength comparisons.
- J. M. Pollard, [Monte Carlo methods for index computation (mod p)](https://doi.org/10.1090/S0025-5718-1978-0491431-9), Mathematics of Computation 32 (1978), 918–924.
- P. Gaudry, E. Thomé, N. Thériault and C. Diem, [A double large prime variation for small genus hyperelliptic index calculus](https://doi.org/10.1090/S0025-5718-06-01900-4), Mathematics of Computation 76 (2007), 475–492.
- D. G. Cantor, [Computing in the Jacobian of a hyperelliptic curve](https://doi.org/10.1090/S0025-5718-1987-0866101-0), Mathematics of Computation 48 (1987), 95–101.

The specific quotient formulas and differential independence checks in this document are derived explicitly here; the references are not being cited as sources for these exact P-256 constructions.
