import unittest
import sympy as sp

from p256_genus.curves import T, equation, fiber_polynomials, mumford_transfer, decode_mumford_image
from p256_genus.elliptic import EllipticCurve
from p256_genus.jacobian import OddJacobian
from p256_genus.finitefield import TinyField, frobenius_polynomial
from p256_genus.experiments import toy_dlp


class ConstructionTests(unittest.TestCase):
    def test_all_toy_fibers_and_transfer_homomorphisms(self):
        # Exhaust every affine E(F_13) point, including possible special fibers.
        p, b = 13, 1
        e = EllipticCurve(p, b)
        points = [(x, y) for x in range(p) for y in range(p) if e.contains((x, y))]
        for g in (2, 3, 4, 5):
            f = equation(g, b, p)
            for point in points:
                u, v = fiber_polynomials(g, point, p)
                self.assertTrue((f-v*v).rem(u).is_zero)
        for g in (3, 4):
            j = OddJacobian(equation(g, b, p))
            for left in [None] + points:
                ll = mumford_transfer(g, left, p)
                self.assertTrue(j.valid(ll))
                self.assertEqual(decode_mumford_image(g, ll, p), left)
                self.assertEqual(j.add(ll, j.neg(ll)), j.zero)
                for right in [None] + points:
                    rr = mumford_transfer(g, right, p)
                    self.assertEqual(j.add(ll, rr), mumford_transfer(g, e.add(left, right), p))

    def test_cantor_on_divisors_outside_the_elliptic_image(self):
        # Single-point divisors and their sums independently exercise reduction.
        p = 13
        for g in (3, 4):
            f = equation(g, 1, p)
            j = OddJacobian(f)
            divisors = []
            for x in range(p):
                for y in range(p):
                    if (int(f.eval(x))-y*y) % p == 0:
                        divisors.append((j.poly(T-x), j.poly(y)))
            a, b, c = divisors[0], divisors[3], divisors[-1]
            with self.assertRaises(ValueError):
                decode_mumford_image(g, b, p)
            self.assertEqual(j.add(j.add(a, b), c), j.add(a, j.add(b, c)))
            for k in range(1, 12):
                result = j.mul(k, a)
                self.assertTrue(j.valid(result))
                self.assertEqual(j.add(result, j.neg(result)), j.zero)

    def test_even_degree_is_explicitly_rejected(self):
        for g in (2, 5):
            with self.assertRaises(ValueError):
                OddJacobian(equation(g, 1, 13))
            with self.assertRaises(ValueError):
                mumford_transfer(g, (1, 1), 13)

    def test_extension_field(self):
        field = TinyField(7, 2)
        for a in range(field.size):
            self.assertEqual(field.mul(a, 1), a)
            self.assertEqual(field.add(a, field.scale(a, -1)), 0)
            if a:
                value = 1
                for _ in range(field.size-1):
                    value = field.mul(value, a)
                self.assertEqual(value, 1)
        e = EllipticCurve(7, 1)
        trace = 8-e.count_points()
        self.assertEqual(field.count_curve([1, 0, -3, 1]), 50-(trace*trace-14))
        frobenius = frobenius_polynomial(7, [e.count_points()])
        self.assertEqual(int(frobenius.eval(1)), e.count_points())

    def test_independent_toy_discrete_logs(self):
        result = toy_dlp((1009,))
        self.assertEqual(len(result["experiments"]), 1)
        row = result["experiments"][0]
        for image in row["jacobians"]:
            self.assertEqual(image["recovered_scalar"], row["known_test_scalar"])


if __name__ == "__main__":
    unittest.main()
