import Field29

namespace VerheulDistortionAudit
noncomputable section
private instance prime5_concrete : Fact (Nat.Prime 5) := ⟨by decide⟩

abbrev repaired := correctedHom (1 : Extension) omega extension_discriminant omega_cube
abbrev repairedEquiv := correctedEquiv (1 : Extension) omega extension_discriminant omega_cube
def Q : (model (1 : Extension)).Point := repaired P

theorem printed_formula_not_on_curve :
    ¬ (model (1 : Extension)).Equation 4 (omega*6) := by
  apply printed_map_fails 1 4 6 omega omega_cube omega_ne_one (by decide +kernel)
  rw [equation_iff]
  decide +kernel

theorem corrected_formula_on_curve : (model (1 : Extension)).Equation (omega*4) 6 := by
  apply (corrected_equation 1 4 6 omega omega_cube).mpr
  rw [equation_iff]
  decide +kernel

theorem Q_ne_zero : Q≠0 := by decide +kernel

theorem Q_five : (5 : ℕ) • Q=0 := by
  change 5 • repaired P=0
  rw [← map_nsmul,P_five,map_zero]

theorem Q_order : addOrderOf Q=5 := addOrderOf_eq_prime Q_five Q_ne_zero

theorem Q_not_small_multiple (i : Fin 5) : Q ≠ i.val • P := by
  fin_cases i <;> decide +kernel

theorem Q_not_nsmul (n : ℕ) : Q ≠ n • P := by
  have hm : (n%5) • P=n • P := by simpa only [P_order] using mod_addOrderOf_nsmul P n
  rw [← hm]
  exact Q_not_small_multiple ⟨n%5,Nat.mod_lt _ (by omega)⟩

theorem cyclotomic_degree_two :
    ¬ 5∣29-1 ∧ 5∣29^2-1 ∧ Nat.Prime 29 ∧ Nat.Prime 5 ∧ 3<29 ∧ 3<5 ∧
      29%3=2 ∧ Nat.Coprime 5 29 := by decide +kernel

/-- The literal printed formula cannot be an endomorphism, already on the
actual source-qualified point of prime order five. -/
theorem no_point_map_with_printed_coordinates :
    ¬ (∃ D : (model (1 : Extension)).Point → (model (1 : Extension)).Point,
      ∃ h : (model (1 : Extension)).Nonsingular 4 (omega*6), D P=.some 4 (omega*6) h) := by
  rintro ⟨D,h,he⟩
  exact printed_formula_not_on_curve h.1

end
end VerheulDistortionAudit
