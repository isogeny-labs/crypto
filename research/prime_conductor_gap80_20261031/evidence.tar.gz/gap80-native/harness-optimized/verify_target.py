"""Independent root oracle on actual 80-bit kernel tiles; not a full map."""
import json
from pathlib import Path
from sage.all import EllipticCurve, GF, ZZ
from blocked_velu import tile, _choose_IJK

root = Path('/workspace/gap80-native')
d = json.loads((root/'parameters80.json').read_text())
F = GF(ZZ(d['p']))
E = EllipticCurve(F, list(map(ZZ, d['source_coefficients'])))
ell = ZZ(d['ell'])
K = E(tuple(map(ZZ, d['kernel'])))
G = E(tuple(map(ZZ, d['generator'])))
assert K and ell*K == E(0) and G and ZZ(d['q'])*G == E(0)
K.set_order(ell)
I,J,_ = _choose_IJK(ell)
I,J = I[:8],J[:8]
roots = [((i+s*j)*K)[0] for i in I for j in J for s in (1,-1)]
assert len(set(roots)) == len(roots) == 128
alphas = [(s*G)[0] for s in range(1,33)]
expected = [(-sum(roots),-sum(x*x for x in roots)/2,-sum(x*x*x for x in roots)/3)]
for alpha in alphas:
    ratios = [1/(alpha-x) for x in roots]
    expected.append((sum(ratios),-sum(x*x for x in ratios)/2,sum(x*x*x for x in ratios)/3))
for backend in ('sage','flint','prime'):
    assert tile(E,K,I,J,[None]+alphas,backend) == expected
result = {'status':'pass','ell':str(ell),'ell_bits':int(ell.nbits()),
          'independent_roots':128,'nonkernel_scalar_contexts':32,
          'backends':['sage','flint','prime'],
          'scope':'One 8x8 tile checked by direct enumeration at 32 non-kernel points. No complete isogeny images.'}
(root/'target80-root-oracle.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
