80-bit prime-conductor candidate and native log-norm optimization
==============================================================

Scope: preserve the requested explicitly evaluated ordinary-isogeny crossing
criterion. Source/kernel verification and partial sums do not meet it.

The native C optimization replaces three trace-only polynomial multiplications
with one shared Newton-sum vector and three coefficient dot products. For monic
h of degree n, rev(h')/rev(h) has coefficients Tr(1),Tr(X),...,Tr(X^(n-1)).
The reversed-modulus inverse is also reused in three modular products.
Nonmonic h is now rejected explicitly; the previous trace rule assumed monic h.
An early-return memory leak for invalid/nonprime modulus inputs was repaired.
baseline.c is the frozen previous native implementation; trace-only.c preserves
the first optimization; optimized.c includes reciprocal reuse as well.

Native candidate construction uses the existing CM(-7) family:
 p=(1+k*ell)^2+7*ell^2, t=2*(1+k*ell), #E=8*q*ell^2,
 k=3000031, q=(k^2+7)/8. ell is inert in Q(sqrt(-7)).
Both quadratic twists are tested: this instance needs y^2=x^3-140*x+784.
The j=-3375 ordinary CM source has maximal endomorphism order. An ell-order
kernel gives an ell-isogeny whose codomain has endomorphism conductor ell,
because inert ell precludes a horizontal edge. This is a structural argument,
not an explicit codomain computation. It is not an arithmetic conductor gap
over Q, which is invariant under Q-isogeny.

parameters80.json is the deterministic native search output. Its replay is
byte-identical. PARI independently checks primality, CM invariant, norm and
trace identities, point membership, the trace-sign witness and prime subgroup
orders. p-primecert.txt is the replayable PARI field-prime certificate; the
80-bit ell also has a small Pocklington witness in the parameters file.
verify80.gp regenerates and verifies the field certificate. No world-record
claim follows from these source/kernel checks.

Rebuild and verify (environment: /workspace/env/sage, FLINT 3.3.1):
 sh /workspace/gap80-native/build.sh
 /workspace/gap80-native/check
 /workspace/gap80-native/search80
 /workspace/gap80-native/pari_verify /workspace/gap80-native/verify80.gp
 DOT_SAGE=/workspace/.sage /workspace/env/sage/bin/python /workspace/gap80-native/harness-optimized/blocked_velu.py --selftest --output /tmp/fixtures80.json
 DOT_SAGE=/workspace/.sage /workspace/env/sage/bin/python /workspace/gap80-native/harness-optimized/verify_target.py

The two harness directories preserve copies of the prior Sage fixture/tile
harness and text boundary. Only target-specific wording was generalized in
blocked_velu.py; the optimized directory loads the new native library.
They are validation harnesses, not a new implementation of the optimization.
Complete small-degree fixtures are checked against traditional Sage Velu.
The actual 80-bit direct-root oracle checks one 8x8 rectangle at 32 non-kernel
scalar contexts. No complete 80-bit point image is produced.

Timing protocol:
 Native helper: seven alternating-order paired calls per measured degree.
 The random polynomial input is deterministic and the same within each pair.
 These microbenchmarks were not CPU-pinned; report their limited scope.
 Actual target tile: seven paired repeats, block 4096, same kernel and contexts.
 Repeats 1-3 were unpinned; repeat 1 overlapped the fixture selftest. Repeats
 4-7 were pinned to CPU 0; repeat 4 overlapped the small root-oracle check.
 Retain every receipt, but use only repeats 5-7 for the clean pinned comparison.
 These evaluate the same partial tile repeatedly, not complete isogenies or
 independent targets. Peak RSS includes Sage/process state. No ECDLP comparison
 or end-to-end speedup is measured.

Known execution issues retained here:
 Initial C benchmark build lacked fmpz headers; corrected before benchmarking.
 Initial candidate search tried only one twist and failed; both twists are now
 tested and verified independently. No failed output is treated as a candidate.
 Initial Sage validation could not write /home/agent/.sage; DOT_SAGE was set
 to /workspace/.sage. The optional /usr/bin/time wrapper was unavailable, so
 resource capture was implemented natively and the deterministic search replayed.

Remaining blocker: the full 80-bit I/J grid has 427154957034 indices per side.
At block 4096 it needs 10875544558802641 rectangular tiles and 722432689208
leftover roots. No full-grid run is running. Native helper savings do not
establish feasible total work. A different scalable construction/evaluation
method is needed before the explicit quotient, complete images and matched
endpoint ECDLP trials can be delivered. Neither 60 nor 80-bit crossing is
claimed here. See results.json for measured scope and requirement status.
