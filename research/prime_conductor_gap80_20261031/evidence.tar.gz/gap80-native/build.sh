#!/bin/sh
set -eu
cd /workspace/gap80-native
P=/workspace/env/sage
gcc -O3 -Wall -Wextra -std=c11 -I"$P/include" -Dprime_log_norm_jet=baseline -Dprime_log_norm_free=baseline_free -c baseline.c -o baseline.o
gcc -O3 -Wall -Wextra -std=c11 -I"$P/include" -Dprime_log_norm_jet=optimized -Dprime_log_norm_free=optimized_free -c optimized.c -o optimized.o
gcc -O3 -Wall -Wextra -std=c11 -I"$P/include" bench.c baseline.o optimized.o -L"$P/lib" -Wl,-rpath,"$P/lib" -lflint -lgmp -o bench
gcc -O3 -Wall -Wextra -std=c11 -I"$P/include" check.c optimized.o -L"$P/lib" -Wl,-rpath,"$P/lib" -lflint -lgmp -o check
gcc -O3 -Wall -Wextra -std=c11 -I"$P/include" search80.c -L"$P/lib" -Wl,-rpath,"$P/lib" -lflint -lgmp -o search80
gcc -O2 -Wall -Wextra -I"$P/include" pari_verify.c -L"$P/lib" -Wl,-rpath,"$P/lib" -lpari -o pari_verify
gcc -shared -O3 -fPIC -std=c11 -I"$P/include" optimized.c -L"$P/lib" -Wl,-rpath,"$P/lib" -lflint -lgmp -o harness-optimized/libprime_poly_trace.so
