#!/usr/bin/env bash
set -u
cd /workspace/crypto-twist-tr04 || exit 2
export CARGO_BUILD_JOBS=2
export CARGO_TARGET_DIR="$PWD/tools/twist-relations/target"
date -u +%FT%TZ > /workspace/pr2890-maintenance-20261030T1244/validation.started
cargo fmt --manifest-path tools/twist-relations/Cargo.toml --check > /workspace/pr2890-maintenance-20261030T1244/fmt.log 2>&1
pr2890_fmt=$?
cargo clippy --release --offline --locked --manifest-path tools/twist-relations/Cargo.toml --all-targets -- -D warnings > /workspace/pr2890-maintenance-20261030T1244/clippy.log 2>&1
pr2890_clippy=$?
cargo test --release --offline --locked --manifest-path tools/twist-relations/Cargo.toml > /workspace/pr2890-maintenance-20261030T1244/native-tests.log 2>&1
pr2890_tests=$?
PATH="/workspace/tr04-dev-tools:$PATH" /workspace/tr04-dev-tools/actionlint .github/workflows/twist-relations.yml > /workspace/pr2890-maintenance-20261030T1244/actionlint.log 2>&1
pr2890_actionlint=$?
NODE_PATH=/workspace/pr2890-checkin-20261030T0029/pattern-fixture/node_modules node /workspace/pr2890-maintenance-20261030T1244/routing.cjs > /workspace/pr2890-maintenance-20261030T1244/routing.log 2>&1
pr2890_routing=$?
tools/twist-relations/target/release/tr04-protocol validate research/twist_relations_tr04_20261029/protocol.json > /workspace/pr2890-maintenance-20261030T1244/protocol.log 2>&1
pr2890_protocol=$?
date -u +%FT%TZ > /workspace/pr2890-maintenance-20261030T1244/validation.finished
node - "$pr2890_fmt" "$pr2890_clippy" "$pr2890_tests" "$pr2890_actionlint" "$pr2890_routing" "$pr2890_protocol" <<'NODE'
const fs=require('fs'),cp=require('child_process');
const dir='/workspace/pr2890-maintenance-20261030T1244',labels=['fmt','clippy','tests','actionlint_shellcheck','routing','protocol'];
const exits=Object.fromEntries(labels.map((l,i)=>[l,Number(process.argv[2+i])]));
const receipt={schema:'pr2890.affected-development-validation/v1',started_at:fs.readFileSync(dir+'/validation.started','utf8').trim(),finished_at:fs.readFileSync(dir+'/validation.finished','utf8').trim(),source_merge:cp.execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),exits,scope:'Standalone native crate and unchanged workflow development checks only; no primary research or broad-library rerun.'};
fs.writeFileSync(dir+'/validation.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt));
if(Object.values(exits).some(x=>x!==0))process.exitCode=1;
NODE

