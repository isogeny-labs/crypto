#!/usr/bin/env bash
# Development transport fixtures: actual maintained artifact tool, fake AWS.
set -euo pipefail
source_root=/workspace/crypto-twist-tr04
fixture_root=$(mktemp -d /workspace/tr04-delivery-transport.XXXXXX)
mkdir "$fixture_root/fake-bin"
cat > "$fixture_root/fake-bin/aws" <<'AWS'
#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' "$1 $2" >> "$FIXTURE_CALLS"
operation="$1 $2"
shift 2
case "$operation" in
  's3api head-object'|'s3api put-object')
    key=
    body=
    while (( $# )); do
      case "$1" in
        --key) key=$2; shift 2 ;;
        --body) body=$2; shift 2 ;;
        *) shift ;;
      esac
    done
    object="$FIXTURE_REMOTE/$key"
    if [[ "$operation" == 's3api head-object' ]]; then
      if [[ ! -f "$object" ]]; then echo 'Not Found (404)' >&2; exit 254; fi
      checksum=$(openssl dgst -sha256 -binary "$object" | base64 -w 0)
      jq -n --argjson size "$(stat -c %s "$object")" --arg checksum "$checksum" '{ContentLength:$size,ChecksumSHA256:$checksum}'
    else
      if [[ "$FIXTURE_MODE" == push_fail ]]; then echo 'Fixture upload denial' >&2; exit 37; fi
      mkdir -p "$(dirname "$object")"
      cp "$body" "$object"
      checksum=$(openssl dgst -sha256 -binary "$object" | base64 -w 0)
      jq -n --arg checksum "$checksum" '{ChecksumSHA256:$checksum}'
    fi
    ;;
  's3 cp')
    if [[ "$FIXTURE_MODE" == readback_fail ]]; then echo 'Fixture GET denial' >&2; exit 43; fi
    remote=$1
    destination=$2
    key=${remote#s3://setec-astronomy-artifacts/}
    mkdir -p "$(dirname "$destination")"
    if [[ "$FIXTURE_MODE" == corrupt_readback ]]; then printf 'Corrupted fixture bytes\n' > "$destination"; else cp "$FIXTURE_REMOTE/$key" "$destination"; fi
    ;;
  *) echo "Unexpected fake AWS operation $operation" >&2; exit 97 ;;
esac
AWS
chmod +x "$fixture_root/fake-bin/aws"

make_fixture() {
  local name=$1
  local path="$fixture_root/$name"
  mkdir -p "$path/tools/twist-relations" "$path/tools/artifacts" "$path/.artifacts" \
    "$path/research/twist_relations_tr04_20261029"
  cp "$source_root/tools/twist-relations/run-tr04-delivery.sh" "$path/tools/twist-relations/"
  cp "$source_root/tools/artifacts/artifacts.py" "$path/tools/artifacts/"
  cp "$source_root/.artifacts/config.json" "$path/.artifacts/"
  printf '{"fixture":"SYNTHETIC TRANSPORT ONLY; no research execution"}\n' > "$path/research/twist_relations_tr04_20261029/protocol.json"
  git -C "$path" init -q
  git -C "$path" add .
  GIT_AUTHOR_DATE=2026-01-01T00:00:00Z GIT_COMMITTER_DATE=2026-01-01T00:00:00Z \
    git -C "$path" -c core.hooksPath=/dev/null -c commit.gpgsign=false \
    -c user.name='TR04 fixture' -c user.email=tr04@example.invalid commit -qm 'Synthetic transport fixture'
  mkdir -p "$path/artifacts/tr04-inputs/tr04-p7-1000-1/results" "$path/artifacts/tr04-preflight-input" \
    "$path/artifacts/tr04-summary/report" "$path/runner-temp" "$path/cache-existing" "$path/remote"
  printf '{"fixture":true,"status":"failed"}\n' > "$path/artifacts/tr04-inputs/tr04-p7-1000-1/results/manifest.json"
  printf '{"fixture":true,"scope":"no primary data"}\n' > "$path/artifacts/tr04-preflight-input/execution.json"
  printf '{"fixture":true,"status":"incomplete"}\n' > "$path/artifacts/tr04-summary/report/export.json"
}

run_fixture() {
  local name=$1 mode=$2 expected=$3
  local path="$fixture_root/$name"
  make_fixture "$name"
  local source_sha
  source_sha=$(git -C "$path" rev-parse HEAD)
  local key=fixture-not-a-secret secret=fixture-not-a-secret
  if [[ "$mode" == missing_credentials ]]; then key=; fi
  if [[ "$mode" == dirty_source ]]; then printf 'dirty\n' >> "$path/research/twist_relations_tr04_20261029/protocol.json"; fi
  set +e
  (
    cd "$path" || exit 98
    PATH="$fixture_root/fake-bin:$PATH" RUNNER_TEMP="$path/runner-temp" \
    GITHUB_RUN_ID=1000 GITHUB_RUN_ATTEMPT=1 TR04_SOURCE_REVISION="$source_sha" \
    AWS_ACCESS_KEY_ID="$key" AWS_SECRET_ACCESS_KEY="$secret" AWS_REGION=us-west-2 \
    ARTIFACTS_CACHE="$path/cache-existing" FIXTURE_REMOTE="$path/remote" \
    FIXTURE_CALLS="$path/aws-calls.txt" FIXTURE_MODE="$mode" \
    TR04_AGGREGATE_OUTCOME=failure TR04_CHECKPOINT_OUTCOME=success \
      bash tools/twist-relations/run-tr04-delivery.sh > "$path/stdout.log" 2> "$path/stderr.log"
  )
  local status=$?
  set -e
  [[ "$status" == "$expected" ]] || { echo "FAIL $name exit=$status expected=$expected"; cat "$path/stderr.log"; exit 1; }
  local outcome="$path/artifacts/tr04-delivery/run-1000-attempt-1/delivery.json"
  jq -e --argjson expected "$expected" '.delivery_exit_code==$expected and .aggregate_step_outcome=="failure" and .aggregate_checkpoint_outcome=="success"' "$outcome" >/dev/null
  case "$mode" in
    success)
      jq -e '.stage=="complete" and .independent_remote_download_verified==true and .push_exit_code==0 and .readback_exit_code==0 and .byte_compare_exit_code==0' "$outcome" >/dev/null
      [[ $(rg -c '^s3 cp$' "$path/aws-calls.txt") == 1 ]]
      test -f "$path/artifacts/tr04-delivery/run-1000-attempt-1/.artifacts.json"
      ;;
    push_fail) jq -e '.stage=="push" and .push_exit_code==2 and .independent_remote_download_verified==false and .readback_exit_code==null' "$outcome" >/dev/null ;;
    readback_fail|corrupt_readback) jq -e '.stage=="readback" and .push_exit_code==0 and .readback_exit_code==2 and .independent_remote_download_verified==false' "$outcome" >/dev/null ;;
    missing_credentials) jq -e '.stage=="credentials" and .push_exit_code==null and .archive_exit_code==0' "$outcome" >/dev/null; test ! -f "$path/aws-calls.txt" ;;
    dirty_source) jq -e '.stage=="source_check" and .archive_exit_code==null and .push_exit_code==null' "$outcome" >/dev/null; test ! -f "$path/aws-calls.txt" ;;
  esac
  printf 'PASS %s: exit%s, actual maintained tool and isolated fake AWS transport\n' "$name" "$status"
}

run_fixture success success 0
run_fixture success_repack success 0
cmp "$fixture_root/success/artifacts/tr04-delivery/run-1000-attempt-1/runs.tar.xz" \
  "$fixture_root/success_repack/artifacts/tr04-delivery/run-1000-attempt-1/runs.tar.xz"
echo 'PASS deterministic repacking of identical synthetic input trees'
run_fixture upload_denied push_fail 2
run_fixture download_denied readback_fail 2
run_fixture download_corrupt corrupt_readback 2
run_fixture credentials_missing missing_credentials 1
run_fixture source_dirty dirty_source 1
printf 'Fixture root: %s\n' "$fixture_root"
