TR04 DEVELOPMENT ONLY. Seven isolated synthetic artifact-transport cases use
the actual maintained infrastructure tool with a fake AWS filesystem driver.
No real S3 upload/download, primary experiment or success claim is present.
Also retained: static checks, existing wrapper/checkpoint stubs, byte-identical
native-source reuse check, and the intentionally superseded fe0 compilation
(Cargo101, compilerSIGTERM15 before tests, to select current-main source).
The original lost-session attempt and original development archive are separate.
Final root validation on445d84bf7 is active and is not included as a completed
result here. No clean pass, later-main validation or physical runtime admission.
