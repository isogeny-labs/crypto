## Goal
Exhaust the frozen TR-04 finite relation-finding scope, retaining selection failures and all paid-work counters.
## Lead / hypothesis
Test bounded twist-guided selection against equal-size random, progression and generic collision-avoiding controls. All matched arms run inside each field shard. This is generic decomposition, not algebraic or L2 speedup admission.
## Spec
research/twist_relations_tr04_20261029/protocol.json at source 85fc870c96a3ea707afe11e06cf884eba6f957ce; SHA-256 a9e631608a486eac8e6be711cbe621f8bfdff84fa49b22d741e7c50f6d3b60fe. Fields 7, 11, 19; B 2, 3; thresholds 1 through 4; selector budget 8; walk length 8. No algorithm parameters may be overridden by workflow inputs.
## State
Native development checks passed. No research shard has started. Source, protocol and workflow are pinned to GitHub run 40973940936 attempt 1.
## Next steps
For each p in 7, 11, 19, run bash tools/twist-relations/run-tr04-workflow.sh field p on crypto-eks-linux. The wrapper builds the locked release binary, invokes twist-tr04 --prime p --output-dir artifacts/tr04/p<prime>/results and verifies that directory. Aggregate all three immutable artifacts with the native summarize subcommand.
## Runs in flight
None. Three field jobs may start only after this checkpoint succeeds. GitHub workflow isogeny-labs/crypto/.github/workflows/twist-relations.yml@refs/heads/codex/twist-tr04-exhaustive-20261029, run 40973940936, attempt 1 will retain each command, source/binary/protocol hash, runner identity, log, output and exit status.
## Stop and success conditions
Maximum three parallel field jobs, each with a 30-minute workflow deadline and no automatic retry. Exhaust the declared finite cases and reject accounting/replay errors or missing/duplicate shards. Failed or interrupted prefixes never establish complete coverage or a passing final clock. All records are operation-count diagnostics, not admitted performance results.
