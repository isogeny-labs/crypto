TR04 DEVELOPMENT EVIDENCE ONLY. No primary finite census or remote submission.
Final native scope: 35 library + 2 legacy binary + 3 CLI tests =40 passed;
formatting and strict Clippy exit0. Full log and exit receipt authoritative.
Fixed known-answer preflight uses M3 and existing fixture, not primaryM8;
artifact replay passed. Timings are development calibration, not comparisons.
Synthetic partial-report-v2 is manufactured test input: one failed exported
attempt,26 absent/unattempted rows, expected CLI exit1, no researchresult.
Its PDF was generated before the later reporter crossbinding hardening;
the copied old analysis source/hash is intentionally preserved. Final native
checks include the later binding regression. Both PDF pages visually inspected.
The two-page draft study plan PDF was rendered/inspected independently.
Root library base24def3ae4dfe94bbbee5f30245847b372d02fa70 is INCOMPLETE:
first attempt missing tracked sparse input; second compilation session vanished
at environment handoff. No terminal summary, exit/signal or ongoing process
was observed. No repeated broad run was started in the bounded check-in.
Older source0044aaf9 completed validation and old4c871 SIGKILL evidence are
separate unchanged records, not validation for this new branch.
All logs, including earlier failed development checks, remain retained.
