#!/usr/bin/env bash
set -u
target=$1
attempt=$2
project=/workspace/crypto-audit/research/theriault_collision_audit_20261114/lean
record=/workspace/scratch/theriault-collision-attempts/$target-$attempt
mkdir -p "$record"
cd "$project" || exit 1
cp -- *.lean lakefile.toml lake-manifest.json lean-toolchain "$record/"
lake build "$target" > "/workspace/scratch/theriault-collision-$target-build$attempt.log" 2>&1
result=$?
printf '%s\n' "$result" > "/workspace/scratch/theriault-collision-$target-build$attempt.exit"
tail -n 65 "/workspace/scratch/theriault-collision-$target-build$attempt.log"
exit "$result"
