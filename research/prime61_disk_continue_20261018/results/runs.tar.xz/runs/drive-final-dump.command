timeout 300 /workspace/prime61-frozen-target/release/examples/isogeny_disk_walk dump research/prime61_disk_continue_20261018/spec.json /workspace/prime61-roundtrip-256/restored.db
