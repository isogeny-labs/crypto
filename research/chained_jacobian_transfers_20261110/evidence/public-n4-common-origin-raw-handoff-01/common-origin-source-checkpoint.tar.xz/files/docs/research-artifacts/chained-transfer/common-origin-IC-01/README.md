# Canonical whole common-origin report

The unchanged79,399-byte PDF is the two-page common-origin IC report. Its
research path is a transparent relative symlink,so the original PCC docs
hydration covers genuine managed data. Whole-data publication and a genuine
manifest remain pending the actual unchanged publisher. Editable report,
figures and sources remain under the research report directory. No policy,
workflow,verifier,keyring or trust changes. [pcc:unverified]
