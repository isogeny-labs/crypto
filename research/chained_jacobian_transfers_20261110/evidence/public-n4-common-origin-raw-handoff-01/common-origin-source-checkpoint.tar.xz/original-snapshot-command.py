"""Whole owned source checkpoint;no credentials or recursive publication data."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess
r=Path('/workspace/cryptanalysis');base='0a3412cd8e59abcd2eba8240371ad3ad394990a4';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==base
o=Path('/workspace/scratch/ct70-common-origin-source-checkpoint-01');o.mkdir()
scope=['experiments/chained-transfer-public-target','docs/chained-transfer-checkpoint-transport','docs/research-artifacts/chained-transfer/common-origin-IC-01','.github/workflows/chained-transfer-common-origin.yml','pcc/claims','pcc/ledger.jsonl','docs/session-logs/2026-11-14.md','.resume/RESUME.md','problems']
paths=set(subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard','-z','--',*scope],cwd=r).split(b'\0'))-{b''}
paths.add(b'experiments/chained-transfer-public-target/common-origin-ic/Cargo.lock')
excluded=[];members={}
for name in sorted(paths):
    rel=name.decode();p=r/rel
    if any(part.startswith('closed-ct70-')for part in p.parts)and p.name in ['whole-raw.tar.xz','members.json.xz']:
        excluded.append(dict(path=rel,reason='whole raw archive/index is separately in this same genuine data handoff;exclude recursive data duplication'));continue
    if not p.is_file():raise AssertionError(rel)
    dest=o/'files'/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    if p.is_symlink():dest.symlink_to(os.readlink(p))
    else:shutil.copyfile(p,dest)
    raw=p.read_bytes();members[rel]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),symlink_target=os.readlink(p)if p.is_symlink()else None)
assert all(hashlib.sha256((o/'files'/p).read_bytes()).hexdigest()==v['sha256']for p,v in members.items())
(o/'source-members.json').write_text(json.dumps(members,indent=2)+'\n')
(o/'base-and-restoration.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),repository='isogeny-labs/cryptanalysis',base=base,branch='research/chained-transfer-public-target-20261113',producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2',owned_files=len(members),restore='checkout exact base+pinned producer,copy files/ into consumer preserving symlink targets/types;apply recorded genuine data projections separately,do not fabricate manifests;then original guards/governance before continuation',scope='ALL owned pending source/report/editablefigures/754CI/workflow/PCC/ledger/resume/journal/protocol/custody metadata;NOT private global instructions/env/credentials;no recursive publication archive',excluded_whole_data=excluded,ledger_scope='exact prefix at this snapshot;subsequent own-snapshot custody/publication claims land later and remain separate',native='8a77f3/3304guards/all20pairs/51JSON',written='8ffc9c',report='6271ce/whole79399PDF+relativecanonicalalias',new_CI='d33ccd/754+self755/ninephases/51JSON/16workflows241native57digests pendingnewsourcefullCI',next='publish this whole data handoff/freshguard08/exactFF/genuineprojections/normalconsumercommit/755full+16CI;then countercoverage',current_checkpoint='ffe675 exact39e9 successful originalremote/local;laterdirtysourceisnotadmitted'),indent=2)+'\n')
(o/'tracked-worktree.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=r));shutil.copyfile(__file__,o/'original-snapshot-command.py')
print(json.dumps(dict(files=len(members),excluded_data=len(excluded),base=base)),flush=True)
