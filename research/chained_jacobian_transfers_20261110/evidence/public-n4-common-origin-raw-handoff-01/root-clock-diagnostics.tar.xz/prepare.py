"""Record prospective ordinary-unit diagnostics; never alter the original tests."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,shutil,subprocess
r=Path('/workspace/crypto');s=r/'research/chained_jacobian_transfers_20261110'
o=Path('/workspace/scratch/ct69-original-root-reap-diagnostics-01');o.mkdir()
before=json.loads(Path('/workspace/scratch/ct68-root-library-regression-03/before.json').read_text())
assert len(before)==2137 and all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
(o/'before.json').write_text(json.dumps(before,indent=2)+'\n')
for label,cmd in [('KB-status',['scripts/research-kb','status']),('KB-diagnostic',['scripts/research-kb','search','diagnostic reap publication regression time namespace clock container permissions','--top-k','8']),('KB-negative',['scripts/research-kb','search','publication collision resource journal pending failure original regression','--top-k','8']),('conductor',['conductor','check','--summary','Original root diagnostic reap unit failure isolation','--scope','path:research/chained_jacobian_transfers_20261110','--scope','path:pcc','--scope','path:docs/session-logs/2026-11-13.md'])]:
    try:p=subprocess.run(cmd,cwd=r,capture_output=True);code=p.returncode;raw=p.stdout+p.stderr
    except FileNotFoundError as e:code=127;raw=str(e).encode()
    (o/(label+'.log')).write_bytes(raw);(o/(label+'.exit')).write_text(str(code)+'\n')
text='''# Original diagnostic-reap failure isolation

2026-11-13,prospective before this exact-test replay. The unfiltered original
root retry03 terminated124 at1800s;two visible failure labels and unknown
suite totals are preserved in62aefb/9b8180. This follow-up does not replace
that required whole-suite result. [pcc:unverified]

Sources checked: unchanged src/cryptanalysis/ecbench/runner.rs lines2659–2845
(both exact tests,Root/tracking/journal,DiagnosticSessionClock::begin),
ROOT_LIBRARY_REPLAY_PROTOCOL_03.md and the whole original timeout log;
unchanged .claude/hooks/checkpoint-hook.sh ordinary-unit exception. KB
unavailable: no MCP tools,repository wrapper status and two exact/negative
queries report no executable;no novelty or absence inference. Conductor
unavailable127;scope is additive protocol/custody/journal/PCC only.
[pcc:unverified]

Question: where do the two existing diagnostic-reap tests panic on this
container? Competing hypotheses are an unsupported clock/environment read
and a resource-publication invariant failure. The first original panic and
backtrace identify the next discriminating source read;either result remains
bounded evidence for this binary/environment,not a full-suite diagnosis.
[pcc:unverified]

Invoke the SAME original binary with --exact and --nocapture separately for
ok_without_observed_reap_cannot_mark_or_read_sidecars and
publication_collision_preserves_previous_bytes_and_pending_failure.
Each invocation has120s timeout/one test thread/RUST_BACKTRACE=1,retains its
whole output and literal exit. No recompilation,test/source/ignore/namespace
or privilege change. Freeze all2137 original root inputs including binary
and authentic fixture before and after;hold07 also stays active. Outcomes
0/101/124 and all failure messages remain distinct. No expected pass is
assumed;only unchanged inputs and faithfully captured outcomes are required
for a diagnostic record. [pcc:unverified]

Ordinary unit diagnostics use the original documented nonexperiment opt-out:
append precise reason with original PCC and attempt original checkpoint push
before launch. Performance admission remains closed. Raw output lives at
/workspace/scratch/ct69-original-root-reap-diagnostics-01;the thin shell
launcher executes only the unchanged binary and hashes custody files.
After terminal results,read the actual failing source and choose a focused
remedy or independent environment route;never repeat an unchanged global
suite or weaken its requirements. [pcc:unverified]
'''
p=s/'ROOT_DIAGNOSTIC_REAP_PROTOCOL_01.md';p.write_text(text);shutil.copyfile(p,o/'prospective-protocol.md');shutil.copyfile(__file__,o/'prepare.py')
cl=subprocess.check_output(['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Prospective original root diagnostic-reap failure isolation after fullretry03 timeout124/two visible failures/unknowntotals. SAMEoriginalbinary/SHA82029f63/exacttwo tests separately120s/nocapture/backtrace/one thread/all2137guards beforeafter;no source/test/namespace/privilege/recompile change. Competing clockenvironment/publicationinvariant hypotheses;retain all actual exits and firstpanics/no assumedpass/notglobalreplacement. KB/conductor unavailable/localprimary source read;ordinaryunit exception/originalbypass+checkpointattempt required;not performance admission.','--proof','attestation:'+str(p.relative_to(r))],cwd=r,text=True).strip()
note='''\n## {at} — original diagnostic-reap failure isolation\n\n### What was done (commands, files, features)\nProspective {claim} freezes SAMEoriginalbinary/two exact failing tests separately120s/backtraces/all2137guards. Unfilteredroot03 remains124/fulltotalsunknown;hold07 remains active. [pcc:unverified]\n\n### Decisions made (and why)\nRead original runner tests/clock call and whole timeout labels before choosing isolation. KB unavailable (wrapper no executable,three receipts);conductor127. Diagnose first actual panics without changing source/environment or repeating whole suite. Ordinaryunit documentedoptout/PCCrecord/originalcheckpointattempt,not performance. [pcc:unverified]\n\n### Open threads (unfinished, pick up next time)\nRun/collect /workspace/scratch/ct69-original-root-reap-diagnostics-01.sh;native codes/backtraces/guards at matchingdirectory. Original artifactpublisher43525890255 inprogress for4125274f/13objects;then exactFF/all3455guards/genuineconsumer report/source730full/14CI. [pcc:unverified]\n\n### Errors (what went wrong, how it was handled)\nWhole root retry03 timeout124/two visiblefailures retained;cause unknown until exact diagnostics. No gate/test weakening. [pcc:unverified]\n'''.format(at=datetime.now(timezone.utc).isoformat(),claim=cl)
for p in [r/'docs/session-logs/2026-11-13.md',r/'.resume/RESUME.md']:
    with p.open('a')as f:f.write(note)
reason='Ordinary unchanged original root unit failure diagnostics after unfiltered required library timeout;two exact tests/backtraces only;not experiment,benchmark or paid launch;performance admission remains closed'
cmd='CHECKPOINT_SKIP=ordinary_original_unit_diagnostics SAME_ORIGINAL_BINARY --exact TWO_RECORDED_FAILURES --nocapture --test-threads=1'
p=subprocess.run(['python3','tools/pcc/pcc.py','ledger','append-bypass','--reason',reason,'--command',cmd],cwd=r,capture_output=True)
(o/'original-ledger-optout.log').write_bytes(p.stdout+p.stderr);(o/'original-ledger-optout.exit').write_text(str(p.returncode)+'\n');assert p.returncode==0
p=subprocess.run(['timeout','60','bash','scripts/checkpoint.sh','push'],cwd=r,capture_output=True)
(o/'original-checkpoint-push.log').write_bytes(p.stdout+p.stderr);(o/'original-checkpoint-push.exit').write_text(str(p.returncode)+'\n')
(o/'plan.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),protocol_claim=cl,original_binary='/workspace/scratch/ct55-g3-root-regression-01-build-cache/release/deps/crypto_lib-0f5740d1cfe22c09',original_binary_sha256='82029f639d326548a7d44ea0f55477880f0c50cf358edeec3a6827f22591a9bd',guard_count=2137,per_test_timeout_s=120,original_checkpoint_push_exit=p.returncode,scope='ordinary exact original unit diagnostics;full root124 not replaced;not experiment or benchmark'),indent=2)+'\n')
launcher=Path(str(o)+'.sh')
launcher.write_text('''#!/usr/bin/env bash
set -u
export RUST_BACKTRACE=1
export CHECKPOINT_SKIP=ordinary_original_unit_diagnostics
out=/workspace/scratch/ct69-original-root-reap-diagnostics-01
binary=/workspace/scratch/ct55-g3-root-regression-01-build-cache/release/deps/crypto_lib-0f5740d1cfe22c09
cd /workspace/crypto
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
for label in ok_without_observed_reap_cannot_mark_or_read_sidecars publication_collision_preserves_previous_bytes_and_pending_failure; do
  timeout 120 "$binary" --exact "cryptanalysis::ecbench::runner::diagnostic_reap_publication_regression_tests::$label" --nocapture --test-threads=1 > "$out/$label.log" 2>&1
  code=$?
  printf '%s\\n' "$code" > "$out/$label.exit"
done
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARDS'
from pathlib import Path
import hashlib,json,sys
o=Path(sys.argv[1]);before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in before};changed=[p for p,h in before.items()if after[p]!=h]
(o/'after.json').write_text(json.dumps(after,indent=2)+'\\n');(o/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\\n');raise SystemExit(bool(changed))
GUARDS
guard=$?
printf '%s\\n' "$guard" > "$out/guard.exit"
exit "$guard"
''')
shutil.copyfile(launcher,o/'original-command.sh')
print(cl,json.dumps(dict(launcher=str(launcher),checkpoint=p.returncode)),flush=True)
