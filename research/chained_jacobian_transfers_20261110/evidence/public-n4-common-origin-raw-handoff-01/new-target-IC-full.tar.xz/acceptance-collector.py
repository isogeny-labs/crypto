"""Whole original native equality and unchanged canonical PCC binding checks."""
from pathlib import Path
import hashlib,importlib.util,json,lzma,re,shutil,subprocess,sys
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';o=Path('/workspace/scratch/ct69-new-target-IC-full-01');d=s/'evidence/new-target-IC-independent-full-01';d.mkdir()
source='1816c3b99cb69e2072a7f0a246bdeb98b9f005e8'
for p in [o/'native.exit',o/'guard.exit',o/'driver/original.exit',o/'driver/guard.exit',o/'driver/cleanliness.exit',o/'original-fixture-verify.exit']:assert p.read_text().strip()=='0',p
assert json.loads((o/'guards.json').read_text())==dict(count=730,changed=[])
phases=[line.split()for line in(o/'driver/phase-index.txt').read_text().splitlines()];assert len(phases)==9
for name,wanted,actual in phases:assert wanted==actual=='0'and(o/'driver'/(name+'.pipe-exits')).read_text().split()==['0','0']
def canonical(xs):
 xs=json.loads(json.dumps(xs))
 for row in xs:
  if row['kind']=='N4_NEW_JACOBIAN_IC_ATTEMPT':
   for phase in row['data']['report']['phases']:del phase['wall']
   row['data']['report']['stats']=[p for p in row['data']['report']['stats']if p[0]!='wall_total']
 return sorted(json.dumps(x,sort_keys=True,separators=(',',':'))for x in xs)
log=(o/'driver/solver.log').read_text();assert '1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in log
rows=[]
for line in log.splitlines():
 m=re.search(r'\b(N4_NEW_JACOBIAN_IC_[A-Z0-9_]+) (\{.*\})$',line)
 if m:rows.append(dict(kind=m[1],data=json.loads(m[2])))
assert len(rows)==82 and canonical(rows)==canonical(json.loads(lzma.decompress((s/'ci_new_target_ic/expected-native.json.xz').read_bytes())))
raw=json.dumps(rows,indent=2).encode()+b'\n';z=lzma.compress(raw);assert len(z)<65536;(d/'whole-native.json.xz').write_bytes(z);(o/'all-native-records.json').write_bytes(raw)
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py');pcc=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pcc;spec.loader.exec_module(pcc)
verdicts=[]
for b in json.loads((s/'evidence/new-target-IC-bindings-01/claims.json').read_text()):
 v=json.loads((o/'driver'/('binding-'+Path(b['claim_path']).stem+'.log')).read_text());c=json.loads((r/b['claim_path']).read_text());assert v['verdict']=='pass'and not v['reasons']and v['commit']==source and v['claim_sha256']==pcc.claim_digest(c);verdicts.append(v)
assert len(verdicts)==2
for p in [o/'guards.json',o/'plan.json',o/'original-command.sh',o/'admission/results.json',o/'admission/restoration.json',o/'fixture-materialization.json']:shutil.copyfile(p,d/p.name)
(d/'exact-local-verdicts.json').write_text(json.dumps(verdicts,indent=2)+'\n')
(d/'observation.json').write_text(json.dumps(dict(source=source,producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2',all730_outer_guards_unchanged=True,portable_inputs=729,phase_pairs='nine ordered positive native/tee0/0',one_unfiltered_test=True,whole_JSON='ALL82 equal except ONLY N4_NEW_JACOBIAN_IC_ATTEMPT report.phases[*].wall and stats.wall_total;all raw timings retained',both_original_proof_gates='two declarations/zero trusted',all2_original_canonical_PCC_digests_match=True,four_actual_admission='2/nooutput/restored',original_HEAD_cleanliness_guards='0',fresh_physical_Git_siblings_and_outside_cache=True,genuine_fixture='already genuine physical original copied read-only and original-tool verified;not new remote read;CI separately hydrates',CI='separate all14workflow audit190native57canonical pending',scope='correctness/unsigned/geometry and global-log extension partial/compatibility and costs open'),indent=2)+'\n')
shutil.copyfile(__file__,o/'acceptance-collector.py')
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Independent actualnewtargetIC full01 exact1816/original3d passes all NINEordered native+tee0/0,ONEunfiltered comprehensive native test/ALL82wholeJSON equal exceptONLYdeclared ATTEMPTreportphase.wall andstats.wall_total/rawtimingsretained. All60attempts/all15publiccases/allanswers/failures/counters/tags/controls equal nativee869bd;no numeric result fields omitted. Both unchanged original2-declarationgates/zero trusted/2exactoriginalcanonicalPCCbindings pass. All730outer/729portable+self/HEAD/cleanlinessguards0;fouractualadmissioncontrols2/nooutput/restored. Fresh physicalGit siblings/outsidecoldcache;complete120752-byte alreadygenuinefixture copiedreadonly/originaltoolverify0,notnewremoteread. Whole rawsource/logs/commands/exits retained;own14CI190native57digests pendingseparate. Genuineprevious25wholeobjects43d6ba/babda6 settled. Unsigned/partialgeometry/global-log extension andsame-origincompatibility/costs open/no computationaladvantage/globalrootgreen/mergewaiver.']
for p in sorted(d.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(r))]
print(subprocess.check_output(cmd,cwd=r,text=True).strip())
