"""Native log/API custody and calls to the unchanged PCC tooling only."""
from pathlib import Path
from datetime import datetime, timezone
import json, re, shutil, subprocess, lzma, hashlib, importlib.util, sys
r=Path('/workspace/cryptanalysis'); s=r/'experiments/chained-transfer-public-target'
def claim(statement,dest):
    cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement',statement]
    for p in sorted(dest.iterdir()):
        if p.is_file(): cmd+=['--proof','attestation:'+str(p.relative_to(r))]
    print(subprocess.check_output(cmd,cwd=r,text=True).strip(),flush=True)
def records(log):
    rows=[]
    for line in log.splitlines():
        m=re.search(r'\b(N4_[A-Z0-9_]+) (\{.*\})$',line)
        if m: rows.append(dict(kind=m[1],data=json.loads(m[2])))
    return rows
canonical=lambda x: sorted(json.dumps(t,sort_keys=True,separators=(',',':')) for t in x)
o=Path('/workspace/scratch/ct69-new-target-IC-own-CI-raw-01'); source='1816c3b99cb69e2072a7f0a246bdeb98b9f005e8'
rows={}; verdicts=[]; jobs=[]
markers={'completed':'Completed-descent replay complete:','V2':'Completed V2/rho replay complete:','P1':'Public-target N4 replay complete:','two-primary':'Actual two-primary replay complete:','bitangents':'Actual bitangent replay complete:','kernels':'Actual kernel census/replay complete:','gluing':'Actual alternative gluing replay complete:','chain':'Actual chain-kernel replay complete:','odd':'Actual odd-source replay complete:','product':'Actual odd-product replay complete:','refinement':'Actual odd-product refinement replay complete:','newIC':'Actual new-target IC replay complete:','fixture':'Original root','PCC':'Verify all claims','PCC-edited':'Verify all claims'}
for item in json.loads((o/'inventory.json').read_text()):
    label,run,job=item['label'],item['run'],item['job'];marker=markers[label]
    api=json.loads((o/(label+'-jobs-api.json')).read_text())['structuredContent']['jobs']
    target=[x for x in api if x['id']==job]; assert len(target)==1
    j=target[0]; assert (j['run_id'],j['status'],j['conclusion'])==(run,'completed','success')
    log=json.loads((o/(label+'-log-api.json')).read_text())['structuredContent']['content']
    assert source in log and (label in ['PCC','PCC-edited','fixture'] or marker in log)
    (o/(label+'-whole-job.log')).write_text(log)
    jobs.append(dict(label=label,run=run,job=job,status='completed',conclusion='success'))
    if label in ['PCC','PCC-edited']:
        sign=[j for j in api if j['name']=='sign']; assert len(sign)==1 and sign[0]['conclusion']=='skipped'
        assert any('exit 2 = not covered is allowed' in step['name'] for step in j['steps'])
    elif label!='fixture':
        rows[label]=records(log)
        for line in log.splitlines():
            if '{"claim_id":' in line: verdicts.append(json.loads(line[line.index('{"claim_id":'):]))
assert {k:len(v) for k,v in rows.items()}==dict(completed=17,V2=12,P1=13,**{'two-primary':4,'bitangents':4,'kernels':8,'gluing':18,'chain':4,'odd':4,'product':17,'refinement':7,'newIC':82})
def omitted(rows):
    rows=json.loads(json.dumps(rows))
    for row in rows:
        if row['kind']=='N4_NEW_JACOBIAN_IC_ATTEMPT':
            for phase in row['data']['report']['phases']:del phase['wall']
            row['data']['report']['stats']=[p for p in row['data']['report']['stats']if p[0]!='wall_total']
        methods=['baseline','candidate'] if row['kind']=='N4_COMPLETED_ATTEMPT' else ['public'] if row['kind']=='N4_PUBLIC_ATTEMPT' else []
        for method in methods:
            for phase in row['data'][method]['phases']: del phase['wall']
            row['data'][method]['stats']=[p for p in row['data'][method]['stats'] if p[0]!='wall_total']
    return canonical(rows)
assert omitted(rows['newIC'])==omitted(json.loads(lzma.decompress((s/'ci_new_target_ic/expected-native.json.xz').read_bytes())))
gluing_expected=[]
for label in ['models','maps']:gluing_expected+=json.loads(lzma.decompress((s/'ci_gluing'/('expected-'+label+'.json.xz')).read_bytes()))
product_expected=json.loads(lzma.decompress((s/'ci_odd_product/expected-models.json.xz').read_bytes()))+json.loads(lzma.decompress((s/'evidence/odd-product-maps-acceptance-02/all-native-records.json.xz').read_bytes()))
assert canonical(rows['refinement'])==canonical(json.loads(lzma.decompress((s/'ci_odd_refinement/expected-native.json.xz').read_bytes())))
assert canonical(rows['product'])==canonical(product_expected)
assert canonical(rows['odd'])==canonical(json.loads(lzma.decompress((s/'ci_odd/expected-kernels.json.xz').read_bytes())))
assert canonical(rows['chain'])==canonical(json.loads(lzma.decompress((s/'ci_chain/expected-kernels.json.xz').read_bytes())))
assert canonical(rows['gluing'])==canonical(gluing_expected)
assert canonical(rows['kernels'])==canonical(json.loads((s/'ci_kernels/expected-native.json').read_text()))
assert canonical(rows['bitangents'])==canonical(json.loads((s/'ci_bitangents/expected-native.json').read_text()))
assert canonical(rows['two-primary'])==canonical(json.loads((s/'ci_two_primary/expected-native.json').read_text()))
assert omitted(rows['completed'])==omitted(json.loads((s/'ci_completed/expected-native.json').read_text()))
assert omitted(rows['P1'])==omitted(json.loads((s/'evidence/unit-acceptance-01/all-native-records.json').read_text()))
for prefix,name in [('N4_V2_','expected-native-v2.json'),('N4_RHO_','expected-native-rho.json')]:
    assert canonical([x for x in rows['V2'] if x['kind'].startswith(prefix)])==canonical(json.loads((s/'ci_v2'/name).read_text()))
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py'); pcc=importlib.util.module_from_spec(spec); sys.modules[spec.name]=pcc; spec.loader.exec_module(pcc)
digests={}
for folder in ['lean-bindings-01','origin-lean-bindings-01','prime-field-bindings-02','two-primary-bindings-01','bitangent-bindings-01','kernel-bindings-01','gluing-models-bindings-01','gluing-chain-bindings-01','chain-kernel-bindings-01','odd-source-bindings-01','odd-product-chain-bindings-01','odd-product-refinement-bindings-01','new-target-IC-bindings-01']:
    for binding in json.loads((s/'evidence'/folder/'claims.json').read_text()):
        c=json.loads((r/binding['claim_path']).read_text()); digests[c['id']]=pcc.claim_digest(c)
assert len(verdicts)==len(digests)==57 and set(digests)=={v['claim_id'] for v in verdicts}
for v in verdicts: assert v['verdict']=='pass' and not v['reasons'] and v['commit']==source and v['claim_sha256']==digests[v['claim_id']]
full=Path('/workspace/scratch/ct69-new-target-IC-full-01')
shutil.copytree(full/'driver/source',o/'source')
shutil.copyfile(full/'original-reference.sha256',o/'source/cryptanalysis/experiments/chained-transfer-public-target/ci_new_target_ic/reference-01.sha256')
assert sum(p.is_file() for p in (o/'source').rglob('*'))==730
for name,data in [('all-native-records.json',rows),('all57-exact-verdicts.json',verdicts),('original-PCC-canonical-digests.json',digests)]: (o/name).write_text(json.dumps(data,indent=2)+'\n')
shutil.copyfile(__file__,o/'original-collector.py')
meta=dict(at=datetime.now(timezone.utc).isoformat(),source=source,jobs=jobs,unique_workflows=14,event_runs=15,extra_event='PCC edited-body validation is an additional successful run of the same workflow;not a new science workflow or manual rerun',native_records=190,all190_native_JSON_match_except_ONLY_declared_old_completed_P1_and_newIC_raw_walls=True,raw_timings_retained=True,all57_original_canonical_PCC_digests_match=True,exact_verdicts='pass/unsigned',PCC_sign='legitimately skipped featurebranch in both events',PCC_gate='success;explicitly allows notcovered exit2',whole_logs_API_and730_source_snapshots_retained=True,artifact_ZIP_downloaded=False,CI_guard_scope='successful original replay steps and complete original markers;standalone exit files not downloaded;separate physical730full3f52fc terminal0/allguards0',fixture='data-only original immutable fixture tool pull/verify jobsuccess;no additional native/PCC records',scope='correctness observations;not full formal geometry/cost advantage/signed execution')
(o/'plan.json').write_text(json.dumps(meta,indent=2)+'\n')
d=s/'evidence/new-target-IC-own-CI-01';d.mkdir();(d/'observation.json').write_text(json.dumps(meta,indent=2)+'\n')
catalog=[]
def retain(name,raw):
    z=lzma.compress(raw);lossless=o/'lossless';lossless.mkdir(exist_ok=True);(lossless/(name+'.xz')).write_bytes(z)
    record=dict(name=name,raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),xz_bytes=len(z),xz_sha256=hashlib.sha256(z).hexdigest(),whole_local_capture=str(lossless/(name+'.xz')),genuine_whole_archive_publication='pending next unchanged publisher; no remote availability claim')
    if len(z)<65536:(d/(name+'.xz')).write_bytes(z);record['small_whole_Git_object']=str((d/(name+'.xz')).relative_to(r))
    else:(d/(name+'.hash.json')).write_text(json.dumps(record,indent=2)+'\n')
    catalog.append(record)
for name in ['all-native-records.json','all57-exact-verdicts.json','original-PCC-canonical-digests.json']:retain(name,(o/name).read_bytes())
for label in markers:retain(label+'-whole-job.log',(o/(label+'-whole-job.log')).read_bytes())
(d/'whole-object-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
claim('Exact1816c3b9 ownCI ALLFOURTEEN unique workflows SUCCESS;15eventruns include separateeditedbodyPCCsuccess/nomanualredispatch. ALL190 nativeJSON match originals:ONLYdeclared oldcompleted/P1 andnewIC reportphase.wall/stats.wall_total omitted/allrawtimingsretained;all57 exactlocalPCCverdictspass/exactsource/originalcanonicaldigests. NewIConeunfilteredtest/ALL82wholeJSON/all60attempts/all15publiccases/bothoriginal2declgates/2bindings;prior108native55bindingsunchanged. Newdata-onlyoriginalfixture jobsuccess/no extra mathrecords;bothPCCsignlegitimatelyskipped/notcovered2allowed. Whole15logs/API/730selectedsources retained;largewholecombinedrecords/gluing/productlogs catalogued fornextgenuinearchive,smallwholeobjectsGit/no newremoteavailabilityclaim. CIguardsscope originalsuccessfulsteps/markers,notdownloadedZIP;separatephysical730full3f52fc actuallyterminal0/all730guards0/ninephasepairs/fouractualcontrols. Unsigned/partialgeometry/global-logextension/commonorigincompatibility/costs open/no computationaladvantage/globalrootgreen/mergewaiver.',d)
print(json.dumps(dict(native=190,digests=57,source=source,whole_objects=[dict(name=x['name'],xz_bytes=x['xz_bytes'],small_Git='small_whole_Git_object'in x)for x in catalog])),flush=True)
