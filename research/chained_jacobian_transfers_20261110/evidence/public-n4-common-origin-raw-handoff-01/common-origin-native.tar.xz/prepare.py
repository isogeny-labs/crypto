"""Input custody and a thin native unit-test launcher;all science is Rust."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';n=s/'common-origin-ic';o=Path('/workspace/scratch/ct70-common-origin-native-01');o.mkdir()
before=json.loads(Path('/workspace/scratch/ct68-new-target-IC-native-01/before.json').read_text());assert len(before)==2543 and all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
for line in(s/'ci_new_target_ic/reference-01.sha256').read_text().splitlines():
    h,p=line.split('  ',1);p=(r/p).resolve();assert hashlib.sha256(p.read_bytes()).hexdigest()==h;before[str(p)]=h
physical=json.loads(Path('/workspace/scratch/ct69-new-target-IC-full-01/before.json').read_text());assert len(physical)==730
for p,h in physical.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h;before[p]=h
for p in [s/'ci_new_target_ic/reference-01.sha256',s/'COMMON_ORIGIN_IC_PROTOCOL_01.md',r/'.github/workflows/chained-transfer-checkpoint-transport.yml',*n.rglob('*')]:
    if p.is_file():before[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
for name in before:
    p=Path(name);dest=o/'source'/p.relative_to('/workspace');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
(o/'before.json').write_text(json.dumps(before,indent=2)+'\n');shutil.copyfile(__file__,o/'prepare.py');shutil.copyfile(s/'COMMON_ORIGIN_IC_PROTOCOL_01.md',o/'prospective-protocol.md')
(o/'plan.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),published_prospective='2dd807/0a3412cd NORMALpush0 BEFOREcode',guards=len(before),prior_current_native=2543,current_portable_CI=729,completed_independent_physical_guard=730,scope='ONEunfiltered native commonorigin test:all20original/candidatepairs/all5publicQ/FB30,36,48,64/seeds102..105/exactP0FB+RNG/r0..32/actualraworigin/sign/differences/foreignP0/allfailures',compiler_timeout=900,native_timeout=900,native_address_space_KiB=2097152,cache='ct57 existing warm outside correctness cache;not cold',acceptance='allreportedanswers actualtarget+independentsource;atleastoneCOMMONcorrectsettingperpublicQ;allactualclass/provenance/negativecontrols andguardsexact',performance='unpriced/incompleteFpR/model/maps/admission/independentverify;noS/ratio/operationalequivalence',checkpoint='ffe675 originalremote/localgate0 forexact39e9;laterstatechangesstale;thisisordinaryboundedunitcorrectness,notexperiment'),indent=2)+'\n')
launcher=Path(str(o)+'.sh')
launcher.write_text('''#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct57-n4-unit-01-build-cache
cd /workspace/cryptanalysis
out=/workspace/scratch/ct70-common-origin-native-01
manifest=experiments/chained-transfer-public-target/common-origin-ic/Cargo.toml
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
rustc -Vv > "$out/rustc.txt"
timeout 900 cargo test --release --offline --locked --manifest-path "$manifest" --lib --no-run > "$out/compile.log" 2>&1
compile=$?
printf '%s\\n' "$compile" > "$out/compile.exit"
if [ "$compile" -eq 0 ]; then
  (ulimit -v 2097152; timeout 900 cargo test --release --offline --locked --manifest-path "$manifest" --lib -- --nocapture --test-threads=1) > "$out/native.log" 2>&1
  native=$?
else
  native=not-launched
fi
printf '%s\\n' "$native" > "$out/native.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARDS'
from pathlib import Path
import hashlib,json,sys
o=Path(sys.argv[1]);before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in before};changed=[p for p in before if before[p]!=after[p]]
(o/'after.json').write_text(json.dumps(after,indent=2)+'\\n');(o/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\\n');raise SystemExit(bool(changed))
GUARDS
guard=$?
printf '%s\\n' "$guard" > "$out/guard.exit"
if [ "$compile" -ne 0 ]; then exit "$compile"; fi
if [ "$native" -ne 0 ]; then exit "$native"; fi
exit "$guard"
''')
shutil.copyfile(launcher,o/'original-command.sh');print(json.dumps(dict(launcher=str(launcher),guards=len(before))),flush=True)
