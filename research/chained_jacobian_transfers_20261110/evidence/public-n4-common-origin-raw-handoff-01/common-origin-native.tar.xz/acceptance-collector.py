"""Whole native JSON custody;no mathematical computation outside Rust."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,lzma,re,shutil,subprocess
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';o=Path('/workspace/scratch/ct70-common-origin-native-01');d=s/'evidence/common-origin-acceptance-01';d.mkdir()
for label in ['compile','native','guard']:assert(o/(label+'.exit')).read_text().strip()=='0'
assert json.loads((o/'guards.json').read_text())==dict(count=3304,changed=[])
log=(o/'native.log').read_text();assert '1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out'in log
rows=[]
for line in log.splitlines():
    m=re.search(r'\b(N4_ORIGIN_[A-Z0-9_]+) (\{.*\})$',line)
    if m:rows.append(dict(kind=m[1],data=json.loads(m[2])))
counts={k:sum(x['kind']==k for x in rows)for k in sorted({x['kind']for x in rows})}
assert counts==dict(N4_ORIGIN_ATTEMPT=20,N4_ORIGIN_CASE=5,N4_ORIGIN_GEOMETRY=20,N4_ORIGIN_PROVENANCE=1,N4_ORIGIN_SCOPE=1,N4_ORIGIN_SETTING=4)
assert rows[-1]['data']['common_correct_settings']==[3]*5 and rows[-1]['data']['omitted_origin_controls']==1004
attempts=[x['data']for x in rows if x['kind']=='N4_ORIGIN_ATTEMPT'];assert len(attempts)==20
for x in attempts:
    assert x['same_outcome']
    for arm in ['original','candidate']:
        if x[arm]['ok']:assert x[arm+'_target_check'] and x[arm+'_independent_source_check']
assert sum(x['original']['ok']for x in attempts)==sum(x['candidate']['ok']for x in attempts)==15
raw=json.dumps(rows,indent=2).encode()+b'\n';z=lzma.compress(raw);(o/'all-native-records.json').write_bytes(raw);(o/'all-native-records.json.xz').write_bytes(z)
catalog=dict(records=51,raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),whole_xz_bytes=len(z),whole_xz_sha256=hashlib.sha256(z).hexdigest(),whole_local_capture=str(o),new_genuine_archive_publication='pending next unchanged whole-data publisher/NEWguard08;alloriginalphysicalbytes retained')
if len(z)<65536:(d/'all-native-records.json.xz').write_bytes(z);catalog['small_whole_Git_object']=True
else:catalog['small_whole_Git_object']=False
(d/'whole-native-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
for name in ['guards.json','plan.json','original-command.sh','prospective-protocol.md','rustc.txt']:shutil.copyfile(o/name,d/name)
geometry=[x['data']for x in rows if x['kind']=='N4_ORIGIN_GEOMETRY'];settings=[x['data']for x in rows if x['kind']=='N4_ORIGIN_SETTING']
summary=dict(at=datetime.now(timezone.utc).isoformat(),prospective='2dd807/0a3412cd NORMALpush0 BEFOREcode',native_tests='1passed/0failed/ignored/filtered',guards=3304,changed=[],whole_records=51,paired_attempts=20,solver_reports=40,original_successes=15,candidate_successes=15,same_success_failure_outcome_all20=True,each_public_common_correct_settings=[3]*5,failures='FB30/seed102:botharms all5 fail exactly20relationrows/30columns;all failures retained',actual_origins=[dict(nfb=x['nfb'],seed=x['seed'],P0=x['P0'],nonzero=x['origin_nonzero'])for x in settings],full_factorbase_and_RNG_equality=True,source_class_triplets=660,individual_complete_images=1980,available_original_raw_points=sum(x['available_legacy_points']for x in geometry),available_original_raw_triples=sum(x['available_legacy_triples']for x in geometry),actual_omitted_origin_rejections=1004,actual_foreign_P0_and_zero_generator_controls=True,literal_provenance='exact originals;ONLYcontexttype/picaccess delta;relationLA/logrecovery/innerdescent slices literal',reported_answers='actualtarget AND independentoriginalsource/knownansweroutside runtime',scope='bounded exact-origin/factorbase/DLP-data compatibility;not identical random paths/counters/globalgeometry/logextension/completeness/costadvantage')
assert summary['available_original_raw_points']==1004 and summary['available_original_raw_triples']==92
(d/'observation.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copyfile(__file__,o/'acceptance-collector.py')
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Common-originIC native01 underprospective2dd807/0a3412cd BEFOREcode:ONEunfilteredtest0/zeroignoredfiltered/ALL3304guards unchanged. ALL20 pairedattempts(public5xFB30/36/48/64,seeds102..105)/40whole reports/51wholeJSON retained;ALL20successfailureoutcomesmatch. Eacharm15correctsolves;FB30bothall5fail20rowsfor30cols;eachpublicQ hasTHREEcommoncorrectsettings/every reportedanswer actualtarget+independentsource/knownscalaroutside runtime. EXACTsameoriginalquartic/fouractualP0s/fullFB/RNGstate;freshactualNormV2/genuineS=-I;ALL660triples/1980completeimages/1004availableoriginalrawpoints raw=H+actualT/92allavailablelegacytriples anddifferences. ALL4actualoriginsnonzero/1004omitted-origin negatives/actualforeignP0+zeroG controls pass. Originalbaseline untouched;byteexactsnapshots/ONLYcontexttype+borrowedpicaccess derivative/relationLAlogrecoveryinnerdescent literal. Wholefailures/source/provenance/rawoutputs retained;genuinewholecapturepublicationpending. Boundedcompatibilityclosesdeclaredfinitecontrol,not randompath/counter/globalgeometry/global-logextension/completeness/costadvantage equivalence;57existingconditionalbindingsunchanged/unsigned.']
for p in sorted(d.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(r))]
claim=subprocess.check_output(cmd,cwd=r,text=True).strip();print(claim,json.dumps(catalog),flush=True)
note='''\n## {at} — native common-origin control passes\n\n### What was done (commands, files, features)\n+{claim}:ONEunfilteredtest0/all3304guards0/ALL20pairedattempts40reports51wholeJSON. Botharms15correctsolves/ALL20outcomesmatch;FB30bothfail20rows30columns/allfailuresretained;eachpublicQ THREEcommoncorrectsettings. FouractualrandomP0s/fullFB/RNGexact;ALL660triples/1980completeimages/1004availablelegacyrawpoints/92allavailabletriples satisfyactualrawH+T/differences. All4Tnonzero/1004wrongomitted-origin/actualforeignP0+zeroGcontrols;everyreportedansweractualtarget+independentsource. [pcc:unverified]\n\n### Decisions made (and why)\n+Keeporiginalbaseline/nativeengines/frozenclasscontext untouched;newderivativeONLYcontexttype+borrowedactualPicardaccess,wholeliteralprovenance/relationLAlogrecoveryinnerdescent checks pass. This closesdeclaredbounded same-origincompatibilitycontrol,notrandompath/counter/global-logextension/completeness/costequivalence. ExistingfaithfulconditionalLeanbindingsremain57/unsigned. [pcc:unverified]\n\n### Open threads (unfinished, pick up next time)\n+Writeexactderivation/proofscope andsource-linkededitablevisualPDFreport;sourcecheckpoint/strictreplay/CI/genuinewholepublication withNEWguard08. Then completeFpR/source-model/maps/admission/verification operationcoverage andodddegreecoordinates/admittedmatchedreferences. [pcc:unverified]\n\n### Errors (what went wrong, how it was handled)\n+No newnativecompile/test failure;bothFB30relationfailures retained. Oldsource/setup/citation/report/root124/clock101 preserved. Originalcheckpointtransportffe675passedexact39e9;newstatechangesstaleit,livebudgetcapacitycostrefsremainrequired. [pcc:unverified]\n'''.format(at=datetime.now(timezone.utc).isoformat(),claim=claim).replace('\n+','\n')
for p in [r/'docs/session-logs/2026-11-14.md',r/'.resume/RESUME.md']:
    with p.open('a')as f:f.write(note)
