#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct53-prime-tests-01/target
export CARGO_TERM_COLOR=never
cd /workspace/cryptanalysis
out=/workspace/scratch/ct53-prime-tests-01
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
set +e
timeout 900 cargo test --manifest-path experiments/chained-transfer-reference/norm-checker/Cargo.toml --release --offline --locked -- --nocapture > "$out/tests.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/tests.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - <<'PY'
from pathlib import Path
import json,hashlib
r=Path('/workspace/scratch/ct53-prime-tests-01')
a=json.loads((r/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in a}
(r/'after.json').write_text(json.dumps(after,indent=2)+'\n')
changed=[p for p in a if a[p]!=after[p]]
(r/'guards.json').write_text(json.dumps({'changed':changed,'checked':len(a)},indent=2)+'\n')
raise SystemExit(bool(changed))
PY
guard=$?
printf '%s\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
