#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
outer=/workspace/scratch/ct53-prime-full-01-outer
mkdir "$outer" || exit 2
mkdir "$outer/no-rg"
cat > "$outer/no-rg/rg" <<'RG'
#!/usr/bin/env bash
printf 'unexpected rg invocation\n' >> /workspace/scratch/ct53-prime-full-01-outer/rg-invoked.txt
exit 19
RG
chmod +x "$outer/no-rg/rg"
export PATH="$outer/no-rg:$PATH"
cd /workspace/cryptanalysis
cp experiments/chained-transfer-reference/check-prime-norms.sh "$outer/original-driver.sh"
git rev-parse HEAD > "$outer/consumer-head.txt"
git -C /workspace/crypto rev-parse HEAD > "$outer/upstream-head.txt"
date -u +%Y-%m-%dT%H:%M:%SZ > "$outer/start.txt"
set +e
timeout 3300 bash experiments/chained-transfer-reference/check-prime-norms.sh /workspace/crypto /workspace/scratch/ct53-prime-full-01 > "$outer/driver.log" 2>&1
status=$?
printf '%s\n' "$status" > "$outer/original.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$outer/finish.txt"
if [ -e "$outer/rg-invoked.txt" ]; then printf '1\n' > "$outer/no-rg.exit"; exit 1; fi
printf '0\n' > "$outer/no-rg.exit"
exit "$status"
