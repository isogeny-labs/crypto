#!/usr/bin/env bash
set -u
cd /workspace/crypto
out=/workspace/scratch/ct55-g3-root-fixture-diagnostic-01
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
set +e
timeout 60 /workspace/scratch/ct55-g3-root-regression-01-build-cache/release/deps/crypto_lib-0f5740d1cfe22c09 --exact cryptanalysis::ecbench::band::tests::default_band_differs_from_the_committed_file_by_the_insert_term_only --nocapture --test-threads=1 > "$out/native.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/native.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARD'
from pathlib import Path
import hashlib,json,sys
o=Path(sys.argv[1]);before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before};changed=[p for p in before if before[p]!=after[p]]
(o/'after.json').write_text(json.dumps(after,indent=2)+'\n');(o/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\n');raise SystemExit(bool(changed))
GUARD
guard=$?
printf '%s\n' "$guard" > "$out/guard.exit"
exit "$status"
