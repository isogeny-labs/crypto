"""CI byte collection only; calls the unchanged original PCC digest function."""
from pathlib import Path
from datetime import datetime, timezone
import importlib.util, sys, json, hashlib, shutil, subprocess, re

r=Path('/workspace/cryptanalysis'); s=r/'experiments/chained-transfer-reference'
producer=Path('/workspace/crypto'); ps=producer/'research/chained_jacobian_transfers_20261110'
old=Path('/workspace/scratch/ct56-g3-norm-own-ci-raw-01')
out=Path('/workspace/scratch/ct56-g3-norm-own-ci-raw-02')
assert not out.exists()
d=s/'evidence/g3-norm-ci-collector-correction-01'; d.mkdir()
failure=dict(at=datetime.now(timezone.utc).isoformat(),observed='collector AssertionError after matching 24 claim IDs; compared claim_sha256 to raw pretty-JSON file SHA',captured_traceback='tool transcript only, not a retained original stderr file',partial_custody='PCC-20261113-d82dd3/21 files/134968-byte whole archive retained unchanged',original_digest='tools/pcc/pcc.py:claim_digest excludes standing then uses canonical sorted compact UTF-8 JSON',correction='import and call that unchanged original function; freeze this correction before completing raw02',native_or_verifier_change=False,optional_artifact_ZIPs=0,optional_access='403 storage proxy; retained 963670, no retry or bypass',scope='collector bookkeeping; no scientific claim or modified verifier')
(d/'failure-and-plan.json').write_text(json.dumps(failure,indent=2)+'\n')
shutil.copyfile(r/'tools/pcc/pcc.py',d/'original-pcc.py')
cl=subprocess.check_output(['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Freeze CI collector correction BEFORE raw02: initial collector wrongly compared canonical claim_sha256 with raw file SHA; failed assertion preserved as observation and partial whole raw01 d82dd3 unchanged. Use ORIGINAL unchanged PCC claim_digest for all24 exact IDs. No native/test/Lean/verifier change; optional ZIP403/zero downloaded retained separately.','--proof','attestation:'+str((d/'failure-and-plan.json').relative_to(r)),'--proof','attestation:'+str((d/'original-pcc.py').relative_to(r))],cwd=r,text=True).strip()
print('frozen correction',cl,flush=True)
shutil.copytree(old,out)
shutil.copytree(d,out/'collector-correction')
shutil.copytree(Path('/workspace/scratch/ct56-g3-norm-full-02/source'),out/'source')
for label,path in [('dispatch','/workspace/scratch/ct56-g3-norm-ci-dispatch-01'),('initial-discovery','/workspace/scratch/ct56-g3-norm-ci-discovery-01')]:
    shutil.copytree(path,out/label)
shutil.copyfile(__file__,out/'original-collector.py')
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py'); pcc=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pcc;spec.loader.exec_module(pcc)
expected={}
for repo,study in [(r,s),(producer,ps)]:
    name='g3-norm-lean-bindings-01' if repo==r else 'genus3-lean-bindings-01'
    bindings=json.loads((study/'evidence'/name/'claims.json').read_text())
    for binding in bindings:
        claim=json.loads((repo/binding['claim_path']).read_text())
        expected[claim['id']]=dict(canonical_claim_sha256=pcc.claim_digest(claim),raw_file_sha256=hashlib.sha256((repo/binding['claim_path']).read_bytes()).hexdigest(),commit='069644bf59499e4172eb8bcdce5de8a6665da93f' if repo==r else '3d49af7f3d0a28e76b79e4825c9d2324e85853d2')
verdicts=json.loads((out/'new-job-exact-PCC-verdicts.json').read_text())
assert len(expected)==len(verdicts)==24 and set(expected)=={v['claim_id'] for v in verdicts}
for v in verdicts:
    e=expected[v['claim_id']]
    assert v['claim_sha256']==e['canonical_claim_sha256'] and v['verdict']=='pass' and v['commit']==e['commit'] and not v['reasons']
(out/'original-PCC-canonical-digest-comparison.json').write_text(json.dumps(expected,indent=2)+'\n')
def records(path):
    result=[]
    for line in path.read_text().splitlines():
        # Rust test harness may prefix concurrent output with the test name.
        m=re.search(r'\b(G3_[A-Z_]+) (\{.*\})$',line)
        if m:result.append(dict(kind=m[1],data=json.loads(m[2])))
    return result
ci=json.loads((out/'new-job-native-records.json').read_text())
norm=records(Path('/workspace/scratch/ct56-g3-norm-unit-02/native.log'))
prod=records(Path('/workspace/scratch/ct55-g3-unit-03/native.log'))
canonical=lambda rows:sorted(json.dumps(x,sort_keys=True,separators=(',',':')) for x in rows)
assert len(ci)==36 and len(norm)==12 and len(prod)==24 and canonical(ci)==canonical(norm+prod)
jobs=json.loads((out/'terminal-jobs-api.json').read_text())['structuredContent']['jobs']
assert len(jobs)==7 and all(j['run_id']==43400864083 and j['status']=='completed' and j['conclusion']=='success' for j in jobs)
for j in jobs:
    log=(out/(j['name']+'-whole-job.log')).read_bytes()
    assert log==json.loads((out/(j['name']+'-log-api.json')).read_text())['structuredContent']['content'].encode()
source_files=[p for p in (out/'source').rglob('*') if p.is_file()]
assert len(source_files)==438
observation=dict(at=datetime.now(timezone.utc).isoformat(),run=43400864083,consumer='069644bf59499e4172eb8bcdce5de8a6665da93f',producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2',jobs=[dict(name=j['name'],id=j['id'],status=j['status'],conclusion=j['conclusion']) for j in jobs],whole_logs=7,source_snapshots=438,new_job_native_records=36,consumer_records_equal_unit02=12,producer_records_equal_unit03=24,exact_original_PCC_verdicts=24,all_original_canonical_claim_digests_match=True,all_verdicts_pass=True,artifact_ZIPs_downloaded=0,exit_and_guard_scope='original unchanged driver terminal marker and successful job step; actual job artifacts/standalone exit files NOT downloaded',observation_plan='collect all seven terminal jobs and WHOLE logs, compare all new-job native records and 24 original exact bindings; append correction rather than rewrite partial raw01',settled=True,next='publish whole archive, checkpoint PR/queue, then public-target N4/V2 pre-code protocol',standing='unsigned CI observations, not a signed execution/performance/math verdict')
(out/'plan.json').write_text(json.dumps(observation,indent=2)+'\n')
print('complete',len(jobs),len(source_files),len(ci),len(verdicts),flush=True)
