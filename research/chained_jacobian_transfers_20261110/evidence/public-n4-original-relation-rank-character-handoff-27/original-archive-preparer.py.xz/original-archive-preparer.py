"""Whole closed custody27 archive: literal I/O only, no scientific calculations."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,lzma,os,shutil,stat,subprocess,tarfile

r=Path('/workspace/crypto');c=Path('/workspace/cryptanalysis');scratch=Path('/workspace/scratch');s=r/'research/chained_jacobian_transfers_20261110';cs=c/'experiments/chained-transfer-public-target'
rootbase='69abf11274ce1f0d49b8e9a42f75af1791fc1bc8';consumer='fe91441709ba1860f8e5b0e54834f5fa0e8fd0c3';previous_consumer='41247ff12bbb6e0fb52e3dd4a39dd722cd76d283';previous_root='a0004ee84cce3b5f07337ec7d350eedd25df42fc'
env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo,env=env)
def sha(p):
 assert not p.resolve().is_relative_to(Path('/workspace/crypto-autoresearcher')),'sealed vault is outside the archive scope'
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def link_state(p):
 row=dict(literal_target=os.readlink(p))
 try:st=p.stat()
 except FileNotFoundError:row['target_kind']='missing'
 except OSError as exc:row.update(target_kind='unresolvable',errno=exc.errno)
 else:
  if stat.S_ISREG(st.st_mode):row.update(target_kind='file',target_bytes=st.st_size,target_sha256=sha(p))
  elif stat.S_ISDIR(st.st_mode):row['target_kind']='directory'
  else:row['target_kind']='other'
 return row

assert git(r,'rev-parse','HEAD').decode().strip()==rootbase
root_hold_names={b'.resume/RESUME.md',b'docs/session-logs/2026-11-15.md'}|{(s.relative_to(r).as_posix()+'/'+n).encode()for n in ['QUEUE.md','PUBLIC_TARGET_CHECKPOINT.md','CHECKPOINT.md']}
assert(set(git(r,'diff','--name-only','-z').split(b'\0'))-{b''})==root_hold_names and not git(r,'diff','--cached','--name-only')and not git(r,'ls-files','--others','--exclude-standard')
assert git(c,'rev-parse','HEAD').decode().strip()==consumer
consumer_hold_names={b'.resume/RESUME.md',b'docs/session-logs/2026-11-15.md',b'experiments/chained-transfer-public-target/CHECKPOINT.md',b'experiments/chained-transfer-public-target/RESEARCH_QUEUE.md'}
assert(set(git(c,'diff','--name-only','-z').split(b'\0'))-{b''})==consumer_hold_names and not git(c,'diff','--cached','--name-only')and not git(c,'ls-files','--others','--exclude-standard')
priorfile=scratch/'ct99-whole-closed-science-handoff-26/current-inputs.json';prior=json.loads(priorfile.read_text());assert len(prior)==58919
priorstage=s/'evidence/public-n4-original-IC-sampler-handoff-26';prioridentity=json.loads((priorstage/'archive-parts.json').read_text());priorlinks=json.loads((s/'evidence/public-n4-current-guard-26/symlink-targets.json').read_text());assert len(priorlinks)==177
allowed={str(c/p)for p in ['.resume/RESUME.md','docs/session-logs/2026-11-14.md','docs/session-logs/2026-11-15.md','experiments/chained-transfer-public-target/CHECKPOINT.md','experiments/chained-transfer-public-target/RESEARCH_QUEUE.md','.gitattributes','pcc/ledger.jsonl','problems/README.md']}
changed=[]
for index,(name,want)in enumerate(prior.items()):
 p=Path(name);assert p.is_file(),name
 if sha(p)!=want:changed.append(name)
 if index%10000==0:print('prior26 hash',index,'/',len(prior),flush=True)
assert set(changed)<=allowed,sorted(set(changed)-allowed)
assert all(Path(n).is_symlink()and os.readlink(n)==v for n,v in priorlinks.items())
with tarfile.open(prioridentity['local_original'],'r:xz')as t:priorledger=t.extractfile('consumer-pending/pcc/ledger.jsonl').read()
assert hashlib.sha256(priorledger).hexdigest()==prior[str(c/'pcc/ledger.jsonl')]
published_previous=git(c,'show',previous_consumer+':pcc/ledger.jsonl');assert published_previous==priorledger
consumer_ledger=git(c,'show',consumer+':pcc/ledger.jsonl');root_ledger=git(r,'show',rootbase+':pcc/ledger.jsonl')
assert(c/'pcc/ledger.jsonl').read_bytes().startswith(priorledger)and(c/'pcc/ledger.jsonl').read_bytes()==consumer_ledger
assert(r/'pcc/ledger.jsonl').read_bytes()==root_ledger
for name,count in [('ct101-original-relation-kernel-native-01',28),('ct102-original-relation-rank-native-01',22),('ct103-original-relation-character-native-01',22)]:
 p=scratch/name;assert(p/'original.exit').read_text().strip()=='0';phases=[line.split()for line in(p/'phases.txt').read_text().splitlines()];assert len(phases)==count and all(a==b for _,a,b in phases)
assert(scratch/'ct104-root-source-character-result-governance-caller02.exit').read_text().strip()=='0'
print('Prior58919 contents/177links/exact ledger prefixes and all three whole native phase sets checked',flush=True)

# Only roots already closed at this declaration are scientific archive inputs.
names=[]
for p in sorted(scratch.iterdir()):
 if not p.is_dir():continue
 if any(p.name.startswith('ct'+str(n)+'-')for n in range(99,105)):names.append(p.name)
 elif p.name.startswith(('ct89-','ct91-'))and any(str(q)not in prior for q in p.rglob('*')if q.is_file()or q.is_symlink()):names.append(p.name)
o=scratch/'ct104-whole-closed-science-handoff-27-attempt02';ram=Path('/dev/shm/ct104-whole-closed-science-handoff-27-attempt02');o.mkdir();ram.mkdir()
(o/'original-prepare-command.py').write_bytes(Path(__file__).read_bytes());write(o/'scientific-root-declaration.json',names)
state='''# Whole relation-character custody27: inputs HELD

## What was done
Source consumerfe914417/producer69abf112: passive d118b9 full100native/60calls660events/strict report-counter parity; rankc0479c all360certificates1440470operations/FB30nullities6-10-13/largerFBnullity1; proof19c467 both27declarationgates/allninebindings; character3a7d56 full60calls13200actualnorm-cofactor4-BSGSwitnesses15125rows/all180canonical-characterdecompositions/all60postsolver targetchecks. Final2fd6b0report53962B/twoactuallyopenedpages and allfailed metadata/source/report/CI/transport specimens retained. Prior58919keys/177links and exact genuine26/current ledger prefixes checked. [pcc:unverified]

## Decisions made
HOLD all science/source/raw/aliases/consumer owned bytes and consumer ledger until actual original remote replays BEFORE the actual publisher/bot, exact normalFF, whole reassembly and terminal27 file/link-state checks. Include every declared complete nonsecret post26root and both repository deltas; keep alreadygenuine archivepayloads referenced without recursive copies. Preserve dangling failed-layout symlinks exactly, with complete literal-target/target-state guards; never hydrate or omit them. Archive/parts initially inRAM; allregularpayloadbytes and anynewGitblobcache require full custody/recovery receipts. No force/rechain/policy exemption/synthetic manifest. [pcc:unverified]

## Open threads
Complete genuine27 and exact wholefixture projection, then prospectively publish whole diagnosticCI comparison contract and review/freeze an unassisted relation-completion successor before code. All numericLean/globalmodel-program-character/causal/calibratedliveadmission/primitive/strongest-reference/merge requirements remain explicit. Vault8edec422/VLT1 only, KB127. [pcc:unverified]

## Errors
All original failures remain complete. Historicalct95staginglist bytes were restored exactly from genuine26; its later overwritten transient list is preserved and newRoot governors use unique staginglist filenames. Consumerproblem-index updates are declared released metadata. No scientificresult or pinned render/source byte changed. [pcc:unverified]

---

'''
for p in [c/'.resume/RESUME.md',cs/'CHECKPOINT.md',cs/'RESEARCH_QUEUE.md',r/'.resume/RESUME.md',s/'QUEUE.md',s/'PUBLIC_TARGET_CHECKPOINT.md',s/'CHECKPOINT.md']:assert p.read_text().startswith(state),'retain firstattempt Holdmetadata exactly'
# The firstattempt Holdmetadata is already active and is not rewritten.

skip=set();previous_payload=[]
for stage in [priorstage,s/'evidence/public-n4-original-full-group-handoff-25',s/'evidence/public-n4-original-prime-kernel-geometry-handoff-24']:
 identity=json.loads((stage/'archive-parts.json').read_text());p=Path(identity['local_original']);skip.add(p);skip.update(p.parent/row['name']for row in identity['parts'])
private_top={p for p in scratch.iterdir()if p.is_file()and p.name.startswith('private-')}
private_inventory=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p),reason='explicit private transport authorization metadata retained locally, outside scientific roots')for p in sorted(private_top)]
files=[];excluded=[];active=[]
def add(p,name,hold=True):
 assert p.is_file()or p.is_symlink(),str(p)
 if p in skip:previous_payload.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p),reason='already genuine and unchanged/held; retain identity without recursively copying payload'));return
 if p in private_top:excluded.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p),reason='explicit private transport authorization metadata, retained locally'));return
 if p.name.startswith('private-'):
  assert p.name=='private-transport-files-outside-declared-roots.json','classify any in-root private-named file explicitly: '+str(p)
  inventory=json.loads(p.read_text())
  forbidden={'download_url','file_uri','authorization','headers','access_token','secret_access_key','aws_secret_access_key','session_token'}
  def no_secret_keys(value):
   if isinstance(value,dict):
    assert not(forbidden&{str(k).lower()for k in value}),str(p)
    for item in value.values():no_secret_keys(item)
   elif isinstance(value,list):
    for item in value:no_secret_keys(item)
  no_secret_keys(inventory)
  # Entire public inventory is retained; no content field is removed.

 files.append((p,name,hold))
def tree(p,name):
 for q in sorted(p.rglob('*')):
  if q.is_file()or q.is_symlink():add(q,name+'/'+q.relative_to(p).as_posix())
for name in names:tree(scratch/name,'whole-science/'+name)
for p in sorted(scratch.iterdir()):
 if not p.is_file():continue
 if any(p.name.startswith('ct'+str(n)+suffix)for n in range(99,105)for suffix in ['-','_']):
  if p.name.startswith('ct104-handoff27-prepare-caller02.')or p.name=='ct104-handoff27-prepare-supervisor02.txt':active.append(dict(path=str(p),reason='this preparation current caller/supervisor is still being generated; retain whole after completion in publication metadata, never treat as closed scientific input'));continue
  add(p,'closed-controls/'+p.name)
for p in [priorfile,priorstage/'.artifacts.json',priorstage/'archive-parts.json',o/'scientific-root-declaration.json']:
 add(p,'control/'+('previous26-'+p.name if p.parent!=o else p.name))
tree(r/'target/ct102-relation-kernel-proof-01','actual-producer-proof-stages/ct102-relation-kernel-proof-01')
for ram_input in sorted(Path('/dev/shm/ct102-original-relation-rank-native-01').glob('*.jsonl')):add(ram_input,'whole-RAM-science/ct102-original-relation-rank-native-01/'+ram_input.name)
owned=['experiments/chained-transfer-public-target','docs/research-artifacts/chained-transfer','pcc/claims','pcc/ledger.jsonl','.resume/RESUME.md','docs/session-logs/2026-11-14.md','docs/session-logs/2026-11-15.md','.gitattributes','problems/README.md','problems/chained-transfer-odd-product-kernel-and-odd-factor.md','problems/chained-transfer-original-FB30-character-extension.md','problems/chained-transfer-original-FB30-character-extension-02.md','.github/workflows']
pending=(set(git(c,'ls-files','--modified','--others','--exclude-standard','-z','--',*owned).split(b'\0'))|set(git(c,'diff','--cached','--name-only','-z').split(b'\0')))-{b''}
allchanges=set(git(c,'ls-files','--modified','--others','--exclude-standard','-z').split(b'\0'))-{b''};assert allchanges<=pending
deltas=set(git(c,'diff','--no-renames','--name-only','-z',previous_consumer,'--',*owned).split(b'\0'))-{b''}
for name in sorted(deltas|pending):add(c/name.decode(),'consumer-delta-since-genuine26/'+name.decode())
add(c/'pcc/ledger.jsonl','consumer-pending/pcc/ledger.jsonl')
rootowned=[s.relative_to(r).as_posix(),'pcc/claims','pcc/ledger.jsonl','.resume/RESUME.md','docs/session-logs/2026-11-15.md','.gitattributes','problems/README.md']
rootmutable={str(r/n)for n in ['pcc/ledger.jsonl','.resume/RESUME.md','docs/session-logs/2026-11-15.md','.gitattributes']}|{str(s/n)for n in ['QUEUE.md','PUBLIC_TARGET_CHECKPOINT.md','CHECKPOINT.md']}
rootpending=(set(git(r,'ls-files','--modified','--others','--exclude-standard','-z','--',*rootowned).split(b'\0'))|set(git(r,'diff','--cached','--name-only','-z').split(b'\0')))-{b''}
rootdelta=set(git(r,'diff','--no-renames','--name-only','-z',previous_root,'--',*rootowned).split(b'\0'))-{b''}
for name in sorted(rootdelta|rootpending):
 p=r/name.decode()
 if p.is_file()or p.is_symlink():add(p,'producer-delta-since-genuine26/'+name.decode(),str(p)not in rootmutable)
write(o/'privacy-exclusions.json',dict(explicit_in_root_private_exclusions=excluded,all_private_files_retained_locally=True,no_scientific_payload_filtered=True))
write(o/'private-transport-files-outside-declared-roots.json',dict(private_authorization_files_outside_declared_roots=private_inventory,never_exported_values=True,all_retained_locally=True))
write(o/'active-preparation-metadata.json',dict(still_active_publication_metadata=active,scope='own unfinished I/O process metadata only; whole completion logs retained separately before publication'))
write(o/'previous-payload-references.json',dict(already_genuine_held_payloads=previous_payload,previous26_identity=prioridentity))
for name in ['privacy-exclusions.json','private-transport-files-outside-declared-roots.json','active-preparation-metadata.json','previous-payload-references.json']:add(o/name,'control/'+name)
assert len({name for _,name,_ in files})==len(files)
current={name:sha(Path(name))for name in prior};linkstates={name:link_state(Path(name))for name in prior if Path(name).is_symlink()}
for name in git(c,'ls-files','-z','--',*owned).split(b'\0'):
 if not name:continue
 p=c/name.decode()
 if p.is_symlink():linkstates[str(p)]=link_state(p)
 if p.is_file():current[str(p)]=sha(p)
archive=ram/'whole-closed-science-27.tar.xz';rows=[]
print('Archiving',len(files),'members from',len(names),'whole roots;',len(deltas|pending),'consumer and',len(rootdelta|rootpending),'producer delta paths',flush=True)
with tarfile.open(archive,'w:xz',dereference=False,preset=6)as t:
 for index,(p,name,hold)in enumerate(sorted(files,key=lambda row:row[1])):
  info=t.gettarinfo(str(p),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  if p.is_symlink():
   state_now=link_state(p);row=dict(path=name,kind='symlink',bytes=0,local_original=str(p),held_original=hold,link_state=state_now)
   if hold:
    linkstates[str(p)]=state_now
    if p.is_file():current[str(p)]=sha(p)
   t.addfile(info)
  else:
   h=sha(p);row=dict(path=name,kind='file',bytes=p.stat().st_size,sha256=h,local_original=str(p),held_original=hold)
   if hold:current[str(p)]=h
   if info.islnk():row['archive_hardlink_target']=info.linkname
   with p.open('rb')as f:t.addfile(info,None if info.islnk()else f)
  rows.append(row)
  if index%500==0:print('archived',index+1,'/',len(files),flush=True)
 extras=[('control/root-base.txt',(rootbase+'\n').encode()),('control/consumer-base.txt',(consumer+'\n').encode()),('control/previous26-consumer-base.txt',(previous_consumer+'\n').encode()),('control/previous26-root-base.txt',(previous_root+'\n').encode()),('control/consumer-whole-delta-since-genuine26.patch',git(c,'diff',previous_consumer,'--binary','--full-index','--',*owned)),('control/consumer-pending.patch',git(c,'diff',consumer,'--binary','--full-index','--',*owned)),('control/producer-whole-delta-since-genuine26.patch',git(r,'diff',previous_root,'--binary','--full-index','--',*rootowned)),('control/genuine26-consumer-ledger.jsonl',priorledger),('control/published-fe914-consumer-ledger.jsonl',consumer_ledger),('control/published-69ab-producer-ledger.jsonl',root_ledger)]
 for name,body in extras:
  info=tarfile.TarInfo(name);info.size=len(body);info.mode=0o600;t.addfile(info,io.BytesIO(body));rows.append(dict(path=name,kind='file',bytes=len(body),sha256=hashlib.sha256(body).hexdigest()))
print('Archive closed',archive.stat().st_size,'bytes; checking every member',flush=True)
with tarfile.open(archive,'r:xz')as t:
 assert len(t.getmembers())==len(rows)
 for index,row in enumerate(rows):
  member=t.getmember(row['path'])
  if row['kind']=='symlink':assert member.issym()and member.linkname==row['link_state']['literal_target']
  else:
   with t.extractfile(member)as f:h=hashlib.file_digest(f,'sha256').hexdigest()
   assert h==row['sha256']and(member.size==row['bytes']or member.islnk()),row['path']
  if index%1000==0:print('roundtripped',index+1,'/',len(rows),flush=True)
current[str(archive)]=sha(archive)
write(o/'whole-members.json',dict(all_declared_closed_roots=names,all_nonsecret_file_symlink_members_no_filter=True,all_members_roundtripped=True,members=rows))
parts=[];whole=hashlib.sha256();offset=0
with archive.open('rb')as src:
 while True:
  body=src.read(32*1024*1024)
  if not body:break
  p=ram/(archive.name+f'.part-{len(parts):04d}');p.write_bytes(body);h=sha(p);current[str(p)]=h;parts.append(dict(name=p.name,bytes=len(body),sha256=h,offset=offset,local_original=str(p)));offset+=len(body);whole.update(body)
assert offset==archive.stat().st_size and whole.hexdigest()==sha(archive)
fixtures=[]
sources=[('passive-whole60-trace.json.xz',scratch/'ct101-original-relation-kernel-native-01/whole60-passive-trace.json'),('passive-whole100-native.json.xz',scratch/'ct101-original-relation-kernel-native-01/whole100-same-run-compared.json'),('relation-whole60-certificates.jsonl.xz',None),('relation-whole60-verdict.json.xz',scratch/'ct102-original-relation-rank-native-01/whole60-independent-verdict.json'),('source-character-whole60-witnesses.jsonl.xz',scratch/'ct103-original-relation-character-native-01/whole60-source-character-witnesses.jsonl'),('source-character-whole60-verdict.json.xz',scratch/'ct103-original-relation-character-native-01/whole60-source-character-verdict.json')]
for name,source in sources:
 p=o/name
 if source is None:
  source=scratch/'ct102-original-relation-rank-native-01/whole60-certificates.jsonl.xz';body=source.read_bytes();decoded=lzma.decompress(body);p.write_bytes(body);assert hashlib.sha256(decoded).hexdigest()==json.loads((scratch/'ct102-original-relation-rank-native-01/whole60-independent-verdict.json').read_text())['whole_certificate_sha256']
 else:
  decoded=source.read_bytes();body=lzma.compress(decoded);assert lzma.decompress(body)==decoded;p.write_bytes(body)
 current[str(p)]=sha(p);fixtures.append(dict(name=name,path=str(p),compressed_bytes=len(body),sha256=sha(p),decoded_bytes=len(decoded),decoded_sha256=hashlib.sha256(decoded).hexdigest(),whole_original=str(source),whole_roundtrip=True))
write(o/'whole-fixtures.json',fixtures)
links={name:row['literal_target']for name,row in linkstates.items()};assert all(links.get(name)==target for name,target in priorlinks.items())
write(o/'current-inputs.json',current);write(o/'symlink-targets.json',links);write(o/'symlink-states.json',linkstates)
guard=dict(schema='whole-input-byte-and-literal-link-state-guard/v2',all_prior58919_content_keys_retained=True,content_sha256=current,symlink_states=linkstates,scope='all priorcontent keys retained; every new file content and every literal symlink/targetstate held, including failed-layout dangling or directory links; no unknown-as-zero')
(o/'whole-current-inputs.json.xz').write_bytes(lzma.compress(json.dumps(guard,indent=2).encode()+b'\n'))
identity=dict(bytes=archive.stat().st_size,sha256=whole.hexdigest(),local_original=str(archive),parts=parts,ordered_reassembly_checked=True,chunk_bytes=32*1024*1024,all_member_bytes_and_literal_links_roundtripped=True,unfiltered_nonsecret_members=len(rows),archive_hardlinks=[dict(path=row['path'],target=row['archive_hardlink_target'])for row in rows if'archive_hardlink_target'in row])
write(o/'archive-parts.json',identity)
write(o/'preparation-observation.json',dict(at=datetime.now(timezone.utc).isoformat(),root_base=rootbase,consumer_base=consumer,previous_consumer=previous_consumer,previous_root=previous_root,prior_content_keys=58919,prior_literal_links=177,declared_released_metadata_changes=changed,current_content_guard_keys=len(current),all_literal_link_guards=len(links),non_file_link_guards={name:v for name,v in linkstates.items()if v['target_kind']!='file'},declared_whole_roots=names,consumer_delta_paths=len(deltas|pending),producer_delta_paths=len(rootdelta|rootpending),root_mutable_publication_metadata_snapshots=sorted(rootmutable),root_ledger_prefix_sha256=hashlib.sha256(root_ledger).hexdigest(),consumer_ledger_exact_sha256=hashlib.sha256(consumer_ledger).hexdigest(),previous_consumer_ledger_prefix_sha256=hashlib.sha256(priorledger).hexdigest(),whole_members=len(rows),archive=identity,fixtures=fixtures,explicit_private_authorization_files_outside_roots=len(private_inventory),scientific_payload_filtered=False,active_own_publication_metadata=active,hold='all science/raw/source/literal aliases/consumer-owned bytes and consumerledger held through actualoriginalremote replays BEFOREpublisher/bot, exactnormalFF/reassembly/terminal27checks',scope='unsigned wholebyte/link custody only; no new scientific computation or remotepublication inferred'))
for name,want in current.items():assert Path(name).is_file()and sha(Path(name))==want,name
for name,want in linkstates.items():assert Path(name).is_symlink()and link_state(Path(name))==want,name
assert(c/'pcc/ledger.jsonl').read_bytes()==consumer_ledger
assert(r/'pcc/ledger.jsonl').read_bytes().startswith(root_ledger)
print('Archive preparation0:',len(rows),'whole members;',archive.stat().st_size,'archive bytes;',len(parts),'ordered parts;',len(current),'content guards;',len(links),'literal links',flush=True)
