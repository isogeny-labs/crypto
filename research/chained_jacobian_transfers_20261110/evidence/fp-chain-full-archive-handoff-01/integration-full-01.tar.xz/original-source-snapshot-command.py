from pathlib import Path
import subprocess,json,hashlib,shutil,re,shlex
layout=Path('/workspace/scratch/ct54-chain-replay-layout');c=layout/'cryptanalysis';up=layout/'crypto';s=c/'experiments/chained-transfer-reference';out=Path('/workspace/scratch/ct54-chain-full-01');out.mkdir();assert not subprocess.check_output(['git','status','--porcelain'],cwd=c);assert not subprocess.check_output(['git','status','--porcelain'],cwd=up)
source=(s/'check-fp-chain.sh').read_text();consumer=[]
for rx in [r'consumer_paths=\((.*?)\n\)',r'consumer_paths\+=\((.*?)\n\)']:
 part=re.search(rx,source,re.S);assert part
 consumer+=shlex.split(part.group(1))
consumer=[p.replace('$consumer_study','experiments/chained-transfer-reference') for p in consumer];tracked=subprocess.check_output(['git','ls-files','-z','--',*consumer],cwd=c).split(b'\0');paths=[c/p.decode() for p in tracked if p]
old=json.loads(Path('/workspace/scratch/ct54-fp-chain-tests-01/before.json').read_text());upstream=[up/str(Path(p).relative_to('/workspace/crypto')) for p in old if p.startswith('/workspace/crypto/')];assert len(upstream)==722
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths+upstream)};(out/'before.json').write_text(json.dumps(before,indent=2)+'\n');(out/'selected-inputs.json').write_text(json.dumps({'upstream':len(upstream),'consumer':len(paths),'source_heads':{'upstream':'927a4efe5fe68b4270ae5989f3cbab0b68852f4b','consumer':'a39fefaa084756d0a58386253651a667e2ad9de6'}},indent=2)+'\n')
for p in paths+upstream:
 repo='upstream' if p.is_relative_to(up) else 'consumer';base=up if repo=='upstream' else c;dst=out/'inputs'/repo/p.relative_to(base);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
shim=out/'shim';shim.mkdir();f=shim/'rg';f.write_text('#!/usr/bin/env bash\nprintf "invoked\\n" >> /workspace/scratch/ct54-chain-full-01/rg-invoked.txt\nexit 99\n');f.chmod(0o755)
print('full prepared frozen',len(upstream),'+',len(paths),'=',len(before),flush=True)
