#!/usr/bin/env bash
set -u
export PATH="/workspace/scratch/ct54-chain-full-01/shim:$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export ELAN_TOOLCHAIN=leanprover/lean4:v4.35.0
export CARGO_TERM_COLOR=never
out=/workspace/scratch/ct54-chain-full-01
cp /workspace/scratch/ct54-chain-full-01.sh "$out/original-command.sh"
cd /workspace/scratch/ct54-chain-replay-layout/cryptanalysis
{
  cargo --version
  rustfmt --version
  lean --version
  uname -a
} > "$out/outer-toolchains.txt" 2>&1
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/outer-start.txt"
set +e
timeout 55m bash experiments/chained-transfer-reference/check-fp-chain.sh ../crypto "$out/run" > "$out/outer.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/outer.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/outer-finish.txt"
python3 - <<'PY'
from pathlib import Path
import hashlib,json
out=Path('/workspace/scratch/ct54-chain-full-01');before=json.loads((out/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before};changed=[p for p in before if before[p]!=after[p]];(out/'after.json').write_text(json.dumps(after,indent=2)+'\n');(out/'outer-guards.json').write_text(json.dumps({'count':len(before),'changed':changed,'rg_invoked':(out/'rg-invoked.txt').exists()},indent=2)+'\n');raise SystemExit(bool(changed or (out/'rg-invoked.txt').exists()))
PY
guard=$?
printf '%s\n' "$guard" > "$out/outer-guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
