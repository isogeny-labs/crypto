//! Actual process controls for the complete-census comparator. No cryptographic arithmetic.
use std::{env,fs,path::PathBuf,process::Command};
fn main() {
 let args:Vec<_>=env::args().collect();assert_eq!(args.len(),5);
 let out=PathBuf::from(&args[4]);fs::create_dir(&out).unwrap();
 let original=fs::read_to_string(&args[3]).unwrap();
 let needle="\"count\":";let first=original.find(needle).unwrap()+needle.len();
 let end=original[first..].find(|c:char|!c.is_ascii_digit()).unwrap()+first;
 let n:u64=original[first..end].parse().unwrap();
 let mut count=original.clone();count.replace_range(first..end,&n.checked_add(1).unwrap().to_string());
 let schema="n4-source-arithmetic-v1";assert_eq!(original.matches(schema).count(),1);
 let metadata=original.replace(schema,"n4-source-arithmetic-v1-tampered");
 for (name,text,expected) in [("positive",original,0),("count-plus-one",count,101),("metadata-changed",metadata,101)] {
  let golden=out.join(format!("{name}-whole-golden.json"));fs::write(&golden,text).unwrap();
  let result=Command::new(&args[1]).arg(&args[2]).arg(&golden).arg(out.join(format!("{name}-summary.json"))).output().unwrap();
  fs::write(out.join(format!("{name}.stdout")),result.stdout).unwrap();fs::write(out.join(format!("{name}.stderr")),result.stderr).unwrap();
  let actual=result.status.code().unwrap();fs::write(out.join(format!("{name}.exit")),format!("{actual}\n")).unwrap();
  assert_eq!(actual,expected,"{name}");println!("{name}: actualprocess{actual}/expected{expected}");
 }
}
