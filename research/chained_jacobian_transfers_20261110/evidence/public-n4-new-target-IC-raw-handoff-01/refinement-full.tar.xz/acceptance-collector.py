"""Whole original native equality and unchanged canonical PCC binding checks."""
from pathlib import Path
import hashlib,importlib.util,json,lzma,re,shutil,subprocess,sys
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';o=Path('/workspace/scratch/ct67-odd-product-refinement-full-02');d=s/'evidence/odd-product-refinement-independent-full-02';d.mkdir()
source='fb9ee1d613eebcd3459c02007b9bce06da218b47'
for p in [o/'native.exit',o/'guard.exit',o/'driver/original.exit',o/'driver/guard.exit',o/'driver/cleanliness.exit',o/'original-fixture-verify.exit']:assert p.read_text().strip()=='0',p
assert json.loads((o/'guards.json').read_text())==dict(count=703,changed=[])
phases=[line.split()for line in(o/'driver/phase-index.txt').read_text().splitlines()];assert len(phases)==10
for name,wanted,actual in phases:assert wanted==actual=='0'and(o/'driver'/(name+'.pipe-exits')).read_text().split()==['0','0']
canonical=lambda xs:sorted(json.dumps(x,sort_keys=True,separators=(',',':'))for x in xs)
log=(o/'driver/refinements.log').read_text();assert '1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in log
rows=[]
for line in log.splitlines():
 m=re.search(r'\b(N4_REFINEMENT_[A-Z0-9_]+) (\{.*\})$',line)
 if m:rows.append(dict(kind=m[1],data=json.loads(m[2])))
assert len(rows)==7 and canonical(rows)==canonical(json.loads(lzma.decompress((s/'ci_odd_refinement/expected-native.json.xz').read_bytes())))
raw=json.dumps(rows,indent=2).encode()+b'\n';z=lzma.compress(raw);assert len(z)<65536;(d/'whole-native.json.xz').write_bytes(z);(o/'all-native-records.json').write_bytes(raw)
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py');pcc=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pcc;spec.loader.exec_module(pcc)
verdicts=[]
for b in json.loads((s/'evidence/odd-product-refinement-bindings-01/claims.json').read_text()):
 v=json.loads((o/'driver'/('binding-'+Path(b['claim_path']).stem+'.log')).read_text());c=json.loads((r/b['claim_path']).read_text());assert v['verdict']=='pass'and not v['reasons']and v['commit']==source and v['claim_sha256']==pcc.claim_digest(c);verdicts.append(v)
assert len(verdicts)==3
for p in [o/'guards.json',o/'plan.json',o/'original-command.sh',o/'admission/results.json',o/'admission/restoration.json',o/'fixture-materialization.json']:shutil.copyfile(p,d/p.name)
(d/'exact-local-verdicts.json').write_text(json.dumps(verdicts,indent=2)+'\n')
(d/'observation.json').write_text(json.dumps(dict(source=source,producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2',all703_outer_guards_unchanged=True,portable_inputs=702,phase_pairs='ten ordered positive native/tee0/0',one_unfiltered_test=True,whole_JSON='ALL7 exactly equal/no exclusions',both_original_proof_gates='three declarations/zero trusted',all3_original_canonical_PCC_digests_match=True,four_actual_admission='2/nooutput/restored',original_HEAD_cleanliness_guards='0',fresh_physical_Git_siblings_and_outside_cache=True,genuine_fixture='already genuine physical original copied read-only and original-tool verified;not new remote read;CI separately hydrates',CI='separate twelve-workflow audit65dd08/108native55canonical',failed_setup='74ee4e preserved;caller hash only corrected in distinct02',scope='correctness;unsigned;geometric bridges partial;no computational advantage'),indent=2)+'\n')
shutil.copyfile(__file__,o/'acceptance-collector.py')
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Independent refinement full02 exactfb9ee/original3d passes all TENordered native+tee0/0,ONEunfiltered comprehensive native test/ALL7wholeJSON exact/noexclusions,both unchanged original3-declarationgates/zero trusted/3exactoriginalcanonicalPCCbindings. All703outer/702portable+self/HEAD/cleanlinessguards0;fouractualadmissioncontrols2/nooutput/restored. Fresh physicalGit siblings/outsidecoldcache;complete120752-byte alreadygenuinefixture copiedreadonly/originaltoolverify0,notnewremoteread. Actualtransportedkernels/all135/independentGaussianrank/all9/negativefree52control and identical-sourceAPIall3/32odd+zero/public5 reproduce147b66. Own12CI65dd08/108native55canonical separatelysettled. Failedsetup01/74ee4e whole retained;onlycallermalformednegativecontrolhash corrected. Whole rawcapture retained/genuinewholepublication pending;unsigned/geometrypartial/no computationaladvantage/globalrootgreen/signedexecution claim.']
for p in sorted(d.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(r))]
print(subprocess.check_output(cmd,cwd=r,text=True).strip())
