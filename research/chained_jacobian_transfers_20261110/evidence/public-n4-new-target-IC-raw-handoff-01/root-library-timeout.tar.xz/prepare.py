"""Governance/native command custody for the original unfiltered library gate."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess
r=Path('/workspace/crypto');o=Path('/workspace/scratch/ct68-root-library-regression-03');o.mkdir()
b=json.loads(Path('/workspace/scratch/ct68-original-root-fixture-regression-02/before.json').read_text());assert len(b)==2137 and all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in b.items())
(o/'before.json').write_text(json.dumps(b,indent=2)+'\n');shutil.copyfile(__file__,o/'prepare.py');shutil.copyfile(r/'research/chained_jacobian_transfers_20261110/ROOT_LIBRARY_REPLAY_PROTOCOL_03.md',o/'prospective-protocol.md')
state='''# Resume: Chained ECDLP Transfers — current2026-11-13T22:20UTC

## Goal
Continue actual DLP-preserving/chained Jacobian/prime-field transfers and admitted computational comparisons across crypto/cryptanalysis/locked autoresearcher;continue after each rung. [pcc:unverified]

## Lead / hypothesis
Actual3Jacobian52maps/transportedkernels/identical-sourceAPI and all15newtargetICpubliccases now work natively;full costs remainunknown. Restore authentic rootfixture through originalCIcredentials,then originalregression,while completing solverproof/report/CI. [pcc:unverified]

## Spec
Consumer sourcefb9ee147b66/702strictreplay;prospective98c6f0/708cb8 normallypublished2aee BEFOREsolvercode/dataworkflow. RootprotocolROOT_LIBRARY_REPLAY_PROTOCOL_03.md freezes unchangedfullrootcommand/1800s/2137guards afterauthenticrestoration1ea795. Original benchmarkadmission isNOTmet. [pcc:unverified]

## State
Rootcdfce1bb normallypublished;consumer3baa6d0a normallypublished includes dataonlyworkflow. Refinementfullb38c7f703guards/12CI65dd08108native55canonicalsettled. NewtargetICe869bdall60attempts/all15publiccases/2543guards,sourcecurrentlyuncommitted innew-target-ic;fullproof/report/strictCI next. Authentic originalfixture2293097bytesSHA8970667e restoredvia43516010720/job132198018704/artifact14081195285/wholeZIP4df508a9/all16members/originalverify0;SAMEbinary exactformerfailedtest passes1/6329filtered,all2137guards0,1ea795/consumer67ef1d. Originalrawfailures allretained. [pcc:unverified]

## Next steps
Collect originalroot library retry03:/workspace/scratch/ct68-root-library-regression-03/{native.log,native.exit,guard.exit};never infer globalpass beforeterminalnative0/unfilteredsummary. ConsumerfinishnewtargetICwritten+faithfulLean+report/strictCI/sourcecommit. UpdatePR1523/root3877/queue3904. Packwholeclosedct65full/CI,ct66native,ct67failedsetup/full/CI,ct68IC+fixture/regression;NEWcurrentguard07 before any rootbotFF. Complete costs/admission/beta coordinates/formal/mainmerge gaps remain. [pcc:unverified]

## Runs in flight
Starting ordinary originalrootlibraryretry03:bash /workspace/scratch/ct68-root-library-regression-03.sh;host=currentworkspace;native1800stimeout;warmcorrectnesscachect55;wholeoutputinmatchingdirectory. Checknative.exit/guard.exit andpreserveentirelog. No benchmark orpaidschedulerjob. [pcc:unverified]

## Stop and success conditions
Routineunitretryneedsnative0/all2137guards0/no filters orignores. Timeout/errorisretainedandnextfailurediagnosed,notglobalgreen. PerformanceexperimentsremainblockedbyoriginalS3checkpoint/livebudget/capacity/countercoverage;neverinfercostadvantagefromcorrectness. [pcc:unverified]

## Open questions
Actualgeometric/formalbridges/completebeta coordinates/allmapcosts/strongestmatchedICrho/mainledger/signing/reviews/conflict/vault8edec422locked/KBecdbunavailable. KeepqueueandGitHubcheckpointcurrent. [pcc:unverified]
'''
p=r/'.resume/RESUME.md';p.write_text(state+'\n---\n\n'+p.read_text())
reason='Routine unchanged root library unit regression required by repository after authentic missing fixture restoration;not an experiment,benchmark or paid launch;performance admission remains closed'
cmd='CHECKPOINT_SKIP=routine_original_unit_regression cargo test --release --lib --offline --locked'
p=subprocess.run(['python3','tools/pcc/pcc.py','ledger','append-bypass','--reason',reason,'--command',cmd],cwd=r,capture_output=True);(o/'original-ledger-optout.log').write_bytes(p.stdout+p.stderr);(o/'original-ledger-optout.exit').write_text(str(p.returncode)+'\n');assert p.returncode==0
p=subprocess.run(['timeout','60','bash','scripts/checkpoint.sh','push'],cwd=r,capture_output=True);(o/'original-checkpoint-push.log').write_bytes(p.stdout+p.stderr);(o/'original-checkpoint-push.exit').write_text(str(p.returncode)+'\n')
(o/'plan.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),command=['cargo','test','--release','--lib','--offline','--locked'],timeout_s=1800,guard_count=2137,cache='/workspace/scratch/ct55-g3-root-regression-01-build-cache',cache_scope='sameoriginalwarmcorrectnesscache/no cold or timing claim',fixture='authentic1ea795/restoredoriginal/localverify0/samebinarytargettestpass',original_checkpoint_push_exit=p.returncode,nonexperiment_exception=reason,original_ledger_append_bypass=0,scope='originalunfilteredrequiredunitregression;notexperiment/benchmark/globalpassbeforeterminal'),indent=2)+'\n')
text=Path('/workspace/scratch/ct55-g3-root-regression-02/original-command.sh').read_text().replace('out=/workspace/scratch/ct55-g3-root-regression-02','out=/workspace/scratch/ct68-root-library-regression-03').replace('timeout 1800 cargo test','CHECKPOINT_SKIP=routine_original_unit_regression timeout 1800 cargo test')
launcher=Path(str(o)+'.sh');launcher.write_text(text);shutil.copyfile(launcher,o/'original-command.sh');print(json.dumps(dict(launcher=str(launcher),guards=2137,original_checkpoint_push_exit=p.returncode,scope='ordinaryunitoptout documented/ledgerrecorded;performanceadmissionnotmet')),flush=True)
