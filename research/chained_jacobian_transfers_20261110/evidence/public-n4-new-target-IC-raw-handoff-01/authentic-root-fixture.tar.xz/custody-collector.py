"""Direct whole-control-plane custody in both repositories;no crypto arithmetic."""
from pathlib import Path
import hashlib,json,lzma,shutil,subprocess
root=Path('/workspace/crypto');consumer=Path('/workspace/cryptanalysis');capture=Path('/workspace/scratch/ct68-original-root-fixture-01');test=Path('/workspace/scratch/ct68-original-root-fixture-regression-02')
assert(test/'native.exit').read_text().strip()==(test/'guard.exit').read_text().strip()=='0'
assert json.loads((test/'guards.json').read_text())==dict(count=2137,changed=[])
for repo,relative in [(root,'research/chained_jacobian_transfers_20261110/evidence/authentic-root-fixture-restoration-01'),(consumer,'experiments/chained-transfer-public-target/evidence/authentic-root-fixture-restoration-01')]:
 d=repo/relative;d.mkdir()
 for p in [capture/'observation.json',capture/'whole-members.json',capture/'original-local-verify.log',capture/'original-local-verify.exit',test/'plan.json',test/'guards.json',test/'explicit-guard-mapping.json',test/'native.log',test/'native.exit',test/'guard.exit']:
  if p.suffix=='.log':(d/(p.name+'.xz')).write_bytes(lzma.compress(p.read_bytes()))
  else:shutil.copyfile(p,d/p.name)
 for stem in ['job-api','job-log-api','artifacts-api']:
  p=Path('/workspace/scratch/ct68-root-fixture-'+stem+'.json');(d/(stem+'.json.xz')).write_bytes(lzma.compress(p.read_bytes()))
 # The download response contains a temporary file-service bearer URL.
 # Preserve its original bytes in the private whole capture,not public Git.
 response=Path('/workspace/scratch/ct68-root-fixture-download-api.json');shutil.copyfile(response,capture/'original-download-api.json')
 (d/'whole-capture-catalog.json').write_text(json.dumps(dict(whole_raw=str(capture),whole_original_ZIP=dict(bytes=150168,sha256='4df508a91b12f84e49e1dd0d2be35ecc89e76b13293759dc463997289bed6150',GitHub_run=43516010720,artifact=14081195285,whole_members=16),original_download_API=dict(bytes=response.stat().st_size,sha256=hashlib.sha256(response.read_bytes()).hexdigest(),custody='whole original private capture;temporary file-service URL not copied to public Git'),targeted_raw=str(test),failed_preparation_raw='/workspace/scratch/ct68-original-root-fixture-regression-01',genuine_whole_archive_publication='pending unchanged publisher;original fixture itself successfully read from original S3 and restored'),indent=2)+'\n')
 cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Authentic original rootfixture restored through prospectivelypublished708cb8/2aee dataonlyworkflow3baa:run43516010720/job132198018704SUCCESS/original3dtool/config/manifest/pull0verify0/literal2293097bytesSHA8970667e. WHOLEGitHubartifact14081195285/150168bytes/SHA4df508a9/all16members bytechecked;originaltool/config/manifest equalpinnedGit;localoriginalverify0/Gitstatusunchanged/ignoredgenuinematerialization. SAMEoriginalcachedbinarySHA82029f63/exactformerfailedtest nowpasses1/0failed/6329filtered/native0/all2137guardsunchanged under37e18b:all2131nonexceptionoldinputs plus2currentWF/2historicalWFsnapshots/binary/fixture;initialprepguardfailure retained,no sourceorWFedit. Targetedmetadatafixture regressionONLY,not globalrootgatepass;unchangedfullgate isnext. Wholeprivatecapture retained/pendinggenuinewholearchive;temporarydownloadURL notpublicGit. Unsigned/no performance/mergewaiver.']
 for p in sorted(d.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(repo))]
 print(repo.name,subprocess.check_output(cmd,cwd=repo,text=True).strip(),flush=True)
shutil.copyfile(__file__,capture/'custody-collector.py')
