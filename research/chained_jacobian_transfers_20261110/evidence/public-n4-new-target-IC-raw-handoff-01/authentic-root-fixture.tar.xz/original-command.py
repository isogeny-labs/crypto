"""Artifact transport/custody only;uses the unchanged original artifact verifier."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib,io,json,shutil,subprocess,urllib.request,zipfile
r=Path('/workspace/crypto');o=Path('/workspace/scratch/ct68-original-root-fixture-01');o.mkdir()
j=json.loads(Path('/workspace/scratch/ct68-root-fixture-download-api.json').read_text());data=j.get('structuredContent',j)
if 'file_uri'not in data:data=data['structuredContent']
uri=data['file_uri'];url=uri['download_url']
with urllib.request.urlopen(url,timeout=120)as response:raw=response.read(4*1024*1024)
assert len(raw)==150168 and hashlib.sha256(raw).hexdigest()=='4df508a91b12f84e49e1dd0d2be35ecc89e76b13293759dc463997289bed6150'
(o/'whole-original-GitHub-artifact.zip').write_bytes(raw);members={}
with zipfile.ZipFile(io.BytesIO(raw))as z:
 names=z.namelist();assert len(names)==16 and len(set(names))==16
 for info in z.infolist():
  name=PurePosixPath(info.filename);assert not name.is_absolute()and'..'not in name.parts and info.file_size<3*1024*1024
  value=z.read(info);p=o/'members'/str(name);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(value);members[str(name)]=dict(bytes=len(value),sha256=hashlib.sha256(value).hexdigest())
(o/'whole-members.json').write_text(json.dumps(members,indent=2)+'\n')
m=o/'members';pin='3d49af7f3d0a28e76b79e4825c9d2324e85853d2'
assert(m/'producer-head.txt').read_text().strip()==pin
for name in ['pull','verify']:assert(m/(name+'.exit')).read_text().strip()=='0'
rel='research/curve25519_f1_targetwalk_20261108/sessions/k20-s0/records.jsonl';dest=r/rel;body=(m/'records.jsonl').read_bytes()
assert len(body)==2293097 and hashlib.sha256(body).hexdigest()=='8970667e2f18587eeb08d033123dab029b94042ac5c07c870b08988f1ee5b738'
for filename,original in [('original-artifacts.py','tools/artifacts/artifacts.py'),('original-config.json','.artifacts/config.json'),('original-manifest.json',str(Path(rel).parent/'.artifacts.json'))]:
 assert(m/filename).read_bytes()==subprocess.check_output(['git','show',pin+':'+original],cwd=r),filename
assert(m/'original-manifest.json').read_bytes()==(dest.parent/'.artifacts.json').read_bytes()
before_status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=r);(o/'before-Git-status.txt').write_bytes(before_status)
before={}
for line in(r/'research/chained_jacobian_transfers_20261110/producer-reference-01.sha256').read_text().splitlines()if(r/'research/chained_jacobian_transfers_20261110/producer-reference-01.sha256').exists()else[]:
 h,p=line.split('  ',1);path=(r/p).resolve();before[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest();assert before[str(path)]==h
if dest.exists():assert dest.read_bytes()==body
else:dest.write_bytes(body)
cmd=['python3','tools/artifacts/artifacts.py','verify',rel];p=subprocess.run(cmd,cwd=r,capture_output=True);(o/'original-local-verify.log').write_bytes(p.stdout+p.stderr);(o/'original-local-verify.exit').write_text(str(p.returncode)+'\n');assert p.returncode==0
assert subprocess.check_output(['git','check-ignore',rel],cwd=r,text=True).strip()==rel
assert subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=r)==before_status
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
(o/'observation.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),workflow_source='3baa6d0a44973ecbb5dd1db0b5a724e235727e78',run=43516010720,job=132198018704,artifact=14081195285,artifact_bytes=len(raw),artifact_sha256=hashlib.sha256(raw).hexdigest(),whole_members=16,original_producer=pin,original_tool_config_manifest_byte_equal_to_pinned_Git=True,path=rel,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),original_CI_pull_verify='0/0',original_local_verify=0,Git_status_byte_unchanged=True,ignored_genuine_original_materialization=True,scope='authentic original fixture restored;exact targeted regression and unchanged full root gate still pending'),indent=2)+'\n')
shutil.copyfile(__file__,o/'original-command.py');print(json.dumps(dict(restored=rel,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),original_local_verify=0,whole_members=16)))
