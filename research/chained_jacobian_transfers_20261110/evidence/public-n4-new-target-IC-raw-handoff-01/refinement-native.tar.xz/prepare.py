"""Freeze and snapshot byte inputs and invoke original native tools only."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';n=s/'odd-product-refinements'
o=Path('/workspace/scratch/ct66-odd-product-refinement-native-01');o.mkdir()
before=json.loads(Path('/workspace/scratch/ct63-odd-product-maps-native-02/before.json').read_text());assert len(before)==2485
for line in(s/'ci_odd_product/reference-01.sha256').read_text().splitlines():
 h,p=line.split('  ',1);p=(r/p).resolve();assert hashlib.sha256(p.read_bytes()).hexdigest()==h;before[str(p)]=h
for p in [s/'ci_odd_product/reference-01.sha256',s/'ODD_PRODUCT_REFINEMENT_PROTOCOL_01.md',*n.rglob('*')]:
 if p.is_file():before[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
for name in before:
 p=Path(name);dest=o/'source'/p.relative_to('/workspace');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
(o/'before.json').write_text(json.dumps(before,indent=2)+'\n');shutil.copyfile(__file__,o/'prepare.py');shutil.copyfile(s/'ODD_PRODUCT_REFINEMENT_PROTOCOL_01.md',o/'prospective-protocol.md')
(o/'plan.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),published_prospective='579e08/c37ad390 normalpush0 BEFOREcode',source='c37ad390 metadata/45ee45d2 science+additive refinement crate',guards=len(before),scope='one unfiltered test:actualgamma2/conjugate maps/all135 transported intersections/all9rational types/independentGaussian rank/wrong untransported control;all3 identical-output source API32odd+zero/public5/recovery/tags/allnegatives',compiler_timeout=900,native_timeout=900,native_address_space_KiB=2097152,cache='ct57 outside completed warm correctness cache;not cold',accounting='correctness only/no experiment or benchmark/performance admission remains unresolved'),indent=2)+'\n')
text=Path('/workspace/scratch/ct63-odd-product-maps-native-02.sh').read_text().replace('ct63-odd-product-maps-native-02','ct66-odd-product-refinement-native-01').replace('odd-product-maps/Cargo.toml','odd-product-refinements/Cargo.toml')
launcher=Path(str(o)+'.sh');launcher.write_text(text);shutil.copyfile(launcher,o/'original-command.sh')
print(str(launcher),len(before),flush=True)
