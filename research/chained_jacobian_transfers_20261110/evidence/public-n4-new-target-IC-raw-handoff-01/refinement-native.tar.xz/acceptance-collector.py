"""Custody/complete JSON capture and unchanged original PCC claims only."""
from pathlib import Path
import json,lzma,re,shutil,subprocess
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';o=Path('/workspace/scratch/ct66-odd-product-refinement-native-01');d=s/'evidence/odd-product-refinement-acceptance-01';d.mkdir()
for name in ['compile','native','guard']:assert(o/(name+'.exit')).read_text().strip()=='0'
assert json.loads((o/'guards.json').read_text())==dict(count=2514,changed=[])
log=(o/'native.log').read_text();assert '1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in log
rows=[]
for line in log.splitlines():
 m=re.search(r'\b(N4_REFINEMENT_[A-Z0-9_]+) (\{.*\})$',line)
 if m:rows.append(dict(kind=m[1],data=json.loads(m[2])))
assert len(rows)==7
assert [x['kind']for x in rows]==['N4_REFINEMENT_GAMMA2','N4_REFINEMENT_INTERSECTIONS','N4_REFINEMENT_KERNEL_TYPES',*['N4_REFINEMENT_SOURCE_API']*3,'N4_REFINEMENT_SCOPE']
raw=json.dumps(rows,indent=2).encode()+b'\n';z=lzma.compress(raw);assert len(z)<65536
(o/'all-native-records.json').write_bytes(raw);(d/'all-native-records.json.xz').write_bytes(z)
for name in ['guards.json','plan.json','original-command.sh','prospective-protocol.md','rustc.txt']:shutil.copyfile(o/name,d/name)
(d/'observation.json').write_text(json.dumps(dict(guards=2514,changed=[],native_tests='1passed/0failed/ignored/filtered',complete_native_records=7,actual_permutation=rows[0]['data']['actual_permutation'],transported_Gold=rows[0]['data']['actual_transported_Gold'],eligible_types=[x for x in rows[2]['data']['all9']if x['eligible_actual_Jacobian']],source_API='all3/33odd+zero total and public5/exact same complete classes/tagged packets/recovery/all controls',compile_native_guard='0/0/0',protocol='579e08/c37ad390 published BEFOREcode',scope='native correctness/conditional full geometric type pending written bridge/no performance claim'),indent=2)+'\n')
shutil.copyfile(__file__,o/'acceptance-collector.py')
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Refinement native01 under published579e08/c37ad390:one unfiltered comprehensive test0/zeroignoredfiltered/ALL2514 selected guards unchanged including original675/full originalnative inputs. Seven whole JSON records retained;actualgamma2 permutation[0,3,2,1]/all3 coefficient-conjugate Kohel maps/all64coordinateimages/4096linearitypairing/Frobenius/all135originalSmith=model census and independent Gaussian rank. TransportedGold2341872925073736705 gives eligible d3,2,1;conditional fulltypes C2^6,C4C2^4,C4^2C2^2 each timesC13^3/order140608,nonefreeC52^3;wrong untransportedGold gives2,3,0 and falsefree lastcase. FastSourceChain holds nooldPhiNorm,evaluates originaldouble/gamma/newPhi;identical complete classes/taggedpackets and source recovery vs frozen45eeChain on all3targets/32odd+zero/public5,exactell and noncanonical/offcurve/nonoddsource/nonoddtarget/foreigntags/mismatchedactualtarget controls. Structural call removal only;globalkernel/quotient/sourceproof/faithfulLean next;no benchmark/performance advantage/fullformalization/signedexecution claim.']
for p in sorted(d.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(r))]
print(subprocess.check_output(cmd,cwd=r,text=True).strip());print(json.dumps(dict(native_records=7,xz_bytes=len(z),permutation=rows[0]['data']['actual_permutation'],eligible=[{k:x[k]for k in ['target','dimension','C4_factors','C2_factors','C13_factors','free_C52_cubed','wrong_untransported_dimension']}for x in rows[2]['data']['all9']if x['eligible_actual_Jacobian']])) )
