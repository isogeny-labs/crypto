"""Native log/API custody and calls to the unchanged PCC tooling only."""
from pathlib import Path
from datetime import datetime, timezone
import json, re, shutil, subprocess, lzma, hashlib, importlib.util, sys
r=Path('/workspace/cryptanalysis'); s=r/'experiments/chained-transfer-public-target'
def claim(statement,dest):
    cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement',statement]
    for p in sorted(dest.iterdir()):
        if p.is_file(): cmd+=['--proof','attestation:'+str(p.relative_to(r))]
    print(subprocess.check_output(cmd,cwd=r,text=True).strip(),flush=True)
def records(log):
    rows=[]
    for line in log.splitlines():
        m=re.search(r'\b(N4_[A-Z0-9_]+) (\{.*\})$',line)
        if m: rows.append(dict(kind=m[1],data=json.loads(m[2])))
    return rows
canonical=lambda x: sorted(json.dumps(t,sort_keys=True,separators=(',',':')) for t in x)
o=Path('/workspace/scratch/ct67-odd-product-refinement-own-CI-raw-01'); source='fb9ee1d613eebcd3459c02007b9bce06da218b47'
rows={}; verdicts=[]; jobs=[]
for label,run,job,marker in [('completed', 43514341275, 132192299943, 'Completed-descent replay complete:'), ('V2', 43514341004, 132192298898, 'Completed V2/rho replay complete:'), ('P1', 43514340959, 132192299092, 'Public-target N4 replay complete:'), ('two-primary', 43514340999, 132192298707, 'Actual two-primary replay complete:'), ('bitangents', 43514340897, 132192298829, 'Actual bitangent replay complete:'), ('kernels', 43514341165, 132192299286, 'Actual kernel census/replay complete:'), ('gluing', 43514340939, 132192298625, 'Actual alternative gluing replay complete:'), ('chain', 43514340895, 132192298940, 'Actual chain-kernel replay complete:'), ('odd', 43514341154, 132192298990, 'Actual odd-source replay complete:'), ('product', 43514341106, 132192300302, 'Actual odd-product replay complete:'), ('refinement', 43514341006, 132192299070, 'Actual odd-product refinement replay complete:'), ('PCC', 43514340906, 132192298676, 'Verify all claims')]:
    api=json.loads((o/(label+'-jobs-api.json')).read_text())['structuredContent']['jobs']
    target=[x for x in api if x['id']==job]; assert len(target)==1
    j=target[0]; assert (j['run_id'],j['status'],j['conclusion'])==(run,'completed','success')
    log=json.loads((o/(label+'-log-api.json')).read_text())['structuredContent']['content']
    assert source in log and (label=='PCC' or marker in log)
    (o/(label+'-whole-job.log')).write_text(log)
    jobs.append(dict(label=label,run=run,job=job,status='completed',conclusion='success'))
    if label=='PCC':
        sign=[j for j in api if j['name']=='sign']; assert len(sign)==1 and sign[0]['conclusion']=='skipped'
        assert any('exit 2 = not covered is allowed' in step['name'] for step in j['steps'])
    else:
        rows[label]=records(log)
        for line in log.splitlines():
            if '{"claim_id":' in line: verdicts.append(json.loads(line[line.index('{"claim_id":'):]))
assert {k:len(v) for k,v in rows.items()}==dict(completed=17,V2=12,P1=13,**{'two-primary':4,'bitangents':4,'kernels':8,'gluing':18,'chain':4,'odd':4,'product':17,'refinement':7})
def omitted(rows):
    rows=json.loads(json.dumps(rows))
    for row in rows:
        methods=['baseline','candidate'] if row['kind']=='N4_COMPLETED_ATTEMPT' else ['public'] if row['kind']=='N4_PUBLIC_ATTEMPT' else []
        for method in methods:
            for phase in row['data'][method]['phases']: del phase['wall']
            row['data'][method]['stats']=[p for p in row['data'][method]['stats'] if p[0]!='wall_total']
    return canonical(rows)
gluing_expected=[]
for label in ['models','maps']:gluing_expected+=json.loads(lzma.decompress((s/'ci_gluing'/('expected-'+label+'.json.xz')).read_bytes()))
product_expected=json.loads(lzma.decompress((s/'ci_odd_product/expected-models.json.xz').read_bytes()))+json.loads(lzma.decompress((s/'evidence/odd-product-maps-acceptance-02/all-native-records.json.xz').read_bytes()))
assert canonical(rows['refinement'])==canonical(json.loads(lzma.decompress((s/'ci_odd_refinement/expected-native.json.xz').read_bytes())))
assert canonical(rows['product'])==canonical(product_expected)
assert canonical(rows['odd'])==canonical(json.loads(lzma.decompress((s/'ci_odd/expected-kernels.json.xz').read_bytes())))
assert canonical(rows['chain'])==canonical(json.loads(lzma.decompress((s/'ci_chain/expected-kernels.json.xz').read_bytes())))
assert canonical(rows['gluing'])==canonical(gluing_expected)
assert canonical(rows['kernels'])==canonical(json.loads((s/'ci_kernels/expected-native.json').read_text()))
assert canonical(rows['bitangents'])==canonical(json.loads((s/'ci_bitangents/expected-native.json').read_text()))
assert canonical(rows['two-primary'])==canonical(json.loads((s/'ci_two_primary/expected-native.json').read_text()))
assert omitted(rows['completed'])==omitted(json.loads((s/'ci_completed/expected-native.json').read_text()))
assert omitted(rows['P1'])==omitted(json.loads((s/'evidence/unit-acceptance-01/all-native-records.json').read_text()))
for prefix,name in [('N4_V2_','expected-native-v2.json'),('N4_RHO_','expected-native-rho.json')]:
    assert canonical([x for x in rows['V2'] if x['kind'].startswith(prefix)])==canonical(json.loads((s/'ci_v2'/name).read_text()))
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py'); pcc=importlib.util.module_from_spec(spec); sys.modules[spec.name]=pcc; spec.loader.exec_module(pcc)
digests={}
for folder in ['lean-bindings-01','origin-lean-bindings-01','prime-field-bindings-02','two-primary-bindings-01','bitangent-bindings-01','kernel-bindings-01','gluing-models-bindings-01','gluing-chain-bindings-01','chain-kernel-bindings-01','odd-source-bindings-01','odd-product-chain-bindings-01','odd-product-refinement-bindings-01']:
    for binding in json.loads((s/'evidence'/folder/'claims.json').read_text()):
        c=json.loads((r/binding['claim_path']).read_text()); digests[c['id']]=pcc.claim_digest(c)
assert len(verdicts)==len(digests)==55 and set(digests)=={v['claim_id'] for v in verdicts}
for v in verdicts: assert v['verdict']=='pass' and not v['reasons'] and v['commit']==source and v['claim_sha256']==digests[v['claim_id']]
full=Path('/workspace/scratch/ct67-odd-product-refinement-full-02')
shutil.copytree(full/'driver/source',o/'source')
shutil.copyfile(full/'original-reference.sha256',o/'source/cryptanalysis/experiments/chained-transfer-public-target/ci_odd_refinement/reference-01.sha256')
assert sum(p.is_file() for p in (o/'source').rglob('*'))==703
for name,data in [('all-native-records.json',rows),('all55-exact-verdicts.json',verdicts),('original-PCC-canonical-digests.json',digests)]: (o/name).write_text(json.dumps(data,indent=2)+'\n')
shutil.copyfile(__file__,o/'original-collector.py')
meta=dict(at=datetime.now(timezone.utc).isoformat(),source=source,jobs=jobs,native_records=108,all108_original_native_JSON_match_except_ONLY_recorded_wall_walltotal_for_candidate_and_P1=True,raw_timings_retained=True,all55_original_canonical_PCC_digests_match=True,exact_verdicts='pass/unsigned',PCC_sign='legitimately skipped featurebranch',PCC_gate='success; explicitly allows notcovered exit2',whole_logs_API_and703_source_snapshots_retained=True,artifact_ZIP_downloaded=False,CI_guard_scope='successful original replay steps and complete original markers; standalone exit files not downloaded; separate physical703full02 is running;no terminal full claim; CI standalone guards not downloaded',scope='correctness observations; not full formal geometry, cost advantage or signed execution')
(o/'plan.json').write_text(json.dumps(meta,indent=2)+'\n')
d=s/'evidence/odd-product-refinement-own-CI-01';d.mkdir();(d/'observation.json').write_text(json.dumps(meta,indent=2)+'\n')
catalog=[]
def retain(name,raw):
    z=lzma.compress(raw);lossless=o/'lossless';lossless.mkdir(exist_ok=True);(lossless/(name+'.xz')).write_bytes(z)
    record=dict(name=name,raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),xz_bytes=len(z),xz_sha256=hashlib.sha256(z).hexdigest(),whole_local_capture=str(lossless/(name+'.xz')),genuine_whole_archive_publication='pending next unchanged publisher; no remote availability claim')
    if len(z)<65536:(d/(name+'.xz')).write_bytes(z);record['small_whole_Git_object']=str((d/(name+'.xz')).relative_to(r))
    else:(d/(name+'.hash.json')).write_text(json.dumps(record,indent=2)+'\n')
    catalog.append(record)
for name in ['all-native-records.json','all55-exact-verdicts.json','original-PCC-canonical-digests.json']:retain(name,(o/name).read_bytes())
for label in ['completed','V2','P1','two-primary','bitangents','kernels','gluing','chain','odd','product','refinement','PCC']:retain(label+'-whole-job.log',(o/(label+'-whole-job.log')).read_bytes())
(d/'whole-object-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
claim('Exactfb9ee1d6 ownCI all TWELVE unique workflows SUCCESS. ALL108 native JSON match originals(ONLY old completed candidate/baseline and P1 wall and wall_total omitted/raw retained);all55 exact local PCC verdicts pass/current source/original canonical digests. New refinement one unfiltered comprehensive test/ALL7wholeJSON exact/noexclusions/bothoriginal3-declarationgates/3bindings;actual transportedkernels/all135/nonefree52/negativecontrol and identical-sourceAPIall3/public5. Prior complete120752-byte fixture fresh pinnedoriginaltool remotehydration succeeds. Whole12 logs/API/703source snapshots retained;large combinedrecords/gluing/productlogs catalogued for next genuinewholearchive,smallwholeobjects Git,no newremoteavailability claim. PCCnotcovered2/signlegitimatelyskipped;CIguardscope originalsuccessfulsteps/markers,notdownloadedartifactZIP. Separate physical703full02 currently running;no terminalfullsuccess claim here. Unsigned/partialgeometry/no computationaladvantage/globalrootgreen.',d)
print(json.dumps(dict(native=108,digests=55,source=source,whole_objects=[dict(name=x['name'],xz_bytes=x['xz_bytes'],small_Git='small_whole_Git_object'in x)for x in catalog])),flush=True)
