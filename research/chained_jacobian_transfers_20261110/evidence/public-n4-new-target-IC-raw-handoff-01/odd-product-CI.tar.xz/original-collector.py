"""Native log/API custody and calls to the unchanged PCC tooling only."""
from pathlib import Path
from datetime import datetime, timezone
import json, re, shutil, subprocess, lzma, hashlib, importlib.util, sys
r=Path('/workspace/cryptanalysis'); s=r/'experiments/chained-transfer-public-target'
def claim(statement,dest):
    cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement',statement]
    for p in sorted(dest.iterdir()):
        if p.is_file(): cmd+=['--proof','attestation:'+str(p.relative_to(r))]
    print(subprocess.check_output(cmd,cwd=r,text=True).strip(),flush=True)
def records(log):
    rows=[]
    for line in log.splitlines():
        m=re.search(r'\b(N4_[A-Z0-9_]+) (\{.*\})$',line)
        if m: rows.append(dict(kind=m[1],data=json.loads(m[2])))
    return rows
canonical=lambda x: sorted(json.dumps(t,sort_keys=True,separators=(',',':')) for t in x)
o=Path('/workspace/scratch/ct65-odd-product-own-CI-raw-01'); source='45ee45d295b069a8425af423a26e1502219f88e7'
rows={}; verdicts=[]; jobs=[]
for label,run,job,marker in [('completed', 43508244080, 132171409688, 'Completed-descent replay complete:'), ('V2', 43508244503, 132171410599, 'Completed V2/rho replay complete:'), ('P1', 43508244088, 132171409653, 'Public-target N4 replay complete:'), ('two-primary', 43508244093, 132171409703, 'Actual two-primary replay complete:'), ('bitangents', 43508244429, 132171410709, 'Actual bitangent replay complete:'), ('kernels', 43508244101, 132171409788, 'Actual kernel census/replay complete:'), ('gluing', 43508244030, 132171409331, 'Actual alternative gluing replay complete:'), ('chain', 43508244043, 132171410164, 'Actual chain-kernel replay complete:'), ('odd', 43508244079, 132171409677, 'Actual odd-source replay complete:'), ('product', 43508244485, 132171411152, 'Actual odd-product replay complete:'), ('PCC', 43508244070, 132171409373, 'Verify all claims')]:
    api=json.loads((o/(label+'-jobs-api.json')).read_text())['structuredContent']['jobs']
    target=[x for x in api if x['id']==job]; assert len(target)==1
    j=target[0]; assert (j['run_id'],j['status'],j['conclusion'])==(run,'completed','success')
    log=json.loads((o/(label+'-log-api.json')).read_text())['structuredContent']['content']
    assert source in log and (label=='PCC' or marker in log)
    (o/(label+'-whole-job.log')).write_text(log)
    jobs.append(dict(label=label,run=run,job=job,status='completed',conclusion='success'))
    if label=='PCC':
        sign=[j for j in api if j['name']=='sign']; assert len(sign)==1 and sign[0]['conclusion']=='skipped'
        assert any('exit 2 = not covered is allowed' in step['name'] for step in j['steps'])
    else:
        rows[label]=records(log)
        for line in log.splitlines():
            if '{"claim_id":' in line: verdicts.append(json.loads(line[line.index('{"claim_id":'):]))
assert {k:len(v) for k,v in rows.items()}==dict(completed=17,V2=12,P1=13,**{'two-primary':4,'bitangents':4,'kernels':8,'gluing':18,'chain':4,'odd':4,'product':17})
def omitted(rows):
    rows=json.loads(json.dumps(rows))
    for row in rows:
        methods=['baseline','candidate'] if row['kind']=='N4_COMPLETED_ATTEMPT' else ['public'] if row['kind']=='N4_PUBLIC_ATTEMPT' else []
        for method in methods:
            for phase in row['data'][method]['phases']: del phase['wall']
            row['data'][method]['stats']=[p for p in row['data'][method]['stats'] if p[0]!='wall_total']
    return canonical(rows)
gluing_expected=[]
for label in ['models','maps']:gluing_expected+=json.loads(lzma.decompress((s/'ci_gluing'/('expected-'+label+'.json.xz')).read_bytes()))
product_expected=json.loads(lzma.decompress((s/'ci_odd_product/expected-models.json.xz').read_bytes()))+json.loads(lzma.decompress((s/'evidence/odd-product-maps-acceptance-02/all-native-records.json.xz').read_bytes()))
assert canonical(rows['product'])==canonical(product_expected)
assert canonical(rows['odd'])==canonical(json.loads(lzma.decompress((s/'ci_odd/expected-kernels.json.xz').read_bytes())))
assert canonical(rows['chain'])==canonical(json.loads(lzma.decompress((s/'ci_chain/expected-kernels.json.xz').read_bytes())))
assert canonical(rows['gluing'])==canonical(gluing_expected)
assert canonical(rows['kernels'])==canonical(json.loads((s/'ci_kernels/expected-native.json').read_text()))
assert canonical(rows['bitangents'])==canonical(json.loads((s/'ci_bitangents/expected-native.json').read_text()))
assert canonical(rows['two-primary'])==canonical(json.loads((s/'ci_two_primary/expected-native.json').read_text()))
assert omitted(rows['completed'])==omitted(json.loads((s/'ci_completed/expected-native.json').read_text()))
assert omitted(rows['P1'])==omitted(json.loads((s/'evidence/unit-acceptance-01/all-native-records.json').read_text()))
for prefix,name in [('N4_V2_','expected-native-v2.json'),('N4_RHO_','expected-native-rho.json')]:
    assert canonical([x for x in rows['V2'] if x['kind'].startswith(prefix)])==canonical(json.loads((s/'ci_v2'/name).read_text()))
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py'); pcc=importlib.util.module_from_spec(spec); sys.modules[spec.name]=pcc; spec.loader.exec_module(pcc)
digests={}
for folder in ['lean-bindings-01','origin-lean-bindings-01','prime-field-bindings-02','two-primary-bindings-01','bitangent-bindings-01','kernel-bindings-01','gluing-models-bindings-01','gluing-chain-bindings-01','chain-kernel-bindings-01','odd-source-bindings-01','odd-product-chain-bindings-01']:
    for binding in json.loads((s/'evidence'/folder/'claims.json').read_text()):
        c=json.loads((r/binding['claim_path']).read_text()); digests[c['id']]=pcc.claim_digest(c)
assert len(verdicts)==len(digests)==52 and set(digests)=={v['claim_id'] for v in verdicts}
for v in verdicts: assert v['verdict']=='pass' and not v['reasons'] and v['commit']==source and v['claim_sha256']==digests[v['claim_id']]
full=Path('/workspace/scratch/ct65-odd-product-full-01')
shutil.copytree(full/'driver/source',o/'source')
shutil.copyfile(full/'original-reference.sha256',o/'source/cryptanalysis/experiments/chained-transfer-public-target/ci_odd_product/reference-01.sha256')
assert sum(p.is_file() for p in (o/'source').rglob('*'))==676
for name,data in [('all-native-records.json',rows),('all52-exact-verdicts.json',verdicts),('original-PCC-canonical-digests.json',digests)]: (o/name).write_text(json.dumps(data,indent=2)+'\n')
shutil.copyfile(__file__,o/'original-collector.py')
meta=dict(at=datetime.now(timezone.utc).isoformat(),source=source,jobs=jobs,native_records=101,all101_original_native_JSON_match_except_ONLY_recorded_wall_walltotal_for_candidate_and_P1=True,raw_timings_retained=True,all52_original_canonical_PCC_digests_match=True,exact_verdicts='pass/unsigned',PCC_sign='legitimately skipped featurebranch',PCC_gate='success; explicitly allows notcovered exit2',whole_logs_API_and676_source_snapshots_retained=True,artifact_ZIP_downloaded=False,CI_guard_scope='successful original replay steps and complete original markers; standalone exit files not downloaded; separate localfull676 417921 terminal guards0; CI standalone guards not downloaded',scope='correctness observations; not full formal geometry, cost advantage or signed execution')
(o/'plan.json').write_text(json.dumps(meta,indent=2)+'\n')
d=s/'evidence/odd-product-own-CI-01';d.mkdir();(d/'observation.json').write_text(json.dumps(meta,indent=2)+'\n')
catalog=[]
def retain(name,raw):
    z=lzma.compress(raw);lossless=o/'lossless';lossless.mkdir(exist_ok=True);(lossless/(name+'.xz')).write_bytes(z)
    record=dict(name=name,raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),xz_bytes=len(z),xz_sha256=hashlib.sha256(z).hexdigest(),whole_local_capture=str(lossless/(name+'.xz')),genuine_whole_archive_publication='pending next unchanged publisher; no remote availability claim')
    if len(z)<65536:(d/(name+'.xz')).write_bytes(z);record['small_whole_Git_object']=str((d/(name+'.xz')).relative_to(r))
    else:(d/(name+'.hash.json')).write_text(json.dumps(record,indent=2)+'\n')
    catalog.append(record)
for name in ['all-native-records.json','all52-exact-verdicts.json','original-PCC-canonical-digests.json']:retain(name,(o/name).read_bytes())
for label in ['completed','V2','P1','two-primary','bitangents','kernels','gluing','chain','odd','product','PCC']:retain(label+'-whole-job.log',(o/(label+'-whole-job.log')).read_bytes())
(d/'whole-object-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
claim('Exact45ee45d2 ownCI all ELEVEN unique workflows SUCCESS. ALL101 native JSON match originals(ONLY old completed candidate/baseline and P1 wall and wall_total omitted/raw retained);all52 exact local PCC verdicts pass/current source/original canonical digests. New odd-product TWO unfiltered tests/ALL17 whole JSON exact/no exclusions/both original2-declaration gates/2 bindings;fresh pinned original-tool remote hydration of complete120752-byte genuine fixture succeeds. Whole11 logs/API/676 source snapshots retained;large combined records/gluing/product logs catalogued for next genuine whole archive,small whole objects Git,no new remote availability claim. PCC notcovered2/sign legitimately skipped;CI guard scope successful original steps/markers,not downloaded standalone artifact ZIP;separate physical full676 417921 terminal guards0. Unsigned/partial geometry/no computational advantage/global-root claim.',d)
print(json.dumps(dict(native=101,digests=52,source=source,whole_objects=[dict(name=x['name'],xz_bytes=x['xz_bytes'],small_Git='small_whole_Git_object'in x)for x in catalog])),flush=True)
