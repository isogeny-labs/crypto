"""Custody and whole-output comparisons; original engines and PCC remain unchanged."""
from pathlib import Path
import hashlib, importlib.util, json, lzma, re, shutil, subprocess, sys
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target'
o=Path('/workspace/scratch/ct65-odd-product-full-01');d=s/'evidence/odd-product-independent-full-01';d.mkdir()
source='45ee45d295b069a8425af423a26e1502219f88e7'
for p in [o/'native.exit',o/'guard.exit',o/'driver/original.exit',o/'driver/guard.exit',o/'driver/cleanliness.exit',o/'original-fixture-verify.exit']:assert p.read_text().strip()=='0',p
assert json.loads((o/'guards.json').read_text())==dict(count=676,changed=[])
phases=[line.split()for line in(o/'driver/phase-index.txt').read_text().splitlines()];assert len(phases)==12
for name,wanted,actual in phases:assert wanted==actual=='0'and(o/'driver'/(name+'.pipe-exits')).read_text().split()==['0','0']
canonical=lambda xs:sorted(json.dumps(x,sort_keys=True,separators=(',',':'))for x in xs)
rows=[]
for label,count,path in [('models',9,s/'ci_odd_product/expected-models.json.xz'),('maps',8,s/'evidence/odd-product-maps-acceptance-02/all-native-records.json.xz')]:
    log=(o/'driver'/(label+'.log')).read_text();assert '1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in log
    current=[]
    for line in log.splitlines():
        m=re.search(r'\b(N4_ODD_PRODUCT_[A-Z0-9_]+) (\{.*\})$',line)
        if m:current.append(dict(kind=m[1],data=json.loads(m[2])))
    assert len(current)==count and canonical(current)==canonical(json.loads(lzma.decompress(path.read_bytes())))
    rows+=current
assert len(rows)==17
raw=json.dumps(rows,indent=2).encode()+b'\n';z=lzma.compress(raw)
(o/'all-native-records.json').write_bytes(raw)
if len(z)<65536:(d/'whole-native.json.xz').write_bytes(z)
else:(d/'whole-native.hash.json').write_text(json.dumps(dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),whole_capture=str(o/'all-native-records.json'),remote_publication='pending;no availability claim'),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py');pcc=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pcc;spec.loader.exec_module(pcc)
verdicts=[]
for b in json.loads((s/'evidence/odd-product-chain-bindings-01/claims.json').read_text()):
    v=json.loads((o/'driver'/('binding-'+Path(b['claim_path']).stem+'.log')).read_text())
    c=json.loads((r/b['claim_path']).read_text());assert v['verdict']=='pass'and not v['reasons']and v['commit']==source and v['claim_sha256']==pcc.claim_digest(c)
    verdicts.append(v)
assert len(verdicts)==2
for p in [o/'guards.json',o/'plan.json',o/'original-command.sh',o/'admission/results.json',o/'admission/restoration.json',o/'fixture-materialization.json']:shutil.copyfile(p,d/p.name)
(d/'exact-local-verdicts.json').write_text(json.dumps(verdicts,indent=2)+'\n')
(d/'observation.json').write_text(json.dumps(dict(source=source,producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2',all676_outer_guards_unchanged=True,portable_inputs=675,phase_pairs='twelve ordered positive native/tee0/0',two_unfiltered_tests=True,whole_JSON='ALL17 exactly equal/no exclusions',both_original_proof_gates='two declarations/zero trusted',all2_original_canonical_PCC_digests_match=True,four_actual_admission='2/nooutput/restored',original_HEAD_cleanliness_guards='0',fresh_physical_Git_siblings_and_outside_cache=True,genuine_fixture='already genuine physical original copied read-only and original-tool verified;not new remote read;CI separately hydrates',CI='separate eleven-workflow audit',scope='correctness;unsigned;geometric bridges partial;no computational advantage'),indent=2)+'\n')
shutil.copyfile(__file__,o/'acceptance-collector.py')
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Independent odd-product full01 exact45ee45d2/original3d passes all twelve ordered native+tee0/0,TWO unfiltered native tests/ALL17 whole JSON exact/no exclusions,both unchanged original2-declaration gates/zero trusted/two exact original canonical PCC bindings. All676 outer/675 portable+self/HEAD/cleanliness guards0;four actual admission controls reject2/nooutput/restored. Fresh physical Git siblings/outside cold cache;complete120752-byte already genuine fixture copied read-only and original-tool verified0,not a new remote read. Actual six Aprime models/three complete different-product Jacobian F/G,both52/public5/reusable source recovery reproduce9722d7/9561ce. Whole raw capture retained;large whole-data publication pending. Unsigned/actual geometry partial/no computational advantage/global-root or signed-execution claim.']
for p in sorted(d.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(r))]
print(subprocess.check_output(cmd,cwd=r,text=True).strip())
