"""Keep historical/current workflow guards explicitly;original science unchanged."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
r=Path('/workspace/crypto');o=Path('/workspace/scratch/ct68-original-root-fixture-regression-02');o.mkdir();old=Path('/workspace/scratch/ct55-g3-root-fixture-diagnostic-01')
historical=json.loads((old/'before.json').read_text());assert len(historical)==2133
changed=json.loads(Path('/workspace/scratch/ct68-original-root-fixture-regression-01/preparation-guard-mismatch.json').read_text());assert {x['path']for x in changed}=={'/workspace/cryptanalysis/.github/workflows/chained-transfer-reference.yml','/workspace/cryptanalysis/.github/workflows/pcc-gate.yml'}
mapping=[];before={}
for p,h in historical.items():
 current=hashlib.sha256(Path(p).read_bytes()).hexdigest();before[p]=current
 if current!=h:
  assert p in {x['path']for x in changed}
  snapshot=Path('/workspace/scratch/ct55-g3-root-regression-01/source')/Path(p).relative_to('/workspace');assert hashlib.sha256(snapshot.read_bytes()).hexdigest()==h
  before[str(snapshot)]=h;mapping.append(dict(current_path=p,historical_sha256=h,current_sha256=current,historical_snapshot=str(snapshot),scope='consumerworkflow metadata,not Rust/Cargo/test/include;bothcurrent+historicalretained'))
assert len(mapping)==2
binary=Path('/workspace/scratch/ct55-g3-root-regression-01-build-cache/release/deps/crypto_lib-0f5740d1cfe22c09');digest=hashlib.sha256(binary.read_bytes()).hexdigest();assert digest=='82029f639d326548a7d44ea0f55477880f0c50cf358edeec3a6827f22591a9bd'
fixture=r/'research/curve25519_f1_targetwalk_20261108/sessions/k20-s0/records.jsonl';h=hashlib.sha256(fixture.read_bytes()).hexdigest();assert h=='8970667e2f18587eeb08d033123dab029b94042ac5c07c870b08988f1ee5b738'
before[str(binary)]=digest;before[str(fixture)]=h;assert len(before)==2137
(o/'before.json').write_text(json.dumps(before,indent=2)+'\n');(o/'historical-before.json').write_text(json.dumps(historical,indent=2)+'\n');(o/'explicit-guard-mapping.json').write_text(json.dumps(mapping,indent=2)+'\n');shutil.copyfile(__file__,o/'prepare.py')
(o/'plan.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),protocol='708cb8/ROOT_FIXTURE_REGRESSION_GUARD_PROTOCOL_02 before run',command=json.loads((old/'plan.json').read_text())['command'],timeout_s=120,original_binary_sha256=digest,original_binary_bytes=binary.stat().st_size,guard_count=2137,source='all2131 originalnonexceptioninputs exact;2 currentconsumerWF+2 historicalsnapshotWF separatelyguarded;binary+fixture guarded;noRust/Cargo/test/science exception',fixture='43516010720/14081195285/wholeZIP+members/originalverify0',scope='exactformerlyfailing originalmetadatafixturetest;not globalrootacceptance or performance'),indent=2)+'\n')
text=(old/'original-command.sh').read_text().replace('out=/workspace/scratch/ct55-g3-root-fixture-diagnostic-01','out=/workspace/scratch/ct68-original-root-fixture-regression-02').replace('timeout 60 ','timeout 120 ')
launcher=Path(str(o)+'.sh');launcher.write_text(text);shutil.copyfile(launcher,o/'original-command.sh');print(launcher,len(before),flush=True)
