"""Whole native-output custody and calls to the unchanged PCC tool."""
from pathlib import Path
import hashlib,json,lzma,re,shutil,subprocess
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';o=Path('/workspace/scratch/ct68-new-target-IC-native-01');d=s/'evidence/new-target-IC-acceptance-01';d.mkdir()
for label in ['compile','native','guard']:assert(o/(label+'.exit')).read_text().strip()=='0'
assert json.loads((o/'guards.json').read_text())==dict(count=2543,changed=[])
log=(o/'native.log').read_text();assert '1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in log
rows=[]
for line in log.splitlines():
 m=re.search(r'\b(N4_NEW_JACOBIAN_IC_[A-Z0-9_]+) (\{.*\})$',line)
 if m:rows.append(dict(kind=m[1],data=json.loads(m[2])))
assert len(rows)==82
assert {kind:sum(x['kind']==kind for x in rows)for kind in sorted({x['kind']for x in rows})}==dict(N4_NEW_JACOBIAN_IC_INPUT=3,N4_NEW_JACOBIAN_IC_ATTEMPT=60,N4_NEW_JACOBIAN_IC_CASE=15,N4_NEW_JACOBIAN_IC_TARGET=3,N4_NEW_JACOBIAN_IC_SCOPE=1)
assert rows[-1]['data']['attempts']==60 and rows[-1]['data']['all15_public_cases_solved']==15
for row in rows:
 if row['kind']=='N4_NEW_JACOBIAN_IC_ATTEMPT'and row['data']['report']['ok']:assert row['data']['actual_target_group_check']and row['data']['independent_original_source_check']
raw=json.dumps(rows,indent=2).encode()+b'\n';z=lzma.compress(raw);assert len(z)<65536
(o/'all-native-records.json').write_bytes(raw);(d/'all-native-records.json.xz').write_bytes(z)
for name in ['guards.json','plan.json','original-command.sh','prospective-protocol.md','rustc.txt']:shutil.copyfile(o/name,d/name)
(d/'observation.json').write_text(json.dumps(dict(protocol='98c6f0/2aee normalpush0 beforecode',native_tests='1passed/0failed/ignored/filtered',guards=2543,changed=[],complete_records=82,attempts=60,public_cases=15,actual_target_IC='all3Jacobians/all5publiccases each/all4FBsettings retained;all15 have >=1correctsolve',reported_success_checks='actualtargetJacobian[k]G=Q AND independentoriginalsource',runtime='publictargetclasses/curve/ell/parameters;no witness/DLPtable/sourceECDLPsolver',compatibility_control='same-origin/same-input bridge to original sourcebound affine legacy triples remainsopen',counter_scope='raw originalIC/wrappedPicard only;FpR/model/map/admission/independentcheck unpricedunknown,no S/ratio/benchmark',source_snapshot='byte-exact originalpublicsolver plus complete literal input/P0/descent/groupverify diff',scope='unsigned finitecorrectness,not full formalgeometry or computationaladvantage'),indent=2)+'\n')
shutil.copyfile(__file__,o/'acceptance-collector.py')
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Actual new-targetIC native01 under prospective98c6f0/2aee BEFOREcode:oneunfiltered comprehensive test0/zeroignoredfiltered/ALL2543selectedguards unchanged including702refinementinputs. ALL3 actualprimefieldJacobians x FIVEunchangedpublictargets x fixedFB30/36/48/64/ALL60attempts and failures retained,82completeJSON. Eachof15publiccases has >=1correct ICsolve;every reported success satisfies actualtargetJacobian[k]G=Q and independentoriginalsource verification/knownansweroutside runtime. Typed publicclass solver uses actualP0/fb0zeroanchor and originalrelation/largeprime/Lanczos/descent body;classR,rG+G,rG+Q and actualtargetverify replace sourceboundplumbing;byteexactoriginalsnapshot+literalderivative diff retained. No sourceECDLPfallback/witnessinput/DLPtable. Alltag/noncanonical/malformed/nonodd/zeroG/actualforeigntarget controls pass. Exact same-origin compatibility bridge remainsopen. OriginalIC+wrappedPicard rawcounter/timing diagnostics incomplete/FpR/maps/setup/admission/independentcheck unpricedunknown;no S/ratio or computationaladvantage. Written/faithfulLean/report/strictreplay/publication next;unsigned/geometrypartial.']
for p in sorted(d.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(r))]
print(subprocess.check_output(cmd,cwd=r,text=True).strip());print(json.dumps(dict(records=82,attempts=60,cases=15,guards=2543,xz_bytes=len(z))))
