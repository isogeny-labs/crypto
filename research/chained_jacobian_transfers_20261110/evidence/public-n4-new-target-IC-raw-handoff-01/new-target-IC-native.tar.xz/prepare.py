"""Input snapshots/native command custody;all science executes in Rust."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';n=s/'new-target-ic';o=Path('/workspace/scratch/ct68-new-target-IC-native-01');o.mkdir()
before=json.loads(Path('/workspace/scratch/ct66-odd-product-refinement-native-01/before.json').read_text());assert len(before)==2514
for line in(s/'ci_odd_refinement/reference-01.sha256').read_text().splitlines():
 h,p=line.split('  ',1);p=(r/p).resolve();assert hashlib.sha256(p.read_bytes()).hexdigest()==h;before[str(p)]=h
for p in [s/'ci_odd_refinement/reference-01.sha256',s/'NEW_TARGET_IC_PROTOCOL_01.md',*n.rglob('*')]:
 if p.is_file():before[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
for name in before:
 p=Path(name);dest=o/'source'/p.relative_to('/workspace');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
(o/'before.json').write_text(json.dumps(before,indent=2)+'\n');shutil.copyfile(__file__,o/'prepare.py');shutil.copyfile(s/'NEW_TARGET_IC_PROTOCOL_01.md',o/'prospective-protocol.md')
(o/'plan.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),published_prospective='98c6f0/2aee9ef5 normalpush0 BEFOREcode',source='published3baa metadata/fb9ee science+additive new-target-ic',guards=len(before),scope='one unfiltered comprehensive test:all3actualJacobians/all5unchangedpublictargets/all4fixedFB30/36/48/64/all60attempts retained;actualtarget+independentoriginalsourcechecks;typed class inputs/no sourceDLPfallback',compiler_timeout=900,native_timeout=900,native_address_space_KiB=2097152,cache='ct57 completed outside warm correctness cache;not cold',compatibility_control='originalrandomFBorigin/affinelegacytriple exactbridge notsupplied;keptopen',accounting='originalIC+wrappedPicard diagnosticcounters/rawtimings;FpR/maps/model/inputchecks/independentverify unpricedunknown;no S/ratio/benchmark'),indent=2)+'\n')
text=Path('/workspace/scratch/ct66-odd-product-refinement-native-01.sh').read_text().replace('ct66-odd-product-refinement-native-01','ct68-new-target-IC-native-01').replace('odd-product-refinements/Cargo.toml','new-target-ic/Cargo.toml')
launcher=Path(str(o)+'.sh');launcher.write_text(text);shutil.copyfile(launcher,o/'original-command.sh');print(str(launcher),len(before),flush=True)
