"""I/O custody only. Native tests and arithmetic live in Rust."""
from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib,shutil,subprocess,lzma,os
phase=sys.argv[1];assert phase in ['static','unit'];attempt=sys.argv[2] if len(sys.argv)>2 else '01';assert attempt.isdecimal();r=Path('/workspace/crypto');s=r/'research/chained_jacobian_transfers_20261110';o=Path('/workspace/scratch')/('ct55-g3-'+phase+'-'+attempt);o.mkdir()
baseline=json.loads(lzma.decompress((s/'evidence/genus3-primary-01/previous-full-current-inputs.json.xz').read_bytes()));assert len(baseline)==794
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in baseline.items())
inputs=[p for p in (r/'isogeny_algos').rglob('*') if p.is_file() and ('/src/' in str(p) or p.name in ['Cargo.toml','Cargo.lock']) and '/target/' not in str(p)]
inputs += [p for p in (s/'genus3-prime-descent').rglob('*') if p.is_file() and '/target/' not in str(p)]
inputs += [r/'src/cryptanalysis/diem_quartic.rs',r/'src/cryptanalysis/plane_quartic_pic.rs',r/'src/hash/sha256.rs',s/'G3_DESCENT_PROTOCOL.md',s/'G3_DESCENT_DERIVATION.md',s/'evidence/genus3-primary-01/cases.json']
inputs=sorted(set(inputs));before=dict(baseline)
for p in inputs:
    before[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest();dest=o/'source/crypto'/p.relative_to(r);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
shutil.copytree('/workspace/scratch/ct55-g3-interface-custody-01',o/'interface-custody')
(o/'before.json').write_text(json.dumps(before,indent=2)+'\n')
command=['cargo','clippy','--all-targets','--offline','--locked','--manifest-path','research/chained_jacobian_transfers_20261110/genus3-prime-descent/Cargo.toml','--','-D','warnings'] if phase=='static' else ['cargo','test','--release','--offline','--locked','--manifest-path','research/chained_jacobian_transfers_20261110/genus3-prime-descent/Cargo.toml','--lib','--','--nocapture','--test-threads=1']
(o/'plan.json').write_text(json.dumps(dict(protocol='394e14 published de0b472 BEFORE implementation',phase=phase,command=command,timeout_s=900,old794_inputs_unchanged_before=True,guard_count=len(before),compiled_source_files=len(inputs),native_cache=str(o)+'-build-cache',cache_outside_raw=True,prediction='static strict warnings0' if phase=='static' else 'all4 substantive tests pass with complete fixed-panel scopes,no ignored/filtered tests',falsification='any original nonzero native exit or changed guard;preserve and diagnose;no relaxation',scope='local correctness build/test only,no benchmark/timing ratio/IC/paid experiment'),indent=2)+'\n')
with (r/'docs/session-logs/2026-11-13.md').open('a') as f:f.write(f'''\n## {datetime.now(timezone.utc).isoformat()} — G3 native {phase} attempt prepared (Codex)\n\n### What was done (commands, files, features)\n+- Protocol394e14 was committed/published de0b472 before code. New native adapter,strict encoded API/CLI and four point-jet/group/control tests implemented. Exact interface removal recovers both prior Diem/Picard files byte for byte;no old arithmetic body change. Prepared {o},source snapshots and{len(before)} guards including all794 prior inputs unchanged before launch. No native acceptance yet. [pcc:unverified]\n\n### Decisions made (and why)\n+- Execute the frozen local correctness {phase} command under900seconds with fresh cache outside raw;retain original stdout/stderr/exit/finalguards. No benchmark or paid experiment launch.\n\n### Open threads (unfinished, pick up next time)\n+- Original native terminal+guard,then diagnose or archive/claim/report/commit;complete independent full-point/group controls and central Lean proof work. No reduced acceptance scope.\n\n### Errors (what went wrong, how it was handled)\n+- Conductor scope-expansion command actually127(command absent),recorded before interface edits. Source freeze starts at preparation;do not edit any selected runtime input until original terminal+guard. No native result yet.\n''')
script='''#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=OUT-build-cache
cd /workspace/crypto
out=OUT
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
rustc -Vv > "$out/rustc.txt" 2>&1
cargo -V > "$out/cargo.txt" 2>&1
uname -a > "$out/host.txt" 2>&1
set +e
timeout 900 COMMAND > "$out/native.log" 2>&1
status=$?
printf '%s\\n' "$status" > "$out/native.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'CHECK_GUARDS'
from pathlib import Path
import hashlib,json,sys
o=Path(sys.argv[1]);before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before};changed=[p for p in before if before[p]!=after[p]]
(o/'after.json').write_text(json.dumps(after,indent=2)+'\\n');(o/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\\n');raise SystemExit(bool(changed))
CHECK_GUARDS
guard=$?
printf '%s\\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
'''.replace('OUT',str(o)).replace('COMMAND',' '.join(command))
path=Path(str(o)+'.sh');path.write_text(script);shutil.copyfile(path,o/'original-command.sh');print(str(path),len(before),flush=True)
