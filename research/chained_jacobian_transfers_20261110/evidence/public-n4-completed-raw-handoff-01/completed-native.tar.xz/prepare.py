"""Exact byte custody and original Rust process launcher, no Python crypto."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';n=s/'completed-descent'
out=Path('/workspace/scratch/ct58-completed-descent-unit-01');out.mkdir()
pins=json.loads((n/'derived/source-pins.json').read_text());raw=(r/pins['original_path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==pins['original_sha256'];t=raw.decode()
for a,b in pins['literal_substitutions']:assert t.count(a)==1;t=t.replace(a,b)
assert t==(n/'derived/completed_solver.rs').read_text() and hashlib.sha256(t.encode()).hexdigest()==pins['candidate_sha256']
receipt=json.loads(Path('/workspace/scratch/ct58-V2-source-publication-01/receipt.json').read_text());assert receipt['original_exit']==0 and receipt['head']=='093134ba9fbdaa4fdb50fe4bc53cd29d809500d0'
before=json.loads(Path('/workspace/crypto/research/chained_jacobian_transfers_20261110/evidence/public-n4-pcc-data-current-guard-02/current-inputs.json').read_text());assert len(before)==2191
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
for line in (s/'ci_v2/reference-01.sha256').read_text().splitlines():
    h,p=line.split('  ',1);p=(r/p).resolve();assert hashlib.sha256(p.read_bytes()).hexdigest()==h;before[str(p)]=h
p=s/'ci_v2/reference-01.sha256';before[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
for p in n.rglob('*'):
    if p.is_file():before[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
for name,h in before.items():
    p=Path(name);assert hashlib.sha256(p.read_bytes()).hexdigest()==h
    dest=out/'source'/p.relative_to('/workspace');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
(out/'before.json').write_text(json.dumps(before,indent=2)+'\n');shutil.copyfile(__file__,out/'prepare.py')
plan=dict(at=datetime.now(timezone.utc).isoformat(),protocol='74e00a actualnormallypublished093 BEFOREcode/7823d2',source='093 parent +ONLYcompleted-descent additivecrate',baseline='native/derived/public_solver.rs unchanged',original_solver_literal_substitutions=6,source_guard_count=len(before),question='does completed triple admission retain ALLFIVEpublicICsolves underoriginal6retrycap?',controls='actualsamewinningP0/nonzeroorigin/32complete16splitmatches/fivepointnormhalfinverses/fiveaffinecancellations/nonzerobase;ALLpairedattempts andanswersoriginalindependentsourcechecked',tests='ONEunfiltered serial test/zeroignoredfiltered;all5required',compiler_timeout_s=900,native_timeout_s=900,native_address_limit_KiB=2097152,cache='/workspace/scratch/ct57-n4-unit-01-build-cache',cache_scope='reused completed outside correctnesscache;notcold',counter_coverage_gap='separate completedcover arithmetic absent from originalN4countertotal;no S/ratio/advantage calculated',failure='whole closedsource/output/eachretry/status/guards;preservewronganswers/exhaustion/no genericDLPfallback',scope='bounded implementation correctness;not admitted performance experiment')
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');d=s/'evidence/completed-descent-native-plan-01';d.mkdir();shutil.copyfile(out/'plan.json',d/'plan.json')
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Freeze completed-descent native01 BEFOREoriginalprocess:activeprotocol74e00a ACTUALpublished093/7823d2 BEFOREcode. Wholepublicsolver derivativeONLY6literal substitutions/argument+adapter+threecompleteGen/reduction/stats;allotherrelationLA/descentwalk/recovery/rhobytes unchanged. '+str(len(before))+'actualsourcescopied/guarded;oneunfilteredserialtest/all5pairedpublictargets/original6retrycap/actualP0nonzeroorigin16split32complete/fivepointinverse+affinecontrols. 900scompiler+900s2GiBnative/reusedoutsidecache;originalcounters omit completedcover arithmetic/no costratio. Wholeallfailures/answers/guards required;not yet candidateacceptance.','--proof','attestation:'+str((d/'plan.json').relative_to(r))]
print(subprocess.check_output(cmd,cwd=r,text=True).strip(),len(before),flush=True)
script='''#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct57-n4-unit-01-build-cache
cd /workspace/cryptanalysis
out=/workspace/scratch/ct58-completed-descent-unit-01
manifest=experiments/chained-transfer-public-target/completed-descent/Cargo.toml
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
rustc -Vv > "$out/rustc.txt" 2>&1
timeout 900 cargo test --release --offline --locked --manifest-path "$manifest" --lib --no-run > "$out/compile.log" 2>&1
build=$?
printf '%s\\n' "$build" > "$out/compile.exit"
if [ "$build" -eq 0 ]; then
  (ulimit -v 2097152; timeout 900 cargo test --release --offline --locked --manifest-path "$manifest" --lib -- --nocapture --test-threads=1) > "$out/native.log" 2>&1
  status=$?
else
  status=$build
  cp "$out/compile.log" "$out/native.log"
fi
printf '%s\\n' "$status" > "$out/native.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARD'
from pathlib import Path
import hashlib,json,sys
o=Path(sys.argv[1]);before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before};changed=[p for p in before if before[p]!=after[p]]
(o/'after.json').write_text(json.dumps(after,indent=2)+'\\n');(o/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\\n');raise SystemExit(bool(changed))
GUARD
guard=$?
printf '%s\\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
'''
launcher=Path(str(out)+'.sh');launcher.write_text(script);shutil.copyfile(launcher,out/'original-command.sh');print(str(launcher),flush=True)
