//! Boolean tensor multigraphs, exact pins, and parsimonious-program metadata.

use crate::canonical::PredicateProgram;
use crate::{integrity, invalid, BigUint, Meter, Result};
use num_traits::{One, Zero};
use std::collections::BTreeSet;
use std::sync::Arc;

/// Stable semantic label carried by a predicate into the canonical network IR.
///
/// Parameters are sorted by key when constructed. The canonical exporter also
/// records the predicate's complete bounded truth table, so this label supplies
/// provenance and human meaning without being trusted as the evaluator.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PredicateTag {
    /// Namespaced predicate family, for example `encoder.constraint`.
    pub kind: String,
    /// Sorted semantic or shape parameters.
    pub parameters: Vec<(String, String)>,
}
impl PredicateTag {
    /// Construct a tag and sort its parameters into canonical key/value order.
    /// Empty or duplicate keys are rejected when a canonical IR is captured.
    pub fn new(kind: impl Into<String>, mut parameters: Vec<(String, String)>) -> Self {
        parameters.sort();
        Self {
            kind: kind.into(),
            parameters,
        }
    }
}

/// One tensor predicate, with a fixed and explicitly ordered port list.
pub trait Predicate: Send + Sync {
    /// Number of incident bit ports, counting parallel edges separately.
    fn arity(&self) -> usize;
    /// Evaluate the Boolean predicate exactly.
    fn evaluate(&self, ports: &[bool], meter: &mut Meter) -> Result<bool>;
    /// Optional semantic tag for strict production canonicalization.
    fn canonical_tag(&self) -> Option<&PredicateTag> {
        None
    }
    /// Optional typed evaluator for predicates above the exact truth-table cap.
    fn canonical_program(&self) -> Option<&PredicateProgram> {
        None
    }
}

/// A native predicate closure with explicit arity.
pub struct FnPredicate {
    arity: usize,
    tag: Option<PredicateTag>,
    program: Option<PredicateProgram>,
    function: Option<Arc<dyn Fn(&[bool], &mut Meter) -> Result<bool> + Send + Sync>>,
}
impl FnPredicate {
    /// Construct a predicate. Contraction complexity assumptions on user-supplied
    /// predicate evaluation remain the caller's responsibility.
    pub fn new(
        arity: usize,
        function: impl Fn(&[bool], &mut Meter) -> Result<bool> + Send + Sync + 'static,
    ) -> Self {
        Self {
            arity,
            tag: None,
            program: None,
            function: Some(Arc::new(function)),
        }
    }
    /// Construct a predicate with a stable semantic tag for canonical export.
    pub fn tagged(
        arity: usize,
        tag: PredicateTag,
        function: impl Fn(&[bool], &mut Meter) -> Result<bool> + Send + Sync + 'static,
    ) -> Self {
        Self {
            arity,
            tag: Some(tag),
            program: None,
            function: Some(Arc::new(function)),
        }
    }
    /// Construct a predicate whose live evaluator is a serializable typed
    /// program. The same program is used after canonical import.
    pub fn programmed(arity: usize, tag: PredicateTag, program: PredicateProgram) -> Self {
        Self {
            arity,
            tag: Some(tag),
            program: Some(program),
            function: None,
        }
    }
}
impl Predicate for FnPredicate {
    fn arity(&self) -> usize {
        self.arity
    }
    fn evaluate(&self, ports: &[bool], meter: &mut Meter) -> Result<bool> {
        if ports.len() != self.arity {
            return Err(invalid("predicate port arity"));
        }
        if let Some(program) = &self.program {
            return program.evaluate(ports, meter);
        }
        self.function
            .as_ref()
            .ok_or_else(|| integrity("predicate has no evaluator"))?(ports, meter)
    }
    fn canonical_tag(&self) -> Option<&PredicateTag> {
        self.tag.as_ref()
    }
    fn canonical_program(&self) -> Option<&PredicateProgram> {
        self.program.as_ref()
    }
}

#[derive(Clone)]
pub(crate) struct Vertex {
    pub predicate: Arc<dyn Predicate>,
    pub edges: Vec<usize>,
}

/// Validated finite undirected multigraph without self-loops. Each edge occurs
/// once at each endpoint; parallel edges retain distinct ordered ports.
#[derive(Clone)]
pub struct Network {
    pub(crate) vertices: Vec<Vertex>,
    pub(crate) edges: Vec<(usize, usize)>,
    pub(crate) interface: Vec<usize>,
    pub(crate) model: Option<Arc<Program>>,
}
impl Network {
    /// Number of bit edges.
    pub fn edge_count(&self) -> usize {
        self.edges.len()
    }
    /// Number of vertices, including isolated scalar predicates.
    pub fn vertex_count(&self) -> usize {
        self.vertices.len()
    }
    /// Maximum degree, counting multiplicities.
    pub fn maximum_degree(&self) -> usize {
        self.vertices
            .iter()
            .map(|v| v.edges.len())
            .max()
            .unwrap_or(0)
    }
    /// Explicit interface edges in language-word order.
    pub fn interface(&self) -> &[usize] {
        &self.interface
    }
    /// Evaluate a full edge assignment, independently of program hints.
    pub fn evaluate(&self, assignment: &[bool], meter: &mut Meter) -> Result<bool> {
        if assignment.len() != self.edges.len() {
            return Err(invalid("edge assignment width"));
        }
        for vertex in &self.vertices {
            meter.charge(1, "Boolean vertex evaluation")?;
            let ports: Vec<_> = vertex.edges.iter().map(|&e| assignment[e]).collect();
            if !vertex.predicate.evaluate(&ports, meter)? {
                return Ok(false);
            }
        }
        Ok(true)
    }
    /// Validate a pin vector; each edge is fixed once or remains free.
    pub fn check_pins(&self, pins: &[Option<bool>]) -> Result<()> {
        if pins.len() != self.edge_count() {
            return Err(invalid("pin vector width"));
        }
        Ok(())
    }
    /// Number of free input bits in a built-in parsimonious encoding.
    pub fn input_bit_count(&self) -> Option<usize> {
        self.model.as_ref().map(|p| p.free.len())
    }
    /// Construct and independently check the full witness determined by free
    /// inputs. Arbitrary predicate graphs do not have this optional metadata.
    pub fn witness_from_input_bits(
        &self,
        bits: &[bool],
        meter: &mut Meter,
    ) -> Result<Option<Vec<bool>>> {
        let Some(program) = &self.model else {
            return Err(invalid("network has no built-in program witness"));
        };
        program.materialize(bits, &vec![None; program.signals], self, meter)
    }
}

/// A graph builder for arbitrary native predicates. It adds no program hints.
#[derive(Default)]
pub struct GraphBuilder {
    vertices: Vec<Vertex>,
    edges: Vec<(usize, usize)>,
}
impl GraphBuilder {
    /// Start an empty graph.
    pub fn new() -> Self {
        Self::default()
    }
    /// Add a predicate; all its ports must subsequently be attached.
    pub fn vertex(&mut self, predicate: impl Predicate + 'static) -> usize {
        self.vertex_arc(Arc::new(predicate))
    }
    pub(crate) fn vertex_arc(&mut self, predicate: Arc<dyn Predicate>) -> usize {
        let index = self.vertices.len();
        self.vertices.push(Vertex {
            predicate,
            edges: Vec::new(),
        });
        index
    }
    /// Attach a distinct edge to the next port of each endpoint.
    pub fn edge(&mut self, left: usize, right: usize, meter: &mut Meter) -> Result<usize> {
        if left == right || left >= self.vertices.len() || right >= self.vertices.len() {
            return Err(invalid("edge endpoints or self-loop"));
        }
        meter.vector(self.edges.len() + 1, "Boolean graph edges")?;
        let edge = self.edges.len();
        self.edges.push((left, right));
        self.vertices[left].edges.push(edge);
        self.vertices[right].edges.push(edge);
        Ok(edge)
    }
    /// Freeze the graph after checking all arities and distinct interface edges.
    pub fn finish(self, interface: Vec<usize>) -> Result<Network> {
        if self
            .vertices
            .iter()
            .any(|v| v.edges.len() != v.predicate.arity())
        {
            return Err(invalid("unattached predicate ports"));
        }
        let mut seen = BTreeSet::new();
        if interface
            .iter()
            .any(|&e| e >= self.edges.len() || !seen.insert(e))
        {
            return Err(invalid("interface must contain distinct graph edges"));
        }
        Ok(Network {
            vertices: self.vertices,
            edges: self.edges,
            interface,
            model: None,
        })
    }
}

#[derive(Clone, Copy, Debug)]
pub(crate) enum Bit {
    Constant(bool),
    Signal(usize),
}
impl Bit {
    pub(crate) fn read(self, values: &[bool]) -> bool {
        match self {
            Self::Constant(b) => b,
            Self::Signal(i) => values[i],
        }
    }
}

/// A little-endian word in an encoding builder. Constants need no graph edges.
#[derive(Clone, Debug)]
pub struct Word(pub(crate) Vec<Bit>);
impl Word {
    /// Number of bits, including hardcoded constants.
    pub fn width(&self) -> usize {
        self.0.len()
    }
    pub(crate) fn value(&self, values: &[bool]) -> BigUint {
        let mut out = BigUint::zero();
        for (i, &bit) in self.0.iter().enumerate() {
            if bit.read(values) {
                out.set_bit(i as u64, true);
            }
        }
        out
    }
}

pub(crate) type ValueFunction =
    Arc<dyn Fn(&[BigUint], &mut Meter) -> Result<Vec<BigUint>> + Send + Sync>;

#[derive(Clone)]
pub(crate) enum Step {
    Define {
        inputs: Vec<Word>,
        outputs: Vec<Word>,
        function: ValueFunction,
    },
    Check {
        vertex: usize,
        ports: Vec<Bit>,
    },
}

// Only the built-in, parsimonious arithmetic encoders construct this metadata.
// Arbitrary caller predicates cannot attach hints or assert their uniqueness.
#[derive(Clone)]
pub(crate) struct Program {
    pub free: Vec<usize>,
    pub signals: usize,
    pub steps: Vec<Step>,
    pub edge_signals: Vec<usize>,
    pub signal_regions: Vec<Option<String>>,
}

/// Conservative dependence on enumeration digits (digit zero changes fastest).
/// A failed step with cutoff k is independent of every digit below k.
pub(crate) struct PruningPlan {
    step_cutoffs: Vec<usize>,
}

pub(crate) enum Evaluation {
    Accepted(Vec<bool>),
    Rejected(usize),
}

impl Program {
    pub(crate) fn evaluate_selected(
        &self,
        free_values: &[bool],
        selected_signals: &[bool],
        selected_vertices: &[bool],
        network: &Network,
        meter: &mut Meter,
    ) -> Result<Option<Vec<bool>>> {
        if free_values.len() != self.free.len()
            || selected_signals.len() != self.signals
            || selected_vertices.len() != network.vertices.len()
        {
            return Err(invalid("selected program shape"));
        }
        meter.vector(self.signals, "selected program signal assignment")?;
        let mut values = vec![false; self.signals];
        let mut assigned = vec![false; self.signals];
        for (&signal, &value) in self.free.iter().zip(free_values) {
            if selected_signals[signal] {
                values[signal] = value;
                assigned[signal] = true;
            }
        }
        for step in &self.steps {
            match step {
                Step::Define {
                    inputs,
                    outputs,
                    function,
                } => {
                    let output_signals = outputs
                        .iter()
                        .flat_map(|word| &word.0)
                        .map(|bit| match bit {
                            Bit::Signal(signal) => Ok(*signal),
                            Bit::Constant(_) => {
                                Err(integrity("selected program output is not a fresh signal"))
                            }
                        })
                        .collect::<Result<Vec<_>>>()?;
                    let selected = output_signals
                        .first()
                        .is_some_and(|&signal| selected_signals[signal]);
                    if output_signals
                        .iter()
                        .any(|&signal| selected_signals[signal] != selected)
                    {
                        return Err(integrity("mixed selected program output region"));
                    }
                    if !selected {
                        continue;
                    }
                    for bit in inputs.iter().flat_map(|word| &word.0) {
                        if let Bit::Signal(signal) = bit {
                            if !assigned[*signal] {
                                return Err(integrity(
                                    "selected program depends on an unselected signal",
                                ));
                            }
                        }
                    }
                    meter.charge(1, "selected parsimonious program evaluation")?;
                    let input = inputs
                        .iter()
                        .map(|word| word.value(&values))
                        .collect::<Vec<_>>();
                    let output = function(&input, meter)?;
                    if output.len() != outputs.len() {
                        return Err(integrity("selected program result arity"));
                    }
                    for (word, value) in outputs.iter().zip(output) {
                        if value.bits() > word.width() as u64 {
                            return Ok(None);
                        }
                        for (i, &bit) in word.0.iter().enumerate() {
                            let Bit::Signal(signal) = bit else {
                                return Err(integrity(
                                    "selected program output is not a fresh signal",
                                ));
                            };
                            values[signal] = value.bit(i as u64);
                            assigned[signal] = true;
                        }
                    }
                }
                Step::Check { vertex, ports } => {
                    if !selected_vertices[*vertex] {
                        continue;
                    }
                    if ports
                        .iter()
                        .any(|bit| matches!(bit, Bit::Signal(signal) if !assigned[*signal]))
                    {
                        return Err(integrity(
                            "selected predicate depends on an unselected signal",
                        ));
                    }
                    meter.charge(1, "selected parsimonious predicate evaluation")?;
                    let bits = ports
                        .iter()
                        .map(|&bit| bit.read(&values))
                        .collect::<Vec<_>>();
                    if !network.vertices[*vertex].predicate.evaluate(&bits, meter)? {
                        return Ok(None);
                    }
                }
            }
        }
        for (vertex_id, vertex) in network.vertices.iter().enumerate() {
            if !selected_vertices[vertex_id] {
                continue;
            }
            let mut ports = Vec::with_capacity(vertex.edges.len());
            for &edge in &vertex.edges {
                let signal = self.edge_signals[edge];
                if !assigned[signal] {
                    return Err(integrity(
                        "selected graph vertex depends on an unselected signal",
                    ));
                }
                ports.push(values[signal]);
            }
            meter.charge(1, "selected graph verification")?;
            if !vertex.predicate.evaluate(&ports, meter)? {
                return Ok(None);
            }
        }
        Ok(Some(values))
    }

    pub(crate) fn pruning_plan(
        &self,
        order: &[usize],
        signal_pins: &[Option<bool>],
        meter: &mut Meter,
    ) -> Result<PruningPlan> {
        if signal_pins.len() != self.signals {
            return Err(invalid("dependency pin shape"));
        }
        meter.vector(self.signals, "program dependency ranks")?;
        meter.vector(self.steps.len(), "program dependency steps")?;
        let constant = order.len();
        let mut ranks = vec![constant; self.signals];
        let mut seen = BTreeSet::new();
        for (rank, &position) in order.iter().enumerate() {
            meter.charge(1, "program input dependency")?;
            let signal = *self
                .free
                .get(position)
                .ok_or_else(|| invalid("dependency input position"))?;
            if signal_pins[signal].is_some() || !seen.insert(position) {
                return Err(invalid("dependency input order"));
            }
            ranks[signal] = rank;
        }
        for (position, &signal) in self.free.iter().enumerate() {
            meter.charge(1, "program dependency coverage")?;
            if signal_pins[signal].is_none() && !seen.contains(&position) {
                return Err(invalid("missing dependency input"));
            }
        }
        let mut step_cutoffs = Vec::with_capacity(self.steps.len());
        for step in &self.steps {
            meter.charge(1, "program dependency step")?;
            let mut cutoff = constant;
            match step {
                Step::Define {
                    inputs, outputs, ..
                } => {
                    for &bit in inputs.iter().flat_map(|word| &word.0) {
                        meter.charge(1, "program dependency input bit")?;
                        if let Bit::Signal(signal) = bit {
                            cutoff = cutoff.min(ranks[signal]);
                        }
                    }
                    for &bit in outputs.iter().flat_map(|word| &word.0) {
                        meter.charge(1, "program dependency output bit")?;
                        let Bit::Signal(signal) = bit else {
                            return Err(integrity("dependency output is not a signal"));
                        };
                        // Even a pinned derived output depends on its inputs:
                        // the computed value must still agree with that pin.
                        ranks[signal] = cutoff;
                    }
                }
                Step::Check { ports, .. } => {
                    for &bit in ports {
                        meter.charge(1, "program dependency check bit")?;
                        if let Bit::Signal(signal) = bit {
                            cutoff = cutoff.min(ranks[signal]);
                        }
                    }
                }
            }
            step_cutoffs.push(cutoff);
        }
        Ok(PruningPlan { step_cutoffs })
    }

    pub(crate) fn signal_pins(&self, pins: &[Option<bool>]) -> Result<Option<Vec<Option<bool>>>> {
        if pins.len() != self.edge_signals.len() {
            return Err(invalid("program pin shape"));
        }
        let mut out = vec![None; self.signals];
        for (edge, &pin) in pins.iter().enumerate() {
            if let Some(bit) = pin {
                let signal = self.edge_signals[edge];
                if let Some(old) = out[signal] {
                    if old != bit {
                        return Ok(None);
                    }
                }
                out[signal] = Some(bit);
            }
        }
        Ok(Some(out))
    }

    pub(crate) fn materialize(
        &self,
        free_values: &[bool],
        signal_pins: &[Option<bool>],
        network: &Network,
        meter: &mut Meter,
    ) -> Result<Option<Vec<bool>>> {
        match self.evaluate(free_values, signal_pins, network, None, meter)? {
            Evaluation::Accepted(assignment) => Ok(Some(assignment)),
            Evaluation::Rejected(_) => Ok(None),
        }
    }

    pub(crate) fn evaluate(
        &self,
        free_values: &[bool],
        signal_pins: &[Option<bool>],
        network: &Network,
        plan: Option<&PruningPlan>,
        meter: &mut Meter,
    ) -> Result<Evaluation> {
        if free_values.len() != self.free.len() || signal_pins.len() != self.signals {
            return Err(invalid("program input shape"));
        }
        meter.vector(self.signals, "program signal assignment")?;
        let mut values = vec![false; self.signals];
        for (&signal, &value) in self.free.iter().zip(free_values) {
            if signal_pins[signal].is_some_and(|p| p != value) {
                return Ok(Evaluation::Rejected(0));
            }
            values[signal] = value;
        }
        for (index, step) in self.steps.iter().enumerate() {
            meter.charge(1, "parsimonious program evaluation")?;
            let cutoff = plan.map_or(0, |p| p.step_cutoffs[index]);
            match step {
                Step::Define {
                    inputs,
                    outputs,
                    function,
                } => {
                    let input: Vec<_> = inputs.iter().map(|word| word.value(&values)).collect();
                    let output = function(&input, meter)?;
                    if output.len() != outputs.len() {
                        return Err(integrity("program result arity"));
                    }
                    for (word, value) in outputs.iter().zip(output) {
                        if value.bits() > word.width() as u64 {
                            return Ok(Evaluation::Rejected(cutoff));
                        }
                        for (i, &bit) in word.0.iter().enumerate() {
                            let Bit::Signal(signal) = bit else {
                                return Err(integrity("program output is not a fresh signal"));
                            };
                            let value = value.bit(i as u64);
                            if signal_pins[signal].is_some_and(|p| p != value) {
                                return Ok(Evaluation::Rejected(cutoff));
                            }
                            values[signal] = value;
                        }
                    }
                }
                Step::Check { vertex, ports } => {
                    let bits: Vec<_> = ports.iter().map(|&bit| bit.read(&values)).collect();
                    if !network.vertices[*vertex].predicate.evaluate(&bits, meter)? {
                        return Ok(Evaluation::Rejected(cutoff));
                    }
                }
            }
        }
        let assignment: Vec<_> = self
            .edge_signals
            .iter()
            .map(|&signal| values[signal])
            .collect();
        if !network.evaluate(&assignment, meter)? {
            return Err(integrity("program witness disagrees with graph"));
        }
        Ok(Evaluation::Accepted(assignment))
    }
}

/// Increment little-endian Boolean digits; return false after the last word.
pub(crate) fn increment(bits: &mut [bool]) -> bool {
    for bit in bits {
        if !*bit {
            *bit = true;
            return true;
        }
        *bit = false;
    }
    false
}

/// Independent exact reference contraction over all unpinned edge bits.
pub fn direct_count(
    network: &Network,
    pins: &[Option<bool>],
    meter: &mut Meter,
) -> Result<BigUint> {
    network.check_pins(pins)?;
    let free: Vec<_> = pins
        .iter()
        .enumerate()
        .filter_map(|(e, p)| p.is_none().then_some(e))
        .collect();
    let mut digits = vec![false; free.len()];
    let mut answer = BigUint::zero();
    loop {
        meter.charge(1, "direct Boolean edge assignment")?;
        let mut assignment: Vec<_> = pins.iter().map(|p| p.unwrap_or(false)).collect();
        for (&edge, &bit) in free.iter().zip(&digits) {
            assignment[edge] = bit;
        }
        if network.evaluate(&assignment, meter)? {
            answer += BigUint::one();
        }
        if !increment(&mut digits) {
            break;
        }
    }
    Ok(answer)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::Limits;
    #[test]
    fn parallel_edges_pins_and_isolated_scalars() {
        let mut meter = Meter::new(Limits::default());
        let mut b = GraphBuilder::new();
        let left = b.vertex(FnPredicate::new(2, |bits, _| Ok(bits[0] == bits[1])));
        let right = b.vertex(FnPredicate::new(2, |_, _| Ok(true)));
        b.vertex(FnPredicate::new(0, |_, _| Ok(true)));
        let e0 = b.edge(left, right, &mut meter).unwrap();
        let e1 = b.edge(left, right, &mut meter).unwrap();
        let graph = b.finish(vec![e0, e1]).unwrap();
        assert_eq!(
            direct_count(&graph, &[None, None], &mut meter).unwrap(),
            BigUint::from(2u8)
        );
        assert_eq!(
            direct_count(&graph, &[Some(false), None], &mut meter).unwrap(),
            BigUint::one()
        );
        assert_eq!(
            direct_count(&graph, &[Some(false), Some(true)], &mut meter).unwrap(),
            BigUint::zero()
        );
        let mut b = GraphBuilder::new();
        b.vertex(FnPredicate::new(0, |_, _| Ok(false)));
        assert_eq!(
            direct_count(&b.finish(vec![]).unwrap(), &[], &mut meter).unwrap(),
            BigUint::zero()
        );
    }
    #[test]
    fn incomplete_graphs_and_duplicate_interfaces_are_rejected() {
        let mut b = GraphBuilder::new();
        b.vertex(FnPredicate::new(1, |_, _| Ok(true)));
        assert!(b.finish(vec![]).is_err());
    }
}
