"""Whole-file custody, command-exit inventory and original PCC record creation."""
from pathlib import Path
import hashlib,json,lzma,shutil,subprocess
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target'
def claim(e,statement):
 cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement',statement]
 for f in sorted(e.rglob('*')):
  if f.is_file():cmd+=['--proof','attestation:'+str(f.relative_to(r))]
 out=subprocess.check_output(cmd,cwd=r,text=True).strip();print(out,flush=True);return out
o=Path('/workspace/scratch/ct73-beta-full-01');d=o/'driver';e=s/'evidence/beta-rational-lift-fresh-full-01';e.mkdir()
assert(o/'native.exit').read_text().strip()=='0'and(o/'guard.exit').read_text().strip()=='0'
guards=json.loads((o/'guards.json').read_text());assert guards==dict(count=845,changed=[])
phases=[x.split()for x in(d/'phases.txt').read_text().splitlines()];assert len(phases)==17
for name,expected,actual in phases:
 assert expected==actual and expected==('101'if name=='identity-negative'else'0')
 assert(d/(name+'.pipe-exits')).read_text()==expected+' 0\n'
for name in ['original','phase-caller','final-source-guards']:assert(d/(name+'.exit')).read_text().strip()=='0'
for side in ['consumer','producer']:
 raw=(d/(side+'-proof.txt')).read_text();assert '20 thm   0 trusted'in raw and'1 thm   0 trusted'in raw
assert 'test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;'in(d/'native.txt').read_text()
assert sum(name.startswith('binding-')for name,_,_in phases)==6
cache=o/'driver-build-cache';exe=[p for p in(cache/'release/deps').glob('chained_n4_beta_rational_lift-*')if p.is_file()and p.suffix==''];assert len(exe)==1
for p,n in[(exe[0],'actual-test-executable.bin'),(cache/'release/compare_native','actual-compare-executable.bin'),(cache/'release/quadratic_identity','actual-identity-executable.bin')]:shutil.copyfile(p,o/n)
for name in ['plan.json','fixture-materialization.json','original-fixture-verify.exit','native.exit','guard.exit','guards.json','original-command.sh','start.txt','finish.txt']:shutil.copyfile(o/name,e/name)
for name in ['phases.txt','consumer-proof.txt','producer-proof.txt','compare.txt','identity-negative.txt']:
 shutil.copyfile(d/name,e/name)
for name in ['native.txt','before.json','after.json']:(e/(name+'.xz')).write_bytes(lzma.compress((o/name).read_bytes()))
files=[dict(path=p.relative_to(o).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in sorted(o.rglob('*'))if p.is_file()]
(e/'whole-capture-index.json').write_text(json.dumps(dict(root=str(o),members=files,all_files_no_filter=True,whole_archive_pending='NEWguard12 unchanged genuine publisher'),indent=2)+'\n')
full=claim(e,'Fresh physical published-c77f95dc beta replay: original producer3d49,844selected+self845guards unchanged, outer native0/guard0, all17ordered phases16expected0 plus actual identity-negative101/alltee0, TWO unfiltered passes/allTHREEwholeJSONexact NO masks, originalIDC0/0/101, both unchanged original proof gates20+1 declarations0trusted, six exact original bindings pass, final guards0. Full raw/source/binaries/whole index retained pending guard12. Unsigned data, not signed execution/corpus standing or performance.')
Path('/workspace/scratch/ct73-beta-full-acceptance.claim').write_text(full+'\n')
o=Path('/workspace/scratch/ct73-beta-complete-native-01');e=s/'evidence/beta-complete-fibres-native-01';e.mkdir()
assert(o/'compile.exit').read_text().strip()=='0'and(o/'native.exit').read_text().strip()=='0'and(o/'guard.exit').read_text().strip()=='0'
assert json.loads((o/'guards.json').read_text())==dict(count=845,changed=[])
assert 'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;'in(o/'native.txt').read_text()
shutil.copytree(o/'executed-source',e/'executed-source')
for name in ['plan.json','lock.txt','lock.exit','compile.txt','compile.exit','native.txt','native.exit','guard.exit','guards.json','run-native.sh','start.txt','finish.txt']:shutil.copyfile(o/name,e/name)
for name in ['before.json','after.json']:(e/(name+'.xz')).write_bytes(lzma.compress((o/name).read_bytes()))
(e/'custody.json').write_text(json.dumps(dict(root=str(o),binary=dict(path=str(o/'actual-test-executable.bin'),bytes=(o/'actual-test-executable.bin').stat().st_size,sha256=hashlib.sha256((o/'actual-test-executable.bin').read_bytes()).hexdigest()),complete_source='executed-source',whole_captures_preserved=True,scope='native finite observations, not signed execution/global coordinates/performance'),indent=2)+'\n')
fibres=claim(e,'StageC first complete quadratic fibre native: compiled0/ONEunfiltered1pass0fail0ignored0filtered/native0/845originalguards0. Both actual source curves all16E4(L),all256orderedadditionpairs each,F3-equivariance,originalKagreement,actualcompleteorigins,allthreeF2conjugateideals/coefficienttrace1,w2,w4 over Fp2; newmodel all16bothkappabranches agree. Each yields8distinctimages/4rational; sourcecofactor equals immutable original four-element golden; all8fibres each2lifts give identical matchedgamma/deltaimages/rational outputs. Three invalidcoordinate/offcurve controls reject. Full source/raw/binary preserved. Native finite unsigned observations; fullrationalbeta/globalclosedcoordinates/formalgeometry/cost still separate.')
Path('/workspace/scratch/ct73-beta-fibres-acceptance.claim').write_text(fibres+'\n')
