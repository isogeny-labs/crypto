"""Retain the actual eight-object publication and exact manifests/FF."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,shutil,hashlib,lzma
r=Path('/workspace/crypto');study=r/'research/chained_jacobian_transfers_20261110';raw=Path('/workspace/scratch/ct55-g3-latest-publication-raw-01');base='a719f6f75f67576ce3835d8acc6e47bb25a3cbe4';bot='bb6e272446f5c58c92ccbb73d4ccebba76d9b56b'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==bot
assert subprocess.check_output(['git','rev-parse',bot+'^'],cwd=r,text=True).strip()==base
log=(raw/'whole-job.log').read_bytes();assert log==json.loads((raw/'log-api.json').read_text())['structuredContent']['content'].encode();assert log.index(b'8 remote objects replayed')<log.index(b'[detached HEAD bb6e27244]')
jobs=json.loads((raw/'jobs-api.json').read_text())['structuredContent']['jobs'];assert len(jobs)==1 and jobs[0]['id']==131733754230 and jobs[0]['run_id']==43379515719 and jobs[0]['conclusion']=='success'
ff=Path('/workspace/scratch/ct55-g3-artifact-ff-02');assert all((ff/(x+'.exit')).read_text().strip()=='0' for x in ['fetch','exact-ff','artifact','wiring'])
shutil.copytree(ff,raw/'exact-ff');shutil.copytree('/workspace/scratch/ct55-g3-source-publication-01',raw/'normal-publication');shutil.copytree('/workspace/scratch/ct55-g3-publication-run-discovery-01',raw/'source-run-discovery');shutil.copyfile('/workspace/scratch/ct55_record_latest_publication.py',raw/'original-recorder.py');shutil.copyfile('/workspace/scratch/ct55-g3-local-proof-subject-hydration.json',raw/'local-proof-subject-hydration.json')
objects=[]
for name in ['genus3-accepted-raw-handoff-01','genus3-artifact-publication-01','genus3-integration-raw-handoff-01','genus3-root-regression-01']:
    p=study/'evidence'/name/'.artifacts.json';shutil.copyfile(p,raw/(name+'-canonical-manifest.json'))
    for file,entry in json.loads(p.read_text())['files'].items():
        path=str((p.parent/file).relative_to(r));original=subprocess.check_output(['git','show',base+':'+path],cwd=r);assert len(original)==entry['bytes'] and hashlib.sha256(original).hexdigest()==entry['sha256']
        objects.append(dict(path=path,**entry,S3_object='s3://setec-astronomy-artifacts/store/sha256/'+entry['sha256'][:2]+'/'+entry['sha256']))
assert len(objects)==8
data=dict(at=datetime.now(timezone.utc).isoformat(),run=43379515719,job=131733754230,conclusion='success',scientific_source=base,canonical_bot=bot,exact_bot_parent=base,exact_changed_paths=16,actual_remote_objects_replayed_BEFORE_bot=8,object_scope='SEVENwholearchives+ONEcompletelosslessmemberindex',objects=objects,exact_local_FF=0,artifact_check=0,wiring_check=0,all_owned_dirty_bytes_and2133_native_inputs_preserved=True,whole_log_bytes=len(log),whole_log_sha256=hashlib.sha256(log).hexdigest(),proof_subject_hydration='exact2 locally restoredfromacceptedoriginalGitblob,hashesmatchcanonicalmanifest;actualremote8witnessiswholetrustedjob,not localcopy',standing='unsigned actualpublication/custody,not scientificsignature or globalrootpass')
(raw/'publication.json').write_text(json.dumps(data,indent=2)+'\n')
subprocess.run(['python3','/workspace/scratch/ct55_pack_closed_tree.py','latest-publication-raw-01'],cwd=r,check=True)
out=study/'evidence/genus3-latest-publication-raw-01';shutil.copyfile(raw/'publication.json',out/'publication.json');z=lzma.compress(log,format=lzma.FORMAT_XZ,preset=9);assert lzma.decompress(z)==log;(out/'whole-job.log.xz').write_bytes(z)
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Unsigned ACTUALlatestG3publication:trusted-base43379515719/job131733754230SUCCESS EIGHTwhole remoteobjectsreplayed BEFOREnormalbotbb6e/directparenta719/EXACT16paths;SEVENwholearchives plusONEcomplete95052bytememberindex. Everyactualcanonicalmanifest size/SHA matchesintactoriginalGitblob;exactlocalFF/artifact/wiring0/allowned dirtybytesand2133nativeinputs unchanged. WholeUTF8log exactAPIbytes/stdXZ/rawarchive/memberhash/roundtrip retained. Exact2PCCsubjects locallyrestoredfromoriginalblobs matchgenuinemanifests;remoteproofisactualtrustedjob. Separate scientific/root/CI standing,no inferred mainmerge/cost.']
for name in ['publication.json','custody.json','whole-job.log.xz']:cmd+=['--proof','attestation:'+str((out/name).relative_to(r))]
if (out/'whole-raw.tar.xz').stat().st_size<=65536:cmd+=['--proof','attestation:'+str((out/'whole-raw.tar.xz').relative_to(r))]
cl=subprocess.run(cmd,cwd=r,capture_output=True,text=True,check=True).stdout.strip();Path('/workspace/scratch/ct55-g3-latest-actual-publication.claim').write_text(cl+'\n');print(cl,len(log),len(z),len(objects),flush=True)
