# Arithmetic audit canonical artifacts

Whole native-output XZ71856B from8d0c27 and forthcoming inspectedreportPDF; genuinepublisheravailability pending. NativeproofrelativeGitlink preserveswholebytes andimmutablePCCsubjectdigest. Source-levelunpricedvectors; no computationaladvantage claimed. [pcc:unverified]
