"""Whole nonsecret closure and restorable pending source, I/O only."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';base='584ba997263904cc2b0f35f4dc1a2b5563eabb2a';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==base
old=Path('/workspace/scratch/ct71-current-original-checkpoint-01');public=Path('/workspace/scratch/ct72-current-checkpoint-public-01');public.mkdir();excluded=[]
for p in old.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(old);raw=p.read_bytes()
 if rel==Path('download-api.json'):
  excluded.append(dict(path=str(rel),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),reason='private temporary FileService download reference; entire original retained privately'));continue
 dest=public/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
assert len(excluded)==1
(public/'private-reference-exclusions.json').write_text(json.dumps(dict(original_full_private_tree=str(old),public_scope='ALL nonsecret files includingwhole111985BZIP/ALL28members/originalremote+localgate outputs/receipt/API;ONLYprivate temporarydownloadreference excluded',excluded=excluded),indent=2)+'\n')
# Close the native report tools before reclaiming their derived compiler cache.
report=Path('/workspace/scratch/ct72-arithmetic-report-native-01');cache=Path(str(report)+'-build-cache');binaries=[]
for name in ['census','vector_table']:
 src=cache/'release'/name;dest=report/(name+'-actual-executable.bin');raw=src.read_bytes();dest.write_bytes(raw);binaries.append(dict(path=str(dest),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
files=[p for p in cache.rglob('*')if p.is_file()];receipt=dict(at=datetime.now(timezone.utc).isoformat(),removed_only_closed_derived_report_cache=str(cache),files=len(files),bytes=sum(p.stat().st_size for p in files),actual_exercised_binaries_retained=binaries,all_raw_sources_outputs_and_original_root_binary_warm_ct57_cache_kept=True);shutil.rmtree(cache);Path('/workspace/scratch/ct72-report-derived-cache-cleanup-01.json').write_text(json.dumps(receipt,indent=2)+'\n')
closure=Path('/workspace/scratch/ct72-arithmetic-closed-source-output-01');closure.mkdir();folders=['ct72-arithmetic-native-layout-01','ct72-arithmetic-native-layout-02','ct72-arithmetic-native-layout-03','ct72-arithmetic-small-root-layout-02','ct72-arithmetic-small-root-layout-03','ct72-arithmetic-small-root-layout-04','ct72-arithmetic-native-01','ct72-arithmetic-native-02','ct72-arithmetic-native-03','ct72-arithmetic-native-04','ct72-arithmetic-post-validation-01','ct72-arithmetic-materialization-failure-01','ct72-arithmetic-comparator-failure-01','ct72-arithmetic-hook-canaries-01','ct72-arithmetic-hook-canaries-02','ct72-arithmetic-hook-canaries-03','ct72-cargo-lock-control-01','ct72-cargo-feature-control-01','ct72-arithmetic-report-native-01','ct72-arithmetic-literature-01']
for name in folders:shutil.copytree(Path('/workspace/scratch')/name,closure/name,symlinks=True)
helpers=[p for p in Path('/workspace/scratch').glob('ct72*.py')if p.is_file()]
receipts=[p for p in Path('/workspace/scratch').glob('ct72*')if p.is_file()and(p.name.endswith('.txt')or p.name.endswith('.exit')or p.name.endswith('.claim')or p.name.endswith('.sha256')or p.name.endswith('cleanup-01.json'))]
for p in helpers+receipts:shutil.copyfile(p,closure/p.name)
shutil.copytree(s/'arithmetic-audit',closure/'current-additive-code',symlinks=True)
(closure/'closure-scope.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),whole_folders=folders,all_scientific_source_outputs_failures_binaries_preserved=True,original785_and_all_derivatives_included=True,original12_and_new19_source_manifest_drafts_preserved=True,caches_outside_captures_only_closed_derived_reclaimed=True,scope='native01/02/03negatives/native04positive+postall86/actualomittedhookpositive0negative101/reportvectornative/Cargofeaturediagnosis/ALLsource-layoutattempts; allunsigned; not a benchmark'),indent=2)+'\n')
drafts=Path('/workspace/scratch/ct72-arithmetic-report-capture-01');drafts.mkdir();shutil.copytree('/workspace/scratch/ct72-arithmetic-report-drafts-01',drafts/'draft01')
for i in [1,2,3]:shutil.copyfile('/workspace/scratch/ct72-arithmetic-report-final-page-'+str(i)+'.png',drafts/('final-page'+str(i)+'.png'))
for name in ['01','02']:
 for suffix in ['txt','exit']:shutil.copyfile('/workspace/scratch/ct72-arithmetic-report-compile-'+name+'.'+suffix,drafts/('compile-'+name+'.'+suffix))
shutil.copyfile(s/'reports/arithmetic-audit-01/report.pdf',drafts/'whole-final-report.pdf')
(drafts/'scope.json').write_text(json.dumps(dict(report='03cfb7/THREEfinal92135BpagesALLviewed/SHAeb814265',draft='whole92144BfirstPDF+all3images preserved; identity-location wordbelow->above only',final='ALL3finalimages/finalwholePDF/compileoutputs'),indent=2)+'\n')
# Capture before creating any new handoff payload; the checkpoint cannot contain itself.
o=Path('/workspace/scratch/ct72-arithmetic-source-checkpoint-01');o.mkdir();scope=['experiments/chained-transfer-public-target','.github/workflows/chained-transfer-arithmetic-audit.yml','docs/research-artifacts/chained-transfer/arithmetic-audit-01','pcc/claims','pcc/ledger.jsonl','docs/session-logs/2026-11-14.md','.resume/RESUME.md','problems/chained-transfer-new-jacobian-ic-cost-coverage.md']
paths=set(subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard','-z','--',*scope],cwd=r).split(b'\0'))-{b''}
for rel in ['experiments/chained-transfer-public-target/arithmetic-audit/taps/Cargo.lock','docs/research-artifacts/chained-transfer/arithmetic-audit-01/report.pdf','docs/research-artifacts/chained-transfer/arithmetic-audit-01/native-output.txt.xz','experiments/chained-transfer-public-target/reports/arithmetic-audit-01/report.pdf']:paths.add(rel.encode())
members={}
for name in sorted(paths):
 rel=name.decode();p=r/rel;assert p.is_file(),rel;target=o/'files'/rel;target.parent.mkdir(parents=True,exist_ok=True)
 if p.is_symlink():target.symlink_to(os.readlink(p))
 else:shutil.copyfile(p,target)
 b=p.read_bytes();members[rel]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),symlink_target=os.readlink(p)if p.is_symlink()else None)
assert all(hashlib.sha256((o/'files'/f).read_bytes()).hexdigest()==meta['sha256']for f,meta in members.items())
(o/'source-members.json').write_text(json.dumps(members,indent=2)+'\n');(o/'tracked-worktree.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=r));shutil.copyfile(__file__,o/'original-snapshot-command.py')
(o/'base-and-restoration.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),repository='isogeny-labs/cryptanalysis',base=base,branch='research/chained-transfer-public-target-20261113',producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2',owned_pending_files=len(members),restore='checkoutexactbase; copyfiles/into consumer preservingrelative symlinktypes/targets; source/PCCledger exactprefix captured; verify frozen784 andnew19+self20; latercustody/publicationmetadata appendseparately',native='8d0c27/ONEunfiltered1pass/all86exact/actualomissioncanary0+101',vectors='8c2406/all7113recordedrowsconserved/moreproductsfewerinverses/unpriced',report='03cfb7/THREEfinal92135BpagesALLviewed',new_CI='new18thworkflow/14orderedphases/new19+self20/785originalinputs/freshfull+ownCIpending',scope='ALLownedpendingcode/protocols/current19inputmanifest/tapCargo.lock/PCCledger+claims/nativeproofs/wholecanonicalPDF+71856nativeXZ+relativealiases/resume/queue/reporteditables; BEFOREhandoff payload, no recursivedata orprivateglobalinstructions/credentials'),indent=2)+'\n')
print(json.dumps(dict(public_checkpoint_files=sum(p.is_file()for p in public.rglob('*')),private_exclusions=len(excluded),arithmetic_whole_files=sum(p.is_file()for p in closure.rglob('*')),source_pending_files=len(members),source_base=base,report_cache_reclaimed=receipt['bytes'])),flush=True)
