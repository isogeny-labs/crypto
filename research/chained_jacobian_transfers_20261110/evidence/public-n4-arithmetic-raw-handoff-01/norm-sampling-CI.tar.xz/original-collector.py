"""Custody and strict JSON/digest checks; no scientific computation."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, importlib.util, json, lzma, re, shutil, subprocess, sys
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target'
source='21afb40f425f89774fe3eaf77695f5f30342a186'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==source
def claim(text,d):
    cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement',text]
    for p in sorted(d.iterdir()):
        if p.is_file():cmd+=['--proof','attestation:'+str(p.relative_to(r))]
    result=subprocess.check_output(cmd,cwd=r,text=True).strip();print(result,flush=True);return result
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def records(log):
    out=[]
    for line in log.splitlines():
        m=re.search(r'\b(N4_[A-Z0-9_]+) (\{.*\})$',line)
        if m:out.append(dict(kind=m[1],data=json.loads(m[2])))
    return out
def canonical(rows):
    rows=json.loads(json.dumps(rows))
    def report(x):
        for phase in x['phases']:del phase['wall']
        x['stats']=[p for p in x['stats']if p[0]!='wall_total']
    def origin(x):
        for arm in ['original','candidate']:report(x[arm])
    for row in rows:
        k,x=row['kind'],row['data']
        if k=='N4_NEW_JACOBIAN_IC_ATTEMPT':report(x['report'])
        elif k=='N4_COMPLETED_ATTEMPT':
            for arm in ['baseline','candidate']:report(x[arm])
        elif k=='N4_PUBLIC_ATTEMPT':report(x['public'])
        elif k=='N4_ORIGIN_ATTEMPT':origin(x)
        elif k=='N4_NORM_SAMPLER_ATTEMPT':origin(x)
        elif k=='N4_ORIGIN_SCOPE':
            for attempt in x['all_attempts']:origin(attempt)
    return sorted(json.dumps(x,sort_keys=True,separators=(',',':'))for x in rows)
def read(p):
    raw=p.read_bytes();return json.loads(lzma.decompress(raw)if p.suffix=='.xz'else raw)
def retain(d,o,name,raw):
    z=lzma.compress(raw);lossless=o/'lossless';lossless.mkdir(exist_ok=True);(lossless/(name+'.xz')).write_bytes(z)
    rec=dict(name=name,raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),xz_bytes=len(z),xz_sha256=hashlib.sha256(z).hexdigest(),whole_local_capture=str(lossless/(name+'.xz')),genuine_whole_archive_publication='pending unchanged publisher;no new remote availability assertion')
    if len(z)<65536:(d/(name+'.xz')).write_bytes(z);rec['small_whole_Git_object']=str((d/(name+'.xz')).relative_to(r))
    else:write(d/(name+'.hash.json'),rec)
    return rec
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py');pcc=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pcc;spec.loader.exec_module(pcc)

o=Path('/workspace/scratch/ct71-current-original-checkpoint-01');d=r/'docs/chained-transfer-checkpoint-transport/acceptance-03';d.mkdir()
meta=read(o/'observation.json');assert meta['source']==source and meta['original_local_gate']==0 and meta['original_remote_gate']==0 and meta['whole_members']==28 and meta['artifact_bytes']==111985
catalog=[]
for name in ['observation.json','whole-members.json','original-import-command.py','before-Git-status.txt','after-Git-status.txt','original-local-status.log','original-local-status.exit','original-local-gate.log','original-local-gate.exit']:
 catalog.append(retain(d,o,name,(o/name).read_bytes()))
for p in sorted((o/'members').iterdir()):catalog.append(retain(d,o,'member-'+p.name,p.read_bytes()))
for name in ['jobs-api.json','artifacts-api.json','whole-log-api.json','whole-original-GitHub-artifact.zip']:catalog.append(retain(d,o,name,(o/name).read_bytes()))
write(d/'whole-object-catalog.json',catalog)
transport=claim('Originalcheckpointtransport acceptance03 exactCLEAN21afb40f:automatic43547710178/job132302784079/artifact14094547986 WHOLE111985B/SHA311c253a2d6fa0c18dbd7b800eac2e5a02f6cb8feda1c7fd7be864e461e90077/all28members. UNCHANGEDoriginalconsumer3de8tool/SHA3c419216 remoteORIGINALgate0/readbackpackResumeMeta0/exactsource-resume-tool. ONLYgenuine233Breceipt importedignoredlastpush matchingcleanHEAD;ORIGINALlocalstatus0current/gate0unchangedsince/Gitstatusunchanged. No keyexport orsyntheticreceipt;private temporarydownloadreference staysoutsidepublicevidence. Latermetadataeditsstaleit;livebudgetcapacityisolation/coststrongestrefs stillrequired. Wholelogs/API/ZIP/members local,smallwholeGit/largecatalogpendinggenuinearchive;unsigned/no performance orrootglobalwaiver.',d)

o=Path('/workspace/scratch/ct71-norm-sampling-full-01');d=s/'evidence/norm-sampling-independent-full-01';d.mkdir()
for p in [o/'native.exit',o/'guard.exit',o/'driver/original.exit',o/'driver/guard.exit',o/'driver/cleanliness.exit',o/'original-fixture-verify.exit']:assert p.read_text().strip()=='0',p
assert read(o/'guards.json')==dict(count=785,changed=[])
phases=[line.split()for line in(o/'driver/phase-index.txt').read_text().splitlines()];assert len(phases)==10
for name,wanted,actual in phases:assert wanted==actual=='0'and(o/'driver'/(name+'.pipe-exits')).read_text().split()==['0','0']
assert read(o/'admission/restoration.json')==dict(all785_unchanged=True,clean_siblings=True,four_exit2_no_output=True)
controls=read(o/'admission/results.json');assert len(controls)==4 and all(x['original_exit']==2 and not x['output_created']for x in controls)
log=(o/'driver/solver.log').read_text();assert '1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out'in log
rows=records(log);assert len(rows)==86 and canonical(rows)==canonical(read(s/'ci_norm_sampling/expected-native.json.xz'))
raw=json.dumps(rows,indent=2).encode()+b'\n';(o/'all-native-records.json').write_bytes(raw);catalog=[retain(d,o,'whole-native.json',raw)];verdicts=[]
for b in read(s/'evidence/norm-sampling-bindings-02/claims.json'):
 v=read(o/'driver'/('binding-'+Path(b['claim_path']).stem+'.log'));c=read(r/b['claim_path']);assert v['verdict']=='pass'and not v['reasons']and v['commit']==source and v['claim_sha256']==pcc.claim_digest(c);verdicts.append(v)
assert len(verdicts)==3
for p in [o/'guards.json',o/'plan.json',o/'original-command.sh',o/'admission/results.json',o/'admission/restoration.json',o/'fixture-materialization.json']:shutil.copyfile(p,d/p.name)
write(d/'exact-local-verdicts.json',verdicts);write(d/'whole-object-catalog.json',catalog)
write(d/'observation.json',dict(at=datetime.now(timezone.utc).isoformat(),source=source,producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2',outer_guards=785,portable_inputs=784,changed=[],ten_native_tee_pairs='0/0',one_unfiltered_test=True,all86_complete_JSON_match=True,excluded='ONLY ATTEMPToriginal/candidate phases[*].wall and stats.wall_total;ALLdescent counters/classes/calls/failures exact',both_original_proof_gates='3declarations/zero trusted',canonical_original_bindings=3,four_actual_admission='2/nooutput/restored',fixture='alreadygenuinewhole120752B/copied0444/originalverify0;notfreshremoteread',scope='correctness/unsigned/conditionalgeometry/fullcost remain'))
shutil.copyfile(__file__,o/'acceptance-collector.py')
full=claim('Independentnorm-assisted full01 exact21afb40f/original3d:ALL785outer784portable+self inputsunchanged/HEADcleanliness0/FOURactualadmission2nooutputrestored. TENorderednative+tee0/0/ONEunfilteredtest0/ALL86wholeJSON matchnative9bc5e6 exceptONLYdeclaredATTEMPToriginal-candidatewall+walltotal;EVERYdescentcounter/class/call/failure/tentativescalar exact/rawtimingsretained. All225scalarpairs1125triples60ICpairs120reports/all15publiccases/15sharedFB30failures exact. BOTHunchangedoriginal3declarationgates0trusted/THREEexactORIGINALcanonicalPCCbindings789d94a9a7afed533b pass/sourceexact/60uniquepartialunsigned. FreshphysicalGitsiblings/outsidebuildcache/wholealreadygenuine120752Bfixturecopied0444/originalverify0/notfreshremoteread. Wholelogs/sources/exits/controls kept/smallwholeGit+largecatalogpendingnextgenuinearchive;notcompletegeometricformalization orcost/mergewaiver.',d)

o=Path('/workspace/scratch/ct71-norm-sampling-own-CI-raw-01');d=s/'evidence/norm-sampling-own-CI-01';d.mkdir()
markers={'completed':'Completed-descent replay complete:','V2':'Completed V2/rho replay complete:','P1':'Public-target N4 replay complete:','two-primary':'Actual two-primary replay complete:','bitangents':'Actual bitangent replay complete:','kernels':'Actual kernel census/replay complete:','gluing':'Actual alternative gluing replay complete:','chain':'Actual chain-kernel replay complete:','odd':'Actual odd-source replay complete:','product':'Actual odd-product replay complete:','refinement':'Actual odd-product refinement replay complete:','newIC':'Actual new-target IC replay complete:','origin':'Actual common-origin IC replay complete:','sampling':'Actual norm-assisted sampling replay complete:','fixture':'Original root','checkpoint':'original-checkpoint','PCC':'Verify all claims'}
rows={};verdicts=[];jobs=[]
for item in read(o/'inventory.json'):
 label,run,job=item['label'],item['run'],item['job'];api=read(o/(label+'-jobs-api.json'))['structuredContent']['jobs'];target=[x for x in api if x['id']==job];assert len(target)==1
 j=target[0];assert(j['run_id'],j['status'],j['conclusion'])==(run,'completed','success')
 log=read(o/(label+'-log-api.json'))['structuredContent']['content'];assert source in log and(label in ['PCC','fixture','checkpoint']or markers[label]in log)
 (o/(label+'-whole-job.log')).write_text(log);jobs.append(dict(label=label,run=run,job=job,conclusion='success'))
 if label=='PCC':
  sign=[x for x in api if x['name']=='sign'];assert len(sign)==1 and sign[0]['conclusion']=='skipped';assert any('exit 2 = not covered is allowed'in step['name']for step in j['steps'])
 elif label not in ['fixture','checkpoint']:
  rows[label]=records(log)
  for line in log.splitlines():
   if '{"claim_id":'in line:verdicts.append(json.loads(line[line.index('{"claim_id":'):]))
assert len(jobs)==17 and set(x['label']for x in jobs)==set(markers)
assert{k:len(v)for k,v in rows.items()}==dict(completed=17,V2=12,P1=13,**{'two-primary':4,'bitangents':4,'kernels':8,'gluing':18,'chain':4,'odd':4,'product':17,'refinement':7,'newIC':82,'origin':51,'sampling':86})
expected={'completed':read(s/'ci_completed/expected-native.json'),'P1':read(s/'evidence/unit-acceptance-01/all-native-records.json'),'two-primary':read(s/'ci_two_primary/expected-native.json'),'bitangents':read(s/'ci_bitangents/expected-native.json'),'kernels':read(s/'ci_kernels/expected-native.json'),'chain':read(s/'ci_chain/expected-kernels.json.xz'),'odd':read(s/'ci_odd/expected-kernels.json.xz'),'refinement':read(s/'ci_odd_refinement/expected-native.json.xz'),'newIC':read(s/'ci_new_target_ic/expected-native.json.xz'),'origin':read(s/'ci_common_origin/expected-native.json.xz'),'sampling':read(s/'ci_norm_sampling/expected-native.json.xz'),'gluing':read(s/'ci_gluing/expected-models.json.xz')+read(s/'ci_gluing/expected-maps.json.xz'),'product':read(s/'ci_odd_product/expected-models.json.xz')+read(s/'evidence/odd-product-maps-acceptance-02/all-native-records.json.xz')}
for label,wanted in expected.items():assert canonical(rows[label])==canonical(wanted),label
for prefix,name in [('N4_V2_','expected-native-v2.json'),('N4_RHO_','expected-native-rho.json')]:assert canonical([x for x in rows['V2']if x['kind'].startswith(prefix)])==canonical(read(s/'ci_v2'/name))
digests={}
for folder in ['lean-bindings-01','origin-lean-bindings-01','prime-field-bindings-02','two-primary-bindings-01','bitangent-bindings-01','kernel-bindings-01','gluing-models-bindings-01','gluing-chain-bindings-01','chain-kernel-bindings-01','odd-source-bindings-01','odd-product-chain-bindings-01','odd-product-refinement-bindings-01','new-target-IC-bindings-01','norm-sampling-bindings-02']:
 for b in read(s/'evidence'/folder/'claims.json'):
  c=read(r/b['claim_path']);digests[c['id']]=pcc.claim_digest(c)
assert len(digests)==60 and len(verdicts)==62 and set(digests)=={v['claim_id']for v in verdicts}
counts=Counter(v['claim_id']for v in verdicts);assert{k:v for k,v in counts.items()if v!=1}=={'PCC-20261113-01efbf':2,'PCC-20261113-671d42':2}
for v in verdicts:assert v['verdict']=='pass'and not v['reasons']and v['commit']==source and v['claim_sha256']==digests[v['claim_id']]
fullraw=Path('/workspace/scratch/ct71-norm-sampling-full-01');shutil.copytree(fullraw/'driver/source',o/'source');shutil.copyfile(fullraw/'original-reference.sha256',o/'source/cryptanalysis/experiments/chained-transfer-public-target/ci_norm_sampling/reference-01.sha256');assert sum(p.is_file()for p in(o/'source').rglob('*'))==785
for name,data in [('all-native-records.json',rows),('all62-exact-verdicts.json',verdicts),('original-PCC-canonical-digests.json',digests)]:write(o/name,data)
meta=dict(at=datetime.now(timezone.utc).isoformat(),source=source,jobs=jobs,unique_workflows=17,event_runs=17,native_records=327,all327_complete_JSON_match_except_ONLY_frozen_wall_fields=True,all_raw_timings_retained=True,original_canonical_PCC_unique_digests=60,actual_verdict_records=62,original_two_bindings_reused_twice=['01efbf','671d42'],all_source_and_digests_exact=True,PCC_sign='legitimately skipped featurebranch',PCC_gate='success;explicitlyallowsnotcovered2',whole_logs_API_and785_source_snapshots_retained=True,science_artifact_ZIPs_downloaded=False,checkpoint_ZIP='separatelydownloaded111985B/all28members/originaltoolverified',CI_guard_scope='originalsuccessfulsteps andcomplete markers;standaloneexitfiles notdownloaded;separatephysicalfull785guards0/tenphasepairs/fouractualcontrols',scope='correctness/unsigned/conditionalgeometry/fullcost remain')
write(o/'plan.json',meta);write(d/'observation.json',meta);shutil.copyfile(__file__,o/'original-collector.py');catalog=[]
for name in ['all-native-records.json','all62-exact-verdicts.json','original-PCC-canonical-digests.json']:catalog.append(retain(d,o,name,(o/name).read_bytes()))
for label in markers:catalog.append(retain(d,o,label+'-whole-job.log',(o/(label+'-whole-job.log')).read_bytes()))
write(d/'whole-object-catalog.json',catalog)
ci=claim('Exact21afb40f ownCI ALLSEVENTEENunique workflowsSUCCESS/17automaticeventruns/nomanualredispatch. ALL327complete nativeJSON matchfrozenoriginals;ONLYdeclared oldcompleted/P1/newIC/commonoriginATTEMPT+duplicatedSCOPE andnormsamplerATTEMPT rawwall fields omitted/ALLotherfieldsincludingALLdescentcounters/classes/calls/failures/tentativescalars exact/rawtimingsretained. ALL60unique ORIGINALcanonical PCCdigests match/sourceexact/passunsigned;62actualverdictrecords becauseold01efbf671d42eachchecked twice/newIC+origin/newnorm3bindingsdistinct. NewnormsamplerONEunfilteredtest86records225scalarpairs1125triples60ICpairs120reports/bothoriginal3gates/3faithfulbindings;previous241native57digests unchanged. Fixture+checkpointdataonlySUCCESS/noextramathrecords;PCCsignlegitimatelyskipped/notcovered2allowed. WHOLE17decodedlogs/API/785selectedsources retained/smallwholeXZGit/largecombinednative+gluing+product+samplerlogs cataloguedpendingnextgenuinearchive/no newremoteavailabilityassertion. CIguardsscopeoriginalsuccessfulsteps/markers/notdownloadedscienceZIPs;separateactualphysical785fullguards0/tenphasepairs/fouractualcontrols. Conditionalgeometry/fullcost/mainmerge remain/no performanceclaim.',d)
print(json.dumps(dict(transport=transport,full=full,CI=ci,native=327,unique_digests=60,actual_verdict_records=62,source=source)),flush=True)

