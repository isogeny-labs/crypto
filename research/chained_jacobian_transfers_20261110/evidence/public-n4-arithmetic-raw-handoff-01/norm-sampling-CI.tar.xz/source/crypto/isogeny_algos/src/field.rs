//! Field abstraction. Baseline arithmetic is deliberately naive
//! (u128 `%` reduction, extended-Euclid inversion) so later iterations have
//! something to beat.
use crate::bigint::Big;
use std::fmt::Debug;
use std::hash::Hash;

#[derive(Clone)]
pub struct Rng(u64);
impl Rng {
    pub fn new(seed: u64) -> Self {
        Rng(seed.wrapping_mul(0x9E3779B97F4A7C15) ^ 0xD1B54A32D192ED03)
    }
    // a deterministic generator, not an iterator (callers draw words, ranges and field elements)
    #[allow(clippy::should_implement_trait)]
    pub fn next(&mut self) -> u64 {
        self.0 = self.0.wrapping_add(0x9E3779B97F4A7C15);
        let mut z = self.0;
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58476D1CE4E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D049BB133111EB);
        z ^ (z >> 31)
    }
    pub fn below(&mut self, n: u64) -> u64 {
        self.next() % n
    }
}

/// A fixed operand prepared for repeated products, in a field-specific form
/// (`Field::prepare`).
pub type Prepared = std::rc::Rc<dyn std::any::Any>;

pub trait Field: Clone + Send + Sync + 'static {
    type E: Copy + Eq + Hash + Debug + Send + Sync;
    fn zero(&self) -> Self::E;
    fn one(&self) -> Self::E;
    fn add(&self, a: Self::E, b: Self::E) -> Self::E;
    fn sub(&self, a: Self::E, b: Self::E) -> Self::E;
    fn neg(&self, a: Self::E) -> Self::E;
    fn mul(&self, a: Self::E, b: Self::E) -> Self::E;
    /// Inverse; panics on zero.
    fn inv(&self, a: Self::E) -> Self::E;
    // the field (modulus, representation) converts the integer, hence &self
    #[allow(clippy::wrong_self_convention)]
    fn from_u64(&self, n: u64) -> Self::E;
    fn char(&self) -> u64;
    /// Exact comparison against a small integer. Multiword prime fields override
    /// this because their legacy `char()` accessor exposes only the low limb.
    fn characteristic_exceeds(&self, n: u64) -> bool {
        self.char() > n
    }
    /// Field size q (p or p^2).
    fn size(&self) -> u128;
    fn random(&self, rng: &mut Rng) -> Self::E;
    fn is_zero(&self, a: Self::E) -> bool {
        a == self.zero()
    }
    fn sq(&self, a: Self::E) -> Self::E {
        self.mul(a, a)
    }
    /// Operand length below which polynomial products are schoolbook (`conv`).
    fn karatsuba_threshold(&self) -> usize {
        32
    }
    fn pow(&self, a: Self::E, mut e: u128) -> Self::E {
        let mut r = self.one();
        let mut b = a;
        while e > 0 {
            if e & 1 == 1 {
                r = self.mul(r, b);
            }
            b = self.mul(b, b);
            e >>= 1;
        }
        r
    }
    /// Field size as a big integer (defaults to `size()`; big fields override).
    fn q(&self) -> Big {
        Big::from_u128(self.size())
    }
    /// a^e by left-to-right sliding windows over the odd powers a, a^3, ..., a^(2^w - 1)
    /// (w = 5 above 256 bits): ~bits/(w+1) multiplications instead of ~bits/2.
    fn pow_big(&self, a: Self::E, e: &Big) -> Self::E {
        let nb = e.bits();
        if nb <= 64 {
            return self.pow(a, e.to_u128().unwrap());
        }
        let w = if nb > 256 {
            5
        } else if nb > 128 {
            4
        } else {
            3
        };
        let a2 = self.sq(a);
        let mut tbl = Vec::with_capacity(1 << (w - 1));
        tbl.push(a);
        for k in 1..(1usize << (w - 1)) {
            tbl.push(self.mul(tbl[k - 1], a2));
        }
        let mut r = self.one();
        let mut started = false;
        let mut i = nb as isize - 1;
        while i >= 0 {
            if !e.bit(i as usize) {
                if started {
                    r = self.sq(r);
                }
                i -= 1;
                continue;
            }
            let mut j = (i - w as isize + 1).max(0);
            while !e.bit(j as usize) {
                j += 1;
            }
            let mut val = 0usize;
            for k in (j..=i).rev() {
                val = 2 * val + e.bit(k as usize) as usize;
            }
            if started {
                for _ in j..=i {
                    r = self.sq(r);
                }
                r = self.mul(r, tbl[(val - 1) / 2]);
            } else {
                r = tbl[(val - 1) / 2];
                started = true;
            }
            i = j - 1;
        }
        r
    }
    /// Full product of two coefficient vectors (length a.len()+b.len()-1). Default: schoolbook;
    /// single-word fields override it with lazy (accumulate-then-reduce) arithmetic.
    fn conv(&self, a: &[Self::E], b: &[Self::E]) -> Vec<Self::E> {
        let mut r = vec![self.zero(); a.len() + b.len() - 1];
        for (i, &x) in a.iter().enumerate() {
            if self.is_zero(x) {
                continue;
            }
            for (j, &y) in b.iter().enumerate() {
                r[i + j] = self.add(r[i + j], self.mul(x, y));
            }
        }
        r
    }
    /// Square of a coefficient vector, `conv(a, a)`; the prime fields override it to form each
    /// cross product once.
    fn conv_sq(&self, a: &[Self::E]) -> Vec<Self::E> {
        self.conv(a, a)
    }
    /// Longest modulus (coefficient count) that `poly::powmod` reduces with the table of
    /// x^k mod m rather than Newton/Barrett: the crossover depends on how fast long products
    /// are (`examples/profile_powmod.rs`).
    fn powmod_table_max(&self) -> usize {
        crate::poly::POWMOD_TABLE_MAX
    }
    /// Length below which `poly::sqr_raw` squares with `conv_sq` instead of splitting.
    fn sqr_threshold(&self) -> usize {
        self.karatsuba_threshold()
    }
    /// Prepares the fixed operand `b` for repeated products ([`Field::conv_prepared`]) with
    /// operands of at most `max_len` coefficients, mod x^cyc - 1 when `cyc` (a power of two) is
    /// below the product length (`usize::MAX`: plain products); None when the field has no
    /// such method or it would not pay.
    fn prepare(&self, _b: &[Self::E], _max_len: usize, _cyc: usize) -> Option<Prepared> {
        None
    }
    /// The product of `a` with a prepared operand (equal to `conv`, or to its reduction mod
    /// x^cyc - 1), or None when `a` does not fit the preparation.
    fn conv_prepared(&self, _a: &[Self::E], _b: &Prepared) -> Option<Vec<Self::E>> {
        None
    }
    /// The product mod x^len - 1 (`len` a power of two, both operands at most `len` + 1 long
    /// and the product shorter than 2 len) by a transform of `len` points, or None when the
    /// field has no such method or the operands are too short for it to pay.
    fn conv_cyclic(&self, _a: &[Self::E], _b: &[Self::E], _len: usize) -> Option<Vec<Self::E>> {
        None
    }
    /// Full product of long coefficient vectors by a sub-quadratic method specific to the
    /// field, or None to use the generic Karatsuba of `poly::mul_raw`. Must equal `conv`.
    fn conv_long(&self, _a: &[Self::E], _b: &[Self::E]) -> Option<Vec<Self::E>> {
        None
    }
    /// First `n` coefficients of the product (truncated power-series multiplication).
    fn conv_trunc(&self, a: &[Self::E], b: &[Self::E], n: usize) -> Vec<Self::E> {
        let mut r = vec![self.zero(); n];
        for i in 0..a.len().min(n) {
            if self.is_zero(a[i]) {
                continue;
            }
            for j in 0..b.len().min(n - i) {
                r[i + j] = self.add(r[i + j], self.mul(a[i], b[j]));
            }
        }
        r
    }
    /// `dot_rev(a, b)` for each row b (all as long as `a`): a matrix-vector product, which the
    /// word-size fields run four rows at a time sharing the loads of `a`.
    fn dot_rev_rows(&self, a: &[Self::E], rows: &[&[Self::E]]) -> Vec<Self::E> {
        rows.iter().map(|b| self.dot_rev(a, b)).collect()
    }
    /// sum_i a[i] * b[len-1-i] over the common length (reversed dot product).
    fn dot_rev(&self, a: &[Self::E], b: &[Self::E]) -> Self::E {
        let n = a.len().min(b.len());
        let mut s = self.zero();
        for i in 0..n {
            s = self.add(s, self.mul(a[i], b[b.len() - 1 - i]));
        }
        s
    }
    /// Inverses of all non-zero entries with one field inversion (Montgomery's trick).
    fn batch_inv(&self, xs: &[Self::E]) -> Vec<Self::E> {
        let n = xs.len();
        let mut pre = Vec::with_capacity(n);
        let mut acc = self.one();
        for &x in xs {
            pre.push(acc);
            acc = self.mul(acc, x);
        }
        let mut inv = self.inv(acc);
        let mut out = vec![self.zero(); n];
        for i in (0..n).rev() {
            out[i] = self.mul(inv, pre[i]);
            inv = self.mul(inv, xs[i]);
        }
        out
    }
    #[allow(clippy::wrong_self_convention)]
    fn from_i64(&self, n: i64) -> Self::E {
        if n >= 0 {
            self.from_u64(n as u64)
        } else {
            self.neg(self.from_u64((-n) as u64))
        }
    }
    fn div(&self, a: Self::E, b: Self::E) -> Self::E {
        self.mul(a, self.inv(b))
    }
    /// Square root in a field of odd size (generic Tonelli-Shanks); None for non-residues.
    fn sqrt(&self, a: Self::E) -> Option<Self::E> {
        if self.is_zero(a) {
            return Some(a);
        }
        let q = self.q();
        if q.bit(0) && q.bit(1) {
            // q = 3 mod 4: one exponentiation, then check
            let r = self.pow_big(a, &q.add_small(1).shr(2));
            return if self.sq(r) == a { Some(r) } else { None };
        }
        let qm1 = q.sub_small(1);
        let half = qm1.shr(1);
        if self.pow_big(a, &half) != self.one() {
            return None;
        }
        let mut rng = Rng::new(0xC0FFEE);
        let z = loop {
            let z = self.random(&mut rng);
            if !self.is_zero(z) && self.pow_big(z, &half) != self.one() {
                break z;
            }
        };
        let mut s = 0u32;
        while !qm1.bit(s as usize) {
            s += 1;
        }
        let m = qm1.shr(s as usize);
        let mut c = self.pow_big(z, &m);
        let mut t = self.pow_big(a, &m);
        let mut r = self.pow_big(a, &m.add_small(1).shr(1));
        let mut mm = s;
        while t != self.one() {
            let (mut i, mut tt) = (0u32, t);
            while tt != self.one() {
                tt = self.sq(tt);
                i += 1;
            }
            let mut b = c;
            for _ in 0..(mm - i - 1) {
                b = self.sq(b);
            }
            mm = i;
            c = self.sq(b);
            t = self.mul(t, c);
            r = self.mul(r, b);
        }
        Some(r)
    }
}

/// Division-free reduction of 128-bit values modulo an odd word-size p < 2^62 (precomputed
/// constants; no `u128 %`, which is a library division call). `redc(x)` is x 2^-64 mod p
/// (Montgomery reduction, any x < 2^128); `reduce(x)` is x mod p.
#[derive(Clone, Copy, Debug)]
pub struct Red128 {
    p: u64,
    /// -p^{-1} mod 2^64
    ninv: u64,
    /// floor((2^64 - 1) / p), for Barrett reduction of one word
    bar: u64,
    /// 2^128 mod p
    r2: u64,
    /// 2^64 mod p
    r1: u64,
}

impl Red128 {
    pub fn new(p: u64) -> Self {
        assert!(p % 2 == 1 && p < (1u64 << 62), "Red128: odd p < 2^62");
        let mut inv = 1u64;
        for _ in 0..6 {
            inv = inv.wrapping_mul(2u64.wrapping_sub(p.wrapping_mul(inv)));
        }
        let r1 = ((1u128 << 64) % p as u128) as u64;
        Red128 {
            p,
            ninv: inv.wrapping_neg(),
            bar: u64::MAX / p,
            r2: ((r1 as u128 * r1 as u128) % p as u128) as u64,
            r1,
        }
    }
    /// x mod p for one word (Barrett; the quotient estimate is short by at most 2).
    #[inline(always)]
    pub fn mod_word(&self, x: u64) -> u64 {
        let q = ((x as u128 * self.bar as u128) >> 64) as u64;
        let mut r = x - q * self.p;
        if r >= self.p {
            r -= self.p;
        }
        if r >= self.p {
            r -= self.p;
        }
        r
    }
    /// x 2^-64 mod p: with x = h 2^64 + l, that is h + REDC(l), REDC(l) = (l + m p) / 2^64 <= p.
    #[inline(always)]
    pub fn redc(&self, x: u128) -> u64 {
        let h = self.mod_word((x >> 64) as u64);
        let l = x as u64;
        let m = l.wrapping_mul(self.ninv);
        let t = ((l as u128 + m as u128 * self.p as u128) >> 64) as u64;
        let mut s = h + t;
        if s >= self.p {
            s -= self.p;
        }
        s
    }
    /// A value congruent to x below 2^64 p (one multiplication): hi (2^64 mod p) + lo.
    #[inline(always)]
    pub fn fold(&self, x: u128) -> u128 {
        (x >> 64) * self.r1 as u128 + (x as u64) as u128
    }
    /// How a lazy accumulator whose final value must stay at most `limit` runs, keeping six
    /// products spare: (fold, step) — reduce with `fold` (below 2^64 p) or `reduce` (below p)
    /// after every `step` products, whichever leaves the longer steps.
    pub fn lazy_plan(&self, limit: u128) -> (bool, usize) {
        let pm = (self.p - 1) as u128;
        let pm2 = (pm * pm).max(1);
        let base = (u64::MAX as u128) * self.r1 as u128 + u64::MAX as u128;
        let room = |b: u128| {
            if limit > b {
                ((limit - b) / pm2).min(1 << 30) as usize
            } else {
                0
            }
        };
        let (f, r) = (room(base), room(self.p as u128));
        if f >= 16 || f >= r {
            (true, f.saturating_sub(6).max(1))
        } else {
            (false, r.saturating_sub(6).max(1))
        }
    }
    /// x mod p: redc(redc(x) 2^128 mod p) = x.
    #[inline(always)]
    pub fn reduce(&self, x: u128) -> u64 {
        self.redc(self.redc(x) as u128 * self.r2 as u128)
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Zp {
    pub p: u64,
    red: Red128,
}

impl Zp {
    pub fn new(p: u64) -> Self {
        assert!(p > 3 && p < (1u64 << 62));
        Zp {
            p,
            red: Red128::new(p),
        }
    }
    pub fn legendre(&self, a: u64) -> i32 {
        if a == 0 {
            return 0;
        }
        if self.pow(a, ((self.p - 1) / 2) as u128) == 1 {
            1
        } else {
            -1
        }
    }
    /// Tonelli-Shanks.
    pub fn sqrt(&self, a: u64) -> Option<u64> {
        if a == 0 {
            return Some(0);
        }
        if self.legendre(a) != 1 {
            return None;
        }
        let p = self.p;
        if p % 4 == 3 {
            return Some(self.pow(a, ((p + 1) / 4) as u128));
        }
        let mut q = p - 1;
        let mut s = 0;
        while q.is_multiple_of(2) {
            q /= 2;
            s += 1;
        }
        let mut z = 2;
        while self.legendre(z) != -1 {
            z += 1;
        }
        let mut m = s;
        let mut c = self.pow(z, q as u128);
        let mut t = self.pow(a, q as u128);
        let mut r = self.pow(a, q.div_ceil(2) as u128);
        while t != 1 {
            let mut i = 0;
            let mut tt = t;
            while tt != 1 {
                tt = self.mul(tt, tt);
                i += 1;
            }
            let mut b = c;
            for _ in 0..(m - i - 1) {
                b = self.mul(b, b);
            }
            m = i;
            c = self.mul(b, b);
            t = self.mul(t, c);
            r = self.mul(r, b);
        }
        Some(r)
    }
}

impl Field for Zp {
    type E = u64;
    fn zero(&self) -> u64 {
        0
    }
    fn one(&self) -> u64 {
        1
    }
    fn add(&self, a: u64, b: u64) -> u64 {
        let s = a + b;
        if s >= self.p {
            s - self.p
        } else {
            s
        }
    }
    fn sub(&self, a: u64, b: u64) -> u64 {
        if a >= b {
            a - b
        } else {
            a + self.p - b
        }
    }
    fn neg(&self, a: u64) -> u64 {
        if a == 0 {
            0
        } else {
            self.p - a
        }
    }
    fn mul(&self, a: u64, b: u64) -> u64 {
        self.red.reduce(a as u128 * b as u128)
    }
    fn inv(&self, a: u64) -> u64 {
        assert!(a != 0, "inverse of zero");
        crate::fpm::inv_u64(a, self.p)
    }
    fn from_u64(&self, n: u64) -> u64 {
        n % self.p
    }
    fn char(&self) -> u64 {
        self.p
    }
    fn size(&self) -> u128 {
        self.p as u128
    }
    fn random(&self, rng: &mut Rng) -> u64 {
        rng.below(self.p)
    }
    fn sqrt(&self, a: u64) -> Option<u64> {
        Zp::sqrt(self, a)
    }
    fn conv(&self, a: &[u64], b: &[u64]) -> Vec<u64> {
        lazy_conv(a, b, &self.red, a.len() + b.len() - 1, |x| {
            self.red.reduce(x)
        })
    }
    fn conv_trunc(&self, a: &[u64], b: &[u64], n: usize) -> Vec<u64> {
        lazy_conv(a, b, &self.red, n, |x| self.red.reduce(x))
    }
    fn dot_rev(&self, a: &[u64], b: &[u64]) -> u64 {
        lazy_dot_rev(a, b, &self.red, |x| self.red.reduce(x))
    }
    fn dot_rev_rows(&self, a: &[u64], rows: &[&[u64]]) -> Vec<u64> {
        lazy_dot_rev_rows(a, rows, &self.red, |x| self.red.reduce(x))
    }
    fn conv_sq(&self, a: &[u64]) -> Vec<u64> {
        lazy_sq(a, &self.red, |x| self.red.reduce(x))
    }
}

/// Bit length of the largest residue p - 1 (p >= 2).
#[inline]
fn residue_bits(p: u64) -> u32 {
    64 - (p - 1).leading_zeros()
}

/// Products (each < 2^(2b), b = residue_bits(p)) that a u128 accumulator already holding a value
/// < p can absorb before it must be reduced: 15 for p < 2^62 as before, 2^(127 - 2b) (at most
/// 2^30) when that is larger. Bit lengths only: this runs once per dot product.
#[inline]
fn lazy_cap(p: u64) -> usize {
    let b = 2 * residue_bits(p);
    if b >= 123 {
        15
    } else {
        1usize << (127 - b).min(30)
    }
}

/// Whether a sum of `terms` products of residues mod p fits in a u64.
#[inline]
fn fits_u64(p: u64, terms: usize) -> bool {
    2 * residue_bits(p) + (usize::BITS - terms.leading_zeros()) <= 64
}

/// sum_i a[i] b[n-1-i] for equal-length slices (p < 2^62), as a u128 congruent to the dot
/// product: up to `cap` products (`lazy_cap`) in one unreduced accumulator; longer, two u128
/// accumulators absorbing `cap` products each between reductions, in branch-free blocks
/// (the result then below 3p).
#[inline(always)]
fn dot_core(a: &[u64], b: &[u64], red: &Red128, cap: usize) -> u128 {
    debug_assert_eq!(a.len(), b.len());
    let n = a.len();
    if n <= cap {
        let mut s = 0u128;
        for (x, y) in a.iter().zip(b.iter().rev()) {
            s += *x as u128 * *y as u128;
        }
        return s;
    }
    let blk = 2 * cap;
    let mut tot = 0u64;
    let mut i = 0;
    while i < n {
        let m = (n - i).min(blk);
        let (xa, xb) = (&a[i..i + m], &b[n - i - m..n - i]);
        let (mut s0, mut s1) = (0u128, 0u128);
        let mut k = 0;
        while k + 1 < m {
            s0 += xa[k] as u128 * xb[m - 1 - k] as u128;
            s1 += xa[k + 1] as u128 * xb[m - 2 - k] as u128;
            k += 2;
        }
        if k < m {
            s0 += xa[k] as u128 * xb[m - 1 - k] as u128;
        }
        // three values below p: fits a u64 (p < 2^62), and the next mod_word brings it back
        tot = red.mod_word(tot + red.reduce(s0) + red.reduce(s1));
        i += m;
    }
    tot as u128
}

/// sum a[i] b[len-1-i] with lazy accumulation (p < 2^62), finished by `fin`, which receives the
/// unreduced sum (< 2^128, congruent to the dot product mod p): Zp passes `Red128::reduce`,
/// the Montgomery field `Red128::redc`. The sum stays in a u64 when it cannot overflow,
/// otherwise in u128 accumulators reduced every `lazy_cap(p)` products (`dot_core`).
pub fn lazy_dot_rev(a: &[u64], b: &[u64], red: &Red128, fin: impl Fn(u128) -> u64) -> u64 {
    let n = a.len().min(b.len());
    let bl = b.len();
    let p = red.p;
    if fits_u64(p, n) {
        let mut acc = 0u64;
        for i in 0..n {
            acc += a[i] * b[bl - 1 - i];
        }
        return fin(acc as u128);
    }
    fin(dot_core(&a[..n], &b[bl - n..], red, lazy_cap(p)))
}

/// `lazy_dot_rev(a, b, ..)` for each row b (each exactly as long as `a`), four rows at a time:
/// one load of a[i] feeds four independent u128 accumulators, each reduced below p every
/// `lazy_cap(p) - 1` products (so it never holds more than p plus `lazy_cap` products).
pub fn lazy_dot_rev_rows(
    a: &[u64],
    rows: &[&[u64]],
    red: &Red128,
    fin: impl Fn(u128) -> u64,
) -> Vec<u64> {
    let n = a.len();
    let p = red.p;
    if fits_u64(p, n) || rows.len() < 4 {
        return rows.iter().map(|b| lazy_dot_rev(a, b, red, &fin)).collect();
    }
    let step = (lazy_cap(p) - 1).max(1);
    let mut out = Vec::with_capacity(rows.len());
    let (quads, rest) = rows.as_chunks::<4>();
    for q in quads {
        let (b0, b1, b2, b3) = (&q[0][..n], &q[1][..n], &q[2][..n], &q[3][..n]);
        let mut s = [0u128; 4];
        let mut i = 0;
        while i < n {
            let e = (i + step).min(n);
            for j in i..e {
                let x = a[j] as u128;
                let k = n - 1 - j;
                s[0] += x * b0[k] as u128;
                s[1] += x * b1[k] as u128;
                s[2] += x * b2[k] as u128;
                s[3] += x * b3[k] as u128;
            }
            if e < n {
                for v in s.iter_mut() {
                    *v = red.reduce(*v) as u128;
                }
            }
            i = e;
        }
        out.extend(s.iter().map(|&v| fin(v)));
    }
    for b in rest {
        out.push(lazy_dot_rev(a, b, red, &fin));
    }
    out
}

/// Four consecutive coefficients k0..k0+3 of a lazily accumulated convolution: sums of
/// a[i] b[k0 + r - i] over i in [lo[r], hi[r]) for r < 4 (callers keep k0 + r - i inside b).
/// The common range is run four outputs at a time sharing the loads of a, folded or reduced
/// as `plan` (`Red128::lazy_plan`) says, so that each sum, with the few edge terms per output
/// (at most six), stays within the plan's limit.
#[inline(always)]
fn conv_block4(
    a: &[u64],
    b: &[u64],
    k0: usize,
    lo: [usize; 4],
    hi: [usize; 4],
    red: &Red128,
    plan: (bool, usize),
) -> [u128; 4] {
    let ilo = lo.iter().copied().max().unwrap();
    let ihi = hi.iter().copied().min().unwrap();
    let mut s = [0u128; 4];
    if ilo < ihi {
        let (fold, step) = plan;
        let mut i = ilo;
        while i < ihi {
            let e = (i + step).min(ihi);
            debug_assert!(e <= a.len() && k0 + 3 - i < b.len() && k0 >= e - 1);
            for j in i..e {
                // SAFETY: j < ihi <= a.len(), and k0 - j .. k0 - j + 3 lie in b: the common
                // range keeps every b index of the four outputs (k0 + r - j) in range
                let (x, w) = unsafe {
                    (
                        *a.get_unchecked(j) as u128,
                        b.get_unchecked(k0 - j..k0 - j + 4),
                    )
                };
                s[0] += x * w[0] as u128;
                s[1] += x * w[1] as u128;
                s[2] += x * w[2] as u128;
                s[3] += x * w[3] as u128;
            }
            i = e;
            for v in s.iter_mut() {
                *v = if fold {
                    red.fold(*v)
                } else {
                    red.reduce(*v) as u128
                };
            }
        }
    }
    // at most three edge terms on each side of the common range (the six kept spare)
    for r in 0..4 {
        let (l, h) = (lo[r], hi[r]);
        let (cl, ch) = if ilo < ihi { (ilo, ihi) } else { (h, h) };
        for j in (l..cl.min(h)).chain(ch.max(l)..h) {
            s[r] += a[j] as u128 * b[k0 + r - j] as u128;
        }
    }
    s
}

/// Convolution with lazy accumulation (p < 2^62): each output coefficient is summed in a u64
/// when that cannot overflow, otherwise by `dot_core`; `fin` maps the unreduced sum (< 2^128)
/// to the output representation.
pub fn lazy_conv(
    a: &[u64],
    b: &[u64],
    red: &Red128,
    nout: usize,
    fin: impl Fn(u128) -> u64,
) -> Vec<u64> {
    let (n, m) = (a.len(), b.len());
    let mut r = Vec::with_capacity(nout);
    if n == 0 || m == 0 {
        return vec![fin(0); nout];
    }
    let p = red.p;
    let small = fits_u64(p, n.min(m));
    let cap = lazy_cap(p);
    let last = nout.min(n + m - 1);
    let mut k = 0;
    // four outputs at a time once the ranges are long enough to pay
    if !small && n.min(m) >= 8 {
        let range = |k: usize| (k.saturating_sub(m - 1), k.min(n - 1) + 1);
        let plan = red.lazy_plan(u128::MAX);
        while k + 4 <= last {
            let rs: [(usize, usize); 4] = std::array::from_fn(|r| range(k + r));
            let s = conv_block4(a, b, k, rs.map(|x| x.0), rs.map(|x| x.1), red, plan);
            r.extend(s.iter().map(|&v| fin(v)));
            k += 4;
        }
    }
    for k in k..nout {
        if k > n + m - 2 {
            r.push(fin(0));
            continue;
        }
        let lo = k.saturating_sub(m - 1);
        let hi = k.min(n - 1);
        if small {
            let mut acc = 0u64;
            for i in lo..=hi {
                acc += a[i] * b[k - i];
            }
            r.push(fin(acc as u128));
            continue;
        }
        r.push(fin(dot_core(&a[lo..=hi], &b[k - hi..=k - lo], red, cap)));
    }
    r
}

/// Square with lazy accumulation (p < 2^62), each cross product formed once: coefficient k is
/// 2 sum_{i < k - i} a_i a_(k-i) (+ a_(k/2)^2), summed in a u64 when that cannot overflow,
/// otherwise by `dot_core` with half its cap (so that doubling the sum and adding the square
/// term stays below 2^128); `fin` maps the unreduced sum to the output representation.
pub fn lazy_sq(a: &[u64], red: &Red128, fin: impl Fn(u128) -> u64) -> Vec<u64> {
    let n = a.len();
    if n == 0 {
        return vec![];
    }
    let p = red.p;
    let small = fits_u64(p, n + 1);
    let cap = lazy_cap(p);
    let mut r = Vec::with_capacity(2 * n - 1);
    let mut k = 0;
    if !small && n >= 16 {
        // four outputs at a time
        let range = |k: usize| (k.saturating_sub(n - 1), k.div_ceil(2));
        // room to double the sum and add the square term
        let pm = (p - 1) as u128;
        let plan = red.lazy_plan((u128::MAX - pm * pm) / 2);
        while k + 4 < 2 * n {
            let rs: [(usize, usize); 4] = std::array::from_fn(|r| range(k + r));
            let s = conv_block4(a, a, k, rs.map(|x| x.0), rs.map(|x| x.1), red, plan);
            for (j, &v) in s.iter().enumerate() {
                let sq = if (k + j) % 2 == 0 { a[(k + j) / 2] } else { 0 };
                r.push(fin(2 * v + sq as u128 * sq as u128));
            }
            k += 4;
        }
    }
    for k in k..2 * n - 1 {
        let lo = k.saturating_sub(n - 1);
        let hi = k.div_ceil(2); // i < k - i
        let sq = if k % 2 == 0 { a[k / 2] } else { 0 };
        if small {
            let mut acc = 0u64;
            for i in lo..hi {
                acc += a[i] * a[k - i];
            }
            r.push(fin((2 * acc + sq * sq) as u128));
            continue;
        }
        // half the cap: the doubled sum plus the square term must still fit a u128
        let s = if lo < hi {
            dot_core(&a[lo..hi], &a[k + 1 - hi..=k - lo], red, (cap / 2).max(1))
        } else {
            0
        };
        r.push(fin(2 * s + sq as u128 * sq as u128));
    }
    r
}

/// F_{p^2} = F_p[i]/(i^2 - nr), nr a non-residue.
#[derive(Clone, Copy, Debug)]
pub struct Zp2 {
    pub base: Zp,
    pub nr: u64,
}

impl Zp2 {
    pub fn new(p: u64) -> Self {
        let base = Zp::new(p);
        let mut nr = p - 1;
        if base.legendre(nr) != -1 {
            nr = 2;
            while base.legendre(nr) != -1 {
                nr += 1;
            }
        }
        Zp2 { base, nr }
    }
    pub fn embed(&self, a: u64) -> (u64, u64) {
        (a, 0)
    }
}

impl Field for Zp2 {
    type E = (u64, u64);
    fn zero(&self) -> Self::E {
        (0, 0)
    }
    fn one(&self) -> Self::E {
        (1, 0)
    }
    fn add(&self, a: Self::E, b: Self::E) -> Self::E {
        (self.base.add(a.0, b.0), self.base.add(a.1, b.1))
    }
    fn sub(&self, a: Self::E, b: Self::E) -> Self::E {
        (self.base.sub(a.0, b.0), self.base.sub(a.1, b.1))
    }
    fn neg(&self, a: Self::E) -> Self::E {
        (self.base.neg(a.0), self.base.neg(a.1))
    }
    fn mul(&self, a: Self::E, b: Self::E) -> Self::E {
        let f = &self.base;
        let t0 = f.mul(a.0, b.0);
        let t1 = f.mul(a.1, b.1);
        let c0 = f.add(t0, f.mul(self.nr, t1));
        let c1 = f.add(f.mul(a.0, b.1), f.mul(a.1, b.0));
        (c0, c1)
    }
    fn inv(&self, a: Self::E) -> Self::E {
        let f = &self.base;
        let n = f.sub(f.mul(a.0, a.0), f.mul(self.nr, f.mul(a.1, a.1)));
        let ni = f.inv(n);
        (f.mul(a.0, ni), f.neg(f.mul(a.1, ni)))
    }
    fn from_u64(&self, n: u64) -> Self::E {
        (n % self.base.p, 0)
    }
    fn char(&self) -> u64 {
        self.base.p
    }
    fn size(&self) -> u128 {
        (self.base.p as u128) * (self.base.p as u128)
    }
    fn random(&self, rng: &mut Rng) -> Self::E {
        (rng.below(self.base.p), rng.below(self.base.p))
    }
}

/// Deterministic Miller-Rabin for u64.
pub fn is_prime(n: u64) -> bool {
    if n < 2 {
        return false;
    }
    for &q in &[2u64, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37] {
        if n.is_multiple_of(q) {
            return n == q;
        }
    }
    let mut d = n - 1;
    let mut s = 0;
    while d.is_multiple_of(2) {
        d /= 2;
        s += 1;
    }
    let mulm = |a: u64, b: u64| ((a as u128 * b as u128) % n as u128) as u64;
    'w: for &a in &[2u64, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37] {
        let mut x = 1u64;
        let mut b = a % n;
        let mut e = d;
        while e > 0 {
            if e & 1 == 1 {
                x = mulm(x, b);
            }
            b = mulm(b, b);
            e >>= 1;
        }
        if x == 1 || x == n - 1 {
            continue;
        }
        for _ in 0..s - 1 {
            x = mulm(x, x);
            if x == n - 1 {
                continue 'w;
            }
        }
        return false;
    }
    true
}

pub fn next_prime(mut n: u64) -> u64 {
    if n.is_multiple_of(2) {
        n += 1;
    }
    while !is_prime(n) {
        n += 2;
    }
    n
}

/// Prime factorisation of n < 2^64 (trial division to 1000, then Pollard-Brent rho), as
/// (prime, exponent) pairs in increasing order.
pub fn factor_u64(n: u64) -> Vec<(u64, u32)> {
    fn mulmod(a: u64, b: u64, m: u64) -> u64 {
        (a as u128 * b as u128 % m as u128) as u64
    }
    fn is_prime64(n: u64) -> bool {
        if n < 2 {
            return false;
        }
        for p in [2u64, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37] {
            if n.is_multiple_of(p) {
                return n == p;
            }
        }
        let (mut d, mut s) = (n - 1, 0);
        while d % 2 == 0 {
            d /= 2;
            s += 1;
        }
        'outer: for a in [2u64, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37] {
            let mut x = 1u64;
            let (mut b, mut e) = (a % n, d);
            while e > 0 {
                if e & 1 == 1 {
                    x = mulmod(x, b, n);
                }
                b = mulmod(b, b, n);
                e >>= 1;
            }
            if x == 1 || x == n - 1 {
                continue;
            }
            for _ in 1..s {
                x = mulmod(x, x, n);
                if x == n - 1 {
                    continue 'outer;
                }
            }
            return false;
        }
        true
    }
    fn gcd(mut a: u64, mut b: u64) -> u64 {
        while b != 0 {
            let t = a % b;
            a = b;
            b = t;
        }
        a
    }
    fn rho(n: u64) -> u64 {
        if n.is_multiple_of(2) {
            return 2;
        }
        let mut c = 1u64;
        loop {
            let f = |x: u64| (mulmod(x, x, n) + c) % n;
            let (mut y, mut r, mut q, mut g) = (2u64, 1u64, 1u64, 1u64);
            let (mut x, mut ys) = (0u64, 0u64);
            while g == 1 {
                x = y;
                for _ in 0..r {
                    y = f(y);
                }
                let mut k = 0;
                while k < r && g == 1 {
                    ys = y;
                    for _ in 0..(128.min(r - k)) {
                        y = f(y);
                        q = mulmod(q, x.abs_diff(y), n);
                    }
                    g = gcd(q, n);
                    k += 128;
                }
                r *= 2;
            }
            if g == n {
                loop {
                    ys = f(ys);
                    g = gcd(x.abs_diff(ys), n);
                    if g > 1 {
                        break;
                    }
                }
            }
            if g != n {
                return g;
            }
            c += 1;
        }
    }
    fn rec(n: u64, out: &mut Vec<u64>) {
        if n == 1 {
            return;
        }
        if is_prime64(n) {
            out.push(n);
            return;
        }
        let d = rho(n);
        rec(d, out);
        rec(n / d, out);
    }
    let mut n = n;
    let mut ps = vec![];
    for p in 2..1000u64 {
        while n.is_multiple_of(p) {
            ps.push(p);
            n /= p;
        }
    }
    rec(n, &mut ps);
    ps.sort();
    let mut out: Vec<(u64, u32)> = vec![];
    for p in ps {
        match out.last_mut() {
            Some((q, e)) if *q == p => *e += 1,
            _ => out.push((p, 1)),
        }
    }
    out
}
