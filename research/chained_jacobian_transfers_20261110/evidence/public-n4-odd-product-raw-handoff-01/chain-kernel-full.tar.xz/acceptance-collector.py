"""Compare entire original outputs and unchanged canonical proof bindings."""
from pathlib import Path
import importlib.util,json,lzma,re,shutil,subprocess,sys
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target'
o=Path('/workspace/scratch/ct61-chain-kernel-full-01');d=s/'evidence/chain-kernel-independent-full-01';d.mkdir()
source='a7ea5998b4482c99469185119d1acbc5b60921a4'
for p in [o/'native.exit',o/'guard.exit',o/'driver/original.exit',o/'driver/guard.exit',o/'driver/cleanliness.exit']:assert p.read_text().strip()=='0'
assert json.loads((o/'guards.json').read_text())==dict(count=617,changed=[])
phases=[line.split()for line in(o/'driver/phase-index.txt').read_text().splitlines()];assert len(phases)==10
for name,wanted,actual in phases:assert wanted==actual=='0'and(o/'driver'/(name+'.pipe-exits')).read_text().split()==['0','0']
rows=[];log=(o/'driver/kernels.log').read_text();assert '1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in log
for line in log.splitlines():
    m=re.search(r'\b(N4_CHAIN_[A-Z0-9_]+) (\{.*\})$',line)
    if m:rows.append(dict(kind=m[1],data=json.loads(m[2])))
canonical=lambda xs:sorted(json.dumps(x,sort_keys=True,separators=(',',':'))for x in xs)
assert len(rows)==4 and canonical(rows)==canonical(json.loads(lzma.decompress((s/'ci_chain/expected-kernels.json.xz').read_bytes())))
(d/'whole-native.json.xz').write_bytes(lzma.compress(json.dumps(rows,indent=2).encode()+b'\n'))
(o/'all-native-records.json').write_text(json.dumps(rows,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py');pcc=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pcc;spec.loader.exec_module(pcc)
verdicts=[]
for b in json.loads((s/'evidence/chain-kernel-bindings-01/claims.json').read_text()):
    v=json.loads((o/'driver'/('binding-'+Path(b['claim_path']).stem+'.log')).read_text())
    c=json.loads((r/b['claim_path']).read_text());assert v['verdict']=='pass'and not v['reasons']and v['commit']==source and v['claim_sha256']==pcc.claim_digest(c)
    verdicts.append(v)
assert len(verdicts)==3
for p in [o/'guards.json',o/'plan.json',o/'original-command.sh',o/'admission/results.json',o/'admission/restoration.json']:shutil.copyfile(p,d/p.name)
(d/'exact-local-verdicts.json').write_text(json.dumps(verdicts,indent=2)+'\n')
(d/'observation.json').write_text(json.dumps(dict(source=source,producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2',all617_outer_guards_unchanged=True,
    portable_inputs=616,phase_pairs='ten ordered positive native/tee0/0',one_unfiltered_test=True,
    whole_JSON='ALL4 exactly equal/no exclusions',both_original_proof_gates='three declarations/zero trusted',
    all3_original_canonical_PCC_digests_match=True,four_actual_admission='2/nooutput/restored',
    original_HEAD_cleanliness_guards='0',fresh_physical_Git_siblings_and_outside_cache=True,
    CI='nine workflows pending separate terminal audit; no CI claim here',scope='correctness; unsigned; geometric bridges partial; no computational advantage'),indent=2)+'\n')
shutil.copyfile(__file__,o/'acceptance-collector.py')
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Independent chain-kernel full01 exacta7ea5998/3d passes all ten ordered native+tee0/0,one unfiltered native test/ALL4 whole JSON exact/no exclusions,both unchanged original3-declaration gates/zero trusted/three exact canonical PCC bindings. All617 outer/616 portable+self/HEAD/cleanliness guards0;four actual admission controls reject2/nooutput/restored. Fresh physical Git siblings/outside cold cache; whole capture retained. All135 intersections/9x9 table/128 actual repeated routes reproduce29830a. Own nine-workflow CI audit remains pending. Unsigned/actual geometry partial/no computational advantage/global-root or signed-execution claim.']
for p in sorted(d.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(r))]
print(subprocess.check_output(cmd,cwd=r,text=True).strip())
