"""I/O retention of actual five-object migration; no scientific verifier."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,lzma,subprocess,shutil
r=Path('/workspace/crypto');s=r/'research/chained_jacobian_transfers_20261110'
raw=Path('/workspace/scratch/ct55-g3-primary-publication-raw-01')
base='beb9db2a8a632c3b7fc360a7b18bb64dee2677b7';bot='006db8eccae560812d12f84983432b317ca36d9a'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==bot
assert subprocess.check_output(['git','rev-parse',bot+'^'],cwd=r,text=True).strip()==base
log=(raw/'whole-job.log').read_bytes()
assert log==json.loads((raw/'log-api.json').read_text())['structuredContent']['content'].encode()
assert log.index(b'2 remote objects replayed')<log.index(b'[detached HEAD 006db8ecc]')
jobs=json.loads((raw/'jobs-api.json').read_text())['structuredContent']['jobs']
assert len(jobs)==1 and jobs[0]['id']==131818908219 and jobs[0]['run_id']==43405549514 and jobs[0]['conclusion']=='success'
ff=Path('/workspace/scratch/ct56-primary-artifact-ff-01')
assert all((ff/(p+'.exit')).read_text().strip()=='0' for p in ['fetch','exact-ff','artifact','wiring'])
for source,name in [(ff,'exact-ff'),(Path('/workspace/scratch/ct56-root-primary-publication-01'),'normal-publication'),(Path('/workspace/scratch/ct56-primary-publication-discovery-01'),'source-discovery')]:
    shutil.copytree(source,raw/name)
shutil.copyfile(__file__,raw/'original-recorder.py')
objects=[]
panels={'genus3-norm-full-publication-raw-01':['whole-raw.tar.xz'],'g3-norm-destination-primary-handoff-01':['whole-primary.tar.xz']}
for name,files in panels.items():
    p=s/'evidence'/name/'.artifacts.json'
    shutil.copyfile(p,raw/(name+'-canonical-manifest.json'))
    manifest=json.loads(p.read_text())['files']
    assert set(manifest)==set(files)
    for file,entry in manifest.items():
        path=str((p.parent/file).relative_to(r))
        original=subprocess.check_output(['git','show',base+':'+path],cwd=r)
        assert len(original)==entry['bytes'] and hashlib.sha256(original).hexdigest()==entry['sha256']
        objects.append(dict(path=path,**entry))
assert len(objects)==2
data=dict(at=datetime.now(timezone.utc).isoformat(),run=43405549514,job=131818908219,conclusion='success',source=base,bot=bot,exact_bot_parent=base,exact_changed_paths=6,actual_remote_objects_replayed_BEFORE_bot=2,objects=objects,exact_local_FF=0,artifact_check=0,wiring_check=0,all_owned_dirty_bytes_and2175_current_union_inputs_preserved=True,old2132_unchanged_and_wholeold6prefix_retained=True,failed_stale_guard_FF01_preserved=True,whole_log_bytes=len(log),whole_log_sha256=hashlib.sha256(log).hexdigest(),standing='unsigned actual publication; separate from scientific/benchmark/main merge standing')
(raw/'publication.json').write_text(json.dumps(data,indent=2)+'\n')
subprocess.run(['python3','/workspace/scratch/ct55_pack_closed_tree.py','primary-publication-raw-01'],cwd=r,check=True)
out=s/'evidence/genus3-primary-publication-raw-01'
shutil.copyfile(raw/'publication.json',out/'publication.json')
z=lzma.compress(log,format=lzma.FORMAT_XZ,preset=9);assert lzma.decompress(z)==log
(out/'whole-job.log.xz').write_bytes(z)
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Unsigned ACTUALprimarysource andcollector publication:trusted-base43405549514/job131818908219SUCCESS TWOremoteobjectsreplayed BEFOREcanonical006db8ecc/directparentbeb9db2/EXACT6paths. Wholepublicationcollector67516 andWHOLEprimarysourcearchive69520 matchoriginalsourceGitblobs/custody/manifests;exactlocalFF/artifact/wiring0/all2175then-currentnativeguardspreserved BEFORElater451bc2/5327f4PCCreadonlypathdelta. Everywholejob/API/stdXZ/memberrawarchivehash/roundtrip retained. GENUINEconsumerentry andexactbothgate/sign dataread keepb992subjectbytes;no verifier/trust/policy orscientificsignature. FutureFFusesNEWcurrentPCCcontrolguardversion,not staleoldmap.']
for name in ['custody.json','publication.json','whole-job.log.xz']:
    cmd+=['--proof','attestation:'+str((out/name).relative_to(r))]
cl=subprocess.check_output(cmd,cwd=r,text=True).strip()
Path('/workspace/scratch/ct56-primary-actual-publication.claim').write_text(cl+'\n')
print(cl,len(log),len(z),flush=True)
