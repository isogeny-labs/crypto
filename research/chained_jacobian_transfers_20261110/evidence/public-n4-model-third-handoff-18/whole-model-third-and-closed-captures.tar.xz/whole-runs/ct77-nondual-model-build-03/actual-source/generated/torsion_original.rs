use chained_n4_completed_v2::NormV2;
use chained_n4_odd_product_models::{er, three, GluingModel, SourceE};
use chained_n4_odd_source::OddSourceIsogeny;
use chained_n4_public_target::CheckedInstance;
use chained_original_smith_engine::original;
use isogeny_algos::{
    curve::{Curve, Isogeny, Pt},
    field::{Field, Rng},
    fpr::{FpR, ER},
    kernel::kohel::kohel,
    poly,
};
use serde_json::{json, Value};
use std::collections::{BTreeMap, BTreeSet};

fn vs(s: u64) -> Vec<u8> {
    (0..64).filter(|&i| s & (1u64 << i) != 0).collect()
}
fn bits(v: &[u8]) -> u64 {
    v.iter().fold(0, |s, &v| s | (1u64 << v))
}
fn pairing(a: u8, b: u8) -> u32 {
    ((((a & 0x15) << 1) | ((a & 0x2a) >> 1)) & b).count_ones() & 1
}
fn frob(x: u8) -> u8 {
    ((x << 2) & 63) | (x >> 4)
}
fn span(g: [u8; 3]) -> u64 {
    bits(
        &(0..8)
            .map(|v| {
                g.iter().enumerate().fold(0, |out, (i, &b)| {
                    out ^ if v & (1 << i) != 0 { b } else { 0 }
                })
            })
            .collect::<Vec<_>>(),
    )
}
fn rank(v: &[u8]) -> u32 {
    let mut basis = [0u8; 6];
    let mut r = 0;
    for &x in v {
        let mut x = x;
        for bit in (0..6).rev() {
            if x & (1 << bit) != 0 {
                if basis[bit] != 0 {
                    x ^= basis[bit];
                } else {
                    basis[bit] = x;
                    r += 1;
                    break;
                }
            }
        }
    }
    r
}
fn dimension(s: u64) -> u32 {
    let v = vs(s);
    assert!(v.contains(&0));
    assert!(v.len().is_power_of_two());
    for &a in &v {
        for &b in &v {
            assert!(v.contains(&(a ^ b)));
            assert_eq!(pairing(a, b), 0);
        }
    }
    let d = (v.len() as u32).trailing_zeros();
    assert_eq!(d, rank(&v));
    d
}
fn original_all() -> BTreeSet<u64> {
    let basis = [3u8, 5, 15, 23, 63, 95];
    let mask = |v: u8| {
        basis
            .iter()
            .enumerate()
            .fold(0, |a, (i, &b)| a ^ if v & (1 << i) != 0 { b } else { 0 })
    };
    let mut inverse = [255; 128];
    for v in 0..64 {
        assert_eq!(inverse[mask(v) as usize], 255);
        inverse[mask(v) as usize] = v;
    }
    for a in 0..64 {
        for b in 0..64 {
            assert_eq!(pairing(a, b), (mask(a) & mask(b)).count_ones() & 1);
        }
    }
    let out: BTreeSet<_> = original::lagrangians()
        .iter()
        .map(|(v, _)| {
            let mut row = v
                .iter()
                .map(|&x| {
                    let y = inverse[x as usize];
                    assert!(y < 64);
                    y
                })
                .collect::<Vec<_>>();
            row.push(0);
            let s = bits(&row);
            assert_eq!(dimension(s), 3);
            s
        })
        .collect();
    assert_eq!(out.len(), 135);
    out
}
fn fp(f: &FpR, mut x: ER, power: usize) -> ER {
    for _ in 0..power {
        x = f.frobenius(x);
    }
    x
}
fn pp(f: &FpR, p: Pt<ER>, power: usize) -> Pt<ER> {
    match p {
        Pt::Inf => Pt::Inf,
        Pt::Aff(x, y) => Pt::Aff(fp(f, x, power), fp(f, y, power)),
    }
}
fn point(p: Pt<ER>) -> Value {
    match p {
        Pt::Inf => Value::Null,
        Pt::Aff(x, y) => json!([three(x), three(y)]),
    }
}
fn torsion(f: &FpR, e: &Curve<ER>) -> Vec<Pt<ER>> {
    let mut roots = poly::roots(f, &vec![e.b, e.a, f.zero(), f.one()], &mut Rng::new(0x6611));
    roots.sort();
    roots.dedup();
    assert_eq!(roots.len(), 3);
    std::iter::once(Pt::Inf)
        .chain(roots.into_iter().map(|x| Pt::Aff(x, f.zero())))
        .collect()
}

include!("../src/torsion_append.rs");
