"""Reclaim only closed derived libraries outside the complete publication17 guard."""
from pathlib import Path
import hashlib,json,lzma,subprocess
s=Path('/workspace/scratch')
root=s/'ct54-fp-chain-cli-01-build-cache'
held=json.loads(lzma.decompress((s/'ct76-whole-census-and-nondual-handoff-17/whole-current-inputs.json.xz').read_bytes()))
processes=subprocess.check_output(['ps','-eo','pid,ppid,stat,comm'],text=True)
assert not any(len(fields:=line.split())==4 and fields[3] in ['cargo','rustc'] and not fields[2].startswith('Z') for line in processes.splitlines())
(s/'ct77-closed-cli-dependency-processes-02.txt').write_text(processes)
files=[p for p in sorted(root.rglob('*'))if p.is_file()and p.suffix in ['.rlib','.rmeta','.o']]
assert files and all(str(p)not in held and str(p.resolve())not in held for p in files)
rows=[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in files]
receipt=s/'ct77-closed-cli-dependency-cleanup-02.json.xz'
assert not receipt.exists()
receipt.write_bytes(lzma.compress((json.dumps(dict(scope='closed external .rlib/.rmeta/.o only; all actual executable/source/raw/guard17 paths, current ct57 cache, sealed B cache and historical root executable untouched',root=str(root),outside_all24445_guard17_paths=True,no_active_cargo_or_rustc=True,whole_files=rows),indent=2)+'\n').encode()))
for p in files:p.unlink()
print('reclaimed',sum(x['bytes']for x in rows),'derived bytes;',len(rows),'whole hashes retained at',receipt)
