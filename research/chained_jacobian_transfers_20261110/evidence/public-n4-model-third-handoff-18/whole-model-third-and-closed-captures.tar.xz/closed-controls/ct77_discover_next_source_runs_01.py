"""Read-only all-event discovery; connector omits pull_request_target runs."""
from pathlib import Path
from datetime import datetime,timezone
import urllib.request,os,json
p=Path('/workspace/scratch/ct77-next-source-run-discovery-01');p.mkdir(exist_ok=True)
source='f0167e430befd4304b170689e8caebcbdabbc6ad'
url='https://api.github.com/repos/isogeny-labs/cryptanalysis/actions/runs?head_sha='+source+'&per_page=100'
req=urllib.request.Request(url,headers={'Authorization':'Bearer '+os.environ['GH_TOKEN'],'Accept':'application/vnd.github+json'})
with urllib.request.urlopen(req,timeout=45)as response:raw=response.read()
data=json.loads(raw);stamp=datetime.now(timezone.utc).strftime('%H%M%S');(p/('all-event-runs-'+stamp+'.json')).write_bytes(raw)
(p/('request-'+stamp+'.json')).write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),method='GET',url=url,credentials='GH_TOKEN in memory only; not retained'),indent=2)+'\n')
(p/'original-discovery.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(dict(total_count=data['total_count'],runs=[dict(id=x['id'],name=x['name'],event=x['event'],status=x['status'],conclusion=x['conclusion'],head_sha=x['head_sha'])for x in data['workflow_runs']])))
