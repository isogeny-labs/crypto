"""Whole CI byte collection and original PCC digest bookkeeping, no new verifier."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,re,shutil,sys,subprocess,lzma
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';o=Path('/workspace/scratch/ct58-public-ci-01')
source='68d22cee01126c9a03a2222687b0faf62113489d'
for label,run,job,status,sha in [('failed01',43430590436,131902790292,'failure','f5d6c92a4eb53fc838ab8bf2665887e12522cbd9'),('success02',43432174569,131908108813,'success',source)]:
    api=json.loads((o/(label+'-jobs-api.json')).read_text());jobs=api['structuredContent']['jobs'];assert len(jobs)==1
    assert (jobs[0]['run_id'],jobs[0]['id'],jobs[0]['status'],jobs[0]['conclusion'])==(run,job,'completed',status)
    log=json.loads((o/(label+'-log-api.json')).read_text())['structuredContent']['content'];(o/(label+'-whole-job.log')).write_text(log)
    assert sha in log
    if status=='success':
        assert 'All 43 phase pairs match expected native/tee exits;14 native exit2 controls intentional.' in log
        assert 'Public-target N4 replay complete:' in log
    else:assert 'FAIL_build' in log
log=(o/'success02-whole-job.log').read_text()
records=[];verdicts=[]
for line in log.splitlines():
    m=re.search(r'\b(N4_PUBLIC_[A-Z_]+) (\{.*\})$',line)
    if m:records.append(dict(kind=m[1],data=json.loads(m[2])))
    if '{"claim_id":' in line:
        v=json.loads(line[line.index('{"claim_id":'):]);assert v['schema']=='pcc.verdict/v1';verdicts.append(v)
assert len(records)==13 and len(verdicts)==14
expected=json.loads((s/'evidence/unit-acceptance-01/all-native-records.json').read_text())
def canonical(rows):return sorted(json.dumps(x,sort_keys=True,separators=(',',':')) for x in rows)
def without_only_native_timing(rows):
    rows=json.loads(json.dumps(rows))
    for row in rows:
        if row['kind']=='N4_PUBLIC_ATTEMPT':
            for phase in row['data']['public']['phases']:del phase['wall']
            row['data']['public']['stats']=[x for x in row['data']['public']['stats'] if x[0]!='wall_total']
    return rows
# Raw complete records remain present even if hardware-dependent timings differ.
same_nontiming=canonical(without_only_native_timing(records))==canonical(without_only_native_timing(expected))
for row in records:
    if row['kind']=='N4_PUBLIC_ATTEMPT':
        d=row['data'];a=d['legacy'];b=d['public'];assert (a['ok'],a['fail'],a['k_found'])==(b['ok'],b['fail'],b['k_found'])
        if b['ok']:assert d['independent_public_check'] and a['independent_check']
assert sum(x['kind']=='N4_PUBLIC_ATTEMPT' and x['data']['public']['ok'] for x in records)==5
assert next(x['data'] for x in records if x['kind']=='N4_PUBLIC_IDENTITY')==json.loads((s/'fixtures/identity.json').read_text())
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py');pcc=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pcc;spec.loader.exec_module(pcc)
claims=[]
for folder in ['lean-bindings-01','origin-lean-bindings-01']:claims+=json.loads((s/'evidence'/folder/'claims.json').read_text())
digest={}
for row in claims:
    claim=json.loads((r/row['claim_path']).read_text());digest[claim['id']]=dict(original_canonical_claim_digest=pcc.claim_digest(claim),raw_file_sha256=hashlib.sha256((r/row['claim_path']).read_bytes()).hexdigest())
assert len(digest)==14 and set(digest)=={v['claim_id'] for v in verdicts}
for v in verdicts:
    assert v['verdict']=='pass' and v['commit']==source and not v['reasons'] and v['claim_sha256']==digest[v['claim_id']]['original_canonical_claim_digest']
for name,value in [('native-records.json',records),('exact-PCC-verdicts.json',verdicts),('original-PCC-digests.json',digest)]:
    (o/name).write_text(json.dumps(value,indent=2)+'\n')
shutil.copytree(Path('/workspace/scratch/ct58-public-full-02/driver/source'),o/'source')
p=o/'source/cryptanalysis/experiments/chained-transfer-public-target/reference-02.sha256';shutil.copyfile('/workspace/scratch/ct58-public-full-02/original-reference.sha256',p)
assert len([p for p in (o/'source').rglob('*') if p.is_file()])==435
shutil.copyfile(__file__,o/'original-collector.py')
meta=dict(at=datetime.now(timezone.utc).isoformat(),source=source,run=43432174569,job=131908108813,conclusion='success',prior_failed_run=43430590436,prior_failed_job=131902790292,whole_UTF8_logs=2,all435_actual_source_snapshots=True,all13_native_records=True,all_non_timing_native_records_equal_original_unit=same_nontiming,ONLY_comparison_omissions=['public.phases[].wall','public.stats[wall_total]'],all14_original_canonical_PCC_digests_match=True,all14_local_CI_verdicts='pass/unsigned',source_head_exact=True,artifact_ZIP_downloaded=False,artifact_scope='whole decoded logs/API retained;uploaded artifact referenced in job,standalone raw exitfiles not downloaded;prior storageproxy403 not retried',CI_guard_scope='complete original driver marker plus successful step;local full02 has actual434portable+manifest435guards andall43native/tee statuses',no_signed_execution_or_performance_claim=True)
(o/'plan.json').write_text(json.dumps(meta,indent=2)+'\n')
d=s/'evidence/independent-CI-02';d.mkdir()
(d/'observation.json').write_text(json.dumps(meta,indent=2)+'\n')
for name in ['native-records.json','exact-PCC-verdicts.json','original-PCC-digests.json']:
    shutil.copyfile(o/name,d/name)
for label in ['failed01','success02']:
    raw=(o/(label+'-whole-job.log')).read_bytes();z=lzma.compress(raw);assert lzma.decompress(z)==raw;(d/(label+'-whole-job.log.xz')).write_bytes(z)
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','P1 ownCI exact68d run43432174569/job131908108813SUCCESS;original43phase marker/all3native/fiveIC14controls/both9+5originalproofgates/14exactPCCverdicts pass. All original canonical claim digests and source68d match;all13native records retained,non-timing whole equality='+str(same_nontiming)+',ONLYwall+wall_totalexcluded from comparison/raw intact. Whole priorfailed01 andsuccess02UTF8logs/API+435sources retained. No artifactZIP/standalone CIexitfiles downloaded;successfulstep/driver marker guard scope explicit. Local full02actual435guards/all43pairs0orintentional2 separatelyaccepted. Unsigned execution/correctness,not speedup.']
for p in sorted(d.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(r))]
print(subprocess.check_output(cmd,cwd=r,text=True).strip(),same_nontiming,flush=True)
