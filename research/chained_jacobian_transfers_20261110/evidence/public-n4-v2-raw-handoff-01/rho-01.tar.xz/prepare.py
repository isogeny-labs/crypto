"""Source/command custody; actual crypto runs only in the original Rust engines."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,shutil,subprocess
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';n=s/'rho-accessor'
out=Path('/workspace/scratch/ct58-rho-unit-cli-01');out.mkdir();(out/'processes').mkdir();(out/'outputs').mkdir()
pins=json.loads((n/'derived/source-pins.json').read_text());raw=(r/pins['original_path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==pins['original_sha256']
t=raw.decode()
for a,b in pins['literal_substitutions']:assert t.count(a)==1;t=t.replace(a,b)
assert t==(n/'derived/public_solver_with_answer.rs').read_text()
before=json.loads(Path('/workspace/crypto/research/chained_jacobian_transfers_20261110/evidence/public-n4-pcc-data-current-guard-02/current-inputs.json').read_text())
assert len(before)==2191
for p in n.rglob('*'):
    if p.is_file():before[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
for p in [s/'fixtures/public-five.json',s/'fixtures/expected-OUTSIDE-input.json',s/'fixtures/negative/unknown-scalar.json',s/'fixtures/negative/unknown-witness.json']:
    before[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
for name in before:
    p=Path(name);dest=out/'source'/p.relative_to('/workspace');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
(out/'before.json').write_text(json.dumps(before,indent=2)+'\n');shutil.copyfile(__file__,out/'prepare.py')
shutil.copyfile(s/'evidence/rho-accessor-plan-01/plan.json',out/'prospective-plan.json')
manifest='experiments/chained-transfer-public-target/rho-accessor/Cargo.toml'
script='''#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct57-n4-unit-01-build-cache
cd /workspace/cryptanalysis
out=/workspace/scratch/ct58-rho-unit-cli-01
manifest=MANIFEST
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"+rustc -Vv > "$out/rustc.txt" 2>&1
timeout 900 cargo test --release --offline --locked --manifest-path "$manifest" --lib --no-run > "$out/compile.log" 2>&1
build=$?
printf '%s\\n' "$build" > "$out/compile.exit"
if [ "$build" -eq 0 ]; then
  (ulimit -v 2097152; timeout 900 cargo test --release --offline --locked --manifest-path "$manifest" --lib -- --nocapture --test-threads=1) > "$out/native.log" 2>&1
  status=$?
else
  status=$build
  cp "$out/compile.log" "$out/native.log"
fi
printf '%s\\n' "$status" > "$out/native.exit"
if [ "$status" -eq 0 ]; then
  timeout 900 cargo build --release --offline --locked --manifest-path "$manifest" > "$out/build-cli.log" 2>&1
  cli=$?
  printf '%s\\n' "$cli" > "$out/build-cli.exit"
  if [ "$cli" -eq 0 ]; then
    bin="$CARGO_TARGET_DIR/release/chained-n4-rho-accessor"
    sha256sum "$bin" > "$out/binary.sha256"
    run_case() {
      local name="$1"; shift
      (ulimit -v 2097152; timeout 900 "$bin" "$@") > "$out/processes/$name.stdout" 2> "$out/processes/$name.stderr"
      printf '%s\\n' "$?" > "$out/processes/$name.exit"
    }
    run_case public-five solve experiments/chained-transfer-public-target/fixtures/public-five.json "$out/outputs/public-five.json"
    for label in unknown-scalar unknown-witness; do
      run_case "$label" solve "experiments/chained-transfer-public-target/fixtures/negative/$label.json" "$out/outputs/$label.json"
    done
  fi
fi
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARD'
from pathlib import Path
import hashlib,json,sys
o=Path(sys.argv[1]);before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before};changed=[p for p in before if before[p]!=after[p]]
(o/'after.json').write_text(json.dumps(after,indent=2)+'\\n');(o/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\\n');raise SystemExit(bool(changed))
GUARD
guard=$?
printf '%s\\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
'''.replace('MANIFEST',manifest).replace('"$out/start.txt"\\+rustc','"$out/start.txt"\nrustc')
assert '\\+' not in script
launcher=Path(str(out)+'.sh');launcher.write_text(script);shutil.copyfile(launcher,out/'original-command.sh')
(out/'plan.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),guards=len(before),source='f5d6 plus outputaccessor4db027',original_source_unchanged=True,cache='completed P1 unit outside cache;not cold',scope='bounded development correctness only',launcher=str(launcher)),indent=2)+'\n')
print(str(launcher),len(before),flush=True)
