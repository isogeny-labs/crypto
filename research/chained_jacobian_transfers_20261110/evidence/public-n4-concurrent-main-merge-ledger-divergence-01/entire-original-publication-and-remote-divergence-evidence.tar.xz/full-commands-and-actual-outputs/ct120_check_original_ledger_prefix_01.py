"""Call the unchanged PCC ledger routines on complete immutable ledger bytes."""
from pathlib import Path
import importlib.util, json, sys

repo = Path('/workspace/crypto')
out = Path('/workspace/scratch/ct120-concurrent-root-merge-01')
spec = importlib.util.spec_from_file_location('original_pcc_ledger', repo / 'tools/pcc/pcc.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
base = module.read_ledger_text((out / 'base-ledger.whole').read_text())
remote = module.read_ledger_text((out / 'remote-ledger.whole').read_text())
errors = []
module.check_prefix(base, remote, errors)
assert errors
(out / 'unchanged-original-prefix-check.json').write_text(json.dumps(dict(original_tool='tools/pcc/pcc.py', base='2d46258afc20188b8593b3a0693183d1282e0aaf', remote='223e86969dd89a382a90b188a5ce5e1d50b57823', entire_original_ledger_prefix_rejection=True, errors=errors, scope='unsigned direct unchanged PCC prefix routine on full immutable ledgers; not a repair or signed verdict'), indent=2)+'\n')
print(json.dumps(errors))
