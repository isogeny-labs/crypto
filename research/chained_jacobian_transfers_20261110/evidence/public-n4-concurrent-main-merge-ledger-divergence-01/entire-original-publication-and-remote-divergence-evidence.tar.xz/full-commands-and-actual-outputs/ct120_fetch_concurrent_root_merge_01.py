"""Fetch immutable remote history in RAM without moving local refs or science."""
from pathlib import Path
from datetime import datetime, timezone
import base64, hashlib, json, os, subprocess

repo = Path('/workspace/crypto')
out = Path('/workspace/scratch/ct120-concurrent-root-merge-01')
out.mkdir()
objects = Path('/dev/shm/ct120-concurrent-root-merge-objects-01')
objects.mkdir()
remote = '223e86969dd89a382a90b188a5ce5e1d50b57823'
local = '1487e3a55efaacf899ab2553af7ff8fbccae22f6'
base = '2d46258afc20188b8593b3a0693183d1282e0aaf'
plain = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0')
def run(*args, env=plain):
    return subprocess.check_output(['git', *args], cwd=repo, env=env)
before = {name: run(*args) for name, args in [('HEAD', ['rev-parse', 'HEAD']), ('refs', ['show-ref']), ('status', ['status', '--porcelain'])]}
assert before['HEAD'].decode().strip() == local and not before['status']
for name, data in before.items():
    (out / ('before-' + name + '.txt')).write_bytes(data)
(out / 'whole-before-ledger.jsonl').write_bytes((repo / 'pcc/ledger.jsonl').read_bytes())
env = dict(plain, GIT_OBJECT_DIRECTORY=str(objects), GIT_ALTERNATE_OBJECT_DIRECTORIES=str(repo / '.git/objects'))
count = int(env.get('GIT_CONFIG_COUNT', '0'))
env.update({'GIT_CONFIG_COUNT': str(count+1), 'GIT_CONFIG_KEY_' + str(count): 'http.https://github.com/.extraheader', 'GIT_CONFIG_VALUE_' + str(count): 'AUTHORIZATION: basic ' + base64.b64encode(('x-access-token:' + env['GH_TOKEN']).encode()).decode()})
command = ['git', '-c', 'fetch.unpackLimit=0', '-c', 'transfer.unpackLimit=0', 'fetch', '--filter=blob:none', '--no-write-fetch-head', '--no-tags', '--no-recurse-submodules', 'https://github.com/isogeny-labs/crypto.git', remote]
start = datetime.now(timezone.utc).isoformat()
result = subprocess.run(command, cwd=repo, env=env, capture_output=True, timeout=300)
(out / 'fetch.txt').write_bytes(result.stdout+result.stderr)
(out / 'fetch.exit').write_text(str(result.returncode)+'\n')
assert result.returncode == 0
records = {}
def expose():
    for path in sorted((objects / 'pack').glob('*')):
        assert path.is_file() and not path.name.startswith('tmp')
        if path.suffix == '.pack':
            assert path.with_suffix('.promisor').exists()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        target = repo / '.git/objects/pack' / path.name
        if not target.exists() and not target.is_symlink():
            target.symlink_to(path)
        assert target.read_bytes() == path.read_bytes()
        records[path.name] = dict(path=str(path), exposed=str(target), bytes=path.stat().st_size, sha256=digest)
expose()
commit = run('cat-file', 'commit', remote)
(out / 'whole-remote-commit.txt').write_bytes(commit)
parents = [line.split()[1].decode() for line in commit.splitlines() if line.startswith(b'parent ')]
assert base in parents, parents
diff = run('diff', '--no-renames', '--name-status', base, remote)
(out / 'entire-base-to-remote-paths.txt').write_bytes(diff)
lazy = dict(env, GIT_NO_LAZY_FETCH='0')
for label, commit_id, name in [('base-ledger', base, 'pcc/ledger.jsonl'), ('remote-ledger', remote, 'pcc/ledger.jsonl'), ('remote-AGENTS', remote, 'AGENTS.md')]:
    q = subprocess.run(['git', 'show', commit_id+':'+name], cwd=repo, env=lazy, capture_output=True, timeout=120)
    (out / (label+'.whole')).write_bytes(q.stdout)
    (out / (label+'.stderr')).write_bytes(q.stderr)
    (out / (label+'.exit')).write_text(str(q.returncode)+'\n')
    assert q.returncode == 0
    expose()
base_ledger = (out / 'base-ledger.whole').read_bytes()
remote_ledger = (out / 'remote-ledger.whole').read_bytes()
local_ledger = (out / 'whole-before-ledger.jsonl').read_bytes()
prefix = remote_ledger.startswith(base_ledger)
for name, args in [('HEAD', ['rev-parse', 'HEAD']), ('refs', ['show-ref']), ('status', ['status', '--porcelain'])]:
    assert run(*args) == before[name], name
assert (repo / 'pcc/ledger.jsonl').read_bytes() == local_ledger
receipt = dict(at=datetime.now(timezone.utc).isoformat(), start=start, local=local, previous_remote=base, new_remote=remote, new_remote_parents=parents, actual_fetch_exit=0, complete_new_remote_cache=list(records.values()), old_remote_ledger_exact_prefix_of_new_remote=prefix, local_ledger_exact_prefix_of_new_remote=remote_ledger.startswith(local_ledger), base_ledger_bytes=len(base_ledger), remote_ledger_bytes=len(remote_ledger), local_ledger_bytes=len(local_ledger), whole_local_refs_HEAD_status_ledger_unchanged=True, no_existing_objects_deleted_or_moved=True, remote_merge_path_count=len(diff.splitlines()), scope='unsigned immutable remote history and complete ledger custody only; no merge or publication retry attempted')
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='complete_new_remote_cache'}), flush=True)
