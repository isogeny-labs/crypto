"""Create a new normal Git checkpoint ref; never overwrite the moved shared ref."""
from pathlib import Path
from datetime import datetime, timezone
import base64, json, os, subprocess

repo = Path('/workspace/crypto')
out = Path('/workspace/scratch/ct120-preserved-root-branch-publication-01')
out.mkdir()
head = '1487e3a55efaacf899ab2553af7ff8fbccae22f6'
branch = 'research/chained-transfer-preserved-20261115-ct120'
ref = 'refs/heads/' + branch
assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip() == head
env = os.environ.copy()
count = int(env.get('GIT_CONFIG_COUNT', '0'))
env.update({'GIT_CONFIG_COUNT': str(count+1), 'GIT_CONFIG_KEY_'+str(count): 'http.https://github.com/.extraheader', 'GIT_CONFIG_VALUE_'+str(count): 'AUTHORIZATION: basic '+base64.b64encode(('x-access-token:'+env['GH_TOKEN']).encode()).decode(), 'GIT_TERMINAL_PROMPT':'0'})
url = 'https://github.com/isogeny-labs/crypto.git'
lookup = subprocess.run(['git','ls-remote','--heads',url,ref], cwd=repo, env=env, capture_output=True, timeout=60)
(out/'new-ref-before-lookup.txt').write_bytes(lookup.stdout+lookup.stderr)
assert lookup.returncode == 0 and not lookup.stdout
start = datetime.now(timezone.utc).isoformat()
result = subprocess.run(['git','push','--no-force','--porcelain',url,head+':'+ref], cwd=repo, env=env, capture_output=True, timeout=180)
(out/'push.txt').write_bytes(result.stdout+result.stderr)
(out/'push.exit').write_text(str(result.returncode)+'\n')
assert result.returncode == 0
after = subprocess.run(['git','ls-remote','--heads',url,ref], cwd=repo, env=env, capture_output=True, timeout=60)
(out/'new-ref-after-lookup.txt').write_bytes(after.stdout+after.stderr)
assert after.returncode == 0 and after.stdout.decode().split()[0] == head
assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip() == head
(out/'receipt.json').write_text(json.dumps(dict(start=start, finish=datetime.now(timezone.utc).isoformat(), new_branch=branch, whole_local_commit=head, actual_push_exit=0, actual_remote_new_ref_exact=True, shared_remote_ref_untouched='research/chained-jacobian-transfer-20261110', no_force_or_rechain_or_merge=True, scope='unsigned new-ref preservation only; existing shared-branch append-only ledger divergence remains unresolved'), indent=2)+'\n')
print(head, branch, result.returncode, flush=True)
