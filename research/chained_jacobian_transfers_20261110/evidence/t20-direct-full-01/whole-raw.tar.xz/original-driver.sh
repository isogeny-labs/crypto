#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CHAINED_EVEN_KERNEL_CERTIFICATE_OUT=/workspace/scratch/ct52-direct-full-01-kernel.json
export CHAINED_T20_GEOMETRY_OUT=/workspace/scratch/ct52-direct-full-01-geometry.json
cd /workspace/crypto
printf '%s\n' "$(date -u +%FT%TZ)" > /workspace/scratch/ct52-direct-full-01.started
if timeout 1800 bash -c 'set -euo pipefail
 cd /workspace/crypto/research/chained_jacobian_transfers_20261110/successor-preflight
 sha256sum -c reference.sha256
 sha256sum -c legacy.sha256
 cargo fmt -- --check
 cargo clippy --all-targets --offline --locked -- -D warnings
 cargo test --release --offline --locked -- --nocapture' > /workspace/scratch/ct52-direct-full-01.txt 2>&1; then native_status=0; else native_status=$?; fi
printf '%s\n' "$native_status" > /workspace/scratch/ct52-direct-full-01.exit
printf '%s\n' "$(date -u +%FT%TZ)" > /workspace/scratch/ct52-direct-full-01.finished
if sha256sum -c /workspace/scratch/ct52-direct-static-01.sha256 > /workspace/scratch/ct52-direct-full-01.after.txt 2>&1; then guard_status=0; else guard_status=$?; fi
printf '%s\n' "$guard_status" > /workspace/scratch/ct52-direct-full-01.after.exit
if [ "$native_status" -ne 0 ]; then exit "$native_status"; fi
if [ "$guard_status" -ne 0 ]; then exit "$guard_status"; fi
for pair in 'geometry geometry' 'kernel oldkernel'; do
 read -r output original <<< "$pair"
 if cmp "/workspace/scratch/ct52-direct-full-01-$output.json" "/workspace/crypto/research/chained_jacobian_transfers_20261110/evidence/t20-whole-full-04/$original-certificate.json" > "/workspace/scratch/ct52-direct-full-01-$output-compare.txt" 2>&1; then compare_status=0; else compare_status=$?; fi
 printf '%s\n' "$compare_status" > "/workspace/scratch/ct52-direct-full-01-$output-compare.exit"
 if [ "$compare_status" -ne 0 ]; then exit "$compare_status"; fi
done
