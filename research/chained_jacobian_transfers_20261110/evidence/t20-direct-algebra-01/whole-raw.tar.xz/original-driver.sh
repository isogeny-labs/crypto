#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
cd /workspace/crypto
mkdir /workspace/scratch/ct52-direct-algebra-outputs-01
printf '%s\n' "$(date -u +%FT%TZ)" > /workspace/scratch/ct52-direct-algebra-01.started
if timeout 900 bash -c 'set -euo pipefail
 cd /workspace/crypto/research/chained_jacobian_transfers_20261110/algebra-certificates
 sha256sum -c reference.sha256
 cargo fmt -- --check
 cargo clippy --all-targets --offline --locked -- -D warnings
 cargo test --release --offline --locked -- --nocapture
 output_paths=(); for i in {0..10}; do output_paths+=("/workspace/scratch/ct52-direct-algebra-outputs-01/$i.json"); done
 cargo run --release --offline --locked -- "${output_paths[@]}"' > /workspace/scratch/ct52-direct-algebra-01.txt 2>&1; then status=0; else status=$?; fi
printf '%s\n' "$status" > /workspace/scratch/ct52-direct-algebra-01.exit
printf '%s\n' "$(date -u +%FT%TZ)" > /workspace/scratch/ct52-direct-algebra-01.finished
if sha256sum -c /workspace/scratch/ct52-direct-algebra-01.sha256 > /workspace/scratch/ct52-direct-algebra-01.after.txt 2>&1; then guard=0; else guard=$?; fi
printf '%s\n' "$guard" > /workspace/scratch/ct52-direct-algebra-01.after.exit
exit "$status"
