"""Exact Git worktrees and admission/source custody only; invokes original tools."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess

r=Path('/workspace/cryptanalysis'); s=r/'experiments/chained-transfer-public-target'
source='85b799ec5d7f3a8e81168af11fbf4ba36007be28'; producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2'
layout=Path('/workspace/scratch/ct59-bitangent-replay-layout-01'); layout.mkdir()
reference=s/'ci_bitangents/reference-01.sha256'
refs=[line.split('  ',1)[1] for line in reference.read_text().splitlines()]
assert len(refs)==522
for name,repo,commit,files in [
    ('cryptanalysis',r,source,[p for p in refs if not p.startswith('../crypto/')]+['experiments/chained-transfer-public-target/ci_bitangents/reference-01.sha256']),
    ('crypto',Path('/workspace/crypto'),producer,[p.removeprefix('../crypto/') for p in refs if p.startswith('../crypto/')])]:
    path=layout/name
    p=subprocess.run(['git','worktree','add','--detach','--no-checkout',str(path),commit],cwd=repo,capture_output=True)
    (layout/(name+'-create.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==0
    subprocess.run(['git','sparse-checkout','init','--no-cone'],cwd=path,check=True)
    subprocess.run(['git','sparse-checkout','set','--no-cone','--stdin'],cwd=path,input=('\n'.join('/'+p for p in sorted(set(files)))+'\n').encode(),check=True)
    subprocess.run(['git','read-tree','-mu','HEAD'],cwd=path,check=True)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip()==commit
    status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=path)
    (layout/(name+'-status.txt')).write_bytes(status); assert not status
c=layout/'cryptanalysis';up=layout/'crypto';cs=c/'experiments/chained-transfer-public-target'
out=Path('/workspace/scratch/ct59-bitangent-full-01');out.mkdir()
before={}
for line in reference.read_text().splitlines():
    h,p=line.split('  ',1); path=(c/p).resolve();assert hashlib.sha256(path.read_bytes()).hexdigest()==h
    before[str(path)]=h
localref=cs/'ci_bitangents/reference-01.sha256';before[str(localref)]=hashlib.sha256(localref.read_bytes()).hexdigest()
assert len(before)==523
(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
shutil.copyfile(__file__,out/'prepare.py')
shutil.copyfile(localref,out/'original-reference.sha256')
(out/'plan.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),source=source,producer=producer,
    plan='5a8e82/2c19d2 published before admission/full',portable_inputs=522,outer_guards=523,
    timeout_s=2100,build_cache=str(out)+'-build-cache',phase_pairs='11positive0/0',
    original_native_and_Lean='actual28bitangents/all4wholeJSON/bothoriginal4gates/4exactbindings',scope='routine bounded local correctness/CI development,not experiment or benchmark'),indent=2)+'\n')
env=os.environ.copy();env['PATH']=str(Path.home()/'.cargo/bin')+':'+str(Path.home()/'.elan/bin')+':'+env['PATH']
env['RUSTUP_TOOLCHAIN']='1.99.1';env['ELAN_TOOLCHAIN']='leanprover/lean4:v4.35.0';env['CARGO_TARGET_DIR']=str(out)+'-build-cache'
ad=out/'admission';ad.mkdir();results=[]
def test(name,dest,environment=env):
    p=subprocess.run(['bash',str(cs/'ci_bitangents/check.sh'),str(up),str(dest)],cwd=c,env=environment,capture_output=True,timeout=60)
    (ad/(name+'.log')).write_bytes(p.stdout+p.stderr);(ad/(name+'.exit')).write_text(str(p.returncode)+'\n')
    results.append(dict(name=name,original_exit=p.returncode,output_created=dest.exists()))
    (ad/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    assert p.returncode==2 and not dest.exists(),results[-1]
missing=env.copy();missing['PATH']='/usr/bin:/bin';test('missing-tool',out/'missing-tool-output',missing)
try:
    p=subprocess.run(['git','checkout','--detach','a719f6f75f67576ce3835d8acc6e47bb25a3cbe4'],cwd=up,capture_output=True)
    (ad/'wrong-head-checkout.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
    test('wrong-head',out/'wrong-head-output')
finally:
    p=subprocess.run(['git','checkout','--detach',producer],cwd=up,capture_output=True)
    (ad/'restore-head.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
p=cs/'PROOF_MAP.md';old=p.read_bytes()
try:
    p.write_bytes(old+b'\nDirty admission control.\n');test('dirty-source',out/'dirty-source-output')
finally:p.write_bytes(old)
test('output-in-source',cs/'admission-should-not-exist')
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=c)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=up)
(ad/'restoration.json').write_text(json.dumps(dict(all523_unchanged=True,clean_siblings=True,four_exit2_no_output=True),indent=2)+'\n')
launcher=Path('/workspace/scratch/ct59-bitangent-full-01.sh')
launcher.write_text('''#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export ELAN_TOOLCHAIN=leanprover/lean4:v4.35.0
export CARGO_TARGET_DIR=/workspace/scratch/ct59-bitangent-full-01-build-cache
cd /workspace/scratch/ct59-bitangent-replay-layout-01/cryptanalysis
out=/workspace/scratch/ct59-bitangent-full-01
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
timeout 2100 bash experiments/chained-transfer-public-target/ci_bitangents/check.sh ../crypto "$out/driver" > "$out/native.log" 2>&1
status=$?
printf '%s\\n' "$status" > "$out/native.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARDS'
from pathlib import Path
import hashlib,json,sys
o=Path(sys.argv[1]);before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before};changed=[p for p in before if before[p]!=after[p]]
(o/'after.json').write_text(json.dumps(after,indent=2)+'\\n');(o/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\\n');raise SystemExit(bool(changed))
GUARDS
guard=$?
printf '%s\\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
''')
shutil.copyfile(launcher,out/'original-command.sh')
print(json.dumps(dict(layout=str(layout),source=source,admissions=results,outer_guards=523,launcher=str(launcher))),flush=True)
