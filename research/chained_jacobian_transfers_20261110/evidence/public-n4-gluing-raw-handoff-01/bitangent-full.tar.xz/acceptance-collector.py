"""Original native/proof process outputs and source custody only."""
from pathlib import Path
import json,re,subprocess,lzma,shutil,importlib.util,sys
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';o=Path('/workspace/scratch/ct59-bitangent-full-01');d=s/'evidence/bitangent-independent-full-01';d.mkdir()
for p in[o/'native.exit',o/'guard.exit',o/'driver/original.exit',o/'driver/guard.exit',o/'driver/cleanliness.exit']:assert p.read_text().strip()=='0'
assert json.loads((o/'guards.json').read_text())==dict(count=523,changed=[])
phases=[line.split()for line in(o/'driver/phase-index.txt').read_text().splitlines()];assert len(phases)==11
for name,wanted,actual in phases:assert wanted==actual=='0' and(o/'driver'/(name+'.pipe-exits')).read_text().split()==['0','0']
rows=[]
for line in(o/'driver/native.log').read_text().splitlines():
 m=re.search(r'\b(N4_BITANGENT_[A-Z0-9_]+) (\{.*\})$',line)
 if m:rows.append(dict(kind=m[1],data=json.loads(m[2])))
canon=lambda xs:sorted(json.dumps(x,sort_keys=True,separators=(',',':'))for x in xs)
assert len(rows)==4 and canon(rows)==canon(json.loads((s/'ci_bitangents/expected-native.json').read_text()))
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py');pcc=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pcc;spec.loader.exec_module(pcc)
verdicts=[]
for b in json.loads((s/'evidence/bitangent-bindings-01/claims.json').read_text()):
 name='binding-'+Path(b['claim_path']).stem;v=json.loads((o/'driver'/(name+'.log')).read_text());c=json.loads((r/b['claim_path']).read_text());assert v['verdict']=='pass' and not v['reasons'] and v['commit']=='85b799ec5d7f3a8e81168af11fbf4ba36007be28' and v['claim_sha256']==pcc.claim_digest(c);verdicts.append(v)
for p in[o/'guards.json',o/'plan.json',o/'original-command.sh',o/'admission/results.json',o/'admission/restoration.json']:shutil.copyfile(p,d/p.name)
(d/'all-native-records.json.xz').write_bytes(lzma.compress(json.dumps(rows,indent=2).encode()+b'\n'));(d/'exact-local-verdicts.json').write_text(json.dumps(verdicts,indent=2)+'\n')
meta=dict(source='85b799ec5d7f3a8e81168af11fbf4ba36007be28',producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2',all523_guards_unchanged=True,phase_pairs='11positive0/0',all4_whole_native_JSON_equal=True,both_original_gates='4/0trusted',all4_exact_original_PCC_digests_match=True,four_admission='2/nooutput/restored',HEAD_cleanliness='originalguards0',scope='independent fixedcase28bitangent correctness;formalgeometrypartial/no actualJac2basis/newmap/cost')
(d/'observation.json').write_text(json.dumps(meta,indent=2)+'\n');shutil.copyfile(__file__,o/'acceptance-collector.py')
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Independent bitangent full01 exact85b/3d passesall11positive native+tee0/0,oneunfiltered/all28actualcoordinatechecks/all4wholeJSON equal,bothunchangedoriginal4theoremgates/4exactlocalPCCverdictsandoriginalcanonicaldigests. All523outerguard/portable522/self/HEAD/cleanliness0;fouractualadmissionrejections2/nooutput/restored. FreshphysicalGit siblings/outsidecache;wholeoriginalcapture retained,ownCIauditnext. Unsigned/partialformal;not actualJac2basis/Weilpairing/kernel/nondualmap/cost.']
for p in sorted(d.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(r))]
print(subprocess.check_output(cmd,cwd=r,text=True).strip())
