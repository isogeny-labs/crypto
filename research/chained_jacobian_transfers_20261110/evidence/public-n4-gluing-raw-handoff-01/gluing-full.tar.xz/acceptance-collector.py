"""Compare complete original process outputs, canonical claims and custody."""
from pathlib import Path
import json,re,subprocess,lzma,shutil,importlib.util,sys
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';o=Path('/workspace/scratch/ct60-gluing-full-01');d=s/'evidence/gluing-independent-full-01';d.mkdir();source='7cf45856e7cb019702e3a14fb3961761babb48d7'
for p in[o/'native.exit',o/'guard.exit',o/'driver/original.exit',o/'driver/guard.exit',o/'driver/cleanliness.exit']:assert p.read_text().strip()=='0'
assert json.loads((o/'guards.json').read_text())==dict(count=597,changed=[])
phases=[line.split()for line in(o/'driver/phase-index.txt').read_text().splitlines()];assert len(phases)==21
for name,wanted,actual in phases:assert wanted==actual=='0'and(o/'driver'/(name+'.pipe-exits')).read_text().split()==['0','0']
records={}
canon=lambda xs:sorted(json.dumps(x,sort_keys=True,separators=(',',':'))for x in xs)
for name,wanted in [('models',8),('maps',10)]:
 rows=[];log=(o/'driver'/(name+'.log')).read_text();assert '1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in log
 for line in log.splitlines():
  m=re.search(r'\b(N4_GLUING_[A-Z0-9_]+) (\{.*\})$',line)
  if m:rows.append(dict(kind=m[1],data=json.loads(m[2])))
 assert len(rows)==wanted and canon(rows)==canon(json.loads(lzma.decompress((s/'ci_gluing'/('expected-'+name+'.json.xz')).read_bytes())))
 raw=lzma.compress(json.dumps(rows,indent=2).encode()+b'\n');assert len(raw)<65536;(d/(name+'-whole-native.json.xz')).write_bytes(raw);records[name]=rows
(o/'all-native-records.json').write_text(json.dumps(records,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py');pcc=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pcc;spec.loader.exec_module(pcc)
verdicts=[]
for folder in ['gluing-models-bindings-01','gluing-chain-bindings-01']:
 for b in json.loads((s/'evidence'/folder/'claims.json').read_text()):
  name='binding-'+Path(b['claim_path']).stem;v=json.loads((o/'driver'/(name+'.log')).read_text());c=json.loads((r/b['claim_path']).read_text());assert v['verdict']=='pass'and not v['reasons']and v['commit']==source and v['claim_sha256']==pcc.claim_digest(c);verdicts.append(v)
assert len(verdicts)==11
for p in[o/'guards.json',o/'plan.json',o/'original-command.sh',o/'admission/results.json',o/'admission/restoration.json']:shutil.copyfile(p,d/p.name)
(d/'exact-local-verdicts.json').write_text(json.dumps(verdicts,indent=2)+'\n')
meta=dict(source=source,producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2',all597_outer_guards_unchanged=True,portable_inputs=596,phase_pairs='21orderedpositive0/0',two_unfiltered_tests=True,whole_native_JSON='ALL8models+10maps exactly equal/no exclusions',both_original_proof_gates='11audited/8models3chain/0trusted',all11_exact_original_canonical_PCC_digests_match=True,four_actual_admission='2/nooutput/restored',original_HEAD_cleanliness_guards='0',fresh_physical_Git_siblings_and_outside_cache=True,CI='aefb67 all8SUCCESS/76native41digests;CI guard scope originalsuccessfulsteps/markers,not standaloneartifactdownloads',scope='fixedcase complete-map/chain correctness;unsigned/actualgeometrypartial/no costadvantage')
(d/'observation.json').write_text(json.dumps(meta,indent=2)+'\n');shutil.copyfile(__file__,o/'acceptance-collector.py')
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Independent gluing full01 exact7cf/3d passesall21orderednative+tee0/0,TWOunfilteredtests/ALL18wholeJSONexact/no exclusions,bothunchangedoriginalgates11audited/0trusted/11exactcanonicalPCCbindings. All597outer/596portable+self/HEAD/cleanlinessguards0;fouractualadmissionreject2/nooutput/restored. FreshphysicalGit siblings/outsidecoldcache;wholecapture retained. ALLfoureligiblemaps/both2+both4/public5/exceptionalcontrols reproduce7c9bf4. OwnCIaefb67 alreadyall8SUCCESS/76native41digests. Unsigned/actualgeometrypartial;no cost/security/signedexecutionclaim.']
for p in sorted(d.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(r))]
print(subprocess.check_output(cmd,cwd=r,text=True).strip())
