"""Custody of original kernel replay outputs; no scientific arithmetic."""
from pathlib import Path
import json,re,hashlib,subprocess,lzma,shutil,importlib.util,sys
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';o=Path('/workspace/scratch/ct60-kernel-full-01')
source='5b459ecae1fc469bf9c3bd5fdfe26a0ac0a09d86'
def claim(statement,d):
 cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement',statement]
 for p in sorted(d.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(r))]
 print(subprocess.check_output(cmd,cwd=r,text=True).strip(),flush=True)
for p in[o/'native.exit',o/'guard.exit',o/'driver/original.exit',o/'driver/guard.exit',o/'driver/cleanliness.exit']:assert p.read_text().strip()=='0'
assert json.loads((o/'guards.json').read_text())==dict(count=555,changed=[])
phases=[line.split()for line in(o/'driver/phase-index.txt').read_text().splitlines()];assert len(phases)==15
for name,wanted,actual in phases:assert wanted==actual=='0' and(o/'driver'/(name+'.pipe-exits')).read_text().split()==['0','0']
rows=[]
for name in ['census.log','replay.log']:
 for line in(o/'driver'/name).read_text().splitlines():
  m=re.search(r'\b(N4_KERNEL_[A-Z0-9_]+) (\{.*\})$',line)
  if m:rows.append(dict(kind=m[1],data=json.loads(m[2])))
canonical=lambda xs:sorted(json.dumps(x,sort_keys=True,separators=(',',':'))for x in xs)
assert len(rows)==8 and canonical(rows)==canonical(json.loads((s/'ci_kernels/expected-native.json').read_text()))
raw=(o/'driver/all-symplectic-matrices.bin').read_bytes();binary=json.loads((s/'ci_kernels/expected-binary.json').read_text())
assert len(raw)==binary['bytes']and hashlib.sha256(raw).hexdigest()==binary['sha256']
assert raw==Path('/workspace/scratch/ct59-kernel-census-native-01/all-symplectic-matrices.bin').read_bytes()
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py');pcc=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pcc;spec.loader.exec_module(pcc)
verdicts=[]
for b in json.loads((s/'evidence/kernel-bindings-01/claims.json').read_text()):
 name='binding-'+Path(b['claim_path']).stem;v=json.loads((o/'driver'/(name+'.log')).read_text());c=json.loads((r/b['claim_path']).read_text())
 assert v['verdict']=='pass' and not v['reasons'] and v['commit']==source and v['claim_sha256']==pcc.claim_digest(c);verdicts.append(v)
d=s/'evidence/kernel-independent-full-01';d.mkdir()
for p in[o/'guards.json',o/'plan.json',o/'original-command.sh',o/'admission/results.json',o/'admission/restoration.json']:shutil.copyfile(p,d/p.name)
(d/'all-native-records.json.xz').write_bytes(lzma.compress(json.dumps(rows,indent=2).encode()+b'\n'));(d/'exact-local-verdicts.json').write_text(json.dumps(verdicts,indent=2)+'\n')
meta=dict(source=source,producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2',all555_outer_guards_unchanged=True,portable_inputs=554,phases=15,all_phase_pairs='0/0',all8_whole_native_JSON_equal=True,entire_binary_bytes=13063688,binary_sha256=binary['sha256'],binary_byte_for_byte_equal=True,both_original_gates='8audited/5named3generated/0trusted',all5_exact_canonical_PCC_digests_match=True,four_admission='2/nooutput/restored',scope='finite algebra correctness;unsigned/partialformal;no actualnewJacobianmap/cost')
(d/'observation.json').write_text(json.dumps(meta,indent=2)+'\n');shutil.copyfile(__file__,o/'acceptance-collector.py')
claim('Independent kernel full01 exact5b459ec/3d passes all15ordered native+tee0/0, TWOseparateunfilteredtests/all8wholeJSON/ALL13063688binarybytes equal nativeproducer, bothunchangedoriginal8auditedgates/5exactcanonicalPCCbindings. All555outer/554portable+self/HEAD/cleanlinessguards0;fouractualadmissionreject2/nooutput/restored. FreshphysicalGit siblings/outsidecache/wholecapture retained. Nativefinitecensus/replay confirms1451520rows/120960compatible/centralizer12/uniqueabstractstablekernel;geometricbridgeswritten/formalpartial,unsigned,not newmap/fullformal/cost. Ownsevenworkflowauditpending.',d)
pub=Path('/workspace/scratch/ct60-kernel-source-publication-01');d=s/'evidence/kernel-normal-publication-01';d.mkdir()
receipt=json.loads((pub/'receipt.json').read_text());assert receipt['original_exit']==0 and receipt['head']==source and receipt['expected_head']=='85b799ec5d7f3a8e81168af11fbf4ba36007be28'and not receipt['force']
for p in pub.iterdir():
 if p.is_file():
  if p.suffix=='.log':(d/(p.name+'.xz')).write_bytes(lzma.compress(p.read_bytes()))
  else:shutil.copyfile(p,d/p.name)
claim('Kernel source5b459ec/tree347f60b3/parent85b799ec/220paths/governance79eec6 actuallynormalpublished0 with expectedhead andno force;wholeoriginalpush/lookup losslessXZ andreceipt retained. e2da08preservesfirstproselintfailure1/exact3historicalfrozenfindings/active02tagcopieslint0;allotheroriginalsourcegovernancegates0. No mainmerge/requiredreview/signingwaiver.',d)
