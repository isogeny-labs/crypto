"""Native log/API custody and calls to the unchanged PCC tooling only."""
from pathlib import Path
from datetime import datetime, timezone
import json, re, shutil, subprocess, lzma, hashlib, importlib.util, sys
r=Path('/workspace/cryptanalysis'); s=r/'experiments/chained-transfer-public-target'
def claim(statement,dest):
    cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement',statement]
    for p in sorted(dest.iterdir()):
        if p.is_file(): cmd+=['--proof','attestation:'+str(p.relative_to(r))]
    print(subprocess.check_output(cmd,cwd=r,text=True).strip(),flush=True)
def records(log):
    rows=[]
    for line in log.splitlines():
        m=re.search(r'\b(N4_[A-Z0-9_]+) (\{.*\})$',line)
        if m: rows.append(dict(kind=m[1],data=json.loads(m[2])))
    return rows
canonical=lambda x: sorted(json.dumps(t,sort_keys=True,separators=(',',':')) for t in x)
o=Path('/workspace/scratch/ct59-bitangent-own-CI-raw-01'); source='85b799ec5d7f3a8e81168af11fbf4ba36007be28'
rows={}; verdicts=[]; jobs=[]
for label,run,job,marker in [('completed',43459421449,132002052569,'Completed-descent replay complete:'),('V2',43459421300,132002052284,'Completed V2/rho replay complete:'),('P1',43459421503,132002052816,'Public-target N4 replay complete:'),('two-primary',43459421462,132002052778,'Actual two-primary replay complete:'),('bitangents',43459421566,132002053733,'Actual bitangent replay complete:'),('PCC',43459421355,132002052080,'Verify all claims')]:
    api=json.loads((o/(label+'-jobs-api.json')).read_text())['structuredContent']['jobs']
    target=[x for x in api if x['id']==job]; assert len(target)==1
    j=target[0]; assert (j['run_id'],j['status'],j['conclusion'])==(run,'completed','success')
    log=json.loads((o/(label+'-log-api.json')).read_text())['structuredContent']['content']
    assert source in log and (label=='PCC' or marker in log)
    (o/(label+'-whole-job.log')).write_text(log)
    jobs.append(dict(label=label,run=run,job=job,status='completed',conclusion='success'))
    if label=='PCC':
        sign=[j for j in api if j['name']=='sign']; assert len(sign)==1 and sign[0]['conclusion']=='skipped'
        assert any('exit 2 = not covered is allowed' in step['name'] for step in j['steps'])
    else:
        rows[label]=records(log)
        for line in log.splitlines():
            if '{"claim_id":' in line: verdicts.append(json.loads(line[line.index('{"claim_id":'):]))
assert {k:len(v) for k,v in rows.items()}==dict(completed=17,V2=12,P1=13,**{'two-primary':4,'bitangents':4})
def omitted(rows):
    rows=json.loads(json.dumps(rows))
    for row in rows:
        methods=['baseline','candidate'] if row['kind']=='N4_COMPLETED_ATTEMPT' else ['public'] if row['kind']=='N4_PUBLIC_ATTEMPT' else []
        for method in methods:
            for phase in row['data'][method]['phases']: del phase['wall']
            row['data'][method]['stats']=[p for p in row['data'][method]['stats'] if p[0]!='wall_total']
    return canonical(rows)
assert canonical(rows['bitangents'])==canonical(json.loads((s/'ci_bitangents/expected-native.json').read_text()))
assert canonical(rows['two-primary'])==canonical(json.loads((s/'ci_two_primary/expected-native.json').read_text()))
assert omitted(rows['completed'])==omitted(json.loads((s/'ci_completed/expected-native.json').read_text()))
assert omitted(rows['P1'])==omitted(json.loads((s/'evidence/unit-acceptance-01/all-native-records.json').read_text()))
for prefix,name in [('N4_V2_','expected-native-v2.json'),('N4_RHO_','expected-native-rho.json')]:
    assert canonical([x for x in rows['V2'] if x['kind'].startswith(prefix)])==canonical(json.loads((s/'ci_v2'/name).read_text()))
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py'); pcc=importlib.util.module_from_spec(spec); sys.modules[spec.name]=pcc; spec.loader.exec_module(pcc)
digests={}
for folder in ['lean-bindings-01','origin-lean-bindings-01','prime-field-bindings-02','two-primary-bindings-01','bitangent-bindings-01']:
    for binding in json.loads((s/'evidence'/folder/'claims.json').read_text()):
        c=json.loads((r/binding['claim_path']).read_text()); digests[c['id']]=pcc.claim_digest(c)
assert len(verdicts)==len(digests)==25 and set(digests)=={v['claim_id'] for v in verdicts}
for v in verdicts: assert v['verdict']=='pass' and not v['reasons'] and v['commit']==source and v['claim_sha256']==digests[v['claim_id']]
full=Path('/workspace/scratch/ct59-bitangent-full-01')
shutil.copytree(full/'driver/source',o/'source')
shutil.copyfile(full/'original-reference.sha256',o/'source/cryptanalysis/experiments/chained-transfer-public-target/ci_bitangents/reference-01.sha256')
assert sum(p.is_file() for p in (o/'source').rglob('*'))==523
for name,data in [('all-native-records.json',rows),('all25-exact-verdicts.json',verdicts),('original-PCC-canonical-digests.json',digests)]: (o/name).write_text(json.dumps(data,indent=2)+'\n')
shutil.copyfile(__file__,o/'original-collector.py')
meta=dict(at=datetime.now(timezone.utc).isoformat(),source=source,jobs=jobs,native_records=50,all50_original_native_JSON_match_except_ONLY_recorded_wall_walltotal_for_candidate_and_P1=True,raw_timings_retained=True,all25_original_canonical_PCC_digests_match=True,exact_verdicts='pass/unsigned',PCC_sign='legitimately skipped featurebranch',PCC_gate='success; explicitly allows notcovered exit2',whole_logs_API_and523_source_snapshots_retained=True,artifact_ZIP_downloaded=False,CI_guard_scope='successful original replay steps and complete original markers; standalone exit files not downloaded; separate localfull523 actual guards0',scope='correctness observations; not full formal geometry, cost advantage or signed execution')
(o/'plan.json').write_text(json.dumps(meta,indent=2)+'\n')
d=s/'evidence/bitangent-own-CI-01'; d.mkdir(); (d/'observation.json').write_text(json.dumps(meta,indent=2)+'\n')
for name in ['all-native-records.json','all25-exact-verdicts.json','original-PCC-canonical-digests.json']:
    raw=(o/name).read_bytes(); (d/(name+'.xz')).write_bytes(lzma.compress(raw))
for label in ['completed','V2','P1','two-primary','bitangents','PCC']:
    raw=(o/(label+'-whole-job.log')).read_bytes(); (d/(label+'-whole-job.log.xz')).write_bytes(lzma.compress(raw))
claim('Exact85b independentCI allSIXunique workflowsSUCCESS: bitangents43459421566/132002053733;two-primary43459421462/132002052778;completed43459421449/132002052569;V2rho43459421300/132002052284;P143459421503/132002052816;PCC43459421355/132002052080. All50nativeJSON match originals (ONLYcandidate/P1recordedwallwalltotalexcluded/rawintact);all25exactlocalPCCverdictspass/source85b/originalcanonicaldigests. Newbitangentoneunfiltered/all4wholeJSON/bothoriginal4gates/4bindings. PCCallowsnotcovered2/signlegitskipped. Whole6logs/API/523sourcesretained;successfuloriginalsteps+markersscope/no downloadedstandaloneexitfilesorZIP;separatelocalfullaf9044all523guards. ExtraPCCrun43460007347observedsuccessinrunsAPI,notduplicatelogclaimed. No signed/fullformal/kernel/newmap/costclaim.',d)
