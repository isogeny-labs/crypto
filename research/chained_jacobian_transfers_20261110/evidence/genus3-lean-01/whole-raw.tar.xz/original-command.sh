#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export ELAN_TOOLCHAIN=leanprover/lean4:v4.35.0
cd /workspace/crypto
out=/workspace/scratch/ct55-g3-lean-01
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
lean --version > "$out/lean-version.txt" 2>&1
command -v lean4checker > "$out/lean4checker-path.txt" 2>&1
set +e
timeout 600 tools/lean/proof-gate.sh --out "$out/gate" research/chained_jacobian_transfers_20261110/genus3-prime-descent/lean/Descent.lean > "$out/native.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/native.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARDS'
from pathlib import Path
import json,hashlib,sys
o=Path(sys.argv[1]);before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before};changed=[p for p in before if before[p]!=after[p]]
(o/'after.json').write_text(json.dumps(after,indent=2)+'\n');(o/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\n');raise SystemExit(bool(changed))
GUARDS
guard=$?
printf '%s\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
