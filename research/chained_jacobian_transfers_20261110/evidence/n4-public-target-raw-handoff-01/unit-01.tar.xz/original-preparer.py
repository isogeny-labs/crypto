"""Freeze/copy native source and commands; no cryptographic computation in Python."""
from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib,subprocess,shutil
label=sys.argv[1];assert label in ['static-01','unit-01']
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';n=s/'native'
out=Path('/workspace/scratch/ct57-n4-'+label);out.mkdir()
pins=json.loads((n/'original/source-pins.json').read_text())
for name,v in pins['files'].items():
    raw=(n/'original'/name).read_bytes();assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256']
t=(n/'original/solver.rs').read_text()
for a,b in [('pub fn ic_solve(inst: &Inst, prm: &Params, k_true: u64, seed: u64, verify_rel: bool) -> Report {','pub fn ic_solve_target(inst: &Inst, prm: &Params, target: EP, seed: u64, verify_rel: bool) -> Report {'),('    let target = inst.ec.mul(&inst.g, k_true as u128);\n',''),('pub fn rho(inst: &Inst, k_true: u64, seed: u64) -> RhoOut {','pub fn rho_target(inst: &Inst, target: EP, seed: u64) -> RhoOut {'),('    let target = ec.mul(&inst.g, k_true as u128);\n','')]:
    assert t.count(a)==1;t=t.replace(a,b)
assert t==(n/'derived/public_solver.rs').read_text() and 'k_true' not in t
old=json.loads(Path('/workspace/crypto/research/chained_jacobian_transfers_20261110/evidence/g3-norm-pcc-current-guard-02/current-inputs.json').read_text())
assert len(old)==2175 and all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in old.items())
guards=dict(old)
for p in n.rglob('*'):
    if p.is_file():guards[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
(out/'before.json').write_text(json.dumps(guards,indent=2)+'\n')
for name,h in guards.items():
    p=Path(name);relative=p.relative_to('/workspace');target=out/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
shutil.copyfile(__file__,out/'original-preparer.py')
manifest='experiments/chained-transfer-public-target/native/Cargo.toml'
command=(f'cargo check --offline --locked --manifest-path {manifest} --all-targets' if label.startswith('static') else f'cargo test --release --offline --locked --manifest-path {manifest} --lib -- --nocapture --test-threads=1')
plan=dict(at=datetime.now(timezone.utc).isoformat(),protocol='7e016c/f888 publishedbeforecode/ready1523/actual388636',question='literal publicQ derivative/five fixedIC solves/original independent source admission and verification',attempt=label,command=command,original_source_files_unchanged=4,derivative_literal_substitutions=4,original_guard_count=2175,total_guard_count=len(guards),timeout_s=900,native_runtime_address_limit_KiB=2097152 if label.startswith('unit') else None,cache=str(out)+'-build-cache',cache_outside_raw=True,tests='THREE unfiltered tests/zero ignored;allfive publicIC targets mustsolve;retainallretrypairs' if label.startswith('unit') else 'original Rust compiler alltargets and formatcheck ownnewsrc;no constructor/test runs',plain_rho_scope='public-body derivative present;original RhoOut does not expose recovered scalar,so independent recovered-answer replay remains separate rather than claimed',scope='bounded routine development correctness only,no timing ratio/paidbenchmark/experimentadmission',falsification='any compiler/test/sourceguard/independentresult failure retainswholeattempt;do notrelaxfrozenfive-target acceptance')
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
if label.startswith('unit'):
    plan['compile_phase']='original cargo test --release --offline --locked --lib --no-run, separate900seconds; no test/constructor execution, compiler memory uncapped'
    plan['runtime_limit_scope']='2GiB address-space applies to original cargo+already-built unfiltered native test executable; not the compiler phase'
    (out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
d=s/'evidence'/('plan-'+label);d.mkdir();shutil.copyfile(out/'plan.json',d/'plan.json')
cl=subprocess.check_output(['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Freeze publicN4 '+label+' BEFOREoriginalRustprocess:publishedprospective7e016c/f888/ready1523/388636;FOURoriginalsourcefilesbyteexact andpublicsolverONLY4literalplumbing substitutions/no k_true. All2175parentinputs+newnative guarded/copiedwhole;900seconds/freshoutsidecache. Staticalltargets/ownsrcformat orTHREEunfilteredunit tests/ALLfivepublicICsolves+strictcontrols/independentoriginalengine. Plainrho derivativeexists butRhoOut no recoveredscalar;do notclaim independentrhoanswerreplay. Wholefailurepreservation/no benchmark admission.','--proof','attestation:'+str((d/'plan.json').relative_to(r))],cwd=r,text=True).strip();print('frozen',cl,'guards',len(guards),flush=True)
script='''#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR='''+str(out)+'''-build-cache
cd /workspace/cryptanalysis
out='''+str(out)+'''
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
rustc -Vv > "$out/rustc.txt" 2>&1
cargo -V > "$out/cargo.txt" 2>&1
uname -a > "$out/host.txt" 2>&1
set +e
'''
if label.startswith('static'):
    script+='rustfmt --edition 2021 --check --config skip_children=true '+str(n/'src/lib.rs')+' '+str(n/'src/main.rs')+' '+str(n/'src/tests.rs')+' > "$out/format.log" 2>&1\nformat=$?\nprintf "%s\\n" "$format" > "$out/format.exit"\n'
    script+='timeout 900 '+command+' > "$out/native.log" 2>&1\nstatus=$?\n'
else:
    compile_command=f'cargo test --release --offline --locked --manifest-path {manifest} --lib --no-run'
    script+='timeout 900 '+compile_command+' > "$out/compile.log" 2>&1\nbuild=$?\nprintf "%s\\n" "$build" > "$out/compile.exit"\n'
    script+='if [ "$build" -eq 0 ]; then\n  (ulimit -v 2097152; timeout 900 '+command+') > "$out/native.log" 2>&1\n  status=$?\nelse\n  status=$build\n  cp "$out/compile.log" "$out/native.log"\nfi\n'
script+='''printf '%s\n' "$status" > "$out/native.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARDS'
from pathlib import Path
import hashlib,json,sys
out=Path(sys.argv[1]);before=json.loads((out/'before.json').read_text())
after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before}
changed=[p for p in before if before[p]!=after[p]]
(out/'after.json').write_text(json.dumps(after,indent=2)+'\\n')
(out/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\\n')
raise SystemExit(bool(changed))
GUARDS
guard=$?
printf '%s\n' "$guard" > "$out/guard.exit"
printf 'native=%s guard=%s\n' "$status" "$guard"
exit "$status"
'''
# Python in this shell is byte-hash custody only, not mathematical execution.
(out/'original-command.sh').write_text(script);Path(str(out)+'.sh').write_text(script)
print(out,flush=True)
