#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct57-n4-static-01-build-cache
cd /workspace/cryptanalysis
out=/workspace/scratch/ct57-n4-static-01
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
rustc -Vv > "$out/rustc.txt" 2>&1
cargo -V > "$out/cargo.txt" 2>&1
uname -a > "$out/host.txt" 2>&1
set +e
rustfmt --edition 2021 --check --config skip_children=true /workspace/cryptanalysis/experiments/chained-transfer-public-target/native/src/lib.rs /workspace/cryptanalysis/experiments/chained-transfer-public-target/native/src/main.rs /workspace/cryptanalysis/experiments/chained-transfer-public-target/native/src/tests.rs > "$out/format.log" 2>&1
format=$?
printf "%s\n" "$format" > "$out/format.exit"
timeout 900 cargo check --offline --locked --manifest-path experiments/chained-transfer-public-target/native/Cargo.toml --all-targets > "$out/native.log" 2>&1
status=$?
printf '%s
' "$status" > "$out/native.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARDS'
from pathlib import Path
import hashlib,json,sys
out=Path(sys.argv[1]);before=json.loads((out/'before.json').read_text())
after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before}
changed=[p for p in before if before[p]!=after[p]]
(out/'after.json').write_text(json.dumps(after,indent=2)+'\n')
(out/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\n')
raise SystemExit(bool(changed))
GUARDS
guard=$?
printf '%s
' "$guard" > "$out/guard.exit"
printf 'native=%s guard=%s
' "$status" "$guard"
exit "$status"
