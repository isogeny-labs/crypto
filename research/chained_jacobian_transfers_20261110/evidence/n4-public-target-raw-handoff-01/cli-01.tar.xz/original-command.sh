#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct57-n4-unit-01-build-cache
cd /workspace/cryptanalysis
out=/workspace/scratch/ct57-n4-cli-01
bin="$CARGO_TARGET_DIR/release/chained-n4-public-target"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
rustc -Vv > "$out/rustc.txt" 2>&1
set +e
timeout 900 cargo build --release --offline --locked --manifest-path experiments/chained-transfer-public-target/native/Cargo.toml > "$out/build.log" 2>&1
build=$?
printf '%s\n' "$build" > "$out/build.exit"
if [ "$build" -eq 0 ]; then
  sha256sum "$bin" > "$out/native-binary.sha256"
  run_case() {
    local name="$1"; shift
    (ulimit -v 2097152; timeout 900 "$bin" "$@") > "$out/processes/$name.stdout" 2> "$out/processes/$name.stderr"
    printf '%s\n' "$?" > "$out/processes/$name.exit"
  }
  run_case describe describe "$out/outputs/describe.json"
  run_case public-five solve "$out/inputs/public-five.json" "$out/outputs/public-five.json"
  run_case foreign-q solve "$out/inputs/foreign-q.json" "$out/outputs/foreign-q.json"
  run_case schema solve "$out/inputs/schema.json" "$out/outputs/schema.json"
  run_case field solve "$out/inputs/field.json" "$out/outputs/field.json"
  run_case model solve "$out/inputs/model.json" "$out/outputs/model.json"
  run_case noncanonical solve "$out/inputs/noncanonical.json" "$out/outputs/noncanonical.json"
  run_case offcurve solve "$out/inputs/offcurve.json" "$out/outputs/offcurve.json"
  run_case nonmember solve "$out/inputs/nonmember.json" "$out/outputs/nonmember.json"
  run_case unknown-scalar solve "$out/inputs/unknown-scalar.json" "$out/outputs/unknown-scalar.json"
  run_case unknown-witness solve "$out/inputs/unknown-witness.json" "$out/outputs/unknown-witness.json"
  run_case empty solve "$out/inputs/empty.json" "$out/outputs/empty.json"
  run_case six solve "$out/inputs/six.json" "$out/outputs/six.json"
  run_case oversize solve "$out/inputs/oversize.json" "$out/outputs/oversize.json"
  run_case overwrite solve "$out/inputs/public-five.json" "$out/outputs/overwrite.json"
  run_case extra-arg solve "$out/inputs/public-five.json" "$out/outputs/extra-arg.json" EXTRA
fi
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARD'
from pathlib import Path
import hashlib,json,sys
o=Path(sys.argv[1]);before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before};changed=[p for p in before if before[p]!=after[p]]
(o/'after.json').write_text(json.dumps(after,indent=2)+'\n');(o/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\n');raise SystemExit(bool(changed))
GUARD
guard=$?
printf '%s\n' "$guard" > "$out/guard.exit"
printf 'build=%s guard=%s; per-process exits retained\n' "$build" "$guard"
exit "$build"
