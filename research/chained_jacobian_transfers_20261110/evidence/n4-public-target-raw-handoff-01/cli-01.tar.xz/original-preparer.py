"""Literal native-output input custody and Bash process plan. No crypto arithmetic."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,shutil,copy
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';n=s/'native'
out=Path('/workspace/scratch/ct57-n4-cli-01');out.mkdir();(out/'inputs').mkdir();(out/'outputs').mkdir();(out/'processes').mkdir()
records=json.loads((s/'evidence/unit-acceptance-01/all-native-records.json').read_text())
attempts=[x['data'] for x in records if x['kind']=='N4_PUBLIC_ATTEMPT']
identity=json.loads((s/'evidence/unit-acceptance-01/instance.json').read_text())
targets=[next(x['public_request'] for x in attempts if x['target_index']==i) for i in range(5)]
request=dict(schema='chained-n4-public-target/v1',q=223,targets=targets)
def write(name,v): (out/'inputs'/(name+'.json')).write_text(json.dumps(v,indent=2)+'\n')
write('public-five',request)
(out/'witnesses-OUTSIDE-public-input.json').write_text(json.dumps([dict(target_index=x['target_index'],original_native_recovered_scalar=x['public']['k_found']) for x in attempts if x['public']['ok']],indent=2)+'\n')
mutations={}
def mutate(name,fn):
    v=copy.deepcopy(request);fn(v);write(name,v);mutations[name]=dict(expected_exit=2,expected_no_output=True)
mutate('foreign-q',lambda v:v.update(q=7));mutate('schema',lambda v:v.update(schema='foreign'))
mutate('field',lambda v:v['targets'][0].update(field='foreign'));mutate('model',lambda v:v['targets'][0].update(model='foreign'))
mutate('noncanonical',lambda v:v['targets'][0].update(coordinates=[[223,0,0],[0,0,0]]))
# Literal input mutation, with actual rejection checked by the original curve engine.
mutate('offcurve',lambda v:v['targets'][0].update(coordinates=[[0,0,0],[0,0,0]]))
admission=next(x['data'] for x in records if x['kind']=='N4_PUBLIC_ADMISSION')
mutate('nonmember',lambda v:v['targets'][0].update(coordinates=admission['actual_nonmember']))
mutate('unknown-scalar',lambda v:v.update(scalar=1))
mutate('unknown-witness',lambda v:v['targets'][0].update(witness=1))
mutate('empty',lambda v:v.update(targets=[]))
mutate('six',lambda v:v.update(targets=v['targets']+[v['targets'][0]]))
(out/'inputs/oversize.json').write_bytes(b' '*65537);mutations['oversize']=dict(expected_exit=2,expected_no_output=True)
(out/'outputs/overwrite.json').write_bytes(b'original output sentinel\n')
mutations['overwrite']=dict(expected_exit=2,expected_original_bytes_unchanged=True)
mutations['extra-arg']=dict(expected_exit=2,expected_no_output=True)
assert len(mutations)==14
old=json.loads(Path('/workspace/crypto/research/chained_jacobian_transfers_20261110/evidence/g3-norm-pcc-current-guard-02/current-inputs.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in old.items())
guards=dict(old)
for p in n.rglob('*'):
    if p.is_file():guards[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
(out/'before.json').write_text(json.dumps(guards,indent=2)+'\n')
for p in guards:
    target=out/'source'/Path(p).relative_to('/workspace');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
shutil.copyfile(__file__,out/'original-preparer.py');(out/'expected-native-instance.json').write_text(json.dumps(identity,indent=2)+'\n')
plan=dict(at=datetime.now(timezone.utc).isoformat(),protocol='7e016c/f888/ready1523/388636',unit='e08eac FIVEpublicICsolves+all10pairs preserved/all2188guards0',scope='actual original-native derivative CLI processes;literalpublicQ only,knownanswers OUTSIDErequests;no timingratio',guards=len(guards),positive_processes=['describe exactsameinstance','solve FIVE literalpublictargets/all5mustpass independentoriginalnativechecks'],negative_processes=mutations,timeout_per_process_s=900,native_address_limit_KiB=2097152,compile='original cargo build release/offline/locked;reuse SAME outside unit01 cache,not fresh/cold benchmark',cache='/workspace/scratch/ct57-n4-unit-01-build-cache',source_dependency_scope='whole2175parent+newnative sources;installedRust/thirdparties versioned/locked not copied;cacheoutside',acceptance='describeJSON==unitnativeidentity;solve0/all5nativeindependentchecks andscalars==unitanswers;ALL14exit2/nonoutputoroverwritebytesunchanged/allguards0',failure='retainwholeoriginalattempt;no weakerprocess/admission/solvercriteria')
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');d=s/'evidence/cli-plan-01';d.mkdir();shutil.copyfile(out/'plan.json',d/'plan.json')
cl=subprocess.check_output(['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Freeze publicN4 actualCLI01 BEFOREnativeprocesses:literal5publicQencodings fromactualunit e08eac,knownwitness metadata OUTSIDE requests;describe+solve positive andFOURTEENactualexit2controls/absenceoroverwriteunchanged. Sameoutsideunitreleasecacheexplicit/notcoldbenchmark;originalnativebody/independentcurvechecks/900seconds2GiBruntime/allparent+newsourceguards. Wholeoriginalcapture andstrictfive-targetacceptance retained;not yetCLIresult.','--proof','attestation:'+str((d/'plan.json').relative_to(r))],cwd=r,text=True).strip();print(cl,flush=True)
script='''#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct57-n4-unit-01-build-cache
cd /workspace/cryptanalysis
out=/workspace/scratch/ct57-n4-cli-01
bin="$CARGO_TARGET_DIR/release/chained-n4-public-target"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
rustc -Vv > "$out/rustc.txt" 2>&1
set +e
timeout 900 cargo build --release --offline --locked --manifest-path experiments/chained-transfer-public-target/native/Cargo.toml > "$out/build.log" 2>&1
build=$?
printf '%s\\n' "$build" > "$out/build.exit"
if [ "$build" -eq 0 ]; then
  sha256sum "$bin" > "$out/native-binary.sha256"
  run_case() {
    local name="$1"; shift
    (ulimit -v 2097152; timeout 900 "$bin" "$@") > "$out/processes/$name.stdout" 2> "$out/processes/$name.stderr"
    printf '%s\\n' "$?" > "$out/processes/$name.exit"
  }
  run_case describe describe "$out/outputs/describe.json"
  run_case public-five solve "$out/inputs/public-five.json" "$out/outputs/public-five.json"
'''
for label in mutations:
    if label=='overwrite':script+='  run_case overwrite solve "$out/inputs/public-five.json" "$out/outputs/overwrite.json"\n'
    elif label=='extra-arg':script+='  run_case extra-arg solve "$out/inputs/public-five.json" "$out/outputs/extra-arg.json" EXTRA\n'
    else:script+='  run_case '+label+' solve "$out/inputs/'+label+'.json" "$out/outputs/'+label+'.json"\n'
script+='''fi
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARD'
from pathlib import Path
import hashlib,json,sys
o=Path(sys.argv[1]);before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before};changed=[p for p in before if before[p]!=after[p]]
(o/'after.json').write_text(json.dumps(after,indent=2)+'\\n');(o/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\\n');raise SystemExit(bool(changed))
GUARD
guard=$?
printf '%s\\n' "$guard" > "$out/guard.exit"
printf 'build=%s guard=%s; per-process exits retained\\n' "$build" "$guard"
exit "$build"
'''
(out/'original-command.sh').write_text(script);Path(str(out)+'.sh').write_text(script)
