"""Reclaim only closed derived incrementals; whole-byte inventory retained."""
from pathlib import Path
import hashlib,json,lzma,shutil,subprocess
s=Path('/workspace/scratch');roots=[s/'ct54-fp-chain-static-02-build-cache/debug/incremental',s/'ct55-g3-focused-local-01-build-cache/debug/incremental']
held=json.loads((s/'ct74-bulk15-handoff-01/current-inputs.json').read_text())
active=subprocess.check_output(['ps','-eo','pid,args'],text=True)
assert not any(('cargo 'in line or 'rustc 'in line)and '<defunct>'not in line and 'python3'not in line and 'bash -lc'not in line for line in active.splitlines())
assert all(not any(Path(p).is_relative_to(root)for p in held)for root in roots)
rows=[]
for root in roots:
 assert root.is_dir()
 for p in sorted(root.rglob('*')):
  if p.is_file():rows.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
receipt=s/'ct74-closed-incremental-cleanup-02.json.xz';receipt.write_bytes(lzma.compress((json.dumps({'roots':list(map(str,roots)),'closed_derived_only':True,'no_active_cargo_or_rustc':True,'outside_all_guard15_paths':True,'sealed_B_full_cache_untouched':True,'whole_files':rows},indent=2)+'\n').encode()))
for root in roots:shutil.rmtree(root)
print('removed closed derived bytes',sum(x['bytes']for x in rows),'files',len(rows),'receipt',str(receipt))
