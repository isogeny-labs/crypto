"""Two literal source substitutions and exact provenance; no new arithmetic."""
from pathlib import Path
import difflib,hashlib,json,shutil,subprocess
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';d=s/'norm-assisted-ic'
pub=json.loads(Path('/workspace/scratch/ct71-protocol-publication-01/receipt.json').read_text());assert pub['original_exit']==0 and pub['head']=='b57b1024d45dd87821ad6b8ba4cf4169ac12a1bb'
old=(s/'new-target-ic/derived/class_solver.rs').read_bytes();snapshot=d/'original/class_solver.rs';snapshot.parent.mkdir();snapshot.write_bytes(old)
text=old.decode();changes=[("crate::TargetContext<'_>","crate::SamplerContext<'_>"),('let r0 = pc(&cv, || cv.mul_scalar(generator, r as u128));','let r0 = inst.sample(r).expect("prepared exact-generator sampler");')]
for a,b in changes:assert text.count(a)==1;text=text.replace(a,b)
new=d/'derived/class_solver.rs';new.parent.mkdir();new.write_text(text)
for p in [snapshot.parent,new.parent]:(p/'.gitattributes').write_text('class_solver.rs whitespace=-blank-at-eof\n')
(d/'literal-derivative.diff').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),text.splitlines(True),fromfile='39b/new-target-ic/derived/class_solver.rs',tofile='norm-assisted-ic/derived/class_solver.rs')))
(d/'provenance.json').write_text(json.dumps(dict(published_prospective='4a6745/b57b1024 NORMALpublication0 BEFOREcode',original_source='39b932dddb9d655d7d35b058aa796af5c6941b8c',original_path='new-target-ic/derived/class_solver.rs',original_sha256=hashlib.sha256(old).hexdigest(),derivative_sha256=hashlib.sha256(text.encode()).hexdigest(),literal_substitutions=changes,all_other_bytes_unchanged=True,final_original_Picard_verification_unchanged=True,no_source_DLP_or_witness=True),indent=2)+'\n')
shutil.copyfile(s/'new-target-ic/Cargo.lock',d/'Cargo.lock')
print('exact two-substitution derivative recorded',flush=True)
