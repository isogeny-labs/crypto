"""Nonsecret whole-capture closures and restorable owned source snapshot."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess
r=Path('/workspace/cryptanalysis');base='b57b1024d45dd87821ad6b8ba4cf4169ac12a1bb';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==base
old=Path('/workspace/scratch/ct70-current-original-checkpoint-01');public=Path('/workspace/scratch/ct71-current-checkpoint-public-01');public.mkdir()
excluded=[]
for p in old.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(old)
 if rel==Path('download-api.json'):
  raw=p.read_bytes();excluded.append(dict(path=str(rel),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),reason='private temporary FileService download reference;original retained locally,all scientific/nonsecret output complete'));continue
 target=public/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
assert len(excluded)==1
(public/'private-reference-exclusions.json').write_text(json.dumps(dict(original_full_private_tree=str(old),public_scope='EVERY nonsecret source file includingwholeZIP/all28members/logs/API/receipt/localgate outputs;ONLYprivate temporarydownloadreference excluded',excluded=excluded),indent=2)+'\n')
draft=Path('/workspace/scratch/ct71-norm-sampling-report-capture-01');draft.mkdir();shutil.copytree('/workspace/scratch/ct71-report-draft-01',draft/'editorial-draft-01')
for name in ['ct71-report-first-compile-tool-output.json','ct71-report-first-failed.typ','ct71-norm-assisted-report-page-1.png','ct71-norm-assisted-report-page-2.png','ct71-norm-assisted-report-final-page-1.png','ct71-norm-assisted-report-final-page-2.png']:
 shutil.copyfile(Path('/workspace/scratch')/name,draft/name)
(draft/'scope.json').write_text(json.dumps(dict(first_compile='exit1/unknownTypstJ/source+toolreturnedoutput retained',editorial_draft='whole75135B/2pages beforefontlayoutprosepolish',final_report='510c8c/whole75055B/SHA087681bc363cd6485f542cb92b89ce691ada9aa17c8c27a58507bd8d1d78aad5',inspection='ALLTWOdraft andALLTWOfinalpages actuallyviewed;final pagesreadable/no clipping',scientific_native='9bc5e6/originalnativeunchanged'),indent=2)+'\n')
o=Path('/workspace/scratch/ct71-norm-sampling-source-checkpoint-01');o.mkdir();scope=['experiments/chained-transfer-public-target','docs/chained-transfer-checkpoint-transport','docs/research-artifacts/chained-transfer/norm-assisted-IC-01','.github/workflows/chained-transfer-norm-sampling.yml','pcc/claims','pcc/ledger.jsonl','docs/session-logs/2026-11-14.md','.resume/RESUME.md','problems/chained-transfer-new-jacobian-ic-cost-coverage.md']
paths=set(subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard','-z','--',*scope],cwd=r).split(b'\0'))-{b''};paths.add(b'experiments/chained-transfer-public-target/norm-assisted-ic/Cargo.lock');members={}
for name in sorted(paths):
 rel=name.decode();p=r/rel;assert p.is_file(),rel;target=o/'files'/rel;target.parent.mkdir(parents=True,exist_ok=True)
 if p.is_symlink():target.symlink_to(os.readlink(p))
 else:shutil.copyfile(p,target)
 raw=p.read_bytes();members[rel]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),symlink_target=os.readlink(p)if p.is_symlink()else None)
assert all(hashlib.sha256((o/'files'/p).read_bytes()).hexdigest()==v['sha256']for p,v in members.items())
(o/'source-members.json').write_text(json.dumps(members,indent=2)+'\n');(o/'tracked-worktree.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=r));shutil.copyfile(__file__,o/'original-snapshot-command.py')
(o/'base-and-restoration.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),repository='isogeny-labs/cryptanalysis',base=base,branch='research/chained-transfer-public-target-20261113',producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2',owned_files=len(members),restore='checkoutexactbase+producer;copyfiles/into consumer preservingrelative symlinktargets/types;originalfrozen784+manifest andgovernance checks;genuinecurrentbatchdata projectionclaims arrive separatelyafterthisledgerprefix',scope='ALL ownedpendingcode/784CI/workflow/faithful3bindings/PCCledger/86nativewholeXZ/fullproofcaptures/reporteditableassets/wholefinalPDF+relativealias/resume/journal/protocol/metadata;no privateglobalinstructions/env/credentials/temporarydownloadreference;capturedBEFORErawhandoffpayloadexists/no recursivepublicationdata',ledger_scope='exactprefixhere;ownsnapshotcustody/genuinepublicationmetadata laterappendseparately',native='9bc5e6/4082guards/225scalarpairs1125triples60ICpairs120reports/all15publiccases/15sharedFB30failures',written='e7a860/789d94a9a7afed533b/60uniqueconditionalbindings',report='510c8c/whole75055PDF/ALLfinalpagesviewed/canonical+relativelink',new_CI='a2feab/784portable+self785/tenphases/86JSON/17workflows327native60unique62actualchecks pendingnewsourcefullCI',original_checkpoint='b08916 succeededoriginalremote+localgate exactclean39b;laterdirtysource NOT performanceadmitted',next='wholedatahandoff/NEWguard09/exactgenuineFF/projections/normalconsumercommit/785full+17CI;thencompletearithmeticcoverage'),indent=2)+'\n')
print(json.dumps(dict(public_checkpoint_files=sum(p.is_file()for p in public.rglob('*')),private_exclusions=len(excluded),source_files=len(members),base=base)),flush=True)
