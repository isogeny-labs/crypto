"""I/O retention of actual five-object migration; no scientific verifier."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,lzma,subprocess,shutil
r=Path('/workspace/crypto');s=r/'research/chained_jacobian_transfers_20261110'
raw=Path('/workspace/scratch/ct55-g3-consumer-norm-publication-raw-01')
base='5fff3767f49c19065e2768b2feb09f73e1be15db';bot='5c527ee19276d1d9282a9a8884f4f8ec15b2364d'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==bot
assert subprocess.check_output(['git','rev-parse',bot+'^'],cwd=r,text=True).strip()==base
log=(raw/'whole-job.log').read_bytes()
assert log==json.loads((raw/'log-api.json').read_text())['structuredContent']['content'].encode()
assert log.index(b'6 remote objects replayed')<log.index(b'[detached HEAD 5c527ee19]')
jobs=json.loads((raw/'jobs-api.json').read_text())['structuredContent']['jobs']
assert len(jobs)==1 and jobs[0]['id']==131794658518 and jobs[0]['run_id']==43398333803 and jobs[0]['conclusion']=='success'
ff=Path('/workspace/scratch/ct56-g3-norm-artifact-ff-02')
assert all((ff/(p+'.exit')).read_text().strip()=='0' for p in ['fetch','exact-ff','artifact','wiring'])
for source,name in [(ff,'exact-ff'),(Path('/workspace/scratch/ct56-norm-root-raw-publication-01'),'normal-publication'),(Path('/workspace/scratch/ct56-g3-norm-raw-publication-discovery-01'),'source-discovery')]:
    shutil.copytree(source,raw/name)
shutil.copyfile(__file__,raw/'original-recorder.py')
objects=[]
panels={'g3-norm-consumer-raw-handoff-01':['static-01.tar.xz','static-02.tar.xz','static-03.tar.xz','unit-01.tar.xz','unit-02.tar.xz','cli-01.tar.xz']}
for name,files in panels.items():
    p=s/'evidence'/name/'.artifacts.json'
    shutil.copyfile(p,raw/(name+'-canonical-manifest.json'))
    manifest=json.loads(p.read_text())['files']
    assert set(manifest)==set(files)
    for file,entry in manifest.items():
        path=str((p.parent/file).relative_to(r))
        original=subprocess.check_output(['git','show',base+':'+path],cwd=r)
        assert len(original)==entry['bytes'] and hashlib.sha256(original).hexdigest()==entry['sha256']
        objects.append(dict(path=path,**entry))
assert len(objects)==6
data=dict(at=datetime.now(timezone.utc).isoformat(),run=43398333803,job=131794658518,conclusion='success',source=base,bot=bot,exact_bot_parent=base,exact_changed_paths=8,actual_remote_objects_replayed_BEFORE_bot=6,objects=objects,exact_local_FF=0,artifact_check=0,wiring_check=0,all_owned_dirty_bytes_and2175_current_union_inputs_preserved=True,old2132_unchanged_and_wholeold6prefix_retained=True,failed_stale_guard_FF01_preserved=True,whole_log_bytes=len(log),whole_log_sha256=hashlib.sha256(log).hexdigest(),standing='unsigned actual publication; separate from scientific/benchmark/main merge standing')
(raw/'publication.json').write_text(json.dumps(data,indent=2)+'\n')
subprocess.run(['python3','/workspace/scratch/ct55_pack_closed_tree.py','consumer-norm-publication-raw-01'],cwd=r,check=True)
out=s/'evidence/genus3-consumer-norm-publication-raw-01'
shutil.copyfile(raw/'publication.json',out/'publication.json')
z=lzma.compress(log,format=lzma.FORMAT_XZ,preset=9);assert lzma.decompress(z)==log
(out/'whole-job.log.xz').write_bytes(z)
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Unsigned ACTUAL SIXindependentnormwholearchivepublication:trusted-base43398333803/job131794658518SUCCESS SIXremoteobjectsreplayed BEFOREnormalbot5c527ee19/directparent5fff/EXACT8paths. All6canonicalmanifest size/SHA match originalconsumer custodyand sourceGitblobs;whole originalstatic01/02/03/unit01/02/CLI01 retained. ExactlocalFF/artifact/wiring0/allowned dirtybytesand2175CURRENTunioninputs preserved;old2132sourcehashesunchanged andwholeold20796SIXprefix intact afterauthorized7thappend. StaleoldguardFF01failedbeforemerge preserved/frozen8b570c correctionbeforeFF02;no native/mathchange. WholeUTF8job/API/stdXZ/everymemberrawarchivehash/roundtrip retained. Separate scientific/CI/benchmark standing.']
for name in ['custody.json','publication.json','whole-job.log.xz']:
    cmd+=['--proof','attestation:'+str((out/name).relative_to(r))]
cl=subprocess.check_output(cmd,cwd=r,text=True).strip()
Path('/workspace/scratch/ct56-g3-norm-actual-publication.claim').write_text(cl+'\n')
print(cl,len(log),len(z),flush=True)
