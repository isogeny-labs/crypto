"""Exact ordinary FF and dirty-file custody; no force/reset/stash."""
from pathlib import Path
import os,subprocess,json,hashlib,base64
r=Path('/workspace/crypto');base='5fff3767f49c19065e2768b2feb09f73e1be15db';bot='5c527ee19276d1d9282a9a8884f4f8ec15b2364d';out=Path('/workspace/scratch/ct56-g3-norm-artifact-ff-01');out.mkdir()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==base
env=os.environ.copy();n=int(env.get('GIT_CONFIG_COUNT','0'));env['GIT_CONFIG_COUNT']=str(n+1);env['GIT_CONFIG_KEY_'+str(n)]='http.https://github.com/.extraheader';env['GIT_CONFIG_VALUE_'+str(n)]='AUTHORIZATION: basic '+base64.b64encode(('x-access-token:'+env['GH_TOKEN']).encode()).decode();env['GIT_TERMINAL_PROMPT']='0'
def run(label,command,extra=None):
    v=subprocess.run(command,cwd=r,env=extra,capture_output=True,timeout=120);(out/(label+'.txt')).write_bytes(v.stdout+v.stderr);(out/(label+'.exit')).write_text(str(v.returncode)+'\n');print(label,v.returncode,flush=True);assert v.returncode==0;(out/(label+'.stdout')).write_bytes(v.stdout);return v
run('fetch',['git','fetch','--no-tags','--no-recurse-submodules','https://github.com/isogeny-labs/crypto.git',bot],env)
assert subprocess.check_output(['git','rev-parse',bot+'^'],cwd=r,text=True).strip()==base
prefix='research/chained_jacobian_transfers_20261110/evidence/'
panels={'g3-norm-consumer-raw-handoff-01':['static-01.tar.xz','static-02.tar.xz','static-03.tar.xz','unit-01.tar.xz','unit-02.tar.xz','cli-01.tar.xz']}
expected={prefix+name+'/'+file for name,files in panels.items() for file in ['.artifacts.json','.gitignore',*files]}
assert len(expected)==8
changed=set(subprocess.check_output(['git','diff','--name-only',base,bot],cwd=r,text=True).splitlines());assert changed==expected
names=set(subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard','-z','--','src/cryptanalysis/diem_quartic.rs','src/cryptanalysis/plane_quartic_pic.rs','research/chained_jacobian_transfers_20261110','pcc/claims','pcc/ledger.jsonl','docs/session-logs/2026-11-13.md','.resume/RESUME.md'],cwd=r).split(b'\0'))-{b''};owned={p.decode():hashlib.sha256((r/p.decode()).read_bytes()).hexdigest() for p in names};assert set(owned).isdisjoint(changed)
native=json.loads(Path('/workspace/scratch/ct55-g3-root-regression-02/before.json').read_text());assert len(native)==2133 and all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in native.items())
run('exact-ff',['git','merge','--ff-only',bot]);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==bot
assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v for p,v in owned.items());assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in native.items())
(out/'dirty-preservation.json').write_text(json.dumps(dict(base=base,bot=bot,exact_changed_paths=sorted(changed),owned_dirty_paths=owned,all_dirty_bytes_preserved=True,all2133_native_inputs_unchanged=True,force_reset_stash=False,scope='normal exact manifest bot FF;remote-byte publication still needs whole original job log'),indent=2)+'\n')
run('artifact',['python3','tools/artifacts/artifacts.py','check',base,bot]);run('wiring',['python3','tools/artifacts/wire_workflows.py','--check'])
for name in panels:
    p=r/prefix/name/'.artifacts.json';(out/(name+'-manifest.json')).write_bytes(p.read_bytes())
print('exactFF8paths,dirty and2133 sources preserved,artifact0,wiring0',flush=True)
