#!/usr/bin/env bash
printf 'called\n' >> /workspace/scratch/ct48-proper-rg-called-01
exit 127
