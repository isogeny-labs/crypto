#!/usr/bin/env bash
set -u
export PATH="/workspace/scratch/ct48-proper-no-rg:$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
full_root=/workspace/scratch/ct48-proper-full-02
date -u +%Y-%m-%dT%H:%M:%SZ > "$full_root/started.txt"
timeout 30m bash /workspace/scratch/ct48-proper-layout/cryptanalysis/experiments/chained-transfer-reference/check-proper.sh /workspace/scratch/ct48-proper-layout/crypto "$full_root/runs" > "$full_root/outer.txt" 2>&1
status=$?
printf '%s\n' "$status" > "$full_root/exit.txt"
date -u +%Y-%m-%dT%H:%M:%SZ > "$full_root/finished.txt"
sha256sum --check /workspace/scratch/ct48-kernel-checker-source-03.sha256 > "$full_root/original-inputs-after.txt" 2>&1
after=$?
printf '%s\n' "$after" > "$full_root/original-inputs-after.exit"
if [ -e /workspace/scratch/ct48-proper-rg-called-01 ]; then
  printf 'called\n' > "$full_root/rg-status.txt"
  exit 1
fi
printf 'not called\n' > "$full_root/rg-status.txt"
if [ "$status" -ne 0 ]; then tail -n 70 "$full_root/outer.txt"; exit "$status"; fi
if [ "$after" -ne 0 ]; then exit "$after"; fi
tail -n 25 "$full_root/outer.txt"
