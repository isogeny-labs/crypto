"""I/O-only exact-source freeze and original native admission controls."""
from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,shutil,os
layout=Path('/workspace/scratch/ct56-norm-replay-layout');c=layout/'cryptanalysis';up=layout/'crypto';r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-reference';out=Path('/workspace/scratch/ct56-g3-norm-full-02');out.mkdir()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=c,text=True).strip()=='069644bf59499e4172eb8bcdce5de8a6665da93f'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=up,text=True).strip()=='3d49af7f3d0a28e76b79e4825c9d2324e85853d2'
ref=c/'experiments/chained-transfer-reference/g3-norm-reference-01.sha256';before={}
for line in ref.read_text().splitlines():
 h,p=line.split('  ',1);path=(c/p).resolve();assert hashlib.sha256(path.read_bytes()).hexdigest()==h;before[str(path)]=h
assert len(before)==437
extra=up/'research/chained_jacobian_transfers_20261110/genus3-prime-descent/reference-02.sha256'
before[str(extra)]=hashlib.sha256(extra.read_bytes()).hexdigest()
assert len(before)==438
for name,h in before.items():
 p=Path(name);dest=out/'source'/p.relative_to(layout);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
(out/'before.json').write_text(json.dumps(before,indent=2)+'\n');shutil.copyfile(ref,out/'original-reference.sha256');shutil.copyfile(__file__,out/'prepare.py')
plan=dict(protocol='ac58df/c3b beforecode;integrationb4cd92',source='069644bf59499e4172eb8bcdce5de8a6665da93f',producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2',layout=str(layout),guards=438,full_timeout_s=2100,initial_admission=['missing native tool','wrong actual producerHEAD','dirty protected source','output inside source'],expected_control_exit=2,expected_controls_create_no_output=True,full_scope='23outer+20inner originalnative/tee0;producer4+CLI9+twooriginalproofmodules+11bindings;consumer4fullJac/source+CLI9+two13declarationgates+13exactbindings;allportable/final/cleanliness guards',build_cache=str(out)+'-build-cache',cache_fresh_outside_raw=True,falsification='any original admission/phase/tee/guard/domain failure;retain whole attempt,neverreduce scope',scope='local development correctness replay;no benchmark,paidexperiment orcost ratio')
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
d=s/'evidence/g3-norm-full-plan-02';d.mkdir();shutil.copyfile(out/'plan.json',d/'plan.json')
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Freeze independentnorm cleanfull01 BEFOREadmission/nativeexecution:EXACTconsumer069644bf/producer3d cleanisolatedphysicalCargo siblings/437portable+1exactproducerreference=438source snapshots+hashes/freshoutsidecache/2100seconds. Fouractual admissionnegativecontrols expected2/nofile. Full23outer+20inner native/tee0,completeproducer/newnorm4+9CLI/two13declarationgates/13exactbindings/finalportable+cleanliness+outerguards required. Correctnessonly,no paidbenchmark,coldcost ratio orsignedexecutionproof.','--proof','attestation:'+str((d/'plan.json').relative_to(r))]
print(subprocess.check_output(cmd,cwd=r,text=True).strip(),flush=True)
driver=c/'experiments/chained-transfer-reference/check-g3-norm.sh';base_env=os.environ.copy();base_env['PATH']=str(Path.home()/'.cargo/bin')+':'+str(Path.home()/'.elan/bin')+':'+base_env['PATH'];base_env['RUSTUP_TOOLCHAIN']='1.99.1';base_env['ELAN_TOOLCHAIN']='leanprover/lean4:v4.35.0';base_env['CARGO_TARGET_DIR']=str(out)+'-build-cache'
ad=out/'admission';ad.mkdir();results=[]
def test(name,dest,env=base_env):
 v=subprocess.run(['bash',str(driver),str(up),str(dest)],cwd=c,env=env,capture_output=True,timeout=60)
 (ad/(name+'.log')).write_bytes(v.stdout+v.stderr);(ad/(name+'.exit')).write_text(str(v.returncode)+'\n')
 results.append(dict(name=name,original_exit=v.returncode,output_created=dest.exists()));(ad/'results.json').write_text(json.dumps(results,indent=2)+'\n');assert v.returncode==2 and not dest.exists(),results[-1]
missing=base_env.copy();missing['PATH']='/usr/bin:/bin';test('missing-tool',out/'missing-tool-output',missing)
try:
 v=subprocess.run(['git','checkout','--detach','a719f6f75f67576ce3835d8acc6e47bb25a3cbe4'],cwd=up,capture_output=True);(ad/'wrong-head-checkout.log').write_bytes(v.stdout+v.stderr);assert v.returncode==0
 test('wrong-head',out/'wrong-head-output')
finally:
 v=subprocess.run(['git','checkout','--detach','3d49af7f3d0a28e76b79e4825c9d2324e85853d2'],cwd=up,capture_output=True);(ad/'restore-head.log').write_bytes(v.stdout+v.stderr);assert v.returncode==0
p=c/'experiments/chained-transfer-reference/g3-norm-checker/README.md';original=p.read_bytes()
try:p.write_bytes(original+b'\nAdmission dirty-source control.\n');test('dirty-source',out/'dirty-source-output')
finally:p.write_bytes(original)
test('output-in-source',c/'experiments/chained-transfer-reference/g3-norm-checker/admission-should-not-exist')
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=c)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=up)
(ad/'restoration.json').write_text(json.dumps(dict(all438_unchanged=True,clean_consumer=True,clean_producer=True,four_original_exits=[x['original_exit'] for x in results],no_outputs=True),indent=2)+'\n')
script='''#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export ELAN_TOOLCHAIN=leanprover/lean4:v4.35.0
export CARGO_TARGET_DIR=OUTPUT-build-cache
cd /workspace/scratch/ct56-norm-replay-layout/cryptanalysis
out=OUTPUT
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
set +e
timeout 2100 bash experiments/chained-transfer-reference/check-g3-norm.sh ../crypto "$out/driver" > "$out/native.log" 2>&1
status=$?
printf '%s\\n' "$status" > "$out/native.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARDS'
from pathlib import Path
import json,hashlib,sys
o=Path(sys.argv[1]);before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before};changed=[p for p in before if before[p]!=after[p]]
(o/'after.json').write_text(json.dumps(after,indent=2)+'\\n');(o/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\\n');raise SystemExit(bool(changed))
GUARDS
guard=$?
printf '%s\\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
'''.replace('OUTPUT',str(out))
launcher=Path(str(out)+'.sh');launcher.write_text(script);shutil.copyfile(launcher,out/'original-command.sh')
with (r/'docs/session-logs/2026-11-13.md').open('a') as f:f.write(f'''\n## {datetime.now(timezone.utc).isoformat()} — independentnorm exactsource admission/full prepared (Codex)

### What was done (commands, files, features)
- Scientific069644bf publishednormalnonforce0/184paths/governancea8379c. Cleanisolatedexact069/3d siblings/all438nativeinputs frozen. Fouroriginaladmissioncontrols exit2/nooutput;all438restored/cleansiblings. Fullplan andsource/command/environment boundaries retained at{out};nativefull notyetaccepted. [pcc:unverified]

### Decisions made (and why)
- Launchoriginalnewdriver under2100seconds/freshoutsidecache;require23outer+20producerpairs0/completefullnormscope/proofs/bindings/CLI/finalguards. Freeze selected sources untiloriginalterminal+finalguards. No paidbenchmark orcostratio.

### Open threads (unfinished, pick up next time)
- Originalfull terminal/custody/acceptance ordiagnosis;new7CIonexact069;GitHubqueue/checkpoints thennextunblockedresearch.

### Errors (what went wrong, how it was handled)
- No fullresultyet. Existingrootfixtureaccess/mainledger/signing/conflict/benchmarkadmission gaps remain separate;nativeunit/CLI/partialformal results retained unsigned.
''')
print(launcher,'four admission2/nofile/restored438/clean',flush=True)
