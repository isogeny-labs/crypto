"""I/O custody of the actual four-object trusted-base publication."""
from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, shutil, tarfile, io, lzma, subprocess
r=Path('/workspace/crypto');s=r/'research/chained_jacobian_transfers_20261110'
raw=Path('/workspace/scratch/ct55-g3-artifact-publication-raw-01')
base='eab262e36c633668ac0550254eb90679f7283bc6';bot='f95c2ab432692cbbe7ae090cc8eb61e64ae32490'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==bot
assert subprocess.check_output(['git','rev-parse',bot+'^'],cwd=r,text=True).strip()==base
jobs=json.loads((raw/'jobs-api.json').read_text())['structuredContent']['jobs']
assert len(jobs)==1 and jobs[0]['id']==131703822791 and jobs[0]['run_id']==43370167545 and jobs[0]['conclusion']=='success'
log=(raw/'whole-job.log').read_bytes()
assert log==json.loads((raw/'log-api.json').read_text())['structuredContent']['content'].encode()
assert log.index(b'4 remote objects replayed')<log.index(b'[detached HEAD f95c2ab43]')
objects=[]
for kind,names in [('static',['static-01.tar.xz','static-02.tar.xz','static-03.tar.xz']),('unit',['unit-01.tar.xz'])]:
    p=s/'evidence'/('genus3-'+kind+'-archive-handoff-01')/'.artifacts.json'
    shutil.copyfile(p,raw/(kind+'-canonical-manifest.json'))
    m=json.loads(p.read_text());assert set(m['files'])==set(names)
    for name,item in m['files'].items():
        original=Path('/workspace/scratch')/('ct55-g3-'+name.removesuffix('.tar.xz')+'-whole-raw.tar.xz')
        assert original.stat().st_size==item['bytes'] and hashlib.sha256(original.read_bytes()).hexdigest()==item['sha256']
        objects.append(dict(path=str(p.relative_to(r)),file=name,**item,S3_object='s3://setec-astronomy-artifacts/store/sha256/'+item['sha256'][:2]+'/'+item['sha256']))
shutil.copytree('/workspace/scratch/ct55-g3-artifact-ff-01',raw/'exact-ff')
shutil.copytree('/workspace/scratch/ct55-root-recovery-handoff-publication-01',raw/'normal-publication')
shutil.copytree('/workspace/scratch/ct55-g3-artifact-discovery-01',raw/'discovery')
shutil.copyfile('/workspace/scratch/ct55_record_g3_publication.py',raw/'original-recorder.py')
assert all((raw/'exact-ff'/(x+'.exit')).read_text().strip()=='0' for x in ['fetch','exact-ff','artifact','wiring'])
members={};b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w',format=tarfile.PAX_FORMAT) as tf:
    for p in sorted(raw.rglob('*')):
        if p.is_file():
            name=str(p.relative_to(raw));v=p.read_bytes();members[name]=dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest());tf.add(p,arcname=name,recursive=False)
data=b.getvalue();z=lzma.compress(data,format=lzma.FORMAT_XZ,preset=9);assert lzma.decompress(z)==data
with tarfile.open(fileobj=io.BytesIO(lzma.decompress(z))) as tf:
    assert set(tf.getnames())==set(members)
    for item in tf.getmembers():assert hashlib.sha256(tf.extractfile(item).read()).hexdigest()==members[item.name]['sha256']
out=s/'evidence/genus3-artifact-publication-01';out.mkdir()
(out/'whole-raw.tar.xz').write_bytes(z);logz=lzma.compress(log,format=lzma.FORMAT_XZ,preset=9);assert lzma.decompress(logz)==log
(out/'whole-job.log.xz').write_bytes(logz);(out/'members.json').write_text(json.dumps(members,indent=2)+'\n')
(out/'custody.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),run=43370167545,job=131703822791,conclusion='success',base=base,bot=bot,actual_whole_remote_objects_replayed_before_bot=4,objects=objects,exact_local_FF=0,artifact_check=0,wiring_check=0,whole_log_bytes=len(log),whole_log_sha256=hashlib.sha256(log).hexdigest(),whole_log_xz_bytes=len(logz),whole_log_xz_sha256=hashlib.sha256(logz).hexdigest(),whole_files=len(members),raw_tar_sha256=hashlib.sha256(data).hexdigest(),archive_bytes=len(z),archive_sha256=hashlib.sha256(z).hexdigest(),every_member_hash=True,exact_standard_tar_xz_roundtrip=True,standing='unsigned publication/custody observation;not scientific signature;followupno-op not uploadproof'),indent=2)+'\n')
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Unsigned ACTUAL G3 FOUR whole raw archive publication:trusted-base43370167545/job131703822791success,4remoteobjectsreplayed BEFORE normalbotf95c2ab/directparenteab262/EXACT8expectedpaths/exactlocalFF0/artifact0/wiring0/allowned dirtybytesand807guardsunchanged. Three static archives andfailedunit01 actualmanifest sizes/hashes match intactoriginals. Whole427120byteUTF8log exactAPIbytes,wholepublicationtreeONEstdtarXZ/everymemberrawarchivehash/exactroundtrip retained. Followupno-opnotuploadproof;no signedscientific/execution/costverdict.']
for p in sorted(out.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(r))]
cl=subprocess.run(cmd,cwd=r,capture_output=True,text=True,check=True).stdout.strip();Path('/workspace/scratch/ct55-g3-artifact-publication.claim').write_text(cl+'\n')
print(cl,len(z),len(logz),len(members),flush=True)
