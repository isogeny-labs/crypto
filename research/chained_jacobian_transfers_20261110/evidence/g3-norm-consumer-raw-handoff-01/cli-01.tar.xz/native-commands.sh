#!/usr/bin/env bash
set -euo pipefail
out=/workspace/scratch/ct56-g3-norm-cli-01
cargo build --offline --locked --manifest-path experiments/chained-transfer-reference/g3-norm-checker/Cargo.toml --bin chained-g3-canonical-norm
bin="$CARGO_TARGET_DIR/debug/chained-g3-canonical-norm"
for q in 5 7 11; do
  "$bin" "$out/q$q-request.json" "$out/q$q-output.json" > "$out/q$q.log" 2>&1
  printf '0\n' > "$out/q$q.exit"
  jq -e '.schema=="g3-canonical-norm-result/v1" and .count==3 and (.points|length)==3' "$out/q$q-output.json" >/dev/null
done
for name in foreign model noncanonical tag offcurve rank unknown-scalar schema too-many oversized; do
  set +e
  "$bin" "$out/$name-request.json" "$out/$name-output.json" > "$out/$name.log" 2>&1
  status=$?
  set -e
  printf '%s\n' "$status" > "$out/$name.exit"
  test "$status" -eq 2
  test ! -e "$out/$name-output.json"
done
cp "$out/q5-output.json" "$out/q5-original-output.json"
set +e
"$bin" "$out/q5-request.json" "$out/q5-output.json" > "$out/overwrite.log" 2>&1
status=$?
set -e
printf '%s\n' "$status" > "$out/overwrite.exit"
test "$status" -eq 2
cmp "$out/q5-output.json" "$out/q5-original-output.json"
set +e
"$bin" "$out/q5-request.json" "$out/extra-output.json" extra > "$out/extra.log" 2>&1
status=$?
set -e
printf '%s\n' "$status" > "$out/extra.exit"
test "$status" -eq 2
test ! -e "$out/extra-output.json"
printf 'G3_CLI complete:3positive requests/9points;12negative process controls\n'
