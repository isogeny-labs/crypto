#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct56-g3-norm-unit-02-build-cache
cd /workspace/cryptanalysis
out=/workspace/scratch/ct56-g3-norm-unit-02
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
rustc -Vv > "$out/rustc.txt" 2>&1
cargo -V > "$out/cargo.txt" 2>&1
uname -a > "$out/host.txt" 2>&1
set +e
timeout 900 cargo test --release --offline --locked --manifest-path experiments/chained-transfer-reference/g3-norm-checker/Cargo.toml --lib -- --nocapture --test-threads=1 > "$out/native.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/native.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARDS'
from pathlib import Path
import hashlib,json,sys
out=Path(sys.argv[1]);before=json.loads((out/'before.json').read_text())
after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before}
changed=[p for p in before if before[p]!=after[p]]
(out/'after.json').write_text(json.dumps(after,indent=2)+'\n')
(out/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\n')
raise SystemExit(bool(changed))
GUARDS
guard=$?
printf '%s\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
