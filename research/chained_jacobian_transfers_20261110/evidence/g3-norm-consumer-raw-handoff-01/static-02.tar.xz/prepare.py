"""I/O source custody and launch preparation; no mathematical computation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, subprocess, sys, shlex

r = Path('/workspace/cryptanalysis')
s = r / 'experiments/chained-transfer-reference'
up = Path('/workspace/crypto')
phase, attempt = sys.argv[1:]
assert phase in ('static', 'unit') and attempt.isdecimal()
out = Path('/workspace/scratch') / ('ct56-g3-norm-' + phase + '-' + attempt)
out.mkdir()
refs = json.loads((s/'evidence/g3-norm-primary-01/upstream-current-inputs.json').read_text())
assert len(refs) == 343
before = {str(up/p): h for p,h in refs.items()}
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p,h in before.items())
workflow = r/'.github/workflows/chained-transfer-reference.yml'
assert workflow.read_bytes() == (s/'evidence/g3-norm-primary-01/six-original-jobs.yml').read_bytes()
selected = list((s/'g3-norm-checker').rglob('*')) + list((s/'evidence/g3-norm-primary-01').rglob('*'))
selected += [workflow, s/'G3_NORM_REPLAY_PROTOCOL.md', s/'G3_CANONICAL_NORM_LEAD.md']
for p in selected:
    if p.is_file() and '/target/' not in str(p):
        before[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
for name, h in sorted(before.items()):
    p=Path(name)
    assert hashlib.sha256(p.read_bytes()).hexdigest() == h
    dest=out/'source'/p.relative_to('/workspace')
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(p,dest)
(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
manifest='experiments/chained-transfer-reference/g3-norm-checker/Cargo.toml'
command=['cargo','clippy','--all-targets','--offline','--locked','--manifest-path',manifest,'--','-D','warnings'] if phase=='static' else ['cargo','test','--release','--offline','--locked','--manifest-path',manifest,'--lib','--','--nocapture','--test-threads=1']
plan=dict(protocol='ac58df published c3b8d74c/ready PR1521 BEFORE code',phase=phase,attempt=attempt,command=command,timeout_s=900,guards=len(before),upstream343_unchanged=True,whole_old_six_jobs_bytes=20796,cache=str(out)+'-build-cache',cache_outside_raw=True,prediction='strict compile warnings zero' if phase=='static' else 'all FOUR unfiltered tests cover complete fixed q=5,7,11 source and independently counted full Jacobian domains, both compositions [2], controls and odd recovery',falsification='original nonzero exit, failed domain/control or changed guard; preserve whole attempt and diagnose without reducing acceptance',scope='local development correctness check; no benchmark, timing ratio, IC solver or paid execution')
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
script='''#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=OUTPUT-build-cache
cd /workspace/cryptanalysis
out=OUTPUT
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
rustc -Vv > "$out/rustc.txt" 2>&1
cargo -V > "$out/cargo.txt" 2>&1
uname -a > "$out/host.txt" 2>&1
set +e
timeout 900 COMMAND > "$out/native.log" 2>&1
status=$?
printf '%s\\n' "$status" > "$out/native.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARDS'
from pathlib import Path
import hashlib,json,sys
out=Path(sys.argv[1]);before=json.loads((out/'before.json').read_text())
after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before}
changed=[p for p in before if before[p]!=after[p]]
(out/'after.json').write_text(json.dumps(after,indent=2)+'\\n')
(out/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\\n')
raise SystemExit(bool(changed))
GUARDS
guard=$?
printf '%s\\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
'''.replace('OUTPUT',str(out)).replace('COMMAND',shlex.join(command))
launcher=Path(str(out)+'.sh');launcher.write_text(script)
shutil.copyfile(launcher,out/'original-command.sh')
shutil.copyfile(__file__,out/'prepare.py')
with (r/'docs/session-logs/2026-11-13.md').open('a') as f:
    f.write(f'''\n## {datetime.now(timezone.utc).isoformat()} — independent norm {phase}{attempt} frozen (Codex)

### What was done (commands, files, features)
- Protocol ac58df was published c3b8d74c with ready PR1521 before code. Prepared {out}: whole selected source/command/environment plan, {len(before)} guards including all343 producer inputs and whole old six-job workflow. New Rust implementation uses original engines; no native acceptance yet. [pcc:unverified]

### Decisions made (and why)
- Run this local development correctness command under900seconds with fresh cache outside raw. Preserve original terminal and final guards before changing selected inputs. No benchmark or paid experiment launch.

### Open threads (unfinished, pick up next time)
- Original terminal and guards; archive all outputs, then diagnose or proceed through full classes, both compositions, CLI, written proof, Lean and independent replay.

### Errors (what went wrong, how it was handled)
- No norm native result yet. Existing producer/root fixture and merge gates remain separate. Never reduce the frozen complete-domain criteria.
''')
print(launcher, len(before), flush=True)
