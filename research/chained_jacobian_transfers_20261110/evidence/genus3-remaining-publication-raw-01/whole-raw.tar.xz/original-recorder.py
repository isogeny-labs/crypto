"""I/O retention of actual five-object migration; no scientific verifier."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,lzma,subprocess,shutil
r=Path('/workspace/crypto');s=r/'research/chained_jacobian_transfers_20261110'
raw=Path('/workspace/scratch/ct55-g3-remaining-publication-raw-01')
base='3d49af7f3d0a28e76b79e4825c9d2324e85853d2';bot='9ee50f2a2090e28d1ca41cec416b77779955604f'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==bot
assert subprocess.check_output(['git','rev-parse',bot+'^'],cwd=r,text=True).strip()==base
log=(raw/'whole-job.log').read_bytes()
assert log==json.loads((raw/'log-api.json').read_text())['structuredContent']['content'].encode()
assert log.index(b'5 remote objects replayed')<log.index(b'[detached HEAD 9ee50f2a2]')
jobs=json.loads((raw/'jobs-api.json').read_text())['structuredContent']['jobs']
assert len(jobs)==1 and jobs[0]['id']==131761261514 and jobs[0]['run_id']==43388106212 and jobs[0]['conclusion']=='success'
ff=Path('/workspace/scratch/ct55-g3-artifact-ff-03')
assert all((ff/(p+'.exit')).read_text().strip()=='0' for p in ['fetch','exact-ff','artifact','wiring'])
for source,name in [(ff,'exact-ff'),(Path('/workspace/scratch/ct55-g3-ci-repair-publication-01'),'normal-publication'),(Path('/workspace/scratch/ct55-g3-remaining-publication-discovery-01'),'source-discovery')]:
    shutil.copytree(source,raw/name)
shutil.copyfile(__file__,raw/'original-recorder.py')
objects=[]
panels={'genus3-root-regression-02':['whole-raw.tar.xz','members.json.xz'],'genus3-root-fixture-diagnostic-01':['whole-raw.tar.xz'],'genus3-ci-control-raw-01':['whole-raw.tar.xz'],'genus3-latest-publication-raw-01':['whole-raw.tar.xz']}
for name,files in panels.items():
    p=s/'evidence'/name/'.artifacts.json'
    shutil.copyfile(p,raw/(name+'-canonical-manifest.json'))
    manifest=json.loads(p.read_text())['files']
    assert set(manifest)==set(files)
    for file,entry in manifest.items():
        path=str((p.parent/file).relative_to(r))
        original=subprocess.check_output(['git','show',base+':'+path],cwd=r)
        assert len(original)==entry['bytes'] and hashlib.sha256(original).hexdigest()==entry['sha256']
        objects.append(dict(path=path,**entry))
assert len(objects)==5
data=dict(at=datetime.now(timezone.utc).isoformat(),run=43388106212,job=131761261514,conclusion='success',source=base,bot=bot,exact_bot_parent=base,exact_changed_paths=13,actual_remote_objects_replayed_BEFORE_bot=5,objects=objects,exact_local_FF=0,artifact_check=0,wiring_check=0,all_owned_dirty_bytes_and2133_native_inputs_preserved=True,whole_log_bytes=len(log),whole_log_sha256=hashlib.sha256(log).hexdigest(),standing='unsigned actual publication; separate from scientific/benchmark/main merge standing')
(raw/'publication.json').write_text(json.dumps(data,indent=2)+'\n')
subprocess.run(['python3','/workspace/scratch/ct55_pack_closed_tree.py','remaining-publication-raw-01'],cwd=r,check=True)
out=s/'evidence/genus3-remaining-publication-raw-01'
shutil.copyfile(raw/'publication.json',out/'publication.json')
z=lzma.compress(log,format=lzma.FORMAT_XZ,preset=9);assert lzma.decompress(z)==log
(out/'whole-job.log.xz').write_bytes(z)
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Unsigned ACTUAL remainingG3 rawpublication:trusted-base43388106212/job131761261514SUCCESS,FIVEremoteobjectsreplayed BEFOREnormalbot9ee50f2a2/directparent3d49af7/EXACT13paths. Root02 whole8950824+completeindex95072,fixturediagnostic89496,CIcontrol2128124,latestpublication66532;all canonical manifest size/SHA match original sourceGitblobs. ExactlocalFF/artifact/wiring0/allowned dirtybytesand2133nativeinputs preserved. WholeUTF8job/API/stdXZ/memberrawarchivehash/roundtrip retained. No new native acceptance,globalrootpass,mathematicalsignature or computational advantage.']
for name in ['custody.json','publication.json','whole-job.log.xz']:
    cmd+=['--proof','attestation:'+str((out/name).relative_to(r))]
cl=subprocess.check_output(cmd,cwd=r,text=True).strip()
Path('/workspace/scratch/ct55-g3-remaining-actual-publication.claim').write_text(cl+'\n')
print(cl,len(log),len(z),flush=True)
