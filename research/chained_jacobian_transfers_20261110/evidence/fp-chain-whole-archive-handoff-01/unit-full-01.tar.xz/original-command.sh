#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct54-fp-chain-tests-01-build-cache
export CARGO_TERM_COLOR=never
cd /workspace/cryptanalysis
out=/workspace/scratch/ct54-fp-chain-tests-01
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
set +e
timeout 900 cargo test --manifest-path experiments/chained-transfer-reference/fp-chain-checker/Cargo.toml --release --offline --locked -- --nocapture > "$out/tests.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/tests.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - <<'PY'
from pathlib import Path
import json,hashlib
p=Path('/workspace/scratch/ct54-fp-chain-tests-01');a=json.loads((p/'before.json').read_text());b={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in a};changed=[f for f in a if a[f]!=b[f]];(p/'after.json').write_text(json.dumps(b,indent=2)+'\n');(p/'guards.json').write_text(json.dumps({'count':len(a),'changed':changed},indent=2)+'\n');raise SystemExit(bool(changed))
PY
guard=$?
printf '%s\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
