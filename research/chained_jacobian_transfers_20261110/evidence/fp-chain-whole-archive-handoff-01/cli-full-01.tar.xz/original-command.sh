#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct54-fp-chain-cli-01-build-cache
export CARGO_TERM_COLOR=never
out=/workspace/scratch/ct54-fp-chain-cli-01
mkdir "$out" || exit 2
cd /workspace/cryptanalysis
cp /workspace/scratch/ct54-fp-chain-tests-01/before.json "$out/before.json"
python3 - <<'PY'
from pathlib import Path
import json,hashlib,shutil
out=Path('/workspace/scratch/ct54-fp-chain-cli-01');before=json.loads((out/'before.json').read_text())
for f,h in before.items():
 p=Path(f);assert hashlib.sha256(p.read_bytes()).hexdigest()==h,f
 dest=out/'source'/p.relative_to('/workspace');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
PY
if [ "$?" -ne 0 ]; then exit 2; fi
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
set +e
timeout 300 cargo run --manifest-path experiments/chained-transfer-reference/fp-chain-checker/Cargo.toml --offline --locked -- experiments/chained-transfer-reference/fp-chain-checker/fixtures/c0-t20.json > "$out/cli.json" 2> "$out/cli-build.log"
status=$?
printf '%s\n' "$status" > "$out/cli.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - <<'PY'
from pathlib import Path
import json,hashlib
out=Path('/workspace/scratch/ct54-fp-chain-cli-01');before=json.loads((out/'before.json').read_text());after={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in before};changed=[f for f in before if before[f]!=after[f]];(out/'after.json').write_text(json.dumps(after,indent=2)+'\n');(out/'guards.json').write_text(json.dumps({'count':len(before),'changed':changed},indent=2)+'\n');raise SystemExit(bool(changed))
PY
guard=$?
printf '%s\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
