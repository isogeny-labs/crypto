#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct57-n4-unit-01-build-cache
export N4_ARITHMETIC_OBSERVER=enabled
bash /workspace/cryptanalysis/experiments/chained-transfer-public-target/norm-arithmetic-audit/quadratic-canary.sh /workspace/scratch/ct75-norm-arithmetic-layout-01 /workspace/scratch/ct75-norm-arithmetic-quad-canaries-03
