"""Immediate File Service downloads; private URLs stay outside evidence."""
from pathlib import Path
import json,urllib.request,hashlib,zipfile
p=Path('/workspace/scratch/ct74-norm-halving-own-CI-01');rows=json.loads(Path('/workspace/scratch/private-ct74-norm-artifact-downloads-01.json').read_text())
for row in rows:
 label=row['label'];meta=row['meta'];target=p/(label+'-artifact.zip')
 with urllib.request.urlopen(row['url'],timeout=50)as r:body=r.read()
 assert len(body)==meta['size_in_bytes'];digest=hashlib.sha256(body).hexdigest();assert meta['digest']=='sha256:'+digest;target.write_bytes(body);(p/(label+'-artifact-metadata.json')).write_text(json.dumps(meta,indent=2)+'\n');print(label,len(body),digest,flush=True)
for row in rows:
 label=row['label'];root=p/(label+'-artifact-members');root.mkdir();members=[]
 with zipfile.ZipFile(p/(label+'-artifact.zip'))as z:
  for item in z.infolist():
   path=Path(item.filename);assert not path.is_absolute()and'..'not in path.parts
   if item.is_dir():(root/path).mkdir(parents=True,exist_ok=True);continue
   body=z.read(item);dest=root/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(body);members.append({'path':item.filename,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
 (p/(label+'-artifact-members.json')).write_text(json.dumps({'every_file_member_retained':True,'files':members},indent=2)+'\n');print(label,'allmembers',len(members),flush=True)
