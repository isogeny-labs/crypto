#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct57-n4-unit-01-build-cache
export N4_ARITHMETIC_OBSERVER=enabled
root=/workspace/cryptanalysis/experiments/chained-transfer-public-target
bash "$root/arithmetic-audit/canary.sh" /workspace/scratch/ct75-norm-arithmetic-layout-01 /workspace/scratch/ct75-norm-arithmetic-old-canaries-01 > /workspace/scratch/ct75-norm-arithmetic-old-canary-caller-01.txt 2>&1
status=$?
printf '%s\n' "$status" > /workspace/scratch/ct75-norm-arithmetic-old-canary-caller-01.exit
if [[ $status != 0 ]]; then exit "$status"; fi
bash "$root/norm-arithmetic-audit/quadratic-canary.sh" /workspace/scratch/ct75-norm-arithmetic-layout-01 /workspace/scratch/ct75-norm-arithmetic-quad-canaries-01 > /workspace/scratch/ct75-norm-arithmetic-quad-canary-caller-01.txt 2>&1
status=$?
printf '%s\n' "$status" > /workspace/scratch/ct75-norm-arithmetic-quad-canary-caller-01.exit
exit "$status"
