"""Reclaim closed external derivative libraries only, retaining every actual executable."""
from pathlib import Path
import hashlib,json,lzma,subprocess
s=Path('/workspace/scratch');roots=[s/'ct58-public-full-01-build-cache',s/'ct58-public-full-02-build-cache'];held=json.loads((s/'ct74-norm-halving-handoff-16/current-inputs.json').read_text());active=subprocess.check_output(['ps','-eo','pid,args'],text=True)
assert not any(('cargo 'in line or 'rustc 'in line)and '<defunct>'not in line and 'python3'not in line and 'bash -lc'not in line for line in active.splitlines())
files=[p for root in roots for p in sorted(root.rglob('*'))if p.is_file()and p.suffix in ['.rlib','.rmeta','.o']]
assert files and all(str(p)not in held for p in files)
rows=[{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in files]
receipt=s/'ct75-closed-public-dependency-cleanup-01.json.xz';assert not receipt.exists();receipt.write_bytes(lzma.compress((json.dumps({'scope':'closed external .rlib/.rmeta/.o caches only; all source, native output, actual executables and sealed B full cache untouched','roots':list(map(str,roots)),'outside_all_guard16_paths':True,'whole_files':rows},indent=2)+'\n').encode()))
for p in files:p.unlink()
print('closed derived dependency bytes',sum(x['bytes']for x in rows),'files',len(files),'whole receipt',receipt)
