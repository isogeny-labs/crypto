"""Render the prospective protocol only. No scientific computations."""
from pathlib import Path
import hashlib,json,subprocess
import typst
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';p=s/'reports/norm-halving-proposal-01';p.mkdir()
old='Ciani-Jac-pi0-v2-3ba99ad5742ad62540f8addbbe153572696d2e595f64cd2c1b0b52e51ff351a4'
new='Ciani-Jac-odd-product-v1-7ea9d0f9d1a48a48489425beab48274fca7bd0848e47a0bac3a027c01601e2c4'
dot='''digraph norm_halving {
 graph [rankdir=LR,bgcolor="white",fontname="DejaVu Sans",nodesep=.22,ranksep=.32];
 node [shape=box,style="rounded",fontname="DejaVu Sans",fontsize=11,margin=.10];
 edge [fontname="DejaVu Sans",fontsize=9,color="#5d6770",style=dashed];
 x [label="J0(F223) input\noriginal class/model/origin\nshared admission counted",color="#295477"];
 n [label="N0(x) = Q in E(K)\nK=F223[z]/(z^3-3)"];
 b [label="STRONG SCALAR BASELINE\n[1386537]Q on E(K)\nCRT x2=[ell]x on J0",color="#966122"];
 h [label="NORM-HALVING CANDIDATE\nall four [2]a=Q in E(L)\nL=F223[w]/(w^6-3)",color="#486d54"];
 bp [label="Phi1 gamma([1386537]Q)\nsubtract beta(x2)"];
 hp [label="d=x-Phi0(a)=Phi0(t)\nt in actual E[2](K)\nreturn Psi(a)+Psi(t)"];
 y [label="J1(F223) output\nmatched degree13 beta\nall four corrected lifts agree",color="#295477"];
 ref [label="FROZEN COMPLETE-C REFERENCE\nall448 exceptional classes\npublic/cofactor/addition controls",shape=note];
 x -> n [label="actual norm"];
 x -> b [label="same admitted input"];
 n -> b;
 n -> h;
 b -> bp;
 h -> hp;
 bp -> y;
 hp -> y;
 ref -> y [label="whole-output equality required"];
}'''
(p/'flow.dot').write_text(dot)
subprocess.run(['dot','-Tsvg',str(p/'flow.dot'),'-o',str(p/'flow.svg')],check=True)
data=dict(status='PROSPECTIVE: no implementation result, proof pass, timing or advantage yet',old_model=old,new_model=new,protocol='../../NORM_HALVING_PROTOCOL_01.md',review='../../evidence/norm-halving-primary-review-01/sources.json',primary_review_claim='PCC-20261114-3da2fc',all_graph_arrows='proposed evaluation routes; dashed, not verification marks',quantitative_graph='not drawn: no new comparable measurements exist',canonical_graphs_checked=['../beta-complete-rational-01/complete-diagram.dot','../beta-rational-lift-01/lift-diagram.dot'],existing_graph_decision='accepted complete-C and historical A/B scope unchanged; this proposal adds a separate diagram',scope='rendering of prospective protocol and actual frozen identities only')
(p/'flow.diagram.json').write_text(json.dumps(data,indent=2)+'\n')
typ=r'''#set page(paper: "a4", margin: 14mm)
#set text(font: "DejaVu Sans", size: 9.4pt)
#set par(leading: 0.55em)
#set heading(numbering: none)
#let d=json("flow.diagram.json")
#text(size: 18pt, weight: "bold")[Norm-halving a degree-13 transfer]
#v(3pt)
#text(fill: rgb("#966122"), weight: "bold")[PROSPECTIVE / UNSIGNED — native and proof outcomes pending]

The matched rational map beta: J0(F223) → J1(F223) already has the complete-C evaluator. This proposal compares a direct elliptic norm-halving implementation against an optimized norm-assisted scalar baseline. The original implementation, inputs and negative records stay frozen.

#image("flow.svg", width: 100%, height: 79mm, fit: "contain")
#text(size: 8pt)[Dashed arrows are proposed evaluation routes. No performance data exist for this comparison, so the diagram explains the algorithm; it is not a measured cost graph.]

== Strengthen the baseline first
#raw("x2=[ell]x; k=1386537; 2k=ell+1\nbaseline(x)=Phi1 gamma([k]N0(x)) - beta(x2)", block: true)
Move inverse-two multiplication to E(K), retaining the Jacobian CRT projection. Include the cofactor table, constructor and the same admission/output checks in both arms. Selected call counts do not price primitive operations.

== Candidate and required correction
Compute Q=N0(x); choose a half a in E(L). Retain d=x-Phi0(a), an actual two-torsion correction t with Phi0(t)=d, and return Psi(a)+Psi(t), where Psi=Phi1 gamma. Check the corrected lift a+t and require all four choices of half to give the same complete-C answer. Reverse with the actual dual.

== Exact models
#text(size: 8pt)[J0: #d.old_model]

#text(size: 8pt)[J1: #d.new_model]

K=F223[z]/(z³−3), L=F223[w]/(w⁶−3), z↦w². E has a=(214,144,205), b=(137,218,9); E13 has a=(196,168,69), b=(8,82,207). Model origins and full quartics remain the frozen complete-C identities. On E(L), the K-Frobenius is F³.

#pagebreak()
#text(size: 17pt, weight: "bold")[Reuse the halving algebra; test the transfer]

The project already has a complete elliptic-halving selector and universal Lean ring proof of its abscissa quartic. Reuse the original code literally as the native oracle. The new question is the complete norm-halving evaluator and its cost against the stronger baseline.

== Complete coordinate cases
#raw("H(X)=X^4-4uX^3-2AX^2-4(Au+2B)X+A^2-4Bu\nT=X^3-3uX^2-AX-Au-2B;  Y=T/(2v)  (v != 0)\nT^2-4(u^3+Au+B)(X^3+AX+B)=H(X)(X-u)^2", block: true)
For Q=O use all E[2]. For nonzero two-torsion Q, retain both ordinates at each distinct abscissa; there need only be two abscissas. Check all four points on the actual curve and [2]a=Q. The fast ordinate formula rejects v=0. Preserve denominator and source-isogeny admission checks.

== Discriminating controls
Retain whole rows for all448 rational exceptional inputs, all48 mixed-sector cases, the five public targets in every cofactor sector, both directions and both [13] compositions. Require direct/optimized/reference agreement, all four corrected lifts, infinity/two-torsion/four-torsion coverage, F³ controls and actual output/source checks. Wrong correction, field action, model/origin, changed quartic term and omitted record must reject. Compiler/CLI failures remain separate from mathematical negatives.

== Proof and accounting boundaries
Check a general-ring ordinate identity, exact-Z coefficient expansion and the original identity-certificate checker. Faithful conditional group lemmas must prove Frobenius halving, lift difference/correction and baseline equality with all geometry hypotheses explicit. Run both unchanged original Lean gates and exact statement binding. The actual Weil-restriction, quotient and Picard bridges remain written/native dependencies.

Record real call-site counts for setup, admission, norm, factorization, ordinates, complete quadratic Phi/Psi, source isogeny, correction and verification. Common full-order admission may still use a large Jacobian scalar. Include it. No calibrated cost, stage win or computational advantage follows from fewer named scalar calls. Existing live budget, isolation, tested image and matched-reference admission remains required for timing.

== Sources and reproducible next step
#link("https://math.mit.edu/classes/18.783/2025/LectureNotes2.pdf")[Sutherland, 18.783 (2025), Lecture2 §2.2: duplication.]

#link("https://math.mit.edu/classes/18.783/2025/LectureNotes5.pdf")[Sutherland, Lecture5, Theorems5.8 and5.25: separable degree and [2].]

Local sources: crypto/successor-preflight/src/two_primary_quotient.rs; lean/TwoPrimaryQuotient.lean; TWO_PRIMARY_QUOTIENT_PROOF.md; algebra-certificates/src/main.rs. Exact hashes and full primary/API review are beside the protocol (3da2fc). KB status/four queries/theorem fallback returned127; the autoresearcher vault is locked. No novelty or absence inference.

Publish NORM_HALVING_PROTOCOL_01.md before new sibling code. Then bounded Rust/Lean correctness (900s build/native; 2GiB serial), preserve every failure, whole replay/CI/custody, complete primitive coverage, and admitted performance work when unblocked. Existing complete-C and historical A/B diagrams were checked and retain their scope; this proposal adds the separate editable diagram above.
'''
(p/'report.typ').write_text(typ)
typst.compile(str(p/'report.typ'),output=str(p/'report.pdf'),root=str(p))
(p/'REPORT.md').write_text('''# Prospective norm-halving transfer evaluator

This is the source-linked proposal for [NORM_HALVING_PROTOCOL_01.md](../../NORM_HALVING_PROTOCOL_01.md), before new implementation. The original complete elliptic-halving quartic, native selector and Lean ring proof already exist in the project; the candidate applies norm-halving and actual E[2](K) correction to the matched degree13 beta and compares the strongest norm-assisted elliptic-scalar baseline. Native correctness, additional proofs, complete cost and performance outcomes are pending. [pcc:unverified]

[PDF](report.pdf), [editable diagram](flow.dot), [diagram metadata](flow.diagram.json), [SVG](flow.svg), [primary/code review](../../evidence/norm-halving-primary-review-01/sources.json). Full field/model identities, formulas, common admission, all448 exceptional controls, proof hypotheses, resource limits and retained negatives are specified by the protocol. No quantitative plot is supplied because no new comparable measurements exist. [pcc:unverified]

Canonical graphs checked: the accepted complete-C flow and historical A/B report remain correct at their original scope; their pinned subjects are unchanged. This proposal adds a separate dashed flow. The KB fallback was unavailable127 and the autoresearcher vault remains locked; no novelty or absence inference. Timing requires existing admission and matched references; no cost advantage is claimed. [pcc:unverified]
''')
(p/'render.py').write_text('''"""Rendering only; frozen prospective sources and identities."""
from pathlib import Path
import subprocess
import typst
p=Path(__file__).resolve().parent
subprocess.run(['dot','-Tsvg',str(p/'flow.dot'),'-o',str(p/'flow.svg')],check=True)
typst.compile(str(p/'report.typ'),output=str(p/'report.pdf'),root=str(p))
''')
print('proposal PDF bytes', (p/'report.pdf').stat().st_size)
