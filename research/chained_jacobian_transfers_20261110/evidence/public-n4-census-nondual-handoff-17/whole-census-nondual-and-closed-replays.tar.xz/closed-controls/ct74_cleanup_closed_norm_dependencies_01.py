"""Closed derived Rust dependency archives only; actual executables stay intact."""
from pathlib import Path
import hashlib,json,lzma,subprocess
s=Path('/workspace/scratch');cache=s/'ct74-norm-halving-driver-02-build-cache';full=s/'ct74-norm-halving-full-02';driver=s/'ct74-norm-halving-driver-02'
assert(full/'native.exit').read_text()=='0\n'and(driver/'original.exit').read_text()=='0\n'
active=subprocess.check_output(['ps','-eo','pid,args'],text=True);assert not any(('cargo 'in x or'rustc 'in x)and'<defunct>'not in x and'python3'not in x and'bash -lc'not in x for x in active.splitlines())
selected=sorted(p for p in(cache/'release/deps').iterdir()if p.is_file()and p.suffix in {'.rlib','.rmeta','.o'})
held=json.loads((full/'before.json').read_text());assert not any(str(p)in held for p in selected)
actual=json.loads((full/'binary-custody.json').read_text())['actual_executable_paths'];before={row['path']:hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()for row in actual};assert all(before[x['path']]==x['sha256']for x in actual)
rows=[{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in selected]
receipt={'all_closed_phases':21,'scope':'only .rlib/.rmeta/.o derived dependency files in explicitly external fresh full cache; not captured output; all three actual executable paths and whole copied executables retained','files':rows,'actual_executables':actual,'outside_all930_fresh_source_guards':True}
(s/'ct74-closed-norm-dependency-cleanup-01.json.xz').write_bytes(lzma.compress((json.dumps(receipt,indent=2)+'\n').encode()))
for p in selected:p.unlink()
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in held.items());assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items());print('closed derived bytes',sum(x['bytes']for x in rows),'files',len(rows),'all930source/all3actualexecutables intact')
