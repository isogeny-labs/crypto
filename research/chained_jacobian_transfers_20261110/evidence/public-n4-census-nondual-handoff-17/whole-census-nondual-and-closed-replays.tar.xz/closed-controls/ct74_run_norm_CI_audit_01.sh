#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct57-n4-unit-01-build-cache
out=/workspace/scratch/ct74-norm-halving-CI-audit-01
timeout 900 cargo build --release --offline --locked --manifest-path "$out/audit-cli/Cargo.toml" > "$out/compile.txt" 2>&1
status=$?
printf '%s\n' "$status" > "$out/compile.exit"
if [[ $status == 0 ]]; then
 cp "$CARGO_TARGET_DIR/release/n4-ci-evidence-audit" "$out/actual-audit-executable.bin"
 (ulimit -v 2097152; exec timeout 120 "$CARGO_TARGET_DIR/release/n4-ci-evidence-audit" /workspace/scratch/ct74-norm-halving-own-CI-01 "$out" "$out/all-original-goldens-plus-complete.json") > "$out/native.txt" 2>&1
 status=$?
 printf '%s\n' "$status" > "$out/native.exit"
fi
exit "$status"
