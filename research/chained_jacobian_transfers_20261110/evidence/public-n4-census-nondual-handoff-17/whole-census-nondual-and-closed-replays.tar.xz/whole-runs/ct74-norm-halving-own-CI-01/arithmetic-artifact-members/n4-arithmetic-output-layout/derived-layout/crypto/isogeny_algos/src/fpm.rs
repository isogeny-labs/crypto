//! Prime fields in Montgomery representation with N 64-bit limbs (`FpM<1>` for primes below 2^63,
//! `FpM<4>` for 256-bit, `FpM<8>` for 512-bit). Elements are `[u64; N]` in Montgomery form
//! a R mod p (R = 2^{64N}); equality and hashing work on that form. The simple reference field
//! remains `field::Zp` (canonical u64 residues).
use crate::bigint::{big_mod, Big};
use crate::field::{Field, Rng};

const MAXN: usize = 16;

thread_local! {
    /// Override of the multi-limb Karatsuba threshold (for tuning runs; None = built-in default).
    pub static KARATSUBA_N: std::cell::Cell<Option<usize>> = const { std::cell::Cell::new(None) };
    /// Override of the shorter-operand length from which products go through the multi-prime
    /// NTT (`crate::ntt`; for tuning runs and tests; None = built-in default, usize::MAX = never).
    pub static NTT_N: std::cell::Cell<Option<usize>> = const { std::cell::Cell::new(None) };
    /// Explicit-CRT fold constants of `conv_long` per (p, prime family, number of primes):
    /// (M / m_i) 2^64 mod p for each prime, then -M 2^64 mod p, N limbs each.
    static CRT_FOLD: std::cell::RefCell<Vec<(Vec<u64>, usize, std::rc::Rc<Vec<u64>>)>> =
        const { std::cell::RefCell::new(Vec::new()) };
}

#[derive(Clone, Debug)]
pub struct FpM<const N: usize> {
    pub p: [u64; N],
    pinv: u64,
    one: [u64; N],
    r2: [u64; N],
    r3: [u64; N],
    pbig: Big,
    pbits: u32,
    fast1: bool,
    /// p[N-1] < 2^63 - 2: the no-carry CIOS variant applies (top bit of the top limb free).
    nocarry: bool,
    /// Montgomery form of 2^64, the correction factor of `redc_wide`.
    s64: [u64; N],
    /// BMI2 + ADX available and N = 8 (N = 4 on request): use the assembly multiplication
    adx: bool,
    /// N = 1 and p < 2^62: division-free reduction of the lazily accumulated u128 sums
    red1: Option<crate::field::Red128>,
}

/// The single limbs of N = 1 residues, read in place ([u64; 1] has the layout of u64).
#[inline(always)]
fn limbs1<const N: usize>(a: &[[u64; N]]) -> &[u64] {
    assert!(N == 1);
    // SAFETY: N == 1, so [u64; N] has the size and alignment of u64 and the slice is contiguous
    unsafe { std::slice::from_raw_parts(a.as_ptr() as *const u64, a.len()) }
}

#[inline(always)]
fn add_raw<const N: usize>(a: &[u64; N], b: &[u64; N]) -> ([u64; N], bool) {
    let mut r = [0u64; N];
    let mut c = false;
    for i in 0..N {
        let (s1, o1) = a[i].overflowing_add(b[i]);
        let (s2, o2) = s1.overflowing_add(c as u64);
        r[i] = s2;
        c = o1 || o2;
    }
    (r, c)
}
#[inline(always)]
fn sub_raw<const N: usize>(a: &[u64; N], b: &[u64; N]) -> ([u64; N], bool) {
    let mut r = [0u64; N];
    let mut br = false;
    for i in 0..N {
        let (d1, o1) = a[i].overflowing_sub(b[i]);
        let (d2, o2) = d1.overflowing_sub(br as u64);
        r[i] = d2;
        br = o1 || o2;
    }
    (r, br)
}
#[inline(always)]
fn geq<const N: usize>(a: &[u64; N], b: &[u64; N]) -> bool {
    for i in (0..N).rev() {
        if a[i] != b[i] {
            return a[i] > b[i];
        }
    }
    true
}

/// Inverse of a in [1, p) modulo p < 2^63: extended Euclid on u64 with i64 Bezout coefficients
/// (every true coefficient is bounded by p, so wrapping two's-complement arithmetic is exact).
/// Measured 2x faster than the i128 version and 2.7x faster than binary gcd on this machine.
pub fn inv_u64(a: u64, p: u64) -> u64 {
        n4_arithmetic_taps::hit("fpm.base", p, "inv", 1);
    let (mut t, mut nt) = (0i64, 1i64);
    let (mut r, mut nr) = (p, a);
    while nr != 0 {
        let q = r / nr;
        let tmp = t.wrapping_sub((q as i64).wrapping_mul(nt));
        t = nt;
        nt = tmp;
        let tmp2 = r - q * nr;
        r = nr;
        nr = tmp2;
    }
    if t < 0 {
        (t + p as i64) as u64
    } else {
        t as u64
    }
}

/// Montgomery multiplication in x86-64 assembly with MULX/ADCX/ADOX (two independent carry
/// chains), CIOS with the accumulator in registers, generated for N = 4 and N = 8
/// (`adx_gen::mont_adx`, printed by the `gen_mont_adx` binary; `tests/adx_gen.rs` checks the
/// text below against it). Buffer at [rsi]: a | b | p | pinv | out[N+1]; the result is
/// < 2p with its top word in out[N]; the caller does the final subtraction.
#[cfg(target_arch = "x86_64")]
pub mod adx {
    macro_rules! mont_adx_4 {
        () => {
            concat!(
                "xor rcx, rcx\n",
                "xor r8, r8\n",
                "xor r9, r9\n",
                "xor r10, r10\n",
                "xor r11, r11\n",
                "mov rdx, qword ptr [rsi + 32]\n",
                "xor rdi, rdi\n",
                "mulx r13, rax, qword ptr [rsi + 0]\n",
                "adox rcx, rax\n",
                "adcx r8, r13\n",
                "mulx r13, rax, qword ptr [rsi + 8]\n",
                "adox r8, rax\n",
                "adcx r9, r13\n",
                "mulx r13, rax, qword ptr [rsi + 16]\n",
                "adox r9, rax\n",
                "adcx r10, r13\n",
                "mulx r13, rax, qword ptr [rsi + 24]\n",
                "adox r10, rax\n",
                "adcx r11, r13\n",
                "mov r12, 0\n",
                "adox r11, rdi\n",
                "adcx r12, rdi\n",
                "adox r12, rdi\n",
                "mov rdx, rcx\n",
                "imul rdx, qword ptr [rsi + 96]\n",
                "xor rdi, rdi\n",
                "mulx r13, rax, qword ptr [rsi + 64]\n",
                "adox rcx, rax\n",
                "adcx r8, r13\n",
                "mulx r13, rax, qword ptr [rsi + 72]\n",
                "adox r8, rax\n",
                "adcx r9, r13\n",
                "mulx r13, rax, qword ptr [rsi + 80]\n",
                "adox r9, rax\n",
                "adcx r10, r13\n",
                "mulx r13, rax, qword ptr [rsi + 88]\n",
                "adox r10, rax\n",
                "adcx r11, r13\n",
                "adox r11, rdi\n",
                "adcx r12, rdi\n",
                "adox r12, rdi\n",
                "mov rdx, qword ptr [rsi + 40]\n",
                "xor rdi, rdi\n",
                "mulx r13, rax, qword ptr [rsi + 0]\n",
                "adox r8, rax\n",
                "adcx r9, r13\n",
                "mulx r13, rax, qword ptr [rsi + 8]\n",
                "adox r9, rax\n",
                "adcx r10, r13\n",
                "mulx r13, rax, qword ptr [rsi + 16]\n",
                "adox r10, rax\n",
                "adcx r11, r13\n",
                "mulx r13, rax, qword ptr [rsi + 24]\n",
                "adox r11, rax\n",
                "adcx r12, r13\n",
                "mov rcx, 0\n",
                "adox r12, rdi\n",
                "adcx rcx, rdi\n",
                "adox rcx, rdi\n",
                "mov rdx, r8\n",
                "imul rdx, qword ptr [rsi + 96]\n",
                "xor rdi, rdi\n",
                "mulx r13, rax, qword ptr [rsi + 64]\n",
                "adox r8, rax\n",
                "adcx r9, r13\n",
                "mulx r13, rax, qword ptr [rsi + 72]\n",
                "adox r9, rax\n",
                "adcx r10, r13\n",
                "mulx r13, rax, qword ptr [rsi + 80]\n",
                "adox r10, rax\n",
                "adcx r11, r13\n",
                "mulx r13, rax, qword ptr [rsi + 88]\n",
                "adox r11, rax\n",
                "adcx r12, r13\n",
                "adox r12, rdi\n",
                "adcx rcx, rdi\n",
                "adox rcx, rdi\n",
                "mov rdx, qword ptr [rsi + 48]\n",
                "xor rdi, rdi\n",
                "mulx r13, rax, qword ptr [rsi + 0]\n",
                "adox r9, rax\n",
                "adcx r10, r13\n",
                "mulx r13, rax, qword ptr [rsi + 8]\n",
                "adox r10, rax\n",
                "adcx r11, r13\n",
                "mulx r13, rax, qword ptr [rsi + 16]\n",
                "adox r11, rax\n",
                "adcx r12, r13\n",
                "mulx r13, rax, qword ptr [rsi + 24]\n",
                "adox r12, rax\n",
                "adcx rcx, r13\n",
                "mov r8, 0\n",
                "adox rcx, rdi\n",
                "adcx r8, rdi\n",
                "adox r8, rdi\n",
                "mov rdx, r9\n",
                "imul rdx, qword ptr [rsi + 96]\n",
                "xor rdi, rdi\n",
                "mulx r13, rax, qword ptr [rsi + 64]\n",
                "adox r9, rax\n",
                "adcx r10, r13\n",
                "mulx r13, rax, qword ptr [rsi + 72]\n",
                "adox r10, rax\n",
                "adcx r11, r13\n",
                "mulx r13, rax, qword ptr [rsi + 80]\n",
                "adox r11, rax\n",
                "adcx r12, r13\n",
                "mulx r13, rax, qword ptr [rsi + 88]\n",
                "adox r12, rax\n",
                "adcx rcx, r13\n",
                "adox rcx, rdi\n",
                "adcx r8, rdi\n",
                "adox r8, rdi\n",
                "mov rdx, qword ptr [rsi + 56]\n",
                "xor rdi, rdi\n",
                "mulx r13, rax, qword ptr [rsi + 0]\n",
                "adox r10, rax\n",
                "adcx r11, r13\n",
                "mulx r13, rax, qword ptr [rsi + 8]\n",
                "adox r11, rax\n",
                "adcx r12, r13\n",
                "mulx r13, rax, qword ptr [rsi + 16]\n",
                "adox r12, rax\n",
                "adcx rcx, r13\n",
                "mulx r13, rax, qword ptr [rsi + 24]\n",
                "adox rcx, rax\n",
                "adcx r8, r13\n",
                "mov r9, 0\n",
                "adox r8, rdi\n",
                "adcx r9, rdi\n",
                "adox r9, rdi\n",
                "mov rdx, r10\n",
                "imul rdx, qword ptr [rsi + 96]\n",
                "xor rdi, rdi\n",
                "mulx r13, rax, qword ptr [rsi + 64]\n",
                "adox r10, rax\n",
                "adcx r11, r13\n",
                "mulx r13, rax, qword ptr [rsi + 72]\n",
                "adox r11, rax\n",
                "adcx r12, r13\n",
                "mulx r13, rax, qword ptr [rsi + 80]\n",
                "adox r12, rax\n",
                "adcx rcx, r13\n",
                "mulx r13, rax, qword ptr [rsi + 88]\n",
                "adox rcx, rax\n",
                "adcx r8, r13\n",
                "adox r8, rdi\n",
                "adcx r9, rdi\n",
                "adox r9, rdi\n",
                "mov qword ptr [rsi + 104], r11\n",
                "mov qword ptr [rsi + 112], r12\n",
                "mov qword ptr [rsi + 120], rcx\n",
                "mov qword ptr [rsi + 128], r8\n",
                "mov qword ptr [rsi + 136], r9\n",
            )
        };
    }
    macro_rules! mont_adx_8 {
        () => {
            concat!(
                "push rbx\n",
                "push rbp\n",
                "xor rbp, rbp\n",
                "xor rcx, rcx\n",
                "xor r8, r8\n",
                "xor r9, r9\n",
                "xor r10, r10\n",
                "xor r11, r11\n",
                "xor r12, r12\n",
                "xor r13, r13\n",
                "xor r14, r14\n",
                "mov rdx, qword ptr [rsi + 64]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 0]\n",
                "adox rbp, rax\n",
                "adcx rcx, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 8]\n",
                "adox rcx, rax\n",
                "adcx r8, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 16]\n",
                "adox r8, rax\n",
                "adcx r9, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 24]\n",
                "adox r9, rax\n",
                "adcx r10, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 32]\n",
                "adox r10, rax\n",
                "adcx r11, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 40]\n",
                "adox r11, rax\n",
                "adcx r12, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 48]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 56]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mov r15, 0\n",
                "adox r14, rdi\n",
                "adcx r15, rdi\n",
                "adox r15, rdi\n",
                "mov rdx, rbp\n",
                "imul rdx, qword ptr [rsi + 192]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 128]\n",
                "adox rbp, rax\n",
                "adcx rcx, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 136]\n",
                "adox rcx, rax\n",
                "adcx r8, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 144]\n",
                "adox r8, rax\n",
                "adcx r9, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 152]\n",
                "adox r9, rax\n",
                "adcx r10, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 160]\n",
                "adox r10, rax\n",
                "adcx r11, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 168]\n",
                "adox r11, rax\n",
                "adcx r12, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 176]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 184]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "adox r14, rdi\n",
                "adcx r15, rdi\n",
                "adox r15, rdi\n",
                "mov rdx, qword ptr [rsi + 72]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 0]\n",
                "adox rcx, rax\n",
                "adcx r8, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 8]\n",
                "adox r8, rax\n",
                "adcx r9, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 16]\n",
                "adox r9, rax\n",
                "adcx r10, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 24]\n",
                "adox r10, rax\n",
                "adcx r11, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 32]\n",
                "adox r11, rax\n",
                "adcx r12, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 40]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 48]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 56]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "mov rbp, 0\n",
                "adox r15, rdi\n",
                "adcx rbp, rdi\n",
                "adox rbp, rdi\n",
                "mov rdx, rcx\n",
                "imul rdx, qword ptr [rsi + 192]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 128]\n",
                "adox rcx, rax\n",
                "adcx r8, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 136]\n",
                "adox r8, rax\n",
                "adcx r9, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 144]\n",
                "adox r9, rax\n",
                "adcx r10, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 152]\n",
                "adox r10, rax\n",
                "adcx r11, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 160]\n",
                "adox r11, rax\n",
                "adcx r12, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 168]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 176]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 184]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "adox r15, rdi\n",
                "adcx rbp, rdi\n",
                "adox rbp, rdi\n",
                "mov rdx, qword ptr [rsi + 80]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 0]\n",
                "adox r8, rax\n",
                "adcx r9, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 8]\n",
                "adox r9, rax\n",
                "adcx r10, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 16]\n",
                "adox r10, rax\n",
                "adcx r11, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 24]\n",
                "adox r11, rax\n",
                "adcx r12, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 32]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 40]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 48]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 56]\n",
                "adox r15, rax\n",
                "adcx rbp, rbx\n",
                "mov rcx, 0\n",
                "adox rbp, rdi\n",
                "adcx rcx, rdi\n",
                "adox rcx, rdi\n",
                "mov rdx, r8\n",
                "imul rdx, qword ptr [rsi + 192]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 128]\n",
                "adox r8, rax\n",
                "adcx r9, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 136]\n",
                "adox r9, rax\n",
                "adcx r10, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 144]\n",
                "adox r10, rax\n",
                "adcx r11, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 152]\n",
                "adox r11, rax\n",
                "adcx r12, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 160]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 168]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 176]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 184]\n",
                "adox r15, rax\n",
                "adcx rbp, rbx\n",
                "adox rbp, rdi\n",
                "adcx rcx, rdi\n",
                "adox rcx, rdi\n",
                "mov rdx, qword ptr [rsi + 88]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 0]\n",
                "adox r9, rax\n",
                "adcx r10, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 8]\n",
                "adox r10, rax\n",
                "adcx r11, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 16]\n",
                "adox r11, rax\n",
                "adcx r12, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 24]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 32]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 40]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 48]\n",
                "adox r15, rax\n",
                "adcx rbp, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 56]\n",
                "adox rbp, rax\n",
                "adcx rcx, rbx\n",
                "mov r8, 0\n",
                "adox rcx, rdi\n",
                "adcx r8, rdi\n",
                "adox r8, rdi\n",
                "mov rdx, r9\n",
                "imul rdx, qword ptr [rsi + 192]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 128]\n",
                "adox r9, rax\n",
                "adcx r10, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 136]\n",
                "adox r10, rax\n",
                "adcx r11, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 144]\n",
                "adox r11, rax\n",
                "adcx r12, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 152]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 160]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 168]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 176]\n",
                "adox r15, rax\n",
                "adcx rbp, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 184]\n",
                "adox rbp, rax\n",
                "adcx rcx, rbx\n",
                "adox rcx, rdi\n",
                "adcx r8, rdi\n",
                "adox r8, rdi\n",
                "mov rdx, qword ptr [rsi + 96]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 0]\n",
                "adox r10, rax\n",
                "adcx r11, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 8]\n",
                "adox r11, rax\n",
                "adcx r12, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 16]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 24]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 32]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 40]\n",
                "adox r15, rax\n",
                "adcx rbp, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 48]\n",
                "adox rbp, rax\n",
                "adcx rcx, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 56]\n",
                "adox rcx, rax\n",
                "adcx r8, rbx\n",
                "mov r9, 0\n",
                "adox r8, rdi\n",
                "adcx r9, rdi\n",
                "adox r9, rdi\n",
                "mov rdx, r10\n",
                "imul rdx, qword ptr [rsi + 192]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 128]\n",
                "adox r10, rax\n",
                "adcx r11, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 136]\n",
                "adox r11, rax\n",
                "adcx r12, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 144]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 152]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 160]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 168]\n",
                "adox r15, rax\n",
                "adcx rbp, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 176]\n",
                "adox rbp, rax\n",
                "adcx rcx, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 184]\n",
                "adox rcx, rax\n",
                "adcx r8, rbx\n",
                "adox r8, rdi\n",
                "adcx r9, rdi\n",
                "adox r9, rdi\n",
                "mov rdx, qword ptr [rsi + 104]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 0]\n",
                "adox r11, rax\n",
                "adcx r12, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 8]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 16]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 24]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 32]\n",
                "adox r15, rax\n",
                "adcx rbp, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 40]\n",
                "adox rbp, rax\n",
                "adcx rcx, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 48]\n",
                "adox rcx, rax\n",
                "adcx r8, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 56]\n",
                "adox r8, rax\n",
                "adcx r9, rbx\n",
                "mov r10, 0\n",
                "adox r9, rdi\n",
                "adcx r10, rdi\n",
                "adox r10, rdi\n",
                "mov rdx, r11\n",
                "imul rdx, qword ptr [rsi + 192]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 128]\n",
                "adox r11, rax\n",
                "adcx r12, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 136]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 144]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 152]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 160]\n",
                "adox r15, rax\n",
                "adcx rbp, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 168]\n",
                "adox rbp, rax\n",
                "adcx rcx, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 176]\n",
                "adox rcx, rax\n",
                "adcx r8, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 184]\n",
                "adox r8, rax\n",
                "adcx r9, rbx\n",
                "adox r9, rdi\n",
                "adcx r10, rdi\n",
                "adox r10, rdi\n",
                "mov rdx, qword ptr [rsi + 112]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 0]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 8]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 16]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 24]\n",
                "adox r15, rax\n",
                "adcx rbp, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 32]\n",
                "adox rbp, rax\n",
                "adcx rcx, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 40]\n",
                "adox rcx, rax\n",
                "adcx r8, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 48]\n",
                "adox r8, rax\n",
                "adcx r9, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 56]\n",
                "adox r9, rax\n",
                "adcx r10, rbx\n",
                "mov r11, 0\n",
                "adox r10, rdi\n",
                "adcx r11, rdi\n",
                "adox r11, rdi\n",
                "mov rdx, r12\n",
                "imul rdx, qword ptr [rsi + 192]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 128]\n",
                "adox r12, rax\n",
                "adcx r13, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 136]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 144]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 152]\n",
                "adox r15, rax\n",
                "adcx rbp, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 160]\n",
                "adox rbp, rax\n",
                "adcx rcx, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 168]\n",
                "adox rcx, rax\n",
                "adcx r8, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 176]\n",
                "adox r8, rax\n",
                "adcx r9, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 184]\n",
                "adox r9, rax\n",
                "adcx r10, rbx\n",
                "adox r10, rdi\n",
                "adcx r11, rdi\n",
                "adox r11, rdi\n",
                "mov rdx, qword ptr [rsi + 120]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 0]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 8]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 16]\n",
                "adox r15, rax\n",
                "adcx rbp, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 24]\n",
                "adox rbp, rax\n",
                "adcx rcx, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 32]\n",
                "adox rcx, rax\n",
                "adcx r8, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 40]\n",
                "adox r8, rax\n",
                "adcx r9, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 48]\n",
                "adox r9, rax\n",
                "adcx r10, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 56]\n",
                "adox r10, rax\n",
                "adcx r11, rbx\n",
                "mov r12, 0\n",
                "adox r11, rdi\n",
                "adcx r12, rdi\n",
                "adox r12, rdi\n",
                "mov rdx, r13\n",
                "imul rdx, qword ptr [rsi + 192]\n",
                "xor rdi, rdi\n",
                "mulx rbx, rax, qword ptr [rsi + 128]\n",
                "adox r13, rax\n",
                "adcx r14, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 136]\n",
                "adox r14, rax\n",
                "adcx r15, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 144]\n",
                "adox r15, rax\n",
                "adcx rbp, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 152]\n",
                "adox rbp, rax\n",
                "adcx rcx, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 160]\n",
                "adox rcx, rax\n",
                "adcx r8, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 168]\n",
                "adox r8, rax\n",
                "adcx r9, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 176]\n",
                "adox r9, rax\n",
                "adcx r10, rbx\n",
                "mulx rbx, rax, qword ptr [rsi + 184]\n",
                "adox r10, rax\n",
                "adcx r11, rbx\n",
                "adox r11, rdi\n",
                "adcx r12, rdi\n",
                "adox r12, rdi\n",
                "mov qword ptr [rsi + 200], r14\n",
                "mov qword ptr [rsi + 208], r15\n",
                "mov qword ptr [rsi + 216], rbp\n",
                "mov qword ptr [rsi + 224], rcx\n",
                "mov qword ptr [rsi + 232], r8\n",
                "mov qword ptr [rsi + 240], r9\n",
                "mov qword ptr [rsi + 248], r10\n",
                "mov qword ptr [rsi + 256], r11\n",
                "mov qword ptr [rsi + 264], r12\n",
                "pop rbp\n",
                "pop rbx\n",
            )
        };
    }

    /// The assembly text of the two routines, as embedded below.
    pub const MONT_ADX_4: &str = mont_adx_4!();
    pub const MONT_ADX_8: &str = mont_adx_8!();

    #[repr(C)]
    pub struct Buf<const N: usize, const M: usize> {
        pub a: [u64; N],
        pub b: [u64; N],
        pub p: [u64; N],
        pub pinv: u64,
        pub out: [u64; M],
    }

    /// # Safety
    /// The CPU must support BMI2 and ADX (callers check `is_x86_feature_detected!`).
    #[inline(always)]
    pub unsafe fn mont4(buf: &mut Buf<4, 5>) {
        std::arch::asm!(
            mont_adx_4!(),
            in("rsi") buf as *mut Buf<4, 5>,
            out("rax") _, out("rcx") _, out("rdx") _, out("rdi") _,
            out("r8") _, out("r9") _, out("r10") _, out("r11") _, out("r12") _, out("r13") _,
        );
    }

    /// # Safety
    /// The CPU must support BMI2 and ADX (callers check `is_x86_feature_detected!`).
    #[inline(always)]
    pub unsafe fn mont8(buf: &mut Buf<8, 9>) {
        // rbx and rbp are saved and restored inside the block (they cannot be operands)
        std::arch::asm!(
            mont_adx_8!(),
            in("rsi") buf as *mut Buf<8, 9>,
            out("rax") _, out("rcx") _, out("rdx") _, out("rdi") _,
            out("r8") _, out("r9") _, out("r10") _, out("r11") _, out("r12") _, out("r13") _,
            out("r14") _, out("r15") _,
        );
    }
}

impl<const N: usize> FpM<N> {
    pub fn new(p: &Big) -> Self {
        assert!(N >= 1 && N <= MAXN);
        assert!(p.bit(0) && p.bits() >= 3, "p must be odd and > 3");
        assert!(p.bits() <= 64 * N, "p does not fit in {N} limbs");
        if N > 1 {
            assert!(p.bits() > 64 * (N - 1), "use fewer limbs for this p");
        }
        let pl: [u64; N] = p.limbs(N).try_into().unwrap();
        let mut inv = 1u64;
        for _ in 0..6 {
            inv = inv.wrapping_mul(2u64.wrapping_sub(pl[0].wrapping_mul(inv)));
        }
        let mut f = FpM {
            p: pl,
            pinv: inv.wrapping_neg(),
            one: [0; N],
            r2: [0; N],
            r3: [0; N],
            pbig: p.clone(),
            pbits: p.bits() as u32,
            fast1: N == 1 && p.bits() <= 63,
            nocarry: N > 1 && pl[N - 1] < (1u64 << 63) - 2,
            s64: [0; N],
            adx: false,
            red1: (N == 1 && p.bits() <= 62).then(|| crate::field::Red128::new(pl[0])),
        };
        // R mod p, R^2 mod p, R^3 mod p by repeated doubling of 1
        let mut x = [0u64; N];
        x[0] = 1;
        let mut out = vec![];
        for _ in 0..3 {
            for _ in 0..64 * N {
                x = f.add_mod(&x, &x);
            }
            out.push(x);
        }
        f.one = out[0];
        f.r2 = out[1];
        f.r3 = out[2];
        // 2^64 R mod p: 64 more doublings of R
        let mut x = f.one;
        for _ in 0..64 {
            x = f.add_mod(&x, &x);
        }
        f.s64 = x;
        #[cfg(target_arch = "x86_64")]
        {
            // N = 4 is generated too, but measured no better than the portable CIOS (mixed: 7%
            // faster throughput, 10% slower latency and squaring), so only N = 8 uses it
            f.adx = (N == 8 || (N == 4 && std::env::var_os("ISOGENY_ADX4").is_some()))
                && std::arch::is_x86_feature_detected!("bmi2")
                && std::arch::is_x86_feature_detected!("adx")
                && std::env::var_os("ISOGENY_NO_ADX").is_none();
        }
        f
    }
    pub fn from_u64_modulus(p: u64) -> Self {
        FpM::new(&Big::from_u64(p))
    }
    pub fn from_dec(s: &str) -> Self {
        FpM::new(&Big::from_dec(s))
    }
    pub fn modulus(&self) -> &Big {
        &self.pbig
    }
    #[inline(always)]
    fn add_mod(&self, a: &[u64; N], b: &[u64; N]) -> [u64; N] {
        let (s, c) = add_raw(a, b);
        if c || geq(&s, &self.p) {
            sub_raw(&s, &self.p).0
        } else {
            s
        }
    }
    #[inline(always)]
    fn sub_mod(&self, a: &[u64; N], b: &[u64; N]) -> [u64; N] {
        let (d, br) = sub_raw(a, b);
        if br {
            add_raw(&d, &self.p).0
        } else {
            d
        }
    }
    #[inline(always)]
    fn mont_mul(&self, a: &[u64; N], b: &[u64; N]) -> [u64; N] {
        if N == 1 && self.fast1 {
            let p0 = self.p[0];
            let x = a[0] as u128 * b[0] as u128;
            let m = (x as u64).wrapping_mul(self.pinv);
            let t = ((x + m as u128 * p0 as u128) >> 64) as u64;
            let mut r = [0u64; N];
            r[0] = if t >= p0 { t - p0 } else { t };
            return r;
        }
        #[cfg(target_arch = "x86_64")]
        if self.adx {
            return self.mont_mul_adx(a, b);
        }
        if self.nocarry {
            // CIOS without the overflow word (Gautam-Botrel-Piellard, gnark): when the top limb of
            // p is below 2^63 - 2 the running value always fits in N words. Measured ~14% faster
            // than the general loop at N = 8.
            let mut t = [0u64; N];
            for i in 0..N {
                let bi = b[i] as u128;
                let s = t[0] as u128 + a[0] as u128 * bi;
                let mut ca = (s >> 64) as u64;
                let t0 = s as u64;
                let m = t0.wrapping_mul(self.pinv) as u128;
                let mut cb = ((t0 as u128 + m * self.p[0] as u128) >> 64) as u64;
                for j in 1..N {
                    let s = t[j] as u128 + a[j] as u128 * bi + ca as u128;
                    ca = (s >> 64) as u64;
                    let s2 = (s as u64) as u128 + m * self.p[j] as u128 + cb as u128;
                    cb = (s2 >> 64) as u64;
                    t[j - 1] = s2 as u64;
                }
                t[N - 1] = ca.wrapping_add(cb);
            }
            if geq(&t, &self.p) {
                t = sub_raw(&t, &self.p).0;
            }
            return t;
        }
        // CIOS with the running value in t[0..N] plus one overflow word (t_n); every inner loop
        // has constant trip count N, so it is fully unrolled per instantiation.
        let mut t = [0u64; N];
        let mut t_n = 0u64;
        for i in 0..N {
            let bi = b[i] as u128;
            let mut c = 0u64;
            for j in 0..N {
                let s = t[j] as u128 + a[j] as u128 * bi + c as u128;
                t[j] = s as u64;
                c = (s >> 64) as u64;
            }
            let s = t_n as u128 + c as u128;
            let (t_n0, t_n1) = (s as u64, (s >> 64) as u64);
            let m = t[0].wrapping_mul(self.pinv) as u128;
            let mut c = ((t[0] as u128 + m * self.p[0] as u128) >> 64) as u64;
            for j in 1..N {
                let s = t[j] as u128 + m * self.p[j] as u128 + c as u128;
                t[j - 1] = s as u64;
                c = (s >> 64) as u64;
            }
            let s = t_n0 as u128 + c as u128;
            t[N - 1] = s as u64;
            t_n = t_n1 + (s >> 64) as u64;
        }
        if t_n != 0 || geq(&t, &self.p) {
            t = sub_raw(&t, &self.p).0;
        }
        t
    }
    /// acc += a * b (full 2N-limb product, no reduction); acc has 2N + 2 limbs.
    #[inline(always)]
    fn mul_acc(acc: &mut [u64; 2 * MAXN + 2], a: &[u64; N], b: &[u64; N]) {
        for i in 0..N {
            let ai = a[i] as u128;
            let mut c = 0u64;
            for j in 0..N {
                let s = acc[i + j] as u128 + ai * b[j] as u128 + c as u128;
                acc[i + j] = s as u64;
                c = (s >> 64) as u64;
            }
            let mut t = i + N;
            while c != 0 {
                let (s, o) = acc[t].overflowing_add(c);
                acc[t] = s;
                c = o as u64;
                t += 1;
            }
        }
    }
    /// For T = sum of fewer than 2^64 products of reduced Montgomery residues (T < 2^64 p R):
    /// N + 1 word-by-word Montgomery steps give T / (2^64 R) + (< p) < 2p; one subtraction and a
    /// multiplication by the Montgomery form of 2^64 restore T R^{-1} mod p.
    #[inline(always)]
    fn redc_wide(&self, acc: &mut [u64; 2 * MAXN + 2]) -> [u64; N] {
        let r = self.redc_raw(acc);
        self.mont_mul(&r, &self.s64)
    }
    /// T / (2^64 R) mod p for T < 2^64 p R: the N + 1 word-by-word Montgomery steps of
    /// `redc_wide` without its correcting product.
    #[inline(always)]
    fn redc_raw(&self, acc: &mut [u64; 2 * MAXN + 2]) -> [u64; N] {
        for i in 0..=N {
            let m = acc[i].wrapping_mul(self.pinv) as u128;
            let mut c = 0u64;
            for j in 0..N {
                let s = acc[i + j] as u128 + m * self.p[j] as u128 + c as u128;
                acc[i + j] = s as u64;
                c = (s >> 64) as u64;
            }
            let mut t = i + N;
            while c != 0 && t < 2 * N + 2 {
                let (s, o) = acc[t].overflowing_add(c);
                acc[t] = s;
                c = o as u64;
                t += 1;
            }
        }
        let mut r = [0u64; N];
        r.copy_from_slice(&acc[N + 1..2 * N + 1]);
        if acc[2 * N + 1] != 0 || geq(&r, &self.p) {
            r = sub_raw(&r, &self.p).0;
        }
        r
    }
    /// acc += w b for one word w.
    #[inline(always)]
    fn mul_acc_word(acc: &mut [u64; 2 * MAXN + 2], w: u64, b: &[u64; N]) {
        let w = w as u128;
        let mut c = 0u64;
        for j in 0..N {
            let s = acc[j] as u128 + w * b[j] as u128 + c as u128;
            acc[j] = s as u64;
            c = (s >> 64) as u64;
        }
        let mut t = N;
        while c != 0 {
            let (s, o) = acc[t].overflowing_add(c);
            acc[t] = s;
            c = o as u64;
            t += 1;
        }
    }
    #[cfg(target_arch = "x86_64")]
    #[inline(always)]
    fn mont_mul_adx(&self, a: &[u64; N], b: &[u64; N]) -> [u64; N] {
        let mut r = [0u64; N];
        let top = if N == 4 {
            let mut buf = adx::Buf::<4, 5> {
                a: [0; 4],
                b: [0; 4],
                p: [0; 4],
                pinv: self.pinv,
                out: [0; 5],
            };
            buf.a.copy_from_slice(a);
            buf.b.copy_from_slice(b);
            buf.p.copy_from_slice(&self.p);
            unsafe { adx::mont4(&mut buf) };
            r.copy_from_slice(&buf.out[..4]);
            buf.out[4]
        } else {
            let mut buf = adx::Buf::<8, 9> {
                a: [0; 8],
                b: [0; 8],
                p: [0; 8],
                pinv: self.pinv,
                out: [0; 9],
            };
            buf.a.copy_from_slice(a);
            buf.b.copy_from_slice(b);
            buf.p.copy_from_slice(&self.p);
            unsafe { adx::mont8(&mut buf) };
            r.copy_from_slice(&buf.out[..8]);
            buf.out[8]
        };
        if top != 0 || geq(&r, &self.p) {
            r = sub_raw(&r, &self.p).0;
        }
        r
    }
    /// The portable CIOS product (for testing the assembly against).
    pub fn mont_mul_portable(&self, a: &[u64; N], b: &[u64; N]) -> [u64; N] {
        let mut g = self.clone();
        g.adx = false;
        g.mont_mul(a, b)
    }
    /// Whether the assembly multiplication is in use.
    pub fn uses_adx(&self) -> bool {
        self.adx
    }
    /// Shorter-operand length from which `conv_long` uses the multi-prime NTT: the measured
    /// crossover with Karatsuba for balanced operands (`examples/profile_ntt.rs`), lower when
    /// the AVX-512 IFMA transforms are in use.
    pub fn ntt_threshold(&self) -> usize {
        if crate::ntt::simd_active() {
            match N {
                1 => 72,
                2 => 56,
                3 | 4 => 32,
                _ => 24,
            }
        } else {
            match N {
                1 => 384,
                2 => 112,
                3 | 4 => 64,
                _ => 40,
            }
        }
    }
    /// Canonical residue (out of Montgomery form).
    pub fn to_canonical(&self, a: &[u64; N]) -> [u64; N] {
        let mut one = [0u64; N];
        one[0] = 1;
        self.mont_mul(a, &one)
    }
    pub fn to_big(&self, a: &[u64; N]) -> Big {
        Big::from_limbs(&self.to_canonical(a))
    }
    pub fn from_big(&self, v: &Big) -> [u64; N] {
        let c: [u64; N] = big_mod(v, &self.pbig).limbs(N).try_into().unwrap();
        self.mont_mul(&c, &self.r2)
    }
}

/// Signed (two's complement) value on N+1 limbs, the scratch type of the binary GCD.
type Wide = [u64; MAXN + 1];

#[inline(always)]
fn lincomb<const N: usize>(x: &[u64; N], fx: i64, y: &[u64; N], fy: i64) -> Wide {
    let mut r = [0u64; MAXN + 1];
    let mut carry: i128 = 0;
    for i in 0..N {
        let s = x[i] as i128 * fx as i128 + y[i] as i128 * fy as i128 + carry;
        r[i] = s as u64;
        carry = s >> 64;
    }
    r[N] = carry as u64;
    r
}
#[inline(always)]
fn wide_neg(r: &mut Wide, n: usize) {
    let mut c = true;
    for x in r.iter_mut().take(n) {
        let (v, o) = (!*x).overflowing_add(c as u64);
        *x = v;
        c = o;
    }
}
/// Arithmetic shift right by k < 64 of an (n)-limb signed value.
#[inline(always)]
fn wide_shr(r: &mut Wide, n: usize, k: u32) {
    for i in 0..n - 1 {
        r[i] = (r[i] >> k) | (r[i + 1] << (64 - k));
    }
    r[n - 1] = ((r[n - 1] as i64) >> k) as u64;
}
#[inline(always)]
fn wide_add_mul_small<const N: usize>(r: &mut Wide, m: &[u64; N], t: u64) {
    let mut c: u128 = 0;
    for i in 0..N {
        let s = r[i] as u128 + m[i] as u128 * t as u128 + c;
        r[i] = s as u64;
        c = s >> 64;
    }
    r[N] = r[N].wrapping_add(c as u64);
}
#[inline(always)]
fn bitlen<const N: usize>(a: &[u64; N]) -> usize {
    for i in (0..N).rev() {
        if a[i] != 0 {
            return 64 * i + 64 - a[i].leading_zeros() as usize;
        }
    }
    0
}
/// Bits [s, s+32) of a (s may exceed the length; missing bits are zero).
#[inline(always)]
fn bits32<const N: usize>(a: &[u64; N], s: usize) -> u64 {
    let (w, o) = (s / 64, s % 64);
    let lo = if w < N { a[w] >> o } else { 0 };
    let hi = if o > 32 && w + 1 < N {
        a[w + 1] << (64 - o)
    } else {
        0
    };
    (lo | hi) & 0xFFFF_FFFF
}

impl<const N: usize> FpM<N> {
    /// Plain-integer inverse of y in [1, p) by Pornin's optimized binary GCD (ePrint 2020/972):
    /// 31 binary-GCD steps at a time on 62-bit approximations of (a, b) (top 32 and low 30 bits),
    /// the accumulated 2x2 update applied once to the full-length values. Invariants a = u y,
    /// b = v y (mod p); ends with b = gcd = 1, v = 1/y. Not constant time.
    fn bingcd_inv(&self, y: &[u64; N]) -> [u64; N] {
        const K: u32 = 31;
        let p = &self.p;
        // -p^{-1} mod 2^(K-1)
        let minv = self.pinv & ((1u64 << (K - 1)) - 1);
        let (mut a, mut b) = (*y, *p);
        let mut u = [0u64; N];
        u[0] = 1;
        let mut v = [0u64; N];
        let n1 = N + 1;
        // (u f + v g) / 2^(K-1) mod p, reduced into [0, p)
        let upd = |u: &[u64; N], f: i64, v: &[u64; N], g: i64| -> [u64; N] {
            let mut w = lincomb(u, f, v, g);
            let t = (w[0].wrapping_mul(minv)) & ((1u64 << (K - 1)) - 1);
            wide_add_mul_small(&mut w, p, t);
            wide_shr(&mut w, n1, K - 1);
            // |w| < 2p: fold into [0, p)
            let mut pw = [0u64; MAXN + 1];
            pw[..N].copy_from_slice(p);
            while (w[N] as i64) < 0 {
                let mut c = false;
                for i in 0..n1 {
                    let (s1, o1) = w[i].overflowing_add(pw[i]);
                    let (s2, o2) = s1.overflowing_add(c as u64);
                    w[i] = s2;
                    c = o1 || o2;
                }
            }
            loop {
                let mut lo = [0u64; N];
                lo.copy_from_slice(&w[..N]);
                if w[N] == 0 && !geq(&lo, p) {
                    return lo;
                }
                let mut br = false;
                for i in 0..n1 {
                    let (d1, o1) = w[i].overflowing_sub(pw[i]);
                    let (d2, o2) = d1.overflowing_sub(br as u64);
                    w[i] = d2;
                    br = o1 || o2;
                }
            }
        };
        let cap = 4 * (64 * N) / (K as usize - 1) + 8;
        for _ in 0..cap {
            if a.iter().all(|&x| x == 0) {
                break;
            }
            let n = bitlen(&a).max(bitlen(&b)).max(2 * K as usize);
            let low = (1u64 << (K - 1)) - 1;
            let mut aa = (a[0] & low) | (bits32(&a, n - K as usize - 1) << (K - 1));
            let mut bb = (b[0] & low) | (bits32(&b, n - K as usize - 1) << (K - 1));
            let (mut f0, mut g0, mut f1, mut g1) = (1i64, 0i64, 0i64, 1i64);
            for _ in 0..K - 1 {
                if aa & 1 == 1 {
                    if aa < bb {
                        std::mem::swap(&mut aa, &mut bb);
                        std::mem::swap(&mut f0, &mut f1);
                        std::mem::swap(&mut g0, &mut g1);
                    }
                    aa -= bb;
                    f0 -= f1;
                    g0 -= g1;
                }
                aa >>= 1;
                f1 <<= 1;
                g1 <<= 1;
            }
            let mut na = lincomb(&a, f0, &b, g0);
            let mut nb = lincomb(&a, f1, &b, g1);
            wide_shr(&mut na, n1, K - 1);
            wide_shr(&mut nb, n1, K - 1);
            if (na[N] as i64) < 0 {
                wide_neg(&mut na, n1);
                f0 = -f0;
                g0 = -g0;
            }
            if (nb[N] as i64) < 0 {
                wide_neg(&mut nb, n1);
                f1 = -f1;
                g1 = -g1;
            }
            a.copy_from_slice(&na[..N]);
            b.copy_from_slice(&nb[..N]);
            let (nu, nv) = (upd(&u, f0, &v, g0), upd(&u, f1, &v, g1));
            u = nu;
            v = nv;
        }
        let mut one = [0u64; N];
        one[0] = 1;
        if a.iter().any(|&x| x != 0) || b != one {
            // no convergence within the cap (not expected): fall back to Fermat on R y
            let yr = self.mont_mul(y, &self.r2);
            let inv_m = self.pow_big(yr, &self.pbig.sub_small(2));
            // inv_m = y^{-1} R; return the plain integer y^{-1}
            return self.mont_mul(&inv_m, &one);
        }
        v
    }
}

impl<const N: usize> Field for FpM<N> {
    type E = [u64; N];
    fn zero(&self) -> Self::E {
        [0u64; N]
    }
    fn one(&self) -> Self::E {
        self.one
    }
    #[inline(always)]
    fn add(&self, a: Self::E, b: Self::E) -> Self::E {
        self.add_mod(&a, &b)
    }
    #[inline(always)]
    fn sub(&self, a: Self::E, b: Self::E) -> Self::E {
        self.sub_mod(&a, &b)
    }
    #[inline(always)]
    fn neg(&self, a: Self::E) -> Self::E {
        if a == [0u64; N] {
            a
        } else {
            sub_raw(&self.p, &a).0
        }
    }
    #[inline(always)]
    fn mul(&self, a: Self::E, b: Self::E) -> Self::E {
        self.mont_mul(&a, &b)
    }
    fn inv(&self, a: Self::E) -> Self::E {
        assert!(a != [0u64; N], "inverse of zero");
        if N == 1 && self.pbits <= 63 {
            // (aR)^{-1} computed on integers, then * R^3 R^{-1} = a^{-1} R
            let c = inv_u64(a[0], self.p[0]);
            let mut x = [0u64; N];
            x[0] = c;
            return self.mont_mul(&x, &self.r3);
        }
        let c = self.bingcd_inv(&a);
        self.mont_mul(&c, &self.r3)
    }
    fn from_u64(&self, n: u64) -> Self::E {
        let mut c = [0u64; N];
        c[0] = if N == 1 { n % self.p[0] } else { n };
        self.mont_mul(&c, &self.r2)
    }
    fn char(&self) -> u64 {
        self.p[0]
    }
    fn characteristic_exceeds(&self, n: u64) -> bool {
        self.pbits > 64 || self.p[0] > n
    }
    fn conv(&self, a: &[Self::E], b: &[Self::E]) -> Vec<Self::E> {
        self.conv_trunc(a, b, a.len() + b.len() - 1)
    }
    fn dot_rev_rows(&self, a: &[Self::E], rows: &[&[Self::E]]) -> Vec<Self::E> {
        let Some(red) = &self.red1 else {
            return rows.iter().map(|b| self.dot_rev(a, b)).collect();
        };
        let rows1: Vec<&[u64]> = rows.iter().map(|b| limbs1(b)).collect();
        crate::field::lazy_dot_rev_rows(limbs1(a), &rows1, red, |x| red.redc(x))
            .into_iter()
            .map(|x| {
                let mut t = [0u64; N];
                t[0] = x;
                t
            })
            .collect()
    }
    fn dot_rev(&self, a: &[Self::E], b: &[Self::E]) -> Self::E {
        if let Some(red) = &self.red1 {
            // sum of (aR)(bR), one Montgomery reduction: (sum ab) R
            let mut t = [0u64; N];
            t[0] = crate::field::lazy_dot_rev(limbs1(a), limbs1(b), red, |x| red.redc(x));
            return t;
        }
        let n = a.len().min(b.len());
        let mut acc = [0u64; 2 * MAXN + 2];
        for i in 0..n {
            Self::mul_acc(&mut acc, &a[i], &b[b.len() - 1 - i]);
        }
        self.redc_wide(&mut acc)
    }
    fn conv_trunc(&self, a: &[Self::E], b: &[Self::E], nout: usize) -> Vec<Self::E> {
        if let Some(red) = &self.red1 {
            // sum of (aR)(bR), one Montgomery reduction per coefficient: (sum ab) R
            let v = crate::field::lazy_conv(limbs1(a), limbs1(b), red, nout, |x| red.redc(x));
            return v
                .into_iter()
                .map(|x| {
                    let mut t = [0u64; N];
                    t[0] = x;
                    t
                })
                .collect();
        }
        // lazy reduction: one wide Montgomery reduction per output coefficient
        let mut r = Vec::with_capacity(nout);
        for k in 0..nout {
            let lo = k.saturating_sub(b.len() - 1);
            let hi = k.min(a.len() - 1);
            let mut acc = [0u64; 2 * MAXN + 2];
            for i in lo..=hi {
                Self::mul_acc(&mut acc, &a[i], &b[k - i]);
            }
            r.push(if lo > hi {
                [0u64; N]
            } else {
                self.redc_wide(&mut acc)
            });
        }
        r
    }
    fn conv_sq(&self, a: &[Self::E]) -> Vec<Self::E> {
        if let Some(red) = &self.red1 {
            // sum of (aR)(aR), one Montgomery reduction per coefficient: (sum a a) R
            let v = crate::field::lazy_sq(limbs1(a), red, |x| red.redc(x));
            return v
                .into_iter()
                .map(|x| {
                    let mut t = [0u64; N];
                    t[0] = x;
                    t
                })
                .collect();
        }
        // coefficient k: 2 sum_{i < k - i} a_i a_{k-i} (+ a_{k/2}^2), lazily accumulated
        let n = a.len();
        let mut r = Vec::with_capacity(2 * n - 1);
        for k in 0..2 * n - 1 {
            let lo = k.saturating_sub(n - 1);
            let mut acc = [0u64; 2 * MAXN + 2];
            let mut i = lo;
            while 2 * i < k {
                Self::mul_acc(&mut acc, &a[i], &a[k - i]);
                i += 1;
            }
            let mut top = 0u64;
            for w in acc[..2 * N + 2].iter_mut() {
                let nt = *w >> 63;
                *w = (*w << 1) | top;
                top = nt;
            }
            if k % 2 == 0 {
                Self::mul_acc(&mut acc, &a[k / 2], &a[k / 2]);
            }
            r.push(self.redc_wide(&mut acc));
        }
        r
    }
    fn prepare(&self, b: &[Self::E], max_len: usize, cyc: usize) -> Option<crate::field::Prepared> {
        let thr = NTT_N.with(|k| k.get()).unwrap_or(self.ntt_threshold());
        if b.is_empty() || b.len().min(max_len) < thr {
            return None;
        }
        Some(std::rc::Rc::new(crate::ntt::prepare(
            b, self.pbits, max_len, cyc,
        )))
    }
    fn conv_prepared(&self, a: &[Self::E], b: &crate::field::Prepared) -> Option<Vec<Self::E>> {
        let (u, t, set) = crate::ntt::conv_crt_prepared(a, b.downcast_ref()?)?;
        Some(self.fold(&u, t, set))
    }
    fn conv_cyclic(&self, a: &[Self::E], b: &[Self::E], len: usize) -> Option<Vec<Self::E>> {
        let thr = NTT_N.with(|k| k.get()).unwrap_or(self.ntt_threshold());
        if a.len().min(b.len()) < thr || a.len() + b.len() - 1 <= len {
            return None;
        }
        assert!(len.is_power_of_two() && a.len().max(b.len()) <= len + 1);
        Some(self.fold_crt(a, b, len))
    }
    fn conv_long(&self, a: &[Self::E], b: &[Self::E]) -> Option<Vec<Self::E>> {
        let thr = NTT_N.with(|k| k.get()).unwrap_or(self.ntt_threshold());
        if a.len().min(b.len()) < thr {
            return None;
        }
        // the Montgomery residues aR, bR as integers: exact convolution T = sum (aR)(bR) in
        // explicit-CRT form, T = sum_i u_i C_i - q M with C_i = M / m_i; folded mod p as
        // sum_i u_i (C_i mod p) + q (-M mod p), all terms non-negative, then one
        // Montgomery reduction gives T R^{-1} = (sum ab) R, as `conv_trunc` returns
        let nout = a.len() + b.len() - 1;
        // a product just past a power of two L (at most 3L/8 beyond, both operands at most
        // L + 1 long): transform at L, mod x^L - 1, and take the wrapped top coefficients
        // V_k (k >= L) from the product of the operands' high ends instead of doubling the
        // transform. V_k for k >= L only involves a_i with i >= L + 1 - len(b) and b_j with
        // j >= L + 1 - len(a): it is coefficient k - (2L + 1 - nout) of that short product.
        let half = nout.next_power_of_two() / 2;
        if half >= 64 && nout - half <= 3 * half / 8 && a.len().max(b.len()) <= half + 1 {
            let ah = &a[half + 1 - b.len()..];
            let bh = &b[half + 1 - a.len()..];
            let top = if std::ptr::eq(a, b) {
                crate::poly::sqr_raw(self, ah)
            } else {
                crate::poly::mul_raw(self, ah, bh)
            };
            let mut r = self.fold_crt(a, b, half);
            let off = 2 * half + 1 - nout;
            for k in half..nout {
                let v = top[k - off];
                r[k - half] = self.sub(r[k - half], v);
                r.push(v);
            }
            return Some(r);
        }
        Some(self.fold_crt(a, b, usize::MAX))
    }
    fn powmod_table_max(&self) -> usize {
        // measured crossovers (examples/profile_powmod.rs); Barrett's two products win from a
        // shorter modulus with the IFMA transforms
        if crate::ntt::simd_active() {
            match N {
                1 => 44,
                2 => 60,
                3 | 4 => 52,
                _ => 40,
            }
        } else {
            match N {
                1 => 160,
                2 => 140,
                3 | 4 => 110,
                _ => 85,
            }
        }
    }
    fn sqr_threshold(&self) -> usize {
        // schoolbook squares form each cross product once, so they stay ahead of Karatsuba
        // much longer than general products (examples/profile_sqr.rs); with the IFMA
        // transforms a multi-limb square goes to the NTT (one transform) from its threshold
        let school = match N {
            1 if self.pbits <= 62 => 72,
            2..=4 => 96,
            _ => 64,
        };
        if N > 1 && crate::ntt::simd_active() {
            school.min(self.ntt_threshold())
        } else {
            school
        }
    }
    fn karatsuba_threshold(&self) -> usize {
        // one limb below 2^62: the four-output lazy kernel stays ahead of Karatsuba to ~72
        KARATSUBA_N.with(|k| k.get()).unwrap_or(match N {
            1 if self.red1.is_some() => 72,
            1 => 32,
            _ => 16,
        })
    }
    fn size(&self) -> u128 {
        self.pbig
            .to_u128()
            .expect("FpM::size: modulus exceeds 128 bits; use q()")
    }
    fn q(&self) -> Big {
        self.pbig.clone()
    }
    fn random(&self, rng: &mut Rng) -> Self::E {
        let top_bits = self.pbits as usize - 64 * (N - 1);
        loop {
            let mut r = [0u64; N];
            for x in r.iter_mut() {
                *x = rng.next();
            }
            if top_bits < 64 {
                r[N - 1] &= (1u64 << top_bits) - 1;
            }
            if !geq(&r, &self.p) {
                return r;
            }
        }
    }
}

impl<const N: usize> FpM<N> {
    /// The convolution of `conv_long` from `ntt::conv_crt` (mod x^cyc - 1 when `cyc` is below
    /// the product length), folded mod p.
    fn fold_crt(&self, a: &[[u64; N]], b: &[[u64; N]], cyc: usize) -> Vec<[u64; N]> {
        let (u, t, set) = crate::ntt::conv_crt(a, b, self.pbits, cyc);
        self.fold(&u, t, set)
    }
    /// Explicit-CRT residues from `ntt` (t per coefficient over `set`) folded mod p.
    fn fold(&self, u: &[u64], t: usize, set: &crate::ntt::PrimeSet) -> Vec<[u64; N]> {
        let ps = &set.primes[..t];
        if let Some(red) = &self.red1 {
            // one limb: t + 1 <= 9 products below 2^124 each (u_i, p < 2^62) fit a u128
            assert!(t <= 8);
            let mut cm = [0u64; 8];
            for (i, c) in cm[..t].iter_mut().enumerate() {
                *c = ps
                    .iter()
                    .enumerate()
                    .filter(|&(j, _)| j != i)
                    .fold(1u64, |c, (_, pj)| red.reduce(c as u128 * pj.p as u128));
            }
            let mneg = (self.p[0] - red.reduce(cm[0] as u128 * ps[0].p as u128)) % self.p[0];
            return u
                .chunks_exact(t)
                .map(|ui| {
                    let mut s = set.quotient(ui) as u128 * mneg as u128;
                    for (x, c) in ui.iter().zip(&cm) {
                        s += *x as u128 * *c as u128;
                    }
                    let mut r = [0u64; N];
                    r[0] = red.redc(s);
                    r
                })
                .collect();
        }
        // the constants carry an extra 2^64, so the N + 1 word reductions of `redc_raw` leave
        // T 2^64 2^(-64 (N + 1)) = T R^{-1} with no correcting product
        let consts = CRT_FOLD.with(|c| {
            let mut c = c.borrow_mut();
            // keyed by p, the prime family (its first prime) and the number of primes
            let key = |p: &[u64], tt: usize| {
                p.len() == N + 1 && p[..N] == self.p[..] && p[N] == ps[0].p && tt == t
            };
            if let Some((_, _, v)) = c.iter().find(|(p, tt, _)| key(p, *tt)) {
                return v.clone();
            }
            let mbig = ps.iter().fold(Big::from_u64(1), |m, pr| m.mul_small(pr.p));
            let shift = |x: &Big| big_mod(&x.shl(64), &self.pbig).limbs(N);
            let mut v: Vec<u64> = ps
                .iter()
                .flat_map(|pr| shift(&mbig.divrem_small(pr.p).0))
                .collect();
            v.extend(shift(&self.pbig.sub(&big_mod(&mbig, &self.pbig))));
            let v = std::rc::Rc::new(v);
            let mut k = self.p.to_vec();
            k.push(ps[0].p);
            c.push((k, t, v.clone()));
            v
        });
        let limb = |i: usize| -> &[u64; N] { consts[i * N..(i + 1) * N].try_into().unwrap() };
        let mneg = limb(t);
        let mut out = Vec::with_capacity(u.len() / t);
        for ui in u.chunks_exact(t) {
            let mut acc = [0u64; 2 * MAXN + 2];
            let q = set.quotient(ui);
            Self::mul_acc_word(&mut acc, q, mneg);
            for (i, x) in ui.iter().enumerate() {
                Self::mul_acc_word(&mut acc, *x, limb(i));
            }
            out.push(self.redc_raw(&mut acc));
        }
        out
    }
}
