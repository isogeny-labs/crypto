"""Copy original exact-reference files; comparison is performed only in Rust."""
from pathlib import Path
import importlib.util,json,shutil,sys
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';ci=Path('/workspace/scratch/ct73-complete-own-CI-01');o=Path('/workspace/scratch/ct73-b691-CI-audit-01');o.mkdir()
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py');mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
digests=json.loads(Path('/workspace/scratch/ct73-c77-own-CI-01/canonical-digests66.json').read_text())
for k,v in digests.items():assert mod.claim_digest(json.loads((r/'pcc/claims'/(k+'.json')).read_text()))==v
for n in ['beta-complete-rational-bindings-01','beta-CRT-projection-bindings-01']:
 for entry in json.loads((s/'evidence'/n/'claims.json').read_text()):
  claim=json.loads((r/entry['claim_path']).read_text());assert claim['id']not in digests;digests[claim['id']]=mod.claim_digest(claim)
assert len(digests)==73;(o/'canonical-digests73.json').write_text(json.dumps(digests,indent=2)+'\n')
g=json.loads(Path('/workspace/scratch/ct73-c77-own-CI-01/all-original-goldens-plus-beta.json').read_text());g['complete']=json.loads((ci/'complete-artifact-members/expected-native.json').read_text());(o/'all-original-goldens-plus-complete.json').write_text(json.dumps(g,separators=(',',':'))+'\n')
for n,sub in [('beta','ci_beta_lift/reference-02.sha256'),('complete','ci_beta_complete/reference-01.sha256')]:shutil.copyfile(s/sub,o/(n+'-reference.sha256'))
for n,sub in [('beta','beta-rational-lift/lean'),('complete','beta-complete-evaluator/lean')]:shutil.copytree(s/sub,o/(n+'-original-proof-source'))
crate=o/'audit-cli';crate.mkdir();(crate/'src').mkdir()
for n in ['Cargo.toml','Cargo.lock']:shutil.copyfile('/workspace/scratch/ct73-c77-own-CI-01/audit-cli/'+n,crate/n)
shutil.copyfile(__file__,o/'prepare.py')
print('73 original canonical digests, whole prior goldens plus whole complete fixture; Rust comparison next')
