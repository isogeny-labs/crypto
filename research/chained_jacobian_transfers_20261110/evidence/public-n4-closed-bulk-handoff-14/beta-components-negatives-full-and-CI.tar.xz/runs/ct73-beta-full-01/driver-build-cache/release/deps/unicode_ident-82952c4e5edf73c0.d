/workspace/scratch/ct73-beta-full-01/driver-build-cache/release/deps/unicode_ident-82952c4e5edf73c0.d: /home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/lib.rs /home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/tables.rs

/workspace/scratch/ct73-beta-full-01/driver-build-cache/release/deps/libunicode_ident-82952c4e5edf73c0.rlib: /home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/lib.rs /home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/tables.rs

/workspace/scratch/ct73-beta-full-01/driver-build-cache/release/deps/libunicode_ident-82952c4e5edf73c0.rmeta: /home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/lib.rs /home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/tables.rs

/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/lib.rs:
/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/tables.rs:
