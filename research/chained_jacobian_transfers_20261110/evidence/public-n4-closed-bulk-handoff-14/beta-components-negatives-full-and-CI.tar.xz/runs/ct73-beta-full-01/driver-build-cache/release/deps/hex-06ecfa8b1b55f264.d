/workspace/scratch/ct73-beta-full-01/driver-build-cache/release/deps/hex-06ecfa8b1b55f264.d: /home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/hex-0.4.3/src/lib.rs /home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/hex-0.4.3/src/error.rs

/workspace/scratch/ct73-beta-full-01/driver-build-cache/release/deps/libhex-06ecfa8b1b55f264.rlib: /home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/hex-0.4.3/src/lib.rs /home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/hex-0.4.3/src/error.rs

/workspace/scratch/ct73-beta-full-01/driver-build-cache/release/deps/libhex-06ecfa8b1b55f264.rmeta: /home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/hex-0.4.3/src/lib.rs /home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/hex-0.4.3/src/error.rs

/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/hex-0.4.3/src/lib.rs:
/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/hex-0.4.3/src/error.rs:
