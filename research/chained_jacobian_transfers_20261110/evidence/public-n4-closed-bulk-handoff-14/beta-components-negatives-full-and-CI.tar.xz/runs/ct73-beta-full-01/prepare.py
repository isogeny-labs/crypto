"""Materialize published Git inputs, preserve custody, invoke the frozen caller."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,sys
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';source=sys.argv[1]
producer='3d49af7f3d0a28e76b79e4825c9d2324e85853d2'
assert subprocess.check_output(['git','rev-parse',source],cwd=r,text=True).strip()==source
layout=Path('/workspace/scratch/ct73-beta-replay-layout-01');layout.mkdir()
reference=s/'ci_beta_lift/reference-02.sha256';refs=[x.split('  ',1)[1]for x in reference.read_text().splitlines()];assert len(refs)==844
for name,repo,commit,files in [
 ('cryptanalysis',r,source,[p for p in refs if not p.startswith('../crypto/')]+['experiments/chained-transfer-public-target/ci_beta_lift/reference-02.sha256']),
 ('crypto',Path('/workspace/crypto'),producer,[p.removeprefix('../crypto/')for p in refs if p.startswith('../crypto/')])]:
 p=layout/name
 q=subprocess.run(['git','worktree','add','--detach','--no-checkout',str(p),commit],cwd=repo,capture_output=True);(layout/(name+'-create.txt')).write_bytes(q.stdout+q.stderr);assert q.returncode==0
 subprocess.run(['git','sparse-checkout','init','--no-cone'],cwd=p,check=True)
 subprocess.run(['git','sparse-checkout','set','--no-cone','--stdin'],cwd=p,input=('\n'.join('/'+x for x in sorted(set(files)))+'\n').encode(),check=True)
 subprocess.run(['git','read-tree','-mu','HEAD'],cwd=p,check=True)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip()==commit
 status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=p);(layout/(name+'-status.txt')).write_bytes(status);assert not status
c=layout/'cryptanalysis';up=layout/'crypto';cs=c/'experiments/chained-transfer-public-target';out=Path('/workspace/scratch/ct73-beta-full-01');out.mkdir()
fixture_relative='experiments/chained-transfer-public-target/evidence/odd-product-maps-acceptance-02/all-native-records.json.xz';fixture=c/fixture_relative
entry=json.loads((fixture.parent/'.artifacts.json').read_text())['files'][fixture.name]
assert entry==dict(bytes=120752,sha256='f5c45a14d9f3496a7136c2976f5a741901e15641047a988fcce0b6ad1e8ca5f4')
raw=(r/fixture_relative).read_bytes();assert len(raw)==entry['bytes']and hashlib.sha256(raw).hexdigest()==entry['sha256'];shutil.copyfile(r/fixture_relative,fixture);fixture.chmod(0o444)
q=subprocess.run(['python3','tools/artifacts/artifacts.py','verify',fixture_relative],cwd=c,capture_output=True);(out/'original-fixture-verify.txt').write_bytes(q.stdout+q.stderr);(out/'original-fixture-verify.exit').write_text(str(q.returncode)+'\n');assert q.returncode==0
(out/'fixture-materialization.json').write_text(json.dumps(dict(path=fixture_relative,entry=entry,method='read-only copy of genuine physical original; original local verifier0; no new remote read',origin='43505654954/22d22eb0e/768f4a/0bb0f5',own_CI='original pinned artifact tool performs independent remote hydration'),indent=2)+'\n')
before={}
for line in reference.read_text().splitlines():
 h,p=line.split('  ',1);path=(c/p).resolve();assert hashlib.sha256(path.read_bytes()).hexdigest()==h,p;before[str(path)]=h
localref=cs/'ci_beta_lift/reference-02.sha256';before[str(localref)]=hashlib.sha256(localref.read_bytes()).hexdigest();assert len(before)==845
(out/'before.json').write_text(json.dumps(before,indent=2)+'\n');shutil.copyfile(__file__,out/'prepare.py');shutil.copyfile(localref,out/'original-reference.sha256')
plan=dict(at=datetime.now(timezone.utc).isoformat(),source=source,producer=producer,protocol='5be5e0/32283c/c08810d5 before implementation',source_inputs=844,outer_guards=845,timeout_s=2400,phase_panel='17ordered:16expected0/oneactual101; everytee0',acceptance='native2unfiltered/all3wholeJSON no masks/IDCpositive0negative101/both unchanged original proof gates21declarations0trusted/six exact bindings/finalguards0',scope='bounded local correctness and CI development; not experiment or benchmark')
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
launcher=Path('/workspace/scratch/ct73-beta-full-01.sh')
launcher.write_text('''#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export ELAN_TOOLCHAIN=leanprover/lean4:v4.35.0
cd /workspace/scratch/ct73-beta-replay-layout-01/cryptanalysis
out=/workspace/scratch/ct73-beta-full-01
date -u +%FT%TZ > "$out/start.txt"
timeout 2400 bash experiments/chained-transfer-public-target/ci_beta_lift/check-02.sh ../crypto "$out/driver" > "$out/native.txt" 2>&1
status=$?
printf '%s\\n' "$status" > "$out/native.exit"
date -u +%FT%TZ > "$out/finish.txt"
python3 - "$out" <<'GUARDS'
from pathlib import Path
import hashlib,json,sys
o=Path(sys.argv[1]);before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in before};changed=[p for p in before if before[p]!=after[p]]
(o/'after.json').write_text(json.dumps(after,indent=2)+'\\n');(o/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\\n');raise SystemExit(bool(changed))
GUARDS
guard=$?
printf '%s\\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
''');shutil.copyfile(launcher,out/'original-command.sh');print(json.dumps(dict(layout=str(layout),source=source,guards=845,launcher=str(launcher))),flush=True)
