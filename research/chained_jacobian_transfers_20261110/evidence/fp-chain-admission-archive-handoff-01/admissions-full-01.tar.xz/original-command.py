from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,os,shutil
layout=Path('/workspace/scratch/ct54-chain-replay-layout');c=layout/'cryptanalysis';up=layout/'crypto';s=c/'experiments/chained-transfer-reference';out=Path('/workspace/scratch/ct54-chain-admissions-01');out.mkdir();driver=s/'check-fp-chain.sh'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=c,text=True).strip()=='a39fefaa084756d0a58386253651a667e2ad9de6';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=up,text=True).strip()=='927a4efe5fe68b4270ae5989f3cbab0b68852f4b';assert not subprocess.check_output(['git','status','--porcelain'],cwd=c);assert not subprocess.check_output(['git','status','--porcelain'],cwd=up)
base=json.loads((s/'evidence/fp-chain-primary-01/baseline.json').read_text());names=set(base['non_workflow_inputs']);names|=set(subprocess.check_output(['git','ls-files','--','experiments/chained-transfer-reference/fp-chain-checker'],cwd=c,text=True).splitlines());names|={'experiments/chained-transfer-reference/check-fp-chain.sh','experiments/chained-transfer-reference/FP_CHAIN_ADAPTER_PROTOCOL.md','experiments/chained-transfer-reference/FP_CHAIN_ADAPTER_DERIVATION.md','experiments/chained-transfer-reference/FP_CHAIN_INDEPENDENT_PROOF.md','experiments/chained-transfer-reference/FP_CHAIN_PROOF_COMPATIBILITY.md','experiments/chained-transfer-reference/fp-chain-upstream-commit.txt','.github/workflows/chained-transfer-reference.yml','.github/workflows/pcc-gate.yml','experiments/chained-transfer-reference/evidence/fp-chain-unit-01/.artifacts.json','experiments/chained-transfer-reference/evidence/fp-chain-unit-01/.gitignore'}
before={n:hashlib.sha256((c/n).read_bytes()).hexdigest() for n in sorted(names)};(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
for n in names:
 dst=out/'source'/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(c/n,dst)
env=os.environ.copy();env['PATH']=os.path.expanduser('~/.cargo/bin')+':'+os.path.expanduser('~/.elan/bin')+':'+env['PATH'];env['RUSTUP_TOOLCHAIN']='1.99.1';results=[]
def control(name,source,environment=env):
 target=out/('allocated-'+name);assert not target.exists();start=datetime.now(timezone.utc).isoformat();p=subprocess.run(['/usr/bin/timeout','60','/usr/bin/bash',str(driver),str(source),str(target)],cwd=c,env=environment,capture_output=True);finish=datetime.now(timezone.utc).isoformat();(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);meta=dict(name=name,start=start,finish=finish,original_exit=p.returncode,output_allocated=target.exists(),source=str(source));(out/(name+'.json')).write_text(json.dumps(meta,indent=2)+'\n');results.append(meta);print(name,p.returncode,'allocated',target.exists(),p.stderr.decode().strip(),flush=True);assert p.returncode==2 and not target.exists();return p.stderr
assert b'HEAD mismatch' in control('wrong-head',Path('/workspace/crypto'))
for name,path,addition in [('dirty-source',s/'fp-chain-checker/src/lib.rs',b'\n// admission control: deliberately dirty new source\n'),('dirty-fixture',s/'fp-chain-checker/fixtures/c0-t20.json',b'\n ')]:
 data=path.read_bytes();(out/(name+'-original')).write_bytes(data);(out/(name+'-mutant')).write_bytes(data+addition)
 try:
  path.write_bytes(data+addition);assert b'consumer has modified or untracked protected inputs' in control(name,up)
 finally:path.write_bytes(data)
shim=out/'path-without-grep';shim.mkdir()
for name in ['bash','git','awk','timeout','sha256sum','cargo','rustfmt','lean','find','sort','xargs','cmp','mktemp','date','python3','cat','wc','tee','dirname']:
 src=shutil.which(name,path=env['PATH']);assert src,name;(shim/name).symlink_to(src)
missing=env.copy();missing['PATH']=str(shim);assert b'missing fp-chain replay tool:grep' in control('missing-grep',up,missing)
after={n:hashlib.sha256((c/n).read_bytes()).hexdigest() for n in before};assert before==after;assert not subprocess.check_output(['git','status','--porcelain'],cwd=c);assert not subprocess.check_output(['git','status','--porcelain'],cwd=up);(out/'after.json').write_text(json.dumps(after,indent=2)+'\n');(out/'results.json').write_text(json.dumps(dict(controls=results,source_hashes=len(before),all_unchanged=True,all_clean=True,scope='actual four strict admission rejections before any output/cache allocation;no native scientific execution'),indent=2)+'\n');print('ALL FOUR admissions pass/source restored',len(before),flush=True)
