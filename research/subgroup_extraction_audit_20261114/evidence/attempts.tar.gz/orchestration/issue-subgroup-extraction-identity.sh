#!/usr/bin/env bash
set -eu
cd /workspace/crypto-audit
p=research/subgroup_extraction_audit_20261114
mkdir -p "$p/evidence"
rustc --edition=2021 "$p/issue_identity.rs" -L dependency=target/release/deps --extern serde=target/release/deps/libserde-0bf82e85196bd177.rlib --extern serde_json=target/release/deps/libserde_json-458049281485fb75.rlib --extern hex="$(find target/release/deps -maxdepth 1 -name 'libhex-*.rlib' -print -quit)" -o /workspace/scratch/subgroup-extraction-identity-issuer > "$p/evidence/identity-build.log" 2>&1
proof_hash=$(sha256sum "$p/lean/PrimeRecovery.lean" | cut -d' ' -f1)
/workspace/scratch/subgroup-extraction-identity-issuer "$proof_hash" > "$p/identity-certificate.json" 2> "$p/evidence/identity-check.log"
