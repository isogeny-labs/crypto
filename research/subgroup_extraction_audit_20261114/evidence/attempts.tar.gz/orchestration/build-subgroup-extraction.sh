#!/usr/bin/env bash
set -u
target=$1
attempt=$2
project=/workspace/crypto-audit/research/subgroup_extraction_audit_20261114/lean
record=/workspace/scratch/subgroup-extraction-attempts/$target-$attempt
mkdir -p "$record"
cd "$project" || exit 1
cp -- *.lean lakefile.toml lake-manifest.json lean-toolchain "$record/"
lake build "$target" > "/workspace/scratch/subgroup-extraction-$target-build$attempt.log" 2>&1
result=$?
printf '%s\n' "$result" > "/workspace/scratch/subgroup-extraction-$target-build$attempt.exit"
tail -n 65 "/workspace/scratch/subgroup-extraction-$target-build$attempt.log"
exit "$result"
