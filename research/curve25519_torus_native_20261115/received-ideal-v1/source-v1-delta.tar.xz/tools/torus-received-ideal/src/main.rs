use serde_json::json;
use sha2::{Digest, Sha256};
use std::{
    fs::OpenOptions,
    io::{BufWriter, Write},
    path::PathBuf,
};
use torus_received_ideal::Result;
fn run() -> Result<()> {
    let (mut out, mut qualify, mut transport) = (None, false, false);
    let mut args = std::env::args().skip(1);
    while let Some(a) = args.next() {
        match a.as_str() {
            "--out" => out = Some(PathBuf::from(args.next().ok_or("output path")?)),
            "--qualify" => qualify = true,
            "--transport-only" => transport = true,
            _ => return Err("unknown argument".into()),
        }
    }
    if qualify {
        let inputs = [
            ("Cargo.toml", include_str!("../Cargo.toml")),
            ("Cargo.lock", include_str!("../Cargo.lock")),
            ("lib.rs", include_str!("lib.rs")),
            ("main.rs", include_str!("main.rs")),
            ("FIXTURES.json", include_str!("../FIXTURES.json")),
        ];
        println!(
            "{}",
            json!({"kind":"source_qualifier","inputs":inputs.iter().map(|(p,b)|json!({"path":p,"sha256":format!("{:x}",Sha256::digest(b.as_bytes()))})).collect::<Vec<_>>(),"decoder_implemented":false,"bounded_box":[10,4]})
        );
        return Ok(());
    }
    let mut w = BufWriter::new(
        OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(out.ok_or("--out required")?)
            .map_err(|e| e.to_string())?,
    );
    if transport {
        writeln!(w, "{}", json!({"kind":"transport_only","math_run":false}))
            .map_err(|e| e.to_string())?;
    } else {
        torus_received_ideal::run(&mut w)?;
    }
    w.flush().map_err(|e| e.to_string())
}
fn main() {
    if let Err(e) = run() {
        eprintln!("received-ideal-control: {e}");
        std::process::exit(1)
    }
}
