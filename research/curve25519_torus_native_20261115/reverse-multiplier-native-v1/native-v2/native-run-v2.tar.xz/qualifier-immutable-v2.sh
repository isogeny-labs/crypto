#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /workspace/isogeny-labs/crypto-spectrum-assessment-20261123
sha256sum --check research/curve25519_torus_native_20261115/reverse-multiplier-native-v1/SOURCES_V2.sha256 > /workspace/curve25519-reverse-multiplier-native-v1/qualifier-source-v2.log
/workspace/curve25519-native-binaries/reverse-multiplier-control-v2 --qualifier > /workspace/curve25519-reverse-multiplier-native-v1/binary-qualifier-v2.json
