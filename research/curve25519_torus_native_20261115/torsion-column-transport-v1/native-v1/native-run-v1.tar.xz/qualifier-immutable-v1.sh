#!/usr/bin/env bash
set -euo pipefail
set -C
cd /workspace/isogeny-labs/crypto-spectrum-assessment-20261123
sha256sum -c research/curve25519_torus_native_20261115/torsion-column-transport-v1/SOURCES.sha256 > /workspace/curve25519-torsion-column-transport-v1/qualifier-source.log
/workspace/curve25519-native-binaries/column-transport-control-v1 --qualifier > /workspace/curve25519-torsion-column-transport-v1/qualified-builtins.json
python3 - <<'PY'
import hashlib,json
from pathlib import Path
p=Path('/workspace/curve25519-torsion-column-transport-v1')
b=json.loads((p/'BUILD.json').read_text());binary=Path(b['binary']).read_bytes()
assert len(binary)==b['bytes'] and hashlib.sha256(binary).hexdigest()==b['sha256']
q=json.loads((p/'qualified-builtins.json').read_text());assert len(q['compiled_inputs'])==6
for name,h in q['compiled_inputs'].items():
    assert hashlib.sha256((Path('tools/torus-column-transport')/name).read_bytes()).hexdigest()==h,name
print('source111/compiled6/retained executable metadata match; no mathematical control ran')
PY
