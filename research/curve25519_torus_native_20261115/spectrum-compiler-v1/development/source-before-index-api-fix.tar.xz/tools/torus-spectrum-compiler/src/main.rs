use std::{io::Write,path::Path};
fn main() {
    let args:Vec<_>=std::env::args().collect();
    if args.len()!=2 {eprintln!("usage: torus-spectrum-compiler EMPTY_EXPORT_DIRECTORY");std::process::exit(2);}
    let dir=Path::new(&args[1]);
    if !dir.is_dir() {eprintln!("export directory must already exist");std::process::exit(2);}
    let mut out=std::io::BufWriter::new(std::io::stdout().lock());
    if let Err(e)=torus_spectrum_compiler::controls::run(Some(dir),&mut out) {let _=out.flush();eprintln!("{e}");std::process::exit(1);}
}
