//! CPU/CUDA/host-RDMA dispatch for exact packed F2 RREF. Default is CPU.
//! Auto modes calibrate each exact shape against CPU, including allocation,
//! copies and network costs, and require identical matrix/rank/word counts.
use serde::Serialize;
use std::{cell::RefCell, collections::HashMap, time::Instant};
#[derive(Clone, Debug, Default, Serialize)]
pub struct DispatchStats {
    pub cpu_jobs: u64,
    pub offload_jobs: u64,
    pub failures: u64,
    pub calibrated_shapes: u64,
    pub calibration_ns: u128,
    pub calibration_word_xors: u64,
    pub offload_ns: u128,
}
#[derive(Default)]
struct State {
    decisions: HashMap<(usize, usize, String), bool>,
    stats: DispatchStats,
}
thread_local! { static STATE: RefCell<State> = RefCell::new(State::default()); }
pub fn stats() -> DispatchStats {
    STATE.with(|s| s.borrow().stats.clone())
}
pub fn reset() {
    STATE.with(|s| *s.borrow_mut() = State::default());
}
#[cfg(feature = "ic-cuda")]
unsafe extern "C" {
    fn ic_f2_cuda(data: *mut u64, rows: usize, cols: usize, rank: *mut usize, ops: *mut u64)
        -> i32;
}
#[cfg(feature = "ic-rdma")]
unsafe extern "C" {
    fn ic_f2_rdma(
        data: *mut u64,
        rows: usize,
        cols: usize,
        rank: *mut usize,
        ops: *mut u64,
        host: *const std::ffi::c_char,
        port: u32,
        timeout_ms: u32,
        gpu: u32,
    ) -> i32;
}
fn offload(matrix: &[Vec<u64>], cols: usize, backend: &str) -> Option<(Vec<Vec<u64>>, usize, u64)> {
    let rows = matrix.len();
    let words = cols.div_ceil(64);
    if rows == 0
        || rows > 4096
        || cols == 0
        || cols > 32768
        || matrix.iter().any(|r| r.len() != words)
    {
        return None;
    }
    if cols % 64 != 0 && matrix.iter().any(|r| r[words - 1] >> (cols % 64) != 0) {
        return None;
    }
    #[allow(unused_mut)]
    let mut data: Vec<u64> = matrix.iter().flatten().copied().collect();
    #[allow(unused_mut)]
    let (mut rank, mut ops) = (0usize, 0u64);
    #[allow(unused_variables)]
    let status = match backend {
        #[cfg(feature = "ic-cuda")]
        "cuda" => unsafe { ic_f2_cuda(data.as_mut_ptr(), rows, cols, &mut rank, &mut ops) },
        #[cfg(feature = "ic-rdma")]
        "rdma-cpu" | "rdma-cuda" => {
            let host = std::ffi::CString::new(std::env::var("IC_RDMA_IPV4").ok()?).ok()?;
            let port = std::env::var("IC_RDMA_PORT").ok()?.parse().ok()?;
            let timeout = std::env::var("IC_RDMA_TIMEOUT_MS")
                .ok()
                .and_then(|s| s.parse().ok())
                .unwrap_or(2000);
            unsafe {
                ic_f2_rdma(
                    data.as_mut_ptr(),
                    rows,
                    cols,
                    &mut rank,
                    &mut ops,
                    host.as_ptr(),
                    port,
                    timeout,
                    u32::from(backend == "rdma-cuda"),
                )
            }
        }
        _ => -1,
    };
    if status != 0 || rank > rows.min(cols) {
        return None;
    }
    Some((
        data.chunks_exact(words).map(|r| r.to_vec()).collect(),
        rank,
        ops,
    ))
}
/// The callback is the original CPU reducer. Offload failures leave its input
/// untouched. Cache and placement scopes belong to the executing worker thread.
pub fn reduce(
    matrix: &mut [Vec<u64>],
    cols: usize,
    ops: &mut u64,
    cpu: fn(&mut [Vec<u64>], usize, &mut u64) -> usize,
) -> usize {
    let mode = std::env::var("IC_F2_BACKEND").unwrap_or_else(|_| "cpu".into());
    let cpu_run = |matrix: &mut [Vec<u64>], ops: &mut u64| {
        STATE.with(|s| s.borrow_mut().stats.cpu_jobs += 1);
        cpu(matrix, cols, ops)
    };
    if mode == "cpu" || matrix.is_empty() || cols == 0 {
        return cpu_run(matrix, ops);
    }
    let auto = mode == "auto" || mode.starts_with("auto-");
    let backend = if mode == "auto" {
        "cuda"
    } else {
        mode.strip_prefix("auto-").unwrap_or(&mode)
    };
    // Endpoint changes must not reuse placement measurements for a different host.
    let identity = format!(
        "{}:{:?}:{:?}:{:?}",
        backend,
        std::env::var("IC_RDMA_IPV4").ok(),
        std::env::var("IC_RDMA_PORT").ok(),
        std::env::var("IC_RDMA_TIMEOUT_MS").ok()
    );
    let key = (matrix.len(), cols, identity);
    let decision = STATE.with(|s| s.borrow().decisions.get(&key).copied());
    if auto && decision == Some(false) {
        return cpu_run(matrix, ops);
    }
    if auto && decision.is_none() {
        // Keep tuning storage bounded when a solver produces many distinct shapes.
        if STATE.with(|s| s.borrow().decisions.len() >= 128) {
            return cpu_run(matrix, ops);
        }
        let start = Instant::now();
        let mut cpu_times = Vec::new();
        let mut gpu_times = Vec::new();
        let mut expected = Vec::new();
        let (mut expected_rank, mut expected_ops) = (0, 0);
        let mut verified = true;
        let mut calibration_ops = 0;
        for repetition in 0..3 {
            let mut original = matrix.to_vec();
            let mut count = 0;
            // The production CPU reducer operates in place. Preserve the
            // calibration input outside its timer; calibration_ns still pays it.
            let t = Instant::now();
            let rank = cpu(&mut original, cols, &mut count);
            cpu_times.push(t.elapsed().as_nanos());
            calibration_ops += count;
            let t = Instant::now();
            let candidate = offload(matrix, cols, backend);
            gpu_times.push(t.elapsed().as_nanos());
            let matched = match candidate {
                Some((ref output, r, o)) => {
                    calibration_ops += o;
                    output == &original && rank == r && count == o
                }
                None => false,
            };
            if repetition == 0 {
                expected = original;
                expected_rank = rank;
                expected_ops = count;
            }
            if !matched {
                verified = false;
                break;
            }
        }
        cpu_times.sort_unstable();
        gpu_times.sort_unstable();
        let use_device = verified && gpu_times[1] < cpu_times[1].saturating_mul(95) / 100;
        STATE.with(|s| {
            let mut s = s.borrow_mut();
            s.decisions.insert(key, use_device);
            s.stats.calibrated_shapes += 1;
            s.stats.calibration_ns += start.elapsed().as_nanos();
            s.stats.calibration_word_xors += calibration_ops;
            if !verified {
                s.stats.failures += 1;
            }
        });
        // Calibration already produced the verified answer; never solve a fourth time.
        matrix.clone_from_slice(&expected);
        *ops += expected_ops;
        return expected_rank;
    }
    let start = Instant::now();
    let result = offload(matrix, cols, backend);
    STATE.with(|s| s.borrow_mut().stats.offload_ns += start.elapsed().as_nanos());
    if let Some((output, rank, count)) = result {
        matrix.clone_from_slice(&output);
        *ops += count;
        STATE.with(|s| s.borrow_mut().stats.offload_jobs += 1);
        rank
    } else {
        STATE.with(|s| {
            let mut s = s.borrow_mut();
            s.stats.failures += 1;
            s.decisions.insert(key, false);
        });
        cpu_run(matrix, ops)
    }
}

#[cfg(all(test, feature = "ic-cuda"))]
mod tests {
    use super::*;
    #[test]
    #[ignore = "requires a CUDA device"]
    fn native_cuda_matches_independent_boolean_oracle() {
        for (rows, cols) in [(1, 1), (13, 65), (64, 129), (96, 257)] {
            let mut state = 0x123456789abcdefu64;
            let mut bits = vec![vec![false; cols]; rows];
            for r in 0..rows {
                for c in 0..cols {
                    state ^= state << 13;
                    state ^= state >> 7;
                    state ^= state << 17;
                    bits[r][c] = r % 5 != 0 && c % 17 != 0 && state & 1 != 0;
                }
            }
            if rows > 3 {
                bits[2] = bits[1].clone();
            }
            let pack = |bits: &Vec<Vec<bool>>| -> Vec<Vec<u64>> {
                bits.iter()
                    .map(|r| {
                        let mut out = vec![0u64; cols.div_ceil(64)];
                        for (c, &b) in r.iter().enumerate() {
                            if b {
                                out[c / 64] |= 1u64 << (c % 64);
                            }
                        }
                        out
                    })
                    .collect()
            };
            let input = pack(&bits);
            let mut rank = 0;
            let mut row_xors = 0;
            for c in 0..cols {
                let Some(p) = (rank..rows).find(|&r| bits[r][c]) else {
                    continue;
                };
                bits.swap(rank, p);
                for r in 0..rows {
                    if r != rank && bits[r][c] {
                        for k in 0..cols {
                            bits[r][k] ^= bits[rank][k];
                        }
                        row_xors += 1;
                    }
                }
                rank += 1;
                if rank == rows {
                    break;
                }
            }
            let (output, r, ops) = offload(&input, cols, "cuda").expect("CUDA unavailable");
            assert_eq!(output, pack(&bits));
            assert_eq!(r, rank);
            assert_eq!(ops, row_xors * cols.div_ceil(64) as u64);
        }
    }
}
