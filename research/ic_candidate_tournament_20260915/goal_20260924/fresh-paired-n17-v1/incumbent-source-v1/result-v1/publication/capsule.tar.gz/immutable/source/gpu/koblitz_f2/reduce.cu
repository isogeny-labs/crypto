// F2 bit-packed RREF. Independent row/word XORs on CUDA; one block controls
// sequential pivots. This is binary arithmetic, not the Fp Macaulay kernel.
#include <cuda_runtime.h>
#include <cstdint>
#include <cstddef>
#include <algorithm>
__global__ void reduce_kernel(uint64_t* a, int rows, int cols, int* rank, unsigned long long* ops) {
    extern __shared__ int flags[];
    __shared__ int next, pivot, current;
    int words = (cols + 63) / 64;
    if (threadIdx.x == 0) { current = 0; *ops = 0; }
    __syncthreads();
    for (int col = 0; col < cols; ++col) {
        // All warps must finish reading the previous pivot before thread 0
        // can publish the next one, including when a column has no pivot.
        __syncthreads();
        int w = col / 64; uint64_t bit = uint64_t(1) << (col % 64);
        if (threadIdx.x == 0) {
            pivot = -1; next = current;
            for (int r = current; r < rows; ++r) if (a[size_t(r)*words+w] & bit) { pivot = r; break; }
        }
        __syncthreads();
        if (pivot < 0) continue;
        for (int k = threadIdx.x; k < words; k += blockDim.x) {
            uint64_t tmp = a[size_t(next)*words+k];
            a[size_t(next)*words+k] = a[size_t(pivot)*words+k];
            a[size_t(pivot)*words+k] = tmp;
        }
        __syncthreads();
        // Snapshot elimination flags before any thread mutates the pivot column.
        for (int r = threadIdx.x; r < rows; r += blockDim.x)
            flags[r] = r != next && (a[size_t(r)*words+w] & bit) != 0;
        __syncthreads();
        for (size_t i = threadIdx.x; i < size_t(rows)*words; i += blockDim.x)
            if (flags[i / words]) a[i] ^= a[size_t(next)*words + i % words];
        __syncthreads();
        if (threadIdx.x == 0) {
            // Force scalar reads for the counter tail. CUDA 13.2 vectorized
            // this loop into a 12-byte shared read past a 13-row allocation.
            const volatile int* count_flags = flags;
            for (int r = 0; r < rows; ++r) if (count_flags[r]) *ops += words;
            ++current;
        }
        __syncthreads();
        if (current == rows) break;
    }
    if (threadIdx.x == 0) *rank = current;
}
extern "C" int ic_f2_cuda(uint64_t* data, size_t rows, size_t cols, size_t* rank, uint64_t* ops) {
    if (!data || !rank || !ops || !rows || rows > 4096 || !cols || cols > 32768) return -1;
    size_t bytes = rows*((cols+63)/64)*sizeof(uint64_t);
    uint64_t* device = nullptr; int* device_rank = nullptr; unsigned long long* device_ops = nullptr;
    int result = -1, r = 0; unsigned long long o = 0;
    cudaStream_t stream = nullptr;
    if (cudaStreamCreateWithFlags(&stream, cudaStreamNonBlocking) != cudaSuccess) goto done;
    if (cudaMalloc(&device, bytes) != cudaSuccess || cudaMalloc(&device_rank, sizeof(int)) != cudaSuccess ||
        cudaMalloc(&device_ops, sizeof(unsigned long long)) != cudaSuccess) goto done;
    if (cudaMemcpyAsync(device, data, bytes, cudaMemcpyHostToDevice, stream) != cudaSuccess) goto done;
    reduce_kernel<<<1,256,rows*sizeof(int),stream>>>(device, rows, cols, device_rank, device_ops);
    if (cudaGetLastError() != cudaSuccess || cudaStreamSynchronize(stream) != cudaSuccess) goto done;
    if (cudaMemcpy(data, device, bytes, cudaMemcpyDeviceToHost) != cudaSuccess ||
        cudaMemcpy(&r, device_rank, sizeof(r), cudaMemcpyDeviceToHost) != cudaSuccess ||
        cudaMemcpy(&o, device_ops, sizeof(o), cudaMemcpyDeviceToHost) != cudaSuccess) goto done;
    *rank = r; *ops = o; result = 0;
done:
    if (stream) cudaStreamSynchronize(stream);
    if (device) cudaFree(device); if (device_rank) cudaFree(device_rank); if (device_ops) cudaFree(device_ops);
    if (stream) cudaStreamDestroy(stream);
    return result;
}
