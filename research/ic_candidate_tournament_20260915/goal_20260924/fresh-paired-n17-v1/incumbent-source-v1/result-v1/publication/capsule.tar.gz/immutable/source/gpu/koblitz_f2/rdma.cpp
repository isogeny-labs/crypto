// Host-memory RDMA via rdma-core rsockets. GPU worker mode stages completed
// host receives through CUDA. This is not GPUDirect/peer-memory RDMA.
#include <rdma/rsocket.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <chrono>
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <vector>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#ifdef IC_F2_TEST_TCP
// Protocol tests only. Production builds always use rdma-core rsockets.
#define rsocket socket
#define rbind bind
#define rlisten listen
#define raccept accept
#define rconnect connect
#define rclose close
#define rfcntl fcntl
#define rpoll poll
#define rgetsockopt getsockopt
#define rrecv recv
#define rsend send
#include <unistd.h>
#endif
using Clock = std::chrono::steady_clock;
struct Socket { int fd=-1; ~Socket() { if (fd>=0) rclose(fd); } };
static bool ready(int fd, short event, Clock::time_point deadline) {
    auto ms=std::chrono::duration_cast<std::chrono::milliseconds>(deadline-Clock::now()).count();
    if (ms<=0) return false;
    pollfd p{fd,event,0};
    int r=rpoll(&p,1,int(ms));
    return r>0 && (p.revents & event) && !(p.revents & (POLLERR|POLLNVAL));
}
static bool transfer(int fd, void* buffer, size_t bytes, bool sending, Clock::time_point deadline) {
    auto p=static_cast<unsigned char*>(buffer);
    while(bytes) {
        if(!ready(fd,sending?POLLOUT:POLLIN,deadline)) return false;
        ssize_t n=sending?rsend(fd,p,bytes,MSG_DONTWAIT|MSG_NOSIGNAL):rrecv(fd,p,bytes,MSG_DONTWAIT);
        if(n<0 && (errno==EAGAIN || errno==EINTR)) continue;
        if(n<=0) return false;
        p+=n; bytes-=size_t(n);
    }
    return true;
}
static bool address(const char* host, unsigned port, sockaddr_in& a) {
    if (!port || port>65535) return false;
    a={}; a.sin_family=AF_INET; a.sin_port=htons(port);
    return inet_pton(AF_INET,host,&a.sin_addr)==1;
}
static bool little_endian() { uint32_t v=1; return *reinterpret_cast<unsigned char*>(&v)==1; }
extern "C" int ic_f2_rdma(uint64_t* data,size_t rows,size_t cols,size_t* rank,uint64_t* ops,
                         const char* host,unsigned port,unsigned timeout_ms,unsigned gpu) {
    if(!data || !rank || !ops || !host || !little_endian() || !rows || rows>4096 || !cols || cols>32768 ||
       !timeout_ms || timeout_ms>60000 || gpu>1) return -1;
    sockaddr_in a; if(!address(host,port,a)) return -1;
    Socket s; s.fd=rsocket(AF_INET,SOCK_STREAM,0); if(s.fd<0) return -1;
    if(rfcntl(s.fd,F_SETFL,O_NONBLOCK)<0) return -1;
    auto deadline=Clock::now()+std::chrono::milliseconds(timeout_ms);
    int status=rconnect(s.fd,reinterpret_cast<sockaddr*>(&a),sizeof(a));
    if(status<0 && errno!=EINPROGRESS) return -1;
    if(status<0) {
        if(!ready(s.fd,POLLOUT,deadline)) return -1;
        int error=0; socklen_t len=sizeof(error);
        if(rgetsockopt(s.fd,SOL_SOCKET,SO_ERROR,&error,&len)<0 || error) return -1;
    }
    // All header words network-endian; matrix/operation words little-endian.
    uint32_t header[]={htonl(0x49434631),htonl(uint32_t(rows)),htonl(uint32_t(cols)),htonl(gpu)};
    size_t bytes=rows*((cols+63)/64)*8;
    if(!transfer(s.fd,header,sizeof(header),true,deadline) || !transfer(s.fd,data,bytes,true,deadline)) return -1;
    uint32_t response[2]; uint64_t operations=0;
    if(!transfer(s.fd,response,sizeof(response),false,deadline) || ntohl(response[0])!=0x49434631 ||
       ntohl(response[1])>std::min(rows,cols) || !transfer(s.fd,&operations,8,false,deadline) ||
       !transfer(s.fd,data,bytes,false,deadline)) return -1;
    *rank=ntohl(response[1]); *ops=operations; return 0;
}
#ifdef IC_F2_SERVER
#ifdef IC_F2_SERVER_CUDA
extern "C" int ic_f2_cuda(uint64_t*,size_t,size_t,size_t*,uint64_t*);
#endif
static size_t cpu(std::vector<uint64_t>& a,size_t rows,size_t cols,uint64_t& ops) {
    size_t words=(cols+63)/64, rank=0; ops=0;
    for(size_t c=0;c<cols && rank<rows;++c) {
        size_t p=rank; uint64_t bit=uint64_t(1)<<(c%64);
        while(p<rows && !(a[p*words+c/64]&bit)) ++p;
        if(p==rows) continue;
        for(size_t w=0;w<words;++w) std::swap(a[p*words+w],a[rank*words+w]);
        for(size_t r=0;r<rows;++r) if(r!=rank && (a[r*words+c/64]&bit)) {
            for(size_t w=0;w<words;++w) a[r*words+w]^=a[rank*words+w]; ops+=words;
        }
        ++rank;
    }
    return rank;
}
int main(int argc,char** argv) {
    if(argc!=4 || !little_endian()) { std::fprintf(stderr,"usage: rdma-worker BIND_IPV4 PORT MAX_JOBS\n"); return 2; }
    unsigned port=std::strtoul(argv[2],nullptr,10), jobs=std::strtoul(argv[3],nullptr,10);
    sockaddr_in a; if(!jobs || !address(argv[1],port,a)) return 2;
    Socket listener; listener.fd=rsocket(AF_INET,SOCK_STREAM,0);
    if(listener.fd<0 || rbind(listener.fd,reinterpret_cast<sockaddr*>(&a),sizeof(a))<0 || rlisten(listener.fd,8)<0) {
        std::perror("RDMA listen"); return 1;
    }
    for(unsigned job=0;job<jobs;++job) {
        Socket s; s.fd=raccept(listener.fd,nullptr,nullptr); if(s.fd<0) return 1;
        rfcntl(s.fd,F_SETFL,O_NONBLOCK);
        auto deadline=Clock::now()+std::chrono::seconds(60);
        uint32_t header[4]; if(!transfer(s.fd,header,sizeof(header),false,deadline)) continue;
        size_t rows=ntohl(header[1]), cols=ntohl(header[2]); unsigned gpu=ntohl(header[3]);
        if(ntohl(header[0])!=0x49434631 || !rows || rows>4096 || !cols || cols>32768 || gpu>1) continue;
        size_t words=(cols+63)/64; std::vector<uint64_t> data(rows*words);
        if(!transfer(s.fd,data.data(),data.size()*8,false,deadline)) continue;
        // Reject noncanonical padding; it is not an extra algebraic column.
        bool valid=true;
        if(cols%64) for(size_t r=0;r<rows;++r) if(data[r*words+words-1]>>(cols%64)) valid=false;
        if(!valid) continue;
        size_t rank=0; uint64_t ops=0;
        if(gpu) {
#ifdef IC_F2_SERVER_CUDA
            if(ic_f2_cuda(data.data(),rows,cols,&rank,&ops)) continue;
#else
            continue; // Never silently label remote CPU work as GPU work.
#endif
        } else rank=cpu(data,rows,cols,ops);
        uint32_t response[]={htonl(0x49434631),htonl(uint32_t(rank))};
        if(!transfer(s.fd,response,sizeof(response),true,deadline) || !transfer(s.fd,&ops,8,true,deadline)) continue;
        transfer(s.fd,data.data(),data.size()*8,true,deadline);
    }
}
#endif
