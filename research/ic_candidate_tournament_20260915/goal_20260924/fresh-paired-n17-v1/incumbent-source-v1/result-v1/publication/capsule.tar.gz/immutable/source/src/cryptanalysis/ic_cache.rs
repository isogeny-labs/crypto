//! Opt-in, thread-scoped artifact cache. Existing callers remain uncached.
//! Redis is an optional L2; bounded process memory is L1. Cache failures fall
//! back to computation. Treat the Redis namespace as trusted application data:
//! checksums detect corruption, not malicious replacement by an authorized writer.
use serde::{de::DeserializeOwned, Deserialize, Serialize};
use std::{
    cell::RefCell,
    collections::HashMap,
    rc::Rc,
    time::{Duration, Instant},
};

// Bump when algebra/serialization semantics change. The build fingerprint also
// invalidates entries whenever these implementing sources change.
const SCHEMA: &str = "ic-artifact-v1";
fn implementation() -> String {
    let mut h = blake3::Hasher::new();
    for s in [
        include_str!("ic_cache.rs"),
        include_str!("koblitz_groebner.rs"),
        include_str!("koblitz_index_calculus.rs"),
        include_str!("pq_groebner_f2.rs"),
        include_str!("../binary_ecc/f2m.rs"),
        include_str!("../binary_ecc/curve.rs"),
        include_str!("ic_f2_dispatch.rs"),
        include_str!("../../gpu/koblitz_f2/reduce.cu"),
        include_str!("../../gpu/koblitz_f2/rdma.cpp"),
        include_str!("../../Cargo.toml"),
    ] {
        h.update(s.as_bytes());
    }
    h.finalize().to_hex().to_string()
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct CacheStats {
    pub l1_hits: u64,
    pub l2_hits: u64,
    pub misses: u64,
    pub producers: u64,
    pub errors: u64,
    pub corrupt: u64,
    pub oversized: u64,
    pub read_bytes: u64,
    pub written_bytes: u64,
    pub lookup_ns: u128,
    pub publish_ns: u128,
}
/// Implementations must bound I/O time and values. Errors are intentionally
/// opaque so URLs/passwords from a client error never enter benchmark artifacts.
pub trait ArtifactStore {
    fn get(&mut self, key: &str, max_bytes: usize) -> Result<Option<Vec<u8>>, ()>;
    fn put(&mut self, key: &str, value: &[u8], ttl: Duration) -> Result<(), ()>;
}
struct Entry {
    value: Vec<u8>,
    expires: Instant,
    used: u64,
}
#[derive(Serialize, Deserialize)]
struct Envelope {
    key: String,
    digest: String,
    payload: Vec<u8>,
}

pub struct ArtifactCache {
    entries: HashMap<String, Entry>,
    bytes: usize,
    tick: u64,
    capacity: usize,
    max_entry: usize,
    ttl: Duration,
    implementation: String,
    store: Option<Box<dyn ArtifactStore>>,
    pub stats: CacheStats,
    report_index: Option<usize>,
}
impl ArtifactCache {
    pub fn new(
        capacity: usize,
        max_entry: usize,
        ttl: Duration,
        store: Option<Box<dyn ArtifactStore>>,
    ) -> Self {
        assert!(max_entry > 0 && !ttl.is_zero() && ttl <= Duration::from_secs(31_536_000));
        Self {
            entries: HashMap::new(),
            bytes: 0,
            tick: 0,
            capacity,
            max_entry,
            ttl,
            implementation: implementation(),
            store,
            stats: CacheStats::default(),
            report_index: None,
        }
    }
    fn key<K: Serialize>(&self, kind: &str, input: &K) -> Option<String> {
        let input = serde_json::to_vec(input).ok()?;
        let mut hash = blake3::Hasher::new();
        hash.update(self.implementation.as_bytes());
        hash.update(&input);
        Some(format!("{SCHEMA}:{kind}:{}", hash.finalize().to_hex()))
    }
    fn retain(&mut self, key: &str, value: Vec<u8>) {
        let size = key.len() + value.len();
        if size > self.capacity {
            return;
        }
        if let Some(old) = self.entries.remove(key) {
            self.bytes -= key.len() + old.value.len();
        }
        while self.bytes + size > self.capacity {
            let Some(victim) = self
                .entries
                .iter()
                .min_by_key(|(_, v)| v.used)
                .map(|(k, _)| k.clone())
            else {
                break;
            };
            let old = self.entries.remove(&victim).unwrap();
            self.bytes -= victim.len() + old.value.len();
        }
        self.tick += 1;
        self.bytes += size;
        self.entries.insert(
            key.into(),
            Entry {
                value,
                expires: Instant::now() + self.ttl,
                used: self.tick,
            },
        );
    }
    fn get<T: DeserializeOwned>(&mut self, key: &str) -> Option<T> {
        let start = Instant::now();
        let result = self.read(key);
        self.stats.lookup_ns += start.elapsed().as_nanos();
        result
    }
    fn read<T: DeserializeOwned>(&mut self, key: &str) -> Option<T> {
        self.tick += 1;
        let local = self.entries.get_mut(key).and_then(|e| {
            if e.expires <= Instant::now() {
                None
            } else {
                e.used = self.tick;
                Some(e.value.clone())
            }
        });
        let was_local = local.is_some();
        let data = match local {
            Some(data) => Some(data),
            None => match self.store.as_mut() {
                None => None,
                Some(store) => match store.get(key, self.max_entry) {
                    Ok(data) => data,
                    Err(()) => {
                        self.stats.errors += 1;
                        None
                    }
                },
            },
        };
        let value = data.as_ref().and_then(|data| {
            if data.len() > self.max_entry {
                return None;
            }
            let envelope: Envelope = serde_json::from_slice(data).ok()?;
            if envelope.key != key
                || envelope.digest != blake3::hash(&envelope.payload).to_hex().as_str()
            {
                return None;
            }
            serde_json::from_slice(&envelope.payload).ok()
        });
        if value.is_some() {
            let data = data.unwrap();
            self.stats.read_bytes += data.len() as u64;
            if was_local {
                self.stats.l1_hits += 1;
            } else {
                self.stats.l2_hits += 1;
                self.retain(key, data);
            }
        } else {
            self.stats.misses += 1;
            if data.is_some() {
                self.stats.corrupt += 1;
                if let Some(old) = self.entries.remove(key) {
                    self.bytes -= key.len() + old.value.len();
                }
            }
        }
        value
    }
    fn put<T: Serialize>(&mut self, key: &str, value: &T) {
        let start = Instant::now();
        let result = (|| {
            let payload = serde_json::to_vec(value).map_err(|_| ())?;
            let envelope = Envelope {
                key: key.into(),
                digest: blake3::hash(&payload).to_hex().to_string(),
                payload,
            };
            let data = serde_json::to_vec(&envelope).map_err(|_| ())?;
            if data.len() > self.max_entry {
                self.stats.oversized += 1;
                return Ok(());
            }
            self.stats.written_bytes += data.len() as u64;
            if let Some(store) = self.store.as_mut() {
                if store.put(key, &data, self.ttl).is_err() {
                    self.stats.errors += 1;
                }
            }
            self.retain(key, data);
            Ok::<(), ()>(())
        })();
        if result.is_err() {
            self.stats.errors += 1;
        }
        self.stats.publish_ns += start.elapsed().as_nanos();
    }
}
thread_local! { static ACTIVE: RefCell<Option<Rc<RefCell<ArtifactCache>>>> = const { RefCell::new(None) }; }
/// Scope a worker explicitly. Rayon/remote threads do not inherit this scope;
/// each worker needs its own cache/connection. Nested scopes and panics restore
/// the previous scope. No cache borrow is held while computing an artifact.
pub fn with_cache<T>(cache: Rc<RefCell<ArtifactCache>>, f: impl FnOnce() -> T) -> T {
    struct Restore(Option<Rc<RefCell<ArtifactCache>>>);
    impl Drop for Restore {
        fn drop(&mut self) {
            ACTIVE.with(|s| *s.borrow_mut() = self.0.take());
        }
    }
    let previous = ACTIVE.with(|s| s.borrow_mut().replace(cache));
    let _restore = Restore(previous);
    f()
}
/// Memoize a deterministic artifact. Do not use for RNG results, incomplete
/// search outcomes or side-effecting operations. Exact input order is preserved.
pub fn memo<K: Serialize, T: Serialize + DeserializeOwned>(
    kind: &str,
    input: &K,
    compute: impl FnOnce() -> T,
) -> T {
    memo_if(kind, input, compute, |_| true)
}
pub fn memo_if<K: Serialize, T: Serialize + DeserializeOwned>(
    kind: &str,
    input: &K,
    compute: impl FnOnce() -> T,
    admissible: impl Fn(&T) -> bool,
) -> T {
    let active = active_cache();
    let Some(cache) = active else {
        return compute();
    };
    let key = cache.borrow().key(kind, input);
    let Some(key) = key else {
        return compute();
    };
    let cached = cache.borrow_mut().get(&key);
    if let Some(value) = cached {
        if admissible(&value) {
            publish_stats(&cache);
            return value;
        }
    }
    cache.borrow_mut().stats.producers += 1;
    let value = compute();
    if admissible(&value) {
        cache.borrow_mut().put(&key, &value);
    }
    publish_stats(&cache);
    value
}

#[cfg(feature = "ic-redis")]
pub mod redis_store {
    use super::*;
    enum Connection {
        Single(redis::Connection),
        Cluster(redis::cluster::ClusterConnection),
    }
    pub struct RedisStore {
        connection: Connection,
    }
    impl RedisStore {
        /// URLs come from the caller's secret/config provider, never CLI output.
        /// Use rediss:// for ElastiCache, redis:// only for explicit local tests.
        pub fn connect(url: &str, cluster: bool, timeout: Duration) -> Result<Self, ()> {
            if timeout.is_zero()
                || url.contains('#')
                || !(url.starts_with("rediss://")
                    || url.starts_with("redis://127.0.0.1:")
                    || url.starts_with("redis://localhost:"))
            {
                return Err(());
            }
            let connection = if cluster {
                let client = redis::cluster::ClusterClient::builder(vec![url])
                    .connection_timeout(timeout)
                    .response_timeout(timeout)
                    .retries(1)
                    .build()
                    .map_err(|_| ())?;
                Connection::Cluster(client.get_connection().map_err(|_| ())?)
            } else {
                let client = redis::Client::open(url).map_err(|_| ())?;
                let c = client
                    .get_connection_with_timeout(timeout)
                    .map_err(|_| ())?;
                c.set_read_timeout(Some(timeout)).map_err(|_| ())?;
                c.set_write_timeout(Some(timeout)).map_err(|_| ())?;
                Connection::Single(c)
            };
            Ok(Self { connection })
        }
        fn query<T: redis::FromRedisValue>(&mut self, cmd: &redis::Cmd) -> Result<T, ()> {
            match &mut self.connection {
                Connection::Single(c) => cmd.query(c),
                Connection::Cluster(c) => cmd.query(c),
            }
            .map_err(|_| ())
        }
    }
    impl ArtifactStore for RedisStore {
        fn get(&mut self, key: &str, max_bytes: usize) -> Result<Option<Vec<u8>>, ()> {
            // GETRANGE bounds the response even when another writer replaces the
            // entry between requests; an extra byte detects oversized entries.
            let data: Vec<u8> =
                self.query(redis::cmd("GETRANGE").arg(key).arg(0).arg(max_bytes))?;
            if data.len() > max_bytes {
                return Err(());
            }
            Ok((!data.is_empty()).then_some(data))
        }
        fn put(&mut self, key: &str, value: &[u8], ttl: Duration) -> Result<(), ()> {
            self.query(
                redis::cmd("SET")
                    .arg(key)
                    .arg(value)
                    .arg("PX")
                    .arg(ttl.as_millis().max(1) as u64),
            )
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cryptanalysis::koblitz_groebner::{
        build_decomposition_system, solve_boolean_system, FieldStructure, SolveOptions,
        SolverEngine, SplitRule,
    };
    use crate::cryptanalysis::koblitz_index_calculus::{
        build_frobenius_factor_base, groebner_decompose, KoblitzCurve,
    };
    fn cache() -> Rc<RefCell<ArtifactCache>> {
        Rc::new(RefCell::new(ArtifactCache::new(
            1 << 20,
            1 << 18,
            Duration::from_secs(60),
            None,
        )))
    }
    #[test]
    fn exact_keys_nested_scope_and_corruption() {
        let c = cache();
        with_cache(c.clone(), || {
            assert_eq!(memo("x", &(7, "basis-a"), || 21), 21);
            assert_eq!(
                memo("x", &(7, "basis-a"), || -> i32 { panic!("must hit") }),
                21i32
            );
            assert_eq!(memo("x", &(9, "basis-a"), || 22), 22);
            assert_eq!(memo("x", &(7, "basis-b"), || 23), 23);
            let inner = cache();
            with_cache(inner, || assert_eq!(memo("x", &(7, "basis-a"), || 42), 42));
            assert_eq!(memo("x", &(7, "basis-a"), || 0), 21);
            for e in c.borrow_mut().entries.values_mut() {
                e.value[0] ^= 1;
            }
            assert_eq!(memo("x", &(7, "basis-a"), || 24), 24);
        });
        assert_eq!(c.borrow().stats.corrupt, 1);
        assert_eq!(memo("x", &(7, "basis-a"), || 99), 99);
    }
    #[test]
    fn failure_size_expiry_and_panic_are_recoverable() {
        struct Down;
        impl ArtifactStore for Down {
            fn get(&mut self, _: &str, _: usize) -> Result<Option<Vec<u8>>, ()> {
                Err(())
            }
            fn put(&mut self, _: &str, _: &[u8], _: Duration) -> Result<(), ()> {
                Err(())
            }
        }
        let c = Rc::new(RefCell::new(ArtifactCache::new(
            400,
            300,
            Duration::from_secs(1),
            Some(Box::new(Down)),
        )));
        with_cache(c.clone(), || {
            assert_eq!(memo("x", &1, || 7), 7);
            for e in c.borrow_mut().entries.values_mut() {
                e.expires = Instant::now();
            }
            assert_eq!(memo("x", &1, || 8), 8);
            assert_eq!(memo("large", &1, || vec![1u64; 1000]).len(), 1000);
            assert!(c.borrow().bytes <= 400);
        });
        assert!(c.borrow().stats.errors >= 4);
        assert_eq!(c.borrow().stats.oversized, 1);
        let _ = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            with_cache(c, || panic!("restore"))
        }));
        assert!(ACTIVE.with(|s| s.borrow().is_none()));
    }
    #[test]
    fn algebra_and_relations_replay_with_verification() {
        let kc = KoblitzCurve::new(1, 9).unwrap();
        let c = cache();
        let baseline = build_frobenius_factor_base(&kc, 0).unwrap();
        with_cache(c.clone(), || {
            let fb = build_frobenius_factor_base(&kc, 0).unwrap();
            let replay = build_frobenius_factor_base(&kc, 0).unwrap();
            assert_eq!(fb.points, baseline.points);
            assert_eq!(fb.points, replay.points);
            let st = FieldStructure::new(kc.n, &kc.curve.irreducible);
            let target = fb
                .points
                .iter()
                .skip(1)
                .map(|p| kc.add(&fb.points[0], p))
                .find(|p| *p != crate::binary_ecc::BinaryPoint::Infinity)
                .unwrap();
            let index = fb.index_map();
            let result = groebner_decompose(
                &kc,
                &fb,
                &index,
                &st,
                &target,
                2,
                SolverEngine::Buchberger,
                10000,
            );
            assert!(result.0.is_some());
            let before = c.borrow().stats.producers;
            let again = groebner_decompose(
                &kc,
                &fb,
                &index,
                &st,
                &target,
                2,
                SolverEngine::Buchberger,
                10000,
            );
            assert_eq!(result.0, again.0);
            assert_eq!(c.borrow().stats.producers, before);
            let x = match target {
                crate::binary_ecc::BinaryPoint::Affine { x, .. } => x,
                _ => panic!(),
            };
            let system =
                build_decomposition_system(&fb.subspace_basis, &x, &kc.curve.b, 2, &st).unwrap();
            let opts = SolveOptions {
                engine: SolverEngine::Buchberger,
                max_solutions: usize::MAX,
                node_budget: 10000,
                split_rule: SplitRule::LowestFree,
            };
            let (a, _) = solve_boolean_system(&system.equations, system.n_vars, &opts);
            let (b, _) = solve_boolean_system(&system.equations, system.n_vars, &opts);
            assert_eq!(a, b);
            assert!(!a.is_empty());
        });
    }
}

#[cfg(all(test, feature = "ic-redis"))]
mod redis_tests {
    use super::*;
    #[test]
    #[ignore = "requires an isolated Redis endpoint in IC_TEST_REDIS_URL"]
    fn redis_l2_replay_corruption_and_expiry() {
        let url = std::env::var("IC_TEST_REDIS_URL").expect("isolated Redis URL required");
        let backend =
            redis_store::RedisStore::connect(&url, false, Duration::from_secs(1)).unwrap();
        let c = Rc::new(RefCell::new(ArtifactCache::new(
            0,
            4096,
            Duration::from_millis(100),
            Some(Box::new(backend)),
        )));
        let nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        with_cache(c.clone(), || {
            assert_eq!(memo("redis-test", &nonce, || 41), 41);
            assert_eq!(memo("redis-test", &nonce, || 42), 41);
            assert_eq!(c.borrow().stats.l2_hits, 1);
            let key = c.borrow().key("redis-test", &nonce).unwrap();
            let mut direct = redis::Client::open(url).unwrap().get_connection().unwrap();
            let _: () = redis::cmd("SET")
                .arg(&key)
                .arg("corrupt")
                .arg("PX")
                .arg(100)
                .query(&mut direct)
                .unwrap();
            assert_eq!(memo("redis-test", &nonce, || 43), 43);
            assert_eq!(c.borrow().stats.corrupt, 1);
            std::thread::sleep(Duration::from_millis(160));
            assert_eq!(memo("redis-test", &nonce, || 44), 44);
            let _: () = redis::cmd("DEL").arg(&key).query(&mut direct).unwrap();
        });
    }
}

/// Process configuration creates an independent L1 and Redis connection lazily
/// on every executing worker, including Rayon threads. Capacity is per worker.
#[derive(Clone)]
pub struct WorkerCacheConfig {
    pub capacity: usize,
    pub max_entry: usize,
    pub ttl: Duration,
    pub redis_url: Option<String>,
    pub redis_cluster: bool,
}
static PROCESS_CONFIG: std::sync::OnceLock<WorkerCacheConfig> = std::sync::OnceLock::new();
static WORKER_STATS: std::sync::Mutex<Vec<CacheStats>> = std::sync::Mutex::new(Vec::new());
pub fn enable_process_cache(config: WorkerCacheConfig) -> Result<(), &'static str> {
    if config.max_entry == 0 || config.ttl.is_zero() || config.ttl > Duration::from_secs(31_536_000)
    {
        return Err("invalid cache limits");
    }
    #[cfg(not(feature = "ic-redis"))]
    if config.redis_url.is_some() {
        return Err("Redis caching requires the ic-redis Cargo feature");
    }
    if let Some(url) = &config.redis_url {
        if url.contains('#')
            || !(url.starts_with("rediss://")
                || url.starts_with("redis://127.0.0.1:")
                || url.starts_with("redis://localhost:"))
        {
            return Err("use a TLS Redis URL (or loopback for local tests)");
        }
    }
    PROCESS_CONFIG
        .set(config)
        .map_err(|_| "process cache already configured")
}
pub fn process_cache_stats() -> Vec<CacheStats> {
    WORKER_STATS.lock().unwrap().clone()
}
fn active_cache() -> Option<Rc<RefCell<ArtifactCache>>> {
    ACTIVE.with(|s| {
        if let Some(cache) = s.borrow().clone() {
            return Some(cache);
        }
        let config = PROCESS_CONFIG.get()?;
        #[allow(unused_mut)]
        let mut backend: Option<Box<dyn ArtifactStore>> = None;
        #[allow(unused_mut)]
        let mut errors = 0;
        #[cfg(feature = "ic-redis")]
        if let Some(url) = &config.redis_url {
            match redis_store::RedisStore::connect(
                url,
                config.redis_cluster,
                Duration::from_secs(2),
            ) {
                Ok(store) => backend = Some(Box::new(store)),
                Err(()) => errors += 1,
            }
        }
        let mut cache = ArtifactCache::new(config.capacity, config.max_entry, config.ttl, backend);
        let mut registry = WORKER_STATS.lock().unwrap();
        cache.report_index = Some(registry.len());
        cache.stats.errors = errors;
        registry.push(cache.stats.clone());
        let cache = Rc::new(RefCell::new(cache));
        *s.borrow_mut() = Some(cache.clone());
        Some(cache)
    })
}
fn publish_stats(cache: &Rc<RefCell<ArtifactCache>>) {
    let cache = cache.borrow();
    if let Some(index) = cache.report_index {
        WORKER_STATS.lock().unwrap()[index] = cache.stats.clone();
    }
}
