//! **Complete Koblitz index calculus for one small curve, in single words.**
//!
//! The tournament worker's cold single-target jobs on odd prime degrees
//! `n ≤ 31` spend most of their instructions outside the arithmetic the
//! algorithm needs: general `BigUint` point operations while sampling the
//! base, Fermat inversions, thread pools, and hash maps keyed by big
//! integers.  This module runs the same algorithm — the same
//! [`FactorBaseSpec::SubgroupOrbits`] base, a folded pair-sum table,
//! three-summand decomposition of `[a]G` probes, a full-rank scalar-field
//! solve certified by `[ℓ]G = C`, and a `[a]G + [b]Q` descent — with every
//! operation on `u64` words and no allocation in a hot loop.
//!
//! What is preserved exactly, and checked by tests against the general
//! implementation:
//!
//! - the factor-base **point set** of `SubgroupOrbits { seed, points }` on
//!   the same curve (the same random abscissa draws, the same lift test,
//!   the same cofactor projection and orbit closure);
//! - the meaning of a relation: exactly `m = 3` base-point indices with
//!   `Σ P_i = [a]G`, repetition allowed, no direct relations;
//! - one column per signed Frobenius orbit after cofactor projection, each
//!   logarithm verified in the group before it is reported;
//! - every returned scalar verified as `[d]G = Q` before it is returned.
//!
//! What differs is only how the work is done: probes are walked
//! (`R_{t+1} = R_t + S`) rather than drawn with a scalar multiplication
//! each; the pair table stores one witness per Frobenius orbit of a sum
//! under a normal-basis rotation key and builds only the rows a cost
//! model says pay for themselves; decomposition stops at the first witness
//! it meets; scalar multiplications run in López–Dahab projective
//! coordinates or off a doubling table of `G`, with the column
//! certifications batched behind one inversion per bit; and the module
//! carries its own field, sampler and tables so that a cold process
//! touches little code and data before its first relation.  None of that
//! changes what is claimed: this is an implementation of the same bounded
//! algorithm, not a new one.

use num_bigint::BigUint;
use crate::cryptanalysis::ic_phase::{mark, Phase};

/// Cargo tracks this environment dependency and rebuilds the library when the
/// complete frozen source inventory changes, even across shared cache restores.
pub fn source_snapshot() -> Option<&'static str> {
    option_env!("IC_SOURCE_MANIFEST_SHA256")
}

use num_traits::ToPrimitive;

use crate::binary_ecc::BinaryPoint;
use crate::cryptanalysis::koblitz_factor_base_search::FactorBaseSpec;
use crate::cryptanalysis::koblitz_fast::FastPoint;
use crate::cryptanalysis::koblitz_index_calculus::{CollectedRelation, KoblitzCurve};

/// Largest degree handled: keys and packed identities must fit a word.
pub const MAX_DEGREE: u32 = 61;

/// Probes beyond the column count that the table-size rule budgets for:
/// a few dependent rows and the descent.
pub const TABLE_PROBES: f64 = 3.0;

fn is_prime(n: u32) -> bool {
    n >= 2 && (2..n).take_while(|d| d * d <= n).all(|d| n % d != 0)
}

/// Whether the fast pipeline applies to this job.  It handles prime
/// degrees up to [`MAX_DEGREE`], the `SubgroupOrbits` base recipe and
/// three summands; everything else keeps the general implementation.
pub fn supports(kc: &KoblitzCurve, spec: &FactorBaseSpec, summands: usize) -> bool {
    kc.k == 1
        && kc.n <= MAX_DEGREE
        && is_prime(kc.n)
        && summands == 3
        && matches!(spec, FactorBaseSpec::SubgroupOrbits { .. })
        && kc.subgroup_order.to_u64().is_some_and(|r| r > 2 && r < 1 << 62)
        && kc.cofactor.to_u64().is_some()
}

// ── Field and curve arithmetic ──────────────────────────────────────

/// `F_{2^n}` in one word: a carry-less multiply, byte-table reduction and
/// a Euclidean inverse.  Its own small reduction tables rather than the
/// library's `Gf2`; the carry-less multiplier is looked up in the standard
/// feature cache, which the worker's target hashing has already filled.
struct Field {
    n: u32,
    irr: u64,
    mask: u64,
    red: Vec<u64>,
    positions: usize,
    clmul: bool,
}

#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "pclmulqdq")]
unsafe fn clmul_pclmul(a: u64, b: u64) -> u128 {
    use std::arch::x86_64::*;
    let x = _mm_set_epi64x(0, a as i64);
    let y = _mm_set_epi64x(0, b as i64);
    let z = _mm_clmulepi64_si128::<0x00>(x, y);
    let lo = _mm_cvtsi128_si64(z) as u64;
    let hi = _mm_cvtsi128_si64(_mm_srli_si128::<8>(z)) as u64;
    ((hi as u128) << 64) | (lo as u128)
}

fn has_pclmul() -> bool {
    // The crate's one cached CPUID probe (`binary_ecc::f2m::pclmul_available`).
    crate::binary_ecc::f2m::pclmul_available()
}

impl Field {
    fn new(n: u32, irr: u64) -> Self {
        let positions = (((n as usize - 1) + 7) / 8).max(1);
        let mut pow = vec![0u64; positions * 8];
        let mut cur = irr ^ (1u64 << n);
        for slot in pow.iter_mut() {
            *slot = cur;
            cur <<= 1;
            if (cur >> n) & 1 != 0 {
                cur ^= irr;
            }
        }
        let mut red = vec![0u64; positions * 256];
        for j in 0..positions {
            for v in 1usize..256 {
                red[j * 256 + v] = red[j * 256 + (v & (v - 1))] ^ pow[j * 8 + v.trailing_zeros() as usize];
            }
        }
        Self { n, irr, mask: (1u64 << n) - 1, red, positions, clmul: has_pclmul() }
    }

    #[inline(always)]
    fn reduce(&self, w: u128) -> u64 {
        let mut acc = (w as u64) & self.mask;
        let mut h = (w >> self.n) as u64;
        for j in 0..self.positions {
            acc ^= self.red[j * 256 + (h & 0xff) as usize];
            h >>= 8;
        }
        acc
    }

    #[inline(always)]
    fn clmul(&self, a: u64, b: u64) -> u128 {
        #[cfg(target_arch = "x86_64")]
        if self.clmul {
            // SAFETY: `clmul` records the runtime feature detection.
            return unsafe { clmul_pclmul(a, b) };
        }
        let mut w = 0u128;
        let mut aa = a as u128;
        let mut bb = b;
        while bb != 0 {
            if bb & 1 != 0 {
                w ^= aa;
            }
            aa <<= 1;
            bb >>= 1;
        }
        w
    }

    #[inline]
    fn mul(&self, a: u64, b: u64) -> u64 {
        self.reduce(self.clmul(a, b))
    }

    #[inline]
    fn sqr(&self, a: u64) -> u64 {
        self.reduce(self.clmul(a, a))
    }

    fn sqr_k(&self, mut a: u64, k: u32) -> u64 {
        for _ in 0..k {
            a = self.sqr(a);
        }
        a
    }
}

/// The curve `y² + xy = x³ + ax² + b` over a [`Field`].
struct Arith {
    field: Field,
    n: u32,
    a: u64,
    b: u64,
}

fn word(e: &crate::binary_ecc::F2mElement) -> u64 {
    e.raw_bits().first().copied().unwrap_or(0)
}

impl Arith {
    fn new(kc: &KoblitzCurve) -> Option<Self> {
        let n = kc.n;
        if n > MAX_DEGREE || kc.curve.irreducible.degree != n {
            return None;
        }
        let irr = kc.curve.irreducible.low_terms.iter().fold(1u64 << n, |acc, &t| acc | (1u64 << t));
        let field = Field::new(n, irr);
        let a = word(&kc.curve.a) & field.mask;
        let b = word(&kc.curve.b) & field.mask;
        Some(Self { field, n, a, b })
    }

    fn lift(&self, p: &BinaryPoint) -> FastPoint {
        match p {
            BinaryPoint::Infinity => FastPoint::INFINITY,
            BinaryPoint::Affine { x, y } => FastPoint::affine(word(x) & self.field.mask, word(y) & self.field.mask),
        }
    }

    fn lower(&self, p: FastPoint) -> BinaryPoint {
        if p.infinity {
            BinaryPoint::Infinity
        } else {
            BinaryPoint::Affine {
                x: crate::binary_ecc::F2mElement::from_biguint(&BigUint::from(p.x), self.n),
                y: crate::binary_ecc::F2mElement::from_biguint(&BigUint::from(p.y), self.n),
            }
        }
    }

    #[inline]
    fn mul(&self, a: u64, b: u64) -> u64 {
        self.field.mul(a, b)
    }

    /// Squaring as a carry-less self-product: one multiplier latency
    /// instead of a dependent bit-spreading chain.
    #[inline]
    fn sqr(&self, a: u64) -> u64 {
        self.field.sqr(a)
    }

    /// `a^{-1}` by the extended Euclidean algorithm on `F_2[z]`: about
    /// `2n` shift-and-xor steps, against the `n` squarings and `n`
    /// multiplications of the Fermat inverse.
    fn inv(&self, a: u64) -> u64 {
        debug_assert!(a != 0);
        let (mut u, mut v) = (a, self.field.irr);
        let (mut g1, mut g2) = (1u64, 0u64);
        while u != 1 {
            let mut j = (63 - u.leading_zeros()) as i32 - (63 - v.leading_zeros()) as i32;
            if j < 0 {
                std::mem::swap(&mut u, &mut v);
                std::mem::swap(&mut g1, &mut g2);
                j = -j;
            }
            u ^= v << j;
            g1 ^= g2 << j;
        }
        g1
    }

    /// Montgomery's trick: one inversion for the whole slice.  Zeros stay
    /// zero.
    fn batch_inv(&self, xs: &mut [u64], scratch: &mut Vec<u64>) {
        scratch.clear();
        let mut acc = 1u64;
        for &x in xs.iter() {
            scratch.push(acc);
            if x != 0 {
                acc = self.mul(acc, x);
            }
        }
        let mut inv_acc = self.inv(acc);
        for i in (0..xs.len()).rev() {
            if xs[i] != 0 {
                let xi = xs[i];
                xs[i] = self.mul(inv_acc, scratch[i]);
                inv_acc = self.mul(inv_acc, xi);
            }
        }
    }

    #[inline]
    fn neg(&self, p: FastPoint) -> FastPoint {
        if p.infinity {
            p
        } else {
            FastPoint::affine(p.x, p.x ^ p.y)
        }
    }

    fn double(&self, p: FastPoint) -> FastPoint {
        if p.infinity || p.x == 0 {
            return FastPoint::INFINITY;
        }
        let lambda = p.x ^ self.mul(p.y, self.inv(p.x));
        let x3 = self.sqr(lambda) ^ lambda ^ self.a;
        let y3 = self.sqr(p.x) ^ self.mul(lambda ^ 1, x3);
        FastPoint::affine(x3, y3)
    }

    /// The abscissa of `add_with_lambda`, without its ordinate: one field
    /// multiplication less, and the scan needs nothing else to name the
    /// orbit of a rest.
    #[inline]
    fn add_x_with_lambda(&self, p: FastPoint, q: FastPoint, lambda: u64) -> u64 {
        self.sqr(lambda) ^ lambda ^ p.x ^ q.x ^ self.a
    }

    #[inline]
    fn add_with_lambda(&self, p: FastPoint, q: FastPoint, lambda: u64) -> FastPoint {
        let x3 = self.sqr(lambda) ^ lambda ^ p.x ^ q.x ^ self.a;
        let y3 = self.mul(lambda, p.x ^ x3) ^ x3 ^ p.y;
        FastPoint::affine(x3, y3)
    }

    fn add(&self, p: FastPoint, q: FastPoint) -> FastPoint {
        if p.infinity {
            return q;
        }
        if q.infinity {
            return p;
        }
        if p.x == q.x {
            if p.y ^ q.y == p.x {
                return FastPoint::INFINITY;
            }
            return self.double(p);
        }
        let lambda = self.mul(p.y ^ q.y, self.inv(p.x ^ q.x));
        self.add_with_lambda(p, q, lambda)
    }

    /// `[k]P` in López–Dahab projective coordinates (`x = X/Z`,
    /// `y = Y/Z²`): no field inversion until the final conversion.
    fn mul_point(&self, p: FastPoint, k: u64) -> FastPoint {
        if k == 0 || p.infinity {
            return FastPoint::INFINITY;
        }
        let mut acc = Ld::INFINITY;
        for i in (0..64 - k.leading_zeros()).rev() {
            acc = self.ld_double(acc);
            if (k >> i) & 1 == 1 {
                acc = self.ld_add_affine(acc, p);
            }
        }
        self.ld_to_affine(acc)
    }

    /// Doubling in López–Dahab coordinates (Hankerson–Menezes–Vanstone,
    /// Algorithm 3.24): `Z3 = X1²Z1²`, `X3 = X1⁴ + bZ1⁴`,
    /// `Y3 = bZ1⁴Z3 + X3(aZ3 + Y1² + bZ1⁴)`.
    #[inline]
    fn ld_double(&self, p: Ld) -> Ld {
        if p.z == 0 {
            return p;
        }
        let z2 = self.sqr(p.z);
        let x2 = self.sqr(p.x);
        let z3 = self.mul(x2, z2);
        if z3 == 0 {
            return Ld::INFINITY;
        }
        let bz4 = self.mul(self.b, self.sqr(z2));
        let x3 = self.sqr(x2) ^ bz4;
        let y3 = self.mul(bz4, z3) ^ self.mul(x3, self.mul(self.a, z3) ^ self.sqr(p.y) ^ bz4);
        Ld { x: x3, y: y3, z: z3 }
    }

    /// Mixed addition `P + Q` with `Q` affine (Algorithm 3.25).  The
    /// degenerate cases (`Q = ±P`) go through the affine formulas.
    #[inline]
    fn ld_add_affine(&self, p: Ld, q: FastPoint) -> Ld {
        if q.infinity {
            return p;
        }
        if p.z == 0 {
            return Ld { x: q.x, y: q.y, z: 1 };
        }
        let z1sq = self.sqr(p.z);
        let a = self.mul(q.y, z1sq) ^ p.y;
        let b = self.mul(q.x, p.z) ^ p.x;
        if b == 0 {
            let affine = self.ld_to_affine(p);
            let sum = self.add(affine, q);
            return if sum.infinity { Ld::INFINITY } else { Ld { x: sum.x, y: sum.y, z: 1 } };
        }
        let c = self.mul(p.z, b);
        let d = self.mul(self.sqr(b), c ^ self.mul(self.a, z1sq));
        let z3 = self.sqr(c);
        let e = self.mul(a, c);
        let x3 = self.sqr(a) ^ d ^ e;
        let f = x3 ^ self.mul(q.x, z3);
        let g = self.mul(q.x ^ q.y, self.sqr(z3));
        let y3 = self.mul(e ^ z3, f) ^ g;
        Ld { x: x3, y: y3, z: z3 }
    }

    #[inline]
    fn ld_to_affine(&self, p: Ld) -> FastPoint {
        if p.z == 0 {
            return FastPoint::INFINITY;
        }
        let zi = self.inv(p.z);
        FastPoint::affine(self.mul(p.x, zi), self.mul(p.y, self.sqr(zi)))
    }

    /// `[2^i]P` for `i < bits`, affine, with one inversion for the whole
    /// table (projective doublings, then a batched normalisation).
    fn doubling_table(&self, p: FastPoint, bits: u32) -> Vec<FastPoint> {
        let mut projective = Vec::with_capacity(bits as usize);
        let mut current = Ld { x: p.x, y: p.y, z: 1 };
        for _ in 0..bits {
            projective.push(current);
            current = self.ld_double(current);
        }
        let mut zs: Vec<u64> = projective.iter().map(|q| q.z).collect();
        let mut scratch = Vec::with_capacity(zs.len());
        self.batch_inv(&mut zs, &mut scratch);
        projective
            .iter()
            .zip(&zs)
            .map(|(q, &zi)| {
                if q.z == 0 {
                    FastPoint::INFINITY
                } else {
                    FastPoint::affine(self.mul(q.x, zi), self.mul(q.y, self.sqr(zi)))
                }
            })
            .collect()
    }

    /// `[k]G` from a doubling table of `G`: affine additions of the set
    /// bits' entries.
    fn fixed_base_mul(&self, table: &[FastPoint], k: u64) -> FastPoint {
        debug_assert!(table.len() >= 64 || k < 1u64 << table.len(), "scalar exceeds the table");
        let mut acc = FastPoint::INFINITY;
        for (i, &entry) in table.iter().enumerate() {
            if (k >> i) & 1 == 1 {
                acc = self.add(acc, entry);
            }
        }
        acc
    }

    /// `[k_o]G` for every `o`, all from the same doubling table, with the
    /// additions of one bit position sharing one field inversion across
    /// the columns.  Equal to [`Self::fixed_base_mul`] entry by entry.
    fn fixed_base_mul_many(&self, table: &[FastPoint], ks: &[u64]) -> Vec<FastPoint> {
        debug_assert!(table.len() >= 64 || ks.iter().all(|&k| k < 1u64 << table.len()), "scalar exceeds the table");
        let mut acc = vec![FastPoint::INFINITY; ks.len()];
        let mut dens = Vec::with_capacity(ks.len());
        let mut scratch = Vec::with_capacity(ks.len());
        let mut active: Vec<usize> = Vec::with_capacity(ks.len());
        for (i, &entry) in table.iter().enumerate() {
            active.clear();
            dens.clear();
            for (o, &k) in ks.iter().enumerate() {
                if (k >> i) & 1 == 0 {
                    continue;
                }
                let s = acc[o];
                if s.infinity || entry.infinity || s.x == entry.x {
                    acc[o] = self.add(s, entry);
                } else {
                    active.push(o);
                    dens.push(s.x ^ entry.x);
                }
            }
            self.batch_inv(&mut dens, &mut scratch);
            for (&o, &inv) in active.iter().zip(&dens) {
                let s = acc[o];
                let lambda = self.mul(s.y ^ entry.y, inv);
                acc[o] = self.add_with_lambda(s, entry, lambda);
            }
        }
        acc
    }

    /// `[k]P` by affine double-and-add; the reference the projective
    /// path is tested against.
    #[cfg(test)]
    fn mul_point_affine(&self, p: FastPoint, k: u64) -> FastPoint {
        if k == 0 || p.infinity {
            return FastPoint::INFINITY;
        }
        let mut result = FastPoint::INFINITY;
        for i in (0..64 - k.leading_zeros()).rev() {
            result = self.double(result);
            if (k >> i) & 1 == 1 {
                result = self.add(result, p);
            }
        }
        result
    }

    /// `(x^{2^k}, y^{2^k})`.
    fn frobenius_k(&self, p: FastPoint, k: u32) -> FastPoint {
        if p.infinity {
            return p;
        }
        FastPoint::affine(self.field.sqr_k(p.x, k), self.field.sqr_k(p.y, k))
    }

    /// The first point the general `factor_base_points_with_x` returns
    /// for `x ≠ 0`, `(x, x·u)` with `u` the half-trace of
    /// `x + a + b/x²`, or `None` when the trace is one.
    fn lift_x(&self, x: u64) -> Option<FastPoint> {
        if x == 0 {
            return None;
        }
        let n = self.n;
        let inverse = self.inv(x);
        let rhs = x ^ self.a ^ self.mul(self.b, self.sqr(inverse));
        let mut acc = rhs;
        let mut u = rhs;
        for _ in 0..(n - 1) / 2 {
            acc = self.sqr(self.sqr(acc));
            u ^= acc;
        }
        if self.sqr(u) ^ u != rhs {
            return None;
        }
        Some(FastPoint::affine(x, self.mul(x, u)))
    }
}

/// A López–Dahab point; `z == 0` is the point at infinity.
#[derive(Clone, Copy, Debug)]
struct Ld {
    x: u64,
    y: u64,
    z: u64,
}

impl Ld {
    const INFINITY: Self = Self { x: 1, y: 0, z: 0 };
}

// ── The base sampler's generator ────────────────────────────────────

/// `rand 0.8`'s `StdRng` (ChaCha12) and its `seed_from_u64` and
/// `gen_range` for `u64`, reproduced word for word so the base recipe
/// draws the same abscissae from a few dozen lines of scalar code instead
/// of the generic block-generator machinery.  A test checks the stream
/// against `StdRng` itself, draw for draw.
struct SeededChaCha12 {
    key: [u32; 8],
    counter: u64,
    buffer: [u32; 64],
    index: usize,
}

impl SeededChaCha12 {
    fn seed_from_u64(mut state: u64) -> Self {
        // rand_core's PCG32 seed expansion.
        const MUL: u64 = 6364136223846793005;
        const INC: u64 = 11634580027462260723;
        let mut key = [0u32; 8];
        for k in key.iter_mut() {
            state = state.wrapping_mul(MUL).wrapping_add(INC);
            let xorshifted = (((state >> 18) ^ state) >> 27) as u32;
            let rot = (state >> 59) as u32;
            *k = xorshifted.rotate_right(rot);
        }
        Self { key, counter: 0, buffer: [0; 64], index: 64 }
    }

    fn refill(&mut self) {
        for block in 0..4 {
            let mut s = [
                0x6170_7865, 0x3320_646e, 0x7962_2d32, 0x6b20_6574,
                self.key[0], self.key[1], self.key[2], self.key[3],
                self.key[4], self.key[5], self.key[6], self.key[7],
                self.counter as u32, (self.counter >> 32) as u32, 0, 0,
            ];
            let input = s;
            #[inline(always)]
            fn qr(s: &mut [u32; 16], a: usize, b: usize, c: usize, d: usize) {
                s[a] = s[a].wrapping_add(s[b]); s[d] = (s[d] ^ s[a]).rotate_left(16);
                s[c] = s[c].wrapping_add(s[d]); s[b] = (s[b] ^ s[c]).rotate_left(12);
                s[a] = s[a].wrapping_add(s[b]); s[d] = (s[d] ^ s[a]).rotate_left(8);
                s[c] = s[c].wrapping_add(s[d]); s[b] = (s[b] ^ s[c]).rotate_left(7);
            }
            for _ in 0..6 {
                qr(&mut s, 0, 4, 8, 12); qr(&mut s, 1, 5, 9, 13); qr(&mut s, 2, 6, 10, 14); qr(&mut s, 3, 7, 11, 15);
                qr(&mut s, 0, 5, 10, 15); qr(&mut s, 1, 6, 11, 12); qr(&mut s, 2, 7, 8, 13); qr(&mut s, 3, 4, 9, 14);
            }
            for (i, w) in s.iter().enumerate() {
                self.buffer[block * 16 + i] = w.wrapping_add(input[i]);
            }
            self.counter = self.counter.wrapping_add(1);
        }
        self.index = 0;
    }

    /// rand_core's `BlockRng::next_u64` over a 64-word buffer.
    fn next_u64(&mut self) -> u64 {
        let len = 64;
        if self.index < len - 1 {
            let lo = self.buffer[self.index];
            let hi = self.buffer[self.index + 1];
            self.index += 2;
            (u64::from(hi) << 32) | u64::from(lo)
        } else if self.index >= len {
            self.refill();
            self.index = 2;
            (u64::from(self.buffer[1]) << 32) | u64::from(self.buffer[0])
        } else {
            let lo = self.buffer[len - 1];
            self.refill();
            self.index = 1;
            (u64::from(self.buffer[0]) << 32) | u64::from(lo)
        }
    }

    /// `rng.gen_range(low..high)` for `u64` in rand 0.8: widening multiply
    /// with rejection below the zone.
    fn gen_range_u64(&mut self, low: u64, high: u64) -> u64 {
        let range = high - low; // inclusive upper bound high - 1
        if range == 0 {
            return self.next_u64();
        }
        let zone = (range << range.leading_zeros()).wrapping_sub(1);
        loop {
            let v = self.next_u64();
            let wide = (v as u128) * (range as u128);
            let (hi, lo) = ((wide >> 64) as u64, wide as u64);
            if lo <= zone {
                return low.wrapping_add(hi);
            }
        }
    }
}

// ── Normal-basis orbit names ────────────────────────────────────────

/// Frobenius as a rotation: in a normal basis `{γ, γ², γ⁴, …}` squaring
/// rotates the coordinate word by one bit, so the least rotation names
/// the orbit of an abscissa and the rotation count locates a point in it.
struct NormalBasis {
    n: u32,
    mask: u64,
    tables: Vec<[u64; 16]>,
}

fn invert_f2(columns: &[u64], n: u32) -> Option<Vec<u64>> {
    let mut a: Vec<u64> = (0..n)
        .map(|i| (0..n).fold(0u64, |acc, k| acc | (((columns[k as usize] >> i) & 1) << k)))
        .collect();
    let mut inv: Vec<u64> = (0..n).map(|i| 1u64 << i).collect();
    for c in 0..n as usize {
        let pivot = (c..n as usize).find(|&r| (a[r] >> c) & 1 == 1)?;
        a.swap(c, pivot);
        inv.swap(c, pivot);
        for r in 0..n as usize {
            if r != c && (a[r] >> c) & 1 == 1 {
                a[r] ^= a[c];
                inv[r] ^= inv[c];
            }
        }
    }
    Some(inv)
}

impl NormalBasis {
    fn new(arith: &Arith) -> Option<Self> {
        let n = arith.n;
        let mask = (1u64 << n) - 1;
        let mut inverse = None;
        let mut candidate = 2u64;
        for _ in 0..4096 {
            candidate = candidate.wrapping_mul(0x9e37_79b9_7f4a_7c15) ^ (candidate >> 29);
            let gamma = candidate & mask;
            if gamma == 0 {
                continue;
            }
            let mut column = gamma;
            let columns: Vec<u64> = (0..n)
                .map(|_| {
                    let c = column;
                    column = arith.sqr(column);
                    c
                })
                .collect();
            if let Some(inv) = invert_f2(&columns, n) {
                inverse = Some(inv);
                break;
            }
        }
        let inverse = inverse?;
        let by_bit: Vec<u64> = (0..n)
            .map(|j| (0..n).fold(0u64, |acc, i| acc | (((inverse[i as usize] >> j) & 1) << i)))
            .collect();
        // Nibble tables: `n/4` lookups per key and a kilobyte to touch.
        let nibbles = ((n + 3) / 4) as usize;
        let tables = (0..nibbles)
            .map(|ni| {
                let mut table = [0u64; 16];
                for (b, slot) in table.iter_mut().enumerate() {
                    let mut acc = 0u64;
                    for t in 0..4 {
                        let j = ni * 4 + t;
                        if (b >> t) & 1 == 1 && j < n as usize {
                            acc ^= by_bit[j];
                        }
                    }
                    *slot = acc;
                }
                table
            })
            .collect();
        Some(Self { n, mask, tables })
    }

    #[inline]
    fn coords(&self, x: u64) -> u64 {
        let mut acc = 0u64;
        for (i, table) in self.tables.iter().enumerate() {
            acc ^= table[((x >> (4 * i)) & 0xf) as usize];
        }
        acc
    }

    /// `(least rotation, rotations applied)`: the orbit name of `x` and
    /// the `k` with `canon = coords(x^{2^k})`.
    ///
    /// The least rotation is the one with the most leading zeros, so it
    /// begins with a longest circular run of zeros at the top of the
    /// word.  The runs are found by doubling (`run(2L) = run(L) ∧
    /// rotr(run(L), L)`), their maximal length by a binary search over
    /// those masks, and only the rotations that put such a run at the
    /// top are compared — usually one or two, where the loop it replaces
    /// tried all `n − 1`.  Ties (periodic words) resolve to the least
    /// `k`, as the loop did; the loop is kept as the test reference.
    #[inline]
    fn canon(&self, x: u64) -> (u64, u32) {
        let c = self.coords(x);
        let n = self.n;
        let mask = self.mask;
        let z = !c & mask;
        if z == 0 {
            return (c, 0);
        }
        let rotr = |v: u64, k: u32| if k == 0 { v } else { ((v >> k) | (v << (n - k))) & mask };
        let rotl = |v: u64, k: u32| if k == 0 { v } else { ((v << k) | (v >> (n - k))) & mask };
        // `runs[i]`: positions that start (upward) a zero run of length ≥ 2^i.
        let mut runs = [0u64; 6];
        runs[0] = z;
        let mut i = 0usize;
        let mut len = 1u32;
        while len * 2 <= n {
            let next = runs[i] & rotr(runs[i], len);
            if next == 0 {
                break;
            }
            i += 1;
            runs[i] = next;
            len *= 2;
        }
        let mut best_mask = runs[i];
        let mut best_len = len;
        let mut j = i;
        let mut step = len / 2;
        while step > 0 {
            j -= 1;
            let cand = best_mask & rotr(runs[j], best_len);
            if cand != 0 {
                best_mask = cand;
                best_len += step;
            }
            step /= 2;
        }
        // A run at positions `p .. p + len − 1` sits at the top of `rotl(c, k)`
        // when `p + len − 1 ≡ n − 1 − k`, i.e. `k ≡ n − p − len (mod n)`.
        let mut best = u64::MAX;
        let mut best_k = 0u32;
        let mut m = best_mask;
        while m != 0 {
            let p = m.trailing_zeros();
            m &= m - 1;
            let k = (2 * n - p - best_len) % n;
            let v = rotl(c, k);
            if v < best || (v == best && k < best_k) {
                best = v;
                best_k = k;
            }
        }
        (best, best_k)
    }

    /// The rotation loop `canon` replaced, kept as the reference.
    #[cfg(test)]
    fn canon_reference(&self, x: u64) -> (u64, u32) {
        let c = self.coords(x);
        let n = self.n;
        let mut best = c;
        let mut best_k = 0u32;
        let mut v = c;
        for k in 1..n {
            v = ((v << 1) | (v >> (n - 1))) & self.mask;
            if v < best {
                best = v;
                best_k = k;
            }
        }
        (best, best_k)
    }
}

// ── The folded pair-sum table ───────────────────────────────────────

/// A stored sum `C_orbit + P_other` and the rotation that names its
/// orbit.
///
/// The coordinates were `u32` while `MAX_DEGREE` was 31, which made the
/// entry twelve bytes and the module's degree ceiling a property of this
/// struct rather than of its arithmetic: the field has always been one
/// `u64`, so the packing was the only thing keeping the collector below
/// degree 32.  They are `u64` now, which costs eight bytes an entry and
/// buys every degree the field can hold.
#[derive(Clone, Copy)]
struct PairEntry {
    sum_x: u64,
    sum_y: u64,
    other: u16,
    orbit: u8,
    rotation: u8,
}

impl PairEntry {
    #[inline]
    fn sum(&self) -> FastPoint {
        FastPoint::affine(self.sum_x, self.sum_y)
    }
}

/// Open addressing on the orbit name; one witness per orbit of a sum.
/// Slots hold a dense index so only the small index array is zeroed.
struct PairTable {
    keys: Vec<u64>,
    slots: Vec<u32>,
    entries: Vec<PairEntry>,
    shift: u32,
}

impl PairTable {
    fn with_capacity(count: usize) -> Self {
        let bits = (usize::BITS - (2 * count.max(1)).leading_zeros()).max(4);
        let slots = 1usize << bits;
        Self {
            keys: Vec::with_capacity(count),
            slots: vec![0; slots],
            entries: Vec::with_capacity(count),
            shift: 64 - bits,
        }
    }

    #[inline]
    fn slot(&self, key: u64) -> usize {
        (key.wrapping_mul(0x9e37_79b9_7f4a_7c15) >> self.shift) as usize
    }

    fn insert(&mut self, key: u64, entry: PairEntry) {
        let mask = self.slots.len() - 1;
        let mut i = self.slot(key);
        loop {
            let s = self.slots[i];
            if s == 0 {
                self.keys.push(key);
                self.entries.push(entry);
                self.slots[i] = self.entries.len() as u32;
                return;
            }
            if self.keys[s as usize - 1] == key {
                return;
            }
            i = (i + 1) & mask;
        }
    }

    #[inline]
    fn get(&self, key: u64) -> Option<&PairEntry> {
        let mask = self.slots.len() - 1;
        let mut i = self.slot(key);
        loop {
            let s = self.slots[i];
            if s == 0 {
                return None;
            }
            if self.keys[s as usize - 1] == key {
                return Some(&self.entries[s as usize - 1]);
            }
            i = (i + 1) & mask;
        }
    }

    /// Stored sum orbits.
    fn len(&self) -> usize {
        self.entries.len()
    }
}

// ── Scalar-field rows ───────────────────────────────────────────────

#[inline]
fn mulmod(a: u64, b: u64, r: u64) -> u64 {
    ((a as u128 * b as u128) % r as u128) as u64
}

fn invmod(a: u64, r: u64) -> Option<u64> {
    let (mut old_r, mut rr) = (a as i128, r as i128);
    let (mut old_s, mut s) = (1i128, 0i128);
    while rr != 0 {
        let q = old_r / rr;
        (old_r, rr) = (rr, old_r - q * rr);
        (old_s, s) = (s, old_s - q * s);
    }
    if old_r != 1 {
        return None;
    }
    Some(old_s.rem_euclid(r as i128) as u64)
}

/// Incremental row echelon form over `Z/rZ`.
struct Echelon {
    columns: usize,
    r: u64,
    pivots: Vec<Option<Vec<u64>>>,
    rank: usize,
}

impl Echelon {
    fn new(columns: usize, r: u64) -> Self {
        Self {
            columns,
            r,
            pivots: vec![None; columns],
            rank: 0,
        }
    }

    /// Reduce and keep `row` (`columns + 1` entries, the last the right
    /// hand side); `true` when it raised the rank.
    fn push(&mut self, mut row: Vec<u64>) -> bool {
        let r = self.r;
        for c in 0..self.columns {
            if row[c] == 0 {
                continue;
            }
            match &self.pivots[c] {
                Some(p) => {
                    let f = row[c];
                    for (x, &y) in row.iter_mut().zip(p.iter()) {
                        *x = (*x + r - mulmod(f, y, r)) % r;
                    }
                }
                None => {
                    let Some(inv) = invmod(row[c], r) else {
                        return false;
                    };
                    for x in row.iter_mut() {
                        *x = mulmod(*x, inv, r);
                    }
                    self.pivots[c] = Some(row);
                    self.rank += 1;
                    return true;
                }
            }
        }
        false
    }

    fn solve(&self) -> Option<Vec<u64>> {
        if self.rank != self.columns {
            return None;
        }
        let r = self.r;
        let mut x = vec![0u64; self.columns];
        for c in (0..self.columns).rev() {
            let p = self.pivots[c].as_ref()?;
            let mut v = p[self.columns];
            for c2 in c + 1..self.columns {
                v = (v + r - mulmod(p[c2], x[c2], r)) % r;
            }
            x[c] = v;
        }
        Some(x)
    }
}

// ── The pipeline ────────────────────────────────────────────────────

struct SplitMix(u64);

impl SplitMix {
    fn next(&mut self) -> u64 {
        self.0 = self.0.wrapping_add(0x9e37_79b9_7f4a_7c15);
        let mut z = self.0;
        z = (z ^ (z >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
        z ^ (z >> 31)
    }

    /// Remove modulo bias from each nonzero scalar draw. The additive
    /// walk still has correlated queries; diagnostics never call them IID.
    fn scalar(&mut self, r: u64) -> u64 {
        let span = r - 1;
        let threshold = span.wrapping_neg() % span;
        loop {
            let word = self.next();
            if word >= threshold { return 1 + word % span; }
        }
    }
}

/// The relation `[a]G + [b]Q = Σ_i P_i` a target's logarithm was derived
/// from, over base indices; empty `points` means the probe was `O`.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DescentWitness {
    pub a: u64,
    pub b: u64,
    pub points: Vec<usize>,
}

/// One complete cold job's state: base, table, relations, logs.
#[derive(Default, Debug, Clone, serde::Serialize)]
pub struct StageDiagnostics {
    pub ordinary_queries: u64,
    pub identity_queries: u64,
    pub pdp_verified: u64,
    pub pdp_unresolved: u64,
    /// Accepted row order: [query trial, rank before insertion, rank after].
    pub rank_events: Vec<[u64; 3]>,
    pub matrix_nonzeros: u64,
}

pub struct TinyIc {
    diagnostics: StageDiagnostics,
    arith: Arith,
    canon: NormalBasis,
    n: u32,
    r: u64,
    h: u64,
    lambda_pow: Vec<u64>,
    g: FastPoint,
    g_table: Vec<FastPoint>,
    /// Base points, orbit-major: index `o·2n + 2k + s` is `(−1)^s π^k(C_o)`.
    points: Vec<FastPoint>,
    negated: Vec<FastPoint>,
    orbits: usize,
    /// `[h]C_o`, the column points.
    columns: Vec<FastPoint>,
    table: PairTable,
    table_rows: usize,
    chunk: usize,
    max_trials: u64,
    // walk state for relation probes
    rng: SplitMix,
    stride: FastPoint,
    stride_scalar: u64,
    probe: FastPoint,
    probe_scalar: u64,
    trials: u64,
    // rows and solution
    echelon: Echelon,
    seen: Vec<(u64, [u32; 3])>,
    accepted: usize,
    duplicates: usize,
    solve_attempts: usize,
    logs: Option<Vec<u64>>,
    // scratch
    dens: Vec<u64>,
    // Which entry of `dens` holds each block position's inverse: +P and -P
    // share an abscissa, hence a denominator, and are inverted once.
    slot: Vec<usize>,
    scratch: Vec<u64>,
}

/// Orbits for a subgroup of order `r`: `8 * round((r / 4,196,903)^0.157)`,
/// never fewer than one batch.  The exponent is the growth of the measured
/// optima (8, 16, 24 orbits across 1100x in `r`, round 0022), not the
/// pair-table model's `r^(1/3)`, which predicts 30 and 83 and measured worse.
fn policy_orbits(r: u64) -> usize {
    let scale = ((r as f64) / 4_196_903.0).powf(0.157).max(1.0);
    8 * (scale.round() as usize).max(1)
}

#[cfg(test)]
mod policy_tests {
    use super::policy_orbits;

    #[test]
    fn policy_is_one_batch_across_the_whole_panel_and_grows_beyond_it() {
        for r in [2_003u64, 42_457, 65_587, 130_873, 262_543, 1_439_393, 2_095_853, 4_196_903] {
            assert_eq!(policy_orbits(r), 8, "panel r = {r}");
        }
        assert_eq!(policy_orbits(230_603_167), 16);
        assert_eq!(policy_orbits(4_644_189_029), 24);
        assert_eq!(policy_orbits(10_063_074_221), 24);
        assert_eq!(policy_orbits(11_514_943_771), 24);
    }
}

impl TinyIc {
    /// Build the base, its columns and the pair table.  `Err` describes
    /// an unsupported job; callers should check [`supports`] first.
    pub fn new(
        kc: &KoblitzCurve,
        spec: &FactorBaseSpec,
        algorithm_seed: u64,
        max_trials: u64,
    ) -> Result<Self, String> {
        let FactorBaseSpec::SubgroupOrbits { seed, points } = spec else {
            return Err("fast pipeline needs a SubgroupOrbits base".into());
        };
        if !supports(kc, spec, 3) {
            return Err("fast pipeline does not support this curve".into());
        }
        let arith = Arith::new(kc).ok_or("field too wide")?;
        let n = kc.n;
        let r = kc.subgroup_order.to_u64().ok_or("order too wide")?;
        let h = kc.cofactor.to_u64().ok_or("cofactor too wide")?;
        let lambda = kc.lambda.to_u64().ok_or("lambda too wide")? % r;
        let g = arith.lift(kc.generator());

        mark(Phase::FactorBase);
        // ── The base: the same draws as `build_subgroup_orbit_factor_base`.
        // Sets are small vectors: a few dozen abscissae do not need a
        // hashed container, and the hashing was a third of the setup.
        let mut rng = SeededChaCha12::seed_from_u64(*seed);
        let cap = 1u64 << n;
        // Factor-base POLICY: past the panel, the orbit count follows the
        // subgroup order.  The sampler builds orbits in batches of eight,
        // which is optimal on every cell up to r = 4.2e6 and not beyond it:
        // round 0022 measured the best base at 8, 16 and 24 orbits at n23a1,
        // n37a0 and n43a1, and the pinned single batch cost the candidate
        // 2.6x at n43a1.  The rule is fitted to those three optima and frozen
        // before any cell it is scored on was measured with it.
        //
        // Where the rule says one batch, the job's own `points` is kept, so
        // the base is the incumbent's exactly.  The first version asked for
        // a full batch's worth of points instead, and on a toy group too
        // small to hold eight orbits it failed to build any base where the
        // incumbent builds one -- caught by `base_matches_general_construction`
        // before any measurement.
        let policy = policy_orbits(r);
        let target = if policy > 8 { 2 * n as usize * policy } else { *points };
        if target == 0 {
            return Err("a factor base needs at least one point".into());
        }
        let budget = 1024u64 * target as u64;
        let mut drawn = 0u64;
        let mut seen_x: Vec<u64> = Vec::new();
        // Frobenius closure of the accepted representatives, sorted.
        let mut closure: Vec<u64> = Vec::new();
        let mut xs: Vec<u64> = Vec::new();
        loop {
            let mut added = 0usize;
            while added < 8 {
                drawn += 1;
                if drawn > budget {
                    return Err(format!(
                        "drew {drawn} abscissae without reaching {target} subgroup points"
                    ));
                }
                let x = rng.gen_range_u64(1, cap);
                let Some(point) = arith.lift_x(x) else {
                    continue;
                };
                let projected = arith.mul_point(point, h);
                if projected.infinity || seen_x.contains(&projected.x) {
                    continue;
                }
                seen_x.push(projected.x);
                let mut orbit = projected.x;
                for _ in 0..n {
                    closure.push(orbit);
                    orbit = arith.sqr(orbit);
                }
                added += 1;
            }
            closure.sort_unstable();
            closure.dedup();
            // The general loop skips a rebuild while the abscissae cannot
            // reach the target; here the closure is the rebuild.
            if 2 * closure.len() < target {
                continue;
            }
            xs = closure.clone();
            break;
        }

        // ── Orbits, in ascending order of their least abscissa.
        let mut assigned = vec![false; xs.len()];
        let mut points_vec: Vec<FastPoint> = Vec::with_capacity(2 * xs.len());
        let mut columns: Vec<FastPoint> = Vec::new();
        for (start, &x) in xs.iter().enumerate() {
            if assigned[start] {
                continue;
            }
            let rep = arith.lift_x(x).ok_or("base abscissa does not lift")?;
            let mut current = rep;
            for _ in 0..n {
                let slot = xs.binary_search(&current.x).map_err(|_| "orbit leaves the base")?;
                if std::mem::replace(&mut assigned[slot], true) {
                    return Err("degenerate Frobenius orbit in base".into());
                }
                points_vec.push(current);
                points_vec.push(arith.neg(current));
                current = arith.frobenius_k(current, 1);
            }
            if current != rep {
                return Err("orbit does not close".into());
            }
            // The column IS the orbit representative.  `rep` is already in
            // the order-`r` subgroup -- it is a Frobenius image of a point the
            // sampler projected with `[h]` -- so the second `[h]` scaled every
            // column by a constant and scaled the rows by the same constant to
            // match.  Dropping both leaves the same logarithms and saves `K`
            // scalar multiplications by the cofactor per job, which is the
            // whole of the base phase wherever `h` is large.
            columns.push(rep);
        }
        if points_vec.len() != 2 * xs.len() {
            return Err("orbit closure does not cover the base".into());
        }
        let orbits = columns.len();
        if orbits < 2 || columns.iter().any(|c| c.infinity) {
            return Err("base has fewer than two projected columns".into());
        }
        if orbits > usize::from(u8::MAX) || points_vec.len() > usize::from(u16::MAX) {
            return Err("base too large for the packed pair table".into());
        }
        mark(Phase::Precompute);
        let negated: Vec<FastPoint> = points_vec.iter().map(|&p| arith.neg(p)).collect();
        let mut lambda_pow = vec![1u64; n as usize];
        for k in 1..n as usize {
            lambda_pow[k] = mulmod(lambda_pow[k - 1], lambda, r);
        }

        // ── The folded pair table.
        //
        // Row `o` of the folded table holds `C_o + P_j` for every `j`, so a
        // pair `(P_i, P_j)` is represented once either summand's orbit has a
        // row: `t` rows cover the fraction `1 − ((K−t)/K)²` of the pairs.
        // Building a row costs `|F|` entries; a probe then costs about one
        // entry per rest it scans, and scans `1/(λ·cov)` rests on average,
        // `λ = |F|(|F|+1)/(2r)` being the expected pair-sum witnesses of a
        // rest.  The row count is the one that minimises the expected total,
        // `t·|F| + (K + TABLE_PROBES)/(λ·cov(t))`, over `1 ≤ t ≤ K` — a fixed
        // function of the public base size, column count and subgroup order,
        // decided before any probe is drawn.  On every cell of this
        // operation that is one or two rows.
        let canon = NormalBasis::new(&arith).ok_or("no normal basis found")?;
        let size = points_vec.len();
        let lambda_pairs = (size as f64) * (size as f64 + 1.0) / 2.0 / r as f64;
        let coverage = |rows: usize| {
            let rest = (orbits - rows) as f64 / orbits as f64;
            1.0 - rest * rest
        };
        let expected_work = |rows: usize| {
            (rows * size) as f64 + (orbits as f64 + TABLE_PROBES) / (lambda_pairs * coverage(rows)).max(1e-12)
        };
        let table_rows = (1..=orbits)
            .min_by(|&a, &b| expected_work(a).total_cmp(&expected_work(b)))
            .unwrap_or(orbits);
        let mut table = PairTable::with_capacity(table_rows * size);
        let mut sums: Vec<FastPoint> = Vec::with_capacity(size);
        let mut dens = Vec::with_capacity(size);
        let mut scratch = Vec::with_capacity(size);
        for o in 0..table_rows {
            let rep = points_vec[o * 2 * n as usize];
            Self::add_many(&arith, rep, &points_vec, &mut sums, &mut dens, &mut scratch);
            for (j, &sum) in sums.iter().enumerate() {
                if sum.infinity {
                    continue;
                }
                let (key, rotation) = canon.canon(sum.x);
                table.insert(
                    key,
                    PairEntry {
                        sum_x: sum.x,
                        sum_y: sum.y,
                        other: j as u16,
                        orbit: o as u8,
                        rotation: rotation as u8,
                    },
                );
            }
        }
        // A scan block pays one inversion and is thrown away on an early
        // exit; size it to about one expected witness per block.
        // `1 − exp(−x) ≥ min(x, 1)/2`, enough to size a block without libm.
        //
        // The ceiling is 16, not 64.  One expected witness per block is the
        // wrong target: the inversion a block amortises saturates after a
        // dozen or so rests, while the work discarded on an early exit keeps
        // growing with the block, so past ~16 a larger block costs more than
        // it saves.  Measured over the round-0017 panel, six fixtures a cell
        // (`campaign_20260916/round18_block_grid.py`), the block this rule
        // asks for is past its own optimum wherever it exceeds 16 — at n23a1
        // it asks for 102, which costs 1.040x what 16 costs.  Only the
        // ceiling moves; the shape of the rule, and every cell whose value is
        // already at or below 16, are unchanged.
        let hit = (lambda_pairs * coverage(table_rows)).min(1.0).max(1e-9);
        let chunk = ((1.0 / hit) as usize + 1).clamp(8, 16).min(size);

        mark(Phase::Queries);
        let mut prng = SplitMix(algorithm_seed ^ 0x5449_4e59_4943_0001);
        let probe_scalar = prng.scalar(r);
        let stride_scalar = prng.scalar(r);
        // `[2^i]G` for every bit of the order: every multiple of `G` the
        // job needs — probes, strides and the certification of each column
        // logarithm — is then a handful of affine additions.
        mark(Phase::Precompute);
        let g_table = arith.doubling_table(g, 64 - r.leading_zeros());
        mark(Phase::Queries);
        let probe = arith.fixed_base_mul(&g_table, probe_scalar);
        let stride = arith.fixed_base_mul(&g_table, stride_scalar);
        mark(Phase::MatrixBuild);
        let echelon = Echelon::new(orbits, r);
        mark(Phase::Setup);
        Ok(Self {
            diagnostics: StageDiagnostics::default(),
            arith,
            canon,
            n,
            r,
            h,
            lambda_pow,
            g,
            g_table,
            points: points_vec,
            negated,
            orbits,
            columns,
            table,
            table_rows,
            chunk,
            max_trials,
            rng: prng,
            stride,
            stride_scalar,
            probe,
            probe_scalar,
            trials: 0,
            echelon,
            seen: Vec::new(),
            accepted: 0,
            duplicates: 0,
            solve_attempts: 0,
            logs: None,
            dens: Vec::with_capacity(size),
            slot: Vec::with_capacity(size),
            scratch: Vec::with_capacity(size),
        })
    }

    fn add_many(
        arith: &Arith,
        p: FastPoint,
        qs: &[FastPoint],
        out: &mut Vec<FastPoint>,
        dens: &mut Vec<u64>,
        scratch: &mut Vec<u64>,
    ) {
        dens.clear();
        dens.extend(qs.iter().map(|q| if p.infinity || q.infinity || q.x == p.x { 0 } else { p.x ^ q.x }));
        arith.batch_inv(dens, scratch);
        out.clear();
        for (q, &inv) in qs.iter().zip(dens.iter()) {
            if inv == 0 {
                out.push(arith.add(p, *q));
            } else {
                let lambda = arith.mul(p.y ^ q.y, inv);
                out.push(arith.add_with_lambda(p, *q, lambda));
            }
        }
    }

    /// `(rows built, rows possible, stored sum orbits, scan block)` of the
    /// folded pair table, for reports.
    pub fn table_shape(&self) -> (usize, usize, usize, usize) {
        (self.table_rows, self.orbits, self.table.len(), self.chunk)
    }

    /// Relation columns (signed Frobenius orbits of the base).
    pub fn columns(&self) -> usize {
        self.orbits
    }

    /// The base, in the index order relations refer to.
    pub fn base_points(&self) -> Vec<BinaryPoint> {
        self.points.iter().map(|&p| self.arith.lower(p)).collect()
    }

    /// The base as single-word coordinates, in the same order.
    pub fn base_words(&self) -> Vec<(u64, u64)> {
        self.points.iter().map(|p| (p.x, p.y)).collect()
    }

    /// One representative point per signed Frobenius orbit, in orbit order:
    /// entry `o` is `points[index(o, 0, false)]`, from which the whole base
    /// regenerates as `+Frob^k(R), -Frob^k(R)` for `k < n`. The checker
    /// performs that expansion itself, so a report carrying these instead of
    /// the full base names the same base with `2n` times fewer points.
    pub fn orbit_representatives(&self) -> Vec<(u64, u64)> {
        (0..self.columns.len())
            .map(|o| self.points[self.index(o as u32, 0, false)])
            .map(|p| (p.x, p.y))
            .collect()
    }

    #[inline]
    fn index(&self, orbit: u32, k: u32, negated: bool) -> usize {
        (orbit as usize) * 2 * self.n as usize + 2 * k as usize + usize::from(negated)
    }

    #[inline]
    fn location(&self, index: usize) -> (u32, u32, bool) {
        let per = 2 * self.n as usize;
        ((index / per) as u32, ((index % per) / 2) as u32, index % 2 == 1)
    }

    /// `(−1)^s λ^k mod r` for a base point.
    #[inline]
    fn coefficient(&self, index: usize) -> u64 {
        let (_, k, negated) = self.location(index);
        let c = self.lambda_pow[k as usize];
        if negated && c != 0 {
            self.r - c
        } else {
            c
        }
    }

    /// Exactly three base indices summing to `target`, scanning the base
    /// from `start` and stopping at the first witness.  The witness is
    /// re-added in the group before it is returned.
    fn decompose(&mut self, target: FastPoint, start: usize, collection: bool) -> Option<[usize; 3]> {
        if !collection { mark(Phase::TargetPdp); }
        if target.infinity {
            return None;
        }
        let size = self.points.len();
        let n = self.n;
        // Abscissae of the rests of one block; `u64::MAX` marks a rest that
        // cannot name an orbit (the point at infinity), which no abscissa is.
        let mut rests: Vec<u64> = Vec::with_capacity(self.chunk);
        let mut offset = start % size;
        let mut scanned = 0usize;
        while scanned < size {
            let len = self.chunk.min(size - scanned);
            let end = offset + len;
            // The block, wrapping around the end of the base.
            self.dens.clear();
            self.slot.clear();
            for t in 0..len {
                let i = (offset + t) % size;
                let q = self.negated[i];
                if t > 0 && q.x == self.negated[(offset + t - 1) % size].x {
                    self.slot.push(self.dens.len() - 1);
                    continue;
                }
                self.slot.push(self.dens.len());
                self.dens.push(if q.x == target.x { 0 } else { target.x ^ q.x });
            }
            self.arith.batch_inv(&mut self.dens, &mut self.scratch);
            rests.clear();
            for t in 0..len {
                let i = (offset + t) % size;
                let q = self.negated[i];
                let inv = self.dens[self.slot[t]];
                rests.push(if inv == 0 {
                    let sum = self.arith.add(target, q);
                    if sum.infinity { u64::MAX } else { sum.x }
                } else {
                    let lambda = self.arith.mul(target.y ^ q.y, inv);
                    self.arith.add_x_with_lambda(target, q, lambda)
                });
            }
            for (t, &rest_x) in rests.iter().enumerate() {
                if rest_x == u64::MAX {
                    continue;
                }
                let i = (offset + t) % size;
                let (key, rot_t) = self.canon.canon(rest_x);
                let Some(entry) = self.table.get(key) else {
                    continue;
                };
                let k = (u32::from(entry.rotation) + n - rot_t) % n;
                let image = self.arith.frobenius_k(entry.sum(), k);
                if image.x != rest_x {
                    continue;
                }
                // The orbit matched, so this rest is worth its ordinate.
                let q = self.negated[i];
                let inv = self.dens[self.slot[t]];
                let rest = if inv == 0 {
                    self.arith.add(target, q)
                } else {
                    let lambda = self.arith.mul(target.y ^ q.y, inv);
                    self.arith.add_with_lambda(target, q, lambda)
                };
                debug_assert_eq!(rest.x, rest_x);
                let negated = image.y != rest.y;
                let first = self.index(u32::from(entry.orbit), k, negated);
                let (o2, k2, s2) = self.location(entry.other as usize);
                let second = self.index(o2, (k2 + k) % n, s2 ^ negated);
                let mut witness = [i, first, second];
                witness.sort_unstable();
                mark(if collection { Phase::RelationCheck } else { Phase::TargetRelationCheck });
                let sum = witness.iter().fold(FastPoint::INFINITY, |s, &w| {
                    self.arith.add(s, self.points[w])
                });
                if sum == target {
                    return Some(witness);
                }
                mark(if collection { Phase::Pdp } else { Phase::TargetPdp });
            }
            scanned += len;
            offset = end % size;
        }
        None
    }

    /// Walk `count` probes `R_t = [a_t]G` and return the relations found.
    pub fn collect(&mut self, count: u64) -> Vec<CollectedRelation> {
        mark(Phase::Pdp);
        let mut rows = Vec::new();
        let size = self.points.len();
        for _ in 0..count {
            if self.trials >= self.max_trials {
                break;
            }
            mark(Phase::Queries);
            let trial = self.trials;
            self.trials += 1;
            let a = self.probe_scalar;
            let target = self.probe;
            // advance the walk before any early return
            self.probe_scalar = (self.probe_scalar + self.stride_scalar) % self.r;
            self.probe = self.arith.add(self.probe, self.stride);
            if a == 0 || target.infinity {
                self.diagnostics.identity_queries += 1;
                continue;
            }
            self.diagnostics.ordinary_queries += 1;
            mark(Phase::Pdp);
            let start = (trial as usize * (2 * self.n as usize + 1)) % size;
            if let Some(w) = self.decompose(target, start, true) {
                self.diagnostics.pdp_verified += 1;
                rows.push(CollectedRelation {
                    trial,
                    a,
                    points: w.to_vec(),
                });
            } else {
                self.diagnostics.pdp_unresolved += 1;
            }
        }
        mark(Phase::Setup);
        rows
    }

    /// Probes drawn so far.
    pub fn trials(&self) -> u64 {
        self.trials
    }

    /// Add rows over the projected columns.
    pub fn push(&mut self, rows: &[CollectedRelation]) {
        for rel in rows {
            mark(Phase::RelationCheck);
            let mut ids = [0u32; 3];
            for (slot, &i) in ids.iter_mut().zip(rel.points.iter()) {
                *slot = i as u32;
            }
            ids.sort_unstable();
            if self.seen.contains(&(rel.a, ids)) {
                self.duplicates += 1;
                continue;
            }
            self.seen.push((rel.a, ids));
            self.accepted += 1;
            mark(Phase::MatrixBuild);
            let mut row = vec![0u64; self.orbits + 1];
            for &i in &rel.points {
                let (o, _, _) = self.location(i);
                row[o as usize] = (row[o as usize] + self.coefficient(i)) % self.r;
            }
            // Columns are the representatives themselves, so the row's
            // right-hand side loses the matching factor of `h`.
            row[self.orbits] = rel.a % self.r;
            self.diagnostics.matrix_nonzeros += row[..self.orbits].iter().filter(|&&v| v != 0).count() as u64;
            let before = self.echelon.rank as u64;
            mark(Phase::RelationLa);
            self.echelon.push(row);
            mark(Phase::MatrixBuild);
            self.diagnostics.rank_events.push([rel.trial, before, self.echelon.rank as u64]);
        }
        mark(Phase::Setup);
    }

    /// Solve when the rows determine every column; each logarithm is
    /// certified by `[ℓ]G = [h]C` before the table is accepted.
    pub fn try_solve(&mut self) -> bool {
        mark(Phase::RelationLa);
        self.solve_attempts += 1;
        let Some(logs) = self.echelon.solve() else {
            return false;
        };
        mark(Phase::RelationCheck);
        let ok = self.certify(&logs);
        if ok {
            self.logs = Some(logs);
        }
        ok
    }

    /// `[ℓ_o]G == [h]C_o` for every column, the multiples computed from
    /// the doubling table of `G` with the columns' additions batched.
    fn certify(&self, logs: &[u64]) -> bool {
        if logs.len() != self.columns.len() || logs.iter().any(|&l| l >= self.r) {
            return false;
        }
        let multiples = self.arith.fixed_base_mul_many(&self.g_table, logs);
        multiples.iter().zip(&self.columns).all(|(m, c)| m == c)
    }

    /// Re-certify every column logarithm in the group.
    pub fn verify_columns(&self) -> bool {
        mark(Phase::RelationCheck);
        match &self.logs {
            Some(logs) => self.certify(logs),
            None => false,
        }
    }

    /// `(column point, logarithm)` per column.
    pub fn column_logs(&self) -> Option<Vec<(BinaryPoint, BigUint)>> {
        let logs = self.logs.as_ref()?;
        Some(
            self.columns
                .iter()
                .zip(logs)
                .map(|(&c, &l)| (self.arith.lower(c), BigUint::from(l)))
                .collect(),
        )
    }

    /// The same as [`Self::column_logs`] in single words.
    pub fn column_words(&self) -> Option<Vec<((u64, u64), u64)>> {
        let logs = self.logs.as_ref()?;
        Some(self.columns.iter().zip(logs).map(|(c, &l)| ((c.x, c.y), l)).collect())
    }

    /// `(accepted, duplicates, solve attempts)`.
    pub fn accounting(&self) -> (usize, usize, usize) {
        (self.accepted, self.duplicates, self.solve_attempts)
    }

    pub fn field_kernel(&self) -> &'static str {
        if self.arith.field.clmul { "pclmulqdq" } else { "portable" }
    }

    pub fn stage_diagnostics(&self) -> (&StageDiagnostics, usize) {
        (&self.diagnostics, self.echelon.rank)
    }

    /// The logarithm of `q`, verified as `[d]G = Q` in the group, with
    /// the number of descent probes it took and the relation
    /// `[a]G + [b]Q = Σ P_i` it was derived from. Every admitted witness
    /// has exactly three indices; direct collisions are skipped. The relation is the
    /// index-calculus certificate the checker re-verifies.
    pub fn solve_target(&mut self, q: &BinaryPoint) -> Option<(BigUint, u64, DescentWitness)> {
        mark(Phase::TargetDescent);
        let logs = self.logs.clone()?;
        mark(Phase::TargetQuery);
        let q_fast = self.arith.lift(q);
        if q_fast.infinity {
            return None;
        }
        let r = self.r;
        let _ = self.h; // the cofactor no longer enters the descent
        let mut a = self.rng.scalar(r);
        let b = self.rng.scalar(r);
        let stride_scalar = self.rng.scalar(r);
        let stride = self.arith.fixed_base_mul(&self.g_table, stride_scalar);
        let mut probe = self.arith.add(
            self.arith.fixed_base_mul(&self.g_table, a),
            self.arith.mul_point(q_fast, b),
        );
        mark(Phase::TargetDescent);
        let hb_inv = invmod(b, r)?;
        let size = self.points.len();
        let mut trials = 0u64;
        while trials < self.max_trials {
            trials += 1;
            let mut candidate = None;
            // A direct collision is not a three-summand IC descent. Keep
            // its work charged, advance the walk and seek an actual witness.
            if !probe.infinity {
                let start = (trials as usize * (2 * self.n as usize + 1)) % size;
                if let Some(w) = self.decompose(probe, start, false) {
                    mark(Phase::TargetDescent);
                    let mut sum = 0u64;
                    for &i in &w {
                        let (o, _, _) = self.location(i);
                        sum = (sum + mulmod(self.coefficient(i), logs[o as usize], r)) % r;
                    }
                    let numerator = (sum + r - a % r) % r;
                    candidate = Some((mulmod(numerator, hb_inv, r), w.to_vec()));
                }
            }
            mark(Phase::TargetDescent);
            if let Some((d, points)) = candidate {
                mark(Phase::RecoveryCheck);
                if d < r && self.arith.fixed_base_mul(&self.g_table, d) == q_fast {
                    return Some((BigUint::from(d), trials, DescentWitness { a, b, points }));
                }
            }
            mark(Phase::TargetQuery);
            a = (a + stride_scalar) % r;
            probe = self.arith.add(probe, stride);
            mark(Phase::TargetDescent);
        }
        None
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn the_orbit_name_from_zero_runs_equals_the_rotation_loop() {
        // Every width the pipeline runs (and up to a whole word), random
        // and sparse words, the all-ones word, powers of two and periodic
        // words: the same least rotation and the same least index.
        for n in (5..=31).chain([33, 47, 62]) {
            let basis = super::NormalBasis { n, mask: (1u64 << n) - 1, tables: (0..((n + 3) / 4) as usize).map(|i| {
                let mut t = [0u64; 16];
                for (b, slot) in t.iter_mut().enumerate() {
                    *slot = ((b as u64) << (4 * i)) & ((1u64 << n) - 1);
                }
                t
            }).collect() };
            let mask = (1u64 << n) - 1;
            let mut state = 0x243f_6a88_85a3_08d3u64 ^ u64::from(n);
            let mut words: Vec<u64> = vec![0, mask, 1, 1 << (n - 1), mask ^ 1, mask >> 1];
            let period = |p: u32| {
                let mut w = 0u64;
                let mut i = 0;
                while i < n {
                    w |= 1 << i;
                    i += p;
                }
                w & mask
            };
            words.extend((1..=n).filter(|p| n % p == 0).map(period));
            for _ in 0..3000 {
                state ^= state << 13;
                state ^= state >> 7;
                state ^= state << 17;
                words.push(state & mask);
                words.push(state & (state >> 11) & (state >> 23) & mask);
                words.push(!(state & (state >> 5)) & mask);
            }
            for &w in &words {
                assert_eq!(basis.canon(w), basis.canon_reference(w), "n={n} word={w:#b}");
            }
        }
    }

    use super::*;
    use crate::cryptanalysis::koblitz_fast::FastCurve;
    use crate::binary_ecc::F2mElement;
    use crate::cryptanalysis::koblitz_index_calculus::point_key;

    const CELLS: [(u32, u8); 9] = [
        (5, 0),
        (7, 1),
        (13, 0),
        (17, 1),
        (19, 0),
        (19, 1),
        (23, 0),
        (31, 0),
        (31, 1),
    ];

    #[test]
    fn euclid_inverse_matches_fermat() {
        for (n, a) in CELLS {
            let Some(kc) = KoblitzCurve::new(a, n) else { continue };
            let fc = FastCurve::new(&kc.curve).unwrap();
            let arith = Arith::new(&kc).unwrap();
            let mask = (1u64 << n) - 1;
            let mut state = 0x1234_5678_9abc_def0u64 ^ u64::from(n);
            for _ in 0..2000 {
                state = state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
                let x = (state >> 11) & mask;
                let y = (state >> 23) & mask;
                if x == 0 {
                    continue;
                }
                assert_eq!(arith.inv(x), fc.field.inv(x), "n={n} x={x}");
                assert_eq!(arith.mul(x, arith.inv(x)), 1);
                assert_eq!(arith.mul(x, y), fc.field.mul(x, y));
                assert_eq!(arith.sqr(x), fc.field.sqr(x));
                assert_eq!(arith.field.sqr_k(x, 5), fc.field.sqr_k(x, 5));
            }
            assert_eq!(arith.lift(kc.generator()), fc.lift(kc.generator()));
            assert_eq!(arith.lower(arith.lift(kc.generator())), *kc.generator());
        }
    }

    #[test]
    fn arithmetic_matches_fast_curve() {
        for (n, a) in CELLS {
            let Some(kc) = KoblitzCurve::new(a, n) else { continue };
            let fc = FastCurve::new(&kc.curve).unwrap();
            let arith = Arith::new(&kc).unwrap();
            let g = fc.lift(kc.generator());
            let r = kc.subgroup_order.to_u64().unwrap();
            let table = arith.doubling_table(g, 64 - r.leading_zeros());
            for (i, entry) in table.iter().enumerate() {
                assert_eq!(*entry, fc.mul_u64(g, 1u64 << i), "n={n} table {i}");
            }
            let mut ks: Vec<u64> = vec![1, 2, 3, 5, 17, 1000, r - 1, r / 3 + 1, r - 2, 12345 % r];
            let mut state = 0x9e37_79b9u64 ^ u64::from(n);
            for _ in 0..40 {
                state = state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
                ks.push(1 + (state >> 20) % (r - 1));
            }
            for &k in &ks {
                let k = k % r;
                if k == 0 {
                    continue;
                }
                let expected = fc.mul_u64(g, k);
                assert_eq!(arith.mul_point(g, k), expected, "n={n} k={k}");
                assert_eq!(arith.mul_point_affine(g, k), expected, "n={n} k={k}");
                assert_eq!(arith.fixed_base_mul(&table, k), expected, "n={n} k={k}");
                let q = fc.mul_u64(g, 777 % r);
                assert_eq!(arith.mul_point(q, k), fc.mul_u64(q, k), "n={n} k={k} q");
            }
            let reduced: Vec<u64> = ks.iter().map(|k| k % r).filter(|&k| k != 0).collect();
            let many = arith.fixed_base_mul_many(&table, &reduced);
            for (&k, m) in reduced.iter().zip(&many) {
                assert_eq!(*m, fc.mul_u64(g, k), "n={n} k={k} many");
            }
            // degenerate: [r]G = O and [r-1]G = -G through the projective path
            assert_eq!(arith.mul_point(g, r), FastPoint::INFINITY);
            assert_eq!(arith.mul_point(g, r - 1), fc.neg(g));
            let p = fc.mul_u64(g, 12345 % r);
            let q = fc.mul_u64(g, 777 % r);
            assert_eq!(arith.add(p, q), fc.add(p, q));
            assert_eq!(arith.double(p), fc.double(p));
            assert_eq!(arith.add(p, arith.neg(p)), FastPoint::INFINITY);
            assert_eq!(arith.frobenius_k(p, 3), fc.frobenius_k(p, 3));
        }
    }

    #[test]
    fn normal_basis_rotation_locates_frobenius_images() {
        for (n, a) in CELLS {
            let Some(kc) = KoblitzCurve::new(a, n) else { continue };
            let arith = Arith::new(&kc).unwrap();
            let canon = NormalBasis::new(&arith).unwrap();
            let mask = (1u64 << n) - 1;
            let mut state = 0xdead_beef_u64 ^ u64::from(n);
            for _ in 0..500 {
                state = state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
                let x = (state >> 7) & mask;
                if x <= 1 {
                    continue;
                }
                let (key, rot_x) = canon.canon(x);
                for k in 0..n {
                    let y = arith.field.sqr_k(x, k);
                    let (key_y, rot_y) = canon.canon(y);
                    assert_eq!(key, key_y);
                    assert_eq!((rot_x + n - rot_y) % n, k, "n={n} x={x} k={k}");
                }
                assert_eq!(arith.field.sqr_k(x, rot_x) , {
                    // the element whose coords are the least rotation
                    let mut best = x; let mut bx = x;
                    for _ in 1..n { bx = arith.sqr(bx); if canon.coords(bx) < canon.coords(best) { best = bx; } }
                    best
                });
            }
        }
    }

    #[test]
    fn base_matches_general_construction() {
        let mut checked = 0;
        for (n, a) in CELLS {
            let Some(kc) = KoblitzCurve::new(a, n) else { continue };
            let spec = FactorBaseSpec::SubgroupOrbits { seed: 43, points: 6 * n as usize };
            let Ok(general) = spec.materialize(&kc) else {
                // A toy group too small for the recipe: both must decline.
                assert!(TinyIc::new(&kc, &spec, 7, 4096).is_err(), "n={n} a={a}");
                continue;
            };
            let tiny = TinyIc::new(&kc, &spec, 7, 4096).unwrap();
            let mut expected: Vec<(BigUint, BigUint)> = general.points.iter().map(point_key).collect();
            let mut actual: Vec<(BigUint, BigUint)> = tiny.base_points().iter().map(point_key).collect();
            expected.sort();
            actual.sort();
            assert_eq!(expected, actual, "base differs on n={n} a={a}");
            assert_eq!(tiny.columns(), general.signed_orbits.len(), "columns on n={n} a={a}");
            // every base point is in the subgroup and the index layout is consistent
            for (i, p) in tiny.base_points().iter().enumerate() {
                let (o, k, s) = tiny.location(i);
                let rep = tiny.base_points()[tiny.index(o, 0, false)].clone();
                let mut expected = rep;
                for _ in 0..k { expected = kc.frobenius(&expected); }
                if s {
                    if let BinaryPoint::Affine { x, y } = &expected {
                        expected = BinaryPoint::Affine { x: x.clone(), y: x.add(y) };
                    }
                }
                assert_eq!(*p, expected);
                assert_eq!(kc.mul(p, &kc.subgroup_order), BinaryPoint::Infinity);
            }
            checked += 1;
        }
        assert!(checked >= 7);
    }

    #[test]
    fn complete_solve_verifies_in_general_arithmetic() {
        for (n, a) in CELLS {
            if n < 13 { continue; }
            let Some(kc) = KoblitzCurve::new(a, n) else { continue };
            let spec = FactorBaseSpec::SubgroupOrbits { seed: 43, points: 6 * n as usize };
            for seed in [1u64, 2, 3] {
                let mut tiny = TinyIc::new(&kc, &spec, seed, 4096).unwrap();
                let mut all = Vec::new();
                let mut solved = false;
                while tiny.trials() < 4096 && !solved {
                    let rows = tiny.collect(4);
                    tiny.push(&rows);
                    all.extend(rows);
                    solved = tiny.try_solve();
                }
                assert!(solved, "n={n} a={a} seed={seed}");
                let base = tiny.base_points();
                let g = kc.generator();
                for rel in &all {
                    let sum = rel.points.iter().fold(BinaryPoint::Infinity, |s, &i| kc.add(&s, &base[i]));
                    assert_eq!(sum, kc.mul(g, &BigUint::from(rel.a)));
                    assert_eq!(rel.points.len(), 3);
                }
                let logs = tiny.column_logs().unwrap();
                assert_eq!(logs.len(), tiny.columns());
                for (c, l) in &logs {
                    assert_eq!(kc.mul(g, l), *c);
                }
                assert!(tiny.verify_columns());
                let r = kc.subgroup_order.to_u64().unwrap();
                // per base index: its column's log times its signed Frobenius coefficient
                let orbit_logs: Vec<u64> = (0..base.len())
                    .map(|i| {
                        let (o, _, _) = tiny.location(i);
                        let (_, l) = &logs[o as usize];
                        mulmod(tiny.coefficient(i), l.to_u64().unwrap(), r)
                    })
                    .collect();
                for d in [5u64, 99, r - 2, r / 2] {
                    let q = kc.mul(g, &BigUint::from(d));
                    let (found, trials, w) = tiny.solve_target(&q).expect("descent");
                    assert_eq!(found, BigUint::from(d), "n={n} a={a} d={d}");
                    assert!(trials >= 1);
                    assert_eq!(w.points.len(), 3);
                    let probe = kc.add(&kc.mul(g, &BigUint::from(w.a)), &kc.mul(&q, &BigUint::from(w.b)));
                    let sum = w.points.iter().fold(BinaryPoint::Infinity, |s, &i| kc.add(&s, &base[i]));
                    assert_eq!(sum, probe, "n={n} a={a} d={d} witness");
                    let logsum = w.points.iter().fold(0u64, |s, &i| (s + orbit_logs[i]) % r);
                    // Under the `representative` column convention a column is the
                    // orbit representative itself rather than `[h]` of it, so the row
                    // reads `a + b*d` and NOT `h*(a + b*d)`.  This assertion still
                    // carried the cofactor after round 0018's column patch moved the
                    // convention, and failed at every cell whose cofactor is not one.
                    assert_eq!((w.a + mulmod(w.b, d, r)) % r, logsum, "n={n} a={a} d={d} scalar");
                }
                let (accepted, duplicates, attempts) = tiny.accounting();
                assert_eq!(accepted + duplicates, all.len());
                assert!(attempts >= 1);
            }
        }
    }

    #[test]
    fn seeded_chacha_matches_std_rng() {
        use rand::{rngs::StdRng, Rng, SeedableRng};
        for seed in [0u64, 1, 43, 2026091606, u64::MAX, 0x9e37_79b9_7f4a_7c15] {
            for cap in [1u64 << 5, 1u64 << 13, 1u64 << 19, 1u64 << 23, 1u64 << 31, 1000, 3] {
                let mut reference = StdRng::seed_from_u64(seed);
                let mut ours = SeededChaCha12::seed_from_u64(seed);
                for i in 0..3000 {
                    let expected: u64 = reference.gen_range(1..cap);
                    assert_eq!(ours.gen_range_u64(1, cap), expected, "seed {seed} cap {cap} draw {i}");
                }
            }
            let mut reference = StdRng::seed_from_u64(seed);
            let mut ours = SeededChaCha12::seed_from_u64(seed);
            for i in 0..500 {
                let expected: u64 = reference.gen();
                assert_eq!(ours.next_u64(), expected, "seed {seed} word {i}");
            }
        }
    }

    #[test]
    fn unsupported_recipes_are_declined() {
        let kc = KoblitzCurve::new(0, 13).unwrap();
        assert!(!supports(&kc, &FactorBaseSpec::Factor { index: 0 }, 3));
        assert!(!supports(&kc, &FactorBaseSpec::SubgroupOrbits { seed: 1, points: 8 }, 2));
        let composite = KoblitzCurve::new(0, 15);
        if let Some(kc) = composite {
            assert!(!supports(&kc, &FactorBaseSpec::SubgroupOrbits { seed: 1, points: 8 }, 3));
        }
        let _ = F2mElement::zero(13);
    }
}

#[cfg(test)]
mod phase_admission_tests {
    use super::*;

    #[test]
    fn direct_collision_is_skipped_and_real_descent_is_retained() {
        let kc = KoblitzCurve::new(0, 13).unwrap();
        let base = FactorBaseSpec::SubgroupOrbits { seed: 43, points: 78 };
        let mut tiny = TinyIc::new(&kc, &base, 20260925, 4096).unwrap();
        while !tiny.try_solve() && tiny.trials() < 4096 {
            let rows = tiny.collect(1);
            tiny.push(&rows);
        }
        assert!(tiny.verify_columns());
        // Predict only the next descent query, then force it to be the identity.
        // This is an admission control, never an ordinary-yield sample.
        let mut next = SplitMix(tiny.rng.0);
        let a = next.scalar(tiny.r);
        let b = next.scalar(tiny.r);
        let d = mulmod(tiny.r - a, invmod(b, tiny.r).unwrap(), tiny.r);
        let q = kc.mul(kc.generator(), &BigUint::from(d));
        let (found, attempts, witness) = tiny.solve_target(&q).unwrap();
        assert_eq!(found, BigUint::from(d));
        assert!(attempts >= 2);
        assert_eq!(witness.points.len(), 3);
        assert_eq!(tiny.diagnostics.ordinary_queries,
            tiny.diagnostics.pdp_verified + tiny.diagnostics.pdp_unresolved);
        assert_eq!(tiny.trials(), tiny.diagnostics.ordinary_queries + tiny.diagnostics.identity_queries);
        assert_eq!(tiny.diagnostics.rank_events.len(), tiny.accepted);
        assert_eq!(tiny.diagnostics.rank_events.last().unwrap()[2], tiny.columns() as u64);
    }
}

#[cfg(test)]
mod row_qualification {
    use super::Echelon;

    // Batch RREF with Fermat inversion is independent of the incremental
    // reducer and its extended-Euclidean inverse. All arithmetic is widened.
    fn reference_rank(input: &[Vec<u64>], columns: usize, prime: u64) -> usize {
        let modulus = u128::from(prime);
        let mut matrix: Vec<Vec<u128>> = input.iter()
            .map(|row| row[..columns].iter().map(|&v| u128::from(v)).collect()).collect();
        let mut rank = 0;
        for column in 0..columns {
            let Some(pivot) = (rank..matrix.len()).find(|&i| matrix[i][column] != 0) else { continue };
            matrix.swap(rank, pivot);
            let (mut power, mut exponent, mut inverse) = (matrix[rank][column], prime - 2, 1);
            while exponent != 0 {
                if exponent & 1 != 0 { inverse = inverse * power % modulus; }
                power = power * power % modulus;
                exponent >>= 1;
            }
            for value in &mut matrix[rank] { *value = *value * inverse % modulus; }
            for row in 0..matrix.len() {
                if row == rank { continue; }
                let factor = matrix[row][column];
                for c in 0..columns {
                    matrix[row][c] = (matrix[row][c] + modulus - factor * matrix[rank][c] % modulus) % modulus;
                }
            }
            rank += 1;
        }
        rank
    }

    #[test]
    fn incremental_rank_and_solution_match_independent_batch_elimination() {
        for prime in [3, 5, 2003, 4_196_903, (1u64 << 61) - 1] {
            for columns in [1, 2, 7, 16, 24] {
                let solution: Vec<u64> = (0..columns).map(|i| (prime - 1 - i as u64 % prime) % prime).collect();
                let mut reducer = Echelon::new(columns, prime);
                let mut rows: Vec<Vec<u64>> = Vec::new();
                let mut state = 0xC61D_2026_0925u64 ^ prime ^ columns as u64;
                for step in 0..(3 * columns + 8) {
                    let mut row = vec![0; columns + 1];
                    if step >= 2 * columns + 8 {
                        // End with a full independent basis even after singular prefixes.
                        row[step - (2 * columns + 8)] = 1;
                    } else if step % 4 == 1 && !rows.is_empty() {
                        row = rows.last().unwrap().clone();
                    } else if step % 4 != 0 {
                        for value in &mut row[..columns] {
                            state ^= state << 13; state ^= state >> 7; state ^= state << 17;
                            *value = state % prime;
                        }
                    }
                    row[columns] = row[..columns].iter().zip(&solution).fold(0u128,
                        |sum, (&a, &b)| (sum + u128::from(a) * u128::from(b)) % u128::from(prime)) as u64;
                    let previous = reducer.rank;
                    let novel = reducer.push(row.clone());
                    rows.push(row);
                    let rank = reference_rank(&rows, columns, prime);
                    assert_eq!(reducer.rank, rank, "prime={prime} columns={columns} step={step}");
                    assert_eq!(novel, rank > previous);
                    if rank == columns { assert_eq!(reducer.solve(), Some(solution.clone())); }
                    else { assert_eq!(reducer.solve(), None); }
                }
                assert_eq!(reducer.rank, columns);
            }
        }
    }
}
