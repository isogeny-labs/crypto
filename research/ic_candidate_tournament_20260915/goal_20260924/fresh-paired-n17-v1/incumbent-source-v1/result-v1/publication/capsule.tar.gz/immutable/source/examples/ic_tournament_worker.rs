// Under `cargo test` the harness supplies the entry point instead.
#![cfg_attr(not(test), no_main)]
//! Complete, public-synthetic IC/rho jobs for the candidate tournament.
//! Uses the production research library; JSON stdin contains no known scalar.
use crypto_lib::binary_ecc::{BinaryPoint, F2mElement};
use crypto_lib::cryptanalysis::koblitz_factor_base_search::FactorBaseSpec;
use crypto_lib::cryptanalysis::koblitz_fast::FastCurve;
use crypto_lib::cryptanalysis::koblitz_index_calculus::{
    lift_points_with_x, koblitz_signed_frobenius_rho_with_preparation, point_key,
    DecompositionStrategy, FactorBaseLogSolver, IndividualLogSolver, KoblitzCurve,
    KoblitzIcOptions, KoblitzSignedRhoOptions, LinearAlgebra, PairSumTable,
    RelationCollector, RelationWorkUnit,
};
use crypto_lib::cryptanalysis::koblitz_sparse_la::SparseSolveOptions;
use crypto_lib::cryptanalysis::koblitz_tiny_ic::{self, TinyIc};
use num_bigint::BigUint;
use serde::Deserialize;
use serde_json::{json, Value};
use std::io::Read;
use std::time::Instant;
use crypto_lib::cryptanalysis::ic_phase::{self, mark, Phase};

/// The whole process allocates well under a megabyte (the largest job of the
/// panel, rho on `n23a0`, asks for 321 KB in 5,700 calls) and lives a few
/// milliseconds, so the general-purpose allocator's bookkeeping is pure
/// overhead: a bump pointer over a zero page region serves every request,
/// frees only the most recent block, grows the most recent block in place and
/// falls back to the system allocator if the region is ever exhausted. The
/// region lives in `.bss`, so it costs nothing until a page is touched.
/// Shared by every arm, rho included.
mod arena {
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::cell::UnsafeCell;
    use std::sync::atomic::{AtomicUsize, Ordering::{Acquire, AcqRel, Relaxed, Release}};

    const SIZE: usize = 64 << 20;

    #[repr(C, align(4096))]
    struct Region(UnsafeCell<[u8; SIZE]>);
    unsafe impl Sync for Region {}
    static REGION: Region = Region(UnsafeCell::new([0; SIZE]));
    /// Offset of the first free byte. Acquire/release transfers ownership of
    /// reused bytes between threads; relaxed atomics do not publish their data.
    static TOP: AtomicUsize = AtomicUsize::new(0);

    #[inline(always)]
    fn base() -> usize { REGION.0.get() as usize }

    #[cfg(test)]
    pub(super) fn contains(ptr: *mut u8) -> bool {
        (ptr as usize).wrapping_sub(base()) < SIZE
    }

    pub struct Bump;

    unsafe impl GlobalAlloc for Bump {
        #[inline]
        unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
            // Offset alignment is sufficient only up to the region's alignment.
            // Larger layouts use System, including their realloc/dealloc path.
            if layout.align() > std::mem::align_of::<Region>() {
                return System.alloc(layout);
            }
            let mut top = TOP.load(Acquire);
            loop {
                let start = (top + layout.align() - 1) & !(layout.align() - 1);
                let end = start + layout.size();
                if end > SIZE { return System.alloc(layout); }
                match TOP.compare_exchange_weak(top, end, AcqRel, Acquire) {
                    Ok(_) => return (base() + start) as *mut u8,
                    Err(seen) => top = seen,
                }
            }
        }

        #[inline]
        unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
            let offset = (ptr as usize).wrapping_sub(base());
            if offset >= SIZE { return System.dealloc(ptr, layout); }
            // Only the most recent block can be given back.
            let end = offset + layout.size();
            let _ = TOP.compare_exchange(end, offset, Release, Relaxed);
        }

        #[inline]
        unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
            let offset = (ptr as usize).wrapping_sub(base());
            if offset >= SIZE { return System.realloc(ptr, layout, new_size); }
            let end = offset + layout.size();
            if offset + new_size <= SIZE
                && TOP.compare_exchange(end, offset + new_size, AcqRel, Acquire).is_ok()
            {
                return ptr;
            }
            let new = self.alloc(Layout::from_size_align_unchecked(new_size, layout.align()));
            if !new.is_null() {
                std::ptr::copy_nonoverlapping(ptr, new, layout.size().min(new_size));
                self.dealloc(ptr, layout);
            }
            new
        }
    }
}

#[global_allocator]
static GLOBAL: arena::Bump = arena::Bump;

#[cfg(test)]
mod arena_tests {
    use std::alloc::{GlobalAlloc, Layout};
    use std::sync::{Mutex, MutexGuard};

    /// The arena is the process allocator, so the test harness and the other
    /// test threads allocate from it too and can move its top between two
    /// calls of a test.  These tests take one lock so they do not disturb
    /// each other, and retry the sequences whose claim is about the *most
    /// recent* block, which only holds when nothing else allocated in
    /// between; an interleaving is a retry, never a failure.  Reported on
    /// PR #403; the measured executable contains none of this.
    static ARENA_TESTS: Mutex<()> = Mutex::new(());

    fn exclusive() -> MutexGuard<'static, ()> {
        ARENA_TESTS.lock().unwrap_or_else(|e| e.into_inner())
    }

    #[test]
    fn over_aligned_layouts_use_system_and_preserve_bytes_when_resized() {
        let _guard = exclusive();
        let allocator = super::arena::Bump;
        for alignment in [8192, 65536, 1 << 20] {
            unsafe {
                let layout = Layout::from_size_align(97, alignment).unwrap();
                let ptr = allocator.alloc(layout);
                assert!(!ptr.is_null());
                assert_eq!((ptr as usize) % alignment, 0);
                assert!(!super::arena::contains(ptr));
                std::ptr::write_bytes(ptr, 0x6D, 97);
                let grown = allocator.realloc(ptr, layout, 257);
                assert!(!grown.is_null());
                assert_eq!((grown as usize) % alignment, 0);
                assert!(!super::arena::contains(grown));
                assert!((0..97).all(|i| *grown.add(i) == 0x6D));
                allocator.dealloc(grown, Layout::from_size_align(257, alignment).unwrap());
            }
        }
    }

    #[test]
    fn grows_the_last_block_in_place_and_gives_it_back() {
        let _guard = exclusive();
        let a = super::arena::Bump;
        let l = Layout::from_size_align(48, 8).unwrap();
        let l96 = Layout::from_size_align(96, 8).unwrap();
        for _ in 0..10_000 {
            unsafe {
                let p = a.alloc(l);
                assert!(!p.is_null() && (p as usize) % 8 == 0);
                std::ptr::write_bytes(p, 0xA5, 48);
                let q = a.realloc(p, l, 96);
                assert!((0..48).all(|i| *q.add(i) == 0xA5), "its bytes survive the growth");
                a.dealloc(q, l96);
                if q != p {
                    continue; // something else allocated in between
                }
                let r = a.alloc(l);
                a.dealloc(r, l);
                if r == p {
                    return; // grew in place and the freed block was reused
                }
            }
        }
        panic!("the most recent block never grew in place and was reused once freed");
    }

    #[test]
    fn honours_alignment_and_moves_a_block_that_cannot_grow() {
        let _guard = exclusive();
        let a = super::arena::Bump;
        unsafe {
            let l = Layout::from_size_align(24, 8).unwrap();
            let p = a.alloc(l);
            std::ptr::write_bytes(p, 0x3C, 24);
            let big = Layout::from_size_align(200, 64).unwrap();
            let q = a.alloc(big);
            assert_eq!((q as usize) % 64, 0);
            // `p` is not the most recent block whatever else ran, because
            // this thread allocated `q` after it.
            let r = a.realloc(p, l, 1000);
            assert_ne!(r, p, "a block that is not the last one moves");
            assert!((0..24).all(|i| *r.add(i) == 0x3C), "its bytes travel with it");
            a.dealloc(r, Layout::from_size_align(1000, 8).unwrap());
            a.dealloc(q, big);
            // `realloc` already released p; freeing it again is invalid.
        }
    }

    #[test]
    fn falls_back_to_the_system_allocator_beyond_the_region() {
        let _guard = exclusive();
        let a = super::arena::Bump;
        unsafe {
            let huge = Layout::from_size_align(80 << 20, 16).unwrap();
            let p = a.alloc(huge);
            assert!(!p.is_null());
            *p = 1;
            *p.add((80 << 20) - 1) = 2;
            a.dealloc(p, huge);
        }
    }
}

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct Job {
    mode: String,
    degree: u32,
    curve_a: u8,
    target_seeds: Vec<u64>,
    #[serde(default)]
    public_targets: Option<Vec<[String; 2]>>,
    algorithm_seed: u64,
    factor_base: FactorBaseSpec,
    config: Config,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(default, deny_unknown_fields)]
struct Config {
    solver: String,
    linear_algebra: String,
    batch_trials: u64,
    max_trials: u64,
    summands: usize,
    collection_window: Option<usize>,
    sparse: SparseSolveOptions,
    rho_parallel_walks: usize,
}
impl Default for Config {
    fn default() -> Self {
        Self {
            solver: "pair_table".into(), linear_algebra: "tiny_gauss".into(),
            batch_trials: 64, max_trials: 4096, summands: 3,
            collection_window: None, sparse: SparseSolveOptions::default(), rho_parallel_walks: 32,
        }
    }
}

fn point(p: &BinaryPoint) -> Value {
    match p {
        BinaryPoint::Infinity => Value::Null,
        BinaryPoint::Affine { x, y } => match (x.raw_bits(), y.raw_bits()) {
            // Same decimal text as the general conversion, without a BigUint.
            ([xw], [yw]) => json!([xw.to_string(), yw.to_string()]),
            _ => json!([x.to_biguint().to_string(), y.to_biguint().to_string()]),
        },
    }
}

// Same public hash-to-curve domain as ic workflow. No target scalar is created.
fn target(c: &KoblitzCurve, seed: u64) -> Result<BinaryPoint, String> {
    // One set of single-word tables for every lift and cofactor multiple.
    let fast = FastCurve::new(&c.curve);
    for counter in 0u64..1_000_000 {
        let mut h = blake3::Hasher::new();
        h.update(b"ic-workflow-public-target-v1\0");
        h.update(&c.n.to_le_bytes()); h.update(&[c.a]);
        h.update(&c.k.to_le_bytes()); h.update(&c.b_index.to_le_bytes());
        h.update(&seed.to_le_bytes()); h.update(&counter.to_le_bytes());
        let digest = h.finalize();
        let x = u64::from_le_bytes(digest.as_bytes()[..8].try_into().unwrap()) & ((1u64 << c.n) - 1);
        let x = F2mElement::from_biguint(&BigUint::from(x), c.n);
        // The exact single-word lift (tested equal to `points_with_x`, order
        // included) and cofactor multiple; the general path where it does not fit.
        let mut lifts = lift_points_with_x(&c.curve, fast.as_ref(), &x);
        lifts.sort_by_key(point_key);
        if lifts.is_empty() { continue; }
        let chosen = &lifts[usize::from(digest.as_bytes()[8] & 1) % lifts.len()];
        let q = match &fast {
            Some(fc) => fc.lower(fc.mul(fc.lift(chosen), &c.cofactor)),
            None => c.mul(chosen, &c.cofactor),
        };
        if q != BinaryPoint::Infinity { return Ok(q); }
    }
    Err("hash-to-curve exhausted".into())
}

/// Decode the supplied public point without constructing a target scalar or
/// silently reducing out-of-range coordinates. Seeds are provenance only.
fn public_point(c: &KoblitzCurve, encoded: &[String; 2]) -> Result<BinaryPoint, String> {
    let coordinate = |text: &str| -> Result<F2mElement, String> {
        if text.is_empty() || !text.bytes().all(|b| b.is_ascii_digit()) ||
            (text.len() > 1 && text.starts_with('0')) {
            return Err("noncanonical public coordinate".into());
        }
        let value = text.parse::<BigUint>().map_err(|_| "invalid coordinate")?;
        if value.bits() > u64::from(c.n) { return Err("coordinate outside field encoding".into()); }
        Ok(F2mElement::from_biguint(&value, c.n))
    };
    let q = BinaryPoint::Affine { x: coordinate(&encoded[0])?, y: coordinate(&encoded[1])? };
    if !c.curve.is_on_curve(&q) || c.mul(&q, &c.subgroup_order) != BinaryPoint::Infinity {
        return Err("public point is outside the declared subgroup".into());
    }
    Ok(q)
}

/// A finished report: a value tree, or text already serialised by the
/// fast pipeline (the same JSON document, written directly).
enum Report {
    Tree(Value),
    Text(String, bool),
}

fn run(job: &Job) -> Result<Report, String> {
    // Mirrors `koblitz_tiny_ic::MAX_DEGREE`, which the pair table's packed
    // coordinate width set: `u32` held it at 31, `u64` lifts it to 61. This is
    // a second, independent bound from the module's own -- lifting one without
    // the other leaves the worker refusing degrees the collector can run.
    if !(5..=61).contains(&job.degree) || job.degree % 2 == 0 || job.curve_a > 1 {
        return Err("worker accepts bounded odd-degree Koblitz fixtures (5..61)".into());
    }
    if job.mode != "fixture" && job.public_targets.as_ref().map(Vec::len) != Some(1) {
        return Err("measured jobs require exactly one supplied public point; use fixture mode first".into());
    }
    let cfg = &job.config;
    if !(1..=256).contains(&cfg.rho_parallel_walks) { return Err("invalid rho width".into()); }
    if cfg.batch_trials == 0 || cfg.batch_trials > 4096 || cfg.max_trials > 65536
        || cfg.max_trials < cfg.batch_trials || !(2..=4).contains(&cfg.summands) {
        return Err("invalid collection limits".into());
    }
    ic_phase::begin();
    let start = Instant::now();
    let c = KoblitzCurve::new(job.curve_a, job.degree).ok_or("curve has no usable subgroup")?;
    let targets = match &job.public_targets {
        Some(encoded) => {
            if encoded.is_empty() || encoded.len() > 100 ||
                (!job.target_seeds.is_empty() && job.target_seeds.len() != encoded.len()) {
                return Err("invalid public-point/seed counts".into());
            }
            encoded.iter().map(|p| public_point(&c, p)).collect::<Result<Vec<_>, _>>()?
        }
        None => {
            if job.mode != "fixture" || job.target_seeds.is_empty() || job.target_seeds.len() > 100 {
                return Err("fixture mode requires 1..100 target seeds".into());
            }
            job.target_seeds.iter().map(|&s| target(&c, s)).collect::<Result<Vec<_>, _>>()?
        }
    };
    let target_seeds: Vec<Option<u64>> = if job.target_seeds.is_empty() {
        vec![None; targets.len()]
    } else { job.target_seeds.iter().copied().map(Some).collect() };
    let metadata = json!({
        "degree": c.n, "curve_a": c.a,
        "irreducible": c.curve.irreducible,
        "subgroup_order": c.subgroup_order.to_string(), "group_order": c.group_order.to_string(),
        "cofactor": c.cofactor.to_string(), "lambda": c.lambda.to_string(),
        "generator": point(c.generator()), "targets": targets.iter().map(point).collect::<Vec<_>>(),
        "target_seeds": target_seeds, "target_scalar_constructed": false
    });

    if job.mode == "fixture" {
        return Ok(Report::Tree(json!({"schema_version":1,"status":"fixture","fixture":metadata})));
    }
    if job.mode == "rho" {
        let mut rho_field_kernel = None;
        let mut answers = Vec::new();
        for (i, q) in targets.iter().enumerate() {
            let options = KoblitzSignedRhoOptions {
                seed: job.algorithm_seed ^ (i as u64).wrapping_mul(0x9e37_79b9_7f4a_7c15),
                max_iterations_per_restart: cfg.max_trials,
                parallel_walks: cfg.rho_parallel_walks,
                ..KoblitzSignedRhoOptions::default()
            };
            answers.push(koblitz_signed_frobenius_rho_with_preparation(&c, q, &options,
                &mut |fc| { rho_field_kernel = Some(fc.field.kernel_name());
                    ic_phase::begin_online(Phase::RhoSolve); },
                &mut |_| {}).ok_or("rho has no prepared packed backend")?);
        }
        mark(Phase::RecoveryCheck);
        let verified = answers.iter().zip(&targets).all(|(answer,q)| {
            answer.recovered_log.as_ref().is_some_and(|d| d < &c.subgroup_order && c.mul(c.generator(), d) == *q)
        });
        ic_phase::end_online();
        let solutions = answers.iter().enumerate().map(|(i,r)| json!({
            "index":i,"recovered":r.recovered_log.as_ref().map(ToString::to_string),
            "verified":r.verified,"iterations":r.iterations,"restarts":r.restarts_attempted,
            "walk_group_additions":r.charges.walk_group_additions,
            "effective_walks":r.parallel_walks
        })).collect::<Vec<_>>();
        let (phase_wall_ns, online_wall_ns) = ic_phase::wall_snapshot();
        return Ok(Report::Tree(json!({"schema_version":1,"mode":"rho","status":if verified{"complete"}else{"incomplete"},
            "fixture":metadata,"solutions":solutions,"automorphism_order":2*c.n,
            "elapsed_seconds":start.elapsed().as_secs_f64(),"phase_schema":3,
            "phase_wall_ns":phase_wall_ns,"online_wall_ns":online_wall_ns,"target_input":"supplied_public_point",
            "rho_reusable_setup_excluded":true,"field_kernel":rho_field_kernel,
            "source_manifest_sha256":koblitz_tiny_ic::source_snapshot(),
            "executed_method":{"reference":"signed_frobenius_rho","requested_walks":cfg.rho_parallel_walks}})));
    }
    if job.mode != "ic" && job.mode != "inventory" { return Err("unknown mode".into()); }
    if cfg.solver == "pair_table" && cfg.collection_window.is_none()
        && koblitz_tiny_ic::supports(&c, &job.factor_base, cfg.summands) {
        return run_tiny(job, &c, &targets, metadata, start);
    }
    Err("no instrumented optimized backend for this configuration".into())
}

/// Decimal text of a word, appended: two digits per division from a
/// table, and the ASCII bytes appended without a validation pass (the
/// same characters `u64::to_string` produces; a test compares them).
fn push_u64(out: &mut String, mut v: u64) {
    const DIGITS: &[u8; 200] = b"0001020304050607080910111213141516171819\
2021222324252627282930313233343536373839\
4041424344454647484950515253545556575859\
6061626364656667686970717273747576777879\
8081828384858687888990919293949596979899";
    let mut buf = [0u8; 20];
    let mut i = buf.len();
    while v >= 100 {
        let d = ((v % 100) as usize) * 2;
        v /= 100;
        i -= 2;
        buf[i] = DIGITS[d];
        buf[i + 1] = DIGITS[d + 1];
    }
    if v >= 10 {
        let d = (v as usize) * 2;
        i -= 2;
        buf[i] = DIGITS[d];
        buf[i + 1] = DIGITS[d + 1];
    } else {
        i -= 1;
        buf[i] = b'0' + v as u8;
    }
    // SAFETY: every byte written is an ASCII digit.
    unsafe { out.as_mut_vec().extend_from_slice(&buf[i..]) };
}

#[cfg(test)]
mod push_u64_tests {
    use super::push_u64;

    #[test]
    fn matches_std_formatting() {
        let mut seed = 0x9E37_79B9_7F4A_7C15u64;
        let mut values = vec![0u64, 1, 9, 10, 11, 99, 100, 101, 999, 1000, 12345, u32::MAX as u64, u64::MAX - 1, u64::MAX];
        for _ in 0..2000 {
            seed ^= seed << 13; seed ^= seed >> 7; seed ^= seed << 17;
            values.push(seed >> (seed % 64));
        }
        for v in values {
            let mut s = String::new();
            push_u64(&mut s, v);
            assert_eq!(s, v.to_string());
        }
    }
}

/// `["x","y"]`, the same text as `point` produces for a single-word point.
fn push_point(out: &mut String, (x, y): (u64, u64)) {
    out.push_str("[\"");
    push_u64(out, x);
    out.push_str("\",\"");
    push_u64(out, y);
    out.push_str("\"]");
}

/// The same job on the single-word pipeline: identical phase boundaries,
/// identical certificate content, identical general final verification.
/// The report is written directly rather than through a value tree; every
/// field and its JSON type match the general path.
fn run_tiny(job: &Job, c: &KoblitzCurve, targets: &[BinaryPoint], metadata: Value, start: Instant) -> Result<Report, String> {
    let cfg = &job.config;
    if cfg.linear_algebra != "tiny_gauss" { return Err("tiny backend executes tiny_gauss; choose it explicitly".into()); }
    let mut ic = TinyIc::new(c, &job.factor_base, job.algorithm_seed, cfg.max_trials)?;
    let expected_columns = ic.columns();
    if job.mode == "inventory" {
        return Ok(Report::Tree(json!({"schema_version":1,"mode":"inventory","status":"inventory",
            "fixture":metadata,"columns":expected_columns,"column_convention":"representative",
            "factor_base_orbits":ic.orbit_representatives().iter()
                .map(|&(x,y)|json!([x.to_string(),y.to_string()])).collect::<Vec<_>>(),
            "summands":3,"phase_schema":3,"target_input":"supplied_public_point","source_manifest_sha256":koblitz_tiny_ic::source_snapshot(),
            "field_kernel":ic.field_kernel()})));
    }

    let mut relations: Vec<crypto_lib::cryptanalysis::koblitz_index_calculus::CollectedRelation> = Vec::new();
    let mut solved = false;
    while ic.trials() < cfg.max_trials && !solved {
        let rows = ic.collect(cfg.batch_trials);

        ic.push(&rows);
        solved = ic.try_solve();
        mark(Phase::Setup);
        relations.extend(rows);

    }
    let (accepted, duplicates, solve_attempts) = ic.accounting();
    let trials = ic.trials();
    let (table_rows, table_rows_possible, table_entries, scan_block) = ic.table_shape();
    // The certificate names the base by its orbit representatives; the
    // checker expands them (oracle.py `factor_base_orbits`). Same base, same
    // relation indices, 2n times fewer points to format and to write.
    let reps = ic.orbit_representatives();
    let mut out = String::with_capacity(8 * 1024 + 24 * reps.len());
    let mut base = String::with_capacity(24 * reps.len());
    base.push('[');
    for (i, &p) in reps.iter().enumerate() {
        if i > 0 { base.push(','); }
        push_point(&mut base, p);
    }
    base.push(']');
    let mut rels = String::with_capacity(48 * relations.len());
    rels.push('[');
    for (i, rel) in relations.iter().enumerate() {
        if i > 0 { rels.push(','); }
        rels.push_str("{\"trial\":");
        push_u64(&mut rels, rel.trial);
        rels.push_str(",\"a\":");
        push_u64(&mut rels, rel.a);
        rels.push_str(",\"points\":[");
        for (k, &idx) in rel.points.iter().enumerate() {
            if k > 0 { rels.push(','); }
            push_u64(&mut rels, idx as u64);
        }
        rels.push_str("]}");
    }
    rels.push(']');
    let fixture = serde_json::to_string(&metadata).map_err(|e| e.to_string())?;
    if !solved {
        out.push_str("{\"schema_version\":1,\"mode\":\"ic\",\"status\":\"incomplete\",\"fixture\":");
        out.push_str(&fixture);
        out.push_str(",\"trials\":");
        push_u64(&mut out, trials);
        out.push_str(",\"columns\":");
        push_u64(&mut out, expected_columns as u64);
        out.push_str(",\"relations\":");
        out.push_str(&rels);
        out.push_str(",\"factor_base_orbits\":");
        out.push_str(&base);
        out.push_str(",\"column_convention\":\"representative\"");
        out.push_str(",\"rejected_relations\":0}");
        append_diagnostics(&mut out, &ic);
        return Ok(Report::Text(out, false));
    }
    if !ic.verify_columns() {
        return Err("invalid relation or factor-base log certificate".into());
    }
    mark(Phase::Setup);
    let mut columns = String::new();
    columns.push('[');
    for (i, &(p, l)) in ic.column_words().ok_or("missing logs")?.iter().enumerate() {
        if i > 0 { columns.push(','); }
        columns.push_str("{\"point\":");
        push_point(&mut columns, p);
        columns.push_str(",\"log\":\"");
        push_u64(&mut columns, l);
        columns.push_str("\"}");
    }
    columns.push(']');

    ic_phase::begin_online(Phase::TargetDescent);
    let mut answers = Vec::with_capacity(targets.len());
    for q in targets {
        answers.push(ic.solve_target(q));
    }
    mark(Phase::RecoveryCheck);
    let verified = answers.iter().zip(targets).all(|(s, q)| {
        s.as_ref().is_some_and(|(d, _, _)| d < &c.subgroup_order && c.mul(c.generator(), d) == *q)
    });
    ic_phase::end_online();
    out.push_str("{\"schema_version\":1,\"mode\":\"ic\",\"status\":\"");
    out.push_str(if verified { "complete" } else { "incomplete" });
    out.push_str("\",\"fixture\":");
    out.push_str(&fixture);
    out.push_str(",\"solutions\":[");
    for (i, answer) in answers.iter().enumerate() {
        if i > 0 { out.push(','); }
        out.push_str("{\"index\":");
        push_u64(&mut out, i as u64);
        match answer {
            Some((d, t, w)) => {
                out.push_str(",\"recovered\":\"");
                out.push_str(&d.to_string());
                out.push_str("\",\"trials\":");
                push_u64(&mut out, *t);
                // The index-calculus certificate: the relation the scalar came from.
                out.push_str(",\"relation\":{\"a\":");
                push_u64(&mut out, w.a);
                out.push_str(",\"b\":");
                push_u64(&mut out, w.b);
                out.push_str(",\"points\":[");
                for (k, &idx) in w.points.iter().enumerate() {
                    if k > 0 { out.push(','); }
                    push_u64(&mut out, idx as u64);
                }
                out.push_str("]}");
            }
            None => out.push_str(",\"recovered\":null,\"trials\":null,\"relation\":null"),
        }
        out.push('}');
    }
    out.push_str("],\"factor_base_orbits\":");
    out.push_str(&base);
    // A column is the orbit representative itself, not `[h]` of it; the
    // checker needs to know which convention the rows were built under.
    out.push_str(",\"column_convention\":\"representative\"");
    out.push_str(",\"relations\":");
    out.push_str(&rels);
    out.push_str(",\"column_logs\":");
    out.push_str(&columns);
    out.push_str(",\"columns\":");
    push_u64(&mut out, expected_columns as u64);
    out.push_str(",\"trials\":");
    push_u64(&mut out, trials);
    out.push_str(",\"solve_attempts\":");
    push_u64(&mut out, solve_attempts as u64);
    out.push_str(",\"accepted_relations\":");
    push_u64(&mut out, accepted as u64);
    out.push_str(",\"duplicate_relations\":");
    push_u64(&mut out, duplicates as u64);
    out.push_str(",\"rejected_relations\":0,\"summands\":");
    push_u64(&mut out, cfg.summands as u64);
    out.push_str(",\"sparse_report\":null,\"pair_table\":{\"rows\":");
    push_u64(&mut out, table_rows as u64);
    out.push_str(",\"rows_possible\":");
    push_u64(&mut out, table_rows_possible as u64);
    out.push_str(",\"sum_orbits\":");
    push_u64(&mut out, table_entries as u64);
    out.push_str(",\"scan_block\":");
    push_u64(&mut out, scan_block as u64);
    out.push_str("},\"elapsed_seconds\":");
    out.push_str(&format!("{}", start.elapsed().as_secs_f64()));
    out.push('}');
    append_diagnostics(&mut out, &ic);
    Ok(Report::Text(out, verified))
}


fn append_diagnostics(out: &mut String, ic: &TinyIc) {
    let (stats, rank) = ic.stage_diagnostics();
    let (phase_wall_ns, online_wall_ns) = ic_phase::wall_snapshot();
    let diagnostics = json!({
        "source_manifest_sha256":koblitz_tiny_ic::source_snapshot(),"field_kernel":ic.field_kernel(),
        "ordinary_queries":stats.ordinary_queries,"identity_queries":stats.identity_queries,
        "pdp_attempts":stats.ordinary_queries,
        "pdp_outcomes":{"verified":stats.pdp_verified,"unresolved":stats.pdp_unresolved,
            "proved_unsat":0,"timeout":0,"budget":0,"error":0,"lift_rejected":0},
        "rank_events":stats.rank_events,"final_rank":rank,
        "matrix_nonzeros":stats.matrix_nonzeros,
        "matrix_encoding":"u64-le-row-major-including-rhs",
        "phase_wall_ns":phase_wall_ns,"online_wall_ns":online_wall_ns,
        "target_input":"supplied_public_point"
    });
    assert_eq!(out.pop(), Some('}'));
    out.push_str(",\"phase_schema\":3,\"executed_method\":{\"pdp\":\"partial_folded_pair_table\",\"collection\":\"additive_walk\",\"relation_la\":\"incremental_gauss\",\"descent\":\"walked_pdp\",\"direct_collision\":false},\"diagnostics\":");
    out.push_str(&serde_json::to_string(&diagnostics).expect("diagnostics"));
    out.push('}');
}

/// The C entry point directly: without the std runtime's start-up the process
/// installs no signal handlers, allocates no alternate signal stack and does not
/// read `/proc/self/maps`, work that served no purpose for a job that reads one
/// JSON document and writes one. Shared by every arm, rho included.
#[cfg(not(test))]
#[no_mangle]
pub extern "C" fn main(_argc: i32, _argv: *const *const u8) -> i32 {
    if option_env!("IC_SOURCE_MANIFEST_SHA256") != koblitz_tiny_ic::source_snapshot() {
        eprintln!("worker/library source manifest mismatch");
        return 2;
    }
    let mut input = String::new();
    std::io::stdin().take(1_048_577).read_to_string(&mut input).expect("stdin");
    let result = if input.len() > 1_048_576 { Err("job too large".into()) } else {
        serde_json::from_str::<Job>(&input).map_err(|e|e.to_string()).and_then(|job| {
            run(&job)
        })
    };
    mark(Phase::Setup);
    let (mut text, success) = match result {
        Ok(Report::Text(text, success)) => (text.into_bytes(), success),
        Ok(Report::Tree(report)) => {
            let success = matches!(report["status"].as_str(),Some("complete"|"fixture"|"inventory"));
            (serde_json::to_vec(&report).expect("serialize report"), success)
        }
        Err(reason) => (serde_json::to_vec(&json!({"schema_version":1,"status":"error","reason":reason})).expect("serialize report"), false),
    };
    // One buffered write of the same bytes `println!("{}", report)` produced.
    text.push(b'\n');
    {
        use std::io::Write;
        let stdout = std::io::stdout();
        let mut lock = stdout.lock();
        lock.write_all(&text).expect("stdout");
        lock.flush().expect("stdout");
    }
    if success { 0 } else { 2 }
}

#[cfg(test)]
mod public_input_tests {
    use super::*;

    fn job(mode: &str, target: Option<Value>, seeds: Vec<u64>) -> Job {
        serde_json::from_value(json!({"mode":mode,"degree":13,"curve_a":0,
            "target_seeds":seeds,"public_targets":target,"algorithm_seed":2026092527u64,
            "factor_base":{"kind":"subgroup_orbits","seed":43,"points":78},
            "config":{"batch_trials":1,"max_trials":4096}})).unwrap()
    }

    fn value(report: Report) -> Value {
        match report { Report::Tree(v) => v, Report::Text(s, _) => serde_json::from_str(&s).unwrap() }
    }

    #[test]
    fn public_coordinates_are_canonical_and_subgroup_checked() {
        let c = KoblitzCurve::new(0, 13).unwrap();
        for encoded in [["00", "1"], ["+1", "1"], ["8192", "1"], ["0", "1"]] {
            assert!(public_point(&c, &encoded.map(String::from)).is_err());
        }
        let encoded: [String; 2] = serde_json::from_value(point(c.generator())).unwrap();
        assert_eq!(public_point(&c, &encoded).unwrap(), *c.generator());
    }

    #[test]
    fn measured_jobs_reject_generation_and_multiple_targets() {
        let c = KoblitzCurve::new(0, 13).unwrap();
        for mode in ["ic", "rho", "inventory"] {
            assert!(run(&job(mode, None, vec![43])).is_err());
            assert!(run(&job(mode, Some(json!([point(c.generator()), point(c.generator())])), vec![43,44])).is_err());
        }
        assert!(run(&job("fixture", None, vec![43])).is_ok());
    }

    #[test]
    fn both_algorithms_use_the_point_and_ignore_provenance_seeds() {
        let c = KoblitzCurve::new(0, 13).unwrap();
        // Planted only as a correctness control, never a yield/timing sample.
        let target = point(&c.mul(c.generator(), &BigUint::from(5u32)));
        for mode in ["ic", "rho"] {
            for seeds in [vec![], vec![111], vec![222]] {
                let report = value(run(&job(mode, Some(json!([target])), seeds)).ok().unwrap());
                assert_eq!(report["fixture"]["targets"][0], target);
                assert_eq!(report["solutions"][0]["recovered"], "5");
                assert_eq!(report["phase_schema"], 3);
                let timing = if mode == "ic" { &report["diagnostics"] } else { &report };
                assert_eq!(timing["target_input"], "supplied_public_point");
                let online: u64 = if mode == "ic" {
                    ["target_query", "target_pdp", "target_relation_check", "target_descent", "recovery_check"].iter()
                        .map(|name| timing["phase_wall_ns"][name].as_u64().unwrap()).sum()
                } else {
                    timing["phase_wall_ns"]["reference_solve"].as_u64().unwrap() +
                        timing["phase_wall_ns"]["recovery_check"].as_u64().unwrap()
                };
                assert_eq!(timing["online_wall_ns"].as_u64(), Some(online));
                assert!(online > 0);
                if mode == "rho" {
                    assert_eq!(report["rho_reusable_setup_excluded"], true);
                    assert!(matches!(report["field_kernel"].as_str(), Some("portable"|"pclmulqdq")));
                }
            }
        }
    }
}

#[test]
fn simultaneous_live_buffers_remain_intact() {
    std::thread::scope(|scope| {
        for thread in 0..4u8 {
            scope.spawn(move || {
                for iteration in 0..5000usize {
                    let byte=thread.wrapping_add(iteration as u8);
                    let mut data=vec![byte; 16+iteration%512];
                    let mut other=vec![byte ^ 0xff; 19+iteration%117];
                    data.reserve(70);
                    other.resize(200,byte ^ 0xff);
                    assert!(data.iter().all(|&v|v==byte));
                    assert!(other.iter().all(|&v|v==byte ^ 0xff));
                }
            });
        }
    });
}
