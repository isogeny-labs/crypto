use std::{env, path::PathBuf, process::Command};
fn run(cmd: &mut Command) {
    assert!(
        cmd.status().expect("native compiler unavailable").success(),
        "native build failed"
    );
}
fn main() {
    println!("cargo:rerun-if-env-changed=CUDA_HOME");
    println!("cargo:rerun-if-env-changed=IC_CUDA_ARCH");
    let cuda = env::var_os("CARGO_FEATURE_IC_CUDA").is_some();
    let rdma = env::var_os("CARGO_FEATURE_IC_RDMA").is_some();
    if !cuda && !rdma {
        return;
    }
    let out = PathBuf::from(env::var_os("OUT_DIR").unwrap());
    let mut objects = Vec::new();
    if cuda {
        let toolkit = PathBuf::from(env::var_os("CUDA_HOME").unwrap_or("/usr/local/cuda".into()));
        let obj = out.join("ic_f2_cuda.o");
        run(Command::new(toolkit.join("bin/nvcc"))
            .args(["-O3", "-std=c++17", "-Xcompiler", "-fPIC", "-arch"])
            .arg(env::var("IC_CUDA_ARCH").unwrap_or("sm_80".into()))
            .args(["-c", "gpu/koblitz_f2/reduce.cu", "-o"])
            .arg(&obj));
        objects.push(obj);
        println!(
            "cargo:rustc-link-search=native={}",
            toolkit.join("lib64").display()
        );
        println!("cargo:rustc-link-lib=dylib=cudart");
        println!("cargo:rerun-if-changed=gpu/koblitz_f2/reduce.cu");
    }
    if rdma {
        let obj = out.join("ic_f2_rdma.o");
        run(Command::new("c++")
            .args([
                "-O3",
                "-std=c++17",
                "-fPIC",
                "-c",
                "gpu/koblitz_f2/rdma.cpp",
                "-o",
            ])
            .arg(&obj));
        objects.push(obj);
        println!("cargo:rustc-link-lib=dylib=rdmacm");
        println!("cargo:rerun-if-changed=gpu/koblitz_f2/rdma.cpp");
    }
    run(Command::new("ar")
        .arg("crs")
        .arg(out.join("libic_f2.a"))
        .args(objects));
    println!("cargo:rustc-link-search=native={}", out.display());
    println!("cargo:rustc-link-lib=static=ic_f2");
    println!("cargo:rustc-link-lib=dylib=stdc++");
}
