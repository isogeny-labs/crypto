//! Complete, public-synthetic IC/rho jobs for the candidate tournament.
//! Uses the production research library; JSON stdin contains no known scalar.
use crypto_lib::binary_ecc::{BinaryPoint, F2mElement};
use crypto_lib::cryptanalysis::ic_measurement::{self as measurement, Phase};
use crypto_lib::cryptanalysis::koblitz_factor_base_search::FactorBaseSpec;
use crypto_lib::cryptanalysis::koblitz_fast::FastCurve;
use crypto_lib::cryptanalysis::koblitz_groebner::{FieldStructure, SolverEngine};
use crypto_lib::cryptanalysis::koblitz_index_calculus::{
    koblitz_signed_frobenius_rho_with_preparation, point_key, points_with_x, DecompositionStrategy,
    FactorBaseLogSolver, FactorBaseLogTable, FrobeniusFactorBase, IndividualLogSolver,
    KoblitzCurve, KoblitzIcOptions, KoblitzSignedRhoOptions, LinearAlgebra, PairSumTable,
    RelationCollector, RelationWorkUnit,
};
use crypto_lib::cryptanalysis::koblitz_sparse_la::SparseSolveOptions;
use crypto_lib::cryptanalysis::semaev_sat::XorEncoding;
use num_bigint::BigUint;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::io::Read;
use std::time::Instant;

/// The amd64 Valgrind client-request ABI, as specified in valgrind.h.
/// Outside Valgrind the rotation preamble and self-exchange have no effect.
/// DUMP_STATS_AT writes the interval then resets counters; collection stays on.
#[inline(never)]
fn dump(label: &'static [u8]) {
    if measurement::enabled() {
        return;
    }
    assert_eq!(label.last(), Some(&0));
    #[cfg(target_arch = "x86_64")]
    unsafe {
        let args = [0x4354_0003usize, label.as_ptr() as usize, 0, 0, 0, 0];
        std::arch::asm!(
            "rol rdi, 3", "rol rdi, 13", "rol rdi, 61", "rol rdi, 51",
            "xchg rbx, rbx",
            in("rax") args.as_ptr(), inout("rdx") 0usize => _, out("rdi") _,
            options(nostack)
        );
    }
}

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct Job {
    mode: String,
    degree: u32,
    curve_a: u8,
    #[serde(default)]
    target_seeds: Vec<u64>,
    #[serde(default)]
    public_targets: Option<Vec<[String; 2]>>,
    algorithm_seed: u64,
    factor_base: FactorBaseSpec,
    config: Config,
    /// Opt-in until independent generic scientific admission is complete.
    #[serde(default)]
    exclusive_phases: bool,
    /// Target-independent state supplied by the separately sealed preparation
    /// adapter. This bounded mode never samples ordinary relation queries.
    #[serde(default)]
    prepared: Option<PreparedTable>,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct PreparedTable {
    mathematical_state_sha256: String,
    factor_base: Vec<[String; 2]>,
    columns: Vec<PreparedColumn>,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct PreparedColumn {
    point: [String; 2],
    log: String,
}

const PREPARED_N17_STATE: &str = "edbff76da6442b9f2e5e8235682c9bf1052465f310c765ba8a37d018a60bf107";

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(default, deny_unknown_fields)]
struct Config {
    solver: String,
    linear_algebra: String,
    batch_trials: u64,
    max_trials: u64,
    summands: usize,
    collection_window: Option<usize>,
    sparse: SparseSolveOptions,
    factor_base_orbits: Option<usize>,
    factor_base_cube_root: bool,
    factor_base: Option<FactorBaseSpec>,
    groebner_degree: u32,
    node_budget: usize,
    conflict_budget: u64,
    rho_parallel_walks: usize,
}
impl Default for Config {
    fn default() -> Self {
        Self {
            solver: "pair_table".into(),
            linear_algebra: "sparse".into(),
            batch_trials: 64,
            max_trials: 4096,
            summands: 3,
            collection_window: None,
            sparse: SparseSolveOptions::default(),
            factor_base_orbits: None,
            factor_base_cube_root: false,
            factor_base: None,
            groebner_degree: 3,
            node_budget: 4096,
            conflict_budget: 100_000,
            rho_parallel_walks: 32,
        }
    }
}

fn point(p: &BinaryPoint) -> Value {
    match p {
        BinaryPoint::Infinity => Value::Null,
        BinaryPoint::Affine { x, y } => {
            json!([x.to_biguint().to_string(), y.to_biguint().to_string()])
        }
    }
}

// None means no valid-range scalar was available to replay; this is not a
// successful check and must not claim that scalar replay was performed.
fn scalar_replay(c: &KoblitzCurve, q: &BinaryPoint, log: Option<&BigUint>) -> Option<bool> {
    log.filter(|d| *d < &c.subgroup_order)
        .map(|d| c.mul(c.generator(), d) == *q)
}

// Strict public coordinates: do not silently reduce or repair supplied inputs.
fn public_point(c: &KoblitzCurve, encoded: &[String; 2]) -> Result<BinaryPoint, String> {
    let coordinate = |text: &str| -> Result<F2mElement, String> {
        if text.is_empty()
            || !text.bytes().all(|b| b.is_ascii_digit())
            || (text.len() > 1 && text.starts_with('0'))
        {
            return Err("noncanonical public coordinate".into());
        }
        let value = text
            .parse::<BigUint>()
            .map_err(|_| "invalid public coordinate")?;
        if value.bits() > u64::from(c.n) {
            return Err("public coordinate outside field".into());
        }
        Ok(F2mElement::from_biguint(&value, c.n))
    };
    let q = BinaryPoint::Affine {
        x: coordinate(&encoded[0])?,
        y: coordinate(&encoded[1])?,
    };
    if !c.curve.is_on_curve(&q) || c.mul(&q, &c.subgroup_order) != BinaryPoint::Infinity {
        return Err("public point is outside the declared subgroup".into());
    }
    Ok(q)
}

// Same public hash-to-curve domain as ic workflow. No target scalar is created.
fn target(c: &KoblitzCurve, seed: u64) -> Result<BinaryPoint, String> {
    for counter in 0u64..1_000_000 {
        let mut h = blake3::Hasher::new();
        h.update(b"ic-workflow-public-target-v1\0");
        h.update(&c.n.to_le_bytes());
        h.update(&[c.a]);
        h.update(&c.k.to_le_bytes());
        h.update(&c.b_index.to_le_bytes());
        h.update(&seed.to_le_bytes());
        h.update(&counter.to_le_bytes());
        let digest = h.finalize();
        let x =
            u64::from_le_bytes(digest.as_bytes()[..8].try_into().unwrap()) & ((1u64 << c.n) - 1);
        let x = F2mElement::from_biguint(&BigUint::from(x), c.n);
        let mut lifts = points_with_x(&c.curve, &x);
        lifts.sort_by_key(point_key);
        if lifts.is_empty() {
            continue;
        }
        let q = c.mul(
            &lifts[usize::from(digest.as_bytes()[8] & 1) % lifts.len()],
            &c.cofactor,
        );
        if q != BinaryPoint::Infinity {
            return Ok(q);
        }
    }
    Err("hash-to-curve exhausted".into())
}

fn run(job: &Job) -> Result<Value, String> {
    if job.prepared.is_some()
        && (job.mode != "ic"
            || !job.exclusive_phases
            || job.degree != 17
            || job.curve_a != 1
            || !matches!(job.config.solver.as_str(), "f4" | "f5" | "inherited_f4")
            || job.config.summands != 3
            || job.config.groebner_degree != 3
            || job.config.linear_algebra != "dense")
    {
        return Err("prepared mode is limited to exclusive n17a1 F4/F5 IC".into());
    }
    if !job.exclusive_phases {
        return run_inner(job);
    }
    if job.mode == "fixture" {
        return Err("exclusive measured phases require a supplied-point job".into());
    }
    for (name, value) in std::env::vars_os() {
        let name = name.to_string_lossy();
        let declared_default = (name == "IC_ARTIFACT_CACHE" && value == "off")
            || (name == "IC_F2_BACKEND" && value == "cpu");
        if name.starts_with("KIC_")
            || name.starts_with("F4_")
            || name.starts_with("SOLVER_")
            || (name.starts_with("IC_") && !declared_default)
        {
            return Err(format!("undeclared algorithm environment override: {name}"));
        }
    }
    if rayon::current_num_threads() != 1 {
        return Err("exclusive phases require one Rayon thread".into());
    }
    let session = measurement::Session::begin_strict()?;
    let mut report = run_inner(job)?;
    let snapshot = session.finish()?;
    // The independently defined phase endpoints are authoritative in this
    // opt-in schema. Preserve the former outer interval as a cross-check.
    report["outer_online_wall_ns"] = report["online_wall_ns"].take();
    report["online_wall_ns"] = json!(snapshot.online_wall_ns);
    report["online_timing_schema"] = json!(2);
    report["generic_phase_timing"] = json!(snapshot);
    report["generic_phase_policy"] = json!("exclusive-owner-thread-v1");
    report["generic_build"] = build_identity();
    report["generic_runtime_policy"] = json!("default-environment-one-rayon-v1");
    Ok(report)
}

fn build_identity() -> Value {
    json!({"schema_version":1,
        "source_manifest_sha256":option_env!("IC_GENERIC_SOURCE_MANIFEST_SHA256"),
        "build_sha256":option_env!("IC_GENERIC_BUILD_SHA256"),
        "target_arch":std::env::consts::ARCH,"target_os":std::env::consts::OS})
}

fn run_inner(job: &Job) -> Result<Value, String> {
    if !(5..=31).contains(&job.degree) || job.degree.is_multiple_of(2) || job.curve_a > 1 {
        return Err("worker accepts bounded odd-degree Koblitz fixtures (5..31)".into());
    }
    if job.mode != "fixture" && job.public_targets.as_ref().map(Vec::len) != Some(1) {
        return Err(
            "measured jobs require exactly one supplied public point; use fixture mode first"
                .into(),
        );
    }
    let cfg = &job.config;
    if !(1..=256).contains(&cfg.rho_parallel_walks)
        || !(2..=4).contains(&cfg.groebner_degree)
        || cfg.node_budget == 0
        || cfg.conflict_budget == 0
    {
        return Err("invalid solver or rho limits".into());
    }
    if cfg.batch_trials == 0
        || cfg.batch_trials > 4096
        || cfg.max_trials > 65536
        || cfg.max_trials < cfg.batch_trials
        || !(2..=4).contains(&cfg.summands)
    {
        return Err("invalid collection limits".into());
    }
    let start = Instant::now();
    let c = KoblitzCurve::new(job.curve_a, job.degree).ok_or("curve has no usable subgroup")?;
    let targets = match &job.public_targets {
        Some(encoded) => {
            if encoded.is_empty()
                || encoded.len() > 100
                || (!job.target_seeds.is_empty() && job.target_seeds.len() != encoded.len())
            {
                return Err("invalid public-point/seed counts".into());
            }
            encoded
                .iter()
                .map(|p| public_point(&c, p))
                .collect::<Result<Vec<_>, _>>()?
        }
        None => {
            if job.mode != "fixture" || job.target_seeds.is_empty() || job.target_seeds.len() > 100
            {
                return Err("fixture mode requires 1..100 target seeds".into());
            }
            job.target_seeds
                .iter()
                .map(|&s| target(&c, s))
                .collect::<Result<Vec<_>, _>>()?
        }
    };
    let target_seeds: Vec<Option<u64>> = if job.target_seeds.is_empty() {
        vec![None; targets.len()]
    } else {
        job.target_seeds.iter().copied().map(Some).collect()
    };
    let metadata = json!({
        "degree": c.n, "curve_a": c.a,
        "irreducible": {"degree": c.curve.irreducible.degree, "low_terms": c.curve.irreducible.low_terms},
        "subgroup_order": c.subgroup_order.to_string(), "group_order": c.group_order.to_string(),
        "cofactor": c.cofactor.to_string(), "lambda": c.lambda.to_string(),
        "generator": point(c.generator()), "targets": targets.iter().map(point).collect::<Vec<_>>(),
        "target_seeds": target_seeds, "target_scalar_constructed": false
    });
    dump(b"curve_and_targets\0");
    if job.mode == "fixture" {
        return Ok(json!({"schema_version":1,"status":"fixture","fixture":metadata}));
    }
    if job.mode == "reference_inventory" {
        if !job.exclusive_phases {
            return Err("reference inventory requires exclusive phase mode".into());
        }
        let fast =
            FastCurve::new(&c.curve).ok_or("no packed arithmetic for reference inventory")?;
        return Ok(json!({"schema_version":1,"mode":"rho","status":"inventory",
            "fixture":metadata,"effective_config":cfg,"generic_admission_schema":1,
            "field_kernel":fast.field.kernel_name(),
            "inventory_policy":"configuration-only-no-query-or-target-solve-v1",
            "online_wall_ns":null,"online_timing_schema":1,
            "target_input":"supplied_public_point","reusable_setup_excluded":true,
            "scalar_replay_included":false}));
    }
    if job.mode == "rho" {
        measurement::mark(Phase::Precompute);
        let q = &targets[0];
        let options = KoblitzSignedRhoOptions {
            seed: job.algorithm_seed,
            max_iterations_per_restart: cfg.max_trials,
            parallel_walks: cfg.rho_parallel_walks,
            ..Default::default()
        };
        let mut online_start = None;
        let mut field_kernel = None;
        let answer = koblitz_signed_frobenius_rho_with_preparation(
            &c,
            q,
            &options,
            &mut |fc| {
                field_kernel = Some(fc.field.kernel_name());
                measurement::begin_online(Phase::RhoSolve);
                online_start = Some(Instant::now());
            },
            &mut |_| {},
        )
        .ok_or("rho has no prepared packed backend")?;
        dump(b"rho_solve\0");
        measurement::mark(Phase::RecoveryCheck);
        let replay = scalar_replay(&c, q, answer.recovered_log.as_ref());
        let verified = replay == Some(true);
        let online_ns = online_start
            .expect("prepared rho boundary")
            .elapsed()
            .as_nanos();
        measurement::end_online();
        dump(b"final_verification\0");
        let solutions = vec![
            json!({"index":0,"recovered":answer.recovered_log.as_ref().map(ToString::to_string),
            "verified":answer.verified,"iterations":answer.iterations,"restarts":answer.restarts_attempted,
            "walk_group_additions":answer.charges.walk_group_additions,"effective_walks":answer.parallel_walks}),
        ];
        return Ok(
            json!({"schema_version":1,"mode":"rho","status":if verified {"complete"} else {"incomplete"},
            "fixture":metadata,"solutions":solutions,"automorphism_order":2*c.n,
            "generic_admission_schema":if job.exclusive_phases {Some(1)} else {None},
            "effective_config":cfg,
            "rho_dispatch":{"algorithm":"signed-frobenius-batched-affine",
                "jump_count":options.jump_count,"max_restarts":options.max_restarts,
                "max_iterations_per_restart":options.max_iterations_per_restart,
                "progress_interval":options.progress_interval,
                "requested_walks":options.parallel_walks,"seed":options.seed,
                "field_kernel":field_kernel},
            "elapsed_seconds":start.elapsed().as_secs_f64(),"online_timing_schema":1,
            "online_wall_ns":online_ns,"target_input":"supplied_public_point",
            "reusable_setup_excluded":true,"scalar_replay_included":replay.is_some(),"field_kernel":field_kernel}),
        );
    }
    if job.mode != "ic" && job.mode != "inventory" {
        return Err("unknown mode".into());
    }
    let strategy = match cfg.solver.as_str() {
        "pair_table" => DecompositionStrategy::PairTable,
        "enumerate" => DecompositionStrategy::Enumerate,
        "f4" | "f5" | "inherited_f4" => DecompositionStrategy::Groebner,
        "sat_xor" | "sat_cnf" => DecompositionStrategy::Sat,
        _ => return Err("unsupported decomposition backend".into()),
    };
    let la = match cfg.linear_algebra.as_str() {
        "dense" => LinearAlgebra::Dense,
        "sparse" => LinearAlgebra::Sparse(cfg.sparse),
        _ => return Err("unknown linear algebra mode".into()),
    };
    let mut opts = KoblitzIcOptions {
        m: cfg.summands,
        seed: job.algorithm_seed,
        max_trials: cfg.max_trials as usize,
        strategy,
        linear_algebra: la,
        node_budget: cfg.node_budget,
        collection_window: cfg.collection_window,
        allow_direct_relation: false,
        ..KoblitzIcOptions::default()
    };
    opts.engine = match cfg.solver.as_str() {
        "f5" => SolverEngine::MatrixF5 {
            max_degree: cfg.groebner_degree,
        },
        "inherited_f4" => SolverEngine::InheritedF4 {
            max_degree: cfg.groebner_degree,
        },
        _ => SolverEngine::MatrixF4 {
            max_degree: cfg.groebner_degree,
        },
    };
    opts.sat_options.conflict_budget = cfg.conflict_budget;
    opts.sat_options.encoding = if cfg.solver == "sat_cnf" {
        XorEncoding::Cnf
    } else {
        XorEncoding::Native
    };
    if cfg
        .factor_base_orbits
        .is_some_and(|n| !(1..=8).contains(&n))
        || (cfg.factor_base_orbits.is_some() && cfg.factor_base_cube_root)
        || (cfg.factor_base.is_some()
            && (cfg.factor_base_orbits.is_some() || cfg.factor_base_cube_root))
    {
        return Err("invalid factor-base policy".into());
    }
    let effective_base = if cfg.factor_base_orbits.is_some() || cfg.factor_base_cube_root {
        let FactorBaseSpec::SubgroupOrbits { seed, .. } = &job.factor_base else {
            return Err("orbit policy requires a subgroup-orbit base recipe".into());
        };
        let points = if let Some(orbits) = cfg.factor_base_orbits {
            2 * c.n as usize * orbits
        } else {
            let r = c.subgroup_order.to_u64_digits()[0];
            let mut b = 1u64;
            while b * b * b < r / 2 {
                b += 1;
            }
            (b as usize).max(2 * c.n as usize)
        };
        FactorBaseSpec::SubgroupOrbits {
            seed: *seed,
            points,
        }
    } else {
        cfg.factor_base
            .clone()
            .unwrap_or_else(|| job.factor_base.clone())
    };
    measurement::mark(Phase::FactorBase);
    let fb = effective_base.materialize(&c)?;
    measurement::mark(Phase::Precompute);
    if job.mode == "inventory" {
        if !job.exclusive_phases {
            return Err("generic inventory requires exclusive phase mode".into());
        }
        let system = FactorBaseLogSolver::new(&c, &fb, &opts).ok_or("no projected columns")?;
        let fast = FastCurve::new(&c.curve).ok_or("no packed arithmetic for IC inventory")?;
        return Ok(json!({"schema_version":1,"mode":"ic","status":"inventory",
            "fixture":metadata,"columns":system.columns(),
            "factor_base":fb.points.iter().map(point).collect::<Vec<_>>(),
            "effective_factor_base":effective_base,"effective_config":cfg,
            "generic_admission_schema":1,"relation_matrix":system.matrix_snapshot(),
            "field_kernel":fast.field.kernel_name(),
            "inventory_policy":"configuration-only-no-query-or-target-solve-v1",
            "online_wall_ns":null,"online_timing_schema":1,
            "target_input":"supplied_public_point","reusable_setup_excluded":true,
            "scalar_replay_included":false}));
    }
    let pair = if strategy == DecompositionStrategy::PairTable {
        Some(PairSumTable::build(&c, &fb).ok_or("pair table unavailable")?)
    } else {
        None
    };
    if let Some(prepared) = &job.prepared {
        return run_prepared_target(job, prepared, &c, &fb, &opts, &targets[0], metadata, start);
    }
    let collector = RelationCollector::with_pair_table(&c, &fb, &opts, pair.as_ref())
        .ok_or("unsupported decomposition")?;
    let mut system = FactorBaseLogSolver::new(&c, &fb, &opts).ok_or("no projected columns")?;
    let expected_columns = system.columns();
    dump(b"factor_base_and_tables\0");
    measurement::mark(Phase::Setup);
    let mut relations = Vec::new();
    let mut trials = 0;
    let mut collection_reports = Vec::new();
    let mut outcome = None;
    let collector_dispatch = job.exclusive_phases.then(|| collector.admission_dispatch());
    let mut matrix_batches = Vec::new();
    while trials < cfg.max_trials && outcome.is_none() {
        let count = cfg.batch_trials.min(cfg.max_trials - trials);
        let (rows, collection_report) = collector.collect_observed(RelationWorkUnit {
            seed: job.algorithm_seed,
            start: trials,
            count,
        });
        trials += count;
        dump(b"collection_and_decomposition\0");
        system.push(&rows);
        collection_reports.push(collection_report);
        outcome = system.try_solve();
        relations.extend(rows);
        if job.exclusive_phases {
            let observed = system.report();
            matrix_batches.push(json!({"queries":trials,"accepted_rows":observed.relations,
                "duplicate_relations":observed.duplicate_relations,
                "rejected_relations":observed.rejected_relations,
                "solve_attempts":observed.solve_attempts,"verified":observed.verified,
                "sparse_report":observed.sparse_report}));
        }
        dump(b"verify_filter_and_linear_algebra\0");
    }
    let base = fb.points.iter().map(point).collect::<Vec<_>>();
    let mut report = system.report();
    report.trials = trials as usize;
    let matrix = job.exclusive_phases.then(|| system.matrix_snapshot());
    let Some((table, mut solved)) = outcome else {
        return Ok(
            json!({"schema_version":1,"mode":"ic","status":"incomplete","fixture":metadata,
            "trials":trials,"columns":expected_columns,"relations":relations,
            "factor_base":base,"rejected_relations":report.rejected_relations,
            "query_schema_version":1,"collection_reports":collection_reports,
            "log_table_report":report,"solve_attempts":report.solve_attempts,
            "effective_factor_base":effective_base,"summands":cfg.summands,
            "generic_admission_schema":if job.exclusive_phases {Some(1)} else {None},
            "effective_config":cfg,"collector_dispatch":collector_dispatch,
            "descent_dispatch":null,"matrix_batches":matrix_batches,"relation_matrix":matrix,
            "online_timing_schema":1,"online_wall_ns":null,"target_input":"supplied_public_point",
            "reusable_setup_excluded":true,"scalar_replay_included":false}),
        );
    };
    solved.trials = trials as usize;
    measurement::mark(Phase::RelationCheck);
    if solved.rejected_relations != 0 || !table.verify(&c) {
        return Ok(
            json!({"schema_version":1,"mode":"ic","status":"invalid_certificate",
            "fixture":metadata,"factor_base":base,"relations":relations,"trials":trials,
            "query_schema_version":1,"collection_reports":collection_reports,
            "log_table_report":solved,"reason":"invalid relation or factor-base log certificate"}),
        );
    }
    measurement::mark(Phase::Setup);
    let columns = table
        .columns
        .iter()
        .map(|(p, l)| json!({"point":point(p),"log":l.to_string()}))
        .collect::<Vec<_>>();
    dump(b"log_certification\0");
    measurement::mark(Phase::Precompute);
    let solver = IndividualLogSolver::new(&c, &fb, &table, &opts, pair.as_ref())
        .ok_or("descent setup failed")?;
    let descent_dispatch = job.exclusive_phases.then(|| solver.admission_dispatch());
    measurement::begin_online(Phase::TargetQuery);
    let online_start = Instant::now();
    let q = &targets[0];
    let answer = solver.solve_observed(q);
    dump(b"individual_log\0");
    measurement::mark(Phase::RecoveryCheck);
    let replay = scalar_replay(&c, q, answer.log.as_ref());
    let verified = replay == Some(true);
    let online_ns = online_start.elapsed().as_nanos();
    measurement::end_online();
    dump(b"final_verification\0");
    let solutions = vec![
        json!({"index":0,"recovered":answer.log.as_ref().map(ToString::to_string),
        "trials":answer.trials,"relation":answer.relation,"attempts":answer.attempts}),
    ];
    Ok(
        json!({"schema_version":1,"mode":"ic","status":if verified{"complete"}else{"incomplete"},
        "fixture":metadata,"solutions":solutions,"factor_base":base,"relations":relations,
        "generic_admission_schema":if job.exclusive_phases {Some(1)} else {None},
        "effective_config":cfg,"collector_dispatch":collector_dispatch,
        "descent_dispatch":descent_dispatch,"matrix_batches":matrix_batches,"relation_matrix":matrix,
        "column_logs":columns,"columns":expected_columns,"trials":trials,"solve_attempts":solved.solve_attempts,
        "query_schema_version":1,"collection_reports":collection_reports,"log_table_report":solved,
        "online_timing_schema":1,"online_wall_ns":online_ns,"target_input":"supplied_public_point",
        "reusable_setup_excluded":true,"scalar_replay_included":replay.is_some(),
        "accepted_relations":solved.relations,"duplicate_relations":solved.duplicate_relations,
        "rejected_relations":solved.rejected_relations,"summands":cfg.summands,
        "effective_factor_base":effective_base,
        "sparse_report":solved.sparse_report,"elapsed_seconds":start.elapsed().as_secs_f64()}),
    )
}

/// Import and verify all reusable data before the first target-dependent
/// computation. The Python adapter independently reconstructs the ordinary
/// relation matrix and binds the external certificate; this native check
/// additionally verifies exact geometry, column coverage and each scalar log.
fn run_prepared_target(
    job: &Job,
    prepared: &PreparedTable,
    c: &KoblitzCurve,
    fb: &FrobeniusFactorBase,
    opts: &KoblitzIcOptions,
    q: &BinaryPoint,
    metadata: Value,
    start: Instant,
) -> Result<Value, String> {
    let geometry = prepared
        .factor_base
        .iter()
        .map(|p| json!(p))
        .collect::<Vec<_>>();
    if prepared.mathematical_state_sha256 != PREPARED_N17_STATE
        || geometry != fb.points.iter().map(point).collect::<Vec<_>>()
        || fb.points.len() != 63
        || prepared.columns.len() != 29
    {
        return Err("prepared mathematical state or ordered geometry differs".into());
    }
    measurement::mark(Phase::RelationCheck);
    let expected_columns = FactorBaseLogSolver::new(c, fb, opts)
        .ok_or("prepared projected base has no columns")?
        .matrix_snapshot()
        .column_points;
    let supplied_columns = prepared
        .columns
        .iter()
        .map(|item| (item.point[0].clone(), item.point[1].clone()))
        .collect::<Vec<_>>();
    if expected_columns != supplied_columns {
        return Err("prepared column coverage or order differs from projected base".into());
    }
    let columns = prepared
        .columns
        .iter()
        .map(|item| {
            if item.log.is_empty()
                || !item.log.bytes().all(|b| b.is_ascii_digit())
                || (item.log.len() > 1 && item.log.starts_with('0'))
            {
                return Err("noncanonical prepared scalar log".into());
            }
            Ok((
                public_point(c, &item.point)?,
                item.log
                    .parse::<BigUint>()
                    .map_err(|_| "invalid prepared scalar log")?,
            ))
        })
        .collect::<Result<Vec<_>, String>>()?;
    let table = FactorBaseLogTable { columns };
    if !table.verify(c) {
        return Err("prepared column logarithm fails scalar replay".into());
    }
    measurement::mark(Phase::Precompute);
    // Initialize the reusable coefficient template without reading Q or
    // solving a query. Zero is a fixed symbolic specialization, not a group
    // target; actual query specialization and Macaulay work stay online.
    let field = FieldStructure::new(c.n, &c.curve.irreducible);
    crypto_lib::cryptanalysis::polynomial_reuse::build_decomposition_system_reusing(
        &fb.subspace_basis,
        &F2mElement::zero(c.n),
        &c.curve.b,
        opts.m,
        &field,
    )
    .ok_or("prepared target-independent Semaev template is unsupported")?;
    let solver = IndividualLogSolver::new(c, fb, &table, opts, None)
        .ok_or("prepared column coverage differs from the projected base")?;
    let dispatch = solver.admission_dispatch();
    measurement::begin_online(Phase::TargetQuery);
    let online_start = Instant::now();
    let answer = solver.solve_observed(q);
    measurement::mark(Phase::RecoveryCheck);
    let replay = scalar_replay(c, q, answer.log.as_ref());
    let online_ns = online_start.elapsed().as_nanos();
    measurement::end_online();
    let verified = replay == Some(true);
    Ok(
        json!({"schema_version":1,"query_schema_version":1,"mode":"ic",
        "status":if verified {"complete"} else {"incomplete"},
        "preparation_mode":"imported-certified-log-table-v1",
        "reusable_symbolic_template_prepared":true,
        "preparation_mathematical_state_sha256":prepared.mathematical_state_sha256,
        "fixture":metadata,"factor_base":fb.points.iter().map(point).collect::<Vec<_>>(),
        "column_logs":table.columns.iter().map(|(p,l)| json!({"point":point(p),"log":l.to_string()})).collect::<Vec<_>>(),
        "columns":table.len(),"trials":0,"relations":[],"collection_reports":[],
        "solve_attempts":0,"effective_config":job.config,"summands":job.config.summands,
        "effective_factor_base":job.factor_base,"descent_dispatch":dispatch,
        "solutions":[{"index":0,"recovered":answer.log.as_ref().map(ToString::to_string),
            "trials":answer.trials,"relation":answer.relation,"attempts":answer.attempts}],
        "online_timing_schema":1,"online_wall_ns":online_ns,
        "target_input":"supplied_public_point","reusable_setup_excluded":true,
        "scalar_replay_included":replay.is_some(),"scalar_verified":verified,
        "elapsed_seconds":start.elapsed().as_secs_f64()}),
    )
}

fn main() {
    let arguments: Vec<_> = std::env::args().skip(1).collect();
    if arguments == ["--build-identity"] {
        println!("{}", build_identity());
        return;
    }
    if !arguments.is_empty() {
        eprintln!("expected no arguments, or --build-identity");
        std::process::exit(2);
    }
    let mut input = String::new();
    std::io::stdin()
        .take(1_048_577)
        .read_to_string(&mut input)
        .expect("stdin");
    let result = if input.len() > 1_048_576 {
        Err("job too large".into())
    } else {
        serde_json::from_str::<Job>(&input)
            .map_err(|e| e.to_string())
            .and_then(|job| {
                if !job.exclusive_phases {
                    dump(b"startup_and_input\0");
                }
                run(&job)
            })
    };
    let report = result
        .unwrap_or_else(|reason| json!({"schema_version":1,"status":"error","reason":reason}));
    let success = matches!(
        report["status"].as_str(),
        Some("complete" | "fixture" | "inventory")
    );
    println!("{}", report);
    if !success {
        std::process::exit(2);
    }
}

#[cfg(test)]
mod prepared_target_tests {
    use super::*;

    fn prepared_job(cap: u64) -> Job {
        // Shared mathematical fixture only. Historical preparation receipts,
        // ordinary query streams and measurements remain invocation evidence.
        let prepared: Value = serde_json::from_str(include_str!(
            "../research/ic_candidate_tournament_20260915/goal_20260924/prepared-f5-runtime-v1/mathematics.json"
        )).unwrap();
        serde_json::from_value(json!({"mode":"ic","degree":17,"curve_a":1,
            "public_targets":[["52411","72106"]],"target_seeds":[],
            "algorithm_seed":2026093032_u64,"exclusive_phases":true,
            "factor_base":{"kind":"standard_subspace","dimension":6},
            "config":{"solver":"f5","linear_algebra":"dense","summands":3,
                "groebner_degree":3,"node_budget":8192,"batch_trials":1,"max_trials":cap},
            "prepared":prepared}))
        .unwrap()
    }

    #[test]
    #[ignore = "requires RAYON_NUM_THREADS=1 and an isolated test process; explicitly run in CI"]
    fn prepared_f5_recovers_disclosed_target_without_ordinary_collection() {
        let report = run(&prepared_job(8)).unwrap();
        assert_eq!(report["query_schema_version"], 1);
        assert_eq!(report["status"], "complete");
        assert_eq!(report["solutions"][0]["recovered"], "24886");
        assert_eq!(report["solutions"][0]["trials"], 3);
        assert_eq!(report["trials"], 0);
        assert_eq!(report["collection_reports"], json!([]));
        assert_eq!(report["relations"], json!([]));
        assert_eq!(report["solve_attempts"], 0);
        assert_eq!(report["scalar_verified"], true);
        assert_eq!(report["reusable_symbolic_template_prepared"], true);
        assert_eq!(report["column_logs"].as_array().unwrap().len(), 29);
        let phases = report["generic_phase_timing"]["online_phases_ns"]
            .as_object()
            .unwrap();
        assert!(phases["rho_solve"].is_null());
        let sum: u64 = phases
            .iter()
            .filter(|(k, _)| k.as_str() != "rho_solve")
            .map(|(_, v)| v.as_u64().unwrap())
            .sum();
        assert_eq!(Some(sum), report["online_wall_ns"].as_u64());
    }

    #[test]
    #[ignore = "requires RAYON_NUM_THREADS=1 and an isolated test process; explicitly run in CI"]
    fn prepared_failed_attempt_is_retained_without_a_scalar() {
        let report = run(&prepared_job(1)).unwrap();
        assert_eq!(report["query_schema_version"], 1);
        assert_eq!(report["status"], "incomplete");
        assert!(report["solutions"][0]["recovered"].is_null());
        assert_eq!(report["solutions"][0]["trials"], 1);
        assert_eq!(
            report["solutions"][0]["attempts"].as_array().unwrap().len(),
            1
        );
        assert_eq!(report["scalar_verified"], false);
        assert_eq!(report["trials"], 0);
        assert!(report["online_wall_ns"].as_u64().unwrap() > 0);
    }

    #[test]
    #[ignore = "requires RAYON_NUM_THREADS=1 and an isolated test process; explicitly run in CI"]
    fn corrupt_or_incomplete_preparation_is_rejected_before_target_work() {
        let mut job = prepared_job(1);
        job.prepared.as_mut().unwrap().columns[0].log = "0".into();
        assert!(run(&job).unwrap_err().contains("scalar replay"));
        let mut job = prepared_job(1);
        job.prepared.as_mut().unwrap().columns.pop();
        assert!(run(&job).unwrap_err().contains("geometry differs"));
        let mut job = prepared_job(1);
        job.prepared.as_mut().unwrap().factor_base.swap(0, 1);
        assert!(run(&job).unwrap_err().contains("geometry differs"));
        let mut job = prepared_job(1);
        let prepared = job.prepared.as_mut().unwrap();
        prepared.columns[0] = prepared.columns[1].clone();
        assert!(run(&job).unwrap_err().contains("column coverage"));
        let mut job = prepared_job(1);
        job.prepared.as_mut().unwrap().columns.swap(0, 1);
        assert!(run(&job).unwrap_err().contains("column coverage"));
        let mut job = prepared_job(1);
        job.prepared.as_mut().unwrap().columns[0].log = "063339".into();
        assert!(run(&job).unwrap_err().contains("noncanonical"));
    }

    #[test]
    #[ignore = "requires RAYON_NUM_THREADS=1 and an isolated test process; explicitly run in CI"]
    fn prepared_mode_rejects_other_curves_stages_and_fixture_generation() {
        for field in ["mode", "degree", "solver", "summands", "exclusive_phases"] {
            let mut job = prepared_job(1);
            match field {
                "mode" => job.mode = "fixture".into(),
                "degree" => job.degree = 19,
                "solver" => job.config.solver = "pair_table".into(),
                "summands" => job.config.summands = 2,
                _ => job.exclusive_phases = false,
            }
            assert!(run(&job).unwrap_err().contains("prepared mode is limited"));
        }
    }
}

#[cfg(test)]
mod public_input_tests {
    use super::*;

    fn job(mode: &str) -> Job {
        serde_json::from_value(json!({"mode":mode,"degree":9,"curve_a":0,
            "target_seeds":[2026092555],"algorithm_seed":2026092555,
            "factor_base":{"kind":"factor","index":0},
            "config":{"solver":"pair_table","linear_algebra":"dense","summands":2,
                "batch_trials":8,"max_trials":256}}))
        .unwrap()
    }

    fn supplied(mode: &str) -> Job {
        let fixture = run(&job("fixture")).unwrap();
        let mut measured = job(mode);
        measured.public_targets =
            Some(serde_json::from_value(fixture["fixture"]["targets"].clone()).unwrap());
        measured
    }

    #[test]
    fn public_input_rejects_seed_only_batch_and_noncanonical_points() {
        for mode in ["ic", "rho"] {
            assert!(run(&job(mode))
                .unwrap_err()
                .contains("exactly one supplied"));
            let original = supplied(mode);
            let mut batch = original.clone();
            let point = batch.public_targets.as_ref().unwrap()[0].clone();
            batch.public_targets.as_mut().unwrap().push(point);
            assert!(run(&batch).unwrap_err().contains("exactly one supplied"));
            for bad in ["", "00", "01", "+1", "-1", " 1", "512"] {
                let mut changed = original.clone();
                changed.public_targets.as_mut().unwrap()[0][0] = bad.into();
                assert!(run(&changed).is_err(), "accepted {bad:?}");
            }
            let mut changed = original.clone();
            changed.public_targets = Some(vec![["0".into(), "0".into()]]); // off curve
            assert!(run(&changed)
                .unwrap_err()
                .contains("outside the declared subgroup"));
            changed.public_targets = Some(vec![["0".into(), "1".into()]]); // order-two point
            assert!(run(&changed)
                .unwrap_err()
                .contains("outside the declared subgroup"));
        }
    }

    #[test]
    fn public_input_seeds_are_provenance_and_online_interval_includes_replay() {
        for mode in ["ic", "rho"] {
            let original = supplied(mode);
            let first = run(&original).unwrap();
            assert_eq!(first["status"], "complete");
            let online = first["online_wall_ns"].as_u64().unwrap();
            assert!(online > 0);
            assert!(online as f64 <= first["elapsed_seconds"].as_f64().unwrap() * 1e9);
            assert_eq!(first["target_input"], "supplied_public_point");
            assert_eq!(first["reusable_setup_excluded"], true);
            assert_eq!(first["scalar_replay_included"], true);
            if mode == "rho" {
                assert!(matches!(
                    first["field_kernel"].as_str(),
                    Some("portable" | "pclmulqdq" | "pmull")
                ));
            }
            for seeds in [Vec::new(), vec![1]] {
                let mut changed = original.clone();
                changed.target_seeds = seeds;
                let after = run(&changed).unwrap();
                assert_eq!(after["fixture"]["targets"], first["fixture"]["targets"]);
                assert_eq!(after["solutions"], first["solutions"]);
            }
        }
    }

    #[test]
    fn public_input_absent_or_out_of_range_scalar_does_not_claim_replay() {
        let c = KoblitzCurve::new(0, 9).unwrap();
        let q = c.generator();
        assert_eq!(scalar_replay(&c, q, None), None);
        assert_eq!(scalar_replay(&c, q, Some(&c.subgroup_order)), None);
        assert_eq!(scalar_replay(&c, q, Some(&BigUint::from(1u32))), Some(true));
        assert_eq!(
            scalar_replay(&c, q, Some(&BigUint::from(2u32))),
            Some(false)
        );
    }

    #[test]
    fn public_input_failed_preparation_has_no_online_interval() {
        let mut job = supplied("ic");
        job.config.max_trials = 1;
        job.config.batch_trials = 1;
        let report = run(&job).unwrap();
        assert_eq!(report["status"], "incomplete");
        assert_eq!(report["trials"], 1);
        assert!(report["online_wall_ns"].is_null());
        assert_eq!(report["scalar_replay_included"], false);
        assert_eq!(
            report["collection_reports"][0]["attempts"]
                .as_array()
                .unwrap()
                .len(),
            1
        );
    }

    fn assert_phase_closure(report: &Value) {
        assert_eq!(report["online_timing_schema"], 2);
        let snapshot = &report["generic_phase_timing"];
        let sum = |map: &Value| {
            map.as_object()
                .unwrap()
                .values()
                .filter_map(Value::as_u64)
                .sum::<u64>()
        };
        assert_eq!(
            sum(&snapshot["phases_ns"]),
            snapshot["observed_wall_ns"].as_u64().unwrap()
        );
        assert_eq!(report["online_wall_ns"], snapshot["online_wall_ns"]);
        if let Some(online) = snapshot["online_wall_ns"].as_u64() {
            assert_eq!(sum(&snapshot["online_phases_ns"]), online);
            assert!(online > 0 && online < snapshot["observed_wall_ns"].as_u64().unwrap());
        } else {
            assert!(snapshot["online_phases_ns"]
                .as_object()
                .unwrap()
                .values()
                .all(Value::is_null));
        }
        assert!(!measurement::enabled());
    }

    #[test]
    #[ignore = "requires RAYON_NUM_THREADS=1 and an isolated test process; explicitly run in CI"]
    fn exclusive_worker_inventory_freezes_kernel_without_target_work() {
        for mode in ["inventory", "reference_inventory"] {
            let mut job = supplied(mode);
            job.exclusive_phases = true;
            let report = run(&job).unwrap();
            assert_eq!(report["status"], "inventory");
            assert_eq!(
                report["inventory_policy"],
                "configuration-only-no-query-or-target-solve-v1"
            );
            assert!(matches!(
                report["field_kernel"].as_str(),
                Some("portable" | "pclmulqdq" | "pmull")
            ));
            assert!(report.get("solutions").is_none());
            assert!(report.get("collection_reports").is_none());
            assert_phase_closure(&report);
            assert!(report["online_wall_ns"].is_null());
            assert_eq!(report["scalar_replay_included"], false);
        }
    }

    #[test]
    #[ignore = "requires RAYON_NUM_THREADS=1 and an isolated test process; explicitly run in CI"]
    fn exclusive_worker_preserves_all_backend_queries_and_certificates() {
        for backend in [
            "pair_table",
            "enumerate",
            "f4",
            "f5",
            "inherited_f4",
            "sat_xor",
            "sat_cnf",
        ] {
            for la in ["dense", "sparse"] {
                let mut job = supplied("ic");
                job.config.solver = backend.into();
                job.config.linear_algebra = la.into();
                let original = run(&job).unwrap();
                job.exclusive_phases = true;
                let traced = run(&job).unwrap();
                assert_eq!(traced["status"], "complete", "{backend}/{la}");
                for key in [
                    "fixture",
                    "factor_base",
                    "relations",
                    "solutions",
                    "column_logs",
                    "columns",
                    "trials",
                    "solve_attempts",
                    "accepted_relations",
                    "duplicate_relations",
                ] {
                    assert_eq!(traced[key], original[key], "{backend}/{la}/{key}");
                }
                for (a, b) in traced["collection_reports"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .zip(original["collection_reports"].as_array().unwrap())
                {
                    assert_eq!(a["attempts"], b["attempts"]);
                }
                for phase in [
                    "setup",
                    "factor_base",
                    "precompute",
                    "queries",
                    "pdp",
                    "relation_check",
                    "matrix_build",
                    "relation_la",
                    "target_query",
                    "target_pdp",
                    "target_relation_check",
                    "target_descent",
                    "recovery_check",
                ] {
                    assert!(
                        traced["generic_phase_timing"]["phases_ns"][phase]
                            .as_u64()
                            .is_some(),
                        "missing {backend}/{la}/{phase}"
                    );
                }
                assert_phase_closure(&traced);
            }
        }
        let mut job = supplied("rho");
        let original = run(&job).unwrap();
        job.exclusive_phases = true;
        let traced = run(&job).unwrap();
        assert_eq!(traced["solutions"], original["solutions"]);
        assert!(traced["generic_phase_timing"]["phases_ns"]["rho_solve"]
            .as_u64()
            .is_some());
        assert!(traced["generic_phase_timing"]["phases_ns"]["relation_la"].is_null());
        assert_phase_closure(&traced);
    }

    #[test]
    #[ignore = "requires RAYON_NUM_THREADS=1 and an isolated test process; explicitly run in CI"]
    fn exclusive_worker_keeps_failed_preparation_unknown_and_drops_errors() {
        let mut job = supplied("ic");
        job.exclusive_phases = true;
        job.config.batch_trials = 1;
        job.config.max_trials = 1;
        let report = run(&job).unwrap();
        assert_eq!(report["status"], "incomplete");
        assert!(report["online_wall_ns"].is_null());
        assert!(report["generic_phase_timing"]["phases_ns"]["relation_la"].is_null());
        assert_phase_closure(&report);
        job.public_targets = Some(vec![["512".into(), "1".into()]]);
        assert!(run(&job).is_err());
        assert!(!measurement::enabled());
    }
}
