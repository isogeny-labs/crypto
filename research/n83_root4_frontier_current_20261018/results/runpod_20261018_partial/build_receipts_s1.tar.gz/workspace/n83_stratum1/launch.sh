#!/usr/bin/env bash
set +e
cd /workspace/crypto
export PATH=/root/.cargo/bin:$PATH
export CARGO_TARGET_DIR=/workspace/n83_target
printf '%s\n' "$(date -u +%FT%TZ)" > /workspace/n83_stratum1/start_utc.txt
timeout 18000 python3 -m research.n83_root4_frontier_current_20261018.runpod_runner --stratum 1 --binary /workspace/n83_target/release/examples/koblitz_orbit_dlp_fast --rho-binary /workspace/n83_target/release/examples/n83_rho_optimization_eval --provider-receipt /tmp/n83_runpod_allocation.json --output /workspace/n83_stratum1/results > /workspace/n83_stratum1/run.log 2>&1
printf '%s\n' "$?" > /workspace/n83_stratum1/exit_status.txt
python3 research/n83_root4_frontier_current_20261018/verify.py /workspace/n83_stratum1/results --stratum 1 > /workspace/n83_stratum1/verify.log 2>&1
printf '%s\n' "$?" > /workspace/n83_stratum1/verify_exit.txt
tar -C /workspace/n83_stratum1 -czf /workspace/n83_stratum1/raw_results.tar.gz results
sha256sum /workspace/n83_stratum1/raw_results.tar.gz > /workspace/n83_stratum1/raw_results.sha256
printf '%s\n' "$(date -u +%FT%TZ)" > /workspace/n83_stratum1/end_utc.txt
