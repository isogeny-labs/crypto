import EdwardsInput
import Mathlib.RingTheory.MvPolynomial.Homogeneous
import Mathlib.RingTheory.Regular.RegularSequence

namespace EdwardsDescentAudit
open MvPolynomial
noncomputable section
abbrev Poly := MvPolynomial (Fin 2) F
abbrev ExtPoly := MvPolynomial (Fin 2) K

def f0 : Poly := 2*(X 0^2+X 1^2)+2*X 1+1
def f1 : Poly := 2*(X 0^2+X 1^2)+3
def top : Poly := 2*(X 0^2+X 1^2)

/-- Symmetrization of the exact printed Edwards polynomial, with the
actual curve parameters and actual target y-coordinate. -/
def symmetric : ExtPoly :=
  C (targetY^2-1)*X 1^2+C (a/d-targetY^2)*X 0^2+
    C (2*targetY^2+2*(1-a/d)*targetY-2*(a/d))*X 1+C ((a/d)*(targetY^2-1))

theorem source_polynomial_identity (x y : K) :
    sourceF3 a d x y targetY = MvPolynomial.eval ![x+y,x*y] symmetric := by
  rw [symmetrization a d targetY x y actual_parameters.2.1]
  simp [symmetric]

theorem coefficient_decomposition :
    symmetric = MvPolynomial.map (algebraMap F K) f0+
      C beta*MvPolynomial.map (algebraMap F K) f1 := by
  decide +kernel

/-- Actual coefficient coordinates in the basis (1,beta) of F25/F5. -/
def descendRe (g : ExtPoly) : Poly :=
  .ofCoeff (Finsupp.mapRange (fun z : K => z.re) rfl (AddMonoidAlgebra.coeff g))
def descendIm (g : ExtPoly) : Poly :=
  .ofCoeff (Finsupp.mapRange (fun z : K => z.im) rfl (AddMonoidAlgebra.coeff g))

theorem coeff_descendRe (m : Fin 2 →₀ ℕ) (g : ExtPoly) :
    (descendRe g).coeff m = (g.coeff m).re := rfl
theorem coeff_descendIm (m : Fin 2 →₀ ℕ) (g : ExtPoly) :
    (descendIm g).coeff m = (g.coeff m).im := rfl

theorem actual_descent : descendRe symmetric=f0 ∧ descendIm symmetric=f1 := by
  constructor
  · ext m
    rw [coeff_descendRe, coefficient_decomposition]
    simp [beta]
  · ext m
    rw [coeff_descendIm, coefficient_decomposition]
    simp [beta]

theorem nonzero_equations : f0 ≠ 0 ∧ f1 ≠ 0 := by decide +kernel
theorem equation_degrees : f0.totalDegree=2 ∧ f1.totalDegree=2 := by decide +kernel
theorem actual_top_parts :
    homogeneousComponent f0.totalDegree f0=top ∧
      homogeneousComponent f1.totalDegree f1=top := by decide +kernel
theorem top_nonzero : top ≠ 0 := by decide +kernel

theorem duplicate_not_regular {A : Type*} [CommRing A] (h : A) :
    ¬ RingTheory.Sequence.IsRegular A [h,h] := by
  intro hr
  have ht := (RingTheory.Sequence.isRegular_cons_iff' A h [h]).mp hr |>.2
  have hz : Ideal.Quotient.mk (Ideal.span ({h} : Set A)) h=0 :=
    Ideal.Quotient.eq_zero_iff_mem.mpr (Ideal.subset_span (by simp))
  simp only [List.map_cons, List.map_nil, hz] at ht
  haveI := ht.nontrivial
  have hn := (RingTheory.Sequence.isRegular_cons_iff _ _ []).mp ht |>.1
  exact IsSMulRegular.not_zero hn rfl

theorem actual_top_parts_not_regular :
    ¬ RingTheory.Sequence.IsRegular Poly
      [homogeneousComponent (descendRe symmetric).totalDegree (descendRe symmetric),
       homogeneousComponent (descendIm symmetric).totalDegree (descendIm symmetric)] := by
  rw [actual_descent.1, actual_descent.2, actual_top_parts.1, actual_top_parts.2]
  exact duplicate_not_regular top

end
end EdwardsDescentAudit
