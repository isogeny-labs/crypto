a1,c0,target_inverse
17
16,
1,
2*a1*c0*target_inverse+8*c0^2*target_inverse+3*c0*target_inverse+16
