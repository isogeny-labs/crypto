a1,c0,q2_0,q2_1,target_inverse
17
5*a1*c0*q2_0+2*c0^2*q2_0+16,
16*a1^2*q2_0+5*a1*c0*q2_1+2*c0^2*q2_1+5*c0*q2_0,
16*a1^2*q2_1+15*a1*q2_0+1*c0^2*q2_0+5*c0*q2_1,
15*a1*q2_1+1*c0^2*q2_1+16*q2_0,
16*q2_1+1,
12*a1*c0*target_inverse+15*c0^2*target_inverse+16
