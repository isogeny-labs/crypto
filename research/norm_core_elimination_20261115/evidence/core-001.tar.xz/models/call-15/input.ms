a1,c0,target_inverse
17
16,
1,
14*a1*c0*target_inverse+1*c0^2*target_inverse+7*c0*target_inverse+16
