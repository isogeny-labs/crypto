a1,c0,target_inverse
17
16,
1,
5*a1*c0*target_inverse+4*c0^2*target_inverse+15*c0*target_inverse+16
