a1,c0,target_inverse
17
16,
1,
2*a1*c0*target_inverse+5*c0^2*target_inverse+12*c0*target_inverse+16
