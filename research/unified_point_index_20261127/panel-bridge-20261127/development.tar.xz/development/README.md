# Driver development receipt

The `source.sha256` file binds the modified panel driver and the shared options JSON. Rust 1.78 `rustfmt --check` and the locked offline release panel binary tests passed (12/12). Both commands are development checks, not benchmark timing. [pcc:unverified]

Strict Rust 1.78 Clippy failed solely on `clippy::format_collect` at unchanged `panel_driver.rs:238` (`sha256(data).iter().map(|b| format!("{b:02x}")).collect()`). The raw failure is `panel-clippy-final.txt`. A repeat with only `-A clippy::format_collect` passed in `panel-clippy-scoped.txt`; this does not qualify a strict hosted pass. The earlier `panel-clippy.txt` records an environment configuration failure because the rustup default was absent. All three outputs are retained. [pcc:unverified]

The Docker Rust 1.78 image had no rustfmt component, and component download failed. Cargo inside that image also could not fetch crates.io because of the proxy certificate. Local cached Rust 1.78 and offline registry were then used for the saved checks. No scientific run or native image build was performed. [pcc:unverified]
