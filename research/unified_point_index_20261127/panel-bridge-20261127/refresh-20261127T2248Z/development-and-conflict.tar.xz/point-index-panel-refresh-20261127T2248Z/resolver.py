from pathlib import Path
from collections import Counter, defaultdict
import subprocess, re, hashlib, heapq, json
root=Path('/workspace/crypto-point-index-panel-e2e-20261127')
head='87cbe11901cc5743e626120bee28295e8627dc72'; main='99b949b383b1205114201a2a5792c09f6fc2d180'
def show(ref,path):return subprocess.check_output(['git','show',f'{ref}:{path}'],cwd=root)
def blob_id(ref,path):return subprocess.check_output(['git','rev-parse',f'{ref}:{path}'],cwd=root,text=True).strip()
def sha(x):return hashlib.sha256(x).hexdigest()
def blocks(x):return [z.strip(b'\n') for z in re.split(rb'(?=^## )',x,flags=re.M) if z.strip()]
log_path='docs/session-logs/2026-11-27.md'
a=show(head,log_path);b=show(main,log_path)
ab=blocks(a);bb=blocks(b)
assert len(ab)==28 and len(bb)==11
assert all(z.startswith(b'## ') for z in ab+bb)
def tagged(seq):
    counts=defaultdict(int); out=[]
    for block in seq:
        key=(sha(block),counts[block]);counts[block]+=1
        out.append(key)
    return out
at=tagged(ab);bt=tagged(bb)
content={}
for seq,tags in [(ab,at),(bb,bt)]:
    for block,key in zip(seq,tags):
        assert key not in content or content[key]==block
        content[key]=block
edges={k:set() for k in content}; indeg={k:0 for k in content}
for tags in (at,bt):
    for x,y in zip(tags,tags[1:]):
        if y not in edges[x]:edges[x].add(y);indeg[y]+=1
# Date-only entries were created at 16:13Z and 16:46Z on the feature branch.
def priority(k):
    h=content[k].splitlines()[0].decode()
    if 'Unified point index exploration' in h:return (16,13,0,h)
    if 'Shared exact native point index' in h:return (16,46,0,h)
    m=re.search(r'(?:T| )(\d\d):(\d\d)(?:Z| UTC)',h)
    return (int(m.group(1)),int(m.group(2)),0 if k in bt else 1,h) if m else (0,0,0,h)
ready=[]
for k,d in indeg.items():
    if not d:heapq.heappush(ready,(priority(k),k))
order=[]
while ready:
    _,k=heapq.heappop(ready);order.append(k)
    for nxt in edges[k]:
        indeg[nxt]-=1
        if not indeg[nxt]:heapq.heappush(ready,(priority(nxt),nxt))
assert len(order)==len(content),'parent journal orders conflict; stop rather than reorder'
def is_subseq(source,result):
    it=iter(result)
    return all(any(x==y for y in it) for x in source)
assert is_subseq(at,order) and is_subseq(bt,order)
merged=b'\n\n'.join(content[k] for k in order)+b'\n'
assert tagged(blocks(merged))==order
(root/log_path).write_bytes(merged)
active='docs/ACTIVE.md';ha=show(head,active);ma=show(main,active);conf=(root/active).read_bytes()
pat=rb'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> [^\n]+\n'
match=re.search(pat,conf,flags=re.S)
assert match and len(re.findall(rb'^<<<<<<<',conf,flags=re.M))==1
hl=match.group(1).splitlines(keepends=True);ml=match.group(2).splitlines(keepends=True)
assert len(hl)==1 and len(ml)==3 and all(x.startswith(b'- [') for x in hl+ml)
new_active=conf[:match.start()]+b''.join(ml+hl)+conf[match.end():]
for src in (ha,ma):
    for line,n in Counter(src.splitlines(keepends=True)).items():assert Counter(new_active.splitlines(keepends=True))[line]>=n
assert b'<<<<<<<' not in new_active and b'>>>>>>>' not in new_active
(root/active).write_bytes(new_active)
receipt={'parents':[head,main],'journal':{'parent_blob_ids':[blob_id(head,log_path),blob_id(main,log_path)],'parent_sha256':[sha(a),sha(b)],'parent_block_counts':[len(ab),len(bb)],'merged_block_count':len(order),'merged_sha256':sha(merged),'ordered_block_sha256':[sha(content[k]) for k in order],'source_subsequence_preserved':True},'active':{'parent_blob_ids':[blob_id(head,active),blob_id(main,active)],'parent_sha256':[sha(ha),sha(ma)],'merged_sha256':sha(new_active),'head_unique_lines':len(hl),'main_unique_lines':len(ml),'every_parent_line_preserved':True}}
out=root/'research/unified_point_index_20261127/panel-bridge-20261127/refresh-20261127T2248Z'
out.mkdir(parents=True,exist_ok=True)
(out/'retention.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'blocks':len(order),'parent_blocks':[len(ab),len(bb)],'head_lines':len(hl),'main_lines':len(ml),'result_sha256':[sha(merged),sha(new_active)]}))
