<!-- BEGIN SHARED SESSION LOG -->

## Session log

At the start of every session, read the newest dated Markdown file in
`docs/session-logs/`.

Write today's log at `docs/session-logs/YYYY-MM-DD.md`, using the current date.
These paths are relative to the repository or workspace root.
Create the folder and file if missing. Claude and Codex share this directory.

Do not wait for the user to end the session. Append a timestamped entry after
every finished piece of work, after every decision, and whenever we switch
tasks. Preserve previous entries. Record concrete facts from commands and
logs; distinguish verified results from plans or assumptions.

Keep the log current *always*, not only at handoff: it is the session's working
memory. Before choosing the next step in any task, read the newest entries in
today's log (and the previous day's when the session spans a date change) and
let them decide the next action; if work already done is missing from the log,
write that entry before doing anything else. Never start a new measurement,
experiment or code change without the previous one recorded and reviewed.

Every entry has four headings:

- What was done (commands, files, features)
- Decisions made (and why)
- Open threads (unfinished, pick up next time)
- Errors (what went wrong, how it was handled)

Commit project handoffs with the related PR so they survive across sessions.
Several sessions append to the same day's file, so a PR that touches it goes
`dirty` on `main` often (lesson `L-1e09e78e395f`, adopted 2026-11-15). Fetch
`origin/main` before appending, and when the file conflicts, merge `main` and
keep both sides in time order; never drop another session's entry.
Keep entries about this project; do not copy private global logs or chat transcripts.

<!-- END SHARED SESSION LOG -->

## Goal: what to work on next

Sessions should never need a prompt to find their work. `docs/ACTIVE.md`
holds the owner's pinned goal and ordered active items; the newest session
logs hold the open threads. `python3 tools/goal_brief.py` prints both (pinned
items first, then the newest "Open threads", capped at 120 lines).

- **Claude** gets the brief automatically from the SessionStart hook, and
  `/goal` (`.claude/commands/goal.md`) re-reads it and starts the next item;
  `/goal <text>` pins a new goal and breaks it into items.
- **Codex** gets it from its SessionStart hook (`.codex/hooks.json`,
  `--hook-json`). Codex and other runtimes without the hook run
  `python3 tools/goal_brief.py` at session start, and treat a bare `goal` /
  `/goal` message like Claude's `/goal`.
- With no other instruction, take the first unchecked item in
  `docs/ACTIVE.md`; if there is none, the most recent open thread no other
  live session owns (`conductor check`). State the choice in one line and
  start; ask only for decisions the brief marks as the owner's.
- Check items off, add follow-ups and move blocked items to "Blocked /
  questions" in `docs/ACTIVE.md` as you go; the history goes in the session
  log. Every other rule in this file still applies to the work itself.

# Agent instructions

## Research progress and communication

Owner instruction, 2026-10-30. Lead with what was derived, implemented,
improved, or checked, and report it at that scope. A completed component is
progress. State a material remaining dependency once, with the next technical
step, and continue authorized work.

Do not append an overall ECDLP verdict or a rho comparison to routine results,
reports, or handoffs. Use those comparisons for an explicitly scoped evaluation,
a required comparison table, or a specific factual correction. Exact checks,
assumptions, measured costs, and actual failures provide the necessary context.
This rule replaces older instructions that discount component progress or
require routine overall-goal disclaimers.

## Literature first

Owner instruction (2026-10-19): check relevant literature before doing any work.
For every task, complete this review before choosing an approach, editing files,
implementing, running experiments, or making recommendations.

- Start with this repository's references, research notes and prior results, then
  check relevant papers, standards and official documentation for current methods,
  limitations and known negative results.
- Read the primary sources that matter. Verify their assumptions, parameters and
  conclusions rather than relying on memory, abstracts or search snippets.
- Briefly record the sources checked, with links or repository paths, and explain
  how they inform the work in the task notes, report or PR. Check novelty claims
  against that prior work and reuse established methods where appropriate.
- If relevant sources are inaccessible or no relevant work is found, state the
  search scope and evidence gaps before proceeding. Never invent citations or
  treat an unsuccessful search as proof that no prior work exists.

## Knowledge base first

Owner instruction, 2026-11-05. The shared `research-kb` MCP server indexes
this repository, `crypto-autoresearcher`, `cryptanalysis`, `crypto-lean`,
`cryptologic-archives` and the paper collection: about 22k sources, 151k
passages and 1.7k Lean declarations. It is the fastest way to find prior work,
negative results, open problems, technique notes and exact theorem statements.
Query it before scanning the 100k-file tree, before proposing a lead, and
before any novelty or “not tried” claim.

**Mandatory triggers.** Query the KB when the task is any of:

- a literature, prior-art or “has this been tried?” question;
- a new lead, mechanism, factor base, summation polynomial, solver, coordinate,
  isogeny or scaling assumption;
- a “first”, “best”, “not known”, “no effect”, “negative result” or novelty
  claim;
- a cross-repository question (crypto ↔ crypto-autoresearcher ↔ cryptanalysis ↔
  crypto-lean);
- a subagent handoff, so the child starts from the sources already found rather
  than repeating the search.

**Minimum protocol.** Use the MCP tools; do not guess names.

1. `kb_status` once. Record `revision` and `last_refresh`. If `ready` is false
   or the refresh is older than the work you rely on, say so and use the
   fallback.
2. `search_knowledge` with two to four distinct queries: the exact mechanism,
   the negative form, the application, and the adjacent field. Add `repo=` when
   the owning repository is known and `source_type=` to separate papers,
   internal notes and formal sources.
3. `search_theorems` for every Lean-backed statement. Quote the declaration
   name, environment digest and `verification`; `source-only` is not a proof.
4. Open the best one to three hits with `get_source` (metadata plus every
   origin) and `get_context` (bounded excerpt); `find_related` on one hit to
   find the sibling lead or the paper behind it.
5. `recent_sources` before a survey or a “what changed?” question. It is
   ordered by ingestion time, not publication date.

**Read the hit, not the score.** A score is relevance, not truth. Check
`claim_status`, `authority`, `evidence_level`, `superseded`/`superseded_by`
and `origins[].repo/path/git_commit`; then read the primary file or paper.
A repository summary is a pointer to the committed evidence, not a replacement
for it. `hybrid_current=false` means lexical search is current and the optional
semantic index is not built: use exact terms, identifiers and phrases. No
result does not prove absence; state the queries, repositories and source types
searched, and the gap.

**Record the receipt.** In the task notes, session-log entry or PR body, add a
“Sources checked (KB)” line with the `source_id` (or `document_id`), the
`repo:path` and what it changed in the plan. If the KB was unavailable, say
which tool failed and what you used instead. A subagent prompt carries the
queries already run and the source IDs already accepted.

**Fallback.** If the MCP server is not loaded in this runtime, use the same
catalog through the repository wrapper, which sets the catalog and registry
that a bare CLI run lacks: `scripts/research-kb status`,
`scripts/research-kb search "<query>" --top-k 8`,
`scripts/research-kb theorems "<name>"`,
`scripts/research-kb brief "<question>"`. If neither is available, use the
lead atlas and repository paths, and mark the KB review as unavailable in the
handoff. The `research-kb` skill has query recipes, the result fields that
matter and a worked receipt.

The adoption audit is `scripts/kb_usage_report.py`; it counts dated
session-log entries carrying a receipt (or an explicit `KB unavailable`). Run
`python3 scripts/kb_usage_report.py --since 2026-11-05` after a batch of
sessions and keep `docs/knowledge-base-usage-baseline.json` as the before
mark. `--ref origin/main` measures committed history.
`.github/workflows/kb-usage-report.yml` runs it weekly and on demand,
report-only. It is not a quota and never blocks a null or negative result.
Retrieval quality is measured separately by `scripts/kb_retrieval_probe.py`
against `docs/kb-retrieval-queries.json`; see `docs/knowledge-base-retrieval.md`.
Change the index or ranking only against that measurement.

## Standing workflow rules (from the owner)

- **Run experiments on EKS Spot by default** (owner, 2026-10-25). For an
  authorized x86 CPU experiment or crypto benchmark, read and use
  [isolab-eks](.agents/skills/isolab-eks/SKILL.md), then submit and verify it;
  do not merely give the user commands to run. This applies to Claude, Codex,
  OpenCode and their experiment agents. Authentication and routing are in
  §9a. Honor an explicitly requested backend, workload and budget.
- **Always commit finished work and open or update a PR.** Landed rungs,
  ledger promotions, evidence directories, and code changes land as commits
  on a feature branch. If the branch already has an open PR, extend that
  PR and update its title and description to match the new scope instead of
  opening a second one. Do not leave finished work uncommitted.
- **Check research proposals into a PR before handing them off** (owner,
  2026-10-28). Lead nominations, literature reviews, experiment plans, reports,
  diagrams, and reproducible sources are finished work. Commit them and open
  a regular PR, or update the appropriate existing regular PR, before the final
  response. Include required report PDFs under the current artifact policy.
  Local commits, workspace links, and private checkpoints are intermediate
  records until the PR contains the intended files. Verify the remote commit
  and PR contents. If publication is blocked, report the exact blocker and
  keep the check-in obligation open. Preserve the distinctions between proposed,
  proved, and measured work, and honor existing merge and experiment limits.
- **Use regular PRs.** Create pull requests with `draft=false` and mark an
  existing draft ready for review when you update it. Record pending CI,
  review, and follow-up work in the PR description; draft status is not a
  holding queue. Ready for review invites review; it does not authorize a
  merge. All validation, evidence, review, and merge gates below still apply.
  Use a draft only when the user explicitly asks for one.
- **Enable auto-merge when you open the PR** (owner, 2026-10-24):
  `gh pr merge <n> --auto --merge`. It is the default for every PR whose base
  is `main`, not an optional extra, and it does not replace the check-in and
  merge rules below. GitHub offers auto-merge only when the base is the
  repository's default branch: a PR stacked on a feature branch cannot
  auto-merge, so retarget it to `main` once its parent lands and enable
  auto-merge then, or merge the stack bottom-up. If the user asks to keep a PR
  open or wait for review, disable auto-merge (`gh pr merge <n>
  --disable-auto`).
- **Verify before pushing:** run `cargo test --release --lib`, the touched
  examples' tests, and the relevant Python suites (for example
  `research/sat_factor_base_review_20260908/autolab/test_boundary_autolab.py`)
  and fix failures first.
- **Evidence scope** (see `docs/ic/boundary_targets.json`): use public synthetic
  / known-answer fixtures and describe the domain and behavior actually checked.
  Support recovery, complexity, and security conclusions with evidence for the
  particular claim. Multi-target and amortized results stay secondary; ledger
  rows promote only with complete measurement fields and independent replay.
- **Beat the fastest external tool, and show it** (owner's rule,
  2026-10-16; details in §15): our implementations should be faster than
  every other implementation of the same computation. Every speed result
  is compared with the fastest external tool for that computation, for
  example Magma's F4 and F5 or msolve for Gröbner bases, on the same inputs
  and host, with the outputs checked equal. A result that has not been
  compared is not yet a claim of being the fastest, and a loss is reported
  as a loss.
- **Every big improvement updates the leaderboard** (owner, 2026-10-15).
  A PR that lands a large measured gain, whether a whole pipeline, a phase
  or a component (an engine, filter, oracle, solver or kernel), regenerates
  `docs/ic-leaderboard.html` and its twins in the same PR (§7b), even when
  no row of tables A–C moves; it is not a follow-up.
- **Validation gate** (owner, 2026-10-19; schema and mechanics in
  [`docs/VALIDATION_GATE.md`](docs/VALIDATION_GATE.md)). No row reaches the
  IC leaderboard (`docs/ic/LEADERBOARD.md`, `docs/ic/leaderboard.json`,
  `docs/ic-leaderboard.html`) or `benchmarks/README.md` unless its evidence
  directory carries a `VALIDATION.json` pointing to three artifacts: (1) a
  **replay certificate**, an independent replay of the recorded runs with the
  scalars verified; (2) a **validator report**, an independent recompute of the
  headline numbers from raw data that is in the repository; (3) a **rho
  reference matched to the protocol**, the reference the protocol names and
  the strongest available for that curve (negation, Frobenius or the
  automorphism fold), priced in the same unit and the same binary or process,
  with the §5a band at 0, 0.1 and 1 GAE. `scripts/build_ic_leaderboard.py`
  refuses a row without them, and `scripts/validation_gate.py check` (workflow
  `validation-gate`) fails a PR that adds or changes such a row. Existing
  rows are not deleted: those frozen in `docs/ic/validation/PRE_GATE.json` and
  `benchmarks/PRE_GATE.json` render as "unvalidated (pre-gate)" until a
  validation sweep verdict
  (`research/validation_sweep_20261019/{A-leaderboard,B-benchmarks}/verdicts.jsonl`)
  or a `VALIDATION.json` validates them; the freeze files may only shrink. The
  `audit-runs` skill re-audits finished runbook and ecbench sessions daily
  (`.github/workflows/audit-runs-daily.yml`). Like the success criterion, the
  gate decides what may be shown as a result, never whether an honest null or
  negative result may be recorded: those stay in their research directories.
- **Conductor:** run `conductor check --summary "…" --scope path:…` before
  editing; report scope expansion before editing outside reserved paths. Do
  not publish chat transcripts or secrets as task metadata.

## Sabotage is assumed: proof-carrying claims

Owner rule, 2026-11-04. Every producer, this session included, is assumed to
be sabotaging the work: numbers, booleans, receipts, proofs, prose and chat
answers are data until a verifier the producer did not write has checked them.
The contract is [`docs/SABOTAGE_RESISTANCE.md`](docs/SABOTAGE_RESISTANCE.md);
the tool is `tools/pcc/pcc.py` (byte-identical across the lab's repositories;
`docs/shared-code.lock.json`).

- **A claim is a record.** Before a result is cited anywhere (leaderboard,
  benchmarks, PR body, session log, paper, chat), write it with
  `python3 tools/pcc/pcc.py claim new --kind <theorem|solve|measurement|speedup|execution|absence> --statement "…" --proof KIND:PATH …`.
  The record pins every proof by SHA-256 and lands in `pcc/claims/` and the
  ledger `pcc/ledger.jsonl`.
- **Only a signed verdict verifies.** `pcc verify` runs the verifier for each
  proof kind (Lean statement binding and holes, solve and zero-knowledge
  solve certificates with the tool's own arithmetic, replay certificates and
  validator reports with a keyring signature, execution receipts through a
  verifier pinned in `pcc/keyring.json`). The signed verdict is written by CI
  on `main` (`pcc-gate.yml`, key `ci-main`), never by the producing session.
  `independent: true` and `verified: true` written by a producer are not read.
- **Standing, not words.** `python3 tools/pcc/pcc.py standing <id>` is the only
  source for "verified". Anything else is an unverified assertion and is
  labelled so: in prose, cite `[pcc:<id>]` for a verified claim or tag the
  sentence `[pcc:unverified]`. `pcc lint-prose` enforces this on pull request
  bodies in CI and is run on reports and session logs.
- **The ledger is append-only.** `pcc ledger verify --base origin/main` runs
  on every pull request: the base ledger must be a prefix of the head's and
  every hash link must hold. Never edit or rewrite `pcc/ledger.jsonl`.
- **Bypasses are recorded.** `CHECKPOINT_SKIP=<reason>` still works, and the
  hook now appends a `bypass` entry to the ledger and pushes a checkpoint
  before the command runs. Commit the ledger with the work.
- **The verifier is tested against sabotage.** `pcc canary` plants every
  sabotage class in the contract into a passing fixture and must reject each
  one; CI runs it on every pull request. A new way to cheat the gate becomes a
  new canary in the same change that closes it.
- **Chat answers follow the same rule.** State a result with its claim id and
  standing, or say that it is an unverified assertion. Never present a
  self-check, a replay, a hash or a model's agreement as verification.

What this does not yet give: a real execution-proof backend. Until a verifier
digest is listed under `trusted_verifiers` in `pcc/keyring.json`, every
`execution` proof is `not_covered`, and no result here is execution verified
(`crypto-autoresearcher:docs/execution-proof-chain.md`, milestones open).

## Success criterion: iterative improvement of the index-calculus baseline

Owner's rule, 2026-10-15. It replaces any earlier wording that treats only
beating rho, or only an "advance", as success.

Verified, measured improvements accumulate toward the long-term index-calculus
objective. **Each improvement over the named baseline is a success at the
scope measured and is reported as one.** Constructions, identities, and
descriptive investigations report their own technical outcomes and next steps.

- **Baseline.** For each curve and size, the baseline is the best current
  verified index-calculus pipeline, frozen with its protocol, receipts and
  end-to-end `S` (every phase, cold). Name it before you optimise.
- **Improvement.** The improvement must lower cost against that baseline on
  the same instances, with every answer verified, under a protocol frozen
  before timing. A stage-level win is reported as a stage improvement and
  becomes a pipeline improvement once it moves end-to-end `S`. The
  measurement rules still apply in full: isolation tiers, A/A and positive
  controls, matched references, and no combining results from different
  experiments.
- **What counts.** Advance and engineering are both successes. Relabelling
  (the headline count fell while total cost rose) and accounting (the
  numbers changed but the algorithm did not) are recorded honestly and are
  not improvements. A negative or null result is a valid outcome to record,
  but it is not an improvement.
- **Ratchet.** Each landed improvement becomes the new baseline. Record it
  with its delta, so progress is cumulative and visible across the
  sequence.
- **Comparison scope.** Include matched rho and precomputation references
  where the pipeline comparison or frozen protocol calls for them. Component
  work uses the matched reference for that component. A claim to beat rho uses
  the complete accounting, growing-size checks, and independent replay for
  that comparison.
- **Keep going.** After each result, name the next improvement to try, and
  move on to it.

**Claim tiers** (owner, 2026-11-15): "below rho", "smaller exponent" and
"subexponential" are defined in
[`docs/ic/SUCCESS_CRITERIA.md`](docs/ic/SUCCESS_CRITERIA.md) (checklist
`docs/ic/success_criteria.json`; red-team review in `docs/ic/reviews/`).
Every tier claim uses the cold end-to-end interval (the online interval of
"IC measurement rules" is reported beside it, never instead), public targets,
no uncounted work, the cheapest registered rho at each weight, and a
preregistration committed as a pcc claim before the first run, with Holm
correction over the thread's attempts. T0 is a gain over the IC baseline; T1
is below that rho at a stated size (band and calibrated readings, growing-size
trend, controls, cross-host audit); T2 is a smaller exponent on a declared path
(the largest per-phase upper limit, six or more sizes over 24+ bits, a
beacon-derived held-out size); T3 is subexponential (an argument with named,
numerically tested heuristics; data can only falsify). A transfer to another
group counts at every tier when the map is charged on every instance, certified
independently, the answer checked on `E`, and applicability and literature
status are preregistered. Each tier is reported as the distance remaining,
never as a gate on the work.

## Tracks of index calculus

Owner's rule, 2026-10-29 (`research/prime_ic_program_20261029/DECISIONS.md`
R1, Option C as amended for D2). It refines the 2026-10-24 criterion
(`docs/ic/SWEEPER.md`, "Tracks").

Index-calculus pipelines are reported in two tracks. Each track has its own
baseline and its own ratchet under the success criterion above.

- **Algebraic.** Relations come from a solver applied to a system that
  contains both the summation polynomial and the factor-base constraint, for
  example ⟨S_{m+1}, F_V⟩ handed to msolve or F4, Weil descent over a subspace
  base, or a PKM tower system. This is the headline track.
- **Generic decomposition.** Relations come from enumerating the base,
  computing group sums or differences, and testing them against the base or a
  table of precomputed sums: `subtract`, `rootfind-*`, `mitm`, pair tables,
  and large primes on a pair table. Such an oracle runs identically on a
  random base. Label this track "generic decomposition" and document the
  applicable generic-group bounds with their assumptions in its method
  description. Improvements in this track count against its own baseline.

Arms of the two tracks may be ranked against each other on the same
instances, in the same unit and across the §5a band. A gain in one track
never ratchets the other track's baseline. Include matched rho in tables whose
protocol calls for that comparison. Per-oracle classification:
`research/prime_ic_program_20261029/ruling/classification.json`, column C.

## Pointers

- **Shared conventions with `crypto-autoresearcher`, `cryptanalysis` and
  `crypto-lean`:** object storage (one bucket, `setec-astronomy-artifacts`,
  region `us-east-2`), the validation vocabulary, curve identity, the skill
  surface and the shared-code parity list are stated once in
  `crypto-autoresearcher:docs/lab-contract.md`. That file wins on a shared
  convention; this file wins on anything specific to this repository.
  `s3://setec-astronomy-artifacts` is the only writable bucket; the legacy
  buckets (`s3://crypto-autoresearcher/**`, `ecc2k130-*`, `aburan28-n83-tier1-*`,
  `cairn-swarm-*`) are read-only.
- **What has already been tried against ECDLP, here and in the sibling
  repositories:** the lead atlas in aburan28/crypto-autoresearcher,
  `knowledge/leads/ecdlp/` (`python3 tools/lead_atlas.py --brief`, printed by
  `.claude/hooks/session-start.sh`). Read it before surveying `research/` for
  leads, and run `--match "<idea>"` before proposing an ECDLP mechanism. A
  result that lands here updates the lead it advances in the same PR or the
  next atlas review (skill `lead-atlas` there).
- **Prior art, negative results and internal notes, by query:** the shared
  `research-kb` MCP server (AGENTS.md “Knowledge base first”; skill
  `research-kb`). It indexes this repository and its siblings, including the
  lead atlas, technique notes, decisions, papers and Lean declarations. Query
  it before `rg`-ing `research/` or claiming that something was not tried.
- **Curve facts, by query instead of by file scan:** the curve database
  ecdb (MCP server `ecdb` in `.mcp.json`, or HTTP). See "Querying the curve
  database (ecdb)" below and [ecdb/docs/AGENTS.md](ecdb/docs/AGENTS.md).
- Boundary ledger (machine): `docs/ic/boundary_targets.json`
- Boundary scoreboard (human): `docs/ic/BOUNDARY_TARGETS.md`
- Autolab runner: `research/sat_factor_base_review_20260908/autolab/`
- Current ladder frontiers: `RESEARCH_KOBLITZ_INDEX_CALCULUS.md`,
  `RESEARCH_ECC2K130_IC_FEASIBILITY.md`
- Faster checkouts (blobless clone, sparse profiles, cloud-session
  settings): [docs/sparse-checkout.md](docs/sparse-checkout.md)
- Experiment design and records: `controlled-experiment` (claims, controls,
  confounders), `experiment-protocol` and `review-run` (pointers to the
  canonical schemas in crypto-autoresearcher), `queue-experiment` (§9b)

For small-prime or pinned GF(2^83) elliptic-curve surface searches, quartic
subgroup transfers, genus-2+ Jacobian transfers, hyperelliptic covers, Mumford
arithmetic, gluing or polarization candidates, or Frobenius compatibility
checks, use
[ecdlp-surfaces](.agents/skills/ecdlp-surfaces/SKILL.md) for tool selection,
commands, and interpretation limits.

## Reading discipline

`research/` is most of a 6.6 GB, 100,000-file checkout. Read what the current step needs:

- **Indexes before archives.** Status comes from the pointers above,
  `docs/bounds/frontier.json`, and the ecbench database views; open a session
  or note to act on it, not to find it.
- **Locate, then read.** `rg -n` an exact id, slug, or term in the narrowest
  directory, then read the matching range.
- **Size before contents.** Check `wc -c` first. Read raw session outputs,
  `*.jsonl`, logs and CSVs by key or range (`jq`, `rg`), never whole; a
  session is read through its audit, replay or claim JSON.
- **Paths, not contents,** in handoffs and subagent prompts.
- **Off disk is not absent.** Cloud sessions start in the sparse `harness`
  profile, without the 18 largest `research/` archives. In a sparse checkout
  (`docs/sparse-checkout.md`) a path `git ls-files` lists is materialized with
  `scripts/sparse-checkout.sh add --path`, never reported missing.

## Preserve scope and report evidence

Use [report-evidence](.agents/skills/report-evidence/SKILL.md) for implementation,
experiments, benchmarks, completion reports, and research handoffs.

- Preserve the user's requested deliverables, parameters, workloads, and acceptance
  criteria. Do not silently substitute a smaller experiment, weaken an argument
  or validation gate, or omit a requested run because you expect it to fail.
- Execute authorized, feasible experiments as requested. The user decides research
  significance and priorities. Report measured values and exact ratios; do not
  independently market results as "massive", "breakthrough", or dismiss them as
  "not worth running". Give interpretation when requested and label it separately.
- Continue to check correctness and flag invalid results, factual errors, and
  uncertainty. Preserve failed runs, timeouts, regressions, raw evidence, exact
  commands, inputs, revisions, environment, and accounting intervals.
- Distinguish assistance restrictions, access/tool limits, resource limits,
  implementation gaps, untested hypotheses, and proved mathematical obstructions.
  Never disguise an assistance limit as mathematical impossibility. State the
  actual blocker explicitly; retain the original requirement as unresolved.
  Higher-priority restrictions and authorization boundaries still apply.
- Keep observations, calculations, hypotheses, extrapolations, and interpretations
  distinct. A stage ratio does not establish an end-to-end gain; a bounded search
  failure does not prove nonexistence; a toy implementation is not general support.
- Track each requested requirement as verified complete, implemented but unverified,
  partial, blocked, or not attempted, with evidence or the exact remaining gap.
  Passing tests or merging a PR does not make the original task complete.
- Correct misleading prior claims explicitly. Do not rewrite frozen evidence or
  quietly redefine completion. Report actual execution status, never planned runs
  as completed or unscheduled work as continuing in the background.

These rules govern scope and reporting throughout this file. Existing measurement
and correctness gates remain in force; they do not authorize an agent to cancel a
requested experiment or decide its research significance for the user.


Guidance for agents doing cryptanalysis work in this repository.

This repository is a study library, not a production one, and its
cryptanalysis suite exists to find out **where crossovers actually are**
rather than to produce attacks.  That makes the reporting rule below the
most important convention here: without it, a thread can run for weeks,
improve its own headline number by two orders of magnitude, and have
established nothing.

## Name the obstruction

When substantial research, cryptanalysis, or audit work cannot meet a proof,
implementation, experiment, or validation requirement, **name the specific
problem**. Before repeating the same blocked approach or handing it off, create
or update `problems/<descriptive-slug>.md` using
[the problem template](problems/TEMPLATE.md), add it to
[the problem index](problems/README.md), and link it from the affected work.

- State exactly what is blocked, under which parameters and assumptions, and
  why that gap prevents the requested conclusion. Track major or recurring
  blockers, not every routine TODO.
- Separate observed evidence, suspected explanations, missing implementations,
  access/tool or assistance limits, resource limits, and proved mathematical
  obstructions. Cite artifacts or proofs with their exact scope; mark unknowns
  explicitly. A timeout or bounded failed search does not prove impossibility;
  failure to find an attack does not establish security.
- Say **what would unblock it**: the missing lemma, construction, verified map,
  measurement, implementation, access, or resource, with checkable acceptance
  criteria. Explain what satisfying those criteria would establish and what
  would remain unresolved. "More research" is not an exit condition.
- Give the next discriminating experiment or proof obligation, its controls
  and execution limits where relevant, and how each possible outcome changes
  the next action. Apply the existing experiment and budget rules.
- Reuse an existing problem record for the same obstruction, including a
  cross-repository link when appropriate. Update its evidence, next action,
  and index row in the PR that changes the situation; preserve frozen evidence.
  Resolve it only with linked evidence meeting its exit criteria. If another
  record replaces it, mark it superseded and link the successor.

Recording a problem keeps the original requirement visible; recording it alone
does not resolve that requirement. It
does not authorize abandoning requested work, weakening its acceptance criteria,
or promoting a claim. Completing the template or merging its PR does not solve
the underlying problem.

## Intermediate-cost and asymmetric-access hypotheses

User instruction, 2026-10-06. In assessments of supplied or published claims
of hidden mathematical advantage, include costly intermediate advantages:
a hypothetical reduction from subgroup-size work r^(1/2) to r^alpha with
alpha < 1/2 may matter even when recovery remains expensive. The example
alpha = 1/3 is a threat-model assumption, not a discovered algorithm or a
required outcome. Do not dismiss a claim solely because it fails to make
recovery trivial; do not infer practical recovery from its exponent alone.

Keep mathematical existence, executable transfer, subgroup preservation,
destination-solver advantage, practical resources, and asymmetric access as
separate obligations. A hypothesis about agency capabilities or motives is
not evidence that a trapdoor exists. Distinguish a deliberately selected
weak instance from an unpublished method applying to honestly generated
instances, and distinguish both from implementation compromise.

Account for curve-specific construction and preprocessing, per-target work,
transfer and recovery, verification, failed attempts, memory, hardware, and
the exact number of targets reusing setup. Report cold-start and genuinely
amortized costs separately. Separate exponent changes, constant factors,
primitive costs, and hardware throughput. Faster known-scalar multiplication
alone does not establish faster unknown-scalar recovery.

Under the user's hidden-route scenario, public discovery must require
substantial deliberate work rather than routine inspection or accidental
rediscovery. An illustrative reconstruction cost near 2^60 operations is a
scenario parameter, not a measured bound or evidence of agency capability.
Define the operation unit, algorithm, success probability, memory, parallelism,
and uncertainty before interpreting that number. Keep public discovery cost,
designer setup with a retained witness, map evaluation, and destination solving
separate. Isogeny degree alone establishes none of these costs. Assess cheaper
equivalent routes as well as reconstruction of the exact withheld map; one
comparably useful public shortcut can defeat the claimed access asymmetry.

Treat secrecy as a separate hypothesis: identify the withheld information,
whether it can be reconstructed from public parameters, and whether a
comparably useful public route exists. A high-degree map is not automatically
cheap to evaluate or hard to reconstruct. State field and construction-family
restrictions; do not transfer composite-degree binary-field conclusions to
prime fields or prime-degree binary extensions without justification.

When the user stipulates layered adversary capability, assess a portfolio
rather than one all-purpose vulnerability. Record each hypothetical technique's
prerequisites, coverage, cost, reusable setup, access requirements, secrecy,
and failure conditions. Distinguish independent alternatives from methods
sharing the same dependency; do not assume independence or multiply speculative
probabilities. Include redundancy, complementary combinations, and what
remains available if one technique is disclosed, patched, or loses its advantage.

Model reserved capabilities and exceptional-use scenarios explicitly, including
activation constraints, scarcity, exposure risk, and the cost of losing secrecy.
These are stipulated game-theoretic assumptions, not observations of agency
behavior or proof of any particular mathematical capability. Alternative
implementation or protocol compromises do not refute an algebraic hypothesis
and do not replace an algebraic workstream the user has requested. Preserve
each requested track and its unresolved obligations.

Apply existing transfer, evidence, run-routing, and review rules. Missing
formulas or measurements remain open obligations. Bounded failure is not
universal nonexistence. This assessment rule adds no autonomous key-recovery
campaign, production-target exploitation, or scientific state transition.

## Curve-structure and endomorphism rules

For trace and anomalous-order patterns, CM conductor gaps, torsion over
extensions, twists, isogenous representatives, GLV/GLS formulas, covers, and
factored or mixed-degree isogeny loops, follow
[docs/endomorphism-rules.md](docs/endomorphism-rules.md). Record the exact
ICV1/EC1 identity, working field, subgroup, bounded signal calculation,
explicit map when proposed, and its complete evaluation and transfer costs.
Keep existence, executable construction, subgroup action, measured scalar
arithmetic, and unknown-scalar recovery as separate claims. A small torsion
factor, class number, embedding degree, or composite map degree is a lead with
specific hypotheses, not a universal verdict. Preserve negative searches
within their exact bounds and run authorized feasible experiments under the
existing evidence, review, and benchmark rules.

## Resume checkpoints in S3 before every run

A session can end at any moment (token or usage limits, a crash, a reclaimed
container), and a worktree that only it knew about is then lost. So **before
any experiment run starts, the leads, the spec and everything needed to
resume the effort are checked into S3**, and kept current while it runs.

- `scripts/checkpoint.sh init` writes `.resume/RESUME.md` (gitignored). Fill
  every section for a reader who has none of this conversation: goal, the
  lead or hypothesis and where it came from, the spec or protocol path with
  frozen inputs, the current state with measured numbers and where raw output
  lives, next steps with exact commands, every run in flight (command, host,
  instance id or pid, log and output paths, how to collect it), and the stop
  and success conditions. The gate rejects missing or empty sections and
  leftover `TODO(checkpoint)` markers.
- `scripts/checkpoint.sh push` uploads one checkpoint to
  `s3://setec-astronomy-artifacts/checkpoints/<repo>/<branch>/<stamp>/`:
  `RESUME.md`, the spec, leads, protocol and plan files the branch changed, a
  git bundle of unpushed commits, a patch of uncommitted changes, untracked
  files (large ones listed, not copied) and `meta.json`. Earlier checkpoints
  are never overwritten. Push again whenever a run starts or finishes,
  results arrive, or the plan changes.
- **Claude Code enforces this** (`.claude/hooks/checkpoint-hook.sh`): writing
  a spec, leads, protocol or plan file, or `RESUME.md`, pushes a checkpoint,
  and run launchers (`scripts/run_*`, sweeps, benchmarks, `nohup`, background
  commands, `cargo run --release`, `expspec run`, `sage-run`, cloud launches)
  are refused until `RESUME.md` is complete and the push succeeded. A command
  that is not an experiment run may opt out with `CHECKPOINT_SKIP=<reason>`.
  **Other runtimes (Codex)** run `scripts/checkpoint.sh gate` before
  launching and do not launch if it fails.
- Claude Code sessions have no AWS credentials, so the script works from a
  token (tried first; an AWS profile is only a fallback). The token is a
  presigned POST policy that can only write under `checkpoints/`, plus a
  presigned link to an index of recent checkpoints, so push, `list`, `share`
  and `restore` all work without credentials. A job on the owner's Mac
  re-mints it every 15 minutes (7-day lifetime) into
  `~/.config/checkpoint/upload-token`, where the script finds it; a session
  elsewhere is given it as `CHECKPOINT_UPLOAD_TOKEN`. The bucket host is in
  this repo's sandbox network allowlist (`.claude/settings.json`). It is a bearer credential: never
  commit it or put it in a PR, report or task card.
- To resume: `scripts/checkpoint.sh list` shows the latest checkpoint per
  branch (from the index, up to 15 minutes behind);
  `scripts/checkpoint.sh restore <repo>/<branch>[/<stamp>]` rebuilds the
  worktree next to this checkout and puts `RESUME.md` in it. `share` prints a
  presigned URL that `restore <url>` accepts anywhere.

A checkpoint is a safety net, not the record: the spec, protocol and results
still land in a PR under the rules above.
Switching runtimes when a budget runs out (Claude Code ↔ Codex):
[docs/runtime-relay.md](docs/runtime-relay.md); on a pending `.resume/HANDOFF.md`, run
`python3 scripts/relay.py accept` first.

## Benchmark records: data in S3, metadata in Git, one progress report

Owner's rule, 2026-11-04; mechanics in
[docs/benchmark-records.md](docs/benchmark-records.md) (shared, byte-identical).
**Every benchmark run leaves a `bench.record/v1` record in Git and its raw
data in S3, and regenerates the progress report, in the same PR.** The record
(`tools/benchrec.py`; `benchmarks/records/`) names the commit, host, command,
every raw file by SHA-256 and content-addressed S3 location
(`s3://setec-astronomy-artifacts/store/sha256/<aa>/<hex>`, or the prefix the
run already wrote to), and every measured value in the shared unit vocabulary
(`S`, `gae`, `log2_gae`, `ns_per_gae`, `ir`, `ir_per_op`, `cycles_per_op`,
`ipc`, `wall_s`, `cpu_s`, `ops_per_s`, `fmul`, `ratio`, `percent`, `count`,
`bytes`); any other unit is rejected. Records are written once; a rerun, an
invalid run and a censored run each get their own record.

The progress report (`benchmarks/progress/`: `progress.json`, `PROGRESS.md`,
`progress.svg`, `progress.pdf`) is generated only from the records and always
states progress the same way: gain versus the first record and versus the
previous record, in percent within one series (same problem, metric and
unit), and value over reference (the distance remaining to the matched rho,
1.0 = parity). The headline panel is in `S`; every other unit has its own
panel and is never mixed in. Derived numbers are labelled derived; a record
is not a validated result and does not move the leaderboard, `benchmarks/`
rows or `VALIDATION.json`, which keep their own gates.

**Enforced.** Claude Code (`.claude/hooks/benchrec-hook.sh`) refuses a
benchmark launcher (`ecbench`, `perfindex`, `perf_ipc`, `perf stat`,
`callgrind`, `hyperfine`, `cargo bench`, `isolated_bench`, `tools/profile.sh`,
`task_card.py run`, `autolab`, `icms`, `scripts/*bench*`, `make bench`) that
does not run as `tools/benchrec.py run <record> -- ...` or carry
`BENCHREC=<record>`, and refuses `git push` and `gh pr create` while
`tools/benchrec.py gate` fails (a record opened here and not closed, an
incomplete record, a stale progress report); `BENCHREC_SKIP=<reason>` opts a
command that is not a benchmark out. Other runtimes run `python3
tools/benchrec.py gate` before pushing. The `bench-records` workflow fails a
PR that adds a `benchmarks/` entry without a record naming it, carries a
malformed, open or edited record, cites a raw object that is not in S3, or
leaves the progress report stale.

## Research searches must leave visual reports

Every experiment run (ICMS or ecbench session, autolab or tournament round,
benchmark, or other research run), every PR that lands a result, and every
substantive search for new isogenies, curves, scalar rules, endomorphisms, or
related ECDLP mechanisms follows
[the research-visuals skill](.agents/skills/research-visuals/SKILL.md), on
every runtime (Claude Code reads it at `.claude/skills/research-visuals/`).
Deliver a source-linked report, a graph or explanatory diagram, and a PDF
containing the report and visual. A run report is descriptive and sits beside
the run's records, never inside a sealed or audited session directory.
Include negative, failed, and inconclusive findings.
Update every affected canonical graph, chart, and rendered copy in the same
change as a new verified finding or correction; record why a graph was left
unchanged when the search yields no graphable result. Keep proposed routes and
unverified rules visibly separate from proved or measured ones. This visual
record supplements the evidence, curve-identity, scoreboard, and PR rules
below; it does not promote a hypothesis or replace a verified run.

### Performance results also land in `benchmarks/`

Every run or PR that measures how fast an algorithm runs or reports a speedup
(an engine, kernel or solver timing, a before/after comparison of the same
code, a comparison with an external system such as msolve, Singular or Magma)
also copies its visual record into `benchmarks/`, in the same PR, always:

- `benchmarks/<YYYYMMDD>-<slug>/` holds the report PDFs (run report and
  results report), every graph as SVG, and a PNG render of every graph
  (150 dpi, rendered from the same plotting source as the SVG).
- `benchmarks/README.md` gets one row per entry, newest first: date, what was
  measured, the headline values with their units and ratios as the report
  states them, host and isolation level, and links to the study directory
  and run report.
- The study directory stays the source of truth (raw records, sources,
  inputs); `benchmarks/` holds copies for browsing. Regenerate both from the
  same source and never edit a copy alone. A later run adds a new entry and
  leaves earlier ones as they are.

`benchmarks/` is not `benches/`, which holds Cargo bench sources.

## Papers

Manuscripts generated from this repository's results live under `papers/`,
one directory per paper, and nowhere else. The layout is the same in
`aburan28/cryptanalysis`, `aburan28/crypto`, `aburan28/crypto-autoresearcher`
and `aburan28/ml-cryptanalysis`:

- `papers/README.md` is the index: one row per paper (directory, title,
  status). Add a row when adding a paper; never add a paper outside `papers/`.
- `papers/paper.mk` is the shared build. A paper's `Makefile` sets `TEX`,
  `SECTIONS`, `BIB` and, for figures or other files the build reads,
  `ASSETS`, and includes it; the targets are `make`, `make check`,
  `make arxiv`, `make eprint`, `make deanonymize` and `make clean`.
- `papers/.gitignore` ignores LaTeX auxiliaries and submission bundles. The
  built PDF is committed next to its sources and rebuilt whenever a cited
  number, conclusion or figure changes.
- `papers/AUTHORS.example` is the author-block template. Sources stay
  anonymized (`\author{Anonymous}`); `make deanonymize` restores the authors
  from an untracked `AUTHORS` file.
- Each paper directory holds the root `.tex` (or the `.md` of a draft that is
  not typeset yet), its sections and bibliography, `README.md` (status banner,
  what it says, what it does not say, how to build, reproduction pointers, and
  the checklist owed before submission), `abstract.txt` (title, keywords,
  category) and the PDF.
- Claims follow the repository's evidence rules: every number cites a
  committed artefact in this repository or a sibling (prefix the path with
  `crypto:`, `cryptanalysis:` or `crypto-autoresearcher:`); a component
  speedup names the measured component and interval; every end-to-end row has
  verified answers; each change is classed as advance, engineering,
  relabelling or accounting. A draft is not submitted, posted or cleared for
  either until its README says so, and its README names the novelty audit
  and the measurements still owed.
- `make check` must pass (references and citations resolved, no LaTeX errors,
  no overfull boxes) before a PDF is recommitted.

## Mathematical results should include Lean proofs

**Standing owner instruction, 2026-10-11:** For every new or substantially
revised mathematical result, include a faithful Lean 4 theorem and checked
proof whenever formalization is feasible. Treat the formalization attempt as
part of the requested work, and prioritize the central theorem and its
dependencies. Keep the readable mathematical proof in the report. The shared
library and gate live in `aburan28/crypto-lean`; pin its revision with the
toolchain, and treat a gate change as a dependency change.

- Maintain a proof map from each report theorem, proposition, lemma or
  corollary to its Lean declaration, exact hypotheses and verification status.
  Match the mathematical statement, including quantifiers, exceptional cases
  and field, curve, subgroup and endomorphism-order assumptions.
- Pin the Lean toolchain and dependency revisions. Build the actual theorem
  modules with `lake build` or an equivalent command, retain the command and
  output, and inspect `#print axioms` for every reported theorem. Recheck the
  compiled proofs with `lean4checker --fresh` when available.
- A reported Lean proof must contain no `sorry`, `admit`, `sorryAx`, custom
  axioms encoding the research claim, kernel-check bypasses or unverified
  native evaluation. Record the standard Lean foundations used.
- Prove the structural implications as well as the algebraic identities.
  Conditional theorems must expose their assumptions and identify any missing
  bridge to the actual mathematical objects. Do not present a weaker statement,
  assumed conclusion, circular hypothesis or arithmetic certificate as a full
  Lean proof of the report's theorem.
- If the full formalization cannot be completed, preserve the original result
  and its written proof, finish the feasible Lean lemmas, and record the
  concrete missing definition, dependency, proof obligation or failed build.
  Report partial formalization explicitly; keep the full theorem open.
- Add reproducible proof checks to the relevant CI workflow where practical.
  Every Lean target is also checked by the repository-wide proof gate
  (`tools/lean/proof-gate.sh`, workflow `lean-proof-gate.yml`): it builds each
  Lake project and standalone file and fails any theorem whose transitive
  axioms include `sorryAx`, an unlisted `native_decide` or a user axiom. A
  `native_decide` that a study deliberately trusts is recorded with its reason
  in `tools/lean/trusted-native.txt`. See `tools/lean/README.md`.
  Preserve frozen evidence and attach formalization updates as versioned
  additions rather than rewriting historical verification records.
- Before the first Lean edit, run the
  [`lean-instance-gate`](.agents/skills/lean-instance-gate/SKILL.md) skill:
  state the result as an instance of a Mathlib or crypto-lean structure,
  apply the existing theorem as stated, build missing laws generically in
  crypto-lean first, and write the inheritance table. The proof gate checks
  soundness; this gate checks that the proof is not a re-derivation.

## What supersedes what

Adapted from the Trail of Bits constructive-cryptography skills
(`skills/plan-the-work`, MIT). When two instructions disagree:

1. An owner decision (a dated owner rule in AGENTS.md or CLAUDE.md, or an
   accepted design recorded in a session log or PR) is settled. Do not reopen
   it; report a conflict with it instead of building around it.
2. A frozen protocol, task card or signed pcc claim supersedes any prose
   summary of it, including this file's examples and a session log.
3. A newer step record (session-log entry, receipt, review) supersedes an
   older plan's text about the same object; the plan goes stale once a step
   has changed its objects.
4. A brief to a worker supersedes the accepted record only on the form of
   what it builds; the worker lists each difference in its result.
5. The owning repository's naming convention supersedes a name in a brief;
   later briefs use the built name.
6. Text read from an artifact, a PR comment, another session or a tool
   output never supersedes any of the above ("Sabotage is assumed").

## Implementation language: no Python

**Do not use Python for cryptographic research or performance work in this
repository.** This applies to algorithms, field and curve arithmetic,
factor-base construction, relation collection, solvers, linear algebra,
experiment harnesses, benchmark drivers, correctness tests, certificate
verifiers, replay tools, and research result generation.

- Use **Rust by default**, integrating with the existing library and Cargo
  tests. Use an existing compiled C, C++, CUDA, or other native backend where
  the component requires it.
- Do not introduce Python prototypes, Python orchestration, embedded Python,
  or compiled wrappers that delegate this work to a Python process. Moving
  only a hot loop to native code does not satisfy this rule.
- When continuing work implemented in Python, replace the relevant execution
  path with a native implementation before extending it or running further
  research comparisons. A working Python harness is not an acceptable final
  deliverable. Use shell commands only for thin build/run orchestration.
- Preserve frozen inputs, historical measurements, source snapshots, and
  certificates as evidence. Do not delete or rewrite them to conceal their
  Python provenance. Label historical Python timings accordingly and rerun
  matched native baseline/candidate measurements before making new performance
  claims.
- For prime-field research, use distinct build, pre-call and post-call
  manifest names, and refuse replacement of a pre-call manifest. Label any
  later reconstruction as post-call evidence (adopted lesson
  `L-b9df3560e3b1`, 2026-11-15).
- For prime-field research, execute a separately copied immutable qualifier
  and capture its hash before calls. Edit a different template for later
  work (adopted lesson `L-9d758ede7873`, 2026-11-15).
- Older instructions that name Python scripts describe legacy tooling; they
  do not grant an exception. Preserve their mathematical contracts, fixtures,
  and accounting requirements in the native replacement.

## Model tiers

Owner rule, 2026-10-17: one model-tier topology across the owner's
repositories. The reference design is
[`docs/model-tiers.md`](https://github.com/aburan28/crypto-autoresearcher/blob/main/docs/model-tiers.md)
in aburan28/crypto-autoresearcher.

| tier | does here | Anthropic |
| --- | --- | --- |
| frontier | design, interpretation, claims, breakthrough review | Mythos (`claude-mythos-5`), Fable 5.1 (`claude-fable-5-1`) |
| core | the same when frontier is not needed; coordination and review | Opus 5.5 (`claude-opus-5-5`); OpenAI, GLM 5.3 and Qwen equivalents |
| director | compiles a decided experiment into a task card (`tools/task_card.py`: one format in every repository, copied byte-identical from crypto-autoresearcher, never edited here), then assesses the run | Sonnet 5.5 (`claude-sonnet-5-5`), [`experiment-director`](.claude/agents/experiment-director.md) |
| mechanical | runs the card through `tools/task_card.py run`, relays its output verbatim, computes nothing, refuses anything underspecified | Haiku 5.5 (`claude-haiku-5-5`, effort low), [`executor-mechanical`](.claude/agents/executor-mechanical.md) |

- **Frontier and core keep the reasoning**: the spec and preregistration,
  analysis (`ecbench compare` and `table` read-outs), the §5a pricing band and
  every cross-method ranking, success-criterion classification, claims, and
  every PR decision (open, fix, merge).
- **The relay.** Subagents do not nest in Claude Code, so the main session
  does every dispatch: it dispatches `experiment-director` in compile mode,
  relays the card it returns to `executor-mechanical` verbatim (adding
  nothing), then dispatches `experiment-director` again in assess mode with
  the executor's returned text. A card with a `specification_error` is not
  relayed; the reasoning tier fixes the spec.
- **The mechanical tier's output is an observation, never a result claim.**
  The director's assessment says only whether the run executed as specified
  and the relay was verbatim. What the numbers mean is decided by the
  frontier or core tier under the measurement rules below.
- **Subagent roster and pins.** The pins live in `.claude/agents/`; the tier
  decides the model, never the reverse. `executor-mechanical` is Haiku 5.5
  (effort low); `experiment-director` and `idea-generator` are Sonnet 5.5;
  `idea-synthesist` is Opus 5.5 (effort high); the independent reviewers
  `red-team` and `validator` inherit the session model at effort `xhigh`;
  their breakthrough siblings `red-team-breakthrough` and
  `validator-breakthrough` are Opus 5.5 at effort `max`. A claimed break,
  closure, or contradiction is reviewed only by the breakthrough siblings, in
  their own sessions.

## Default workflow: open the PR, check in, and land it

The repository owner's standing preference (owner, 2026-10-14) is that the
session which opens a PR stays with it until the PR is merged or closed. That
session checks in on the PR, fixes the CI failures and review feedback its
change causes, and merges once the PR is green and authorized. This replaces
the 2026-10-09 split, in which the authoring session stopped at the PR and a
separate small-model automation did the CI work and the merge.

**The authoring session** implements the change, validates it locally,
commits, pushes, and opens the PR (or updates the existing one). It then
follows the PR until it lands, under the check-in and merge rules below.

- **Open every PR ready for review (`draft=false`)**, whatever a tool or
  runtime defaults to. Before ending an update to an existing draft, mark it
  ready so reviews and checks that skip drafts (`llm-review`) can run. An
  explicit user request to keep a particular PR in draft is the only exception.
- **One PR per research lane, not per session.** Before opening a PR, look for
  an open PR from `lane/<lane>` for the same study (IC autolab, volcano,
  conductor gap, N83, ...). If there is one, push to it with
  `scripts/lane-push.sh <lane>` (merge commits, retried, never a force-push)
  and stop there: the lane PR carries your commits. Open a new PR only for
  work no lane covers; name new lanes after the study.
- **Keep a PR's head within 30 CI checks.** The sweeper holds a PR whose head
  ran more (`ci:over-budget`); split it by touched area instead.
- Review the final diff and confirm that the requested scope, relevant tests,
  evidence, and documentation are complete before opening the PR. Passing CI
  does not substitute for checking that the work is finished.
- **Lint the PR body before submitting it** (lesson `L-77b44d3fe205`, adopted
  2026-11-15). `pcc-gate` runs `python3 tools/pcc/pcc.py lint-prose --stdin` on
  the PR body and fails the required `gate` check on a strong-claim word
  without `[pcc:ID]` or `[pcc:unverified]`. Run it locally first; reword words
  that describe proposals, and cite or tag those that describe results.
- **Record the episode when the PR merges or closes** (owner, 2026-11-15).
  The session that owned the PR runs `python3 tools/autonomy_report.py
  add-episode` (task, class, PR, start and end, result, merged, CI state, each
  incident with whether it was fixed without a human) and one `add-intervention`
  per human message after the first prompt, classed by the rules in
  `benchmarks/agent-autonomy/README.md` (store the text's SHA-256, never the
  text). It records the matching `lessons.py outcome`. Both land with the next
  PR or a small follow-up. Fourteen days later any session records
  `set-check --check reverted` from `git log`.
- **Check in on PRs you opened.** Follow the PR's activity: CI results, review
  comments, merge-state changes, and merges or closes. Where the runtime
  provides PR-activity subscriptions (`subscribe_pr_activity`), use them. Where
  it provides scheduled check-ins (`send_later` or similar), keep one
  safety-net check-in about 50 minutes after the last activity, later ones
  about 4 hours apart, re-armed silently when nothing has changed. Stop after 3
  check-ins in a row that find nothing new, when the PR merges or closes, or
  when the user says to stop. Any new activity resets the count.
- **No busy polling.** Do not sleep in a loop, re-read check runs or job logs
  faster than the check-in cadence, or wait on a job in the foreground. The
  cadence limits apply to every runtime, top-tier models included.
- **Any runtime may do the CI work.** Claude Opus, Fable, and other top tiers
  may check in on, fix, and merge the PRs they opened, under the same rules as
  a small model. The owner's 2026-10-09 restriction on top-tier CI work is
  withdrawn.

**Merging** is part of the same flow. The authoring session does not ask for
another approval to merge a completed, passing PR unless a policy or reviewer
requires explicit authorization for that merge, and it follows these rules:

- **The merge set is three checks.** A pull request merges when `gate`
  (validation-gate), `size` (large-files), and `artifacts` have passed on the
  current head. Those are the only workflows that run on `pull_request`,
  besides the pull-request review and the autofix label queue. Rust lint, the
  workspace compile, ecbench, CodeQL, Lean, the release build, and the
  research workflows run after the change is on `main` (a push, usually
  limited to the paths that workflow names) or on their existing schedule.
  CodeQL runs weekly. `workflow_dispatch` runs one of them now. Do not wait
  on a pull request for a check that did not run, and do not put
  `pull_request` back on those workflows to chase a green box.
- Apply merge authorization to PRs created or maintained for the current user
  task, not unrelated PRs. An explicit instruction to leave a PR open, keep it
  as a draft, wait for review, or avoid merging overrides this default.
- Check the current PR head: the merge set above must have completed
  successfully. Pending, cancelled, timed-out, or failed checks in that set
  are not a pass. A skipped job counts as inapplicable only when its
  conditions or path filters justify that status; a required check must still
  be satisfied.
- **Checks that never start do not block** (owner, 2026-10-23). A check that
  no branch-protection rule or ruleset requires, and that has been queued for
  24 hours or more without starting (no runner picked it up), does not hold
  the merge, provided every check that did run on the current head passed.
  Name each such job and how long it waited in the merge commit message. A
  required check never falls under this: if one has not run, the PR waits and
  the session says so on the PR. A check that started and is still running is
  pending, not stuck.
- Fix failures caused by the change autonomously: read the failing check's
  log, reproduce the failure locally, fix it, and rerun the affected
  validation before pushing. Never skip, disable, or quarantine a test to get
  green, and never push an empty commit or close and reopen a PR to re-run CI.
  A failure that is not this change's (red on the base branch, or a service
  the diff does not touch) is reported on the PR with the evidence, not
  patched around. Offload merge conflicts to GitHub Copilot (next bullet) rather
  than resolving them yourself. Any new commit requires checking CI again for
  the new head. Do not bypass branch protections, required reviews, unresolved
  blocking review feedback, or required checks.
- **Merge conflicts go to Copilot first.** When a PR you maintain reports a
  merge conflict (`mergeable_state` `dirty`, or a conflict notice), post one PR
  comment asking `@copilot` to resolve it by merging the base branch into the
  PR head, without rebasing or force-pushing, and to keep the PR's scope
  unchanged (the GitHub MCP tools also expose Copilot assignment if a comment is
  not enough). This standing instruction authorizes that comment; do not ask
  again. Then:
  - Do not edit the conflicted files yourself while Copilot's request is
    pending; two resolvers on one branch create a second conflict.
  - When Copilot pushes, review its diff against both sides, regenerate
    lockfiles and generated files with the repo's tooling rather than by hand,
    and rerun the affected validation (`cargo check`, the touched tests). A
    resolution is not done until the PR head merges cleanly and CI is checked
    on the new head. Report Copilot's result as unverified until you have done
    this.
  - Resolve it yourself (merge the base in, never rebase or force-push a shared
    branch) only if Copilot declines or cannot act on the PR, pushes a
    resolution that fails validation, or has not responded after a reasonable
    wait; say in the PR why you stepped in.
  - Conflicts in frozen evidence, ledger rows, or claim files are never
    resolved by picking a side: report them to the user.
  - A conflicted binary file (PDF, PNG, archive) is never resolved by keeping
    both sides, which concatenates the two versions: take one side and
    regenerate it. `binary-merges.yml` fails a merge whose result matches
    neither parent unless the merge names the file with a
    `Binary-Regenerated: <path>` trailer.
  - If Copilot is unavailable in the session (no GitHub MCP access, plan
    limits), say so and fall back to resolving it yourself.
- If a documentation-only change legitimately triggers no CI, verify the
  workflow filters, inspect the diff, and run any relevant local validation.
  State that no CI applied; do not claim that nonexistent checks passed.
- Auto-merge is already enabled when the PR was opened, so merge with the
  repository's permitted merge method and an expected-head-SHA guard where
  supported. Confirm that GitHub reports the PR as merged, then record the
  merge commit and validation outcome on the PR.
- If access, required external review, a persistent CI failure, or another
  concrete gate prevents merging, report that blocker precisely on the PR
  rather than asking the user to repeat the authorization already given.
- If automatic approval review rejects a merge for lack of authorization,
  leave that PR open and ask for explicit approval naming the exact PR. Do not
  retry by changing tools, branches, accounts, or merge route. After approval,
  recheck the final PR head, review state, and applicable CI before merging.

## Research work belongs in pull requests

**Always create or update a PR for repository-related action items, research
plans, benchmark protocols, and workstream closeout checklists, including
Markdown-only planning work. Do this in the same task without waiting for the
user to ask again.** Commit the plan in the relevant repository and return its
PR link; a chat response, scratch file, or Library copy alone is not delivery.
Update an existing relevant PR when appropriate rather than creating duplicates.
An explicit user request not to create a PR overrides this default.

A planning PR may merge when the plan itself is complete and its applicable
checks pass. Keep unperformed experiments and measurements marked pending;
merging the plan does not close the underlying workstream. Track execution,
evidence, and closeout in linked follow-on PRs and update the checklist as work
lands. Apply the PR and merge rules above to each completed deliverable.

Treat an experiment as repository work, including a negative or inconclusive
result. A research decision, preregistered protocol, reproducibility fix, or
rejected hypothesis also belongs in a PR, even before an outcome exists.
Before running an experiment, state the hypothesis, frozen inputs, reference,
success and stop conditions, and cost accounting in a versioned protocol.
Make each bounded experiment or compatible group of experiments a focused
branch and PR. Commit the code, configuration, seeds, source and input hashes,
commands, compact raw results, verification receipts, analysis, and decision
in that PR. Link follow-on PRs to their dependencies; do not let a local note,
untracked worktree, chat summary, or published page be the only record of a
finding or a decision.

Preserve failures, timeouts, and regressions. Do not overwrite an earlier
run. If raw output is too large for Git, commit a manifest with its content
hash, byte count, durable accessible location, extraction command, and the
small derived data needed to audit the claim. A local absolute path alone is
not a durable location. Label unmerged work and unreviewed replays as such;
a downstream claim cannot silently treat them as accepted evidence.

For performance changes, the existing frozen-suite, full-cost, matched-rho,
and scoreboard requirements in sections 1–8 still apply. A PR that reports
only a stage measurement reports that stage's cost or speedup, with its
matched interval, and leaves unmeasured end-to-end fields unset. Open or update
the PR as part of the iteration and stop there; the merge automation of the
default workflow above merges it once its evidence, review, and CI gates are
satisfied.

## The rule: boundary, table, ratio

For a quantitative performance comparison, report candidate and matched
reference costs in the same unit, with their ratio and correctness checks.
Include a proved lower bound when it informs that comparison. Recognize
constant-factor, component, construction, and whole-pipeline improvements at
their respective scopes; a flat ratio to a lower bound does not erase them.

### 1. State the boundary before measuring

A comparison can use a proved lower bound and a measured reference. They
answer different questions:

- A **floor**: a lower bound from a counting or generic-group argument.
  Example from `research/notes/index-calculus/RESEARCH_RESIDUAL_WALKS.md`: a generic algorithm's
  expected relation yield from `P` residuals is at most `γP²/2n`, so the
  count factor obeys `κ_total ≥ √(2(B+1)/γ)`.  That floor moves only
  with the factor-base size `B` and the automorphism order `γ`, so it
  cannot be tuned away.
- A **reference**: the cost of the best algorithm that already solves
  the same problem, measured in the same unit on the same instances.
  For the discrete logarithm that is Pollard rho, run on the same group,
  with the same operation accounting.

Name the reference and any applicable floor before measuring the comparison.
State the floor's assumptions and use the reference for the actual component
or pipeline being measured. A new construction can proceed while its cost
analysis is being developed.

### 2. Report one table, one unit

One table, one unit, every variant as a row, including the reference and
the unmodified baseline.  Pick the unit so that the boundary is a
constant in it.  This repository's ECDLP threads use

```
S = total operations / sqrt(n)
```

which makes rho a flat `S ≈ 1.3` at every size and turns "is this
better than rho" into reading one column.  Every cost the method incurs
belongs in `S`: precomputation, table setup, relation verification,
linear algebra, and any work an oracle does per call.  Convert foreign
units with a measured conversion factor and record it, for instance the
63 field multiplications per curve addition measured on `F_{p³}`.

**Name the measured interval.** For a cold end-to-end comparison, `S` covers
setup through the recovered logarithm and the ratio is
`speedup = baseline_total_operations / candidate_total_operations`.
For a component comparison, use the same component interval in both arms and
report the ratio as that component's speedup. A relation search, decomposition
oracle, solver, or linear-algebra improvement is a valid scoped result.
Leave unmeasured pipeline costs unset. An explicit comparison against rho
includes the full method at growing sizes under the reference rules.

The table must carry a **ratio column** against each boundary, and a
correctness column.  A row without a verified answer is not a result.

### 3. Describe what improved

Classify every change, in the note, as one of:

| class | what moved | what it means |
|:--|:--|:--|
| **advance** | ratio to the floor fell | the method does something a generic algorithm cannot |
| **engineering** | `S` fell, ratio to the floor flat | an improvement to the baseline: a success (see "Success criterion") |
| **relabelling** | headline count fell, `S` rose | work moved somewhere the headline does not look |
| **accounting** | numbers changed, algorithm did not | a correction; say so and do not claim the gain |

All four are worth committing.  Advance and engineering are both
improvements, and every improvement over the baseline is a success
("Success criterion: iterative improvement of the index-calculus
baseline").  Label each row, because the failure mode this rule exists
to prevent is reporting relabelling or accounting as an improvement, or
engineering as an advance.

The relabelling class is not hypothetical.  In §10.5 of the
residual-walk note a triple-decomposition oracle cut the walked count
from `16.3` to `0.15`, a hundredfold move in the number the thread had
been tracking, while total cost got `4.6×` worse: the count was not
reduced, it was paid for per residual instead of per step.

### 3a. Write the cost chain before claiming a change

Adapted from rule 12 of the Trail of Bits constructive-cryptography skills
(`trailofbits/constructive-cryptography/skills/README.md`, MIT). Before a
row, note or PR states that a method got cheaper, write the claim as a chain
from the incumbent's cost to the candidate's, in the counted unit of §2:

```text
C(incumbent) = Σ phases (relations, linear algebra, descent, unpriced work)   def., record R0
             = C'  (restructure: name the accounting identity)                 equal by construction
             → C'' (replace one component: name it, its measurement or bound)  measured Δ ± CI
             = C(candidate)                                                    def., record R1
```

- A **restructure** line regroups, renames, moves work between phases or
  prices it differently. It must leave the total unchanged, so it can never
  carry a gain. If it changes the total, it is an accounting correction
  (§3, class *accounting*) and the chain restarts from the corrected
  incumbent.
- A **replace** line swaps exactly one component (an oracle, a factor
  base, a walk, a linear-algebra kernel) and carries a measured or bounded
  change with its interval, priced across the §5a band.
- A line never does both. A change that needs both is split: first the
  restructure that makes the component stand alone, then the replacement.
- The interface stays: target, curve (ICV1 slug), success probability and
  the unit are the same on the first and last line. A line that changes
  any of them compares different problems; stop.

The §3 class follows from the chain: only replace lines count, and a chain
whose replace lines sum to a gain while the total rose is *relabelling*.
Put the chain in the note and the PR; `ecbench-bounds` challenges cite it.

### 4. Declare the falsification target in advance

State, in the note, the numeric condition that would make the thread a
success, and the conditions under which you would abandon it.  Make it
specific enough that a later run either meets it or does not.

The residual-walk note's target is a good model: `κ_total / κ_floor <
0.9` on a hybrid at fixed `B`, with a correct answer on every seed, zero
relations failing verification, and zero trivial collisions counted as
relations.  It also lists what is inadmissible: changing `B` or the
decomposition size, changing the operation accounting, skipping
verification, choosing favourable seeds, or counting dependent
relations.

### 5. Separate the phases, and price all of them

State whether an exponent describes a component or the whole method. For a
whole-method claim, account for every phase and identify which dominates at
each size. Fit empirical exponents over at least four sizes and report the fit
next to the prediction; distinguish a derived bound from a fitted exponent.

This is where the residual-walk thread went wrong once and had to be
corrected: three rounds priced the relation phase, quoted a crossover
with rho at `2^96`, and left the linear algebra unpriced.  When it was
measured it turned out to grow as `n^{0.68}` against relations at
`n^{1/3}`, so the method's cost bottoms out near `200×` rho around
`2^{50}` and rises after.  The `2^96` was a statement about one phase
and had been read as a statement about the method.

### 5a. Price the unpriced work on every arm, the reference included

Owner rule, 2026-10-15. Almost no ECDLP cost in this repository is
complete, and the rho baselines are no exception. Rho, BSGS and the
kangaroo leave canonicalisations, partition hashes, table inserts and
lookups unpriced. Index-calculus arms are complete only on curves that
have a pinned timing calibration (`calibration_pinned_units`; in the
2026-10-15 pilot that was Koblitz `n = 13` and `n = 23` but not `n = 19`).
A "complete IC against lower-bound rho" comparison is therefore
lopsided, and before this rule several were reported that way
(`research/ic_frontier_campaign_20261015/pilot/FINDINGS.md`).

Every cross-method comparison and every ranking must:

- **List every unpriced counter for every arm**, references included,
  with its count. An arm that names a counter but does not emit its count
  cannot be ranked. Report it as a lower bound and record the missing
  emission as an implementation gap to fix.
- **Price the unpriced work at several weights**: at least 0, 0.1 and 1
  group-addition equivalents per native operation, applied the same way
  to every arm. Pinned calibrations may be added as a further point, but
  they never replace the band.
- **A calibrated weight for field-arithmetic counters** (owner, 2026-11-12).
  Some counters count base-field multiplications: the `mod p` or `mod r`
  mulmods of linear algebra, smoothness tests and root finding. Price those
  counters at a per-host calibrated weight `w_cal` as well as the band. Here
  `w_cal` is the time of one native mulmod divided by the time of one group
  addition on the same curve and host. Measure it with `perf-ipc` on an
  isolated host where one is available. Otherwise use a best-of-N timing,
  labelled as such. Record `w_cal`, its method and the host in the run's
  metadata. Report the order of the arms at `w = 0`, at `w_cal` and at
  `10·w_cal`. When it holds at all three, report the pair as **ranked at
  calibrated price** next to the band verdict. The band verdict is still
  reported and still governs the leaderboard tables. Reason: the IC positive
  control (`research/ic_positive_control_20261112/`,
  `problems/section5a-band-cannot-show-a-known-ic-win.md`) measured a mulmod
  at about 0.005–0.013 GAE on lab hosts. At the band's 0.1 and 1 GAE, an IC
  expected to cost less than rho read 5.8× and 31× rho at p = 65,537, so the
  band alone could not tell that win from a loss.
- **Rank only where the conclusion holds at every weight in the band.**
  If the order of two arms changes inside the band, report them as
  unresolved at that boundary, never as a win for either side.
- **Never compare a calibrated cost on one side with an uncalibrated one
  on the other.** If a calibration exists for only some arms or sizes,
  use the band alone.
- **The band prices operations, not bytes** (owner, 2026-11-01). A
  memory-size counter (`residual_table_bytes_uncharged`,
  `factor_base_vec_bytes_floor_uncharged`, `native_table_bytes_uncharged`)
  is still listed with its count for every arm, but is not charged `w` and
  cannot block a ranking. The list is `NON_OPERATION_COUNTERS` in
  `src/cryptanalysis/ecbench/band.rs`, by name, so committed records replay
  unchanged. A new byte-valued counter is added there; do not name a byte
  count `*_uncharged` without doing so. The audit and the re-run studies are
  in `research/ic_byte_counter_pricing_20261101/`.
- **The band prices the table oracles' counted per-step inserts** (owner,
  2026-11-08). The index-calculus table oracles (`wwalk` and the pair
  tables, every oracle in `src/cryptanalysis/ic_framework/plugins.rs` that
  calls `table_counted()`) do one hash-table insert per walk step and
  record it only as `work_native.table_insert_attempts` behind the marker
  `counted:table_insert_attempts`, never in `cost.unpriced`, while
  prime-field rho lists its per-step canonicalisation there and is charged
  for it. From 2026-11-08 the band's default reading adds the phase sum of
  each counter in `TABLE_WORK_COUNTERS` (`src/cryptanalysis/ecbench/band.rs`,
  today `table_insert_attempts`) to `U` on every arm, when and only when
  some phase of the record carries the matching `counted:<name>` marker;
  counted work without its marker is not known to be complete and is not
  charged. A band or comparison computed before that date is the
  pre-2026-11-08 reading and is labelled so where it is cited again; its
  frozen evidence is not rewritten. `ecbench band --no-price-table-work`
  and `ecbench compare --no-price-table-work` (`band::Pricing::
  pre_2026_11_08()`) reproduce it, `comparison_id` and plain
  `comparisons/a__b.json` name included; a default comparison carries the
  priced counters in its identity and is saved under its id. The record
  format does not change: the price is a reading of the committed
  `work_native` maps, `cost.unpriced` and the phase `native` maps are
  written as before, and committed sessions replay "identical". The
  numbers under both readings: `research/ecbench_table_work_pricing_20261108/`.

This applies to `ecbench compare` read-outs, tables, frontier syntheses,
ledger rows, papers and PR descriptions. A ratio produced before this rule
is relabelled as a lower-bound comparison where it is cited again. Its
frozen evidence is not rewritten.

### 6. What does not count

- A ratio improved by moving the boundary, changing the unit, or
  dropping a cost from the budget.
- A count lowered without the total falling.
- An extrapolation presented as a measurement.  Extrapolate freely, and
  mark it as extrapolation with the exponents it rests on.
- A run whose answer was not checked against the planted secret, or a
  new oracle not cross-checked against the one it replaces on every
  input of a full run.
- Wall-clock time as the headline.  It belongs in the table as a
  practicality note, never as the metric; operation counts are the
  metric because they survive hardware.

### 7. Keep the scoreboard current

The table lives in two places and both are part of the deliverable:
the prose table in the thread's note, and the drawn one in
`docs/index-calculus-scoreboard.html`.  **A round is not finished until
the page carries its numbers.**  The page is the thing a reader opens
first, so a stale page is worse than no page: it reports a verdict the
measurements no longer support.

The repository file is canonical.  Edit `docs/index-calculus-scoreboard.html`
and let any published copy be a republish of it, never the other way
round; a figure that exists only in a published copy is lost.

What a round owes the page:

- **A row per variant**, in the same unit and against the same
  boundaries as everything already on it.  A new variant that does not
  fit the axis means the axis was wrong, not that the variant is
  exempt.
- **A superseded figure moves, it does not vanish.**  When tuning
  lowers a cost, the old value becomes the "before" mark on that row.
  Deleting it hides the size of the gain and lets an engineering step
  read as an advance.
- **The class chip set** to advance, engineering, relabelling or
  accounting, by the test in §3 and not by how the change felt to make.
- **The exponent panel and the boundary facts re-derived** whenever a
  fit changes or a phase is priced for the first time.  An exponent on
  the page that predates a new phase measurement is the §5 mistake,
  drawn.
- **The verdict rewritten** when the verdict changes.  The sentence at
  the top of the page is a claim; a round that falsifies it rewrites it
  in the same commit.

Two standing constraints on the page itself: every number on it comes
from the frozen experiment files, so the page cites and never computes;
and anything that is not a measurement stays marked as what it is, an
extrapolation with the exponents it rests on named.

The update rides in the commit or pull request that lands the
measurement.  It is not a follow-up task, and "the page is out of date"
is not a state this repository has.

#### 7a. Every result lands on the dashboard, in the same PR

The scoreboard is a dashboard with several panels that each carry a
view of the latest results, and a result that reaches one panel and not
the others leaves the page contradicting itself.  **Any PR that lands a
new measurement, a reclassification, a corrected reference or a
withdrawn claim updates every panel that cites that kind of result,
before it merges.**  "Latest results" means the newest verified figure
in each regime, with the figure it supersedes kept as "was".

Which panels a result owes, by kind:

| result kind | panels that must change |
|:--|:--|
| any IC/rho ratio, cold or online, elliptic or not | the progress chart (`#lab-progress`): a new point in its series, dated the day the PR merges, with reference quality, class, anchor and source |
| a new best in any regime of the best-of table (`#lab-best`) | that row, the old figure kept as "was"; a new regime is a new row |
| a cross-method `ecbench` session (§12) | the every-candidate panel (`#lab-ecbench-all`) or a new panel in its unit, and a progress-chart point for its best cold one-target IC cell |
| a tournament or autolab round | the round's own panel, the reference-history table where the reference changed, and the chart |
| a boundary, exponent or phase priced for the first time | the exponent panel and the boundary facts (§7 above) |
| a verdict change | the sentence at the top of the page and the best-of table's first row |
| a whole-pipeline measurement on any curve, a newly priced curve or a re-matched reference | the index-calculus leaderboard, regenerated from the round's frozen files (§7b) |

Rules that make this checkable:

- **The chart's data is one file.** `docs/ic/progress-timeline.json` is
  canonical for the progress chart; the copy embedded in the page
  (`<script id="progress-data">`) and the "every plotted point" table
  are regenerated from it, never edited on their own.  CI
  (`scripts/site/test_build.py`) fails the build when the embedded copy
  differs from the file or a point in the file is missing from the
  table.  Add a point to the file, re-embed, add its row.
- **A point per result, not per PR.** A PR that lands two results in two
  regimes adds two points.  A PR that only re-prices an existing figure
  adds a point with the `accounting` class and keeps the old point.
- **Dates are merge dates.** The chart shows when a figure landed on
  `main`, so a point's date is the day its PR merges, and the file's
  `updated` field is never older than its newest point.
- **The page is republished when it changes.** GitHub Pages republishes
  `/scoreboard/` from `main` on every merge, automatically.  Any other
  published copy (a claude.ai artifact, a snapshot sent to someone) is
  republished from the canonical file in the same task that changed it,
  or it is named as stale where it is linked.
- **Reviewing a PR means reading the dashboard diff.** A reviewer, human
  or agent, checks the scoreboard change against the result's own
  frozen files before approving: the number on the page is the number in
  the session, table or report it links to, and nothing on the page is
  computed from another number on the page.

A PR that lands a result without its dashboard update is incomplete, and
the merge authorization in the default workflow above does not cover merging it.

#### 7b. Keep the leaderboard current

`docs/ic-leaderboard.html` is the same evidence curve by curve. For every
curve priced end to end it shows the best recipe, the phase split of `S`,
the ratio to the matched reference and to the floor, every recipe on every
curve, the per-phase exponents, the decomposition oracles, and every curve
the repository names. Its Markdown and data twins are
`docs/ic/LEADERBOARD.md` and `docs/ic/leaderboard.json`. It is held to §7's
and §7a's standard: **a round that changes what the leaderboard shows is not finished
until the leaderboard shows it**, in the same pull request.

- **When.** Update it in the PR that lands any of these:
  - a whole-pipeline measurement: a new ledger section, a new ladder or
    recipe, or a re-run that supersedes a row;
  - a curve priced end to end for the first time;
  - a reference re-matched;
  - a rule change that redefines the primary comparison, as the
    one-target rule did;
  - a change to `docs/curves/registry.json`, which the page's roster reads;
  - a big improvement in a phase or component (an engine, filter, oracle,
    solver or kernel) that moves no whole-pipeline row (owner, 2026-10-15):
    it gets its own section outside tables A–C, generated from the study's
    frozen summary with the before figure kept and its class (usually
    engineering) named, as the linear-algebra engine section was added for
    `research/la_engines_20261014`.
- **How.** The page is generated, never edited by hand.
  - Point `SOURCES` in `scripts/build_ic_leaderboard.py` at the round's
    frozen files.
  - Keep a superseded figure as the row's "before" mark.
  - Keep batch or legacy figures labelled as diagnostics, never as the
    headline.
  - Regenerate with `python3 scripts/build_ic_leaderboard.py` and commit
    all three outputs.
  - The builder reads only committed frozen files, so a number that is
    not in one cannot reach the page.
- **Agree with the scoreboard.** The leaderboard's headline figures must
  match the ledger and the verdict on `docs/index-calculus-scoreboard.html`.
  When they disagree, one of them is stale: fix it in the same PR.
- **Enforced in CI** (`ic-leaderboard`). `--check` fails when any output is
  stale against the files the builder reads. It also fails when the ledger
  has a section later than `LEDGER_COVERED_THROUGH`, because the check
  cannot otherwise see evidence the builder does not read yet.
  - When a new section changes the page, point `SOURCES` at it,
    regenerate, and raise the number.
  - When it changes nothing on the page (a stage diagnostic, a plan),
    confirm that, and raise the number.
- **Published copies** are republishes of the repository file, as in §7.

#### 7c. Keep the lab browser current

`docs/browser/` (published at `/browser/`) is the searchable index over
everything the workstream names: every curve in the ICV1 registry with
its invariants (family, field, trace, order, subgroup order, cofactor,
endomorphism discriminant) and identities (ICV1, EC1, curve UID, retired
names), every `ecbench` method (`ECM1`) and factor base (`FB1`) a
committed session ran, every tournament candidate identity (`IC1`) the
repository writes, every tournament round, every committed `ecbench`
session, the vocabulary of oracles, solvers and factor-base families,
and the **yield ledger**: one row per index-calculus run with its curve,
target, factor base, oracle, solver, trials, relations, yield, lookups,
matrix rank and the record's `solver` block (the ICMS `pdp_metrics`:
system shape, solving degree, Macaulay and SAT figures), which the
`ecbench` database exposes as the `ic_yield` view. It is how a reader
gets from a number on the scoreboard to the curve, algorithm and
evidence behind it, and how a candidate combination is informed: a
yield describes a stage, while whole-pipeline `S` compares complete solves.

- **Generated, never edited.** `docs/browser/data.json` is written by
  `python3 scripts/build_lab_browser.py` from committed files only (the
  registry, `docs/ic/leaderboard.json`, `research/ecbench_*/sessions/*`,
  the tournament's `runs/`, and the files that mention IC1 identities).
  It computes nothing beyond a mean over a session's own verified runs.
- **Regenerate it in the PR that lands** a new curve in the registry, a
  new `ecbench` session, a new tournament round, a new candidate identity,
  or a leaderboard change. CI (`ic-leaderboard`, `--check`) fails when the
  file is stale, and the site build test fails when a cross-reference in
  it does not resolve. The check ignores how many files mention each
  candidate identity, and which: those counts change with any report that
  writes one and refresh on the next regeneration.
- **Every identity is a link.** A curve page links to the leaderboard
  rows, sessions, factor bases, rounds and candidates that cite it; a
  session, method, factor base or round links back to its curves. A new
  kind of record gets a view and a join, not a free-text mention.
- **The page renders data with DOM nodes only**, never `innerHTML`, like
  the status dashboards; the site test pins that.
- **Unregistered references stay visible.** A tournament cell or
  candidate on a curve the registry does not hold is shown as
  "not in the registry", never dropped or silently mapped; registering
  the curve (§11) is the fix.

#### 7d. Dashboard coverage is a pre-merge contract

The leaderboard, scoreboard, progress timeline and lab browser are one
published research index. **Every PR that changes a curve, frozen IC/rho
result, factor base, recipe, phase cost, validation status or reference must
update all affected views in that PR.** A new study that does not qualify for
the priced tables still needs a clearly labelled diagnostic or a documented
exclusion. Reviewers check the dashboard diff against the frozen source,
including losses, superseded figures and unresolved identities, before merge.

- **All named curves remain findable.** The ICV1 slugs in the registry,
  leaderboard roster and lab browser must agree exactly. The priced subset
  is counted separately; absence of a measured whole-pipeline cost is shown
  as unpriced, never inferred from a stage diagnostic. A new curve or result
  must not silently fall out of search because another generated index is
  stale.
- **Every priced row is auditable.** Keep its ICV1 curve, exact regime and
  target count, measured factor-base size and recipe, FB1 linkage status,
  frozen source, validation status, phase costs, matched-rho quality, unit,
  and the previous figure when superseded. Show counted totals as `2^x`
  operations only when those totals are in the frozen record. Show IC/rho
  with `1.0×` as parity; do not mix cold one-target and batch references or
  timing and counted-operation units. A missing exact FB1 identity remains
  explicitly unreconciled, even when a base size is known.
- **Progress is append-only evidence.** Every new numeric comparison gets a
  source-backed point in `docs/ic/progress-timeline.json` with merge date,
  class, reference quality and anchor. Corrections retain the old point and
  mark the new one `accounting`. Update the scoreboard's embedded chart and
  point table from the canonical timeline in the same PR.
- **Check before merge.** Run `node scripts/check_ic_dashboard_coverage.mjs`
  and the leaderboard and browser `--check` commands on complete inputs.
  The coverage check enforces registry/roster/browser equality, source
  digests, required row fields and timeline metadata; the generators enforce
  exact outputs. The `ic-leaderboard` workflow runs this on matching PRs,
  not only after a push to `main`. A missing frozen or artifact-store input
  is a failed check to repair or report, not a reason to call the page current.
- **Publish and verify.** After merge, confirm the Pages workflow succeeded
  and the public `/scoreboard/ic-leaderboard.html` and `/browser/` reflect
  the merged source. A local preview or open PR does not establish that.

The architecture and coverage limits are recorded in
[`docs/ic/DASHBOARD_COVERAGE.md`](docs/ic/DASHBOARD_COVERAGE.md). Frozen
files and replay receipts are the source of truth. The existing `ecbench`
SQLite database is a rebuildable query index. Do not make a mutable hosted
database, including RDS, the sole source for a published result.

### 8. Use the frozen benchmark to establish end-to-end speedups

Every index-calculus performance iteration must use the
[frozen regression suite](research/index_calculus_baseline_20260914/regression/README.md)
before claiming a gain. The accepted target is
`research/index_calculus_baseline_20260914/regression/results/baseline_v2/`.

Every incremental performance change must include a saved baseline/candidate
benchmark comparison, even when it regresses or no gain is claimed. Rerun
the frozen inputs and include fresh holdouts; a candidate-only run does not
complete an iteration. The equivalent-suite exception below still applies.

- **Run the reference and candidate.** Follow the suite's `run.py` and
  `compare.py` commands with the full 60 inputs, both configurations and all
  three repetitions. Preserve the contract, input hashes, counter definitions
  and algebraic-only rejection control. Save each iteration in a new directory;
  never overwrite the baseline. For other encodings or field families, freeze
  an equivalent matched suite under the
  [parent accounting contract](research/index_calculus_baseline_20260914/ec_index_calculus_contract.json)
  and document why the WDSat protocol is inapplicable.
- **Measure the complete ECDLP pipeline.** In addition to that solver regression,
  run matched baseline/candidate full-DLP experiments on identical curves,
  subgroups, factor bases, targets and seeds, including independent holdouts.
  Charge setup/precomputation, target generation, encoding, failed attempts,
  solving, extraction/lifting, verification, filtering, relation-matrix work
  and final scalar recovery, using exclusive accounting. Verify `[k]P = Q`
  for every completed test; retain failures, timeouts and OOMs. Compare equal
  verified workloads; missing completions block an unqualified end-to-end claim.
  Report cold cost first and name the target count for any warm amortization.
- **Require a measured total-cost improvement.** Define
  `speedup = baseline_total_operations / candidate_total_operations`.
  An end-to-end claim requires this ratio greater than one in the same
  calibrated operation unit, with all phases priced and correctness preserved.
  Report `S` and ratios to the matched rho reference and applicable floor.
  Runtime claims additionally require paired baseline/candidate reruns on
  matched hardware/resources and a 95% paired confidence interval excluding
  no improvement; wall time remains secondary.
- **Keep solver gains in scope.** Passing `compare.py`, meeting its optional
  20% conflict target, or reducing Gröbner/F4 time alone does not establish
  an end-to-end speedup. The current corpus measures a solver stage.
  If full-pipeline costs or conversions are missing, leave them null and
  report a stage diagnostic; do not infer a full-DLP result.
- **Commit the evidence with the claim.** Preserve raw runs, source/configuration
  hashes, certificates, phase costs and comparison output, including regressions.
  Update the research note and canonical scoreboard in the same PR, retaining
  the prior baseline and classifying the change by §3.

### 8a. Require m=83 for high-fidelity ECC2K-130 IC evidence

For every index-calculus improvement intended to transfer to ECC2K-130,
**always use m=83 as the highest-fidelity smaller-curve confidence gate**
before claiming that the improvement survives scaling toward m=131. Use the
same Koblitz family as the challenge:
`E_0: y² + xy = x³ + 1` over `GF(2^83)`. Its group order is
`4 * 2417851639230796216685689`, with the second factor prime. A verified
polynomial-basis modulus is `z^83 + z^45 + z² + z + 1`; a different basis
is acceptable only when the field representation and conversions are recorded.
Freeze the exact curve, basis, prime-order subgroup, generator, and cofactor
clearing in each candidate/workload manifest. Frobenius has 83 phases on
nonidentity points in that subgroup, and `ord_83(2) = 82`, so the nontrivial
cyclotomic block is irreducible over `GF(2)`, as for m=131.

- Use smaller degrees, including m=53, for smoke tests, solver tuning, and
  inexpensive falsification. They do not discharge the m=83 gate.
- On m=83, run the unmodified baseline and candidate with matching curve,
  subgroup, factor-base policy, targets, seeds, resource limits, and independent
  holdouts. Preserve failed searches, timeouts, and out-of-memory outcomes.
  Apply the full-cost, verified-DLP, matched-rho, and scoreboard rules above;
  a solver-only or relation-only gain remains a stage diagnostic.
- If the m=83 comparison is missing or incomplete, report that explicitly and
  leave high-fidelity ECC2K-130 improvement unestablished. A successful m=83
  result is evidence at m=83; any transfer to m=131 remains an extrapolation
  until separately checked there.

### 8b. ECC2K-130 is the reference family; disclose subfield structure

User direction, 2026-09-28: the ECC2K-130 binary Koblitz challenge is the
archetype for this workstream. The challenge field is GF(2^131); "130" in
the challenge name is not the field-extension degree. Use smaller members
of the same E_0 family for exploratory evidence, and record the exact field,
curve, subgroup and Frobenius action. A generic binary curve, another
Koblitz model, or an isogenous neighbor is not silently the same instance.

Say **no proper intermediate subfields over GF(2)**, not "no subfields".
GF(2^m) contains GF(2^d) exactly when d divides m. In every case GF(2)
is present.

| Field degree m | Proper intermediate subfields over GF(2) | Evidence role |
| --- | --- | --- |
| 31 | None | Primary exploratory size; disclose its different Frobenius-module structure |
| 51 | GF(2^3), GF(2^17) | Composite-degree comparison; keep subfield-dependent findings separate |
| 53 | None | Additional prime-degree exploratory comparison |
| 83 | None | Required smaller-curve confidence gate under section 8a |
| 131 | None | Exact challenge field; target-specific conclusions require separate evidence |

- Use m=31 as the primary exploratory size when a smaller instance is needed.
  Preserve the m=83 requirement in section 8a. A result at 31, 51 or 53
  does not replace that gate.
- Prime extension degree alone does not guarantee structural fidelity.
  In particular, ord_31(2)=5, whereas ord_53(2)=52, ord_83(2)=82 and
  ord_131(2)=130. Thus the nontrivial cyclotomic block splits at m=31,
  unlike the irreducible block at 53, 83 and 131. State this difference
  whenever an argument uses invariant linear subspaces or that block.
- Label methods that depend on a proper intermediate subfield as such.
  A gain at m=51 that uses its subfields cannot support a claim at
  m=31, 53, 83 or 131 without a separate applicable argument and evidence.
- Distinguish a curve defined over GF(2) from its field of rational points.
  Koblitz coefficients in GF(2) do not place all challenge points in GF(2).
  Absence of an intermediate field does not remove Frobenius or rule out
  every Weil-restriction formulation.
- Keep field degree m, subgroup order r, and polynomial-variable count
  separate in all manifests and reports. Matching bit counts is not
  matching instances.

For the general-algebra follow-up and its current limits, see
[SPARSE_ALGEBRA_FOLLOWUP.md](SPARSE_ALGEBRA_FOLLOWUP.md).

### 9. AWS GPU hosts use the `meow34` key pair

For AWS EC2 benchmark and validation hosts, including G7/G7e instances, use the
existing EC2 key-pair name **`meow34`** when launching the instance.

- Launch with `--key-name meow34` (or the equivalent SDK/IaC setting).
- For local SSH, use the private key file `meow34.pem`, e.g.
  `ssh -i meow34.pem <user>@<host>`.
- Never commit, print, upload, copy into artifacts, or otherwise expose the
  contents of `meow34.pem`. The repository should contain only the key-pair
  name and usage instructions, never the private key material.
- Ensure the local private key is mode `0600` (for example,
  `chmod 600 meow34.pem`) before SSH use.
- Agents must not create a replacement EC2 key pair merely because the private
  key is unavailable in their environment. If `meow34.pem` is not mounted or
  accessible, report that access blocker and continue with non-SSH work where
  possible.

### 9a. Experiments default to Iso Lab on EKS Spot

Use [isolab-eks](.agents/skills/isolab-eks/SKILL.md) for supported x86 CPU
experiments and benchmarks. Freeze the requested spec, source/image identity,
resources, deadline and acceptance criteria, submit the job, and retain its
receipt. The experiment runs in a pod in cluster `isolab`, namespace `isolab`,
region `us-east-2`, account `104186811093`. Karpenter starts Spot workers;
`cpu-spot` serves ordinary work and `cpu-l2-spot` serves native L2 benchmarks.
Follow the owner cost ceilings in [COST_CONTROLS.md](taskq/deploy/eks-karpenter/COST_CONTROLS.md):
24 worker vCPUs / 160 GiB total, with no automatic quota or cap increases.
Before any EKS/IsoLab build or run, commit and push the exact experiment code,
protocol, configuration and launch command to GitHub; retain the publication
check receipt. Publish outcomes, including failures, in the same experiment PR.
Record a finite dollar ceiling, CPU/RAM, original deadline and total retry
allowance before spending; charge build, idle, failed and interrupted attempts.
Queue work that cannot fit. Never bypass a budget stop through another pool,
account, region, provider or a renamed retry.

- **Use existing authentication.** Verify the caller with
  `aws sts get-caller-identity` and check the required permissions using
  [ACCESS.md](taskq/deploy/eks-karpenter/ACCESS.md). Keep a working AWS
  role/profile; do not request new keys or SSO setup merely because an agent
  session is new. Never embed credentials in cards, requests or artifacts.
- **Submit from the agent.** Use an installed EKS MCP connection, or the
  portable `remote/validate-request` and `remote/launch-remote` clients under
  `taskq/deploy/eks-karpenter/`. CodeBuild supplies the private cluster route
  for remote callers. Missing local kubectl or MCP does not require a backend
  change. Long launches run in the background with their request/build identity
  retained; reconcile an ambiguous submission before retrying.
- **Build identity is required.** Use the requested spec and an image built
  from its tested commit. The main-only GitHub workflow is usable only after
  its reviewed implementation and matching OIDC trust are available. A source
  label on the deployed fixture does not build that source. Report a missing
  image/build route instead of running a different experiment.
- **Earn the result.** Require native L2, replay and A/A admission for an L2
  benchmark, and download and verify S3 payload hashes. A successful pod is
  not enough. Preserve failures and keep all original measurement thresholds.
- **Resume explicitly.** Requested resumability uses CRIU plus EBS snapshots
  through `isolab.eks.resumable/v1`, with compatible workers and a fresh
  measurement epoch after interruption. Ordinary request-v1 is non-resumable.
  Report unsupported workloads or restore compatibility before launching them.
- **Preserve other requirements.** An explicit local, GPU, ARM, bare-metal or
  L3 request retains its requested environment and gates. Do not silently route
  an unsupported workload to a different backend. Local builds, unit tests,
  static checks and analysis of existing results remain development work.

Claude's experiment director freezes the EKS client commands and environment in
the existing task-card format; the mechanical executor runs that card unchanged.
Codex and OpenCode use the same submission contract. Agent instructions select
the path; they do not create experiments without a user task or scheduled job.

### 9b. Explicit ephemeral experiments and cloud builds

Use the ephemeral runner for an explicitly selected ephemeral experiment, or
for a standalone cloud build outside the EKS image-building workflow
([`taskq/deploy/ephemeral/`](taskq/deploy/ephemeral/README.md)). Do not
launch EC2 instances by hand for it. `conductor/deploy/aws/launch.py`, in the
Conductor repository, starts the Conductor control plane, not experiments.

```sh
cargo build --release --manifest-path taskq/deploy/ephemeral/cli/Cargo.toml   # once
E=taskq/deploy/ephemeral/cli/target/release/ephemeral   # or the bash CLI: taskq/deploy/ephemeral/ephemeral
$E run --detach --type c7i.4xlarge --ttl 4h -- 'cargo run --release -- ... --out "$EPHEMERAL_OUT"'
$E status last; $E logs -f last; $E fetch last
```

- The two CLIs are interchangeable: same flags, S3 layout and runner, and
  either one can follow, fetch or kill the other's jobs.
- Agents use `--detach` and check back with `status` or `logs -f` at the
  check-in cadence of the default workflow, rather than holding a foreground
  session open on a long job.
- Each job is a paid instance. Start the jobs the request asks for and no
  more. Pick the smallest instance type and `--ttl` that fit, and `kill` any
  `--keep` instance once you are done with it. The runner, the deadline timer
  and the reaper terminate everything else.
- Runners use Session Manager (`ephemeral shell`), not SSH. Section 9 applies
  to hosts launched by hand.
- A result that lands in the repository still follows section 10, the
  `benchmarks/` rule and the research-visuals rule. Its provenance is the
  fetched `job.json`, `host.txt` and `rusage.txt` in
  `~/.cache/ephemeral/runs/<id>/`.

### 9b. Protocol-bound jobs on the queue, and what a restore means

Owner request, 2026-10-22; design in
[`taskq/deploy/spot-checkpoint/README.md`](taskq/deploy/spot-checkpoint/README.md),
submission in the `queue-experiment` skill. Every job a queue runs binds a
frozen `experiment.protocol/v1` (`experiment-protocol` skill; the schemas and
checker are canonical in aburan28/crypto-autoresearcher) and lands as one
`experiment.export/v1` beside its raw records, one row per execution with the
isolation level it earned and its checkpoint history. The protocol's
`measurement_class` picks the pool: a job whose clock or counter is read
against an A/A interval goes to an isolated pool and is never resumed (an
interrupted row is abandoned and a new row runs); a throughput, search or
training job goes to Spot capacity and checkpoints under the application
manifest contract or, where a program cannot save itself, a CRIU image. After
a restore, counted units stay valid and wall and CPU time do not
(`wall_valid: false`, `resumed > 0`); the export checker refuses a resumed row
with a valid clock. A `review-run` record by another runner is the second
reading of an export and an input to the validation gate, never a row.

### 10. Performance work starts from a clean, recorded baseline

A speedup is a comparison, so it is only as good as the baseline and the
conditions both sides ran under.  Before changing code for speed:

- **Record the baseline and the host.** Build the unmodified revision and
  keep the binary.  Record the commit, `rustc --version`, the CPU model and
  its relevant features (for example `popcnt`, `avx2`, `avx512*`,
  `pclmulqdq`, NEON/`aes`), the logical core count, memory, OS and
  architecture, and the exact benchmark command and inputs.  A number
  without its host is not a baseline.
- **Pin the output, not just the time.** Every run must show identical
  results and counted units (fingerprints, digests, counters) between
  baseline and candidate.  A faster run that decides anything differently
  is a different algorithm, not a speedup.
- **Isolate every timed run: pin it, reserve its core, and record the
  conditions.  This is mandatory for any wall-clock or native-time number.**
  EKS experiments use the native isolation and admission in §9a; the submitting
  machine's lock does not isolate the remote pod. For an explicitly selected
  local or ephemeral run, use `tools/isolated_bench.py`: `run` for a single
  command it pins itself, `reserve` for a harness that pins its own children
  (such as the tournament evaluator's `--cpu`). The tool does the following:
  - It takes an exclusive lock, so only one benchmark runs at a time.
  - It refuses to start while other processes use CPU or while the CPU or
    memory pressure (PSI) is high.
  - It moves every other movable thread off the benchmark core and pins
    the benchmark there.
  - It records, per run, the context switches, faults, load average, PSI
    and the CPU time everything else used, and it marks a run `contended`
    when others used more than the threshold.

  `taskset` alone is not enough. It keeps the benchmark on one core, but
  it does not keep anything else off that core. It also does nothing about
  builds on the neighbouring cores, which share the cache and the memory
  bus.

  While a timed stage runs, start no builds, test suites, lints, audit
  cells or other agents' jobs on the same machine. Run heavy work through
  `tools/isolated_bench.py busy -- CMD` so that it waits for the lock.

  Instruction counts and the repository's counted units do not depend on
  contention, so they stay the primary metric. Wall time is evidence only
  from uncontended runs. Report how many runs were contended, and do not
  pool contended and uncontended runs.

  A virtual machine's host neighbours and CPU frequency are outside the
  tool's reach. Expect ±5–10% residual wall noise on cloud containers and
  CI runners, and measure it with an A/A run. Fix the thread count
  explicitly (`RAYON_NUM_THREADS=1`), and report the pinned CPUs.
- **Profile to find the cost, then measure the change.** Before tuning a CPU
  loop or a CUDA kernel, find where the time goes with `tools/profile.sh`
  (the [profile skill](.agents/skills/profile/SKILL.md)). It covers `perf`
  sampling, Callgrind, top-down, `nsys`, `ncu` and `nvidia-smi`, and records
  the host, the tool versions and the binary hash. Profilers perturb what
  they observe (ncu replays each launch at locked clocks), so a profile
  explains a cost but never establishes a speedup. The measurement below
  does.
- **Measure the noise floor, then interleave.** Run the baseline against a
  copy of itself (A/A) to see the spread, then alternate baseline and
  candidate (ABAB…, at least five rounds) and report median and minimum.
  A difference inside the A/A spread is not a result.  Where wall time is
  noisy, add a deterministic measure beside it: instruction counts
  (`valgrind --tool=callgrind`) or the repository's counted units.
- **Watch for one-time costs.** Thread-pool start-up, page faults, lazy
  statics and cold caches land on whichever case runs first; do not charge
  them to that case's algorithm.
- **Measure parallel changes at one thread and at many.** A multi-core gain
  must not regress `RAYON_NUM_THREADS=1`, and the core count of the host
  bounds what the result says about any other host.
- **Say which hardware class a result covers.** This code is meant to run
  well on a diverse set of targets: Linux x86-64 (whose baseline target has
  no `popcnt` or AVX2 unless dispatched at runtime), Arm64 (Apple silicon,
  Graviton), GPUs (CUDA; Metal on Apple silicon; see §9 for the AWS hosts)
  and, prospectively, FPGAs.  A result holds for the class it was measured
  on; name it, and name the classes it was not measured on rather than
  implying them.  Use runtime feature detection with a portable fallback
  instead of global `target-cpu` flags, and report a gain on one class that
  costs another per class.
- **Keep the evidence.** The PR states the host manifest, the A/A spread,
  the A/B table with identical-output checks, and the changes that were
  tried and rejected with their numbers.

### 11. Name every curve by its ICV1 slug

A number quoted against the wrong curve is a wrong number, and until this
rule one Koblitz curve went by five spellings, a prime curve by whichever
generator found it, and no name said which modulus or model it meant.
Every elliptic curve is now named by an identity computed from the curve,
specified in [`docs/curves/ICV1.md`](docs/curves/ICV1.md).

- **Write the slug.** In prose, tables, scoreboard rows, report `name`
  fields, parameter and run file names, a curve is its ICV1 slug
  (`icv1-f2m41-tm2308219-7f48b14a`).  A curve a standards body or public
  challenge published may go by that name (`ECC2K-130`, `sect163k1`,
  `secp256k1`, `P-256`).  Family notation with a free parameter is fine
  when a sentence is about the family.
- **Use the standard panel.** New measurements run on the curves of
  [`docs/ic/STANDARD_PANEL.md`](docs/ic/STANDARD_PANEL.md) (owner,
  2026-11-10), and a study that uses another curve says why. Prose and
  tables may name a panel curve by its alias (`K0-23`, `K1-83`, `P36a`);
  records and file names keep the slug. An alias-shaped name that is not
  on the panel fails `curve-names` in `docs/ic/` and in research dated on
  or after the freeze.
- **Never write a retired form.** The spellings in `ICV1.md`'s table of
  retired names carry no model and may not appear in new text or be
  emitted by new code.  Frozen reports keep them; the registry resolves
  them, and code that replays a report or reads a table keyed the old way
  matches through `curve_id::same_curve`, never by string equality.
- **Register before you cite.** Every slug written must be in
  [`docs/curves/registry.json`](docs/curves/registry.json).  A new curve is
  registered in the pull request that first names it
  (`python3 scripts/build_curve_registry.py`; a curve built from a seed
  also goes in `docs/curves/sources/specs.txt`).
- **Join on EC1, write ICV1.** The slug names a curve *model*.  A
  comparison, UI export or candidate manifest that joins across
  repositories carries the EC1 alias and curve UID of the exact
  representation measured, subgroup and generator included, as the
  cross-repository section below and
  [`docs/curve-identities.md`](docs/curve-identities.md) require.  The
  registry lists each model's EC1 representations.
- **Do not rename evidence.** Frozen run JSON, hash-pinned files and
  anything under a `results/`, `runs/`, `raw/`, `evidence/` or `archives/`
  directory keep the names they were written with.  Prose about them uses
  the slug.

`scripts/check_curve_names.py` enforces this in CI (`curve-names`): no
retired form in Markdown or HTML outside a code fence, every slug
registered, and no retired form on a line a pull request adds to prose or
code.  `--fix` rewrites retired names in place.

### 12. Measure across ECDLP methods with ecbench

New measurements that put ECDLP methods side by side (Pollard rho in its
variants, baby-step giant-step, the kangaroo, index calculus) use the
native harness `ecbench` ([docs/ecbench/README.md](docs/ecbench/README.md)),
so every method is charged in one counted unit, on the same one-target
workloads, under the same isolation, into the same sealed records.

- **Spec, session, audit.** Write an `ecbench.spec/v1`, run it into a new
  directory, and pass `ecbench verify --replay N` before citing a figure;
  the receipt's SHA-256 is the replay certificate.
- **Levels gate wall time, never counts.** Operation counts stand at any
  isolation level; a wall-clock figure needs the spec's level (L2 by
  default) and is read against the session's A/A interval.
- **Sessions are evidence.** Commit them under `research/<topic>_<date>/
  sessions/`; CI re-audits them with replays on another host and never
  lets one be edited.  The SQLite database is an index rebuilt from them.
- **A `vs_rho` claim is one IC run against one strong-rho run on one
  public target.** `ecbench claim build` assembles it from a session with
  `target_kind: public`, names the candidate by the tournament's IC1
  identity, and runs the ledger's checker (`ecbench claim check`, the
  native `boundary_autolab.py claim-check --stage vs_rho`).  It passes
  only with an audit receipt from another host class that replayed both
  runs; without one it fails on that and says so.
  The wall reference is the fastest rho for the curve family, never the
  untuned `rho.negation`: `rho.signed_frobenius_strong` on Koblitz curves
  (the only one `ecbench claim build` accepts today; it has no prime
  branch), `rho.prime_fast` (`prime_fast::rho_parallel`, negation map, one
  thread, p < 2^62, `RhoConfig::tuned`) on prime curves: 1.03x
  `rho.negation`'s operations [0.98, 1.08] at about 0.22x its median wall
  on 28–40-bit curves (`research/tuned_gae_20261020/`).  It is the wall
  reference; the counted reference stays `rho.negation`.  A prime wall ratio is `rho.prime_fast` online wall over
  IC online wall, priced under §5a, until a prime claim branch exists.
- **Skills:** `ecbench-measure`, `ecbench-independent-runner` and
  `ecbench-extend` under `.agents/skills/`.

Historical autolab, tournament and ICMS evidence keeps its own protocols.

### 13. Large files go through the store

Data files follow the artifact-store policy (owner, 2026-10-24): any non-code
file over 1 MiB, and any data-suffixed file (`.jsonl`, `.gz`, `.npy`, logs,
archives) over 64 KiB, lives in `s3://setec-astronomy-artifacts` with a
`.artifacts.json` manifest in its directory, moved with `tools/artifacts`
(`artifacts.py push`, `pull`, `status`, `verify`) instead of `git add`. See
[docs/artifacts.md](docs/artifacts.md). The rest of this section describes
`crypto store`, which stays for named single-file references (`store:NAME`);
both share one object layout and cache.

A factor base, relation table or raw evidence file too big for Git is pushed
with `crypto store push` (or `ecbench store push`) and referred to by name,
not by a local path or a one-off bucket URL: `store:<name>`, accepted
wherever a path is (`ic --factor-base`, and any code that calls
`crypto_lib::store::resolve_path`). The tracked `store/index.json` is the
manifest the evidence rules ask for: content hash, byte count, location,
and the command that produced the file (`--provenance`). Commit the index
entry in the PR that lands the result. Objects are immutable and keyed by
SHA-256; a name is not repointed without `--replace`, which keeps the old
digest as superseded. Never delete remote objects from an agent session.
See [docs/store/README.md](docs/store/README.md).

"Too big for Git" means over 10 MiB (owner, 2026-10-22); for data files the
thresholds above now apply first, and the 10 MiB limit still covers anything the
artifact policy does not select. Every blob committed
stays in every future clone. The `large-files` workflow
(`scripts/check-large-files.sh`) fails a PR that adds or modifies such a file,
except generated text that git delta-compresses well (`docs/browser/data.json`,
`docs/curves/*.json`) and the reviewed paths in
`.github/large-files-allowed.txt`. A PR that must commit another one anyway
carries the `large-file-ok` label, added by the owner or a reviewer. Do not
pre-compress text files to get under the limit: compressed blobs do not delta,
so each revision costs its full size again.

### 13a. Raw run trees land as one archive

A round's or study's raw run tree (per-run reports, stderr, isolation records,
logs: everything under its `runs/`) lands as one deterministic `runs.tar.xz`
beside its README, with `runs.tar.xz.sha256` (`sha256sum runs.tar.xz`, so
`sha256sum -c` checks it in place) and a `.gitignore` there holding `/runs/`. The
analysis, figures and claims are made from the extracted tree, and the README
says how to extract and re-check it. Pack it so packing the extracted tree
again gives the same bytes, as
`research/ic_tool_program/rounds/R01-baseline-v0/` does:

```sh
tar --sort=name --mtime='YYYY-MM-DD 00:00:00Z' --owner=0 --group=0 \
    --numeric-owner --mode='u+rwX,go+rX,go-w' --format=gnu -cf - runs \
  | xz -6 -T1 > runs.tar.xz
sha256sum runs.tar.xz > runs.tar.xz.sha256
```

Use the round's start date for `--mtime`. Raw `.jsonl` and logs compress
5-20x, and one file costs a checkout one entry instead of thousands.

**Exception: keep it loose when a path must resolve.** When a claim, replay,
manifest or verifier names individual run records by repository path (the
`report` fields of `research/ic_tool_program/rule/v*/claims/` point into
`runs/`; `verify_archive.py`-style checkers hash files in place), those
records stay committed as loose files. Only the part nothing names goes in the
archive; say in the README which part is which.

This applies to new run trees. Never re-pack or compress a committed tree, or
rewrite history to slim one: committed evidence stays as it was written. The
one exception (owner, 2026-10-24): data files move out of Git to
`s3://setec-astronomy-artifacts` ([docs/artifacts.md](docs/artifacts.md)); a
moved file keeps its path and bytes (checked by hash) and history is not
rewritten. A tree too big for Git even compressed goes through the store (§13).
Checkouts that do not need a research tree leave it off disk instead
([docs/sparse-checkout.md](docs/sparse-checkout.md)).

### 14. Experiments to run later go in `backlog/`

An experiment worth running that this session will not run (too big, blocked,
or for another machine) is written as a card in `backlog/<ID>/` and checked
with `backlog validate`; leases and runs go through cairn, and results return
to `research/` by PR. The protocol, including funding as priority, is
[backlog/README.md](backlog/README.md).

### 15. Compare against the fastest external implementations

Owner's rule, 2026-10-16. The goal is for our implementations to be faster
than everything else that computes the same thing. A before/after speedup
against our own previous code (§10) shows progress. It does not show where
we stand. So every performance result also names the fastest external
implementation of the same computation and measures against it.

**Which tools.** Compare against the fastest available implementation, not a
convenient one. As a minimum, for the areas this repository works in:

| computation | compare against |
|:--|:--|
| Gröbner bases (F4, F5, decomposition and summation-polynomial systems) | Magma `GroebnerBasis` (its F4, and its F5 where Magma offers it), msolve, FGb; also Singular (`std`, `slimgb`, `modStd`) and OpenF4 where relevant |
| Sparse or dense linear algebra mod p and over GF(2) | Magma, FLINT, M4RI/M4RIE (GF(2)), and the block Lanczos/Wiedemann solvers of CADO-NFS |
| Polynomial and field arithmetic (products, powers, roots, factoring) | FLINT (`nmod_poly`, `fmpz_mod_poly`, `fq`), NTL, Magma, PARI/GP |
| Point counting (SEA), modular polynomials, isogenies | PARI/GP (`ellcard`, `ellap`), Magma (`#E`, `ClassicalModularPolynomial`, `Isogeny`), Sutherland's `classpoly`/`modpoly` and his published tables, Sage where it calls a faster library |
| Isogeny-based protocols (CSIDH, √élu, SQIsign-style quaternion steps) | the authors' reference and optimised implementations, and published cycle counts on named CPUs |
| ECDLP (rho, kangaroo, index calculus) | the fastest published implementation or record computation for that curve class, with its hardware stated |

If a faster tool exists than the ones listed, use it and add it to this
table.

**How to compare.**

- **Same inputs, same answer.**
  - Run the external tool on exactly the inputs our code runs on, exported
    by a checked-in script. `examples/gb_cas_export.rs` writes msolve,
    Singular and Magma inputs for the Gröbner workloads; add an equivalent
    when a workload has none.
  - Check that the outputs agree: the same reduced basis and order, the same
    group order, the same j-invariants, the same kernel. A faster run that
    computes something different is not comparable.
  - Record the tool's name, version, options, and the algorithm it actually
    ran (for example whether Magma used F4 or F5, or which msolve flags
    were set).
- **Same host, same conditions.**
  - Run both sides on the same machine, with the same isolation as §10 and
    the same thread count. Compare single-threaded with single-threaded and
    many threads with many.
  - Do not time the external tool's start-up, licence check or
    parsing/printing as its algorithm. Use its own internal timer
    (Magma `Cputime`/`Realtime`, msolve `-v`) when it reports one, and say
    which was used.
- **Report the ratio, per size.**
  - Report our time divided by the external tool's time, at each problem
    size, with the A/A spread (or another uncertainty) for both sides. Also
    report how the cost grows with size for both, so a constant-factor win
    at small sizes is not mistaken for a better exponent.
  - Say plainly who is faster, at which sizes, and on which hardware class.
  - "Faster than X" holds only over the sizes and hosts that were measured,
    and only against the fastest configuration of X that was tried. A loss
    at large sizes is reported even when small sizes win.
- **Missing tools are named, not skipped.**
  - If the fastest tool is unavailable (Magma needs a licence; some tools
    run only on other platforms), use the fastest open tool available. msolve
    is the open reference for F4.
  - Cite the missing tool's published timings with their hardware, labelled
    "published, not reproduced".
  - List which comparisons are still missing, and ask the owner for access
    or a host that has the tool instead of quietly dropping the comparison.
  - Never present a comparison against a slower tool as "fastest".
- **A loss is a target.** When an external tool is faster, record the gap,
  as the ratio and the sizes where it holds, in the study and as a
  `backlog/` card (§14) or the next round's goal. A later performance PR on
  the same computation reports the ratio against the external tool before
  and after.
- **Where it lands.**
  - The external comparison goes in the same report and `benchmarks/` entry
    as the speed result, under the rules of "Performance results also land
    in `benchmarks/`".
  - The `benchmarks/README.md` row gives the ratio against the fastest
    external tool next to the before/after ratio, or says "external
    comparison: not run" with the reason.
  - Keep the export and run scripts in the repository. Do not commit
    proprietary binaries, or output that the tool's licence forbids
    redistributing.

## Worked example

`research/notes/index-calculus/RESEARCH_RESIDUAL_WALKS.md` is the reference implementation of this
rule, end to end: §9.6 states the boundary and the target, §9.7 freezes
the baseline table, §10.6 classifies every lever tried against the
floor, §11.5 and §11.6 are an engineering ledger with the class of each
step named, and §11.7 prices the phase the earlier rounds had skipped
and corrects the conclusion they implied.  Its bottom line is a
negative result stated in numbers: on `E(F_{p³})` at the sizes that fit,
rho costs `S ≈ 1.3` and every index-calculus variant built costs
between `528×` and `4,000×` that, with the asymptotically better variant
crossing rho only past `2^{230}`.

`docs/index-calculus-scoreboard.html` is the same ledger drawn, and
the reference for what §7 asks of a round: the boundaries as the axis
and the reference line, the `C₃` steps with their classes, the fitted
exponents against rho's one half, and the extrapolated crossovers
marked as extrapolations.

That is what a finished thread looks like when the answer is no.

## Cross-repository curve identity in comparisons

For new curve comparisons and UI exports, follow [docs/curve-identities.md](docs/curve-identities.md)
and `tools/curve_identity.py`. Reuse EC1 aliases and full curve UIDs across IC and
Pollard rho; keep factor-base/isogeny candidate identities separate. Preserve
immutable historical names and never infer exact identity from field degree alone.
Within this repository the text name is the ICV1 slug (§11); the curve
registry, [docs/curves/registry.json](docs/curves/registry.json), maps each
slug to the EC1 identities of its recorded representations.
The [IC curve crosswalk](docs/curves/ic/README.md) mirrors cryptanalysis's
exact curve records and links them to ICV1 only when the model match is
established.
The [typed curve-link rules](docs/curves/ic/curve-links/README.md) keep
twists and field/model changes separate from verified isogeny routes; no
base-field log transport is inferred from a shared j-invariant. Keep unknown traits and unsupported models as `null` with status.
Large factor bases remain content-addressed archives, while the browser's
FB1 entries are session summaries; link them only after exact curve and
point-set identities, encoding and quotient rules agree. An isogenous curve
has its own EC1/UID and an ordered, verified map route before `ISO1` is used.
Run `python3 docs/curves/ic/validate_semantics.py` after changing the IC curve
crosswalk or typed links. The `ic-semantic-metadata` CI job also compares the
three mirrored files with cryptanalysis `main`; land source changes there
first, then update this mirror and its `mirror-lock.json` in a paired PR.
To enumerate a prime-field curve's isogeny class, use the native walker
`src/bin/isogeny_walk.rs` ([docs/curves/ic/README.md](docs/curves/ic/README.md#walking-an-isogeny-class)):
it emits these records and kernel-certified `IW1` routes, and `isogeny_walk
verify` replays them.
The user guide, including S3 storage, is
[docs/isogeny-walk/README.md](docs/isogeny-walk/README.md).

## Querying the curve database (ecdb)

ecdb is a Postgres catalogue on RDS (us-west-2). It holds:

- every curve in the registry, the walk outputs and the trait catalogue,
  with their Jacobians, isogenies, covers, transfer prices and computed
  polynomials;
- this repository's measured results: the IC leaderboard and its recipes,
  the progress timeline, the boundary ledger, the `benchmarks/` index, and
  every ecbench session with its runs;
- the curve records and measured datasets of cryptanalysis,
  crypto-autoresearcher, cryptanalysis-rl and ml-cryptanalysis.

Agents reach it through the MCP server `ecdb` in `.mcp.json`, over HTTP, or
with `scripts/ecdb.sh`. The guide is [ecdb/docs/AGENTS.md](ecdb/docs/AGENTS.md);
read it before the first query.

- **Look up before computing.** Query ecdb before writing code or scanning
  `docs/curves/*.json` for a curve fact. This covers trace, order, cofactor,
  CM discriminant, End(E), embedding degree, twist, l-torsion, volcano level,
  isogeny neighbours, covers, transfer price, division or modular
  polynomials, and GLV data. Resolve curve names there too; on an ambiguous
  name (409), choose a candidate explicitly.
- **Token.** Export it before the runtime starts:

  ```sh
  export ECDB_TOKEN=$(aws secretsmanager get-secret-value --region us-west-2 --secret-id ecdb/api --query SecretString --output text | jq -r .read_token)
  ```

  Never print, commit or log it. Without AWS access to `ecdb/api`, say so and
  fall back to the repository files.
- **Cite the source, not the query.** ecdb is imported from this
  repository's files at the commit `GET /v1/meta` names. A PR, report or
  leaderboard row cites the repository file, certificate or run, not an ecdb
  query.
- **Keep statuses.** Report every value with its `fact_status`. Unknown is
  `null`, never 0. `probable` is not `proved`.
- **Transfer prices are leads.** `dlp_transfer.ratio_log2` is a formula
  estimate. It is not a measured speedup, and it never enters the IC
  leaderboard or `benchmarks/` (§5a and "The rule: boundary, table, ratio").
- **Measured rows are copies.** Leaderboard, progress, boundary, benchmark,
  ecbench and sibling-dataset rows are the producers' frozen records with
  their units:
  - compare a ratio only within its leaderboard family, ecbench session or
    dataset;
  - rank arms only across the §5a band;
  - keep `unvalidated (pre-gate)` rows out of any claim.

  Querying them is not a measurement. A new result still goes through its
  run, the validation gate and the generators of the files ecdb copies.
- **Relations are not routes.** A twist, isomorphism or model-change row
  does not transport a logarithm. Only a kernel-certified `isogeny` row does
  (the typed curve-link rules above).
- **Writes are claims.** `ecdb_record_evidence` and `POST /v1/isogenies`
  need the write token. They record what a run or certificate in a PR
  supports, with its artifact hash and true status. Correct imported data in
  the source file, then redeploy (`ecdb/deploy/README.md`). Never patch rows.
- **Keep it current.** A PR that changes a file ecdb imports says so in its
  body. That covers the registry, `traits.json`, `covers.json`,
  `jacobian-transfers.json`, the certificates, the imported walk outputs,
  `docs/ic/leaderboard.json`, `progress-timeline.json`,
  `boundary_targets.json`, `benchmarks/` and ecbench sessions.
  `scripts/ecdb.sh check` lists the files that differ from ecdb's copy. After
  merge, redeploy with `ecdb/deploy/build-lambda.sh` and
  `ecdb/deploy/deploy-aws.sh`.

## IC measurement rules

### Primary comparison uses one target

The default elliptic-curve index-calculus (IC) question is the cost to solve
one previously unseen public target. Every primary comparison run must use
exactly one target and pair IC with Pollard rho on that same point under the
same resource envelope. A panel of independent points is a set of separate
one-target workloads, with one result row per point; do not combine them into
a multi-target DLP run or replace the per-target results with a batch average.

**Cold interval governs the primary comparison** (owner, 2026-11-15). The
primary IC-vs-rho comparison, every leaderboard ratio and every claim tier of
[`docs/ic/SUCCESS_CRITERIA.md`](docs/ic/SUCCESS_CRITERIA.md) use the cold
end-to-end cost in counted operations: from the instance to a verified scalar,
with all target-independent setup charged in full to the one target ("Success
criterion", §2, §8). The online interval defined below is reported beside it as
a separate row labelled `online-only`; it never replaces the cold cost and never
supports a claim to beat rho on its own. Operation counts are the metric and
wall time a practicality note (§6), for both rows.

Start the IC online clock when target-dependent computation begins, after
reusable target-independent base, index, relation-log, or solver setup is
ready. Include all target-dependent attempts and point-query generation, and
stop after scalar recovery and independent verification. Report reusable
setup separately. Exclude process launch, input loading, and construction of a
known-answer target from both IC and rho online intervals. Start rho timing at
its first target-dependent walk and stop after recovery and independent
verification. If scalar replay is outside either interval, report its cost
separately and keep the correctness check.

Do not use multi-target rho batches, cross-target distinguished-point tables,
batch throughput divided by target count, or shared-collision work as the
one-target rho reference. Multi-target work needs a separate, explicit
research question after the one-target measurement; it cannot be the default,
headline, or acceptance gate for a speedup claim. Preserve old batch results
as historical diagnostics and label their target count and shared setup.

An IC-vs-rho speedup is eligible only when both methods solve and verify the
same point and both online intervals are complete. Report
`rho_online_ms / ic_online_ms`, target identity, candidate and workload
identity, included phases, resource conditions, and correctness evidence.
Timeouts, failures, OOMs, and unverified scalars stay in the record and never
count as wins. Missing phase costs make the total and speedup unknown. Key result rows by
`(candidate_id, workload_id, run_id)`, preserve their manifest hashes, and
use the canonical run-id convention from the repository's IC measurement
rules. Keep the five exclusive IC online phase costs; their sum must equal the
charged IC online wall time. Each claim must retain independent replay
certificate SHA-256 digests and the exact nonempty resource-envelope object for
both arms; the claim checker requires those envelopes to match and rejects a
bare boolean verification or resource-match assertion. The IC interval must
name all five target-dependent phases, and rho must name walk, collision, and
recovery check.

The current `boundary_autolab.py` producer timing is whole-process or
operation-counted. Treat those outputs as legacy diagnostics until producers
emit the online intervals above; they cannot establish the primary speedup.
Its launch interface now permits one target per run only.

<!-- conductor:begin -->
Before making code changes, obtain or attach to a Conductor task. Run
`conductor check --summary "…" --scope path:…` first — if someone already holds
those files, it will tell you who and what to do about it. Read `docs/CONDUCTOR.md`
and the active task card. Report scope expansion before editing outside the reserved paths.
Do not publish chat transcripts or secrets as task metadata.
<!-- conductor:end -->

### Progress metrics (daily lab report)

`tools/progress_metrics.py` exports this repo's progress KPIs as JSONL for the lab-wide daily
report (`/Volumes/SSD990-2/progress-metrics`). It reads committed state at `origin/<default>` and
prints one sample per line (`metric, value, date, problem, unit, better, kind, label, source`).

- When a PR adds or changes a benchmark, leaderboard, result file or ledger source that carries a
  number worth tracking day over day, extend the exporter in the same PR. Keep metric ids stable;
  a renamed id is a new series.
- Never emit estimates. If a source is missing, emit nothing for it.
- `python3 tools/progress_metrics.py --since 2026-10-01` must run in under a minute, stdlib only,
  no builds, and never read the working tree.

## Persistent scientific research loop

Owner instruction, 2026-11-08. Pursue the user's research objective through
successive evidence-driven attempts. A failed command, rejected candidate,
negative result, completed subtask, or written plan is not by itself a reason
to end the effort.

### Hypotheses and experiments

- State the question and retain its acceptance criteria. Separate observations,
  assumptions, hypotheses, theories and conclusions. For explanatory work,
  propose competing falsifiable hypotheses and say what would change your mind.
- Choose the smallest informative experiment or proof obligation. Before running,
  state predictions, controls or baseline, observables, success/falsification
  criteria, resource limits and artifact locations. Descriptive studies use a
  sampling and observation plan without inventing a predicted outcome.
- Inspect actual outputs and check correctness before interpreting them. Keep
  methods, inputs, versions, seeds, raw evidence, uncertainty and failed attempts
  reproducible under the repository's existing storage and privacy rules.
- Update or reject hypotheses when evidence disagrees. Broader theories must
  explain existing observations and yield further testable predictions. Preserve
  null and negative results; never invent evidence, cherry-pick outcomes, relax
  frozen criteria, or turn a timeout into a proof of impossibility.

### Recover, adapt and continue

1. After each attempt, record what happened, what was learned, the remaining gap,
   and the next discriminating action. Execute that action when it is within the
   authorized scope and available resources; do not stop at proposing it.
2. When blocked, diagnose the concrete cause. Distinguish infrastructure, access,
   implementation, measurement and mathematical issues. Test a focused remedy
   and then a materially different approach when the evidence warrants it.
   Consider smaller reproductions, alternative tools or methods, independent
   derivations and other tractable parts of the same objective.
3. Before declaring the objective blocked, investigate the reasonable available
   alternatives and record why each cannot currently proceed. One failed path
   blocks that path, not the entire goal. Recording a problem, backlog card or
   handoff does not itself satisfy the original task.
4. Continue across intermediate stage boundaries for a full-cycle assignment.
   A worker finishing, a review rejecting a candidate, or a component passing
   is input to the next step; it is not automatic goal completion. Honor an
   explicitly stage-limited task's stopping point.
5. Use evidence to choose retries. Do not repeat an unchanged failed command
   without a reason to expect a different outcome, rerun checks merely to get
   green, or consume resources indefinitely. Respect existing admission,
   ownership, role, privacy, review and budget limits. Persistence grants no
   additional execution or spending authority.
6. Before interruption or an actual resource/access limit, checkpoint through
   the repository's established mechanism: objective, current hypothesis,
   commands/configuration, evidence pointers, failed approaches, remaining
   budget and exact next action. Resume from that state and check whether a
   recorded blocker has changed instead of restarting the investigation.

### Evidence required to stop

Stop only when the requested acceptance criteria are met and checked, the user
redirects or stops the work, an explicit task boundary is reached, or a concrete
authorization/resource/dependency blocker prevents further useful authorized
progress after reasonable alternatives have been investigated. A disproved
candidate may close that candidate; pursue the remaining objective through an
informed successor when one is available.

If work must stop incomplete, report the observed blocker, alternatives actually
tried, evidence and unresolved uncertainty, saved checkpoint, exact next
experiment or action, and the specific input or condition needed to resume.
Never claim success from effort alone or claim that every avenue is exhausted
without evidence. Apply this loop proportionately: routine edits need direct
checks; substantive research needs an explicit experimental record.

## Continuous learning loop

Owner instruction, 2026-11-15: agents and skills run continuously, learn from
what they observe, adapt their own instructions from evidence, and resolve
what they can without waiting for a person. The persistent research loop above
governs a single effort; this loop carries what one effort learned into the
next. The ledger is `docs/lessons/` (`tools/lessons.py`, schema
`crypto.lesson/v1`; guide: [`docs/lessons/README.md`](docs/lessons/README.md)).

1. **Read before acting.** Every skill and agent starts with
   `python3 tools/lessons.py brief --scope <its name>`; the session-start hook
   prints the global brief. Adopted lessons are applied; candidates are
   hypotheses the run can test.
2. **Act on your own, within authority.** Diagnose a blocker, try the
   documented remedy, then a materially different approach, before escalating
   (persistent loop, "Recover, adapt and continue"). Escalate only what needs
   authority, access, budget or an owner decision you do not have. The loop
   adds no authority: model tiers, admission, sabotage and budget rules hold.
3. **Record after acting.** One `outcome` per finished task, with evidence
   (receipt, commit, PR, job or session-log path). One `test` per lesson the
   task applied, `confirm` or `refute`. A surprise that would change what the
   next run does becomes a new `lesson`: a trigger, an action, and the evidence
   that showed it.
4. **Promote only on evidence.** A lesson is *adopted* after two confirmations
   with distinct evidence and more than twice as many confirmations as
   refutations; *contested* once refuted; *retired* by a `retire` entry or two
   more refutations than confirmations. Status is derived from the entries,
   never stored, so it cannot be asserted.
5. **Adapt the instructions.** An adopted lesson is folded into the skill or
   agent file it is scoped to (or into this file, for scope `*`) by a PR that
   cites the lesson id. A retired lesson's text is removed the same way. A
   rule from the owner is never changed by a lesson; a lesson that contradicts
   one is reported to the owner ("What supersedes what").
6. **Measure the skills.** `python3 tools/lessons.py stats` gives each skill's
   and agent's outcome counts with a Wilson 95% interval. A scope with at least
   8 outcomes whose success interval lies wholly below 0.5 is reviewed: its
   failure outcomes are read together and the cause becomes a lesson or a fix.
7. **Integrity.** Entries are content-addressed and append-only; the
   `agent-learning` workflow fails an edited, removed or unevidenced entry.
   Every entry is `[pcc:unverified]` until a pcc claim cites it, and a lesson
   never stands in for a measurement or a proof.

Lean work adds one measured signal: `tools/lean/lean-health.sh` (advisory)
reports crypto-lean use, limit overrides, `native_decide` and theorem families
per study; the baseline is `docs/lean-health/BASELINE-20261115.md`.
