"""Source byte layout/manifests only. No mathematical execution."""
from pathlib import Path
from datetime import datetime, timezone
import ast, difflib, hashlib, json, os, shutil, subprocess
r=Path('/workspace/crypto-chained-balanced-main');s=r/'research/chained_richelot_map_20261117'
d=s/'compiler-revision-D';e=s/'compiler-revision-E'
assert not (e/'SOURCE_LOCK_14E.json').exists()
if not e.exists():shutil.copytree(d,e)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=(d/'src/shifted.rs').read_text()
marker='// New visibility-only adapter around the unchanged unit12 chart/witness code.\n'
assert old.count(marker)==1
base,adapter=old.split(marker);adapter=marker+adapter
testmark='#[cfg(test)]\nmod tests {\n';assert base.count(testmark)==1
before,test=base.split(testmark);test=testmark+test
new=before+adapter+'\n'+test.rstrip('\n')+'\n'
assert base==(d/'original-sources/shifted12.rs').read_text()+'\n'
assert new.replace(adapter+'\n','',1)==(d/'original-sources/shifted12.rs').read_text()
assert new.count(test.rstrip('\n'))==1 and new.count(adapter)==1
(e/'src/shifted.rs').write_text(new)
oldcaller=(d/'run_first_unit_14_D.py').read_text()
newcaller=oldcaller.replace('SOURCE_LOCK_14D.json','SOURCE_LOCK_14E.json')
assert newcaller.count('SOURCE_LOCK_14E.json')==1
(e/'run_first_unit_14_D.py').unlink(missing_ok=True);(e/'run_first_unit_14_E.py').write_text(newcaller)
(e/'SOURCE_LOCK_14D.json').unlink(missing_ok=True)
ast.parse(newcaller)
result=subprocess.run(['rustup','run','1.99.1','rustfmt','--check','--edition','2021',str(e/'src/lib.rs')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,PATH='/home/agent/.cargo/bin:'+os.environ['PATH']))
(e/'E-layout-format.stdout').write_bytes(result.stdout);(e/'E-layout-format.stderr').write_bytes(result.stderr);assert result.returncode==0,(result.stdout,result.stderr)
changes=[]
for p in sorted(d.rglob('*')):
 if p.is_file() and p.name not in ['SOURCE_LOCK_14D.json','run_first_unit_14_D.py']:
  other=e/p.relative_to(d)
  if p.read_bytes()!=other.read_bytes():changes.append(p.relative_to(d).as_posix())
assert changes==['src/shifted.rs'],changes
(e/'LAYOUT_ONLY_E.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='D/src/shifted.rs',tofile='E/src/shifted.rs'))+''.join(difflib.unified_diff(oldcaller.splitlines(True),newcaller.splitlines(True),fromfile='D/caller',tofile='E/caller')))
prospective={'time':datetime.now(timezone.utc).isoformat(),'parent_public_source':'c0a2f94debb9bd26763ebabb0dda746936fdbdd1','preserved_D2_negative':'PCC-20261117-309c13','change':'Move entire exact visibility bridge before exact retained old test module; caller only selects E lock.','original_method_bodies_and_old_test_block_unchanged':True,'all_other_D_input_bytes_unchanged':True,'scientific_acceptance_and_limits_unchanged':True,'no_new_lint_allowance':True,'no_arithmetic_observed_or_executed_in_preparation':True,'format_exit':result.returncode,'python_syntax':'parsed','changed_original_relative_paths':changes,'D_shifted_sha256':sha(d/'src/shifted.rs'),'E_shifted_sha256':sha(e/'src/shifted.rs'),'source_lock_must_be_public_before_execution':True}
(e/'PROSPECTIVE_LAYOUT_CORRECTION_E.json').write_text(json.dumps(prospective,indent=2)+'\n')
(e/'LAYOUT_ADDENDUM_E.md').write_text('''# E: move the unchanged adapter before the retained test module

Public D source c0a2f94debb9bd26763ebabb0dda746936fdbdd1 compiled, then
strict Clippy rejected items_after_test_module before arithmetic. The complete
D2 negative is PCC-20261117-309c13. E relocates the entire exact new visibility
adapter before the entire exact old unit12 test block, dropping the old join's
extra trailing blank line. Removing the adapter and its new join separator
from E recovers the exact original unit12 source. All original function bodies,
test block, other sources and input fixtures remain unchanged. The caller
selects E's source lock; no lint allowance is added. [pcc:unverified]

PROTOCOL_14 and PROOF_14 still govern. Keep17 witnesses,34 diagonal/cyclic
pairs, two quadratic routes,109/113 generators and10 scalar cases, conjugacy,
both declared dual[2] orientations, three malformed constructor controls and
two wrong-sign controls. Manual formula-derived kappa100 precedes any map
evaluation. Keep one worker,120s per call and8MiB/3MiB storage floors.
This preparation executes formatting and Python metadata syntax only;
the first mathematical result is still pending. [pcc:unverified]
''')
files=[]
for p in sorted(e.rglob('*')):
 if p.is_file():files.append({'path':p.relative_to(e).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p),'mode':p.stat().st_mode&0o7777})
lock={'schema':'source-input-lock14/v1','time':datetime.now(timezone.utc).isoformat(),'caller_revision':'E','parent_D_public_source':'c0a2f94debb9bd26763ebabb0dda746936fdbdd1','original_source':'77d9ad43f2a0706b5c76eaf997262f52e1ca380b','prospective_protocol_commit':'e9d833a53265908311f087ca736bfd0bed3c4f9e','prospective_claim':'PCC-20261117-9dec6a','scientific_acceptance_unchanged':True,'test_filter':'nonsplit::map::tests_14::frozen_joint_chart_divisor_map_14','files':files}
(e/'SOURCE_LOCK_14E.json').write_text(json.dumps(lock,indent=2)+'\n')
print(json.dumps({'E_files':len(files),'format_exit':result.returncode,'only_existing_input_changed':changes,'disk_free':shutil.disk_usage(r).free}))
