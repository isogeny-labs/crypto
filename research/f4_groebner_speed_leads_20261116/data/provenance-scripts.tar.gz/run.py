#!/usr/bin/env python3
"""Serial ABBA wall-clock runner. See PROTOCOL.md. Appends one JSON line per run to runs.jsonl."""
import json, os, subprocess, sys, time

S = "${SCRATCH}"
N = f"{S}/integrated/bin"
B = f"{S}/baseline/bin"
M = f"{S}/measure"
RAW = f"{M}/raw"
os.makedirs(RAW, exist_ok=True)

ALLT = {"F4_FP_PAR_OLD": "1", "F4_FP_MEM_OLD": "1", "KIC_M4RI_OLD": "1"}
# pair -> (new arm (bin, env), old arm (bin, env))
F4P = {
    "AA": ((N, {}), (N, {})),
    "CROSS": ((N, ALLT), (B, {})),
    "PAR": ((N, {}), (N, {"F4_FP_PAR_OLD": "1"})),
    "MEM": ((N, {}), (N, {"F4_FP_MEM_OLD": "1"})),
    "ALL": ((N, {}), (N, ALLT)),
    "TOTAL": ((N, {}), (B, {})),
}
GFP = {
    "AA": ((N, {}), (N, {})),
    "M4RI": ((N, {}), (N, {"KIC_M4RI_OLD": "1"})),
    "CROSS": ((N, {"KIC_M4RI_OLD": "1"}), (B, {})),
    "TOTAL": ((N, {}), (B, {})),
}
XB_PAIRS = {1: ["AA", "M4RI"], 4: ["AA", "M4RI", "CROSS", "TOTAL"]}

out = open(f"{M}/runs.jsonl", "a")
seq = [0]


def run(bench, args, pair, arm, slot, block, t, binenv):
    bindir, env = binenv
    e = dict(os.environ)
    for k in ("F4_FP_PAR_OLD", "F4_FP_MEM_OLD", "KIC_M4RI_OLD"):
        e.pop(k, None)
    e.update(env)
    e["RAYON_NUM_THREADS"] = str(t)
    seq[0] += 1
    tag = f"{seq[0]:05d}_{bench}_{'-'.join(args)}_{pair}_{arm}{slot}_b{block}_t{t}"
    t0 = time.perf_counter()
    p = subprocess.run([f"{bindir}/{bench}"] + args, env=e, capture_output=True, text=True)
    wall = (time.perf_counter() - t0) * 1000
    with open(f"{RAW}/{tag}.txt", "w") as f:
        f.write(p.stdout)
        f.write(p.stderr)
    rec = dict(seq=seq[0], bench=bench, args=args, pair=pair, arm=arm, slot=slot, block=block,
               threads=t, bin="baseline" if bindir == B else "integrated", env=env, rc=p.returncode,
               proc_wall_ms=wall, raw=f"raw/{tag}.txt", ts=time.time())
    out.write(json.dumps(rec) + "\n")
    out.flush()


def abba(block):
    return ["A", "B", "B", "A"] if block % 2 == 1 else ["B", "A", "A", "B"]


def do_pair(bench, args, pair, arms, block, t, xblock=None):
    order = abba(xblock if xblock is not None else block)
    cnt = {"A": 0, "B": 0}
    for a in order:
        run(bench, args, pair, a, cnt[a], block, t, arms[0] if a == "A" else arms[1])
        cnt[a] += 1


for block in range(1, 9):
    tb = time.time()
    for t in (1, 2, 4):
        for pname, arms in F4P.items():
            do_pair("f4_fp_bench", ["3", "large"], pname, arms, block, t)
        for pname, arms in GFP.items():
            for sysn in ("x", "sym"):
                do_pair("koblitz_f4_kernel_bench", ["5", sysn], pname, arms, block, t)
        if block % 2 == 1 and t in XB_PAIRS:
            for pname in XB_PAIRS[t]:
                do_pair("crossbred_bench", ["9", "11", "13"], pname, GFP[pname], block, t,
                        xblock=(block + 1) // 2)
    print(f"block {block} done in {time.time()-tb:.0f}s", flush=True)
print("ALL DONE", flush=True)
