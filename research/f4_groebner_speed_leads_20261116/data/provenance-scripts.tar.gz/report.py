#!/usr/bin/env python3
"""Print markdown tables from rows.json."""
import json, math
M = "${SCRATCH}/measure"
rows = json.load(open(f"{M}/rows.json"))


def table(bench, pair, cases=None):
    sel = [r for r in rows if r["bench"] == bench and r["pair"] == pair and (cases is None or r["case"] in cases)]
    if not sel:
        return ""
    o = ["| threads | case | n | new med ms | old med ms | old/new | 95% CI | A/A tau | sig |",
         "|--:|:--|--:|--:|--:|--:|:--|--:|:--:|"]
    for r in sorted(sel, key=lambda r: (r["threads"], r["case"])):
        tau = "-" if r["aa_tau_ln"] is None else f"{math.exp(r['aa_tau_ln'])-1:.1%}"
        o.append(f"| {r['threads']} | {r['case']} | {r['n_trials']} | {r['new_median_ms']:.3f} | {r['old_median_ms']:.3f} | "
                 f"{r['ratio_old_over_new']:.3f} | [{r['ci_low']:.3f}, {r['ci_high']:.3f}] | {tau} | "
                 f"{'**yes**' if r['significant'] else 'no'} |")
    return "\n".join(o)


import sys
bench, pair = sys.argv[1], sys.argv[2]
cases = sys.argv[3].split(",") if len(sys.argv) > 3 else None
print(table(bench, pair, cases))
