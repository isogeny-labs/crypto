#!/usr/bin/env python3
"""Analyse runs.jsonl per PROTOCOL.md. Writes rows.json and fingerprints.json; prints a summary."""
import json, math, random, statistics as st, sys
from collections import defaultdict

M = "${SCRATCH}/measure"
runs = [json.loads(l) for l in open(f"{M}/runs.jsonl")]

F4FP = ["basis_fp", "solve_fp", "field_ops", "solve_field_ops", "steps", "max_rows", "max_cols",
        "basis_len", "solutions"]
KFP = ["rows", "cols", "rank", "word_ops", "degree", "equations", "syzygies", "variables"]


def strip_xb(text):
    outl, drop = [], set()
    for l in text.splitlines():
        if l.startswith("|"):
            cells = l.split("|")
            if any("wall" in c for c in cells):
                drop = {i for i, c in enumerate(cells) if "wall" in c}
            outl.append("|".join(c for i, c in enumerate(cells) if i not in drop))
        else:
            if not l.strip():
                drop = set()
            outl.append(l)
    return "\n".join(outl)


def parse(r):
    """Return (metrics: {case: ms}, fingerprint: {case: tuple} or str)."""
    text = open(f"{M}/{r['raw']}").read()
    met, fp = {}, {}
    if r["bench"] == "f4_fp_bench":
        tot = 0.0
        for l in text.splitlines():
            if l.startswith("{"):
                j = json.loads(l)
                c = j["case"]
                met[c] = j["f4_ms"]
                tot += j["f4_ms"]
                if "solve_ms" in j:
                    met[c + ":solve"] = j["solve_ms"]
                fp[c] = tuple(j.get(k) for k in F4FP)
        met["SUM_f4_ms"] = tot
        met["process_wall"] = r["proc_wall_ms"]
    elif r["bench"] == "koblitz_f4_kernel_bench":
        for l in text.splitlines():
            if l.startswith("{"):
                j = json.loads(l)
                c = "kernel_" + j["system"]
                met[c] = j["median_ms"]
                fp[c] = tuple(json.dumps(j.get(k)) for k in KFP)
    else:
        hdr = None
        for l in text.splitlines():
            if l.startswith("|"):
                cells = [c.strip() for c in l.strip().strip("|").split("|")]
                if "xb wall" in cells:
                    hdr = cells
                    continue
                if hdr and len(cells) == len(hdr) and cells[0].isdigit():
                    n = cells[0]
                    for k in ("xb wall", "F4 wall"):
                        met[f"xb_n{n}:{k.replace(' ', '_')}"] = float(cells[hdr.index(k)].split()[0])
            elif not l.strip():
                hdr = None
        met["xb_process_wall"] = r["proc_wall_ms"]
        fp["stripped"] = strip_xb(text)
    return met, fp


for r in runs:
    r["met"], r["fp"] = parse(r)

# --- fingerprints: reference = first baseline-binary run per bench/args
ref = {}
for r in runs:
    key = (r["bench"], tuple(r["args"]))
    if r["bin"] == "baseline" and key not in ref:
        ref[key] = r["fp"]
fp_bad = []
for r in runs:
    key = (r["bench"], tuple(r["args"]))
    if r["rc"] != 0:
        fp_bad.append((r["raw"], "rc", r["rc"]))
        continue
    rf = ref.get(key)
    if rf is None:
        fp_bad.append((r["raw"], "noref"))
    elif r["fp"] != rf:
        diff = [c for c in set(rf) | set(r["fp"]) if rf.get(c) != r["fp"].get(c)]
        fp_bad.append((r["raw"], "mismatch", diff))
fpsum = dict(runs_checked=len(runs), mismatches=fp_bad[:50], n_mismatch=len(fp_bad),
             reference_runs={f"{k[0]} {' '.join(k[1])}": "first baseline-binary run" for k in ref})
json.dump(fpsum, open("${SCRATCH}/redteam/out/fingerprints.json", "w"), indent=1)

# --- statistics
groups = defaultdict(lambda: {"A": [], "B": []})  # (bench,args,pair,t) -> arm -> list of (block,slot,met)
for r in runs:
    groups[(r["bench"], " ".join(r["args"]), r["pair"], r["threads"])][r["arm"]].append(
        ((r["block"], r["slot"]), r["met"]))

rng = random.Random(20261116)


def boot(a, b, n=2000):
    k = len(a)
    rs = []
    for _ in range(n):
        idx = [rng.randrange(k) for _ in range(k)]
        ma = st.median(a[i] for i in idx)
        mb = st.median(b[i] for i in idx)
        rs.append(mb / ma)
    rs.sort()
    return rs[int(0.025 * n)], rs[int(0.975 * n) - 1]


rows = []
for (bench, args, pair, t), arms in sorted(groups.items()):
    A = dict(arms["A"]); Bm = dict(arms["B"])
    keys = sorted(set(A) & set(Bm))
    cases = sorted(set().union(*[set(m) for m in A.values()]))
    for c in cases:
        a = [A[k][c] for k in keys if c in A[k] and c in Bm[k]]
        b = [Bm[k][c] for k in keys if c in A[k] and c in Bm[k]]
        if len(a) < 4:
            continue
        mn, mo = st.median(a), st.median(b)
        if mn <= 0 or mo <= 0:
            continue
        lo, hi = boot(a, b)
        rows.append(dict(bench=bench, args=args, pair=pair, threads=t, case=c, n_trials=len(a),
                         new_median_ms=mn, old_median_ms=mo, ratio_old_over_new=mo / mn,
                         ci_low=lo, ci_high=hi))

aa = {(r["bench"], r["args"], r["threads"], r["case"]): r for r in rows if r["pair"] == "AA"}
for r in rows:
    q = aa.get((r["bench"], r["args"], r["threads"], r["case"]))
    tau = None
    if q:
        tau = max(abs(math.log(q["ci_low"])), abs(math.log(q["ci_high"])),
                  abs(math.log(q["ratio_old_over_new"])))
    r["aa_tau_ln"] = tau
    excl = r["ci_low"] > 1 or r["ci_high"] < 1
    r["ci_excludes_1"] = excl
    r["significant"] = bool(excl and tau is not None and abs(math.log(r["ratio_old_over_new"])) > tau
                            and r["pair"] != "AA")
json.dump(rows, open("${SCRATCH}/redteam/out/rows.json", "w"), indent=1)
print(f"runs={len(runs)} rows={len(rows)} fingerprint_mismatches={len(fp_bad)}")
for x in fp_bad[:10]:
    print("  FP", x)
