#!/usr/bin/env python3
"""Red-team fingerprint/race check. Runs only after the measurement runner exits.
Writes everything under redteam/out; never touches measure/ or integrated/."""
import json, os, subprocess, sys, time, itertools
S = "${SCRATCH}"
N = f"{S}/integrated/bin"; B = f"{S}/baseline/bin"; O = f"{S}/redteam/out"
F4K = ["basis_fp","solve_fp","field_ops","solve_field_ops","steps","max_rows","max_cols","basis_len","solutions"]
KK = ["rows","cols","rank","word_ops","syzygies","degree","equations","variables"]
log = open(f"{O}/fpcheck.jsonl","a")
TOG = ("F4_FP_PAR_OLD","F4_FP_MEM_OLD","KIC_M4RI_OLD")
def run(bindir, bench, args, env, t, tag):
    e = {k:v for k,v in os.environ.items() if not k.startswith(("F4_","KIC_","RAYON"))}
    e.update(env); e["RAYON_NUM_THREADS"] = str(t)
    t0=time.time()
    p = subprocess.run([f"{bindir}/{bench}"]+args, env=e, capture_output=True, text=True)
    out = p.stdout
    with open(f"{O}/{tag}.txt","w") as f: f.write(out); f.write("\n--stderr--\n"+p.stderr[-4000:])
    res = {}
    if bench == "f4_fp_bench":
        for l in out.splitlines():
            if l.startswith("{"):
                j=json.loads(l); res[j["case"]] = [j.get(k) for k in F4K]
    elif bench == "koblitz_f4_kernel_bench":
        for l in out.splitlines():
            if l.startswith("{"):
                j=json.loads(l); res[j["system"]] = [j.get(k) for k in KK]
    else:
        lines=[]; drop=set()
        for l in out.splitlines():
            if l.startswith("|"):
                cells=l.split("|")
                if any("wall" in c for c in cells): drop={i for i,c in enumerate(cells) if "wall" in c}
                lines.append("|".join(c for i,c in enumerate(cells) if i not in drop))
            else:
                if not l.strip(): drop=set()
                lines.append(l)
        res["stripped"] = "\n".join(lines)
    rec=dict(tag=tag,bin="baseline" if bindir==B else "integrated",bench=bench,args=args,env=env,threads=t,rc=p.returncode,secs=time.time()-t0,res=res)
    log.write(json.dumps(rec)+"\n"); log.flush()
    return rec
# wait for measurement runner
while os.path.exists("/proc/9055"):
    time.sleep(20)
log.write(json.dumps({"start":time.time(),"load":os.getloadavg()})+"\n"); log.flush()
results=[]
K1={"F4_FP_PAR_FL_MODE":"tiles","F4_FP_PAR_FL_WORK":"0","F4_FP_PAR_FL_TILES":"7","F4_FP_PAR_SYM_SEEDS":"0","F4_FP_PAR_SYM_FRONTIER":"0"}
K2={"F4_FP_PAR_FL_MODE":"rows","F4_FP_PAR_FL_INBLOCK":"0","F4_FP_PAR_SYM_SEEDS":"1","F4_FP_PAR_SYM_FRONTIER":"1"}
ALLT={k:"1" for k in TOG}
seq=0
def R(bindir,bench,args,env,t,label):
    global seq; seq+=1
    results.append(run(bindir,bench,args,env,t,f"{seq:04d}_{label}_t{t}"))
# fixed suite
R(B,"f4_fp_bench",["1","large"],{},1,"base_fixed"); R(B,"f4_fp_bench",["1","large"],{},3,"base_fixed")
for rep in range(3):
    for t in (1,2,3,4,6,8):
        R(N,"f4_fp_bench",["1","large"],{},t,f"new_fixed_r{rep}")
for t in (2,3,4,8):
    for rep in range(2):
        R(N,"f4_fp_bench",["1","large"],K1,t,f"k1_fixed_r{rep}"); R(N,"f4_fp_bench",["1","large"],K2,t,f"k2_fixed_r{rep}")
for t in (3,):
    R(N,"f4_fp_bench",["1","large"],{"F4_FP_PAR_OLD":"1"},t,"parold_fixed"); R(N,"f4_fp_bench",["1","large"],{"F4_FP_MEM_OLD":"1"},t,"memold_fixed"); R(N,"f4_fp_bench",["1","large"],ALLT,t,"allold_fixed")
# fresh seeds (held-out systems)
for sx in ("1","2","deadbeef","5eed5eed","c0ffee"):
    R(B,"f4_fp_bench",["1","large",sx],{},1,f"base_s{sx}")
    for t in (1,3,4):
        R(N,"f4_fp_bench",["1","large",sx],{},t,f"new_s{sx}")
    R(N,"f4_fp_bench",["1","large",sx],K1,4,f"k1_s{sx}"); R(N,"f4_fp_bench",["1","large",sx],K2,3,f"k2_s{sx}")
    R(N,"f4_fp_bench",["1","large",sx],ALLT,4,f"allold_s{sx}")
# GF(2)
for sysn in ("x","sym"):
    R(B,"koblitz_f4_kernel_bench",["1",sysn],{},1,f"base_k{sysn}")
    for t in (1,3,4): R(N,"koblitz_f4_kernel_bench",["1",sysn],{},t,f"new_k{sysn}")
    R(N,"koblitz_f4_kernel_bench",["1",sysn],{"KIC_M4RI_OLD":"1"},3,f"old_k{sysn}")
R(B,"crossbred_bench",["9","11","13"],{},3,"base_xb"); R(N,"crossbred_bench",["9","11","13"],{},3,"new_xb")
# compare
ref={}
for r in results:
    if r["bin"]=="baseline": ref[(r["bench"],tuple(r["args"]))]=ref.get((r["bench"],tuple(r["args"])),r["res"])
bad=[]
for r in results:
    rf=ref.get((r["bench"],tuple(r["args"])))
    if r["rc"]!=0: bad.append((r["tag"],"rc",r["rc"])); continue
    if rf is None: bad.append((r["tag"],"noref")); continue
    if r["res"]!=rf:
        diff=[c for c in set(rf)|set(r["res"]) if rf.get(c)!=r["res"].get(c)]
        bad.append((r["tag"],"mismatch",diff,[(c,rf.get(c),r["res"].get(c)) for c in diff][:3]))
summ=dict(n_runs=len(results),n_bad=len(bad),bad=bad,end=time.time(),load=os.getloadavg())
json.dump(summ,open(f"{O}/summary.json","w"),indent=1)
print(json.dumps(summ)[:3000])
