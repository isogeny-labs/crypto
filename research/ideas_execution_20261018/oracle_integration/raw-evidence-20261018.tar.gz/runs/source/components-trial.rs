//! Native component certificates for items 4, 16 and 17 of the 2026-10-18 audit.
//! These are correctness certificates, not a four-presentation solver study.
use std::collections::{BTreeMap, BTreeSet};
use std::fs;

use crypto_lib::binary_ecc::curve::point_add;
use crypto_lib::binary_ecc::{BinaryCurve, BinaryPoint, F2mElement};
use crypto_lib::cryptanalysis::koblitz_index_calculus::{
    find_irreducible_sparse_wide, points_with_x, KoblitzCurve,
};
use crypto_lib::cryptanalysis::wide_gf2m::WideGf2;
use num_bigint::BigUint;
use num_traits::ToPrimitive;
use serde_json::{json, Value};

fn fpow(f: &WideGf2, mut a: u128, mut e: u128) -> u128 {
    let mut z = 1;
    while e > 0 {
        if e & 1 != 0 {
            z = f.mul(z, a);
        }
        a = f.sqr(a);
        e >>= 1;
    }
    z
}

fn hex(a: u128) -> String {
    format!("{a:x}")
}

fn rank(xs: &[u128], n: usize) -> usize {
    let mut pivots = vec![0u128; n];
    let mut out = 0;
    for &x in xs {
        let mut v = x;
        while v != 0 {
            let b = 127 - v.leading_zeros() as usize;
            if pivots[b] == 0 {
                pivots[b] = v;
                out += 1;
                break;
            }
            v ^= pivots[b];
        }
    }
    out
}

fn c2_member(f: &WideGf2, roots: &[u128], x: u128) -> bool {
    // C2 uses subsets of cardinality 2: repeated roots are excluded.
    roots
        .iter()
        .any(|&z| x ^ z != z && fpow(f, x ^ z, 167) == 1)
}

fn cyclotomic_n83() -> Value {
    let n = 83;
    let irr = find_irreducible_sparse_wide(n).expect("degree-83 irreducible");
    let f = WideGf2::new(&irr);
    let exponent = ((1u128 << n) - 1) / 167;
    let candidate = (2..4096)
        .find(|&a| fpow(&f, a, exponent) != 1)
        .expect("nontrivial 167th root in frozen candidate range");
    let gamma = fpow(&f, candidate, exponent);
    assert_ne!(gamma, 1);
    assert_eq!(fpow(&f, gamma, 167), 1);
    let roots: Vec<_> = (0..167).map(|i| fpow(&f, gamma, i)).collect();
    let root_set: BTreeSet<_> = roots.iter().copied().collect();
    assert_eq!(root_set.len(), 167);
    let mut onb = Vec::new();
    let mut k = 1;
    for _ in 0..83 {
        onb.push(roots[k] ^ roots[(167 - k) % 167]);
        k = (k * 2) % 167;
    }
    assert_eq!(k, 1);
    let onb_rank = rank(&onb, 83);
    assert_eq!(onb_rank, 83);
    for i in 0..83 {
        assert_eq!(f.sqr(onb[i]), onb[(i + 1) % 83]);
    }
    let mut generic_checks = 0;
    for &r in &roots {
        let generic = F2mElement::from_biguint(&BigUint::from(r), n);
        assert_eq!(generic.square(&irr).to_biguint().to_u128(), Some(f.sqr(r)));
        let g = F2mElement::from_biguint(&BigUint::from(gamma), n);
        assert_eq!(
            generic.mul(&g, &irr).to_biguint().to_u128(),
            Some(f.mul(r, gamma))
        );
        generic_checks += 2;
    }
    let mut c2 = BTreeMap::new();
    let mut hasher = blake3::Hasher::new();
    let mut witnesses = Vec::new();
    for i in 0..167 {
        for j in i + 1..167 {
            let x = roots[i] ^ roots[j];
            assert_eq!(fpow(&f, roots[i], 167), 1);
            assert_eq!(fpow(&f, roots[j], 167), 1);
            c2.entry(x).or_insert((i, j));
        }
    }
    for (&x, &(i, j)) in &c2 {
        hasher.update(&x.to_le_bytes());
        hasher.update(&(i as u32).to_le_bytes());
        hasher.update(&(j as u32).to_le_bytes());
        assert!(c2.contains_key(&f.sqr(x)));
        witnesses.push(json!({"x_hex":hex(x),"i":i,"j":j}));
    }
    for &r in &roots {
        assert!(root_set.contains(&f.sqr(r)));
    }
    let mut state = 20261018u128;
    let mut member_probes = 0;
    for _ in 0..4096 {
        state ^= state << 31;
        state ^= state >> 19;
        state ^= state << 23;
        let x = state & f.mask();
        let answer = c2_member(&f, &roots, x);
        assert_eq!(answer, c2.contains_key(&x));
        member_probes += usize::from(answer);
    }
    // Probe every member with a separate constructive lookup predicate.
    let mut witnessed = 0;
    for &x in c2.keys() {
        assert!(roots
            .iter()
            .any(|&z| z != x ^ z && root_set.contains(&(x ^ z))));
        witnessed += 1;
    }
    json!({"kind":"cyclotomic_component_certificate","n":n,"p":167,
        "field_modulus_hex":hex(f.modulus_bits()),"kernel":f.kernel_name(),
        "candidate":candidate,"gamma_hex":hex(gamma),"gamma_order":167,
        "generic_backend_checks":generic_checks,"onb_rank":onb_rank,
        "onb_hex":onb.iter().map(|&x|hex(x)).collect::<Vec<_>>(),
        "c1_cardinality":roots.len(),"c2_pair_count":167*166/2,
        "c2_cardinality":c2.len(),"c2_witnessed_members":witnessed,
        "frobenius_closed":true,"full_width_probes":4096,
        "probe_members":member_probes,"probe_mismatches":0,
        "c2_certificate_blake3":hasher.finalize().to_hex().to_string(),
        "c2_witnesses":witnesses,"passed":true,
        "scope":"multiword field/base construction and C2 membership only; no subgroup projection, descent solving degree, useful rank or ECDLP cost measured"})
}

#[derive(Clone)]
enum MobiusPoint {
    Infinity,
    Affine {
        u: F2mElement,
        v: F2mElement,
        y: F2mElement,
    },
}

fn encode(p: &BinaryPoint, n: u32) -> MobiusPoint {
    match p {
        BinaryPoint::Infinity => MobiusPoint::Infinity,
        BinaryPoint::Affine { x, y } => MobiusPoint::Affine {
            u: F2mElement::one(n),
            v: x.add(&F2mElement::one(n)),
            y: y.clone(),
        },
    }
}

fn decode(p: &MobiusPoint, c: &BinaryCurve) -> BinaryPoint {
    match p {
        MobiusPoint::Infinity => BinaryPoint::Infinity,
        MobiusPoint::Affine { u, v, y } => BinaryPoint::Affine {
            x: u.add(v).mul(
                &u.flt_inverse(&c.irreducible).expect("valid inverse chart"),
                &c.irreducible,
            ),
            y: y.clone(),
        },
    }
}

// Check the unprojected polynomial graph of addition independently of the
// output coordinate formulas. Branch tests keep denominators nonzero.
fn addition_witness(
    c: &BinaryCurve,
    p: &BinaryPoint,
    q: &BinaryPoint,
    r: &BinaryPoint,
) -> &'static str {
    let irr = &c.irreducible;
    match (p, q) {
        (BinaryPoint::Infinity, _) => {
            assert_eq!(q, r);
            "identity-left"
        }
        (_, BinaryPoint::Infinity) => {
            assert_eq!(p, r);
            "identity-right"
        }
        (BinaryPoint::Affine { x: x1, y: y1 }, BinaryPoint::Affine { x: x2, y: y2 }) => {
            if x1 == x2 && y1.add(y2) == *x1 {
                assert_eq!(*r, BinaryPoint::Infinity);
                return "inverse-or-two-torsion";
            }
            let BinaryPoint::Affine { x: x3, y: y3 } = r else {
                panic!("finite generic/double result")
            };
            assert!(c.is_on_curve(r));
            if x1 == x2 {
                assert_eq!(y1, y2);
                assert!(!x1.is_zero());
                let lambda = x1
                    .square(irr)
                    .add(y1)
                    .mul(&x1.flt_inverse(irr).unwrap(), irr);
                assert!(lambda.mul(x1, irr).add(&x1.square(irr)).add(y1).is_zero());
                assert!(x3.add(&lambda.square(irr)).add(&lambda).add(&c.a).is_zero());
                assert!(y3
                    .add(&x1.square(irr))
                    .add(&lambda.add(&F2mElement::one(c.m)).mul(x3, irr))
                    .is_zero());
                "doubling"
            } else {
                let d = x1.add(x2);
                let lambda = y1.add(y2).mul(&d.flt_inverse(irr).unwrap(), irr);
                assert!(lambda.mul(&d, irr).add(y1).add(y2).is_zero());
                assert!(x3
                    .add(&lambda.square(irr))
                    .add(&lambda)
                    .add(x1)
                    .add(x2)
                    .add(&c.a)
                    .is_zero());
                assert!(y3
                    .add(&lambda.mul(&x1.add(x3), irr))
                    .add(x3)
                    .add(y1)
                    .is_zero());
                "generic"
            }
        }
    }
}

fn key(p: &BinaryPoint) -> String {
    match p {
        BinaryPoint::Infinity => "O".into(),
        BinaryPoint::Affine { x, y } => format!(
            "{}:{}",
            x.to_biguint().to_str_radix(16),
            y.to_biguint().to_str_radix(16)
        ),
    }
}

fn presentation_cert() -> Value {
    let kc = KoblitzCurve::new(0, 7).expect("public K0/GF(2^7)");
    let c = &kc.curve;
    let mut rows = Vec::new();
    for (m, ell) in [(3u32, 4u32), (4, 3)] {
        let xs: Vec<_> = (0u32..1 << ell)
            .map(|v| F2mElement::from_biguint(&BigUint::from(v), 7))
            .collect();
        let points: Vec<_> = xs.iter().flat_map(|x| points_with_x(c, x)).collect();
        let mut with_o = points.clone();
        with_o.push(BinaryPoint::Infinity);
        let mut branches = BTreeMap::<&str, usize>::new();
        let mut poles = 0;
        let mut certificate = blake3::Hasher::new();
        for p in &with_o {
            assert_eq!(decode(&encode(p, c.m), c), *p);
            if matches!(encode(p,c.m),MobiusPoint::Affine { ref v,.. } if v.is_zero()) {
                poles += 1;
            }
            for q in &with_o {
                let r = point_add(c, p, q);
                *branches.entry(addition_witness(c, p, q, &r)).or_default() += 1;
                let transported =
                    point_add(c, &decode(&encode(p, c.m), c), &decode(&encode(q, c.m), c));
                assert_eq!(r, decode(&encode(&transported, c.m), c));
                certificate.update(key(&r).as_bytes());
                certificate.update(b"\n");
            }
        }
        let tuples = points.len().pow(m);
        let mut sums = BTreeSet::new();
        let mut infinity_sums = 0;
        for mut index in 0..tuples {
            let mut sum = BinaryPoint::Infinity;
            let mut transport = MobiusPoint::Infinity;
            for _ in 0..m {
                let p = &points[index % points.len()];
                index /= points.len();
                sum = point_add(c, &sum, p);
                let previous = decode(&transport, c);
                let result = point_add(c, &previous, &decode(&encode(p, c.m), c));
                addition_witness(c, &previous, p, &result);
                transport = encode(&result, c.m);
            }
            assert_eq!(sum, decode(&transport, c));
            infinity_sums += usize::from(sum == BinaryPoint::Infinity);
            let k = key(&sum);
            certificate.update(k.as_bytes());
            certificate.update(b"\n");
            sums.insert(k);
        }
        rows.push(json!({"m":m,"ell":ell,"base_x_words":(0..1u32<<ell).collect::<Vec<_>>(),
            "base_points":points.iter().map(key).collect::<Vec<_>>(),"lifted_points":points.len(),
            "ordered_pair_checks":with_o.len()*with_o.len(),"branch_counts":branches,
            "mobius_pole_points":poles,"ordered_tuple_checks":tuples,"infinity_sums":infinity_sums,
            "distinct_sums":sums.len(),"certificate_blake3":certificate.finalize().to_hex().to_string(),
            "solving_degree":null,"macaulay_columns":null,"passed":true}));
    }
    json!({"kind":"presentation_component_certificate","a":0,"b":1,"n":7,
        "curve_identity":"K_0: y^2+xy=x^3+1 over GF(2^7)",
        "modulus_low_terms":c.irreducible.low_terms,"group_order":kc.group_order.to_string(),
        "target_law":"complete ordered tuple sum census; not planted decompositions",
        "mobius_map":"[X:Z] -> [Z:X+Z]; Y retained; projective pole V=0 included",
        "panels":rows,"passed":true,
        "scope":"coordinate transport and branch-complete addition certificates only; four descended presentations and degree comparison remain unimplemented"})
}

fn summarize(path: &str) -> Value {
    let mut panels = Vec::new();
    for name in ["equivariant-step", "equivariant-oracle"] {
        let raw = fs::read_to_string(format!("{path}/{name}.stdout.jsonl")).unwrap();
        let rows: Vec<Value> = raw
            .lines()
            .filter(|s| !s.trim().is_empty())
            .map(|s| serde_json::from_str(s).expect("native JSONL record"))
            .collect();
        let gates: Vec<_> = rows.iter().map(|r| r["gate"].clone()).collect();
        let gate_true = gates.iter().filter(|v| **v == Value::Bool(true)).count();
        let by_n: BTreeMap<u64, usize> = rows.iter().fold(BTreeMap::new(), |mut out, r| {
            *out.entry(r["n"].as_u64().unwrap()).or_default() += 1;
            out
        });
        panels.push(json!({"name":name,"rows":rows.len(),"gate_true":gate_true,
            "gate_false":gates.iter().filter(|v| **v == Value::Bool(false)).count(),"by_n":by_n,
            "contained_true":rows.iter().filter(|r|r["contained"]==Value::Bool(true)).count(),
            "contained_false":rows.iter().filter(|r|r["contained"]==Value::Bool(false)).count(),
            "source":format!("{name}.stdout.jsonl")}));
    }
    json!({"panels":panels,"isolation":"L0 shared host","performance_claim":"none; incidental CPU/wall fields retained only"})
}

fn main() {
    let args: Vec<_> = std::env::args().collect();
    let mode = args
        .get(1)
        .expect("cyclotomic-n83|presentation-cert|summarize");
    let output = args.get(2).expect("output JSON file");
    let result = match mode.as_str() {
        "cyclotomic-n83" => cyclotomic_n83(),
        "presentation-cert" => presentation_cert(),
        "summarize" => summarize(args.get(3).expect("raw run directory")),
        _ => panic!("unknown mode"),
    };
    fs::write(output, serde_json::to_vec_pretty(&result).unwrap()).unwrap();
    println!("{}", json!({"mode":mode,"output":output,"passed":true}));
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn high_word_field_and_generic_backend_agree() {
        let irr = find_irreducible_sparse_wide(83).unwrap();
        let f = WideGf2::new(&irr);
        for a in [1u128 << 80, (1 << 82) | (1 << 65) | 17] {
            for b in [2u128, (1 << 75) | 3] {
                let ga = F2mElement::from_biguint(&BigUint::from(a), 83);
                let gb = F2mElement::from_biguint(&BigUint::from(b), 83);
                assert_eq!(ga.mul(&gb, &irr).to_biguint().to_u128(), Some(f.mul(a, b)));
            }
        }
    }
    #[test]
    fn mobius_pole_identity_inverse_and_doubling_are_retained() {
        let kc = KoblitzCurve::new(0, 7).unwrap();
        let c = &kc.curve;
        let ps = points_with_x(c, &F2mElement::one(7));
        assert!(!ps.is_empty());
        for p in ps {
            assert!(matches!(encode(&p,7),MobiusPoint::Affine {ref v,..} if v.is_zero()));
            assert_eq!(decode(&encode(&p, 7), c), p);
            let neg = crypto_lib::binary_ecc::curve::point_neg(&p);
            assert_eq!(
                addition_witness(c, &p, &neg, &point_add(c, &p, &neg)),
                "inverse-or-two-torsion"
            );
            assert_eq!(
                addition_witness(c, &p, &p, &point_add(c, &p, &p)),
                "doubling"
            );
            assert_eq!(
                addition_witness(c, &BinaryPoint::Infinity, &p, &p),
                "identity-left"
            );
        }
    }
}
