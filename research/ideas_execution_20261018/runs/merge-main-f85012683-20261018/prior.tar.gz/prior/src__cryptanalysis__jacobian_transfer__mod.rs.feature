//! # Jacobian transfer discovery across the curve registry.
//!
//! For every curve in `docs/curves/registry.json` this module enumerates the
//! known ways of moving its discrete logarithm into the Jacobian of a curve
//! of higher genus, prices each route with one frozen formula-level cost
//! model ([`cost::CostModel`]), and reports the ratio of that price to the
//! Pollard-rho reference on the original subgroup.  The result is
//! `docs/curves/jacobian-transfers.json`, rebuilt and checked by
//! `cargo run --release --bin jacobian_transfers`; see
//! `docs/curves/JACOBIAN_TRANSFERS.md`.
//!
//! Routes, by field:
//!
//! | field | route | what is exact | what is estimated |
//! |:--|:--|:--|:--|
//! | `GF(2^N)` | GHS Weil descent, every `N = n * l` | magic number, type, genus | solver cost |
//! | `GF(2^N)` | GHS isogeny extension (Galbraith–Hess–Smart) | annihilator-degree census | class membership, walk cost |
//! | `GF(2^N)` | same-field genus-3 cover (`COVERS.md`) | genus, degree | solver cost |
//! | `GF(p)` | same-field genus-2 cover (`COVERS.md`) | genus, degree | solver cost |
//! | `GF(p)` | base change to `GF(p^k)` then a genus-`k` descent | nothing (existence open) | solver cost at the most favourable genus |
//! | `GF(p^k)` | Gaudry–Diem decomposition on `E(F_{p^k})` | — | relation and decomposition cost |
//! | `GF(p^k)` | descent to a cover over `GF(p)` | nothing (existence open) | solver cost at the most favourable genus: `k`, or the GHS floor ([`ghs_genus_floor`]) where that is higher |
//!
//! Every row is a formula.  A `formula_advantage` row says the literature's
//! complexity formulas, with the stated constants, put the route below rho on
//! that subgroup by at least the margin; it is a lead with named open
//! obligations (`AGENTS.md`, curve-structure rules), not a speedup, a
//! measured result or a security claim.  A `boundary` row says the formulas
//! themselves place the route at or above rho, so no constant-factor work on
//! it can cross rho.

pub mod binary;
pub mod cost;
pub mod report;

use std::collections::BTreeMap;

use num_bigint::{BigInt, BigUint};
use num_traits::{ToPrimitive, Zero};
use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::binary_ecc::{F2mElement, IrreduciblePoly};
use crate::cryptanalysis::curve_traits::arith::{factor, log2_abs};
use crate::cryptanalysis::ec_trapdoor::DescentRow;
use cost::{CostModel, DestinationCost, DestinationSolver};

pub const SCHEMA: &str = "jacobian-transfers/2";

/// Least genus of a GHS compositum cover in odd characteristic, by the
/// Frobenius period `n` of the branch set (that is, for `E/F_{q^n}` with
/// `F_q(j(E)) = F_{q^n}`), for `n = 1..=14`.  It depends only on the orbit
/// type of the branch locus, never on `q`.  Every degree-2 function on such
/// an `E` has a branch set of period exactly `n`, so this is a lower bound on
/// every GHS cover; whether a particular curve attains it is a separate
/// question (Joux–Vitse, Eurocrypt 2012, App. C, shapes 12/13, give 9 as the
/// minimum at `n = 6`, not a genus-9 cover of any given curve).
/// Source: `research/odd_char_descent_genus3_20261014/` (Theorem 3 and the
/// exact enumeration in `results/run-20261014T1800Z/min_genus.csv`).
const GHS_GENUS_FLOOR: [u32; 14] = [1, 2, 3, 5, 5, 9, 7, 33, 81, 49, 1793, 25, 9217, 41];

/// The least genus of any GHS cover of `E/F_{p^k}` when `F_p(j(E)) = F_{p^k}`,
/// or `None` for `k` outside the enumerated range `1..=14`.  A curve whose
/// `j` lies in a proper subfield can have a smaller cover, and a non-GHS
/// construction is not covered by this bound.
pub fn ghs_genus_floor(k: u32) -> Option<u32> {
    k.checked_sub(1)
        .and_then(|i| GHS_GENUS_FLOOR.get(i as usize))
        .copied()
}

/// Pollard-rho iterations spent factoring an order whose subgroup the
/// registry does not record.
pub const DEFAULT_FACTOR_BUDGET: u64 = 200_000;

// ── Registry input ────────────────────────────────────────────────────

/// The field a registered model lives over.
#[derive(Clone, Debug)]
pub enum Field {
    /// `GF(2^n)` with its reduction polynomial and the curve's `a`, `b`.
    Binary {
        n: u32,
        irr: IrreduciblePoly,
        a: F2mElement,
        b: F2mElement,
    },
    /// `GF(p)`.
    Prime { p: BigUint },
    /// `GF(p^k)`, `k >= 2`.
    Extension { p: BigUint, k: u32 },
}

/// A registry entry, read for transfer screening.
#[derive(Clone, Debug)]
pub struct RegistryCurve {
    pub slug: String,
    pub family: String,
    pub icv1: String,
    pub standard_names: Vec<String>,
    pub field: Field,
    pub trace: BigInt,
    pub order: BigUint,
    /// The prime subgroup order the registry records, if any.
    pub subgroup_order: Option<BigUint>,
}

fn parse_uint(s: &str) -> Option<BigUint> {
    match s.strip_prefix("0x") {
        Some(h) => BigUint::parse_bytes(h.as_bytes(), 16),
        None => s.parse().ok(),
    }
}

fn str_field<'a>(v: &'a Value, key: &str) -> Result<&'a str, String> {
    v[key]
        .as_str()
        .ok_or_else(|| format!("missing string field {key}"))
}

fn parse_field(model: &Value, label: &str) -> Result<Field, String> {
    let num = |key: &str| {
        str_field(model, key).and_then(|s| parse_uint(s).ok_or_else(|| format!("bad {key}: {s}")))
    };
    if label.starts_with("f2m-") {
        let modulus = num("modulus")?;
        let n = (modulus.bits() - 1) as u32;
        if !label.starts_with(&format!("f2m-{n}-")) {
            return Err(format!("field {label} is not of degree {n}"));
        }
        let irr = IrreduciblePoly {
            degree: n,
            low_terms: (0..n).filter(|&i| modulus.bit(u64::from(i))).collect(),
        };
        let a = F2mElement::from_biguint(&num("a")?, n);
        let b = F2mElement::from_biguint(&num("b")?, n);
        Ok(Field::Binary { n, irr, a, b })
    } else if label.starts_with("fpk-") {
        let p = num("p")?;
        let k: u32 = str_field(model, "k")?
            .parse()
            .map_err(|_| "bad extension degree".to_string())?;
        if k < 2 {
            return Err("extension label with degree below 2".into());
        }
        Ok(Field::Extension { p, k })
    } else if label.starts_with("fp-") {
        Ok(Field::Prime { p: num("p")? })
    } else {
        Err(format!("unknown field label {label}"))
    }
}

/// Parse `docs/curves/registry.json`, every form of model, keeping what the
/// transfer screen needs.  The recorded order is checked against the ICV1
/// trace and the Hasse bound.
pub fn read_registry(text: &str) -> Result<Vec<RegistryCurve>, String> {
    let doc: Value = serde_json::from_str(text).map_err(|e| format!("registry JSON: {e}"))?;
    let curves = doc["curves"].as_array().ok_or("registry has no curves")?;
    let mut out = Vec::with_capacity(curves.len());
    for c in curves {
        let slug = str_field(c, "slug")?.to_string();
        let ctx = |e: String| format!("{slug}: {e}");
        let icv1 = str_field(c, "icv1")?.to_string();
        let parts: Vec<&str> = icv1.split(':').collect();
        let label = parts
            .get(1)
            .ok_or_else(|| ctx("ICV1 has no field".into()))?;
        let model: Value = serde_json::from_str(str_field(c, "model_json")?)
            .map_err(|e| ctx(format!("model JSON: {e}")))?;
        let field = parse_field(&model, label).map_err(ctx)?;
        let trace: BigInt = parts
            .get(2)
            .and_then(|t| t.parse().ok())
            .ok_or_else(|| ctx("ICV1 string has no trace".into()))?;
        let order = parse_uint(str_field(c, "order")?).ok_or_else(|| ctx("bad order".into()))?;
        let q = field_size(&field);
        if BigInt::from(q.clone()) + 1 - &trace != BigInt::from(order.clone()) {
            return Err(ctx(format!("order {order} ≠ q + 1 − t for t = {trace}")));
        }
        if &trace * &trace > BigInt::from(q) * 4u8 {
            return Err(ctx(format!("|t| = |{trace}| exceeds the Hasse bound 2√q")));
        }
        let subgroup_order = c["representations"]
            .as_array()
            .into_iter()
            .flatten()
            .filter_map(|r| r["curve"]["subgroup_order"].as_str().and_then(parse_uint))
            .max();
        let standard_names = c["standard_names"]
            .as_array()
            .into_iter()
            .flatten()
            .filter_map(|v| v.as_str().map(str::to_string))
            .collect();
        out.push(RegistryCurve {
            slug,
            family: str_field(c, "family")?.to_string(),
            icv1,
            standard_names,
            field,
            trace,
            order,
            subgroup_order,
        });
    }
    Ok(out)
}

fn field_size(f: &Field) -> BigUint {
    match f {
        Field::Binary { n, .. } => BigUint::from(1u32) << *n,
        Field::Prime { p } => p.clone(),
        Field::Extension { p, k } => p.pow(*k),
    }
}

/// Round a stored value to three decimals and at most 12 significant digits,
/// so the committed file does not depend on the last bits of the platform's
/// `log2`/`exp2`/`ln` (CI rebuilds on Linux what was written on macOS).
pub fn round_to(x: f64, digits: i32) -> f64 {
    if !x.is_finite() {
        return x;
    }
    let scale = 10f64.powi(digits);
    let r = (x * scale).round() / scale;
    if r.abs() >= 1e9 {
        format!("{r:.11e}").parse().expect("formatted float")
    } else {
        r
    }
}

/// `log2 x` for a positive integer, to double precision.
pub fn log2_biguint(x: &BigUint) -> f64 {
    if x.is_zero() {
        return f64::NEG_INFINITY;
    }
    let bits = x.bits();
    if bits <= 53 {
        return x.to_f64().expect("fits").log2();
    }
    let top = (x >> (bits - 53)).to_f64().expect("53 bits");
    top.log2() + (bits - 53) as f64
}

// ── The record ────────────────────────────────────────────────────────

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct FieldInfo {
    /// `binary`, `prime` or `extension`.
    pub kind: String,
    /// `GF(2^n)`: `n`; `GF(p)`: 1; `GF(p^k)`: `k`.
    pub degree: u32,
    /// `log2` of the field size.
    pub log2_size: f64,
    /// `log2 p` for an extension field, else equal to `log2_size`.
    pub log2_base: f64,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct SubgroupInfo {
    /// Decimal prime order `r`, or the bound used when it is not established.
    pub order: String,
    pub bits: f64,
    /// `registry_representation`, `largest_prime_of_order`, or
    /// `largest_unfactored_composite_bound` (an upper bound on `r`).
    pub status: String,
}

/// How a route's destination relates to the subgroup.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Transport {
    /// The subgroup is carried whenever `r` is coprime to the map degree
    /// (a same-field cover pulls back injectively on the `r`-torsion).
    CarriedIfCoprimeToDegree,
    /// The Jacobian is large enough to contain the subgroup; carrying it is a
    /// necessary-condition check only.
    SizeAdmits,
    /// The Jacobian cannot contain a subgroup of order `r`.
    TooSmall,
    /// The descent curve is `E` itself over the subfield: nothing is gained.
    Degenerate,
    /// The GHS cover exists over the top field but does not descend to the
    /// subfield: MMT Lemma 6 condition (8) fails.
    DescentObstructed,
    /// Not applicable: the route stays on `E`.
    SameGroup,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize, PartialOrd, Ord)]
#[serde(rename_all = "snake_case")]
pub enum RouteClass {
    /// The formulas, with the stated constants, place the route at least
    /// the margin below rho and the subgroup can be carried.
    FormulaAdvantage,
    /// The formulas place the route below rho but by less than the margin:
    /// the exponents favour it and the constants decide.
    FormulaMarginal,
    /// The formulas place the route at or above rho.
    Boundary,
    /// The subgroup is not carried, so the route solves a different problem.
    NotCarried,
}

/// How much of a row is established.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Evidence {
    /// Geometry computed exactly on this curve; only the solver cost is a formula.
    ExactInvariant,
    /// The destination's existence is established by a construction family
    /// but not exercised; the cost is a formula.
    Construction,
    /// The destination's existence is not established; the row prices the
    /// most favourable case the literature allows.
    Proposed,
    /// Counting and class-membership heuristics enter the price.
    Heuristic,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Destination {
    /// `Jac(C)` or `E(F_{p^k})`.
    pub object: String,
    /// Decimal genus.
    pub genus: String,
    pub log2_genus: f64,
    /// `log2` of the field the destination is defined over.
    pub field_bits: f64,
    /// `log2 #Jac`, taken as `genus * field_bits`.
    pub log2_order: f64,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct RouteCost {
    /// Finding the route (an isogeny walk); absent when none is needed.
    pub log2_search: Option<f64>,
    /// Evaluating the transfer map once; absent when the route stays on `E`.
    pub log2_transfer: Option<f64>,
    pub destination: DestinationCost,
    /// `log2(2^search + 2^transfer + 2^destination)`.
    pub log2_total: f64,
    /// `reference - total`: positive means the formulas favour the route.
    pub ratio_log2: f64,
    /// `0.5 log2 r - (leading term of the destination solver)`: the ratio with
    /// every constant stripped, so exponent and constant effects can be told apart.
    pub exponent_ratio_log2: f64,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct TransferRoute {
    pub kind: String,
    pub label: String,
    pub evidence: Evidence,
    /// Exact or estimated structural data, by name.
    pub invariants: BTreeMap<String, Value>,
    pub destination: Destination,
    pub transport: Transport,
    pub cost: RouteCost,
    pub class: RouteClass,
    pub notes: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct CurveTransfers {
    pub slug: String,
    pub icv1: String,
    pub standard_names: Vec<String>,
    pub family: String,
    pub field: FieldInfo,
    pub trace: String,
    pub subgroup: SubgroupInfo,
    /// Pollard rho on the subgroup of `E`, in the model's unit.
    pub reference_log2: f64,
    /// Best class over the routes.
    pub verdict: RouteClass,
    /// Index into `routes` of the cheapest carried route.
    pub best_route: Option<usize>,
    pub routes: Vec<TransferRoute>,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Summary {
    pub curves: usize,
    pub routes: usize,
    pub by_class: BTreeMap<String, usize>,
    pub by_route_kind: BTreeMap<String, usize>,
    /// Slugs whose verdict is `formula_advantage` or `formula_marginal`, with
    /// the route that gives it.
    pub formula_advantage: Vec<(String, String)>,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct TransferFile {
    pub schema: String,
    pub generated_by: String,
    pub what_this_is: String,
    pub registry_sha256: String,
    pub factor_budget: u64,
    pub cost_model: CostModel,
    pub summary: Summary,
    pub curves: Vec<CurveTransfers>,
}

// ── The scan ──────────────────────────────────────────────────────────

fn subgroup_info(c: &RegistryCurve, budget: u64) -> SubgroupInfo {
    if let Some(r) = &c.subgroup_order {
        return SubgroupInfo {
            order: r.to_string(),
            bits: round_to(log2_biguint(r), 3),
            status: "registry_representation".into(),
        };
    }
    let f = factor(&c.order, budget);
    let largest_prime = f.primes.iter().map(|(p, _)| p.clone()).max();
    let largest_composite = f.composites.iter().map(|(c, _)| c.clone()).max();
    match (largest_prime, largest_composite) {
        (Some(p), Some(comp)) if comp > p => SubgroupInfo {
            order: comp.to_string(),
            bits: round_to(log2_biguint(&comp), 3),
            status: "largest_unfactored_composite_bound".into(),
        },
        (Some(p), _) => SubgroupInfo {
            order: p.to_string(),
            bits: round_to(log2_biguint(&p), 3),
            status: "largest_prime_of_order".into(),
        },
        (None, Some(comp)) => SubgroupInfo {
            order: comp.to_string(),
            bits: round_to(log2_biguint(&comp), 3),
            status: "largest_unfactored_composite_bound".into(),
        },
        (None, None) => SubgroupInfo {
            order: c.order.to_string(),
            bits: round_to(log2_biguint(&c.order), 3),
            status: "largest_prime_of_order".into(),
        },
    }
}

fn field_info(f: &Field) -> FieldInfo {
    match f {
        Field::Binary { n, .. } => FieldInfo {
            kind: "binary".into(),
            degree: *n,
            log2_size: f64::from(*n),
            log2_base: f64::from(*n),
        },
        Field::Prime { p } => {
            let b = round_to(log2_biguint(p), 3);
            FieldInfo {
                kind: "prime".into(),
                degree: 1,
                log2_size: b,
                log2_base: b,
            }
        }
        Field::Extension { p, k } => {
            let b = log2_biguint(p);
            FieldInfo {
                kind: "extension".into(),
                degree: *k,
                log2_size: round_to(b * f64::from(*k), 3),
                log2_base: round_to(b, 3),
            }
        }
    }
}

struct RouteBuilder<'a> {
    model: &'a CostModel,
    subgroup_bits: f64,
    reference_log2: f64,
    source_field_bits: f64,
}

impl RouteBuilder<'_> {
    fn jacobian_route(
        &self,
        kind: &str,
        label: String,
        evidence: Evidence,
        invariants: BTreeMap<String, Value>,
        genus: &BigUint,
        field_bits: f64,
        transport: Transport,
        log2_search: f64,
        notes: Vec<String>,
    ) -> TransferRoute {
        let log2_genus = log2_biguint(genus).max(0.0);
        let log2_order = log2_genus.exp2() * field_bits;
        let destination_cost =
            self.model
                .jacobian_destination(self.subgroup_bits, log2_genus, field_bits);
        // One evaluation of the transfer map: at least `g` operations over the
        // source field (the GHS conorm–norm map writes a genus-`g` divisor).
        let log2_transfer = log2_genus + self.model.log2_elliptic_op(self.source_field_bits);
        self.finish(
            kind,
            label,
            evidence,
            invariants,
            Destination {
                object: "Jac(C)".into(),
                genus: genus.to_string(),
                log2_genus: round_to(log2_genus, 3),
                field_bits: round_to(field_bits, 3),
                log2_order: round_to(log2_order, 3),
            },
            transport,
            log2_search,
            log2_transfer,
            destination_cost,
            notes,
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn finish(
        &self,
        kind: &str,
        label: String,
        evidence: Evidence,
        invariants: BTreeMap<String, Value>,
        destination: Destination,
        transport: Transport,
        log2_search: f64,
        log2_transfer: f64,
        destination_cost: DestinationCost,
        notes: Vec<String>,
    ) -> TransferRoute {
        let log2_total =
            binary::log2_total(&[log2_search, log2_transfer, destination_cost.log2_cost]);
        let ratio_log2 = self.reference_log2 - log2_total;
        let exponent_ratio_log2 = 0.5 * self.subgroup_bits - destination_cost.log2_leading;
        let carried = matches!(
            transport,
            Transport::CarriedIfCoprimeToDegree | Transport::SizeAdmits | Transport::SameGroup
        );
        let class = if !carried {
            RouteClass::NotCarried
        } else if ratio_log2 >= self.model.advantage_margin_bits {
            RouteClass::FormulaAdvantage
        } else if ratio_log2 > 0.0 {
            RouteClass::FormulaMarginal
        } else {
            RouteClass::Boundary
        };
        let destination_cost = DestinationCost {
            solver: destination_cost.solver,
            log2_cost: round_to(destination_cost.log2_cost, 3),
            log2_leading: round_to(destination_cost.log2_leading, 3),
            considered: destination_cost
                .considered
                .iter()
                .map(|(s, c)| (*s, round_to(*c, 3)))
                .collect(),
            enge_gaudry_hypothesis_holds: destination_cost.enge_gaudry_hypothesis_holds,
        };
        TransferRoute {
            kind: kind.into(),
            label,
            evidence,
            invariants,
            destination,
            transport,
            cost: RouteCost {
                log2_search: log2_search.is_finite().then(|| round_to(log2_search, 3)),
                log2_transfer: log2_transfer
                    .is_finite()
                    .then(|| round_to(log2_transfer, 3)),
                destination: destination_cost,
                log2_total: round_to(log2_total, 3),
                ratio_log2: round_to(ratio_log2, 3),
                exponent_ratio_log2: round_to(exponent_ratio_log2, 3),
            },
            class,
            notes,
        }
    }

    fn transport_by_size(&self, log2_genus: f64, field_bits: f64) -> Transport {
        if log2_genus.exp2() * field_bits + 1.0 >= self.subgroup_bits {
            Transport::SizeAdmits
        } else {
            Transport::TooSmall
        }
    }
}

fn inv<K: Into<String>, V: Into<Value>>(pairs: Vec<(K, V)>) -> BTreeMap<String, Value> {
    pairs
        .into_iter()
        .map(|(k, v)| (k.into(), v.into()))
        .collect()
}

fn binary_routes(
    rb: &RouteBuilder,
    c: &RegistryCurve,
    n_total: u32,
    irr: &IrreduciblePoly,
    a: &F2mElement,
    b: &F2mElement,
) -> Vec<TransferRoute> {
    let mut routes = Vec::new();
    let disc = &c.trace * &c.trace - BigInt::from(BigUint::from(1u32) << n_total) * 4;
    let log2_abs_disc = log2_abs(&disc);
    for audit in binary::ghs_rows(n_total, irr, a, b) {
        let l = audit.l;
        let magic = binary::ghs_magic(n_total, l, irr, a, b);
        let field_bits = f64::from(l);
        let m = magic.magic_b;
        let genus = crate::cryptanalysis::ec_trapdoor::ghs_genus_for_type(m, magic.type_i);
        let row = DescentRow {
            n: audit.n,
            l,
            magic_m: m,
            genus,
            type_i: magic.type_i,
            descends: magic.descent_exists,
        };
        let log2_genus = log2_biguint(&row.genus).max(0.0);
        let transport = if !magic.descent_exists {
            Transport::DescentObstructed
        } else if row.magic_m <= 1 {
            Transport::Degenerate
        } else {
            rb.transport_by_size(log2_genus, field_bits)
        };
        let mut notes = vec![
            "GHS Weil descent: magic number dim Span{(1, σ^i(√b))} and genus as in research/cover_route_prime_binary_20261008/ghs_magic.rs (Hess); the cover C/GF(2^l) is not constructed here".into(),
        ];
        if !magic.descent_exists {
            notes.push(format!(
                "MMT Lemma 6 condition (8) fails: n = {} is even, Tr(a) = 1 and Tr_(K/k)(b) = 0, so the Artin–Schreier compositum has no σ-lift of order n and there is no descent to GF(2^{l}); the magic number and genus describe the cover over K only",
                row.n
            ));
        } else if row.magic_m <= 1 {
            notes.push("sqrt(b) lies in the subfield: E is defined over GF(2^l) and the descent is the trace map onto E(GF(2^l)), which cannot carry the subgroup".into());
        }
        if audit.magic_m != magic.magic_b {
            notes.push(format!(
                "ec_trapdoor::audit_curve reports magic number {} here, against {} from the span of (1, σ^i(√b))",
                audit.magic_m, magic.magic_b
            ));
        }
        routes.push(rb.jacobian_route(
            "ghs_weil_descent",
            format!("GHS descent to Jac(C)/GF(2^{l}), N = {} * {l}", row.n),
            Evidence::ExactInvariant,
            inv(vec![
                ("relative_degree", Value::from(row.n)),
                ("base_degree", Value::from(l)),
                ("magic_number", Value::from(row.magic_m)),
                ("trace_a", Value::from(magic.trace_a)),
                (
                    "relative_trace_b_zero",
                    Value::from(magic.relative_trace_b_zero),
                ),
                ("mmt_condition_8", Value::from(magic.descent_exists)),
                ("audit_curve_magic_number", Value::from(audit.magic_m)),
                ("type_i", Value::from(row.type_i)),
                ("cover_degree_log2", Value::from(row.magic_m)),
            ]),
            &row.genus,
            field_bits,
            transport,
            f64::NEG_INFINITY,
            notes,
        ));
        // Galbraith–Hess–Smart isogeny extension, priced heuristically.
        // Tr(a) is an isogeny invariant: with Tr(a) = 1 and n even, only
        // targets satisfying MMT condition (8) count.  An obstructed direct
        // descent caps nothing, so every degree up to n is a gain then.
        let needs_unit = magic.trace_a == 1 && row.n.is_multiple_of(2);
        let cap = if magic.descent_exists {
            row.magic_m
        } else {
            row.n + 1
        };
        let estimates = binary::isogeny_extension_estimates(
            rb.model,
            n_total,
            l,
            row.n,
            cap,
            log2_abs_disc,
            needs_unit,
        );
        let mut chosen: Vec<&binary::IsogenyExtensionEstimate> = Vec::new();
        if let Some(first) = estimates.first() {
            chosen.push(first);
        }
        let best_plausible = estimates
            .iter()
            .filter(|e| e.log2_expected_isogenous >= 0.0)
            .min_by(|x, y| {
                let cx = route_cost_preview(rb, x, field_bits);
                let cy = route_cost_preview(rb, y, field_bits);
                cx.partial_cmp(&cy).unwrap_or(std::cmp::Ordering::Equal)
            });
        if let Some(bp) = best_plausible {
            if !chosen
                .iter()
                .any(|e| e.annihilator_degree == bp.annihilator_degree)
            {
                chosen.push(bp);
            }
        }
        for e in chosen {
            let genus = binary::generic_genus(e.magic_bound);
            let log2_genus = log2_biguint(&genus).max(0.0);
            let transport = rb.transport_by_size(log2_genus, field_bits);
            let plausible = e.log2_expected_isogenous >= 0.0;
            routes.push(rb.jacobian_route(
                "ghs_isogeny_extension",
                format!(
                    "isogenous curve with magic number <= {} over the same tower, descent to Jac(C)/GF(2^{l})",
                    e.magic_bound
                ),
                Evidence::Heuristic,
                inv(vec![
                    ("relative_degree", Value::from(row.n)),
                    ("base_degree", Value::from(l)),
                    ("direct_magic_number", Value::from(row.magic_m)),
                    ("direct_descent_exists", Value::from(magic.descent_exists)),
                    ("target_needs_mmt_condition_8", Value::from(needs_unit)),
                    ("target_annihilator_degree", Value::from(e.annihilator_degree)),
                    ("target_magic_number_bound", Value::from(e.magic_bound)),
                    ("log2_candidate_curves", Value::from(round_to(e.log2_candidate_curves, 3))),
                    ("log2_isogeny_class_size", Value::from(round_to(0.5 * log2_abs_disc - std::f64::consts::PI.log2(), 3))),
                    ("log2_expected_isogenous_candidates", Value::from(round_to(e.log2_expected_isogenous, 3))),
                    ("isogenous_candidate_expected", Value::from(plausible)),
                ]),
                &genus,
                field_bits,
                transport,
                e.log2_search_cost,
                vec![
                    "heuristic: counts curves whose sqrt(b') has a small Frobenius annihilator and assumes isogeny classes are random of size sqrt(|t^2-4q|)/pi; no isogenous curve is exhibited".into(),
                    if plausible {
                        "at least one such isogenous curve is expected; the search cost prices a random walk in the class until one is hit".into()
                    } else {
                        "fewer than one such isogenous curve is expected in the class; the route is priced for the record".into()
                    },
                ],
            ));
        }
    }
    // Same-field genus-3 cover from COVERS.md (ordinary binary, b != 0).
    if !b.is_zero() {
        routes.push(rb.jacobian_route(
            "same_field_cover",
            format!("same-field genus-3 cover H -> E of degree 3 over GF(2^{n_total}) (ordinary_binary_cubic_pullback)"),
            Evidence::Construction,
            inv(vec![("map_degree", Value::from(3u32)), ("construction", Value::from("docs/curves/COVERS.md ordinary binary"))]),
            &BigUint::from(3u32),
            f64::from(n_total),
            Transport::CarriedIfCoprimeToDegree,
            f64::NEG_INFINITY,
            vec!["the Jacobian over the same field is larger than E: index calculus there is q^(4/3) against rho's q^(1/2)".into()],
        ));
    }
    routes
}

fn route_cost_preview(
    rb: &RouteBuilder,
    e: &binary::IsogenyExtensionEstimate,
    field_bits: f64,
) -> f64 {
    let genus = binary::generic_genus(e.magic_bound);
    let log2_genus = log2_biguint(&genus).max(0.0);
    let dest = rb
        .model
        .jacobian_destination(rb.subgroup_bits, log2_genus, field_bits);
    binary::log2_total(&[e.log2_search_cost, dest.log2_cost])
}

fn prime_routes(rb: &RouteBuilder, p: &BigUint) -> Vec<TransferRoute> {
    let p_bits = log2_biguint(p);
    let mut routes = Vec::new();
    if p > &BigUint::from(3u32) {
        routes.push(rb.jacobian_route(
            "same_field_cover",
            "same-field genus-2 cover H -> E of degree 2 over GF(p) (prime_quadratic_pullback_v1)".into(),
            Evidence::Construction,
            inv(vec![("map_degree", Value::from(2u32)), ("construction", Value::from("docs/curves/COVERS.md prime characteristic > 3"))]),
            &BigUint::from(2u32),
            p_bits,
            Transport::CarriedIfCoprimeToDegree,
            f64::NEG_INFINITY,
            vec!["the Jacobian over the same field is larger than E: its best solver is rho or q^(2-2/g) index calculus, both at or above rho on E".into()],
        ));
    }
    for k in [2u32, 3] {
        routes.push(rb.jacobian_route(
            "base_change_descent",
            format!("base change to GF(p^{k}) then descent to a genus-{k} cover over GF(p)"),
            Evidence::Proposed,
            inv(vec![("extension_degree", Value::from(k)), ("genus_lower_bound", Value::from(k))]),
            &BigUint::from(k),
            p_bits,
            Transport::SameGroup,
            f64::NEG_INFINITY,
            vec![
                "GF(p) has no proper subfield; any descent must first base-change, and a cover over GF(p) of the Weil restriction has genus >= k (existence for this curve not established)".into(),
                "priced at the most favourable genus the literature allows, g = k, so the row is a lower bound on the route".into(),
            ],
        ));
    }
    routes
}

fn extension_routes(
    rb: &RouteBuilder,
    c: &RegistryCurve,
    p: &BigUint,
    k: u32,
) -> Vec<TransferRoute> {
    let p_bits = log2_biguint(p);
    let two_torsion = (&c.order % 2u32).is_zero();
    let mut routes = Vec::new();
    // Gaudry–Diem decomposition on E(F_{p^k}) with a factor base from F_p.
    let dest_log2 = rb.model.log2_extension_ic(p_bits, k);
    let considered = vec![(DestinationSolver::ExtensionIndexCalculus, dest_log2)];
    routes.push(rb.finish(
        "extension_index_calculus",
        format!("Gaudry–Diem decomposition index calculus on E(GF(p^{k})) with factor base from GF(p)"),
        Evidence::Construction,
        inv(vec![
            ("extension_degree", Value::from(k)),
            ("relations_exponent", Value::from(round_to(2.0 - 2.0 / f64::from(k), 3))),
            ("decomposition_bezout_log2", Value::from(k * (k - 1))),
            (
                "decomposition_trials_log2",
                Value::from(round_to(rb.model.log2_extension_trials(p_bits, k), 3)),
            ),
            (
                "decomposition_solve_log2_fp_mults",
                Value::from(round_to(rb.model.log2_extension_solve_mults(k), 3)),
            ),
            (
                "decomposition_solve_basis",
                Value::from(
                    if rb.model.extension_measured_solve_mults.iter().any(|&(kk, _)| kk == k) {
                        "measured"
                    } else {
                        "degree_cubed_floor"
                    },
                ),
            ),
        ]),
        Destination {
            object: format!("E(GF(p^{k}))"),
            genus: "1".into(),
            log2_genus: 0.0,
            field_bits: round_to(p_bits * f64::from(k), 3),
            log2_order: round_to(p_bits * f64::from(k), 3),
        },
        Transport::SameGroup,
        f64::NEG_INFINITY,
        f64::NEG_INFINITY,
        DestinationCost {
            solver: DestinationSolver::ExtensionIndexCalculus,
            log2_cost: dest_log2,
            log2_leading: rb.model.log2_extension_trials(p_bits, k)
                + rb.model.log2_extension_solve_mults(k),
            considered,
            enge_gaudry_hypothesis_holds: false,
        },
        vec![
            "no transfer: the method works on E itself with a subfield factor base; each of the k! * p^(2-2/k) decomposition attempts is priced at the measured C_k F_p multiplications (k = 3, 4) or, elsewhere, at D^3 with D = 2^(k(k-1)) the Bézout bound of the Semaev system, a floor on the Gröbner/FGLM solve".into(),
            "until 2026-10-16 the solve was priced at D elliptic operations with no k! trial factor; the measured C_3 = 0.876e6 and C_4 = 1.227e12 lie above D^3, so rows at other k remain lower bounds and a formula advantage here is a lead, not a measurement".into(),
        ],
    ));
    // Descent to a cover over GF(p).  The cheapest genus the literature
    // allows is k for the Weil restriction in general, but no GHS cover has
    // genus below `ghs_genus_floor(k)`; where that is above k the row is priced
    // at the floor, and keeps what it said at genus k for the record.
    let floor = ghs_genus_floor(k).filter(|&f| f > k);
    let genus_of = |g: u32| {
        let g = BigUint::from(g);
        let transport = rb.transport_by_size(log2_biguint(&g), p_bits);
        (g, transport)
    };
    let priced_genus = floor.unwrap_or(k);
    let (genus, transport) = genus_of(priced_genus);
    let mut invariants = inv(vec![
        ("extension_degree", Value::from(k)),
        ("genus_lower_bound", Value::from(priced_genus)),
        ("rational_two_torsion_point", Value::from(two_torsion)),
    ]);
    let mut notes = vec![
        "existence of a cover over GF(p) of the priced genus is not established for this curve; odd-characteristic GHS and Diem's genus-3 covers need extra structure (for k = 3, rational 2-torsion is the usual precondition, recorded as an exact invariant)".into(),
    ];
    if let Some(f) = floor {
        // What the row said before 2026-10-15, when it was priced at g = k.
        let (gk, tk) = genus_of(k);
        let at_k = rb.jacobian_route(
            "cover_descent",
            String::new(),
            Evidence::Proposed,
            BTreeMap::new(),
            &gk,
            p_bits,
            tk,
            f64::NEG_INFINITY,
            Vec::new(),
        );
        invariants.insert("genus_basis".into(), Value::from("ghs_genus_floor"));
        invariants.insert(
            "class_at_genus_k".into(),
            Value::from(class_name(at_k.class)),
        );
        invariants.insert(
            "ratio_log2_at_genus_k".into(),
            Value::from(at_k.cost.ratio_log2),
        );
        let attained = if k == 6 {
            invariants.insert(
                "conditional_on".into(),
                Value::from("a genus-9 cover of this curve being exhibited"),
            );
            "Joux–Vitse (Eurocrypt 2012, App. C) shapes 12/13 give 9 as the minimum genus, not the existence of a genus-9 cover for this curve, so the row is conditional on such a cover being exhibited"
        } else {
            "whether this curve attains that genus is not verified"
        };
        notes.push(format!(
            "priced at g = {f}, the least genus of any GHS cover of E/GF(p^{k}) when F_p(j(E)) = GF(p^{k}) (research/odd_char_descent_genus3_20261014/); {attained}.  Until 2026-10-15 the row was priced at g = {k}, which no GHS cover has, and was {} ({:+.1} bits against rho).  A curve whose j lies in a proper subfield, or a non-GHS cover, could have a smaller genus, so the row is a lower bound on the GHS route only",
            class_name(at_k.class),
            at_k.cost.ratio_log2
        ));
    } else {
        invariants.insert("genus_basis".into(), Value::from("weil_restriction"));
        notes.push(
            "priced at the most favourable genus, g = k, so the row is a lower bound on the route"
                .into(),
        );
    }
    routes.push(rb.jacobian_route(
        "cover_descent",
        format!("descent to a genus-{priced_genus} cover C/GF(p) of E/GF(p^{k})"),
        Evidence::Proposed,
        invariants,
        &genus,
        p_bits,
        transport,
        f64::NEG_INFINITY,
        notes,
    ));
    routes
}

/// Screen one registry curve.
pub fn screen(c: &RegistryCurve, model: &CostModel, budget: u64) -> CurveTransfers {
    let field = field_info(&c.field);
    let subgroup = subgroup_info(c, budget);
    let reference_log2 = model.log2_rho_elliptic(subgroup.bits, field.log2_size);
    let rb = RouteBuilder {
        model,
        subgroup_bits: subgroup.bits,
        reference_log2,
        source_field_bits: field.log2_size,
    };
    let routes = match &c.field {
        Field::Binary { n, irr, a, b } => binary_routes(&rb, c, *n, irr, a, b),
        Field::Prime { p } => prime_routes(&rb, p),
        Field::Extension { p, k } => extension_routes(&rb, c, p, *k),
    };
    let best_route = routes
        .iter()
        .enumerate()
        .filter(|(_, r)| r.class != RouteClass::NotCarried)
        .min_by(|(_, x), (_, y)| {
            x.cost
                .log2_total
                .partial_cmp(&y.cost.log2_total)
                .unwrap_or(std::cmp::Ordering::Equal)
        })
        .map(|(i, _)| i);
    let verdict = routes
        .iter()
        .map(|r| r.class)
        .min()
        .unwrap_or(RouteClass::NotCarried);
    CurveTransfers {
        slug: c.slug.clone(),
        icv1: c.icv1.clone(),
        standard_names: c.standard_names.clone(),
        family: c.family.clone(),
        field,
        trace: c.trace.to_string(),
        subgroup,
        reference_log2: round_to(reference_log2, 3),
        verdict,
        best_route,
        routes,
    }
}

impl TransferFile {
    pub fn build(registry_text: &str, model: CostModel, budget: u64) -> Result<Self, String> {
        use rayon::prelude::*;
        let curves = read_registry(registry_text)?;
        let records: Vec<CurveTransfers> = curves
            .par_iter()
            .map(|c| screen(c, &model, budget))
            .collect();
        let digest = crate::hash::sha256::sha256(registry_text.as_bytes());
        let mut by_class = BTreeMap::new();
        let mut by_route_kind = BTreeMap::new();
        let mut formula_advantage = Vec::new();
        for r in &records {
            *by_class.entry(class_name(r.verdict)).or_insert(0) += 1;
            for route in &r.routes {
                *by_route_kind.entry(route.kind.clone()).or_insert(0) += 1;
            }
            if matches!(
                r.verdict,
                RouteClass::FormulaAdvantage | RouteClass::FormulaMarginal
            ) {
                let best = r
                    .best_route
                    .map(|i| r.routes[i].label.clone())
                    .unwrap_or_default();
                formula_advantage.push((r.slug.clone(), best));
            }
        }
        Ok(TransferFile {
            schema: SCHEMA.into(),
            generated_by: "cargo run --release --bin jacobian_transfers -- build".into(),
            what_this_is: "Every known route from each registered curve's discrete logarithm into a \
                           Jacobian, priced by one frozen formula-level cost model against Pollard rho \
                           on the same subgroup; see docs/curves/JACOBIAN_TRANSFERS.md. Rows are \
                           formulas and leads, never measurements or security claims."
                .into(),
            registry_sha256: digest.iter().map(|b| format!("{b:02x}")).collect(),
            factor_budget: budget,
            cost_model: model,
            summary: Summary {
                curves: records.len(),
                routes: records.iter().map(|r| r.routes.len()).sum(),
                by_class,
                by_route_kind,
                formula_advantage,
            },
            curves: records,
        })
    }

    /// Pretty JSON with a trailing newline, as committed.
    pub fn to_json(&self) -> String {
        let mut s = serde_json::to_string_pretty(self).expect("serialisable");
        s.push('\n');
        s
    }

    pub fn find(&self, name: &str) -> Option<&CurveTransfers> {
        let slug = crate::cryptanalysis::curve_id::resolve(name).unwrap_or(name);
        self.curves
            .iter()
            .find(|c| c.slug == slug || c.standard_names.iter().any(|s| s == name))
    }
}

pub fn class_name(c: RouteClass) -> String {
    serde_json::to_value(c)
        .ok()
        .and_then(|v| v.as_str().map(str::to_string))
        .unwrap_or_default()
}

#[cfg(test)]
mod tests {
    use super::*;

    const REGISTRY: &str = include_str!("../../../docs/curves/registry.json");

    fn registry() -> Vec<RegistryCurve> {
        read_registry(REGISTRY).unwrap()
    }

    fn by_name(name: &str) -> RegistryCurve {
        let slug = crate::cryptanalysis::curve_id::resolve(name).unwrap_or(name);
        registry()
            .into_iter()
            .find(|c| c.slug == slug || c.standard_names.iter().any(|s| s == name))
            .unwrap_or_else(|| panic!("{name} not registered"))
    }

    #[test]
    fn every_registry_entry_parses() {
        let curves = registry();
        assert!(curves.len() >= 300);
        assert!(curves
            .iter()
            .any(|c| matches!(c.field, Field::Extension { .. })));
        assert!(curves
            .iter()
            .any(|c| matches!(c.field, Field::Binary { .. })));
        assert!(curves
            .iter()
            .any(|c| matches!(c.field, Field::Prime { .. })));
    }

    #[test]
    fn oakley_group_three_reproduces_the_cover_route_census() {
        // research/cover_route_prime_binary_20261008: m = 5 over GF(2^31),
        // m = 26 over GF(2^5), m = 126 over GF(2).
        let c = by_name("Oakley Group 3");
        let r = screen(&c, &CostModel::default(), DEFAULT_FACTOR_BUDGET);
        let magic = |l: u32| {
            r.routes
                .iter()
                .find(|x| x.kind == "ghs_weil_descent" && x.invariants["base_degree"] == l)
                .unwrap()
                .invariants["magic_number"]
                .as_u64()
                .unwrap()
        };
        assert_eq!(magic(31), 5);
        assert_eq!(magic(5), 26);
        assert_eq!(magic(1), 126);
        let g16 = r
            .routes
            .iter()
            .find(|x| x.kind == "ghs_weil_descent" && x.invariants["base_degree"] == 31)
            .unwrap();
        // Tr_{K/k}(b) != 0, so (x - 1) | Ord_b: type II, genus 2^4 = 16
        // (MMT Theorem 5(i)).  Before 2026-10-13 the orbit-length type rule
        // reported type I, genus 15.
        assert_eq!(g16.destination.genus, "16");
        assert_eq!(g16.transport, Transport::SizeAdmits);
        // Genus 16 over GF(2^31): relation collection 16! * 2^31 = 2^75.25
        // against rho's 2^76 leaves an exponent ratio near 0.75 bits, which the
        // genus constants (10 g^2 per Jacobian operation) consume.
        assert!(g16.cost.ratio_log2 < cost::CostModel::default().advantage_margin_bits);
        assert_ne!(g16.class, RouteClass::FormulaAdvantage);
        assert_ne!(r.verdict, RouteClass::FormulaAdvantage);
    }

    #[test]
    fn trace_of_a_decides_whether_the_descent_exists() {
        // c2pnb304w1, c2pnb272w1 and c2pnb176w1 have Tr(a) = 1 with n even
        // over GF(4), but Tr_(K/k)(b) != 0, so MMT condition (8) holds and the
        // magic number 8 is exact: one row per tower, genus 2^7 = 128.
        // Before 2026-10-13 the screen bracketed it as 8 or 9.
        for (name, l, n, class) in [
            ("c2pnb304w1", 2, 152, RouteClass::NotCarried),
            ("c2pnb272w1", 2, 136, RouteClass::FormulaAdvantage),
            ("c2pnb176w1", 2, 88, RouteClass::FormulaAdvantage),
        ] {
            let r = screen(&by_name(name), &CostModel::default(), DEFAULT_FACTOR_BUDGET);
            let rows: Vec<_> = r
                .routes
                .iter()
                .filter(|x| x.kind == "ghs_weil_descent" && x.invariants["base_degree"] == l)
                .collect();
            assert_eq!(rows.len(), 1, "{name}");
            let row = rows[0];
            assert_eq!(row.invariants["relative_degree"], n);
            assert_eq!(row.invariants["trace_a"], 1);
            assert_eq!(row.invariants["mmt_condition_8"], true);
            assert_eq!(row.invariants["magic_number"], 8);
            assert_eq!(row.evidence, Evidence::ExactInvariant);
            assert_eq!(row.destination.genus, "128");
            assert_eq!(row.class, class, "{name}");
            // Every isogenous target must satisfy (8) as well, which forces
            // (x - 1)^8 into its annihilator: nothing below m = 8 remains.
            assert!(
                !r.routes
                    .iter()
                    .any(|x| x.kind == "ghs_isogeny_extension" && x.invariants["base_degree"] == l),
                "{name}"
            );
        }
        // c2pnb304w1's 288-bit subgroup does not fit in a 256-bit Jacobian;
        // its best route is the n = 4, genus-8 descent over GF(2^76).
        // The earlier 10*g^2 Jacobian price put that route 2.001 bits below
        // rho. The measured Cantor price (2620.9, rather than 640, at g=8)
        // moves it 0.033 bits above rho without changing its exact geometry.
        let model = CostModel::default();
        let r = screen(&by_name("c2pnb304w1"), &model, DEFAULT_FACTOR_BUDGET);
        let best = &r.routes[r.best_route.unwrap()];
        assert_eq!(r.verdict, RouteClass::Boundary);
        assert_eq!(best.invariants["base_degree"], 76);
        assert_eq!(best.destination.genus, "8");
        assert!(best.cost.ratio_log2 < 0.0);
        assert!(best.cost.exponent_ratio_log2 > 0.0);

        // Preserve the historical model's conclusion as an explicit control:
        // do not recover it by weakening the measured production price.
        let mut legacy = model.clone();
        legacy.jacobian_group_op_mults_measured = model
            .jacobian_group_op_mults_measured
            .iter()
            .map(|&(g, _)| (g, 10.0 * f64::from(g).powi(2)))
            .collect();
        legacy.jacobian_group_op_extrapolation_exponent = 2.0;
        let old = screen(&by_name("c2pnb304w1"), &legacy, DEFAULT_FACTOR_BUDGET);
        let old_best = &old.routes[old.best_route.unwrap()];
        assert_eq!(old.verdict, RouteClass::FormulaMarginal);
        assert_eq!(old_best.invariants, best.invariants);
        assert_eq!(old_best.destination, best.destination);
        let measured_price_delta = (2620.9_f64 / 640.0).log2();
        assert!(
            (old_best.cost.ratio_log2 - best.cost.ratio_log2 - measured_price_delta).abs() < 0.003
        );
        // A registry curve where (8) fails: b in F_2, Tr(a) = 1, N = 18.
        let r = screen(
            &by_name("icv1-f2m18-t999-40751283"),
            &CostModel::default(),
            DEFAULT_FACTOR_BUDGET,
        );
        let obstructed: Vec<u64> = r
            .routes
            .iter()
            .filter(|x| x.transport == Transport::DescentObstructed)
            .map(|x| x.invariants["base_degree"].as_u64().unwrap())
            .collect();
        assert_eq!(obstructed, [9, 3, 1]);
        assert!(
            r.routes
                .iter()
                .filter(|x| x.transport == Transport::DescentObstructed)
                .all(|x| x.class == RouteClass::NotCarried
                    && x.invariants["mmt_condition_8"] == false)
        );
        // c2pnb368w1 has Tr(a) = 0: one exact row per tower.
        let r = screen(
            &by_name("c2pnb368w1"),
            &CostModel::default(),
            DEFAULT_FACTOR_BUDGET,
        );
        let g7 = r
            .routes
            .iter()
            .filter(|x| x.kind == "ghs_weil_descent" && x.invariants["base_degree"] == 92)
            .collect::<Vec<_>>();
        assert_eq!(g7.len(), 1);
        assert_eq!(g7[0].evidence, Evidence::ExactInvariant);
        // n = 4: x^4 - 1 = (x - 1)^4, so every curve is type II and m = 4
        // gives genus 8 (7 under the pre-2026-10-13 orbit-length rule).
        assert_eq!(g7[0].destination.genus, "8");
    }

    #[test]
    fn koblitz_curves_degenerate_and_random_b_sits_at_the_maximum() {
        let k = screen(
            &by_name("sect163k1"),
            &CostModel::default(),
            DEFAULT_FACTOR_BUDGET,
        );
        let ghs: Vec<_> = k
            .routes
            .iter()
            .filter(|x| x.kind == "ghs_weil_descent")
            .collect();
        assert_eq!(ghs.len(), 1);
        assert_eq!(ghs[0].invariants["magic_number"], 1);
        assert_eq!(ghs[0].transport, Transport::Degenerate);
        assert_eq!(k.verdict, RouteClass::Boundary);
        let b = screen(
            &by_name("sect113r1"),
            &CostModel::default(),
            DEFAULT_FACTOR_BUDGET,
        );
        let ghs = b
            .routes
            .iter()
            .find(|x| x.kind == "ghs_weil_descent")
            .unwrap();
        assert_eq!(ghs.invariants["magic_number"], 113);
        let two_112 = BigUint::from(1u32) << 112u32;
        assert!(
            ghs.destination.genus == two_112.to_string()
                || ghs.destination.genus == (&two_112 - BigUint::from(1u32)).to_string()
        );
        assert_eq!(b.verdict, RouteClass::Boundary);
    }

    #[test]
    fn prime_field_curves_are_boundary_rows_only() {
        for name in ["P-256", "secp256k1", "Curve25519"] {
            let r = screen(&by_name(name), &CostModel::default(), DEFAULT_FACTOR_BUDGET);
            assert_eq!(r.verdict, RouteClass::Boundary, "{name}");
            assert!(r.routes.iter().all(|x| x.cost.ratio_log2 < 0.0), "{name}");
            assert!(r.routes.iter().any(|x| x.kind == "same_field_cover"));
            assert_eq!(
                r.routes
                    .iter()
                    .filter(|x| x.kind == "base_change_descent")
                    .count(),
                2
            );
        }
    }

    #[test]
    fn extension_curves_get_both_extension_routes() {
        let c = registry()
            .into_iter()
            .find(|c| matches!(c.field, Field::Extension { .. }))
            .unwrap();
        let r = screen(&c, &CostModel::default(), DEFAULT_FACTOR_BUDGET);
        assert_eq!(r.field.kind, "extension");
        assert!(r
            .routes
            .iter()
            .any(|x| x.kind == "extension_index_calculus"));
        assert!(r.routes.iter().any(|x| x.kind == "cover_descent"));
    }

    #[test]
    fn ghs_genus_floor_matches_the_odd_characteristic_study() {
        // research/odd_char_descent_genus3_20261014/results/run-20261014T1800Z/
        // min_genus.csv, column min_genus_period_n, n = 1..=14.  Joux–Vitse
        // App. C gives 9 at n = 6.  Genus n is attained at n = 1, 2, 3, 5, 7
        // only; at n = 4 the least genus is 5 and at n = 9 it is 81.
        let csv = [1, 2, 3, 5, 5, 9, 7, 33, 81, 49, 1793, 25, 9217, 41];
        for (i, g) in csv.into_iter().enumerate() {
            assert_eq!(ghs_genus_floor(i as u32 + 1), Some(g), "n = {}", i + 1);
        }
        assert_eq!(ghs_genus_floor(6), Some(9));
        assert_eq!(ghs_genus_floor(10), Some(49));
        assert_eq!(ghs_genus_floor(14), Some(41));
        assert_eq!(ghs_genus_floor(0), None);
        assert_eq!(ghs_genus_floor(15), None);
    }

    #[test]
    fn cover_descent_is_priced_at_the_ghs_floor_where_it_exceeds_k() {
        let file =
            TransferFile::build(REGISTRY, CostModel::default(), DEFAULT_FACTOR_BUDGET).unwrap();
        let (mut raised, mut unchanged) = (0, 0);
        for c in file.curves.iter().filter(|c| c.field.kind == "extension") {
            let k = c.field.degree;
            let r = c.routes.iter().find(|r| r.kind == "cover_descent").unwrap();
            match ghs_genus_floor(k).filter(|&f| f > k) {
                Some(f) => {
                    assert_eq!(r.destination.genus, f.to_string(), "{}", c.slug);
                    assert_eq!(r.invariants["genus_lower_bound"], f);
                    assert_eq!(r.invariants["genus_basis"], "ghs_genus_floor");
                    assert_eq!(
                        r.label,
                        format!("descent to a genus-{f} cover C/GF(p) of E/GF(p^{k})")
                    );
                    // Pricing at a larger genus never improves the class.
                    let before: RouteClass =
                        serde_json::from_value(r.invariants["class_at_genus_k"].clone()).unwrap();
                    assert!(before <= r.class, "{} k = {k}", c.slug);
                    assert!(
                        r.invariants["ratio_log2_at_genus_k"].as_f64().unwrap()
                            >= r.cost.ratio_log2,
                        "{}",
                        c.slug
                    );
                    assert!(r.notes.last().unwrap().contains("Until 2026-10-15"));
                    assert_eq!(
                        r.invariants.contains_key("conditional_on"),
                        k == 6,
                        "{} k = {k}",
                        c.slug
                    );
                    raised += 1;
                }
                None => {
                    assert_eq!(r.destination.genus, k.to_string(), "{}", c.slug);
                    assert_eq!(r.invariants["genus_basis"], "weil_restriction");
                    assert!(!r.invariants.contains_key("class_at_genus_k"));
                    unchanged += 1;
                }
            }
            // The verdict is still the best class over the routes.
            assert_eq!(c.verdict, c.routes.iter().map(|r| r.class).min().unwrap());
        }
        assert!(raised > 0 && unchanged > 0);
    }

    #[test]
    fn unrecorded_subgroups_fall_back_to_the_largest_prime() {
        let c = registry()
            .into_iter()
            .find(|c| c.subgroup_order.is_none())
            .unwrap();
        let r = screen(&c, &CostModel::default(), DEFAULT_FACTOR_BUDGET);
        assert_ne!(r.subgroup.status, "registry_representation");
        assert!(r.subgroup.bits > 0.0);
    }

    #[test]
    fn the_whole_registry_builds_and_round_trips() {
        let file =
            TransferFile::build(REGISTRY, CostModel::default(), DEFAULT_FACTOR_BUDGET).unwrap();
        assert_eq!(file.curves.len(), registry().len());
        let json = file.to_json();
        assert!(
            !json.contains("null,") || !json.contains("\"log2_cost\": null"),
            "non-finite cost"
        );
        let back: TransferFile = serde_json::from_str(&json).unwrap();
        // The file parses back; values agree to 12 significant digits (the
        // JSON parser is not correctly rounded above 2^53, and `check` rebuilds
        // from the registry rather than round-tripping these numbers).
        assert_eq!(back.summary, file.summary);
        assert_eq!(back.curves.len(), file.curves.len());
        for (x, y) in back.curves.iter().zip(&file.curves) {
            assert_eq!(x.slug, y.slug);
            assert_eq!(x.verdict, y.verdict);
            assert_eq!(x.best_route, y.best_route);
            for (rx, ry) in x.routes.iter().zip(&y.routes) {
                let (a, b) = (rx.cost.log2_total, ry.cost.log2_total);
                assert!(
                    (a - b).abs() <= 1e-11 * a.abs().max(1.0),
                    "{} {a} {b}",
                    x.slug
                );
            }
        }
        // Rebuilding is deterministic.
        let again =
            TransferFile::build(REGISTRY, CostModel::default(), DEFAULT_FACTOR_BUDGET).unwrap();
        assert_eq!(again.to_json(), json);
        assert_eq!(file.summary.curves, file.curves.len());
        assert!(file.find("Oakley Group 3").is_some());
    }
}
