#!/bin/bash
# Lever 3 exploration: five filter arms interleaved, three rounds, two rows.
set -u
cd /home/user/crypto
D=/tmp/claude-0/scanp/explore3c; BIN=/tmp/claude-0/scanp/ic-lever3c; ISO=/tmp/claude-0/rulev9/bin/isolated_bench
SUITE=research/ic_tool_program/suite/v1/SUITE.json
declare -A ENVS=([default]="" [huge]="KIC_FILTER_HUGE=1" [b8]="KIC_FILTER=blocked8" [b16]="KIC_FILTER=blocked" [b16huge]="KIC_FILTER=blocked KIC_FILTER_HUGE=1")
for round in 1 2 3; do
  for row in "k0n53 M1-T01" "k0n61 M1-T01"; do
    set -- $row; seed=$(jq -r --arg id "$1-$2" '.rows[]|select(.id==$id)|.rho_seed' $SUITE)
    for arm in default b8 b16; do
      o=$D/$1-$2-$arm-r$round.json; [ -s $o ] && continue
      env ${ENVS[$arm]} RAYON_NUM_THREADS=1 $ISO run --wait --cpus 2 --out $o.iso.jsonl --label l3/$arm -- \
        $BIN price --params research/ic_tool_program/suite/v1/params/S/$1/$2.json --json --out $o --single-target --rho-seed $seed > /dev/null 2>&1 || echo "FAIL $o"
    done
  done
done
echo done
