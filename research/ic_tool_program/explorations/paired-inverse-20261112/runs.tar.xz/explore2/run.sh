#!/bin/bash
# Lever 2 exploration: paired (default) vs KIC_SCAN_PAIRED=0, interleaved, three rounds, three rows.
set -u
cd /home/user/crypto
D=/tmp/claude-0/scanp/explore2; BIN=/tmp/claude-0/scanp/ic-lever2; ISO=/tmp/claude-0/rulev9/bin/isolated_bench
SUITE=research/ic_tool_program/suite/v1/SUITE.json
declare -A ENVS=([paired]="" [off]="KIC_SCAN_PAIRED=0")
for round in 1 2 3; do
  for row in "k0n53 M1-T01" "k1n59 M1-T01" "k0n61 M1-T01"; do
    set -- $row; seed=$(jq -r --arg id "$1-$2" '.rows[]|select(.id==$id)|.rho_seed' $SUITE)
    arms="paired off"; [ $((round % 2)) = 0 ] && arms="off paired"
    for arm in $arms; do
      o=$D/$1-$2-$arm-r$round.json; [ -s $o ] && continue
      env ${ENVS[$arm]} RAYON_NUM_THREADS=1 $ISO run --wait --cpus 2 --out $o.iso.jsonl --label l2/$arm -- \
        $BIN price --params research/ic_tool_program/suite/v1/params/S/$1/$2.json --json --out $o --single-target --rho-seed $seed > /dev/null 2>&1 || echo "FAIL $o"
    done
  done
done
