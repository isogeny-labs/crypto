const fs=require('fs'),c=require('crypto'),[root,label,file]=process.argv.slice(2);
const artifacts=fs.readFileSync(file,'utf8').trim().split('\n').map(s=>JSON.parse(s)).filter(x=>x.reason==='compiler-artifact'&&x.profile.test&&x.executable);
if(!artifacts.length)throw Error('no test executable artifact');
const rows=artifacts.map(x=>{const dst=root+'/qualified/'+label+'-'+x.target.name;fs.copyFileSync(x.executable,dst,fs.constants.COPYFILE_EXCL);fs.chmodSync(dst,0o500);return {path:dst,source_executable:x.executable,sha256:c.createHash('sha256').update(fs.readFileSync(dst)).digest('hex')};});
fs.writeFileSync(root+'/build01/'+label+'-qualifiers.json',JSON.stringify(rows,null,2)+'\n',{flag:'wx'});
