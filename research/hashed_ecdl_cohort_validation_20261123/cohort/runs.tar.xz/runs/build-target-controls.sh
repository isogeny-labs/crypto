#!/usr/bin/env bash
set -euo pipefail
R=/tmp/ecdlp-larger-cohort-20261123
sha256sum -c "$R/TARGET-BUILD-BEFORE.sha256" > "$R/build-target01/source-precheck.log"
/tmp/ecdlp-native-tools-20261123/rust-1.99.1/bin/rustc --edition=2021 -O -D warnings --crate-name target_controls "$R/target-control-source/target-controls.rs" -o "$R/build-target01/target-controls"
/tmp/ecdlp-native-tools-20261123/rust-1.99.1/bin/rustc --edition=2021 -O -D warnings --test --crate-name target_controls "$R/target-control-source/target-controls.rs" -o "$R/build-target01/target-controls-tests"
for NAME in target-controls target-controls-tests; do cp "$R/build-target01/$NAME" "$R/qualified/$NAME"; chmod 500 "$R/qualified/$NAME"; done
sha256sum "$R/qualified/target-controls" "$R/qualified/target-controls-tests" > "$R/build-target01/copied-qualifiers.sha256"
sha256sum -c "$R/TARGET-BUILD-BEFORE.sha256" > "$R/build-target01/source-postcheck.log"
printf 'Copied target-control driver and parser tests built; no execution.\n'
