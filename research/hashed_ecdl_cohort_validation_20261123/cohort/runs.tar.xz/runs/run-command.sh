#!/usr/bin/env bash
# One bounded source-frozen qualification phase.
set -euo pipefail
ROOT=/tmp/ecdlp-larger-cohort-20261123
LABEL=$1
shift
OUT="$ROOT/$LABEL"
mkdir "$OUT"
printf '%q ' "$@" > "$OUT/command.txt"
printf '\n' >> "$OUT/command.txt"
cp "$ROOT/additional-inputs.sha256" "$OUT/additional-inputs.frozen.sha256"
chmod a-w "$OUT/additional-inputs.frozen.sha256"
sha256sum "$ROOT/run-command.sh" "$OUT/additional-inputs.frozen.sha256" > "$OUT/input-before.sha256"
cat "$OUT/additional-inputs.frozen.sha256" >> "$OUT/input-before.sha256"
sha256sum -c "$OUT/input-before.sha256" > "$OUT/input-precheck.log"
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$OUT/started-utc.txt"
read -r INITIAL < /sys/fs/cgroup/memory.current
FREE=$(df --output=avail -B1 /tmp | tail -n 1)
printf "%s\n" "$FREE" > "$OUT/free-disk-start-bytes.txt"
if [ "$FREE" -lt 268435456 ]; then printf "78\n" > "$OUT/exit-code.txt"; printf "disk launch condition\n" > "$OUT/setup-stop.txt"; exit 78; fi
if [ "$INITIAL" -ge 15032385536 ]; then
  printf '75\n' > "$OUT/exit-code.txt"
  printf '1\n' > "$OUT/physical-stop.txt"
  printf '%s\n' "$INITIAL" > "$OUT/peak-cgroup-bytes.txt"
  exit 75
fi
setsid timeout --signal=TERM --kill-after=5 600 flock /tmp/ecdlp-larger-cohort-20261123/worker.lock "$@" > "$OUT/stdout.txt" 2> "$OUT/stderr.txt" &
PID=$!
PEAK=$INITIAL
STOP=0
DISK_STOP=0
MIN_FREE=$FREE
while kill -0 "$PID" 2>/dev/null; do
  read -r USED < /sys/fs/cgroup/memory.current
  if [ "$USED" -gt "$PEAK" ]; then PEAK=$USED; fi
  if [ "$USED" -ge 15032385536 ]; then STOP=1; kill -TERM -- "-$PID" 2>/dev/null || true; break; fi
  FREE=$(df --output=avail -B1 /tmp | tail -n 1)
  if [ "$FREE" -lt "$MIN_FREE" ]; then MIN_FREE=$FREE; fi
  if [ "$FREE" -lt 67108864 ]; then DISK_STOP=1; kill -TERM -- "-$PID" 2>/dev/null || true; break; fi
  sleep 0.25
done
set +e
wait "$PID"
CODE=$?
set -e
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$OUT/finished-utc.txt"
printf '%s\n' "$CODE" > "$OUT/exit-code.txt"
printf '%s\n' "$STOP" > "$OUT/physical-stop.txt"
printf '%s\n' "$DISK_STOP" > "$OUT/disk-stop.txt"
printf '%s\n' "$MIN_FREE" > "$OUT/min-free-disk-bytes.txt"
printf '%s\n' "$PEAK" > "$OUT/peak-cgroup-bytes.txt"
sha256sum -c "$OUT/input-before.sha256" > "$OUT/input-after-check.log"
cat "$OUT/stdout.txt" "$OUT/stderr.txt"
exit "$CODE"
