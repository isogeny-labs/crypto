#!/usr/bin/env bash
set -euo pipefail
R=/tmp/ecdlp-larger-cohort-20261123
sha256sum -c "$R/TARGET-CALL-BEFORE.sha256" > "$R/target-controls01/precall-check.log"
set +e
timeout --foreground --signal=TERM --kill-after=5 120 "$R/qualified/target-controls-tests" --test-threads=1 > "$R/target-controls01/parser.stdout" 2> "$R/target-controls01/parser.stderr"
PARSER_CODE=$?
CENSUS_CODE=-1
if [ "$PARSER_CODE" -eq 0 ]; then
  "$R/qualified/target-controls" "$R/target-controls01/census" "$R/qualified/parent-scale" "$R/qualified/candidate-scale" "$R/qualified/point-check" /tmp/ecdlp-cohort-validation-20261123/inputs/targets.tsv "$R/legacy-validation-scalars.tsv" 4 > "$R/target-controls01/census.stdout" 2> "$R/target-controls01/census.stderr"
  CENSUS_CODE=$?
fi
sha256sum -c "$R/TARGET-CALL-BEFORE.sha256" > "$R/target-controls01/postcall-check.log"
HASH_CODE=$?
set -e
printf '{"parser_exit":%s,"census_exit":%s,"postcheck_exit":%s}\n' "$PARSER_CODE" "$CENSUS_CODE" "$HASH_CODE" > "$R/target-controls01/disposition.json"
if [ "$PARSER_CODE" -ne 0 ]; then exit "$PARSER_CODE"; fi
if [ "$CENSUS_CODE" -ne 0 ]; then exit "$CENSUS_CODE"; fi
exit "$HASH_CODE"
