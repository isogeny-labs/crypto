#!/usr/bin/env bash
set -euo pipefail
R=/tmp/ecdlp-larger-cohort-20261123
sha256sum -c "$R/UNIT-PRECALL.sha256" > "$R/units01/precall-check.log"
for NAME in harness-cohort-panel harness-cohort-point-audit parent-hashed_ecdl_cpu candidate-hashed_ecdl_cpu; do
  timeout --foreground --signal=TERM --kill-after=5 120 "$R/qualified/$NAME" --test-threads=1 > "$R/units01/$NAME.stdout" 2> "$R/units01/$NAME.stderr"
done
sha256sum -c "$R/UNIT-PRECALL.sha256" > "$R/units01/postcall-check.log"
printf 'Copied library/collector/auditor unit controls completed; no expanded-cohort calls.\n'
