#!/usr/bin/env bash
set -euo pipefail
R=/tmp/ecdlp-larger-cohort-20261123
export PATH="/tmp/ecdlp-native-tools-20261123/rust-1.99.1/bin:$PATH"
export CARGO_HOME=/tmp/ecdlp-native-tools-20261123/cargo-home
export CARGO_TARGET_DIR="$R/target"
export CARGO_BUILD_JOBS=1
export CARGO_INCREMENTAL=0
node -e 'const f=require("fs"),m=JSON.parse(f.readFileSync("/tmp/ecdlp-port-mass-20261123/idle-rust-manifest.json","utf8"));process.stdout.write(m.rows.map(x=>"/tmp/"+x.relative_to_tmp).join("\n")+"\n")' > "$R/build01/tool-cache-paths.txt"
while IFS= read -r FILE; do dd if="$FILE" iflag=nocache count=0 status=none; done < "$R/build01/tool-cache-paths.txt"
cc -std=c11 -O2 -Wall -Wextra -Wshadow -Wconversion -Werror "$R/cohort/native/point-check.c" -o "$R/build01/point-check" -lcrypto
cp "$R/build01/point-check" "$R/qualified/point-check"
chmod 500 "$R/qualified/point-check"
cargo test --manifest-path "$R/cohort/native/Cargo.toml" --release --locked --offline --bins --no-run --message-format=json-render-diagnostics > "$R/build01/harness-tests.jsonl" 2> "$R/build01/harness-tests.stderr"
node "$R/freeze-artifacts.cjs" "$R" harness "$R/build01/harness-tests.jsonl"
cargo build --manifest-path "$R/cohort/native/Cargo.toml" --release --locked --offline --bins > "$R/build01/harness-build.stdout" 2> "$R/build01/harness-build.stderr"
for NAME in cohort-panel cohort-point-audit; do cp "$R/target/release/$NAME" "$R/qualified/$NAME"; chmod 500 "$R/qualified/$NAME"; done
for ARM in parent candidate; do
  cargo test --manifest-path "$R/source-$ARM/crates/hashed-ecdl-cpu/Cargo.toml" --release --locked --offline --lib --no-run --message-format=json-render-diagnostics > "$R/build01/$ARM-tests.jsonl" 2> "$R/build01/$ARM-tests.stderr"
  node "$R/freeze-artifacts.cjs" "$R" "$ARM" "$R/build01/$ARM-tests.jsonl"
  cargo build --manifest-path "$R/source-$ARM/crates/hashed-ecdl-cpu/Cargo.toml" --release --locked --offline --example scale > "$R/build01/$ARM-worker.stdout" 2> "$R/build01/$ARM-worker.stderr"
  cp "$R/target/release/examples/scale" "$R/qualified/$ARM-scale"
  chmod 500 "$R/qualified/$ARM-scale"
done
printf 'Strict C / locked Rust copied qualifiers built; no qualifier or solver invocation.\n'
