#!/usr/bin/env bash
# One bounded source-frozen qualification phase.
set -euo pipefail
ROOT=/tmp/ecdlp-cohort-validation-20261123
LABEL=$1
shift
OUT="$ROOT/$LABEL"
mkdir "$OUT"
printf '%q ' "$@" > "$OUT/command.txt"
printf '\n' >> "$OUT/command.txt"
cp "$ROOT/additional-inputs.sha256" "$OUT/additional-inputs.frozen.sha256"
chmod a-w "$OUT/additional-inputs.frozen.sha256"
sha256sum "$ROOT/run-command-v2.sh" "$OUT/additional-inputs.frozen.sha256" > "$OUT/input-before.sha256"
cat "$OUT/additional-inputs.frozen.sha256" >> "$OUT/input-before.sha256"
sha256sum -c "$OUT/input-before.sha256" > "$OUT/input-precheck.log"
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$OUT/started-utc.txt"
read -r INITIAL < /sys/fs/cgroup/memory.current
if [ "$INITIAL" -ge 15032385536 ]; then
  printf '75\n' > "$OUT/exit-code.txt"
  printf '1\n' > "$OUT/physical-stop.txt"
  printf '%s\n' "$INITIAL" > "$OUT/peak-cgroup-bytes.txt"
  exit 75
fi
setsid timeout --signal=TERM --kill-after=5 600 flock /tmp/ecdlp-cohort-validation-20261123/worker.lock "$@" > "$OUT/stdout.txt" 2> "$OUT/stderr.txt" &
PID=$!
PEAK=$INITIAL
STOP=0
while kill -0 "$PID" 2>/dev/null; do
  read -r USED < /sys/fs/cgroup/memory.current
  if [ "$USED" -gt "$PEAK" ]; then PEAK=$USED; fi
  if [ "$USED" -ge 15032385536 ]; then STOP=1; kill -TERM -- "-$PID" 2>/dev/null || true; break; fi
  sleep 0.25
done
set +e
wait "$PID"
CODE=$?
set -e
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$OUT/finished-utc.txt"
printf '%s\n' "$CODE" > "$OUT/exit-code.txt"
printf '%s\n' "$STOP" > "$OUT/physical-stop.txt"
printf '%s\n' "$PEAK" > "$OUT/peak-cgroup-bytes.txt"
sha256sum -c "$OUT/input-before.sha256" > "$OUT/input-after-check.log"
cat "$OUT/stdout.txt" "$OUT/stderr.txt"
exit "$CODE"
