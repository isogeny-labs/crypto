#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/ecdlp-cohort-validation-20261123
sha256sum -c "$ROOT/PRECALL.sha256" > "$ROOT/native01/precall-check.log"
timeout --signal=TERM --kill-after=5 60 "$ROOT/qualified/admission" "$ROOT/inputs/targets.tsv" "$ROOT/native01/rows.jsonl"
sha256sum -c "$ROOT/PRECALL.sha256" > "$ROOT/native01/postcall-check.log"
