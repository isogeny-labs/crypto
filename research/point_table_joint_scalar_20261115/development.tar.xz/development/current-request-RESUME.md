# Point-table joint-target continuation

## Goal
Continue the user-requested point-hashing relation-collection improvements in isogeny-labs/crypto and cryptanalysis. Runtime gains require admitted matched measurement.

## Lead / hypothesis
HAC14.88 two-base joint multiplication shares the doubling chain for public relation targets uG+vQ, reusing three points. Existing per-query subgroup and final arithmetic/certificate replay remain.

## Spec
Native API/docs: crates/hashed-ecdl-tensor/PREPARED_PAIRS.md. Current source/protocol work is on codex/point-table-joint-scalar-20261115, stacked on codex/reusable-point-tables-code-20261115. The original 32-context/2368-attempt pilot in separate PR2984 remains unchanged, not launched by this task. Do not edit its branch. No new measured panel is silently substituted for it.

## State
JointTable, prepared::solve_joint and solve-hashed-joint implemented and mirrored. Public F17 developer controls show whole seeded certificates/RNG match; additions 1131 to1015,905 to855,985 to923. These counts are not runtime results. Initial source/logs and formatting failure are in /workspace/scratch/joint-scalar-20261115, committed compact receipts are being assembled. Crypto source base02cc5b6a9183a64acccc9ee58a319e58fc2cf54a, mirror7893dc931c6f691a57b428d16f7cf8df193082ad. Crypto canonical registration storage contract remains separately unresolved; do not mutate ledger.

## Next steps
Finish exact-source development receipts and paired stacked PR publication. Track parents4342/1574 on spaced cadence; respect Copilot-first conflict workflow. For scientific execution, fresh S3 checkpoint upload/readback, authenticated exact native image/execution and original pilot admission must all pass. Check configured identity/client and documented GitHub checkpoint route; do not use chat credentials or launch stock fixture.

## Runs in flight
No scientific run, cloud build or production batch submitted. Development all-target test wrapper /workspace/scratch/joint-scalar-20261115/qualify.py is finishing mirror structured controls; source/logs stay local then in versioned receipts. No retries/restores.

## Stop and success conditions
Component acceptance: full certificate/RNG equality, subgroup/canonical/exception/limit and CLI controls, strict fmt/clippy and applicable minimum-version checks, preserved raw/source receipts and PRs. Scientific acceptance remains the original admitted matched workload, cold/setup/query/full-pipeline costs and independent replay. Existing first-pilot USD10 ceiling, two image builds, one1800s attempt,4CPU/4GiB, concurrency1, zero automatic retries/restores remain unchanged; unknown lane/account headroom alone does not block that override. Missing upload/readback or native execution/image admission does block experiments.
