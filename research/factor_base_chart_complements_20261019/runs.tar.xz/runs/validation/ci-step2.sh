set -euo pipefail
study=research/factor_base_chart_complements_20261019
(cd "$study" && sha256sum -c SOURCE_SHA256SUMS && sha256sum -c runs.tar.xz.sha256 && tar -xJf runs.tar.xz && sha256sum -c runs/SHA256SUMS)
"$study/screen/target/release/factor-base-chart-screen" screen "$study" "$RUNNER_TEMP/chart-census.json"
cmp "$study/runs/census.json" "$RUNNER_TEMP/chart-census.json"
