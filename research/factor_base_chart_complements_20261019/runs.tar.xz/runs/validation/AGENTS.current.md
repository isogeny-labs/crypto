# Agent instructions

## Standing workflow rules (from the owner)

- **Always commit finished work and open or update a PR.** Landed rungs,
  ledger promotions, evidence directories, and code changes land as commits
  on a feature branch. If the branch already has an open PR, extend that
  PR and update its title and description to match the new scope instead of
  opening a second one. Do not leave finished work uncommitted.
- **Verify before pushing:** run `cargo test --release --lib`, the touched
  examples' tests, and the relevant Python suites (for example
  `research/sat_factor_base_review_20260908/autolab/test_boundary_autolab.py`)
  and fix failures first.
- **Claim hygiene** (see `docs/ic/boundary_targets.json`): public synthetic
  / known-answer fixtures only; fail-closed evidence; no key-recovery,
  asymptotic sub-rho, or deployed-curve-security claims; multi-target and
  amortized results stay secondary; ledger rows promote only with complete
  measurement fields and independent replay.
- **Beat the fastest external tool, and show it** (owner's rule,
  2026-10-16; details in §15): our implementations should be faster than
  every other implementation of the same computation. Every speed result
  is compared with the fastest external tool for that computation, for
  example Magma's F4 and F5 or msolve for Gröbner bases, on the same inputs
  and host, with the outputs checked equal. A result that has not been
  compared is not yet a claim of being the fastest, and a loss is reported
  as a loss.
- **Every big improvement updates the leaderboard** (owner, 2026-10-15).
  A PR that lands a large measured gain, whether a whole pipeline, a phase
  or a component (an engine, filter, oracle, solver or kernel), regenerates
  `docs/ic-leaderboard.html` and its twins in the same PR (§7b), even when
  no row of tables A–C moves; it is not a follow-up.
- **Conductor:** run `conductor check --summary "…" --scope path:…` before
  editing; report scope expansion before editing outside reserved paths. Do
  not publish chat transcripts or secrets as task metadata.

## Success criterion: iterative improvement of the index-calculus baseline

Owner's rule, 2026-10-15. It replaces any earlier wording that treats only
beating rho, or only an "advance", as success.

The long-term goal is an index calculus that beats Pollard rho. That will
not come from one breakthrough. It comes from many measured improvements,
each building on the last, until the gap closes. So **the success criterion
is a verified, measured improvement over the current index-calculus
baseline. Every such improvement is a success and is reported as one.**

- **Baseline.** For each curve and size, the baseline is the best current
  verified index-calculus pipeline, frozen with its protocol, receipts and
  end-to-end `S` (every phase, cold). Name it before you optimise.
- **Improvement.** The improvement must lower cost against that baseline on
  the same instances, with every answer verified, under a protocol frozen
  before timing. A stage-level win is reported as a stage improvement and
  becomes a pipeline improvement once it moves end-to-end `S`. The
  measurement rules still apply in full: isolation tiers, A/A and positive
  controls, matched references, and no combining results from different
  experiments.
- **What counts.** Advance and engineering are both successes. Relabelling
  (the headline count fell while total cost rose) and accounting (the
  numbers changed but the algorithm did not) are recorded honestly and are
  not improvements. A negative or null result is a valid outcome to record,
  but it is not an improvement.
- **Ratchet.** Each landed improvement becomes the new baseline. Record it
  with its delta, so progress is cumulative and visible across the
  sequence.
- **Distance to rho.** Report the gap to the matched rho on every row,
  and to precomputation rho (Bernstein–Lange) where setup is excluded. The
  gap is the distance remaining, not a pass/fail gate. Not beating rho
  never makes an improvement a failure. A claim to *beat* rho still needs
  every reference rule: an end-to-end cold `S` below the matched rho's,
  robust at growing `n`, independently replayed.
- **Keep going.** After each result, name the next improvement to try, and
  move on to it.

## Pointers

- Boundary ledger (machine): `docs/ic/boundary_targets.json`
- Boundary scoreboard (human): `docs/ic/BOUNDARY_TARGETS.md`
- Autolab runner: `research/sat_factor_base_review_20260908/autolab/`
- Current ladder frontiers: `RESEARCH_KOBLITZ_INDEX_CALCULUS.md`,
  `RESEARCH_ECC2K130_IC_FEASIBILITY.md`
- Faster checkouts (blobless clone, sparse profiles, cloud-session
  settings): [docs/sparse-checkout.md](docs/sparse-checkout.md)

For small-prime or pinned GF(2^83) elliptic-curve surface searches, quartic
subgroup transfers, genus-2+ Jacobian transfers, hyperelliptic covers, Mumford
arithmetic, gluing or polarization candidates, or Frobenius compatibility
checks, use
[ecdlp-surfaces](.agents/skills/ecdlp-surfaces/SKILL.md) for tool selection,
commands, and interpretation limits.

## Reading discipline

`research/` is most of a 6.6 GB, 100,000-file checkout. Read what the current step needs:

- **Indexes before archives.** Status comes from the pointers above,
  `docs/bounds/frontier.json`, and the ecbench database views; open a session
  or note to act on it, not to find it.
- **Locate, then read.** `rg -n` an exact id, slug, or term in the narrowest
  directory, then read the matching range.
- **Size before contents.** Check `wc -c` first. Read raw session outputs,
  `*.jsonl`, logs and CSVs by key or range (`jq`, `rg`), never whole; a
  session is read through its audit, replay or claim JSON.
- **Paths, not contents,** in handoffs and subagent prompts.
- **Off disk is not absent.** In a sparse checkout (`docs/sparse-checkout.md`)
  a path `git ls-files` lists is materialized with
  `scripts/sparse-checkout.sh add --path`, never reported missing.

# AGENTS.md

## Preserve scope and report evidence

Use [report-evidence](.agents/skills/report-evidence/SKILL.md) for implementation,
experiments, benchmarks, completion reports, and research handoffs.

- Preserve the user's requested deliverables, parameters, workloads, and acceptance
  criteria. Do not silently substitute a smaller experiment, weaken an argument
  or validation gate, or omit a requested run because you expect it to fail.
- Execute authorized, feasible experiments as requested. The user decides research
  significance and priorities. Report measured values and exact ratios; do not
  independently market results as "massive", "breakthrough", or dismiss them as
  "not worth running". Give interpretation when requested and label it separately.
- Continue to check correctness and flag invalid results, factual errors, and
  uncertainty. Preserve failed runs, timeouts, regressions, raw evidence, exact
  commands, inputs, revisions, environment, and accounting intervals.
- Distinguish assistance restrictions, access/tool limits, resource limits,
  implementation gaps, untested hypotheses, and proved mathematical obstructions.
  Never disguise an assistance limit as mathematical impossibility. State the
  actual blocker explicitly; retain the original requirement as unresolved.
  Higher-priority restrictions and authorization boundaries still apply.
- Keep observations, calculations, hypotheses, extrapolations, and interpretations
  distinct. A stage ratio does not establish an end-to-end gain; a bounded search
  failure does not prove nonexistence; a toy implementation is not general support.
- Track each requested requirement as verified complete, implemented but unverified,
  partial, blocked, or not attempted, with evidence or the exact remaining gap.
  Passing tests or merging a PR does not make the original task complete.
- Correct misleading prior claims explicitly. Do not rewrite frozen evidence or
  quietly redefine completion. Report actual execution status, never planned runs
  as completed or unscheduled work as continuing in the background.

These rules govern scope and reporting throughout this file. Existing measurement
and correctness gates remain in force; they do not authorize an agent to cancel a
requested experiment or decide its research significance for the user.


Guidance for agents doing cryptanalysis work in this repository.

This repository is a study library, not a production one, and its
cryptanalysis suite exists to find out **where crossovers actually are**
rather than to produce attacks.  That makes the reporting rule below the
most important convention here: without it, a thread can run for weeks,
improve its own headline number by two orders of magnitude, and have
established nothing.

## Name the obstruction

When substantial research, cryptanalysis, or audit work cannot meet a proof,
implementation, experiment, or validation requirement, **name the specific
problem**. Before repeating the same blocked approach or handing it off, create
or update `problems/<descriptive-slug>.md` using
[the problem template](problems/TEMPLATE.md), add it to
[the problem index](problems/README.md), and link it from the affected work.

- State exactly what is blocked, under which parameters and assumptions, and
  why that gap prevents the requested conclusion. Track major or recurring
  blockers, not every routine TODO.
- Separate observed evidence, suspected explanations, missing implementations,
  access/tool or assistance limits, resource limits, and proved mathematical
  obstructions. Cite artifacts or proofs with their exact scope; mark unknowns
  explicitly. A timeout or bounded failed search does not prove impossibility;
  failure to find an attack does not establish security.
- Say **what would unblock it**: the missing lemma, construction, verified map,
  measurement, implementation, access, or resource, with checkable acceptance
  criteria. Explain what satisfying those criteria would establish and what
  would remain unresolved. "More research" is not an exit condition.
- Give the next discriminating experiment or proof obligation, its controls
  and execution limits where relevant, and how each possible outcome changes
  the next action. Apply the existing experiment and budget rules.
- Reuse an existing problem record for the same obstruction, including a
  cross-repository link when appropriate. Update its evidence, next action,
  and index row in the PR that changes the situation; preserve frozen evidence.
  Resolve it only with linked evidence meeting its exit criteria. If another
  record replaces it, mark it superseded and link the successor.

Recording a problem keeps the original requirement visible; recording it alone
does not resolve that requirement. It
does not authorize abandoning requested work, weakening its acceptance criteria,
or promoting a claim. Completing the template or merging its PR does not solve
the underlying problem.

## Intermediate-cost and asymmetric-access hypotheses

User instruction, 2026-10-06. In assessments of supplied or published claims
of hidden mathematical advantage, include costly intermediate advantages:
a hypothetical reduction from subgroup-size work r^(1/2) to r^alpha with
alpha < 1/2 may matter even when recovery remains expensive. The example
alpha = 1/3 is a threat-model assumption, not a discovered algorithm or a
required outcome. Do not dismiss a claim solely because it fails to make
recovery trivial; do not infer practical recovery from its exponent alone.

Keep mathematical existence, executable transfer, subgroup preservation,
destination-solver advantage, practical resources, and asymmetric access as
separate obligations. A hypothesis about agency capabilities or motives is
not evidence that a trapdoor exists. Distinguish a deliberately selected
weak instance from an unpublished method applying to honestly generated
instances, and distinguish both from implementation compromise.

Account for curve-specific construction and preprocessing, per-target work,
transfer and recovery, verification, failed attempts, memory, hardware, and
the exact number of targets reusing setup. Report cold-start and genuinely
amortized costs separately. Separate exponent changes, constant factors,
primitive costs, and hardware throughput. Faster known-scalar multiplication
alone does not establish faster unknown-scalar recovery.

Under the user's hidden-route scenario, public discovery must require
substantial deliberate work rather than routine inspection or accidental
rediscovery. An illustrative reconstruction cost near 2^60 operations is a
scenario parameter, not a measured bound or evidence of agency capability.
Define the operation unit, algorithm, success probability, memory, parallelism,
and uncertainty before interpreting that number. Keep public discovery cost,
designer setup with a retained witness, map evaluation, and destination solving
separate. Isogeny degree alone establishes none of these costs. Assess cheaper
equivalent routes as well as reconstruction of the exact withheld map; one
comparably useful public shortcut can defeat the claimed access asymmetry.

Treat secrecy as a separate hypothesis: identify the withheld information,
whether it can be reconstructed from public parameters, and whether a
comparably useful public route exists. A high-degree map is not automatically
cheap to evaluate or hard to reconstruct. State field and construction-family
restrictions; do not transfer composite-degree binary-field conclusions to
prime fields or prime-degree binary extensions without justification.

When the user stipulates layered adversary capability, assess a portfolio
rather than one all-purpose vulnerability. Record each hypothetical technique's
prerequisites, coverage, cost, reusable setup, access requirements, secrecy,
and failure conditions. Distinguish independent alternatives from methods
sharing the same dependency; do not assume independence or multiply speculative
probabilities. Include redundancy, complementary combinations, and what
remains available if one technique is disclosed, patched, or loses its advantage.

Model reserved capabilities and exceptional-use scenarios explicitly, including
activation constraints, scarcity, exposure risk, and the cost of losing secrecy.
These are stipulated game-theoretic assumptions, not observations of agency
behavior or proof of any particular mathematical capability. Alternative
implementation or protocol compromises do not refute an algebraic hypothesis
and do not replace an algebraic workstream the user has requested. Preserve
each requested track and its unresolved obligations.

Apply existing transfer, evidence, run-routing, and review rules. Missing
formulas or measurements remain open obligations. Bounded failure is not
universal nonexistence. This assessment rule adds no autonomous key-recovery
campaign, production-target exploitation, or scientific state transition.

## Curve-structure and endomorphism rules

For trace and anomalous-order patterns, CM conductor gaps, torsion over
extensions, twists, isogenous representatives, GLV/GLS formulas, covers, and
factored or mixed-degree isogeny loops, follow
[docs/endomorphism-rules.md](docs/endomorphism-rules.md). Record the exact
ICV1/EC1 identity, working field, subgroup, bounded signal calculation,
explicit map when proposed, and its complete evaluation and transfer costs.
Keep existence, executable construction, subgroup action, measured scalar
arithmetic, and unknown-scalar recovery as separate claims. A small torsion
factor, class number, embedding degree, or composite map degree is a lead with
specific hypotheses, not a universal verdict. Preserve negative searches
within their exact bounds and run authorized feasible experiments under the
existing evidence, review, and benchmark rules.

## Research searches must leave visual reports

Every experiment run (ICMS or ecbench session, autolab or tournament round,
benchmark, or other research run), every PR that lands a result, and every
substantive search for new isogenies, curves, scalar rules, endomorphisms, or
related ECDLP mechanisms follows
[the research-visuals skill](.agents/skills/research-visuals/SKILL.md), on
every runtime (Claude Code reads it at `.claude/skills/research-visuals/`).
Deliver a source-linked report, a graph or explanatory diagram, and a PDF
containing the report and visual. A run report is descriptive and sits beside
the run's records, never inside a sealed or audited session directory.
Include negative, failed, and inconclusive findings.
Update every affected canonical graph, chart, and rendered copy in the same
change as a new verified finding or correction; record why a graph was left
unchanged when the search yields no graphable result. Keep proposed routes and
unverified rules visibly separate from proved or measured ones. This visual
record supplements the evidence, curve-identity, scoreboard, and PR rules
below; it does not promote a hypothesis or replace a verified run.

### Performance results also land in `benchmarks/`

Every run or PR that measures how fast an algorithm runs or reports a speedup
(an engine, kernel or solver timing, a before/after comparison of the same
code, a comparison with an external system such as msolve, Singular or Magma)
also copies its visual record into `benchmarks/`, in the same PR, always:

- `benchmarks/<YYYYMMDD>-<slug>/` holds the report PDFs (run report and
  results report), every graph as SVG, and a PNG render of every graph
  (150 dpi, rendered from the same plotting source as the SVG).
- `benchmarks/README.md` gets one row per entry, newest first: date, what was
  measured, the headline values with their units and ratios as the report
  states them, host and isolation level, and links to the study directory
  and run report.
- The study directory stays the source of truth (raw records, sources,
  inputs); `benchmarks/` holds copies for browsing. Regenerate both from the
  same source and never edit a copy alone. A later run adds a new entry and
  leaves earlier ones as they are.

`benchmarks/` is not `benches/`, which holds Cargo bench sources.

## Papers

Manuscripts generated from this repository's results live under `papers/`,
one directory per paper, and nowhere else. The layout is the same in
`aburan28/cryptanalysis`, `aburan28/crypto`, `aburan28/crypto-autoresearcher`
and `aburan28/ml-cryptanalysis`:

- `papers/README.md` is the index: one row per paper (directory, title,
  status). Add a row when adding a paper; never add a paper outside `papers/`.
- `papers/paper.mk` is the shared build. A paper's `Makefile` sets `TEX`,
  `SECTIONS`, `BIB` and, for figures or other files the build reads,
  `ASSETS`, and includes it; the targets are `make`, `make check`,
  `make arxiv`, `make eprint`, `make deanonymize` and `make clean`.
- `papers/.gitignore` ignores LaTeX auxiliaries and submission bundles. The
  built PDF is committed next to its sources and rebuilt whenever a cited
  number, conclusion or figure changes.
- `papers/AUTHORS.example` is the author-block template. Sources stay
  anonymized (`\author{Anonymous}`); `make deanonymize` restores the authors
  from an untracked `AUTHORS` file.
- Each paper directory holds the root `.tex` (or the `.md` of a draft that is
  not typeset yet), its sections and bibliography, `README.md` (status banner,
  what it says, what it does not say, how to build, reproduction pointers, and
  the checklist owed before submission), `abstract.txt` (title, keywords,
  category) and the PDF.
- Claims follow the repository's evidence rules: every number cites a
  committed artefact in this repository or a sibling (prefix the path with
  `crypto:`, `cryptanalysis:` or `crypto-autoresearcher:`); a stage
  diagnostic is never reported as a speedup; every end-to-end row has
  verified answers; each change is classed as advance, engineering,
  relabelling or accounting. A draft is not submitted, posted or cleared for
  either until its README says so, and its README names the novelty audit
  and the measurements still owed.
- `make check` must pass (references and citations resolved, no LaTeX errors,
  no overfull boxes) before a PDF is recommitted.

## Mathematical results should include Lean proofs

**Standing owner instruction, 2026-10-11:** For every new or substantially
revised mathematical result, include a faithful Lean 4 theorem and checked
proof whenever formalization is feasible. Treat the formalization attempt as
part of the requested work, and prioritize the central theorem and its
dependencies. Keep the readable mathematical proof in the report.

- Maintain a proof map from each report theorem, proposition, lemma or
  corollary to its Lean declaration, exact hypotheses and verification status.
  Match the mathematical statement, including quantifiers, exceptional cases
  and field, curve, subgroup and endomorphism-order assumptions.
- Pin the Lean toolchain and dependency revisions. Build the actual theorem
  modules with `lake build` or an equivalent command, retain the command and
  output, and inspect `#print axioms` for every reported theorem. Recheck the
  compiled proofs with `lean4checker --fresh` when available.
- A reported Lean proof must contain no `sorry`, `admit`, `sorryAx`, custom
  axioms encoding the research claim, kernel-check bypasses or unverified
  native evaluation. Record the standard Lean foundations used.
- Prove the structural implications as well as the algebraic identities.
  Conditional theorems must expose their assumptions and identify any missing
  bridge to the actual mathematical objects. Do not present a weaker statement,
  assumed conclusion, circular hypothesis or arithmetic certificate as a full
  Lean proof of the report's theorem.
- If the full formalization cannot be completed, preserve the original result
  and its written proof, finish the feasible Lean lemmas, and record the
  concrete missing definition, dependency, proof obligation or failed build.
  Report partial formalization explicitly; keep the full theorem open.
- Add reproducible proof checks to the relevant CI workflow where practical.
  Every Lean target is also checked by the repository-wide proof gate
  (`tools/lean/proof-gate.sh`, workflow `lean-proof-gate.yml`): it builds each
  Lake project and standalone file and fails any theorem whose transitive
  axioms include `sorryAx`, an unlisted `native_decide` or a user axiom. A
  `native_decide` that a study deliberately trusts is recorded with its reason
  in `tools/lean/trusted-native.txt`. See `tools/lean/README.md`.
  Preserve frozen evidence and attach formalization updates as versioned
  additions rather than rewriting historical verification records.

## Implementation language: no Python

**Do not use Python for cryptographic research or performance work in this
repository.** This applies to algorithms, field and curve arithmetic,
factor-base construction, relation collection, solvers, linear algebra,
experiment harnesses, benchmark drivers, correctness tests, certificate
verifiers, replay tools, and research result generation.

- Use **Rust by default**, integrating with the existing library and Cargo
  tests. Use an existing compiled C, C++, CUDA, or other native backend where
  the component requires it.
- Do not introduce Python prototypes, Python orchestration, embedded Python,
  or compiled wrappers that delegate this work to a Python process. Moving
  only a hot loop to native code does not satisfy this rule.
- When continuing work implemented in Python, replace the relevant execution
  path with a native implementation before extending it or running further
  research comparisons. A working Python harness is not an acceptable final
  deliverable. Use shell commands only for thin build/run orchestration.
- Preserve frozen inputs, historical measurements, source snapshots, and
  certificates as evidence. Do not delete or rewrite them to conceal their
  Python provenance. Label historical Python timings accordingly and rerun
  matched native baseline/candidate measurements before making new performance
  claims.
- Older instructions that name Python scripts describe legacy tooling; they
  do not grant an exception. Preserve their mathematical contracts, fixtures,
  and accounting requirements in the native replacement.

## Model tiers

Owner rule, 2026-10-17: one model-tier topology across the owner's
repositories. The reference design is
[`docs/model-tiers.md`](https://github.com/aburan28/crypto-autoresearcher/blob/main/docs/model-tiers.md)
in aburan28/crypto-autoresearcher.

| tier | does here | Anthropic |
| --- | --- | --- |
| frontier | design, interpretation, claims, breakthrough review | Mythos (`claude-mythos-5`), Fable 5.1 (`claude-fable-5-1`) |
| core | the same when frontier is not needed; coordination and review | Opus 5.5 (`claude-opus-5-5`); OpenAI, GLM 5.3 and Qwen equivalents |
| director | compiles a decided experiment into a task card (`tools/task_card.py`: one format in every repository, copied byte-identical from crypto-autoresearcher, never edited here), then assesses the run | Sonnet 5.5 (`claude-sonnet-5-5`), [`experiment-director`](.claude/agents/experiment-director.md) |
| mechanical | runs the card through `tools/task_card.py run`, relays its output verbatim, computes nothing, refuses anything underspecified | Haiku 5.5 (`claude-haiku-5-5`, effort low), [`executor-mechanical`](.claude/agents/executor-mechanical.md) |

- **Frontier and core keep the reasoning**: the spec and preregistration,
  analysis (`ecbench compare` and `table` read-outs), the §5a pricing band and
  every cross-method ranking, success-criterion classification, claims, and
  every PR decision (open, fix, merge).
- **The relay.** Subagents do not nest in Claude Code, so the main session
  does every dispatch: it dispatches `experiment-director` in compile mode,
  relays the card it returns to `executor-mechanical` verbatim (adding
  nothing), then dispatches `experiment-director` again in assess mode with
  the executor's returned text. A card with a `specification_error` is not
  relayed; the reasoning tier fixes the spec.
- **The mechanical tier's output is an observation, never a result claim.**
  The director's assessment says only whether the run executed as specified
  and the relay was verbatim. What the numbers mean is decided by the
  frontier or core tier under the measurement rules below.

## Default workflow: open the PR, check in, and land it

The repository owner's standing preference (owner, 2026-10-14) is that the
session which opens a PR stays with it until the PR is merged or closed. That
session checks in on the PR, fixes the CI failures and review feedback its
change causes, and merges once the PR is green and authorized. This replaces
the 2026-10-09 split, in which the authoring session stopped at the PR and a
separate small-model automation did the CI work and the merge.

**The authoring session** implements the change, validates it locally,
commits, pushes, and opens the PR (or updates the existing one). It then
follows the PR until it lands, under the check-in and merge rules below.

- **Open every PR ready for review, never as a draft**, whatever a tool or
  runtime defaults to, and mark an existing draft ready when you update it,
  so reviews and checks that skip drafts (`llm-review`) run from the first
  push. Open a draft only when the user asks for one in that task.
- Review the final diff and confirm that the requested scope, relevant tests,
  evidence, and documentation are complete before opening the PR. Passing CI
  does not substitute for checking that the work is finished.
- **Check in on PRs you opened.** Follow the PR's activity: CI results, review
  comments, merge-state changes, and merges or closes. Where the runtime
  provides PR-activity subscriptions (`subscribe_pr_activity`), use them. Where
  it provides scheduled check-ins (`send_later` or similar), keep one
  safety-net check-in about 50 minutes after the last activity, later ones
  about 4 hours apart, re-armed silently when nothing has changed. Stop after 3
  check-ins in a row that find nothing new, when the PR merges or closes, or
  when the user says to stop. Any new activity resets the count.
- **No busy polling.** Do not sleep in a loop, re-read check runs or job logs
  faster than the check-in cadence, or wait on a job in the foreground. The
  cadence limits apply to every runtime, top-tier models included.
- **Any runtime may do the CI work.** Claude Opus, Fable, and other top tiers
  may check in on, fix, and merge the PRs they opened, under the same rules as
  a small model. The owner's 2026-10-09 restriction on top-tier CI work is
  withdrawn.

**Merging** is part of the same flow. The authoring session does not ask for
another approval to merge a completed, passing PR unless a policy or reviewer
requires explicit authorization for that merge, and it follows these rules:

- Apply merge authorization to PRs created or maintained for the current user
  task, not unrelated PRs. An explicit instruction to leave a PR open, keep it
  as a draft, wait for review, or avoid merging overrides this default.
- Check the current PR head: all required and applicable CI checks must have
  completed successfully. Pending, cancelled, timed-out, or failed checks are
  not a pass. A skipped job counts as inapplicable only when its conditions or
  path filters justify that status; required checks must still be satisfied.
- Fix failures caused by the change autonomously: read the failing check's
  log, reproduce the failure locally, fix it, and rerun the affected
  validation before pushing. Never skip, disable, or quarantine a test to get
  green, and never push an empty commit or close and reopen a PR to re-run CI.
  A failure that is not this change's (red on the base branch, or a service
  the diff does not touch) is reported on the PR with the evidence, not
  patched around. Offload merge conflicts to GitHub Copilot (next bullet) rather
  than resolving them yourself. Any new commit requires checking CI again for
  the new head. Do not bypass branch protections, required reviews, unresolved
  blocking review feedback, or required checks.
- **Merge conflicts go to Copilot first.** When a PR you maintain reports a
  merge conflict (`mergeable_state` `dirty`, or a conflict notice), post one PR
  comment asking `@copilot` to resolve it by merging the base branch into the
  PR head, without rebasing or force-pushing, and to keep the PR's scope
  unchanged (the GitHub MCP tools also expose Copilot assignment if a comment is
  not enough). This standing instruction authorizes that comment; do not ask
  again. Then:
  - Do not edit the conflicted files yourself while Copilot's request is
    pending; two resolvers on one branch create a second conflict.
  - When Copilot pushes, review its diff against both sides, regenerate
    lockfiles and generated files with the repo's tooling rather than by hand,
    and rerun the affected validation (`cargo check`, the touched tests). A
    resolution is not done until the PR head merges cleanly and CI is checked
    on the new head. Report Copilot's result as unverified until you have done
    this.
  - Resolve it yourself (merge the base in, never rebase or force-push a shared
    branch) only if Copilot declines or cannot act on the PR, pushes a
    resolution that fails validation, or has not responded after a reasonable
    wait; say in the PR why you stepped in.
  - Conflicts in frozen evidence, ledger rows, or claim files are never
    resolved by picking a side: report them to the user.
  - If Copilot is unavailable in the session (no GitHub MCP access, plan
    limits), say so and fall back to resolving it yourself.
- If a documentation-only change legitimately triggers no CI, verify the
  workflow filters, inspect the diff, and run any relevant local validation.
  State that no CI applied; do not claim that nonexistent checks passed.
- Merge using the repository's permitted merge method and an expected-head-SHA
  guard where supported. Confirm that GitHub reports the PR as merged, then
  record the merge commit and validation outcome on the PR.
- If access, required external review, a persistent CI failure, or another
  concrete gate prevents merging, report that blocker precisely on the PR
  rather than asking the user to repeat the authorization already given.
- If automatic approval review rejects a merge for lack of authorization,
  leave that PR open and ask for explicit approval naming the exact PR. Do not
  retry by changing tools, branches, accounts, or merge route. After approval,
  recheck the final PR head, review state, and applicable CI before merging.

## Research work belongs in pull requests

**Always create or update a PR for repository-related action items, research
plans, benchmark protocols, and workstream closeout checklists, including
Markdown-only planning work. Do this in the same task without waiting for the
user to ask again.** Commit the plan in the relevant repository and return its
PR link; a chat response, scratch file, or Library copy alone is not delivery.
Update an existing relevant PR when appropriate rather than creating duplicates.
An explicit user request not to create a PR overrides this default.

A planning PR may merge when the plan itself is complete and its applicable
checks pass. Keep unperformed experiments and measurements marked pending;
merging the plan does not close the underlying workstream. Track execution,
evidence, and closeout in linked follow-on PRs and update the checklist as work
lands. Apply the PR and merge rules above to each completed deliverable.

Treat an experiment as repository work, including a negative or inconclusive
result. A research decision, preregistered protocol, reproducibility fix, or
rejected hypothesis also belongs in a PR, even before an outcome exists.
Before running an experiment, state the hypothesis, frozen inputs, reference,
success and stop conditions, and cost accounting in a versioned protocol.
Make each bounded experiment or compatible group of experiments a focused
branch and PR. Commit the code, configuration, seeds, source and input hashes,
commands, compact raw results, verification receipts, analysis, and decision
in that PR. Link follow-on PRs to their dependencies; do not let a local note,
untracked worktree, chat summary, or published page be the only record of a
finding or a decision.

Preserve failures, timeouts, and regressions. Do not overwrite an earlier
run. If raw output is too large for Git, commit a manifest with its content
hash, byte count, durable accessible location, extraction command, and the
small derived data needed to audit the claim. A local absolute path alone is
not a durable location. Label unmerged work and unreviewed replays as such;
a downstream claim cannot silently treat them as accepted evidence.

For performance changes, the existing frozen-suite, full-cost, matched-rho,
and scoreboard requirements in sections 1–8 still apply. A PR that reports
only a stage measurement must label it a stage diagnostic and leave
end-to-end cost and speedup unset. Open or update the PR as part of the
iteration and stop there; the merge automation of the default workflow above
merges it once its evidence, review, and CI gates are satisfied.

## The rule: boundary, table, ratio

Any thread that claims to improve an attack must express its progress as
a **ratio to a boundary**, reported in a **single table** whose rows are
variants and whose columns are one unit.  A thread that cannot state its
boundary has not started; a thread whose ratio to the boundary is flat
has not progressed, however much its constants moved.

### 1. State the boundary before measuring

A **boundary** is a quantity that the method under study cannot cross,
derived rather than measured.  It comes in two kinds, and a thread
normally has one of each:

- A **floor**: a lower bound from a counting or generic-group argument.
  Example from `research/notes/index-calculus/RESEARCH_RESIDUAL_WALKS.md`: a generic algorithm's
  expected relation yield from `P` residuals is at most `γP²/2n`, so the
  count factor obeys `κ_total ≥ √(2(B+1)/γ)`.  That floor moves only
  with the factor-base size `B` and the automorphism order `γ`, so it
  cannot be tuned away.
- A **reference**: the cost of the best algorithm that already solves
  the same problem, measured in the same unit on the same instances.
  For the discrete logarithm that is Pollard rho, run on the same group,
  with the same operation accounting.

Write both into the note *before* optimising, with the formula for the
floor and the measured value of the reference.  A boundary chosen after
the fact is not a boundary.

### 2. Report one table, one unit

One table, one unit, every variant as a row, including the reference and
the unmodified baseline.  Pick the unit so that the boundary is a
constant in it.  This repository's ECDLP threads use

```
S = total operations / sqrt(n)
```

which makes rho a flat `S ≈ 1.3` at every size and turns "is this
better than rho" into reading one column.  Every cost the method incurs
belongs in `S`: precomputation, table setup, relation verification,
linear algebra, and any work an oracle does per call.  Convert foreign
units with a measured conversion factor and record it, for instance the
63 field multiplications per curve addition measured on `F_{p³}`.

**End-to-end speed is the measure of speed.**  `S` is defined over the
*whole* method, cold, from setup to the recovered logarithm; a number
that prices only one phase — the relation search, the decomposition
oracle, a single solver call, the linear algebra — is a stage
diagnostic, never a speed.  "Faster than rho" means the method's `S`
column, with every phase inside it, sits below rho's, robustly, at
growing `n` — nothing less earns the phrase.  Quoting a phase crossover
as a method crossover is the §5 mistake, and the residual-walk thread is
the worked case: its relation phase crosses rho near `2^{96}` in
isolation while the whole method never does, because the linear algebra
it left out decides the exponent (§11.6–11.7).  Equivalently, the only
admissible speed ratio is §8's
`speedup = baseline_total_operations / candidate_total_operations`;
a ratio taken over any smaller slice of the pipeline is labelled a stage
diagnostic and may not be reported as a speedup.

The table must carry a **ratio column** against each boundary, and a
correctness column.  A row without a verified answer is not a result.

### 3. Progress is the ratio, not the constant

Classify every change, in the note, as one of:

| class | what moved | what it means |
|:--|:--|:--|
| **advance** | ratio to the floor fell | the method does something a generic algorithm cannot |
| **engineering** | `S` fell, ratio to the floor flat | an improvement to the baseline: a success (see "Success criterion") |
| **relabelling** | headline count fell, `S` rose | work moved somewhere the headline does not look |
| **accounting** | numbers changed, algorithm did not | a correction; say so and do not claim the gain |

All four are worth committing.  Advance and engineering are both
improvements, and every improvement over the baseline is a success
("Success criterion: iterative improvement of the index-calculus
baseline").  Label each row, because the failure mode this rule exists
to prevent is reporting relabelling or accounting as an improvement, or
engineering as an advance.

The relabelling class is not hypothetical.  In §10.5 of the
residual-walk note a triple-decomposition oracle cut the walked count
from `16.3` to `0.15`, a hundredfold move in the number the thread had
been tracking, while total cost got `4.6×` worse: the count was not
reduced, it was paid for per residual instead of per step.

### 4. Declare the falsification target in advance

State, in the note, the numeric condition that would make the thread a
success, and the conditions under which you would abandon it.  Make it
specific enough that a later run either meets it or does not.

The residual-walk note's target is a good model: `κ_total / κ_floor <
0.9` on a hybrid at fixed `B`, with a correct answer on every seed, zero
relations failing verification, and zero trivial collisions counted as
relations.  It also lists what is inadmissible: changing `B` or the
decomposition size, changing the operation accounting, skipping
verification, choosing favourable seeds, or counting dependent
relations.

### 5. Separate the phases, and price all of them

An exponent claim covers the whole method or it is not an exponent
claim.  Price each phase against the boundary separately and say which
one dominates, at what size.  Fit exponents over at least four sizes and
report the fit next to the prediction.

This is where the residual-walk thread went wrong once and had to be
corrected: three rounds priced the relation phase, quoted a crossover
with rho at `2^96`, and left the linear algebra unpriced.  When it was
measured it turned out to grow as `n^{0.68}` against relations at
`n^{1/3}`, so the method's cost bottoms out near `200×` rho around
`2^{50}` and rises after.  The `2^96` was a statement about one phase
and had been read as a statement about the method.

### 5a. Price the unpriced work on every arm, the reference included

Owner rule, 2026-10-15. Almost no ECDLP cost in this repository is
complete, and the rho baselines are no exception. Rho, BSGS and the
kangaroo leave canonicalisations, partition hashes, table inserts and
lookups unpriced. Index-calculus arms are complete only on curves that
have a pinned timing calibration (`calibration_pinned_units`; in the
2026-10-15 pilot that was Koblitz `n = 13` and `n = 23` but not `n = 19`).
A "complete IC against lower-bound rho" comparison is therefore
lopsided, and before this rule several were reported that way
(`research/ic_frontier_campaign_20261015/pilot/FINDINGS.md`).

Every cross-method comparison and every ranking must:

- **List every unpriced counter for every arm**, references included,
  with its count. An arm that names a counter but does not emit its count
  cannot be ranked. Report it as a lower bound and record the missing
  emission as an implementation gap to fix.
- **Price the unpriced work at several weights**: at least 0, 0.1 and 1
  group-addition equivalents per native operation, applied the same way
  to every arm. Pinned calibrations may be added as a further point, but
  they never replace the band.
- **Rank only where the conclusion holds at every weight in the band.**
  If the order of two arms changes inside the band, report them as
  unresolved at that boundary, never as a win for either side.
- **Never compare a calibrated cost on one side with an uncalibrated one
  on the other.** If a calibration exists for only some arms or sizes,
  use the band alone.

This applies to `ecbench compare` read-outs, tables, frontier syntheses,
ledger rows, papers and PR descriptions. A ratio produced before this rule
is relabelled as a lower-bound comparison where it is cited again. Its
frozen evidence is not rewritten.

### 6. What does not count

- A ratio improved by moving the boundary, changing the unit, or
  dropping a cost from the budget.
- A count lowered without the total falling.
- An extrapolation presented as a measurement.  Extrapolate freely, and
  mark it as extrapolation with the exponents it rests on.
- A run whose answer was not checked against the planted secret, or a
  new oracle not cross-checked against the one it replaces on every
  input of a full run.
- Wall-clock time as the headline.  It belongs in the table as a
  practicality note, never as the metric; operation counts are the
  metric because they survive hardware.

### 7. Keep the scoreboard current

The table lives in two places and both are part of the deliverable:
the prose table in the thread's note, and the drawn one in
`docs/index-calculus-scoreboard.html`.  **A round is not finished until
the page carries its numbers.**  The page is the thing a reader opens
first, so a stale page is worse than no page: it reports a verdict the
measurements no longer support.

The repository file is canonical.  Edit `docs/index-calculus-scoreboard.html`
and let any published copy be a republish of it, never the other way
round; a figure that exists only in a published copy is lost.

What a round owes the page:

- **A row per variant**, in the same unit and against the same
  boundaries as everything already on it.  A new variant that does not
  fit the axis means the axis was wrong, not that the variant is
  exempt.
- **A superseded figure moves, it does not vanish.**  When tuning
  lowers a cost, the old value becomes the "before" mark on that row.
  Deleting it hides the size of the gain and lets an engineering step
  read as an advance.
- **The class chip set** to advance, engineering, relabelling or
  accounting, by the test in §3 and not by how the change felt to make.
- **The exponent panel and the boundary facts re-derived** whenever a
  fit changes or a phase is priced for the first time.  An exponent on
  the page that predates a new phase measurement is the §5 mistake,
  drawn.
- **The verdict rewritten** when the verdict changes.  The sentence at
  the top of the page is a claim; a round that falsifies it rewrites it
  in the same commit.

Two standing constraints on the page itself: every number on it comes
from the frozen experiment files, so the page cites and never computes;
and anything that is not a measurement stays marked as what it is, an
extrapolation with the exponents it rests on named.

The update rides in the commit or pull request that lands the
measurement.  It is not a follow-up task, and "the page is out of date"
is not a state this repository has.

#### 7a. Every result lands on the dashboard, in the same PR

The scoreboard is a dashboard with several panels that each carry a
view of the latest results, and a result that reaches one panel and not
the others leaves the page contradicting itself.  **Any PR that lands a
new measurement, a reclassification, a corrected reference or a
withdrawn claim updates every panel that cites that kind of result,
before it merges.**  "Latest results" means the newest verified figure
in each regime, with the figure it supersedes kept as "was".

Which panels a result owes, by kind:

| result kind | panels that must change |
|:--|:--|
| any IC/rho ratio, cold or online, elliptic or not | the progress chart (`#lab-progress`): a new point in its series, dated the day the PR merges, with reference quality, class, anchor and source |
| a new best in any regime of the best-of table (`#lab-best`) | that row, the old figure kept as "was"; a new regime is a new row |
| a cross-method `ecbench` session (§12) | the every-candidate panel (`#lab-ecbench-all`) or a new panel in its unit, and a progress-chart point for its best cold one-target IC cell |
| a tournament or autolab round | the round's own panel, the reference-history table where the reference changed, and the chart |
| a boundary, exponent or phase priced for the first time | the exponent panel and the boundary facts (§7 above) |
| a verdict change | the sentence at the top of the page and the best-of table's first row |
| a whole-pipeline measurement on any curve, a newly priced curve or a re-matched reference | the index-calculus leaderboard, regenerated from the round's frozen files (§7b) |

Rules that make this checkable:

- **The chart's data is one file.** `docs/ic/progress-timeline.json` is
  canonical for the progress chart; the copy embedded in the page
  (`<script id="progress-data">`) and the "every plotted point" table
  are regenerated from it, never edited on their own.  CI
  (`scripts/site/test_build.py`) fails the build when the embedded copy
  differs from the file or a point in the file is missing from the
  table.  Add a point to the file, re-embed, add its row.
- **A point per result, not per PR.** A PR that lands two results in two
  regimes adds two points.  A PR that only re-prices an existing figure
  adds a point with the `accounting` class and keeps the old point.
- **Dates are merge dates.** The chart shows when a figure landed on
  `main`, so a point's date is the day its PR merges, and the file's
  `updated` field is never older than its newest point.
- **The page is republished when it changes.** GitHub Pages republishes
  `/scoreboard/` from `main` on every merge, automatically.  Any other
  published copy (a claude.ai artifact, a snapshot sent to someone) is
  republished from the canonical file in the same task that changed it,
  or it is named as stale where it is linked.
- **Reviewing a PR means reading the dashboard diff.** A reviewer, human
  or agent, checks the scoreboard change against the result's own
  frozen files before approving: the number on the page is the number in
  the session, table or report it links to, and nothing on the page is
  computed from another number on the page.

A PR that lands a result without its dashboard update is incomplete, and
the merge authorization in the default workflow above does not cover merging it.

#### 7b. Keep the leaderboard current

`docs/ic-leaderboard.html` is the same evidence curve by curve. For every
curve priced end to end it shows the best recipe, the phase split of `S`,
the ratio to the matched reference and to the floor, every recipe on every
curve, the per-phase exponents, the decomposition oracles, and every curve
the repository names. Its Markdown and data twins are
`docs/ic/LEADERBOARD.md` and `docs/ic/leaderboard.json`. It is held to §7's
and §7a's standard: **a round that changes what the leaderboard shows is not finished
until the leaderboard shows it**, in the same pull request.

- **When.** Update it in the PR that lands any of these:
  - a whole-pipeline measurement: a new ledger section, a new ladder or
    recipe, or a re-run that supersedes a row;
  - a curve priced end to end for the first time;
  - a reference re-matched;
  - a rule change that redefines the primary comparison, as the
    one-target rule did;
  - a change to `docs/curves/registry.json`, which the page's roster reads;
  - a big improvement in a phase or component (an engine, filter, oracle,
    solver or kernel) that moves no whole-pipeline row (owner, 2026-10-15):
    it gets its own section outside tables A–C, generated from the study's
    frozen summary with the before figure kept and its class (usually
    engineering) named, as the linear-algebra engine section was added for
    `research/la_engines_20261014`.
- **How.** The page is generated, never edited by hand.
  - Point `SOURCES` in `scripts/build_ic_leaderboard.py` at the round's
    frozen files.
  - Keep a superseded figure as the row's "before" mark.
  - Keep batch or legacy figures labelled as diagnostics, never as the
    headline.
  - Regenerate with `python3 scripts/build_ic_leaderboard.py` and commit
    all three outputs.
  - The builder reads only committed frozen files, so a number that is
    not in one cannot reach the page.
- **Agree with the scoreboard.** The leaderboard's headline figures must
  match the ledger and the verdict on `docs/index-calculus-scoreboard.html`.
  When they disagree, one of them is stale: fix it in the same PR.
- **Enforced in CI** (`ic-leaderboard`). `--check` fails when any output is
  stale against the files the builder reads. It also fails when the ledger
  has a section later than `LEDGER_COVERED_THROUGH`, because the check
  cannot otherwise see evidence the builder does not read yet.
  - When a new section changes the page, point `SOURCES` at it,
    regenerate, and raise the number.
  - When it changes nothing on the page (a stage diagnostic, a plan),
    confirm that, and raise the number.
- **Published copies** are republishes of the repository file, as in §7.

#### 7c. Keep the lab browser current

`docs/browser/` (published at `/browser/`) is the searchable index over
everything the workstream names: every curve in the ICV1 registry with
its invariants (family, field, trace, order, subgroup order, cofactor,
endomorphism discriminant) and identities (ICV1, EC1, curve UID, retired
names), every `ecbench` method (`ECM1`) and factor base (`FB1`) a
committed session ran, every tournament candidate identity (`IC1`) the
repository writes, every tournament round, every committed `ecbench`
session, the vocabulary of oracles, solvers and factor-base families,
and the **yield ledger**: one row per index-calculus run with its curve,
target, factor base, oracle, solver, trials, relations, yield, lookups,
matrix rank and the record's `solver` block (the ICMS `pdp_metrics`:
system shape, solving degree, Macaulay and SAT figures), which the
`ecbench` database exposes as the `ic_yield` view. It is how a reader
gets from a number on the scoreboard to the curve, algorithm and
evidence behind it, and how a candidate combination is informed: a
yield is a stage diagnostic, and only a whole-pipeline `S` decides speed.

- **Generated, never edited.** `docs/browser/data.json` is written by
  `python3 scripts/build_lab_browser.py` from committed files only (the
  registry, `docs/ic/leaderboard.json`, `research/ecbench_*/sessions/*`,
  the tournament's `runs/`, and the files that mention IC1 identities).
  It computes nothing beyond a mean over a session's own verified runs.
- **Regenerate it in the PR that lands** a new curve in the registry, a
  new `ecbench` session, a new tournament round, a new candidate identity,
  or a leaderboard change. CI (`ic-leaderboard`, `--check`) fails when the
  file is stale, and the site build test fails when a cross-reference in
  it does not resolve. The check ignores how many files mention each
  candidate identity, and which: those counts change with any report that
  writes one and refresh on the next regeneration.
- **Every identity is a link.** A curve page links to the leaderboard
  rows, sessions, factor bases, rounds and candidates that cite it; a
  session, method, factor base or round links back to its curves. A new
  kind of record gets a view and a join, not a free-text mention.
- **The page renders data with DOM nodes only**, never `innerHTML`, like
  the status dashboards; the site test pins that.
- **Unregistered references stay visible.** A tournament cell or
  candidate on a curve the registry does not hold is shown as
  "not in the registry", never dropped or silently mapped; registering
  the curve (§11) is the fix.

### 8. Use the frozen benchmark to establish end-to-end speedups

Every index-calculus performance iteration must use the
[frozen regression suite](research/index_calculus_baseline_20260914/regression/README.md)
before claiming a gain. The accepted target is
`research/index_calculus_baseline_20260914/regression/results/baseline_v2/`.

Every incremental performance change must include a saved baseline/candidate
benchmark comparison, even when it regresses or no gain is claimed. Rerun
the frozen inputs and include fresh holdouts; a candidate-only run does not
complete an iteration. The equivalent-suite exception below still applies.

- **Run the reference and candidate.** Follow the suite's `run.py` and
  `compare.py` commands with the full 60 inputs, both configurations and all
  three repetitions. Preserve the contract, input hashes, counter definitions
  and algebraic-only rejection control. Save each iteration in a new directory;
  never overwrite the baseline. For other encodings or field families, freeze
  an equivalent matched suite under the
  [parent accounting contract](research/index_calculus_baseline_20260914/ec_index_calculus_contract.json)
  and document why the WDSat protocol is inapplicable.
- **Measure the complete ECDLP pipeline.** In addition to that solver regression,
  run matched baseline/candidate full-DLP experiments on identical curves,
  subgroups, factor bases, targets and seeds, including independent holdouts.
  Charge setup/precomputation, target generation, encoding, failed attempts,
  solving, extraction/lifting, verification, filtering, relation-matrix work
  and final scalar recovery, using exclusive accounting. Verify `[k]P = Q`
  for every completed test; retain failures, timeouts and OOMs. Compare equal
  verified workloads; missing completions block an unqualified end-to-end claim.
  Report cold cost first and name the target count for any warm amortization.
- **Require a measured total-cost improvement.** Define
  `speedup = baseline_total_operations / candidate_total_operations`.
  An end-to-end claim requires this ratio greater than one in the same
  calibrated operation unit, with all phases priced and correctness preserved.
  Report `S` and ratios to the matched rho reference and applicable floor.
  Runtime claims additionally require paired baseline/candidate reruns on
  matched hardware/resources and a 95% paired confidence interval excluding
  no improvement; wall time remains secondary.
- **Keep solver gains in scope.** Passing `compare.py`, meeting its optional
  20% conflict target, or reducing Gröbner/F4 time alone does not establish
  an end-to-end speedup. The current corpus measures a solver stage.
  If full-pipeline costs or conversions are missing, leave them null and
  report a stage diagnostic; do not infer a full-DLP result.
- **Commit the evidence with the claim.** Preserve raw runs, source/configuration
  hashes, certificates, phase costs and comparison output, including regressions.
  Update the research note and canonical scoreboard in the same PR, retaining
  the prior baseline and classifying the change by §3.

### 8a. Require m=83 for high-fidelity ECC2K-130 IC evidence

For every index-calculus improvement intended to transfer to ECC2K-130,
**always use m=83 as the highest-fidelity smaller-curve confidence gate**
before claiming that the improvement survives scaling toward m=131. Use the
same Koblitz family as the challenge:
`E_0: y² + xy = x³ + 1` over `GF(2^83)`. Its group order is
`4 * 2417851639230796216685689`, with the second factor prime. A verified
polynomial-basis modulus is `z^83 + z^45 + z² + z + 1`; a different basis
is acceptable only when the field representation and conversions are recorded.
Freeze the exact curve, basis, prime-order subgroup, generator, and cofactor
clearing in each candidate/workload manifest. Frobenius has 83 phases on
nonidentity points in that subgroup, and `ord_83(2) = 82`, so the nontrivial
cyclotomic block is irreducible over `GF(2)`, as for m=131.

- Use smaller degrees, including m=53, for smoke tests, solver tuning, and
  inexpensive falsification. They do not discharge the m=83 gate.
- On m=83, run the unmodified baseline and candidate with matching curve,
  subgroup, factor-base policy, targets, seeds, resource limits, and independent
  holdouts. Preserve failed searches, timeouts, and out-of-memory outcomes.
  Apply the full-cost, verified-DLP, matched-rho, and scoreboard rules above;
  a solver-only or relation-only gain remains a stage diagnostic.
- If the m=83 comparison is missing or incomplete, report that explicitly and
  leave high-fidelity ECC2K-130 improvement unestablished. A successful m=83
  result is evidence at m=83; any transfer to m=131 remains an extrapolation
  until separately checked there.

### 8b. ECC2K-130 is the reference family; disclose subfield structure

User direction, 2026-09-28: the ECC2K-130 binary Koblitz challenge is the
archetype for this workstream. The challenge field is GF(2^131); "130" in
the challenge name is not the field-extension degree. Use smaller members
of the same E_0 family for exploratory evidence, and record the exact field,
curve, subgroup and Frobenius action. A generic binary curve, another
Koblitz model, or an isogenous neighbor is not silently the same instance.

Say **no proper intermediate subfields over GF(2)**, not "no subfields".
GF(2^m) contains GF(2^d) exactly when d divides m. In every case GF(2)
is present.

| Field degree m | Proper intermediate subfields over GF(2) | Evidence role |
| --- | --- | --- |
| 31 | None | Primary exploratory size; disclose its different Frobenius-module structure |
| 51 | GF(2^3), GF(2^17) | Composite-degree comparison; keep subfield-dependent findings separate |
| 53 | None | Additional prime-degree exploratory comparison |
| 83 | None | Required smaller-curve confidence gate under section 8a |
| 131 | None | Exact challenge field; target-specific conclusions require separate evidence |

- Use m=31 as the primary exploratory size when a smaller instance is needed.
  Preserve the m=83 requirement in section 8a. A result at 31, 51 or 53
  does not replace that gate.
- Prime extension degree alone does not guarantee structural fidelity.
  In particular, ord_31(2)=5, whereas ord_53(2)=52, ord_83(2)=82 and
  ord_131(2)=130. Thus the nontrivial cyclotomic block splits at m=31,
  unlike the irreducible block at 53, 83 and 131. State this difference
  whenever an argument uses invariant linear subspaces or that block.
- Label methods that depend on a proper intermediate subfield as such.
  A gain at m=51 that uses its subfields cannot support a claim at
  m=31, 53, 83 or 131 without a separate applicable argument and evidence.
- Distinguish a curve defined over GF(2) from its field of rational points.
  Koblitz coefficients in GF(2) do not place all challenge points in GF(2).
  Absence of an intermediate field does not remove Frobenius or rule out
  every Weil-restriction formulation.
- Keep field degree m, subgroup order r, and polynomial-variable count
  separate in all manifests and reports. Matching bit counts is not
  matching instances.

For the general-algebra follow-up and its current limits, see
[SPARSE_ALGEBRA_FOLLOWUP.md](SPARSE_ALGEBRA_FOLLOWUP.md).

### 9. AWS GPU hosts use the `meow34` key pair

For AWS EC2 benchmark and validation hosts, including G7/G7e instances, use the
existing EC2 key-pair name **`meow34`** when launching the instance.

- Launch with `--key-name meow34` (or the equivalent SDK/IaC setting).
- For local SSH, use the private key file `meow34.pem`, e.g.
  `ssh -i meow34.pem <user>@<host>`.
- Never commit, print, upload, copy into artifacts, or otherwise expose the
  contents of `meow34.pem`. The repository should contain only the key-pair
  name and usage instructions, never the private key material.
- Ensure the local private key is mode `0600` (for example,
  `chmod 600 meow34.pem`) before SSH use.
- Agents must not create a replacement EC2 key pair merely because the private
  key is unavailable in their environment. If `meow34.pem` is not mounted or
  accessible, report that access blocker and continue with non-SSH work where
  possible.

### 9a. Experiments that do not run locally go through `ephemeral`

When an experiment, benchmark or build is to run in the cloud rather than on
the local machine, run it with the ephemeral runner
([`taskq/deploy/ephemeral/`](taskq/deploy/ephemeral/README.md)). Do not
launch EC2 instances by hand for it. `conductor/deploy/aws/launch.py`, in the
Conductor repository, starts the Conductor control plane, not experiments.

```sh
cargo build --release --manifest-path taskq/deploy/ephemeral/cli/Cargo.toml   # once
E=taskq/deploy/ephemeral/cli/target/release/ephemeral   # or the bash CLI: taskq/deploy/ephemeral/ephemeral
$E run --detach --type c7i.4xlarge --ttl 4h -- 'cargo run --release -- ... --out "$EPHEMERAL_OUT"'
$E status last; $E logs -f last; $E fetch last
```

- The two CLIs are interchangeable: same flags, S3 layout and runner, and
  either one can follow, fetch or kill the other's jobs.
- Agents use `--detach` and check back with `status` or `logs -f` at the
  check-in cadence of the default workflow, rather than holding a foreground
  session open on a long job.
- Each job is a paid instance. Start the jobs the request asks for and no
  more. Pick the smallest instance type and `--ttl` that fit, and `kill` any
  `--keep` instance once you are done with it. The runner, the deadline timer
  and the reaper terminate everything else.
- Runners use Session Manager (`ephemeral shell`), not SSH. Section 9 applies
  to hosts launched by hand.
- A result that lands in the repository still follows section 10, the
  `benchmarks/` rule and the research-visuals rule. Its provenance is the
  fetched `job.json`, `host.txt` and `rusage.txt` in
  `~/.cache/ephemeral/runs/<id>/`.

### 10. Performance work starts from a clean, recorded baseline

A speedup is a comparison, so it is only as good as the baseline and the
conditions both sides ran under.  Before changing code for speed:

- **Record the baseline and the host.** Build the unmodified revision and
  keep the binary.  Record the commit, `rustc --version`, the CPU model and
  its relevant features (for example `popcnt`, `avx2`, `avx512*`,
  `pclmulqdq`, NEON/`aes`), the logical core count, memory, OS and
  architecture, and the exact benchmark command and inputs.  A number
  without its host is not a baseline.
- **Pin the output, not just the time.** Every run must show identical
  results and counted units (fingerprints, digests, counters) between
  baseline and candidate.  A faster run that decides anything differently
  is a different algorithm, not a speedup.
- **Isolate every timed run: pin it, reserve its core, and record the
  conditions.  This is mandatory for any wall-clock or native-time number.**
  Run the benchmark through `tools/isolated_bench.py`: `run` for a single
  command it pins itself, `reserve` for a harness that pins its own children
  (such as the tournament evaluator's `--cpu`). The tool does the following:
  - It takes an exclusive lock, so only one benchmark runs at a time.
  - It refuses to start while other processes use CPU or while the CPU or
    memory pressure (PSI) is high.
  - It moves every other movable thread off the benchmark core and pins
    the benchmark there.
  - It records, per run, the context switches, faults, load average, PSI
    and the CPU time everything else used, and it marks a run `contended`
    when others used more than the threshold.

  `taskset` alone is not enough. It keeps the benchmark on one core, but
  it does not keep anything else off that core. It also does nothing about
  builds on the neighbouring cores, which share the cache and the memory
  bus.

  While a timed stage runs, start no builds, test suites, lints, audit
  cells or other agents' jobs on the same machine. Run heavy work through
  `tools/isolated_bench.py busy -- CMD` so that it waits for the lock.

  Instruction counts and the repository's counted units do not depend on
  contention, so they stay the primary metric. Wall time is evidence only
  from uncontended runs. Report how many runs were contended, and do not
  pool contended and uncontended runs.

  A virtual machine's host neighbours and CPU frequency are outside the
  tool's reach. Expect ±5–10% residual wall noise on cloud containers and
  CI runners, and measure it with an A/A run. Fix the thread count
  explicitly (`RAYON_NUM_THREADS=1`), and report the pinned CPUs.
- **Measure the noise floor, then interleave.** Run the baseline against a
  copy of itself (A/A) to see the spread, then alternate baseline and
  candidate (ABAB…, at least five rounds) and report median and minimum.
  A difference inside the A/A spread is not a result.  Where wall time is
  noisy, add a deterministic measure beside it: instruction counts
  (`valgrind --tool=callgrind`) or the repository's counted units.
- **Watch for one-time costs.** Thread-pool start-up, page faults, lazy
  statics and cold caches land on whichever case runs first; do not charge
  them to that case's algorithm.
- **Measure parallel changes at one thread and at many.** A multi-core gain
  must not regress `RAYON_NUM_THREADS=1`, and the core count of the host
  bounds what the result says about any other host.
- **Say which hardware class a result covers.** This code is meant to run
  well on a diverse set of targets: Linux x86-64 (whose baseline target has
  no `popcnt` or AVX2 unless dispatched at runtime), Arm64 (Apple silicon,
  Graviton), GPUs (CUDA; Metal on Apple silicon; see §9 for the AWS hosts)
  and, prospectively, FPGAs.  A result holds for the class it was measured
  on; name it, and name the classes it was not measured on rather than
  implying them.  Use runtime feature detection with a portable fallback
  instead of global `target-cpu` flags, and report a gain on one class that
  costs another per class.
- **Keep the evidence.** The PR states the host manifest, the A/A spread,
  the A/B table with identical-output checks, and the changes that were
  tried and rejected with their numbers.

### 11. Name every curve by its ICV1 slug

A number quoted against the wrong curve is a wrong number, and until this
rule one Koblitz curve went by five spellings, a prime curve by whichever
generator found it, and no name said which modulus or model it meant.
Every elliptic curve is now named by an identity computed from the curve,
specified in [`docs/curves/ICV1.md`](docs/curves/ICV1.md).

- **Write the slug.** In prose, tables, scoreboard rows, report `name`
  fields, parameter and run file names, a curve is its ICV1 slug
  (`icv1-f2m41-tm2308219-7f48b14a`).  A curve a standards body or public
  challenge published may go by that name (`ECC2K-130`, `sect163k1`,
  `secp256k1`, `P-256`).  Family notation with a free parameter is fine
  when a sentence is about the family.
- **Never write a retired form.** The spellings in `ICV1.md`'s table of
  retired names carry no model and may not appear in new text or be
  emitted by new code.  Frozen reports keep them; the registry resolves
  them, and code that replays a report or reads a table keyed the old way
  matches through `curve_id::same_curve`, never by string equality.
- **Register before you cite.** Every slug written must be in
  [`docs/curves/registry.json`](docs/curves/registry.json).  A new curve is
  registered in the pull request that first names it
  (`python3 scripts/build_curve_registry.py`; a curve built from a seed
  also goes in `docs/curves/sources/specs.txt`).
- **Join on EC1, write ICV1.** The slug names a curve *model*.  A
  comparison, UI export or candidate manifest that joins across
  repositories carries the EC1 alias and curve UID of the exact
  representation measured, subgroup and generator included, as the
  cross-repository section below and
  [`docs/curve-identities.md`](docs/curve-identities.md) require.  The
  registry lists each model's EC1 representations.
- **Do not rename evidence.** Frozen run JSON, hash-pinned files and
  anything under a `results/`, `runs/`, `raw/`, `evidence/` or `archives/`
  directory keep the names they were written with.  Prose about them uses
  the slug.

`scripts/check_curve_names.py` enforces this in CI (`curve-names`): no
retired form in Markdown or HTML outside a code fence, every slug
registered, and no retired form on a line a pull request adds to prose or
code.  `--fix` rewrites retired names in place.

### 12. Measure across ECDLP methods with ecbench

New measurements that put ECDLP methods side by side (Pollard rho in its
variants, baby-step giant-step, the kangaroo, index calculus) use the
native harness `ecbench` ([docs/ecbench/README.md](docs/ecbench/README.md)),
so every method is charged in one counted unit, on the same one-target
workloads, under the same isolation, into the same sealed records.

- **Spec, session, audit.** Write an `ecbench.spec/v1`, run it into a new
  directory, and pass `ecbench verify --replay N` before citing a figure;
  the receipt's SHA-256 is the replay certificate.
- **Levels gate wall time, never counts.** Operation counts stand at any
  isolation level; a wall-clock figure needs the spec's level (L2 by
  default) and is read against the session's A/A interval.
- **Sessions are evidence.** Commit them under `research/<topic>_<date>/
  sessions/`; CI re-audits them with replays on another host and never
  lets one be edited.  The SQLite database is an index rebuilt from them.
- **A `vs_rho` claim is one IC run against one strong-rho run on one
  public target.** `ecbench claim build` assembles it from a session with
  `target_kind: public`, names the candidate by the tournament's IC1
  identity, and runs the ledger's checker (`ecbench claim check`, the
  native `boundary_autolab.py claim-check --stage vs_rho`).  It passes
  only with an audit receipt from another host class that replayed both
  runs; without one it fails on that and says so.
- **Skills:** `ecbench-measure`, `ecbench-independent-runner` and
  `ecbench-extend` under `.agents/skills/`.

Historical autolab, tournament and ICMS evidence keeps its own protocols.

### 13. Large files go through the store

A factor base, relation table or raw evidence file too big for Git is pushed
with `crypto store push` (or `ecbench store push`) and referred to by name,
not by a local path or a one-off bucket URL: `store:<name>`, accepted
wherever a path is (`ic --factor-base`, and any code that calls
`crypto_lib::store::resolve_path`). The tracked `store/index.json` is the
manifest the evidence rules ask for: content hash, byte count, location,
and the command that produced the file (`--provenance`). Commit the index
entry in the PR that lands the result. Objects are immutable and keyed by
SHA-256; a name is not repointed without `--replace`, which keeps the old
digest as superseded. Never delete remote objects from an agent session.
See [docs/store/README.md](docs/store/README.md).

### 13a. Raw run trees land as one archive

A round's or study's raw run tree (per-run reports, stderr, isolation records,
logs: everything under its `runs/`) lands as one deterministic `runs.tar.xz`
beside its README, with `runs.tar.xz.sha256` (`sha256sum runs.tar.xz`, so
`sha256sum -c` checks it in place) and a `.gitignore` there holding `/runs/`. The
analysis, figures and claims are made from the extracted tree, and the README
says how to extract and re-check it. Pack it so packing the extracted tree
again gives the same bytes, as
`research/ic_tool_program/rounds/R01-baseline-v0/` does:

```sh
tar --sort=name --mtime='YYYY-MM-DD 00:00:00Z' --owner=0 --group=0 \
    --numeric-owner --mode='u+rwX,go+rX,go-w' --format=gnu -cf - runs \
  | xz -6 -T1 > runs.tar.xz
sha256sum runs.tar.xz > runs.tar.xz.sha256
```

Use the round's start date for `--mtime`. Raw `.jsonl` and logs compress
5-20x, and one file costs a checkout one entry instead of thousands.

**Exception: keep it loose when a path must resolve.** When a claim, replay,
manifest or verifier names individual run records by repository path (the
`report` fields of `research/ic_tool_program/rule/v*/claims/` point into
`runs/`; `verify_archive.py`-style checkers hash files in place), those
records stay committed as loose files. Only the part nothing names goes in the
archive; say in the README which part is which.

This applies to new run trees. Never re-pack, compress or move a committed
tree, or rewrite history to slim one: committed evidence stays as it was
written. A tree too big for Git even compressed goes through the store (§13).
Checkouts that do not need a research tree leave it off disk instead
([docs/sparse-checkout.md](docs/sparse-checkout.md)).

### 14. Experiments to run later go in `backlog/`

An experiment worth running that this session will not run (too big, blocked,
or for another machine) is written as a card in `backlog/<ID>/` and checked
with `backlog validate`; leases and runs go through cairn, and results return
to `research/` by PR. The protocol, including funding as priority, is
[backlog/README.md](backlog/README.md).

### 15. Compare against the fastest external implementations

Owner's rule, 2026-10-16. The goal is for our implementations to be faster
than everything else that computes the same thing. A before/after speedup
against our own previous code (§10) shows progress. It does not show where
we stand. So every performance result also names the fastest external
implementation of the same computation and measures against it.

**Which tools.** Compare against the fastest available implementation, not a
convenient one. As a minimum, for the areas this repository works in:

| computation | compare against |
|:--|:--|
| Gröbner bases (F4, F5, decomposition and summation-polynomial systems) | Magma `GroebnerBasis` (its F4, and its F5 where Magma offers it), msolve, FGb; also Singular (`std`, `slimgb`, `modStd`) and OpenF4 where relevant |
| Sparse or dense linear algebra mod p and over GF(2) | Magma, FLINT, M4RI/M4RIE (GF(2)), and the block Lanczos/Wiedemann solvers of CADO-NFS |
| Polynomial and field arithmetic (products, powers, roots, factoring) | FLINT (`nmod_poly`, `fmpz_mod_poly`, `fq`), NTL, Magma, PARI/GP |
| Point counting (SEA), modular polynomials, isogenies | PARI/GP (`ellcard`, `ellap`), Magma (`#E`, `ClassicalModularPolynomial`, `Isogeny`), Sutherland's `classpoly`/`modpoly` and his published tables, Sage where it calls a faster library |
| Isogeny-based protocols (CSIDH, √élu, SQIsign-style quaternion steps) | the authors' reference and optimised implementations, and published cycle counts on named CPUs |
| ECDLP (rho, kangaroo, index calculus) | the fastest published implementation or record computation for that curve class, with its hardware stated |

If a faster tool exists than the ones listed, use it and add it to this
table.

**How to compare.**

- **Same inputs, same answer.**
  - Run the external tool on exactly the inputs our code runs on, exported
    by a checked-in script. `examples/gb_cas_export.rs` writes msolve,
    Singular and Magma inputs for the Gröbner workloads; add an equivalent
    when a workload has none.
  - Check that the outputs agree: the same reduced basis and order, the same
    group order, the same j-invariants, the same kernel. A faster run that
    computes something different is not comparable.
  - Record the tool's name, version, options, and the algorithm it actually
    ran (for example whether Magma used F4 or F5, or which msolve flags
    were set).
- **Same host, same conditions.**
  - Run both sides on the same machine, with the same isolation as §10 and
    the same thread count. Compare single-threaded with single-threaded and
    many threads with many.
  - Do not time the external tool's start-up, licence check or
    parsing/printing as its algorithm. Use its own internal timer
    (Magma `Cputime`/`Realtime`, msolve `-v`) when it reports one, and say
    which was used.
- **Report the ratio, per size.**
  - Report our time divided by the external tool's time, at each problem
    size, with the A/A spread (or another uncertainty) for both sides. Also
    report how the cost grows with size for both, so a constant-factor win
    at small sizes is not mistaken for a better exponent.
  - Say plainly who is faster, at which sizes, and on which hardware class.
  - "Faster than X" holds only over the sizes and hosts that were measured,
    and only against the fastest configuration of X that was tried. A loss
    at large sizes is reported even when small sizes win.
- **Missing tools are named, not skipped.**
  - If the fastest tool is unavailable (Magma needs a licence; some tools
    run only on other platforms), use the fastest open tool available. msolve
    is the open reference for F4.
  - Cite the missing tool's published timings with their hardware, labelled
    "published, not reproduced".
  - List which comparisons are still missing, and ask the owner for access
    or a host that has the tool instead of quietly dropping the comparison.
  - Never present a comparison against a slower tool as "fastest".
- **A loss is a target.** When an external tool is faster, record the gap,
  as the ratio and the sizes where it holds, in the study and as a
  `backlog/` card (§14) or the next round's goal. A later performance PR on
  the same computation reports the ratio against the external tool before
  and after.
- **Where it lands.**
  - The external comparison goes in the same report and `benchmarks/` entry
    as the speed result, under the rules of "Performance results also land
    in `benchmarks/`".
  - The `benchmarks/README.md` row gives the ratio against the fastest
    external tool next to the before/after ratio, or says "external
    comparison: not run" with the reason.
  - Keep the export and run scripts in the repository. Do not commit
    proprietary binaries, or output that the tool's licence forbids
    redistributing.

## Worked example

`research/notes/index-calculus/RESEARCH_RESIDUAL_WALKS.md` is the reference implementation of this
rule, end to end: §9.6 states the boundary and the target, §9.7 freezes
the baseline table, §10.6 classifies every lever tried against the
floor, §11.5 and §11.6 are an engineering ledger with the class of each
step named, and §11.7 prices the phase the earlier rounds had skipped
and corrects the conclusion they implied.  Its bottom line is a
negative result stated in numbers: on `E(F_{p³})` at the sizes that fit,
rho costs `S ≈ 1.3` and every index-calculus variant built costs
between `528×` and `4,000×` that, with the asymptotically better variant
crossing rho only past `2^{230}`.

`docs/index-calculus-scoreboard.html` is the same ledger drawn, and
the reference for what §7 asks of a round: the boundaries as the axis
and the reference line, the `C₃` steps with their classes, the fitted
exponents against rho's one half, and the extrapolated crossovers
marked as extrapolations.

That is what a finished thread looks like when the answer is no.

## Cross-repository curve identity in comparisons

For new curve comparisons and UI exports, follow [docs/curve-identities.md](docs/curve-identities.md)
and `tools/curve_identity.py`. Reuse EC1 aliases and full curve UIDs across IC and
Pollard rho; keep factor-base/isogeny candidate identities separate. Preserve
immutable historical names and never infer exact identity from field degree alone.
Within this repository the text name is the ICV1 slug (§11); the curve
registry, [docs/curves/registry.json](docs/curves/registry.json), maps each
slug to the EC1 identities of its recorded representations.
The [IC curve crosswalk](docs/curves/ic/README.md) mirrors cryptanalysis's
exact curve records and links them to ICV1 only when the model match is
established.
The [typed curve-link rules](docs/curves/ic/curve-links/README.md) keep
twists and field/model changes separate from verified isogeny routes; no
base-field log transport is inferred from a shared j-invariant. Keep unknown traits and unsupported models as `null` with status.
Large factor bases remain content-addressed archives, while the browser's
FB1 entries are session summaries; link them only after exact curve and
point-set identities, encoding and quotient rules agree. An isogenous curve
has its own EC1/UID and an ordered, verified map route before `ISO1` is used.
Run `python3 docs/curves/ic/validate_semantics.py` after changing the IC curve
crosswalk or typed links. The `ic-semantic-metadata` CI job also compares the
three mirrored files with cryptanalysis `main`; land source changes there
first, then update this mirror and its `mirror-lock.json` in a paired PR.
To enumerate a prime-field curve's isogeny class, use the native walker
`src/bin/isogeny_walk.rs` ([docs/curves/ic/README.md](docs/curves/ic/README.md#walking-an-isogeny-class)):
it emits these records and kernel-certified `IW1` routes, and `isogeny_walk
verify` replays them.
The user guide, including S3 storage, is
[docs/isogeny-walk/README.md](docs/isogeny-walk/README.md).

# Agent rules for IC measurements

## Primary comparison uses one target

The default elliptic-curve index-calculus (IC) question is the cost to solve
one previously unseen public target. Every primary comparison run must use
exactly one target and pair IC with Pollard rho on that same point under the
same resource envelope. A panel of independent points is a set of separate
one-target workloads, with one result row per point; do not combine them into
a multi-target DLP run or replace the per-target results with a batch average.

Start the IC online clock when target-dependent computation begins, after
reusable target-independent base, index, relation-log, or solver setup is
ready. Include all target-dependent attempts and point-query generation, and
stop after scalar recovery and independent verification. Report reusable
setup separately. Exclude process launch, input loading, and construction of a
known-answer target from both IC and rho online intervals. Start rho timing at
its first target-dependent walk and stop after recovery and independent
verification. If scalar replay is outside either interval, report its cost
separately and keep the correctness check.

Do not use multi-target rho batches, cross-target distinguished-point tables,
batch throughput divided by target count, or shared-collision work as the
one-target rho reference. Multi-target work needs a separate, explicit
research question after the one-target measurement; it cannot be the default,
headline, or acceptance gate for a speedup claim. Preserve old batch results
as historical diagnostics and label their target count and shared setup.

An IC-vs-rho speedup is eligible only when both methods solve and verify the
same point and both online intervals are complete. Report
`rho_online_ms / ic_online_ms`, target identity, candidate and workload
identity, included phases, resource conditions, and correctness evidence.
Timeouts, failures, OOMs, and unverified scalars stay in the record and never
count as wins. Missing phase costs make the total and speedup unknown. Key result rows by
`(candidate_id, workload_id, run_id)`, preserve their manifest hashes, and
use the canonical run-id convention from the repository's IC measurement
rules. Keep the five exclusive IC online phase costs; their sum must equal the
charged IC online wall time. Each claim must retain independent replay
certificate SHA-256 digests and the exact nonempty resource-envelope object for
both arms; the claim checker requires those envelopes to match and rejects a
bare boolean verification or resource-match assertion. The IC interval must
name all five target-dependent phases, and rho must name walk, collision, and
recovery check.

The current `boundary_autolab.py` producer timing is whole-process or
operation-counted. Treat those outputs as legacy diagnostics until producers
emit the online intervals above; they cannot establish the primary speedup.
Its launch interface now permits one target per run only.

<!-- conductor:begin -->
Before making code changes, obtain or attach to a Conductor task. Run
`conductor check --summary "…" --scope path:…` first — if someone already holds
those files, it will tell you who and what to do about it. Read `.conductor/WORKFLOW.md`
and the active task card. Report scope expansion before editing outside the reserved paths.
Do not publish chat transcripts or secrets as task metadata.
<!-- conductor:end -->

