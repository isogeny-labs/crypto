set -euo pipefail
manifest=research/factor_base_chart_complements_20261019/screen/Cargo.toml
cargo fmt --manifest-path "$manifest" -- --check
cargo test --locked --release --manifest-path "$manifest"
cargo clippy --locked --release --manifest-path "$manifest" --all-targets -- -D warnings
cargo build --locked --release --manifest-path "$manifest"
