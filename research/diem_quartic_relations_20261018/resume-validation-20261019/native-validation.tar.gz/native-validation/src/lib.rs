pub mod hash { pub mod sha256; }
pub mod cryptanalysis { pub mod diem_quartic; }
