#!/usr/bin/env python3
"""Compare raw upstream output with prior arithmetic and necessary conditions.

This does not modify upstream output or upstream source.
"""
import json
from pathlib import Path
from collections import Counter

ROOT=Path(__file__).resolve().parent
prior=json.loads((ROOT.parent/'dissection/results.json').read_text())
by_id={c['id']:c for c in prior['curves']}
native=json.loads((ROOT/'run/results.json').read_text())
checks=[]
issues=[]
partial=[]
nulls=[]


def check(row,field,expected,observed):
    item={'curve':row['curve'],'trait':row['trait'],'params':row['params'],
          'field':field,'expected':expected,'observed':observed,
          'matches':expected==observed}
    checks.append(item)
    if not item['matches']:
        issues.append(item)


def extension_card_mod(p,t,degree,modulus):
    a,b=2,t%modulus
    if degree==0:
        trace=a
    elif degree==1:
        trace=b
    else:
        for _ in range(2,degree+1):
            a,b=b,(t*b-p*a)%modulus
        trace=b
    return (pow(p,degree,modulus)+1-trace)%modulus


for r in native['data']:
    if r['status']!='complete':
        continue
    result=r['result']
    c=by_id[r['curve']]
    p,n=(int(c[k],16) for k in ['p','n'])
    trait=r['trait']
    params=r['params']
    if 'timed out' in json.dumps(result).lower():
        partial.append({'curve':r['curve'],'trait':trait,'params':params})
    if result is None or isinstance(result,dict) and all(v is None for v in result.values()):
        nulls.append({'curve':r['curve'],'trait':trait,'params':params})
    if trait=='embedding':
        check(r,'embedding_degree_complement',(n-1)//c['n_minus_1_analysis']['embedding_degree'],result['embedding_degree_complement'])
    elif trait=='isogeny_neighbors':
        check(r,'len',c['small_isogeny_neighbor_counts'][str(params['l'])],result['len'])
    elif trait in ['torsion_extension','isogeny_extension']:
        expected=c['extension_traits'][str(params['l'])][trait]
        for field,value in expected.items():
            check(r,field,value,result[field])
        if trait=='torsion_extension' and result['full'] is not None:
            ell=params['l']
            card_mod=extension_card_mod(p,c['t'],result['full'],ell)
            if card_mod!=0:
                issues.append({'curve':r['curve'],'trait':trait,'params':params,
                               'necessary_condition_failure':True,
                               'claimed_full_torsion_extension':result['full'],
                               'cardinality_at_that_extension_mod_l':card_mod,
                               'explanation':'The claimed extension has no nonidentity l-torsion at all.'})
    elif trait=='discriminant' and isinstance(result.get('cm_disc'),int):
        check(r,'cm_disc',c['frob_disc_analysis']['CM_field_discriminant'],result['cm_disc'])
        check(r,'max_conductor',c['frob_disc_analysis']['frobenius_order_conductor'],result['max_conductor'])
    elif trait=='twist_order' and params['deg']==1:
        check(r,'twist_cardinality',c['twist_order'],result['twist_cardinality'])
        if isinstance(result['factorization'],list):
            check(r,'factorization',sorted(q for q,e in c['twist_analysis']['factors'] for _ in range(e)),sorted(result['factorization']))
    elif trait=='trace_factorization':
        degree=params['deg']
        expected=c['t'] if degree==1 else c['t']*c['t']-2*p
        check(r,'trace',expected,result['trace'])

out={
    'raw_upstream_results_unchanged':True,
    'statuses':dict(Counter(r['status'] for r in native['data'])),
    'returned_timeout_cases':partial,
    'null_result_cases':nulls,
    'comparison_checks':len(checks),
    'matching_checks':sum(c['matches'] for c in checks),
    'issues':issues,
    'source_findings':[
        {'trait':'torsion_extension','file':'dissect/traits/torsion_extension.py',
         'finding':'In the repeated-eigenvalue non-scalar case, k2 is set to l rather than multiplied by l. Raw output can claim full torsion over a field containing no nonidentity l-torsion.'},
        {'trait':'trace_factorization','file':'dissect/traits/trace_factorization.py',
         'finding':'The trait factors the extension trace but returns curve.trace(), the base-field trace, in the trace field.'},
    ],
}
(ROOT/'audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['issues','null_result_cases','returned_timeout_cases']},indent=2))
print('Returned timeout cases:',len(partial))
print('Null result cases:',len(nulls))
print('Issue records:',len(issues))
