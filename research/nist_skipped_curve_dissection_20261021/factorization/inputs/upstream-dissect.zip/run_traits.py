#!/usr/bin/env python3
"""Execute unmodified upstream DiSSECT traits under Sage, with case limits.

The process wrapper records each default curve/trait/parameter combination
and isolates only execution and wall-time limits; it does not implement or
replace any DiSSECT mathematical trait.
"""

import argparse
from collections import Counter
import hashlib
import importlib.metadata
import json
import multiprocessing as mp
import os
from pathlib import Path
import signal
import sys
import time
import traceback

from sage.all import version
from dissect.traits import TRAITS
from dissect.utils.custom_curve import CustomCurve
from dissect.utils.database_handler import _cast_sage_types


def key(curve,trait,params):
    src=json.dumps([curve,trait,params],sort_keys=True).encode()
    return hashlib.sha256(src).hexdigest()[:20]


def encode(obj):
    return json.loads(json.dumps(_cast_sage_types(obj),default=str))


def execute(task,curve,out):
    os.setsid()
    start=time.monotonic()
    logfile=out/(task['id']+'.log')
    with logfile.open('w',buffering=1) as log:
        os.dup2(log.fileno(),1)
        os.dup2(log.fileno(),2)
        record=dict(task)
        try:
            result=TRAITS[task['trait']](curve,**task['params'])
            record.update(status='complete',result=encode(result),sage_repr=repr(result))
        except BaseException as exc:
            record.update(status='error',error_type=type(exc).__name__,
                          error=str(exc),traceback=traceback.format_exc())
            traceback.print_exc()
        record['elapsed_seconds']=round(time.monotonic()-start,3)
        (out/(task['id']+'.json')).write_text(json.dumps(record,indent=2)+'\n')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--commit',required=True)
    ap.add_argument('--workers',type=int,default=6)
    ap.add_argument('--timeout',type=int,default=180)
    ap.add_argument('--hamming-timeout',type=int,default=300)
    ap.add_argument('--cli-seed',type=Path)
    args=ap.parse_args()
    args.output.mkdir(exist_ok=True,parents=True)
    cases=args.output/'cases'
    cases.mkdir(exist_ok=True)
    raw=json.loads(args.input.read_text())
    raw=raw if isinstance(raw,list) else raw['curves']
    assert all('properties' not in r for r in raw), 'Use raw inputs without precomputed trait results'
    curves={c['name']:CustomCurve(c) for c in raw}
    # Run the expensive traits after the requested algebraic traits.
    preferred=['weierstrass','cofactor','x962_invariant','discriminant',
               'embedding','isogeny_neighbors','volcano','division_polynomials',
               'isogeny_extension','torsion_extension','class_number','twist_order',
               'trace_factorization','small_prime_order','pow_distance',
               'brainpool_overlap','multiples_x','q_torsion','conductor',
               'square_4p1','kn_factorization','hamming_x']
    assert set(preferred)==set(TRAITS)
    tasks=[]
    for trait in preferred:
        for params in TRAITS[trait].params_iter():
            for name in curves:
                tasks.append({'id':key(name,trait,params),'curve':name,'trait':trait,
                              'params':params,'source':'upstream DiSSECT trait'})
    if args.cli_seed and args.cli_seed.exists():
        for r in json.loads(args.cli_seed.read_text())['data']:
            record={'id':key(r['curve'],'isogeny_neighbors',r['params']),
                    'curve':r['curve'],'trait':'isogeny_neighbors','params':r['params'],
                    'status':'complete','result':r['result'],
                    'source':'upstream dissect.utils.compute_json CLI'}
            (cases/(record['id']+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    manifest={
        'source_repository':'https://github.com/crocs-muni/DiSSECT',
        'source_commit':args.commit,'sage_version':version(),
        'python_version':sys.version,'traits':list(TRAITS),
        'curve_count':len(curves),'planned_case_count':len(tasks),
        'input_precomputed_properties':False,
        'skipped_historical_generators_unknown':True,
        'case_wall_time_seconds':args.timeout,
        'hamming_case_wall_time_seconds':args.hamming_timeout,
        'traits_source_file':str(Path(sys.modules['dissect.traits'].__file__).resolve()),
    }
    (args.output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest),flush=True)
    pending=[]
    for task in tasks:
        path=cases/(task['id']+'.json')
        if not path.exists():
            pending.append(task)
    active={}
    context=mp.get_context('fork')
    finished=len(tasks)-len(pending)
    last_update=time.monotonic()
    while pending or active:
        while pending and len(active)<args.workers:
            task=pending.pop(0)
            process=context.Process(target=execute,args=(task,curves[task['curve']],cases))
            process.start()
            active[process.pid]=(process,task,time.monotonic())
        for pid,(process,task,start) in list(active.items()):
            limit=args.hamming_timeout if task['trait']=='hamming_x' else args.timeout
            timed_out=time.monotonic()-start>limit
            if process.is_alive() and not timed_out:
                continue
            if timed_out:
                try:
                    os.killpg(pid,signal.SIGKILL)
                except ProcessLookupError:
                    pass
            process.join(timeout=1)
            path=cases/(task['id']+'.json')
            if not path.exists():
                record=dict(task,status='timeout' if timed_out else 'crashed',
                            elapsed_seconds=round(time.monotonic()-start,3),
                            exitcode=process.exitcode)
                path.write_text(json.dumps(record,indent=2)+'\n')
            record=json.loads(path.read_text())
            if record['status']!='complete':
                print('CASE',record['status'],task['curve'],task['trait'],task['params'],flush=True)
            del active[pid]
            finished+=1
        if time.monotonic()-last_update>10:
            print(f'Progress: {finished}/{len(tasks)} cases; active: '+
                  ', '.join(t['trait']+':'+t['curve'] for p,t,s in active.values()),flush=True)
            last_update=time.monotonic()
        time.sleep(0.1)
    results=[json.loads((cases/(t['id']+'.json')).read_text()) for t in tasks]
    summary={'statuses':dict(Counter(r['status'] for r in results)),'by_trait':{}}
    for trait in preferred:
        rows=[r for r in results if r['trait']==trait]
        summary['by_trait'][trait]=dict(Counter(r['status'] for r in rows))
    (args.output/'results.json').write_text(json.dumps({'manifest':manifest,'data':results},indent=2)+'\n')
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print('FINISHED',json.dumps(summary),flush=True)


if __name__=='__main__':
    main()
