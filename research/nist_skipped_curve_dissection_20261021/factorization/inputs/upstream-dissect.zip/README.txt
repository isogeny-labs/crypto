ACTUAL UPSTREAM DISSECT RUN

Source: https://github.com/crocs-muni/DiSSECT
Commit: 8edc3030fb91411a55aa6c07d050507d840c5e55
Runtime: SageMath version 9.8, Release Date: 2023-02-11, Python 3.11.1
Image: sagemath/sagemath@sha256:1dca662086a58ea620c54af578ee1d2ee5d0dbad01efed442a58ebf99c09fea9
Upstream mathematical source was not modified.

Six input curves: four recovered skipped candidates and published P-224/P-256.
Inputs contain no precomputed trait properties. Published control generators
were obtained from OpenSSL and checked. Historical generators for skipped
curves remain unknown and were omitted.

The upstream CLI was executed as:
  sage -python -m dissect.utils.compute_json -t isogeny_neighbors -i curves.json -o cli_isogeny_neighbors.json
It produced 18 records. The remaining default cases were executed using the
actual upstream TRAITS and CustomCurve classes by run_traits.py. The wrapper
adds process isolation, per-case wall-time limits, serialization, and logging.
No outer wall-time limit was reached.

22 traits, 438 default curve/trait/parameter cases returned.
10 cases returned partial factorization timeout messages.
40 multiples_x cases return nulls because original skipped generators are unknown.
The default class_number trait computes bounds, not exact class numbers.

Files:
  run/results.json: all raw upstream results
  run/cases/: individual results and captured logs
  run/manifest.json: source/runtime and execution metadata
  run/summary.json: upstream-call status counts
  cli_isogeny_neighbors.json: output of the actual upstream CLI
  audit.json: comparison with prior arithmetic, including upstream defects
  source/: exact tracked repository source used in this run

Audit: 330 fields checked against the prior arithmetic or exact recurrences;
308 matched, and 22 discrepancies were found in two upstream traits.
Eight torsion_extension cases have an incorrect full extension degree and
relative degree in the repeated-eigenvalue branch. In those cases the claimed
full-torsion extension has no nonidentity l-torsion at all, as checked by the
point-count recurrence modulo l. The source sets k2=l instead of k2*=l.
Six trace_factorization cases (degree 2) return the base trace in the trace
field while factoring the extension trace. Raw output is preserved.

Reproduce with SageMath and this source on PYTHONPATH. The CLI additionally
imports pymongo; versions used were pymongo 4.6.3 and dnspython 2.6.1.
Run the CLI above, then:
  sage -python run_traits.py --input curves.json --output run --commit 8edc3030fb91411a55aa6c07d050507d840c5e55 --workers 4 --cli-seed cli_isogeny_neighbors.json

This is execution of DiSSECT traits, not a statistical outlier analysis against
a large population of simulated curves.
