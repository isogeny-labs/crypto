# Native implementation review

2026-10-21 UTC: review found that `Solver::add_clause` immediately assigns
units and simplifies later clauses against those assignments. Emitting
shared-root units before the phase multiplexer would also simplify that
multiplexer, beyond the frozen replacement. The implementation now emits
the shared units after all domain CNF/XOR construction. Allocation and
phase clauses remain unchanged; the exact preflight formula therefore
counts only the requested root-implication replacement. Exhaustive domain
and actual-construction count tests cover this boundary.

The first library build was already compiling the earlier source. Its
log is retained separately; final validation must use the corrected source.
Conductor's configured local endpoint refused connections on this
continuation. The original task reserved the source/study paths; the
additional N83 CI workflow scope check was attempted and failed with the
same service-access error.
