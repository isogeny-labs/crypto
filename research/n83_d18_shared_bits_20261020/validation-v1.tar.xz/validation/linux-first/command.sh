#!/bin/bash
set -eu
source=/var/tmp/n83-shared-bits-source
logs=/home/ec2-user/n83-m23-20261019/shared-root-build-398abd50d
mkdir "$logs"
cd "$source"
test "$(git rev-parse HEAD)" = 398abd50d32b3a1929ca7d8c38215b7022886afe
test -z "$(git status --porcelain)"
test -z "$(sudo -n docker ps -q)"
git rev-parse HEAD > "$logs/source-commit.txt"
git status --porcelain > "$logs/source-status.txt"
sha256sum /var/tmp/n83-shared-bits-source-398abd50d.pack > "$logs/source-pack.sha256"
{ date -u +%FT%TZ; uname -a; rustc --version; cargo --version; lscpu; } > "$logs/host.txt"
ps -eo pid,ppid,etime,pcpu,comm > "$logs/host-processes.txt"
export CARGO_TARGET_DIR=/home/ec2-user/n83-m23-20261019/target-small-m4
export CARGO_BUILD_JOBS=2
export TMPDIR=/var/tmp
run_check() {
    local label=$1 result=0
    shift
    printf '%q ' "$@" > "$logs/$label-command.txt"
    printf '\n' >> "$logs/$label-command.txt"
    "$@" > "$logs/$label.log" 2>&1 || result=$?
    printf '%s\n' "$result" > "$logs/$label-exit.txt"
    test "$result" = 0
}
run_check lib cargo test --release --lib
run_check tests cargo test --release --example n83_d18_shared_bits --example n83_prebuild_cost_m23 --example n83_small_m4_replay --example n83_full_m4_audit --example n83_xor_cache_audit --example n83_full_m4_card_check --example n83_prebuild_reuse_accounting
run_check build cargo build --release --example n83_d18_shared_bits --example n83_prebuild_cost_m23 --example n83_small_m4_replay
sha256sum "$CARGO_TARGET_DIR/release/examples/n83_d18_shared_bits" "$CARGO_TARGET_DIR/release/examples/n83_prebuild_cost_m23" "$CARGO_TARGET_DIR/release/examples/n83_small_m4_replay" > "$logs/binaries.sha256"
date -u +%FT%TZ > "$logs/completed.utc"
printf '%s\n' COMPLETE > "$logs/status.txt"
