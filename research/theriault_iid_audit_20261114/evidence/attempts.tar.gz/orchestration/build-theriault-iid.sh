#!/usr/bin/env bash
set -u
target=$1
attempt=$2
project=/workspace/crypto-audit/research/theriault_iid_audit_20261114/lean
record=/workspace/scratch/theriault-iid-attempts/$target-$attempt
mkdir -p "$record"
cd "$project" || exit 1
cp -- *.lean lakefile.toml lake-manifest.json lean-toolchain "$record/"
lake build "$target" > "/workspace/scratch/theriault-iid-$target-build$attempt.log" 2>&1
result=$?
printf '%s\n' "$result" > "/workspace/scratch/theriault-iid-$target-build$attempt.exit"
tail -n 65 "/workspace/scratch/theriault-iid-$target-build$attempt.log"
exit "$result"
