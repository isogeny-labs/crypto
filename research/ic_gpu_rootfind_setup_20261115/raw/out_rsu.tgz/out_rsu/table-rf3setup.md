| session | arm | method | curve | log2 r | verified | mean S | 95% interval | theory S | S / theory | S / floor | S / reference | lower bound | med wall ms | levels | flags |
|---|---|---|---|---:|---:|---:|---|---:|---:|---:|---:|---|---:|---|---|
| ECBS1hbd69b299e3b6 | rho-neg | rho.negation | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 0.743 | [0.288, 1.918] indicative | 0.886 | 0.839 | 0.839 | 1.000 | yes | 35.927 | L0×6 | – |
| ECBS1hbd69b299e3b6 | rho-neg | rho.negation | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 0.827 | [0.741, 0.924] indicative | 0.886 | 0.934 | 0.934 | 1.000 | yes | 81.613 | L0×6 | – |
| ECBS1hbd69b299e3b6 | rf3-cpu-echelon-F2048 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 289.912 | [274.306, 306.405] indicative | – | – | 327.130 | 389.949 | yes | 4291.448 | L0×6 | – |
| ECBS1hbd69b299e3b6 | rf3-cpu-echelon-F2048 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 566.351 | [546.571, 586.847] indicative | – | – | 639.059 | 684.515 | yes | 15853.475 | L0×6 | – |
| ECBS1hbd69b299e3b6 | rf3-gpup-echelon-F2048 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 289.912 | [274.306, 306.405] indicative | – | – | 327.130 | 389.949 | yes | 116.085 | L0×6 | – |
| ECBS1hbd69b299e3b6 | rf3-gpup-echelon-F2048 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 566.351 | [546.571, 586.847] indicative | – | – | 639.059 | 684.515 | yes | 222.715 | L0×6 | – |
| ECBS1hbd69b299e3b6 | rf3-cpu-echelon-F4096 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 163.807 | [156.937, 170.978] indicative | – | – | 184.836 | 220.330 | yes | 5491.943 | L0×6 | – |
| ECBS1hbd69b299e3b6 | rf3-cpu-echelon-F4096 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 291.058 | [289.175, 292.952] indicative | – | – | 328.423 | 351.784 | yes | 15974.524 | L0×6 | – |
| ECBS1hbd69b299e3b6 | rf3-gpup-echelon-F4096 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 163.807 | [156.937, 170.978] indicative | – | – | 184.836 | 220.330 | yes | 259.361 | L0×6 | – |
| ECBS1hbd69b299e3b6 | rf3-gpup-echelon-F4096 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 291.058 | [289.175, 292.952] indicative | – | – | 328.423 | 351.784 | yes | 293.244 | L0×6 | – |
| ECBS1hbd69b299e3b6 | rf3-gpup-echelon-aa-F4096 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 163.807 | [156.937, 170.978] indicative | – | – | 184.836 | 220.330 | yes | 251.458 | L0×6 | – |
| ECBS1hbd69b299e3b6 | rf3-gpup-echelon-aa-F4096 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 291.058 | [289.175, 292.952] indicative | – | – | 328.423 | 351.784 | yes | 283.692 | L0×6 | – |
| ECBS1hbd69b299e3b6 | rho-neg-aa | rho.negation | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 0.743 | [0.288, 1.918] indicative | 0.886 | 0.839 | 0.839 | 1.000 | yes | 36.038 | L0×6 | – |
| ECBS1hbd69b299e3b6 | rho-neg-aa | rho.negation | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 0.827 | [0.741, 0.924] indicative | 0.886 | 0.934 | 0.934 | 1.000 | yes | 81.537 | L0×6 | – |
