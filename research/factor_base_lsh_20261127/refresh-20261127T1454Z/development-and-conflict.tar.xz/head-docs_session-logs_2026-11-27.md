# Session log 2026-11-27

## 2026-11-27T03:55Z — Bit-sampling factor-base candidate index (Codex, draft PR #5264)

### What was done

- Fetched Crypto main `c0a238743cf9afed77688a39cc1c33bfc135053f`, made `codex/factor-base-lsh-20261127`, committed and pushed the ACTIVE-only entry, then opened draft PR #5264 before implementation. The PR number was added to ACTIVE in the next change.
- Reviewed the exact `FactorBase` inverse-hash enumeration, `PairTable` full-point membership, selector-order complement search, and `solve_joint` relation collection. The additive equation already has an exact `Q=R-P` lookup; coordinate Hamming proximity offers no established relation-yield signal. The implementation is an opt-in bit-sampling bucket index for that exact lookup, with full point equality inside the bucket, original membership/sum replay, and separate public position seed. [pcc:unverified]
- Source checked (KB): `scripts/research-kb status` returned `no executable found`; no KB MCP tool is present. Primary literature: Indyk and Motwani, *Approximate Nearest Neighbors: Towards Removing the Curse of Dimensionality*, STOC 1998 (https://graphics.stanford.edu/courses/cs468-06-fall/Papers/06%20indyk%20motwani%20-%20stoc98.pdf), for coordinate Hamming bit sampling. Repository sources: `crates/hashed-ecdl-tensor/src/{reduction,prepared}.rs` and `PREPARED_PAIRS.md` for the exact group and factor-base contract. `conductor` was absent; no lane reservation is claimed.
- Native bytes: `factor_base_lsh.rs` SHA-256 `f242386395568ccccd81bbf91f7089b217d236850f01327ee80f3eccdce0974d`; `prepared.rs` `ecf81da1da6bb2c80e5095752e797d612e0e375ba9749e5d808632c5c2fbe166`; new test `ae845e154b1060f88411fe31e1e27377747401dbd55bfa3f52b2e3acbbfd60c5`; `PREPARED_PAIRS.md` `0193864d5e44cea2628528447e4a4164fd98894dd9955ef2fea861f5c39c5782`. These four file bodies are equal to the mirror draft #1998. [pcc:unverified]
- Rust 1.78 locked release all-target tests passed, including 193 library tests and the three new factor-base LSH integration tests; zero observed failures. The new tests exhaust all 19 public F17 target points across three base-threshold policies, three projection widths, three public seeds, and both selector policies, then compare full seeded relation certificates and final label RNG state. Changed-file rustfmt passed. All-target strict Clippy first found six diagnostics in unchanged `census.rs`, contraction controls and `panel_driver.rs`; a rerun allowing only those four inherited lint classes passed with no new-path diagnostics. [pcc:unverified]

### Decisions made

- Keep the default exact `HashSet` route and the CLI unchanged. `PairTable::enable_lsh` and `prepared::solve_joint_lsh` expose the alternate lookup to explicit callers. A bucket is never accepted as a relation or as proof of factor-base membership; exact equality and arithmetic replay remain authoritative.
- Treat this as a candidate-index control, not an index-calculus breakthrough or runtime gain. It adds O(B) index storage and still computes one complement per scanned first-slot point. A frozen matched cold/online comparison would be required to assess usefulness. [pcc:unverified]

### Open threads

- Push exact source and inspect current-head applicable CI, reviews and protection. Keep auto-merge off while failures or checks remain. No scientific run or challenge-scalar claim was made.

### Errors

- The task-local Rustup initially had no default toolchain; explicit Rust 1.78 environment variables fixed invocation. `scripts/research-kb` has no executable in this runtime. No source or gate was weakened for either issue.

## 2026-11-27T04:03Z — Hosted formatting correction and exact-source recheck

### What was done

- Mirror native job `140302874543` ([run 45937149985](https://github.com/isogeny-labs/cryptanalysis/actions/runs/45937149985/job/140302874543)) failed `cargo fmt --all --check` because `mod factor_base_lsh` followed `pub mod factoring`. The source-controlled failure is one line of declaration order; full decoded job log SHA-256 `c11d8beb7fbb4989ea2df747fac2a76b997c7778749b0d43e23e8076c1a1e2f3` is retained locally at `/workspace/scratch/factor-base-lsh-mirror-format-failure-140302874543.log` with the provider job URL above. [pcc:unverified]
- Moved the module declaration before `factoring` in both crates, without changing the LSH module, prepared solver, test or documentation bytes. Final Crypto `lib.rs` SHA-256 `ddb3802d6d76f165aea4fab41ff68cc5b8cf30d2edb604fa933c9fa0c1891286`. Rust 1.78 locked release all-target tests and scoped strict all-target Clippy passed again on this exact source. Direct `rustfmt --config skip_children=true --check` passed for `lib.rs`; the broad root-format traversal still reports unrelated unchanged files. Mirror full crate `cargo fmt --all --check` passed on its corrected source. [pcc:unverified]

### Decisions made

- Push the ordinary format fix and inspect new-head hosted CI; do not infer a hosted pass from local checks. Auto-merge remains off while current applicable checks are unresolved.

### Open threads

- Current-head CI, blocking reviews and source parity after push. The performance question remains unmeasured.

### Errors

- The first hosted mirror format check exposed an ordering error caused by this PR; it was corrected in both repos. No formatting policy or unrelated file was changed.
- The official pre-push script initially blocked the CI-only correction because it compares the entire branch with main and sees the journal originally added while draft. The PR was returned to draft while the fix was in progress; the unchanged official gate then passed. It will be marked ready again after the corrective push, with no check bypass.
