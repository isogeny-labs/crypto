import subprocess,re,collections,hashlib,json,sys
from pathlib import Path
ROOT='/workspace/crypto-point-tables';J='docs/session-logs/2026-11-15.md'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def clean(s):return re.sub(r'(?m)^(?:<<<<<<< .*|=======|>>>>>>> .*)\r?\n?', '',s)
def blocks(s):
 parts=re.split(r'(?m)(?=^## )',clean(s));return [p.strip('\r\n') for p in parts if p.strip('\r\n')]
def counter(sha):return collections.Counter(blocks(git('show',sha+':'+J).decode()))
merges=['683647fbb2c9d21bf8a87161d7e9d4b0f3ffe23f','df51dae962162e22f56bd1aaa0c296237517e16e','149d208dd9019adcccc85a8e82c3f9d89c38971f']
out=[]
for sha in merges:
 parents=git('show','-s','--format=%P',sha).decode().strip().split();c=counter(sha);req=counter(parents[0])|counter(parents[1]);missing=req-c
 row={'merge':sha,'parents':parents,'actual_blocks':sum(c.values()),'required_parent_blocks':sum(req.values()),'missing_count':sum(missing.values()),'missing':[{'heading':s.splitlines()[0][:130],'sha256':hashlib.sha256(s.encode()).hexdigest(),'count':n} for s,n in missing.items()]}
 out.append(row);print(json.dumps({**row,'missing':row['missing'][:15]}))
Path('/workspace/scratch/point-table-tracking-20261115T2247Z/automated-journal-audit.initial.json').write_text(json.dumps(out,indent=2)+'\n')
