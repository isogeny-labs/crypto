"""Retain complete normalized journal blocks, multiplicities and parent order."""
import argparse,collections,datetime,hashlib,heapq,json,re,subprocess
from pathlib import Path

def clean(s):
    return re.sub(r'(?m)^(?:<<<<<<< .*|=======|>>>>>>> .*)\r?\n?', '',s)
def parse(s):
    return [p.strip('\r\n') for p in re.split(r'(?m)(?=^## )',clean(s)) if p.strip('\r\n')]
def sha(b):return hashlib.sha256(b).hexdigest()
def run(repo,refs,dest,receipt):
    path='docs/session-logs/2026-11-15.md'; texts={}; edges=collections.defaultdict(set); incoming=collections.Counter(); sources=[]; ranks={}; allids=set()
    for ri,ref in enumerate(refs):
        raw=subprocess.check_output(['git','show',ref+':'+path],cwd=repo)
        parts=parse(raw.decode()); counts=collections.Counter(); ids=[]
        for pos,part in enumerate(parts):
            digest=sha(part.encode()); counts[digest]+=1; key=(digest,counts[digest]); texts[digest]=part; ids.append(key); allids.add(key); ranks.setdefault(key,(ri,pos))
        for a,b in zip(ids,ids[1:]):
            if b not in edges[a]:edges[a].add(b);incoming[b]+=1
        sources.append({'ref':ref,'raw_sha256':sha(raw),'blob':subprocess.check_output(['git','rev-parse',ref+':'+path],cwd=repo,text=True).strip(),'blocks':len(ids),'ids':ids})
    def priority(k):
        h=texts[k[0]].splitlines()[0]; m=re.search(r'(?<!\d)([0-2]?\d):([0-5]\d)(?!\d)',h)
        return ((int(m[1])*60+int(m[2])) if m else -1,*ranks[k],k)
    ready=[priority(k) for k in allids if incoming[k]==0];heapq.heapify(ready);ordered=[]
    while ready:
        k=heapq.heappop(ready)[-1];ordered.append(k)
        for v in edges[k]:
            incoming[v]-=1
            if incoming[v]==0:heapq.heappush(ready,priority(v))
    if len(ordered)!=len(allids):
        cycle=[texts[k[0]].splitlines()[0][:120] for k in allids if incoming[k]>0]
        raise RuntimeError('incompatible parent block orders: '+repr(cycle[:15]))
    pos={k:i for i,k in enumerate(ordered)}
    for source in sources:
        ix=[pos[tuple(k)] for k in source.pop('ids')]
        source['complete_blocks_and_multiplicity_retained']=len(ix)==source['blocks']
        source['parent_order_retained']=all(a<b for a,b in zip(ix,ix[1:]));assert source['parent_order_retained']
    result='\n\n'.join(texts[k[0]] for k in ordered)+'\n'
    assert not re.search(r'(?m)^(?:<<<<<<< |=======|>>>>>>> )',result)
    Path(dest).write_text(result)
    data={'schema':'point-table-journal.retention/v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'normalization':'Remove only conflict-marker lines and outer block newlines; retain every other byte of every block. Block identity is full SHA256, never heading. Common identical block occurrences are shared up to maximum parent multiplicity.','sources':sources,'result_blocks':len(ordered),'result_bytes':len(result.encode()),'result_sha256':sha(result.encode()),'conflict_markers':0,'ordering':'Stable topological union preserving each complete source block sequence; time priority between independent ready blocks only.','standing':'Producer retention controls; not signed scientific/execution evidence'}
    Path(receipt).write_text(json.dumps(data,indent=2)+'\n');print(json.dumps({'blocks':len(ordered),'bytes':len(result.encode()),'sources':len(sources),'all_parent_orders_retained':True}))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--out',required=True);p.add_argument('--receipt',required=True);p.add_argument('refs',nargs='+');a=p.parse_args();run(a.repo,a.refs,a.out,a.receipt)
