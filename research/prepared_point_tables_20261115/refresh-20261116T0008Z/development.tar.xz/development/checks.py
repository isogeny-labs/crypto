from pathlib import Path
import subprocess,json,os,sys,datetime,hashlib
repo=Path(sys.argv[1]);name=sys.argv[2];crate=Path('crates/hashed-ecdl-tensor');scratch=Path('/workspace/scratch/point-table-tracking-20261116T0008Z')
env=os.environ.copy();env['PATH']='/home/agent/.cargo/bin:'+env['PATH'];env['CARGO_TARGET_DIR']='/workspace/.task-cache/point-tables-crypto' if name=='parent' else '/workspace/.task-cache/joint-scalar-crypto'
checks=[('tests',['cargo','test','--locked','--release','--manifest-path',str(crate/'Cargo.toml'),'--all-targets']),('fmt',['cargo','fmt','--manifest-path',str(crate/'Cargo.toml'),'--','--check']),('clippy',['cargo','clippy','--locked','--manifest-path',str(crate/'Cargo.toml'),'--all-targets','--','-D','warnings']),('msrv',['cargo','+1.78.0','check','--locked','--manifest-path',str(crate/'Cargo.toml'),'--all-targets'])]
for check,args in checks:
 out=scratch/f'{name}.{check}.stdout.log';err=scratch/f'{name}.{check}.stderr.log'
 with out.open('wb') as o,err.open('wb') as e:r=subprocess.run(args,cwd=repo,env=env,stdout=o,stderr=e)
 receipt={'check':check,'argv':args,'cwd':str(repo),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'stdout':out.name,'stdout_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'stderr':err.name,'stderr_sha256':hashlib.sha256(err.read_bytes()).hexdigest(),'nonsecret_env':{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR'],'PATH_prefix':'/home/agent/.cargo/bin'}}
 (scratch/f'{name}.{check}.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
 if r.returncode:
  print(out.read_text()[-2500:]);print(err.read_text()[-2500:]);raise SystemExit(r.returncode)
