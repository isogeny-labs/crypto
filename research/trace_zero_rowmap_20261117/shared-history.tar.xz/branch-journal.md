# Session log 2026-11-17

## 2026-11-17 ~00:45Z — F4/Gröbner speed leads: parallel workflow, integration, confirmation run (Claude)

### What was done (commands, files, features)
- Owner request (2026-11-16): "Pursue all the leads here in parallel workflow", after the assessment in
  `docs/session-logs/2026-11-16.md` (~16:30Z entry, PR #4436, merged).
- Ran a multi-agent workflow (5 leads, then integrate, measure, red-team). Two container restarts interrupted it;
  finished leads were carried forward from their saved results and interrupted leads resumed from their notes.
- Leads, all output-identical to the baseline [pcc:unverified]:
  - f4-parallel (`src/cryptanalysis/f4_fp.rs`): one-thread share of counted row ops on quad_n9 10.2% → 2.5%,
    cubic_n5 97.9% → 12.4% (column-tiled `B'`, tiled in-block finish, work-based gates, gated parallel symbolic).
  - f4-memory (`f4_fp.rs`): fused 8-update lazy accumulation, accumulator words per field op 1.0 → 0.13–0.14.
  - gf2-m4ri (`src/cryptanalysis/koblitz_groebner.rs`): sort-free parity row generation for cold GF(2) Macaulay
    builds; callgrind `macaulay_profile` 71.1 M → 54.4 M Ir.
  - crossbred-m3: measurement only; pair table beats every algebraic engine at m = 3 (40–6800× wall);
    crossbred vs InheritedF4 unresolved (counters disagree with wall time).
  - isolab: blocked (CodeBuild queue limit 0 on every 2026-11-16 launch; this session's AWS keys rejected by STS).
- Integration commit `929c01c601`; serial ABBA run `run-20261116T2306Z` (1,440 runs, Python runner); red-team
  re-analysis: f4-memory and f4-parallel refuted as claimed (missed pre-registered targets), gf2-m4ri survives.
- Commit `b04b25832f`: f4-memory made opt-in (`F4_FP_MEM=1`); new native driver `examples/f4_ab_confirm.rs`
  (Rust, `ecbench::stats`). Outputs identical to baseline (default, `F4_FP_MEM=1`, 1 thread, `F4_FP_PAR_OLD=1`;
  koblitz x/sym). `cargo test --release --lib f4_fp koblitz_groebner inherited_f4`: 210 passed.
- Confirmation run `run-20261117T0022Z`, pre-registered (`CONFIRM_PROTOCOL.md`), under
  `tools/benchrec.py run`, record `benchmarks/records/20261117T0022Z-f4-shipped-default-ab.json`: 384 runs, 0 failed,
  0 fingerprint mismatches; every prediction held. Primary: sum of f4 times at 4 threads 1.141 [1.098, 1.158];
  quad_n9 1.161; 1 thread 1.034 (n.s.); quart_n3 0.811 and cubic_n4 0.865 at 4 threads (significant regressions);
  GF(2) kernel_x 1.335 / 1.492 [pcc:unverified].
- Evidence: `research/f4_groebner_speed_leads_20261116/` (README, two run reports with SVG + PDF, raw data, lead notes,
  red-team verdicts). Lessons `L-d80b6fce4f25`, `L-54849f1ae03b`, outcome `O-d044628ddd31` in `docs/lessons/entries/`.

### Decisions made (and why)
- f4-parallel and gf2-m4ri on by default; f4-memory opt-in: its pre-registered endpoint failed and it regressed
  small systems, while its unpredicted gains rest on a weak output check (basis {1}).
- No benchmarks/README row and no leaderboard change: no counted unit moved, and the validation gate needs a matched
  rho reference this component study does not have. Results stay in the research directory, as the gate allows.
- The first run's Python runner and analyses are kept only as archived provenance; the confirmation run replaces them
  with the native driver (AGENTS.md "Implementation language: no Python").
- `CONFIRM_PROTOCOL.md` left byte-unchanged after data (one advisory prose-lint finding) to keep the freeze intact.

### Open threads (unfinished, pick up next time)
- Small-system regression of f4-parallel at 4 threads (quart_n3, cubic_n4): add a work threshold that keeps tiny
  steps on one thread, then re-run the confirmation.
- f4-memory: pre-registered confirmation with overdet_n12 at 4 threads as primary endpoint, a step-matrix hash and a
  size gate.
- Time quad_n10, quad_n11, cubic_n6; add an msolve arm (AGENTS.md §15).
- Many-core confirmation once CodeBuild is restored (`leads/isolab/`).
- `main` was emptied to 13,157 files by sparse-branch merges (#4352, #4463); #4467 restores it. This branch's PR
  cannot merge until then (`koblitz_groebner.rs` is missing on main).

### Errors (what went wrong, how it was handled)
- Two container restarts killed the workflow; recovered from the journal and lead directories without rerunning
  finished work.
- The workflow's measure agent stopped before its runner finished; the runner completed and the red-team analysed it.
- S3 checkpoint push failed (no valid AWS credentials); the resume note is committed instead.
- `benchrec check --local` reports one pre-existing failure in `20261105T1826Z-ic-aimed-gather-registry-binding`
  (`docs/curves/registry.json` changed); not from this work.
## 2026-11-17T00:50:18.666657+00:00 — Begin direct-cubic speed follow-up on integrated main

- User requests continued acceleration. PR4349 merged at28f667c57a0919600f7ec07c191c53b316348419. Fetched main successfully, created codex/direct-syzygy-speed-20261117 atd06c4a82808701ede1aca1a64ebb7f861b0eade5. Prior source/records unchanged; Rust math/root worker sources match previous study. Current main retired AGENTS/old helper tools; no deleted workflows restored. Hydrated session logs and read newest16 entries. Prior degree5to4 result and all fixed seeds preserved.
- Sources checked (KB unavailable):old wrapper no executable and no MCP KB. RANK_RESULT_REPORT/FOLLOWUP, rank selector/cheap.rs exact identities, previous stronger-frontier qualification. Reopened Caminata–Gorla arXiv2112.05579v2 and official SciPy bootstrap documentation (paired index resampling; retained prior Rust percentile estimator, not default BCa).

- New prospectively fixed fourarm repeated comparison separates rank scouting from unused-candidate construction, keeps previous-fastest frontier comparator and full original-basis/identity checks. Onlyknown p31 n3/4/6 seed7; no fresh/reserved seed generation. LocalCPU0/L0/checkpoint waiver/zero cloud. Reuse hash-pinned existing isolation monitor outside repo; self-contained Rust raw record/auditor instead of resurrecting removed tools. New follow-up PR needed because4349 merged.

- Freeze protocol, implement direct/fourarm capture/audit, qualify and publish methods before repeated timing; preserve all A/A rejections, failures and costs.

- Old origin/main trackingref was stale; fetched FETCH_HEAD is the actual base. Missing log files were sparse checkout, hydrated. Removed tools/instructions are actualmain changes, not environment failures.

- Before any native data: compile51 caught a missing error-propagation operator; test52/53 caught that the frozen calculator only supports odd7/21 samples. Final design uses25 main blocks (24 position-balanced plus fixed0123) and a separate25 adapter; same odd median/percentile sampler, legacy7/21 admission unchanged. Initial24 draft and all failed receipts retained. No data-dependent criterion change.

## 2026-11-17T00:59:22.236746+00:00 — Complete direct-comparison implementation checks

- New direct_paired.rs compares dynamic rank, full-family direct, first-four-equation prefix direct, and previous-fastest checked frontier. The same selected identities/augmented bytes are independently reconstructed. Work includes full Singular identity and native/original-reference equality checks.53 scoped capture and16 library release tests, strict lint and build54 pass.

- Preserve legacy7/21 public admission; explicit25 numerical adapter reuses identical odd-median/index-resampling core. Main has24 position-balanced blocks plus fixed0123. Statistical gates/prices/false-flag/order/overflow and original membership guards tested. Freeze source now, one oldn3 correctness panel then corrupt-wire/cost refusal before new PR/method publication.

- Frozen source/calibration/archive/sourcepublication/newPR before bounded repeated run. No fresh/reserved inputs.

-51 compile error and52/53 sample-roster assertions retained; fixed before any native data. No legacy statistical conclusion or acceptance threshold weakened.

- Monitor dependency was also sparse in the older checkout. Recovered byte-exact Git object f4499e9d into the isolated monitor directory. Earlier dependent command55 reached a missing-file wrapper before native invocation; all diagnostics retained. Build55/tests/lint passed; no math change or native retry. Configuration/dependencies now complete, qualify existing frozen55 executable in a new attempt56.

## 2026-11-17T01:03:42.412241+00:00 — Qualify frozen four-route direct comparison

- Frozen55 driver:one oldn3 panel,4 complete answers, exact original3CAS/identity/byte-equal selected inputs/F4/frontier-wire replay and cost checks pass. CPU0 monitor valid, unchanged program/config hashes. Coherently altered paid sum and corrupted frontier schema both refused before output. Five full qualification/negative/program archives retained.

- All implementation and runtime fixes occurred before native performance data. Publish method/config/source/qualification and open new regular PR from integrated main, then register bounded3case development run.

- NewPR/sourcepublication,25 repeated blocks plus A/A, full raw statistics/cost evaluation and honest report.

-54/55 wrapper-only startup failures retained;56 is first actual native calibration. No case/seed substitution or statistical gate change based on timings.

## 2026-11-17T01:06:45.793208+00:00 — Publish direct methods and register repeated run

- Exact compiler-source Git commits and full qualification/program archives pushed; published method0583346733f8e7bbd0ee80fe3698ec7f6dc2092c. New regular PR4476 opened against main, parent4349 merged. No performance samples before publication. Self-contained run record registered.

- Launch collector itself with taskset0 inside the default CPU0 reservation, so in-process construction/rank work and native child solves use the same reserved CPU. Correctness-only calibration is not used for timing. Fixed25main blocks and7AA pairs per n; continue main after AA rejection only descriptively, no reruns/gate changes.

- Execute bounded run, audit every native answer and recompute statistics/prices, archive/report/plots/PDF and updatePR4476.

- None in source publication/newPR. No cloud spend or holdout generation.

## 2026-11-17T01:10:59.717412+00:00 — Complete fixed direct-construction comparison

- All3 cases complete,480 full answers independently replayed against original3CAS outputs and original membership identities; frontier strictwire replay passes. All three cubic routes produce identical augmented systems. Monitor valid/zero contention/program/config hashes unchanged. Rust recomputes all cost sums/orders/8AAgates/25block statistics from raw bytes.

- Global all-case/all-control gain isfalse. n3 AApasses; rank workmedian1.130528/lower1.011667 and frontier1.086289/lower1.067976, but direct-all lower0.935040. n4/n6 AAfail and remain descriptive despite positive rank/frontier medians. Prefix/direct-all lower bounds cross1 at every size. No sustained timing/15x claim, no retries.

- Read-only Rust phase/ratio visual, complete raw archives, report/PDF, close run record and publish outcomes toPR4476. Next hypothesis must target actual measured checking cost and retain exact obligations.

- Two neutral-control rejections are scientific outcomes, not infrastructure failures to rerun. No correctness, native, raw audit or runtime-pin failure.

## 2026-11-17T01:19:46.041557+00:00 — Close direct study and replay archived evidence

- Complete4rawarchives extracted into a new workspace and frozen Rust auditor rerun read-only:byte-identical audit SHA73389d83f7ef1cf62eb598272537f59deae75735a9f2d9a7b06c0da4f08962ba. All480 answers/statistics/identities/frontier wires recomputed. Four-pageA3 PDF/all plots inspected, no rendering warnings. CLOSE_RECORD pins all results and verifies original method/config/program bytes still match. Run status measured.

- Publish scoped n3 observations and global gatefalse, preserve2AA-rejected cases and direct-all nulls. No new15x or broad fastest claim. Extra preprocessing shrinks, external identity-check call is measured next target; any successor must retain exact independent checks.

- Push result/source/raw closure and updatePR4476; review/CI/independent validation remain. Successor native identity checker is unimplemented/unmeasured and needs a prospective protocol.

- No archive, correctness, numerical replay or render failure. No scientific rerun after neutral-control rejection.

## 2026-11-17T01:22:16.171693+00:00 — Verify published direct result and close bounded work

- Exact source/result commit79594070f0b5e970bdc81fb25aa44bc0c661ecea pushed; PR4476 updated around final outcomes. Remote RESULT blobc338fb71 matches local GitSHA. Complete480answer/raw4archives/qualification/source/plots/four-pagePDF uploaded, archive audit byte-equal. PUBLICATION receipt retained.

- Bounded direct-comparison goal complete, not a claim of broad or15x speedup. n3 observations scoped to named frontier/rank controls; all-case gatefalse and2AA-rejected cases retained. PIN_SCOPE explicitly bounds attestation to executable/config/source/monitor coverage, not comprehensive shared libraries. Existing result/PDF hashes unchanged.

- Review/CI and signed independent execution remain pending. Next unmeasured lead:exact independently implemented native identity checker to reduce the observed external-check phase, preserving every mathematical obligation and full paid accounting. No new benchmark is running.

- No result upload or remotehash failure. No post-data rerun, hidden rejected case, or changed criterion.
# Session log — 2026-11-17

## 00:08Z — retain failed42 qualification; correct ownership in a new native entrypoint (Codex)

- Active Rust graph-IC/extension-field objective continues across midnight. Trial42source9c7ab02c1e/solePOST2022026-11-16T23:47:50Z: all3workers0, copied qualifier1 with component cost/scope because every foreign_thread_hooks=1. Original archive/raw/manifests collected/hash/private-pattern checks before owned4td258m5gya0ogDELETE204/independentGET40423:50:26Z;guardian marked. All owned paid pods32–42deleted. Failure packet/native failure-summary retain original hash-bound data; no admitted costs or independent math assertion. [pcc:unverified]
- ProductionPR4453merged268f4bdc5; componentPR4463merged23:45:47Z/a11edb4d2/head64a8788d39. Remote automatic merge deleted shared bitops.rs from the frozen source set. Published immutable measurement branch measure/anchored-descent42-source-9c7ab02c, sealed11MBbundle and dispatched exactlyonce from9c. Never force-pushed or discarded remote changes. [pcc:unverified]
- New branch feat/extension-ic-owned-descent starts at currentmaind06c4a8280 after stashing/restoring only new wrapper/snapshot. Official PCC admin tool is run from exact historical9csource at/tmp/ic-pcc43.py with --repo, without restoring unrelated deleted infrastructure. Shared metadata was not edited while Copilot request6932829993 on4463was pending; closure/merge now confirmed. Earlier sidecar records preserved. [pcc:unverified]

- Preserve all frozen42science/checker/binaries/data. Add a new native owned entrypoint following existing production comparator: explicit Rayon1threadpool.install wraps the whole component call, so claim/moduli/tallies live on the worker running F4. Keep same401public input/residual/cofactor stream in a separately frozen changed-source repeat43; unchanged checker must reject missing work. No favorable-seed reroll, no relaxation of foreign gate or42repricing. [pcc:unverified]
- A narrow versioned snapshot of exact9cshared source, accounting and two unit-vector inputs replaces dependence on removed global compiler-read paths. All snapshot bytes remain identical to their recorded Git origins. This supports the native component without unrelated source restoration or claiming current-main Root Cargo success. [pcc:unverified]

- Owned entrypoint29test/strictClippy job pending; add exact repetition checker and bounded43protocol/source/binaries/publication, then Runpod. Failure42report/claim committed with continuation; scientific qualification of corrected run remains pending. Continue to the next relation/descent lead using actual coverage when this control is complete. [pcc:unverified]

-42qualifier caught genuine lost-thread counts; native worker had claimed the caller rather than the Rayon executor. Initial owned compile found unused frozen prepare helper: mark only that shared included module's unused members, as existing copied checker does. Snapshot unit build required two existing accounting-vector JSON files; copied exact historical bytes, retaining failed receipts. No science retry or paidpod43yet. [pcc:unverified]
- APIv2create exposes nested cpu/cost fields; initial legacy-flat validation failed after201/id/guardian capture, then normalized actual allocation without another create. Initial preparer lacked feature tracking ref; explicitfetch exposed remote advance, so published a separate immutable measurement branch. Workspace startup twice returned ready immediately; sessions disappear across restart, so inspect persisted actual status files instead of inventing completion or rerunning successful work. [pcc:unverified]

## 00:21Z —29owned controls/source freeze; failure42report retained (Codex)

- Owned worker29testsPASS, including nested Rayon hooks on the actual claimed executor with zero foreign flags; strictClippy0/opt-level3build0. Native repetition controls accept identical geometry despite changed count fields and refuse substituted cofactor/foreign ownership. Simulated all-arm/first-failure/duplicate-execution transportPASS. New sourcePCC-20261117-e4f277 UNVERIFIED pins22source/control/protocol blobs and immutable binary manifest.15snapshot blobs are byte-identical to9cGit origins, including the two required unit vectors and complete copied-checker sources. [pcc:unverified]
- Failed42PCC73ededUNVERIFIED packet/native metadata/onepagePDF/SVG/150dpiPNG complete; finalonepagePDF rasterVIEWEDunclipped, benchmark copieshashbound. Exact originals stay LOCALhashbound; copied qualifier rejection and original foreign1counts are never relaxed/repriced. Failurecommit exists on current lane branch; source43notyetpublished/allocated. [pcc:unverified]
- Current-main cargo test --release --lib with isolated CARGO_TARGET_DIR fails beforecompile: missing ecdl-tensor-icpackage. Native component uses explicit snapshot/oldRoot instead; no global Cargo success. Latest main ledger prefix plus all payload multiplicities from the retained9ccomponent and committed42failure are preserved through official PCC append API; original hash envelopes in owned43-ledger-provenance.json. [pcc:unverified]

- AMENDMENT38registers separate changed-source repeat43with identical401input/residual/cofactor stream and unchanged copied checker. Snapshot avoids removed global accounting/PCC dependency without restoring unrelated infrastructure. Retainold42raws only as hash-bound postmeasurement qualifier references; worker reads its homogeneous input only. Complete costs/ratios staynull, no seedreroll. [pcc:unverified]

- Commit/push source43/regularPRandautoMerge; preserve immutable measurement branch before automation changes PRhead. Sealbounded5400sCPU runner/solecall/collect/hash/delete/qualifiedreport. Allownedpaidpods32–42deleted;43notallocated. Goalactive. [pcc:unverified]

- Initial owned build omitted frozen shared prepare helper allowance and two compile-time accounting vectors; fixednarrowly, failedreceipts retained. Runtime restart returnedreadyimmediately and discarded active execsessionID; actualfiles showed prior failure, followedby successful29controls. No scientific43call or automatic42retry. [pcc:unverified]


---

2026-11-17T00:14:00.915153+00:00
# Main-based Richelot chart and separate trace-auditor source successor

## What was done
Unsigned source claim668611: exact d06c4a8280 full base index,69 native files copied/allSHAchecked/13 base overlaps unchanged; whole161-file767400B old fork/53 claims/keyring/tools/policy/handoffs archive retained with every member bytes/SHA/mode checked. Later raw intake record and complete source-fork ledger preserved separately. Chart1422f5/auditf88c0c and inspected7557ce/2fab5c reports unchanged. NewCI wrapper Bash syntax0/actionlint0, not locally executed. No producer rerun. [pcc:unverified]

## Decisions made
Active source successor: /workspace/crypto-chained-chart-current, new lane/chained-transfer-charts, pinned base d06c4a8280. New index /workspace/crypto-chained-main-validated/.git/worktrees/crypto-chained-chart-current/index (initial1964210B retained); old original indices/branch remain. Do not install archived tools as active trust roots or edit canonical ledger. Source PR is reviewable while original canonical PCC/store/merge gaps remain; current main omissions are external evidence, not a waiver. [pcc:unverified]

## Open threads
Normal guarded new branch/tag/regular PR/body lint and actual CI, original gate set/store/PCC trust restoration, actual count<=30. Then balanced-divisor/Richelot factor chart composition/dual orientation. Original fullLP/admission/strongest matched costs/paidSTOP/vault constraints remain. [pcc:unverified]

## Errors
Original missing-base prefix0 explicitly rejected; unchanged verifier1 after full blob hydration, canonical and source forks preserved without choose/rechain. Current-main root AGENTS/keyring/PCC/artifact config+tools/gate workflows absent per bd5fdc pinned tree. Their absence is not replaced by archival sources or claimed signed/green admission. [pcc:unverified]
# Shared session log

## 2026-11-17T00:03:25Z — Polarized quotient proof/report ready; predecessor PR merged

- Completed POLARIZED_QUOTIENT.md/PDF with the actual26-member witnesses,the determinant/norm height bridge and the positive-Rosati degree/polarization proof. Inspected every final page:quotient4,REPORT7,FORMAL3,BACKMAP3,KUMMER3. Updated study/status/problem notes and retained all native exits0.
- Native certificates:PCC-20261116-3f440b(actual K),ce4a7b(heights),8559fc(direct rank),b5b5f6(limited-field identities). PCC-20261117-79f29f pins the readable quotient proof. All are unsigned statement records and remain not_covered. [pcc:unverified]
- Structural IDs IDC1he1df3cc59b22101e/IDC1hbd7884154ab5b718 cover norm multiplicativity and cubic equality only,not finite-field positivity or the geometric theorem. Lesson outcome O-d004d796c455 records completion of this geometric milestone,not scalar recovery.
- PR4403 merged atc75ec0ee14ae while this work ran;its remote branch was deleted. Renamed the local continuation lane/nist-p192-polarized-quotient and fetched main. Publish a follow-up regular PR;do not update the closed predecessor. No new paid/performance run or gate change.

- Preserve the completed native source and proof pins,then integrate current main with full shared-journal/ledger retention before publishing. The original fixed geometric objective has a constructed same-field quotient,map,public transfer and restricted relation set;generic transpose-dual execution,exceptional-chart interfaces and scalar descent remain distinct work.

- Finish follow-up PR publication and remote-content verification. Preserve pending large historical artifacts outside Git;all new result files are below1MiB.
- Independent verification/compiled geometric formalization remain absent;the frozen protocol lint wording is documented in its companion erratum.

- No new arithmetic failure. Predecessor PR closed normally;the new branch avoids publishing unmerged follow-up work into that closed PR. Cargo/Lean/lake/KB/Conductor remain unavailable as recorded.

## 2026-11-17T00:25:52Z — Follow-up PR4471 and current-main history reconciliation

- Pushedaa7163fd52 and opened regular PR4471 with auto-merge enabled. Requested Copilot reconciliation in comment6933424643;no bot action occurred during the wait,so used the documented full-history fallback.
- Integrated main snapshot d06c4a8280. Preserved its1222-row canonical ledger byte prefix and archived/reappended57 absent unsigned branch claim/note bodies unchanged. Structural chain errors0. Journal merge retains the maximum complete-block multiset:909 branch,1205 main,1325 result. Exact receipt and raw suffix are committed with the metadata-only reconciliation helper. [pcc:unverified]
- Main removed local tooling/agent files;kept those upstream deletions. Used the preserved maintained PCC API(snapshot SHA165df341956504d140141e149f1615e286e2c7feb7f5837084af3999443e7d83) for metadata checks rather than restoring tooling. Post-merge proof bindings match;statement79f29f remains not_covered.
- Main's lesson check has122 entries/90 unknown-reference diagnostics;merged has123/90,the same diagnostic set. No new error from this task. Scoped changed-source diff/prose checks pass. Fetched main before this append.

- Preserve immutable math/source/proof bytes while reconciling shared metadata. Do not fix unrelated upstream metadata/tooling removals or claim all-green validation.
- Publish the same-field polarized quotient milestone with explicit producer-proof standing;generic transpose-dual execution,exceptional-chart interfaces and individual descent remain distinct work.

- Push the reconciliation,update PR validation status and verify intended remote proof/result/PDF files. Independent verification and compiled geometric formalization remain absent.

- Initial metadata helper refused a whitespace-only preamble difference before writing;the corrected helper retains main's preamble and all full blocks. A broad read-only diff/stat caused lazy-fetch work and ended without changing math artifacts;use scoped checks.
- One administrative command was rejected for forced-rm style;the generated cache was removed by an exact non-forced file deletion. No private data or protected source was removed. The90 lesson diagnostics are inherited from main.

## 2026-11-17T00:37:53Z — Quotient milestone published; intended remote contents verified

- PR4471 is open,mergeable and auto-merge enabled at9681ff7e0e. Verified matching remote Git blobs for the frozen quotient proof,its PDF,the actual-kernel result,the degree result,the direct-rank result and shared-history receipt. The mathematical source/proof pins remain unchanged.
- Rechecked all five new PCC records after main integration:artifact hashes match and each statement remains not_covered. The goal's geometric deliverable now has one explicit same-field quartic,recorded K,source-class map,public transfer and six restricted setup relations. Readable proof uses the named standard geometric theorems;independent/compiled verification is absent. [pcc:unverified]
- Inspected CI failures on both this branch and main:scope fails because .github/scripts/ci-scope.mjs is absent;harness/CLI fail as dependents;gate fails because tools/artifacts/artifacts.py is absent. Both paths are absent in maind06c4a8280 and unchanged by this branch. Exact baseline/run receipt retained. No gate bypass or unrelated restoration.
- Fetched main before this append. Only three historical large pending-artifact files remain untracked;all completed new math sources/results/proofs are published.

- Treat the fixed geometric quotient/transfer/relation milestone as delivered at producer-proof standing. Do not equate it with an index-calculus scalar solver or a speed result.

- Generic transpose-dual execution,complete exceptional-chart interfaces and restricted individual descent remain separate implementation work. CI awaits upstream script repair;no all-green assertion.

- Four CI failures have the same missing-script causes on main. Main lesson metadata also retains its90 baseline diagnostics,with no new diagnostic from this task. Native qualifiers and source bindings have no observed mismatch.

## 2026-11-17T03:40:13.374678+00:00 — Resume ECC2K-130 index-calculus solver only

### What was done (commands, files, features)

- User scope: continue ECC2K-130 code improvements ONLY for index calculus. PR3744 merged as211dc153; began clean continuation from actual main2043bee6 on codex/ecc2k-ic-rowmap-20261117. Relevant production solver/field/context bytes are unchanged from the previous result. Preserved current source snapshot and executable bda296f1 before edits [pcc:unverified].
- Sources checked (KB): no loaded tools; wrapper status127. Read existing binary_semaev S3/Artin–Schreier, certicom131_symlp/sym2 symmetric subspace oracle and linear-map/Gray-code discussion, gf2_elim Four Russians tables including known setup regressions, partial_enlargement combination tables, prior trace-zero studies. These support testing existing binary-linear lookup techniques, not a novelty assertion.
- Read current main instructions, controlled experiment/protocol/profile/report rules and scope-specific lessons. The canonical experiment tool, PCC, artifact and CI-scope tools are present on actual current main. Existing local CPU0/2GiB/600second/zero-paid authorization remains; no paid EKS launch. No open lane/ecc2k PR found.

### Decisions made (and why)

- Profile the CURRENT merged algebraic relation oracle, then focus on projected S3 equation assembly. Keep curve, full factor-base/kernel admission, exact equation system, signs, model order, limits and replay fixed. Any lookup preparation stays charged to each complete query. Compare with current best kernel, not earlier v1.
- Cost chain: C_old=setup+complete_oracle+post. Replace ONLY binary-linear row evaluation inside complete_oracle; C_new=the same three boundaries with the replacement and all table construction charged. No IC pipeline, relation-density or native-time conclusion from a component instruction panel.

### Open threads (unfinished, pick up next time)

- Baseline discovery profile; implement/check exact packed linear-map evaluation if supported; freeze a matched A/B/A panel before primary counts. Finish source-bound report/export/archive and regular continuation PR.

### Errors (what went wrong, how it was handled)

- Old remote branch was deleted after merge; queried PR and fetched main rather than resurrecting it. Reads attempted while checkout was still running saw transient absent files; waited for switch completion and confirmed clean tree/tool availability. Conductor unavailable127; scoped paths recorded here. No source change or comparative run yet.

## 2026-11-17T03:41:38.474405+00:00 — Profile supports packed S3 row-map replacement

### What was done (commands, files, features)

- Retained merged-kernel profile records51775125 whole-process Ir. Exact compiler-path annotation identifies repeated parity and coefficient-row assembly. All profile output stays discovery-only, not a comparative performance result [pcc:unverified].
- Reviewed existing Four Russians/linear-table setup tradeoffs and symmetric subspace oracle; standard binary-linear combination tables supply the mechanism. KB unavailable127; no novelty claim.

### Decisions made (and why)

- For widths<=16, pack up to16 projected coefficient rows into four u64 lanes and evaluate them together with four-bit input tables. Pack RHS projections alongside those tables. Keep remaining rows/widths on exact parity fallback, preserve row order/elimination/reconstruction and all W/root/replay checks. Per-query tables are built lazily only after an actual projected residual.
- Pre-data comparative target: on BOTH uniform controls, reduce complete-oracle Ir by>=5% and complete cold-query Ir by>=1% against current merged kernel with lazy context fixed. Require exact outputs and all six A/A discrepancies<=1%; other positive/cancellation cold-query medians may not regress>1%. Full six-cell A/B/A, five repeats; no threshold relaxation after data.

### Open threads (unfinished, pick up next time)

- Implement exact map with exhaustive linear-basis/random packed-row checks, narrow/wide fallback and65-case parity. Then source/protocol publication, capped pilot/freeze/primary and all result custody/reporting.

### Errors (what went wrong, how it was handled)

- No profile failure. Earlier transient checkout reads were resolved before measurement. No solver changes or comparative candidate counts yet.

## 2026-11-17T03:52:24.618783+00:00 — Packed S3 map validated and qualified before comparison

### What was done (commands, files, features)

- Twenty-one focused release checks pass, including all65 exact current/lookup outputs, full input-basis/random matrix evaluation, width>16 fallback and forced late scalar rows. Packed rows preserve original projected diagnostics, roots/model order and group replay. Statement5b4512 pins unsigned pre-primary tests [pcc:unverified].
- Built a study-local backend with actual current numeric field/context/solver code and pinned previously compiled SAT/chain support fromd7a006293. Current main SAT parser is malformed; broad root check separately fails hashed-ecdl-tensor metrics imports. No full-root/SAT success claimed. Both experimental arms share exactly the qualified support.
- Corrected the earlier log's broad unchanged-field assumption: current main includes one F2m square-tally tick plus tests. The historical bda profile remains source-bound discovery evidence; a new fresh current-arithmetic baseline profile is retained before comparative data. Prior result files/claims are unchanged [pcc:unverified].
- Prepared90-row A/B/A,12-call pilot, exact input/analysis/source hashes and narrative cost chain. Canonical protocol validate passes. User scope remains index calculus only; standard K0-131 plus explicitly matched E0 n83 fixture.

### Decisions made (and why)

- Keep production edit at projected S3 row evaluation only. Do not repair unrelated current-main SAT/tensor sources or silently treat support qualification as a full repository build. Publish source and explicit qualification before calibration/pilot/freeze/primary.
- Keep the pre-data5% oracle/1% cold criterion and no>1% regression checks unchanged. Preparation paid per query; all fixed controls and failed outcomes retained.

### Open threads (unfinished, pick up next time)

- Publish source on a new regular lane PR, then run capped final calibration/pilot/frozen90 rows; separate arithmetic replay, grid/export/archive/report, source review and PR update.

### Errors (what went wrong, how it was handled)

- Initial focused build exposed unchanged upstream SAT syntax failure. Local support crate copy initially had nested workspace markers, then missing new current-main facade imports/dependencies; retained every failure, corrected only the focused wrapper and rebuilt successfully. PCC API now requires claim-type; added explicit data/interpretive types after the rejected initial command. No primary row exists yet [pcc:unverified].

## 2026-11-17T03:58:47.073273+00:00 — Packed S3 panel passes fixed improvement criterion

### What was done (commands, files, features)

- Published source45b0279c02, calibrated and passed all12 pilot calls, then froze/pushed protocol7703daa3af347a76a52bd0bc5b5587516e658ecb04c0b5c887d6b7d550aadfcf in8413104e62 before primary. All90 rows complete with exact outcomes/witnesses/common/projected diagnostics and identical field ledgers. Separate Rust grid auditor recomputes every raw summary range; separate polynomial checker replays60 saved tuples and rechecks65 truths [pcc:unverified].
- ECC2K-130 uniform oracle/cold Ir reductions22.866246%/11.211412%; n83 reductions31.582373%/16.769302%. Every fixed criterion passes, including no>1% other-cell regression and all six A/A checks. Zero invalid/missing/retry. The comparison is against the current merged optimized kernel, in the same qualified instrument [pcc:unverified].

### Decisions made (and why)

- Finish raw archive/export/inspected report and regular lane PR. Preserve current-root/SAT qualification and all failed build receipts. Do not multiply this panel's ratios by older results or claim an IC pipeline/native-time result.
- Original preregistration narrative is already hash-pinned; kept it byte-equal. Added a prose-only v2 companion to remove one linter claim-word, without changing any equation, threshold or measurement. Other same-day journal lint findings predate this task and are preserved.

### Open threads (unfinished, pick up next time)

- Artifact packaging, final canonical export, scientific report and PR publication. New PCC records carry required claim_type;151 missing-type diagnostics belong to base claim files and current-main ledger byte prefix remains intact [pcc:unverified].

### Errors (what went wrong, how it was handled)

- A metadata check initially compared diagnostic claim IDs to ledger text, where current schema stores hashes rather than IDs; corrected the administrative check to base claim filenames. All151 diagnostics are base files; no ledger rewriting. No solver/replay/primary failure [pcc:unverified].

## 2026-11-17T04:11:34.191877+00:00 — Packed S3 result artifacts ready for lane PR

### What was done (commands, files, features)

- Accepted canonical export, all728 raw member hashes and byte-identical archive repack. Inspected both scientific-report pages and four discovery-profile pages; historical retained binary provenance is explicitly separated from the fresh qualified baseline. Copied PDF/SVG/150dpi PNG into dated benchmark report folder without promoting a gated benchmark row [pcc:unverified].
- Copied the separate polynomial checker source byte-exact into the study; a fresh focused rebuild reproduces the original independent-audit JSON exactly. Frozen primary analysis/source/binary hashes still match; post-run auditor/checker/rendering sources are separately hashed [pcc:unverified].
- Final data statement PCC-20261117-4d24cd pins README/PDF/export/rebuild audit/archive check and report copy; standing remains unverified. The result is22.87% oracle/11.21% complete-query instruction reduction on the fixed ECC2K-130 uniform control against the optimized kernel, not a native-runtime or pipeline claim [pcc:unverified].

### Decisions made (and why)

- Publish this completed index-calculus-only optimization in a new regular lane PR because3744 merged. Fetch main before journal append. If shared metadata conflicts, preserve both whole histories and immutable claims/proofs while retaining actual main prefix; do not choose/drop either history or alter scientific results.

### Open threads (unfinished, pick up next time)

- Commit/push final result, reconcile shared metadata with current main if required, open regular lane PR with auto-merge, verify remote contents and actual checks/custody. Existing full-root/SAT and inherited missing-claim-type failures remain explicit.

### Errors (what went wrong, how it was handled)

- No new numerical or replay failure. Corrected a report multiplication glyph before final pinning; preserved original protocol narrative and put prose-only lint repair in its v2 companion. All raw data and frozen result proofs remain unchanged [pcc:unverified].
