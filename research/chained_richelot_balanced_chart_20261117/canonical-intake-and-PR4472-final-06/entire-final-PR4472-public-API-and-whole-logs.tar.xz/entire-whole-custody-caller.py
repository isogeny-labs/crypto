"""Whole final-head provider custody; metadata and archive I/O only."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib, json, shutil, stat, urllib.request, zipfile, lzma

h = Path('/dev/shm/ct671-final4472-CI')
response = json.loads((h/'private/native11-download.json').read_text())['structuredContent']
url = response['file_uri']['download_url']; assert url.startswith('https://')
archive = h/'entire-final-a60-native11-provider-artifact.zip'
assert not archive.exists()
with urllib.request.urlopen(url, timeout=60) as inp, archive.open('xb') as out:
    shutil.copyfileobj(inp, out)
raw_zip = archive.read_bytes()
assert len(raw_zip)==3675419
assert hashlib.sha256(raw_zip).hexdigest()=='3d961e8ae7779970e370e2c26d961cbe2ca39652e8c0d14c86580abc83f9ff04'
inventory=[]; root_members={}
with zipfile.ZipFile(archive) as z:
    for m in z.infolist():
        path=PurePosixPath(m.filename)
        assert not path.is_absolute() and '..' not in path.parts
        assert stat.S_IFMT(m.external_attr>>16) in (0,stat.S_IFREG,stat.S_IFDIR)
        if m.is_dir(): continue
        raw=z.read(m); assert len(raw)==m.file_size
        inventory.append({'path':m.filename,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
                          'CRC32':m.CRC,'provider_mode':stat.S_IMODE(m.external_attr>>16)})
        if len(path.parts)==1: root_members[m.filename]=raw
phases=[line.split() for line in root_members['actual-phases.txt'].decode().splitlines()]
assert len(phases)==28 and all(p[1]==p[2].removeprefix('expected') for p in phases)
local=Path('/workspace/scratch/ct637-first-frozen-trace-audit11-unit-01/original-positive-audit.entire-stdout.txt').read_bytes()
assert local==root_members['original-positive.entire-stdout.txt']==root_members['audit-timing-only.entire-stdout.txt']
negatives=[]
for control in ['forward-coordinate','drop-projective','duplicate-forward','sign-relation','summary-coefficient','lost-infinity']:
    assert root_members['generate-'+control+'.exit'].strip()==b'0'
    assert root_members['audit-'+control+'.exit'].strip()==b'1'
    assert root_members['audit-'+control+'.entire-stderr.txt'].startswith(b'audit rejected: ordered event ')
    assert len(root_members[control+'.entire-transcript.txt'])>280000
    negatives.append({'control':control,'exit':1,'whole_rejection':root_members['audit-'+control+'.entire-stderr.txt'].decode()})
for name in ['validation','artifacts','migration','learning','size','native11']:
    obj=json.loads((h/(name+'-log-response.json')).read_text())
    log=obj['structuredContent']['content'].encode()
    (h/(name+'-entire-job.log.xz')).write_bytes(lzma.compress(log))
    assert lzma.decompress((h/(name+'-entire-job.log.xz')).read_bytes())==log
(h/'ENTIRE_FINAL_NATIVE_ZIP_MEMBER_INVENTORY.json').write_text(json.dumps(inventory,indent=2)+'\n')
scope={'time':datetime.now(timezone.utc).isoformat(),'actual_final_head':'a60bc0186bf3e057473f7f5d1dd5307424391466',
       'run':43995846107,'job':133747593537,'artifact':14290136722,'whole_provider_zip_bytes':len(raw_zip),
       'whole_provider_zip_sha256':hashlib.sha256(raw_zip).hexdigest(),'all_regular_members':len(inventory),
       'all_member_CRC_SHA_checks':True,'all_native_phases':phases,'full_two_positive_outputs_equal_local_first_11':True,
       'all_six_negative_controls':negatives,'source12_absent_on_actual_final_head':True,
       'scope':'Same-author frozen trace auditor replay on another host. No producer execution, signed verification, native12 CI or all-green merge inference.'}
(h/'ACTUAL_FINAL_PR4472_NATIVE_SCOPE.json').write_text(json.dumps(scope,indent=2)+'\n')
print('provider zip',len(raw_zip),'members',len(inventory),'phases',len(phases),'whole positive outputs equal original',True)
