# crypto — Comprehensive Educational Cryptography Library

[OpenResearch setup and agent integration](docs/openresearch.md).

A from-scratch implementation of the major cryptographic algorithm families in Rust,
plus a substantial **cryptanalysis suite** for studying how those algorithms break.
Every algorithm is documented with the underlying mathematics, making this a study
companion as much as a working library.

[Lean retrospective, 2026-10-18](research/lean_retrospective_20261018/README.md):
checked subgroup-transport and factor-base lemmas, exact proof scope, and
remaining historical-coverage obligations.
[Backend performance frontier](docs/backend-leaderboard/index.html) ·
[Machine-readable leaderboard](docs/backend-leaderboard/leaderboard.json) ·
[How agents measure and beat an incumbent](docs/ecbench/BACKEND_FRONTIER.md).
Compare F4, F5, F6-IC, root finding and SAT by exact workload, including cold
operation time, solver counters and explicit gaps in field-size coverage.

> ## ⚠️ DO NOT USE IN PRODUCTION
>
> This library is **not safe** for any real use case where confidentiality,
> integrity, or authenticity matters.  It is an educational reimplementation
> intended for studying the algorithms.
>
> **What is wrong with it:**
> - **Not constant-time.** All big-integer arithmetic uses `num-bigint`,
>   which branches on secret values.  Every RSA, ECDSA, ECDH, and ECC
>   operation leaks via timing.  AES uses a lookup-table S-box vulnerable
>   to cache-timing attacks.
> - **No third-party audit.**
> - **Two Kybers.**  `pqc::ml_kem` is real FIPS 203 ML-KEM (validated
>   against the NIST ACVP vectors, but still not constant-time);
>   `pqc::kyber` is a pre-standard toy that is *not* compatible with
>   FIPS 203 and is kept only for comparison.
> - **Toy McEliece parameters** (m=6, n=32, t=3) — far below any security
>   level.
>
> See [`SECURITY.md`](SECURITY.md) for the full list of structural
> limitations and recommended audited alternatives (`aws-lc-rs`, `ring`,
> RustCrypto, dalek, etc.).

---

## Repository layout

| path | what lives there |
|:--|:--|
| `src/`, `tests/`, `examples/` | the Rust library, its tests and runnable examples |
| `research/notes/` | every research note, grouped by theme; start at [`research/notes/README.md`](research/notes/README.md) |
| `research/<topic>_<date>/` | frozen experiment directories (harness, contract, results) that the notes cite |
| `experiments/`, `figures/` | older frozen run outputs and plots referenced by the notes |
| `isolab/` | standalone experiment execution environment: NATS hub, Linux workers with enforced measurement fidelity, MCP server; see [`isolab/README.md`](isolab/README.md) |
| `spotlab/` | resumable throughput jobs on the cheapest AWS/GCP spot capacity: checkpoints in S3/GCS, automatic resume after preemption, MCP server; not a measurement environment; see [`spotlab/README.md`](spotlab/README.md) |
| `docs/` | published pages (`index-calculus-scoreboard.html`, `algorithm-lab.html`, the ECC2K-130 status site), guides and primers in `docs/guides/`, the roadmap in `docs/DEFERRED.md` |
| `ecc2k130/`, `gpu/`, `hdl/` | the ECC2K-130 rho campaign: fleet tooling, GPU kernels, FPGA cost models |
| `sage/`, `scripts/`, `secp256k1_cm_audit/`, `cd_attack/`, `quantum_circuit_secp256k1/` | Sage/PARI/Python companions to specific notes |
| `papers/` | manuscript sources, one directory per paper (`papers/README.md` is the index) |
| [`problems/`](problems/README.md) | named research and audit blockers, supporting evidence, and concrete conditions for moving past them |
| [`backlog/`](backlog/README.md) | experiments we would like to run: one validated card each (`backlog validate`), leased and run through cairn, results landed in `research/` by PR |
| `AGENTS.md` | the reporting convention (boundary, table, ratio) every research thread follows |

## Quick tour

The dedicated [`isogeny` executable](tools/isogeny-cli/README.md) screens P192/P224
prime degrees, constructs explicit isogenies, and verifies their certificates.
Download its platform archive from [Releases](https://github.com/aburan28/crypto/releases)
and run it directly:

```sh
isogeny search --curve p224 --ell 1471 --out ./p224-1471
isogeny search --curve p192 --ell 10453 --out ./p192-10453
isogeny verify --input ./p224-1471
isogeny curves
isogeny search --curve P-384 --ell 19 --out ./p384-19
isogeny search --curve P-521 --ell 7 --out ./p521-7
```

The executable embeds its algorithms and standard curve data. The kernel route at
these two degrees constructs one Frobenius eigenline of two and labels coverage
`PARTIAL`. The repository's Release workflow builds the platform archives and
publishes them through ReleaseMe; PR runs test the archives before publication.
# Root-finding decomposition engine in ecbench: results

For the Bochum v0.2 hashed-factor-base algorithm, see the
[native Rust tensor implementation](docs/hashed-ecdl.md): compact encodings,
exact contraction, relation collection and certificate replay. Correctness
controls do not establish the conditional asymptotic bound or a speedup.

The [Hexagon complexity integration](research/hexagon_cscc_20261030/README.md)
adds exact divisor-prefix factorization, bounded weighted cost profiles, three
prime-field factor-base recipes, and a searchable, version-pinned review of all
22 works in the `cs.CC` collection on 2026-10-30. Its implementation and proof
statuses are recorded separately.

The separately scoped [scalar tensor companion](docs/hashed-ecdl.md#scalar-tensor-companion)
in cryptanalysis adds binary/prime-field coordinate checks and Certicom ECCp-131
inputs. No Python execution path is introduced here and neither challenge is solved.

**Decision: engineering.** The new oracles verify, replay identically, and
match the query stream of the existing table/subtract arms; they do not
change the asymptotic group-operation count of the decomposition, so
nothing here is an *advance*. Against Gröbner (`inherited-f4`) the root
finder's `S` is a complete count beside a lower bound and is not a
speedup. Against `mitm` / `subtract` the ops ratio is 1 (same stream);
wall time on this L0 macOS host is descriptive only and favours the root
finder. No security claim; no ECC2K-130 inference.

| | |
|---|---|
| protocol | [`PROTOCOL.md`](PROTOCOL.md) (committed before any session ran) |
| engine ids | `pdp3-koblitz:m=2\|3,engine=rootfind`; `rootfind-subtract:m=2\|3` (see `docs/ecbench/README.md` §7) |
| specs | `docs/ecbench/specs/smoke-koblitz-rootfind.json`, `smoke-prime-rootfind.json`, `claim-koblitz-rootfind-n13.json`, `claim-koblitz-rootfind-n19.json`, `panel-prime-rootfind.json` |
| binary | `ecbench` release SHA-256 `1e972df4d8e769629ad4fd4a023214b05ee513a2cfea6f3ef51f2ca9e61fe531` |
| host | Apple M4 Pro, 14 logical CPUs, macOS 25.6.0 aarch64; env class `ECBENV2h59034d4cd61b`; `--cpus none --allow-busy` → every run **L0** |
| classification | **engineering** (same decomposition work, faster constant / cleaner charge); accounting vs Gröbner lower bounds |

## Complete sessions

| session | id | records | audit | replay cert (SHA-256 of audit JSON) |
|---|---|---:|---|---|
| [`sessions/smoke-koblitz`](sessions/smoke-koblitz) | `ECBS1hd86e5cfc2b77` | 42/42 verified | OK | `1cb597b686e68d783c8c370806686740ef316e862ebd191b6482470f2605c2b5` |
| [`sessions/smoke-prime`](sessions/smoke-prime) | `ECBS1hb8f2623c82e2` | 36/36 verified | OK | `bfb3f0207a2ae4f57ee8e176bd3cd05e44b8eb0d108340f70d4323e647188a1f` |
| [`sessions/claim-n13`](sessions/claim-n13) | `ECBS1hfd5bf1885227` | 224/224 verified | OK at `2245b75`, 168/168 replays identical; **pre-#2043**: replayable only by its recording binary (lazy inherited-F4 charge) | `8e6a76596041d9a182e2584b9844ecf4846d827e32fbb1c9e3bd3d68e36a19ae` |
| [`sessions/claim-n13-v2`](sessions/claim-n13-v2) | `ECBS1h396db1437f4a` | 224/224 verified | OK on `main` `2b9f3f72f`, 168/168 replays identical, run twice; accounting version 2 | `59e7e2bf46ffaa1716e069e1a400d0f77e5bff43b87b0729b4e7f902d76e3bac` |
| [`sessions/panel-prime`](sessions/panel-prime) | `ECBS1h045961daac5c` | 768/768 verified | OK, 576/576 replays identical | `19d4aba584a99a48c46fd7b70262d31972a6d11770771826e2c5ac10a49d74ce` |
| [`sessions/claim-n19`](sessions/claim-n19) | `ECBS1h52e3269d5dab` | 224/224 verified | OK, 168/168 replays identical | `f3a3105be311cee69d7c2328a283a3c7632739136d832fd86d9de6e30998136d` |

Incomplete starts kept under [`abandoned/`](abandoned/) (SIGKILL / shell detach
at mid-session; status left as recorded).

## Boundary and unit

As in [`PROTOCOL.md`](PROTOCOL.md): floor `√(π/2A)` in `S`; reference
`rho.signed_frobenius_strong` (Koblitz) / `rho.negation` (prime); cold
`S` with every phase charged. Gröbner arms mark `lower bound` (word XORs
counted, not charged). Root-finding Koblitz arms are complete counts.

## Tables (mean `S`, L0)

Full `ecbench table` output: [`tables/`](tables/). Headline cells:

### Koblitz `E_0`, `n=13`, `d=5` (`claim-n13`, 8 public targets × 3 rounds)

| arm | oracle | mean S | S / strong-rho | lower bound |
|---|---|---:|---:|---|
| `rho-strong` | — | 14.118 | 1.000 | yes |
| `rho-frob` | — | 1.871 | 0.133 | yes |
| `ic-f4-m3` | `pdp3-koblitz:m=3,engine=inherited-f4,…` | 15.928 | 1.128 | yes |
| `ic-rootfind-m3` | `pdp3-koblitz:m=3,engine=rootfind` | 38.822 | 2.750 | **no** |
| `ic-f4-m2` | `pdp3-koblitz:m=2,engine=inherited-f4,…` | 16.642 | 1.179 | yes |
| `ic-rootfind-m2` | `pdp3-koblitz:m=2,engine=rootfind` | 28.383 | 2.010 | **no** |

`ic-rootfind-m3 / ic-f4-m3` ops = 2.44 [2.35, 2.53] is **diagnostic only**
(complete count over a lower bound). Descriptive solve-wall sums over the
24 measured runs: F4-m3 5.70 s vs rootfind-m3 0.13 s (~43×); F4-m2 0.45 s
vs rootfind-m2 0.12 s (~3.6×). Not admitted (L0).

**Re-recorded under accounting version 2 (`claim-n13-v2`, 2026-10-28).** The owner made
the eager inherited-F4 charge (post-#2043, version 2) the method identity, so the table above
is pre-#2043. The same spec on `main` gives identical rho and root-finder S. The inherited-F4
arms are now complete counts rather than lower bounds: `ic-f4-m3` 534.859 [476.5, 600.4]
(37.9× strong rho), `ic-f4-m2` 35.758 [30.5, 41.9] (2.53×). That is an accounting change, not a
regression. With both engines complete, `ic-rootfind / ic-f4` ops is 0.0726 (m3) and 0.7938 (m2),
but the §5a band (0, 0.1 and 1 GAE per unpriced operation) is unresolved for both pairs, so
neither engine ranks above the other. The IC replay plan and the backend leaderboard
(`docs/backend-leaderboard/`) cite `claim-n13-v2`. Report, graph and PDF:
[`reports/run-20261028T0403Z/`](reports/run-20261028T0403Z/REPORT.md).

Smoke Koblitz: `ic-rootfind-m2 / ic-mitm-m2` ops = **1.000** [1.000, 1.000]
(identical `S` and query stream).

### Koblitz `E_0`, `n=19`, `d=7` (`claim-n19`, 8 public targets × 3 rounds)

| arm | mean S | S / strong-rho | lower bound |
|---|---:|---:|---|
| `rho-strong` | 3.163 | 1.000 | yes |
| `ic-f4-m3` | 4.904 | 1.550 | yes |
| `ic-rootfind-m3` | 53.996 | 17.072 | yes |
| `ic-f4-m2` | 8.097 | 2.560 | yes |
| `ic-rootfind-m2` | 34.688 | 10.967 | yes |

Two sizes are not a scaling claim. Rootfind remains above rho and above the
Gröbner lower-bound `S` (complete charged table work vs uncharged solver XORs).

### Prime panel (18/20/22/24-bit `prime_search`, seeds of
`research/ecbench_all_candidates_20261003/spec-prime.json`)

| arm | 18-bit mean S (ref×) | 20-bit | 22-bit | 24-bit |
|---|---:|---:|---:|---:|
| `rho-neg` | 1.294 (1.00) | 1.344 | 1.480 | 1.080 |
| `ic-subtract` | 310 (239×) | 449 | 927 | 2775 |
| `ic-rootfind-m2` | 310 (239×) | ≈subtract | ≈subtract | ≈subtract |
| `ic-mitm` | 9.96 (7.7×) | 10.5 | 16.2 | 43.7 |
| `ic-rootfind-m3` | (see table) | | | |

`ic-rootfind-m2 / ic-subtract` ops = **1.000** [1.000, 1.000] over 96 pairs
(same candidates, same relations; GAE differs by one re-addition per
relation; `inversions` counted uncharged). Descriptive solve-wall:
subtract / rootfind-m2 ≈ 2.5× over the panel.

No IC arm is below rho on these curves.

## Hypotheses (from PROTOCOL)

- **H1:** every root-finding run verified; every audit replay `identical`. **Met.**
- **H2:** same stream as control oracles where the control completes. **Met**
  for `rootfind-m2` vs `mitm-m2` (Koblitz smoke) and vs `subtract` (prime panel).
- **H3:** root-finding solve wall below Gröbner at `m=3` on completed
  workloads. **Met descriptively** on claim-n13 (L0, not admitted).

## Inadmissible / caveats

- All wall figures are L0 on a shared macOS host (load often ≫ 1); do not
  cite them as admitted speedups.
- Two Koblitz sizes ≠ a scaling claim (AGENTS.md §5).
- Do not divide rootfind `S` by Gröbner `S`.
- Interrupted first attempts of claim-n13 are under `abandoned/`, not in the scoreboard.

## Reproduce

```bash
# Build
cargo build --release

# Run the protocol demos
cargo run --release -- demo

# Hash a string
cargo run --release -- hash sha256 "hello world"

# Auto-run every applicable cryptanalysis attack against a named cipher
cargo run --release -- cryptanalysis auto --cipher toyspn-2r
cargo run --release -- cryptanalysis auto --cipher aes-2r

# Discover what attacks/ciphers are registered
cargo run --release -- cryptanalysis list-ciphers

# Run the full empirical research bench
cargo run --release -- cryptanalysis bench

# Tests (all 843 of them)
cargo test --release
```

---

## Index-calculus research executable

The standalone ic command supports named/custom curve inspection, generated
known-answer experiments, and bounded factor-base comparisons with live
stage reporting.

    cargo build --release --bin ic
    ./target/release/ic ecc2k-130
    ./target/release/ic run --degree 11 --curve-a 1 --known-log 53 --solver enumerate
    ./target/release/ic generate --degree 9 --seed 42 --out fixture.json
    ./target/release/ic inspect --file fixture.json
    ./target/release/ic compare --degree 7 --curve-a 1 --samples 3 --holdout 2 --json

Imported points are inspected only. Synthetic runs retain the library's
small-curve limits and verify their known answers. Comparison reports include
unsuccessful candidates, separate holdout checks, time and memory measurements,
and explicitly bounded conclusions.

See [the ic guide](docs/ic/README.md) for the parameter schema, capabilities,
limits, resource accounting, and report semantics. The original crypto
command remains the default for cargo run.

The [EC index-calculus baseline](research/index_calculus_baseline_20260914/README.md)
adds counting bounds, an operation-accounting contract, and a certified WDSat control
with frozen measurements and reproducible commands.

## Elliptic-curve surface tools

[`tools/ecdlp-surfaces`](tools/ecdlp-surfaces/README.md) is a standalone Rust
crate with three command-line tools: `surface_search` enumerates containing
quadrics, `transfer_check` checks the transported group law and prime subgroup,
and `frobenius_filter` applies necessary conditions to supplied abelian-surface
polynomials. Point arithmetic uses small prime fields, up to 10,000. Equivalent
embeddings preserve the ECDLP; no destination-solver speedup is established.
The [report](docs/ecdlp-surfaces/REPORT.md) includes the diagram, PDF, fixtures,
and native identity certificates. Run `tools/ecdlp-surfaces/check.sh` to validate
the crate and replay its examples.

For genus-2 and higher Jacobian transfers, use the
[`ecdlp-surfaces` skill](.agents/skills/ecdlp-surfaces/SKILL.md) and its
[higher-genus reference](.agents/skills/ecdlp-surfaces/references/higher-genus.md)
for the existing cover/arithmetic tools, native pullback APIs, and construction
and subgroup-validation requirements.

## Isogeny walks

`isogeny_walk` walks a prime-field curve's isogeny class (P-256, P-224,
P-192 or a custom curve).

- **Certified.** Every isogeny is certified by an explicit kernel
  polynomial, and every curve is recorded with its ICV1/EC1 identity and
  traits.
- **Stored.** Runs can be stored in S3, write-once and hash-checked.

    cargo build --release --bin isogeny_walk
    ./target/release/isogeny_walk walk --curve p256 --max-ell 61 --max-curves 2000 --out runs/p256
    ./target/release/isogeny_walk verify --curve p256 --dir runs/p256
    ./target/release/isogeny_walk walk --curve p256 --max-ell 61 --max-curves 20000 \
        --store s3://crypto-autoresearcher/isogeny-walk --prune-local --out runs/p256-20k

See [the isogeny-walk guide](docs/isogeny-walk/README.md) for:
- every command;
- S3 setup and IAM;
- offline use;
- sizing;
- what the tool does and does not establish.

## Algorithm coverage

### Symmetric primitives

| Module                    | Algorithm                            | Standard / Origin           |
|---------------------------|--------------------------------------|-----------------------------|
| `symmetric::aes`          | AES-128 / AES-256 + CTR + GCM        | FIPS 197 / SP 800-38A,D     |
| `symmetric::aes_cbc`      | AES-CBC                              | NIST SP 800-38A             |
| `symmetric::chacha20`     | ChaCha20 + Poly1305 + AEAD           | RFC 8439                    |
| `symmetric::serpent`      | Serpent block cipher                 | Anderson–Biham–Knudsen 1998 |
| `symmetric::threefish`    | Threefish (Skein tweakable cipher)   | Skein NIST submission        |
| `symmetric::sm4`          | SM4 Chinese national block cipher    | GB/T 32907                  |
| `symmetric::gost_magma`   | GOST R 34.12-2015 Magma (64-bit)     | GOST R 34.12-2015           |
| `symmetric::kuznyechik`   | GOST R 34.12-2015 Kuznyechik (128-bit) | GOST R 34.12-2015           |
| `symmetric::cmac`         | CMAC-AES MAC                          | NIST SP 800-38B             |
| `symmetric::des`          | DES (Data Encryption Standard, broken — teaching) | FIPS PUB 46-3 |
| `symmetric::des3`         | Triple-DES (EDE3, deprecated by NIST 2017)   | NIST SP 800-67  |
| `symmetric::rc4`          | RC4 stream cipher (broken — teaching) | Rivest 1987 / RFC 6229 vectors |
| `symmetric::rc5`          | RC5-32/12/16 block cipher             | Rivest, FSE 1994            |

### Block-cipher modes (generic over `BlockCipher<N>` trait)

The `symmetric::modes` submodule hosts modes that work against any
[`BlockCipher<N>`] implementor — AES, SM4, Serpent, Kuznyechik, Magma.

| Mode                            | Type                           | Standard               |
|---------------------------------|--------------------------------|------------------------|
| `modes::ecb` (PKCS#7 padded)    | Confidentiality (broken — teaching only) | NIST SP 800-38A §6.1 |
| `modes::cfb`                    | Self-synchronising stream      | NIST SP 800-38A §6.3   |
| `modes::ofb`                    | Pre-computable keystream       | NIST SP 800-38A §6.4   |
| `modes::ccm`                    | **AEAD** (Counter + CBC-MAC)   | NIST SP 800-38C / RFC 3610 |
| `modes::siv`                    | **AEAD, misuse-resistant** (deterministic) | RFC 5297            |
| `modes::eax`                    | **AEAD** (three-CMAC construction)         | Bellare-Rogaway-Wagner FSE 2004 |
| `modes::ocb3`                   | **AEAD** (single-pass, offset-codebook)    | RFC 7253 |
| `modes::gcm_siv` (+ POLYVAL)    | **AEAD, nonce-misuse-resistant** (GCM variant) | RFC 8452 |
| `modes::kw`                     | Deterministic key wrap         | NIST SP 800-38F / RFC 3394 |
| `modes::xts`                    | Disk encryption (ciphertext stealing) | IEEE P1619 / NIST SP 800-38E |

### Hashes / XOFs

| Module           | Algorithm                  | Standard                |
|------------------|----------------------------|-------------------------|
| `hash::md4`      | MD4 (broken — teaching/target)  | RFC 1320            |
| `hash::md5`      | MD5 (broken — teaching/target)  | RFC 1321            |
| `hash::sha256`   | SHA-224 / SHA-256          | FIPS 180-4              |
| `hash::sha512`   | SHA-384 / SHA-512          | FIPS 180-4              |
| `hash::sha3`     | SHA3-256/512, SHAKE128/256 | FIPS 202 (Keccak)       |
| `hash::blake3`   | BLAKE3                     | BLAKE3 spec (via crate) |
| `hash::ripemd160`| RIPEMD-160                 | ISO/IEC 10118-3         |
| `hash::siphash`  | SipHash-2-4                | Aumasson–Bernstein 2012 |
| `hash::sm3`      | SM3 Chinese national hash  | GB/T 32905              |
| `hash::streebog` | GOST R 34.11-2012 (256/512)| GOST R 34.11-2012       |

### Hash-function cryptanalysis

Generic attacks over the `HashFunction` / `MerkleDamgardHash` trait:

| Attack                                  | Module                     | Notes                                |
|----------------------------------------|----------------------------|--------------------------------------|
| **Length-extension attack**            | `cryptanalysis::hash_attacks::length_extension_attack` | Works against any MD-Damgård hash used as `H(secret \|\| msg)` MAC.  Tested on MD4, MD5, SHA-1. |
| **Birthday-collision search**          | `cryptanalysis::hash_attacks::birthday_collision_search` | Generic `√(2^b)` collision finder over a truncated hash. |
| **Joux multicollision** (CRYPTO 2004)  | `cryptanalysis::hash_attacks::joux_multicollision` | Chain `t` collisions → `2^t` equivalent messages at cost `t · 2^(b/2)`. |
| **Differential bias**                  | `cryptanalysis::hash_attacks::differential_bias` | Per-output-byte bias measurement on a chosen input differential. |
| **MD5 Wang differential**              | `cryptanalysis::md5_differential` | Reduced-round near-collision finder. |
| **SHA-1 differential**                 | `cryptanalysis::sha1_differential` | Round-function table + near-collision search. |

CLI:

```bash
# Isogeny-volcano tools (docs/volcano/README.md)
crypto volcano profile --koblitz-n 83 --ell 6473        # conductor, depth, level tables
crypto volcano koblitz-step --n 131 --ell 263          # ECC2K-130: the 262 level-1 neighbours over F_(2^131)

# Auto-run every applicable hash attack
crypto cryptanalysis hash-auto --hash md5
crypto cryptanalysis hash-auto --hash md4
crypto cryptanalysis hash-auto --hash sha1
crypto cryptanalysis hash-differential-observed --algorithm sha256 --input docs/ic/fixtures/hash_differential_sha256_public.json
crypto cryptanalysis hash-differential-observed --algorithm sha3-256 --input docs/ic/fixtures/hash_differential_sha3_256_public.json

# Length-extension demo (interactive)
crypto cryptanalysis length-extension --hash sha1 \
    --secret-len 16 --message-hex "&role=guest" \
    --suffix-hex "&role=admin" --digest-hex <hex>

# AES related-key attack: key-schedule diffusion + avalanche + local collision
crypto cryptanalysis aes-related-key --key-bits 256 --rounds 4
crypto cryptanalysis aes-related-key --key-bits 128 --rounds 4 --avalanche-trials 1024

# Exact one-round S-box DDT entry and four MixColumns shifted differences.
# The combined probability uses an explicit independent-S-box-call assumption.
crypto cryptanalysis aes-related-differential --alpha 1 --beta 1
crypto cryptanalysis aes-sbox-table --kind ddt --row 1  # 256 exact XOR-difference counts
crypto cryptanalysis aes-sbox-table --kind lat --row 1  # 256 signed linear-bias counts
crypto cryptanalysis aes-sbox-table --kind ddt > aes-ddt.json  # all 256 rows
crypto cryptanalysis aes-differential-statistics --input docs/ic/fixtures/aes_differential_statistics_public.json
crypto cryptanalysis aes-linear-statistics --input docs/ic/fixtures/aes_linear_statistics_public.json

# AES visual demos — ASCII art for every major attack
crypto cryptanalysis aes-visual-demo --demo all              # all four below
crypto cryptanalysis aes-visual-demo --demo truncated-diff   # 4-round trail grid
crypto cryptanalysis aes-visual-demo --demo integral         # 3-round Square balance
crypto cryptanalysis aes-visual-demo --demo dfa              # Piret-Quisquater fault diff
crypto cryptanalysis aes-visual-demo --demo key-schedule     # AES-128 vs AES-256 diffusion

# Visual demos for every NON-AES attack module
crypto cryptanalysis visual-all --target all                 # full bundle (Markdown)
crypto cryptanalysis visual-all --target sbox-ddt            # DDT heat-maps (AES + Serpent + PRESENT)
crypto cryptanalysis visual-all --target sbox-lat            # LAT heat-maps
crypto cryptanalysis visual-all --target walsh               # Walsh-Hadamard signed spectrum bars
crypto cryptanalysis visual-all --target pollard-rho         # ρ-iteration trajectory plot
crypto cryptanalysis visual-all --target hnp                 # HNP recovery probability curve
crypto cryptanalysis visual-all --target bleichenbacher      # nonce-bias histogram
crypto cryptanalysis visual-all --target length-extension    # MD-Damgård chain diagram
crypto cryptanalysis visual-all --target joux                # multicollision tree
crypto cryptanalysis visual-all --target j0-twists           # twist factor-size bars
crypto cryptanalysis visual-all --target birthday            # cumulative collision-probability curve
```

### Library-wide visual demos

Beyond the cryptanalysis-side visualizations, every major module
ships ASCII-art demos:

```bash
# Symmetric ciphers
crypto visual symmetric --target ecb-penguin   # leak structure through ECB
crypto visual symmetric --target modes         # CBC/CFB/OFB/CTR/GCM/CCM/SIV/XTS/KW dataflow
crypto visual symmetric --target aes-trace     # 11 AES-128 state grids round-by-round
crypto visual symmetric --target chacha        # ChaCha20 4×4 word state evolution
crypto visual symmetric --target avalanche     # AES avalanche heat-map at 1/2/3/5/10 rounds

# Hash functions
crypto visual hash --target md                 # Merkle-Damgård chain (MD5/SHA-2/RIPEMD)
crypto visual hash --target sponge             # SHA-3 / SHAKE sponge construction
crypto visual hash --target blake3             # BLAKE3 binary-tree mode
crypto visual hash --target sha256-trace       # SHA-256 working-variable trace
crypto visual hash --target avalanche          # MD5 vs SHA-256 single-bit avalanche

# Elliptic curves
crypto visual ecc --target curve               # scatter plot of points on toy F_p curve
crypto visual ecc --target ops                 # point-add and point-double geometric diagrams
crypto visual ecc --target ladder              # double-and-add scalar-mul trace
crypto visual ecc --target ecdsa               # ECDSA sign/verify dataflow

# Everything at once
crypto visual all

# Color control
crypto --color always visual symmetric --target ecb-penguin    # force colors
crypto --color never  visual ecc       --target curve          # plain text
CRYPTO_COLOR=always crypto visual hash --target sponge         # via env var
NO_COLOR=1 crypto visual all                                   # standard NO_COLOR
```

**ANSI colors**: every visual renderer emits ANSI colors when stdout
is a TTY.  Heat-maps grade `dim → blue → green → yellow → red` (low
to high); state grids highlight non-zero bytes in **yellow**; active
patterns paint `▓` in **bright red**; signed bars are **green** for
positive, **red** for negative; recovery progress bars are **green
filled, dim unfilled**; verdict markers (`✓ ✗ ⚠`) get their canonical
colors.  Set `NO_COLOR=1` or `--color never` to suppress.

### Visual output samples

The `aes-visual-demo` subcommand renders ASCII diagrams.  For example,
`--demo truncated-diff` shows the classical wide-trail AES diffusion:

```
        input      R1 SR      R2 SR      R3 SR      R4 SR
  row 0    ▓ · · ·    ▓ · · ·    ▓ · · ·    ▓ ▓ ▓ ▓    ▓ ▓ ▓ ▓
  row 1    · · · ·    · · · ·    · · · ▓    ▓ ▓ ▓ ▓    · · · ·
  row 2    · · · ·    · · · ·    · · ▓ ·    ▓ ▓ ▓ ▓    · · · ·
  row 3    · · · ·    · · · ·    · ▓ · ·    ▓ ▓ ▓ ▓    · · · ·

**Active S-boxes per round**

round  0 │█                              1
round  1 │███████                        4
round  2 │██████████████████████████████ 16
round  3 │███████                        4

**Total active S-boxes** N = 25, Pr ≤ 2⁻¹⁵⁰
```

The same machinery powers every other attack's test output — run any
`#[ignore]`-flagged `demo_*` test with `--nocapture` to see it.

### Elliptic-curve cryptography

| Module                | Algorithm / Curve                                           | Standard               |
|-----------------------|-------------------------------------------------------------|------------------------|
| `ecc::field` / `point`| Generic short-Weierstrass arithmetic                        | SEC 1                  |
| `ecc::curve`          | secp256k1, P-256                                            | SEC 2, FIPS 186-4      |
| `ecc::curve_zoo`      | Brainpool {160,192,224,256,320,384,512} r1, FRP256v1, NIST P-{192,224,384,521}, SECG k-curves, GOST tc26 paramsets | RFC 5639 / FIPS 186-4 / SEC 2 / GOST |
| `ecc::p256_field`     | Optimised P-256 field arithmetic (Solinas reduction)        | FIPS 186-4             |
| `ecc::secp256k1_*`    | Optimised secp256k1 field + Jacobian coordinates            | SEC 2                  |
| `ecc::ct`             | Constant-time scalar multiplication primitives              | —                      |
| `ecc::curve25519`     | Curve25519 prime field                                      | RFC 7748               |
| `ecc::x25519`         | X25519 ECDH                                                 | RFC 7748               |
| `ecc::ed25519`        | Ed25519 EdDSA signatures                                    | RFC 8032               |
| `ecc::ecdsa`          | ECDSA with RFC 6979 deterministic nonces                    | FIPS 186-4 + RFC 6979  |
| `ecc::barrett_ecdsa`  | ECDSA with Barrett-reduced fields                           | —                      |
| `ecc::ecdh`           | ECDH key exchange                                           | RFC 8422               |
| `ecc::schnorr`        | Schnorr signatures (BIP-340 flavour)                        | BIP-340                |
| `ecc::sm2`            | SM2 signature + encryption + ZA                             | GB/T 32918             |
| `ecc::gost_3410_2012` | GOST R 34.10-2012 signature (256/512)                       | GOST R 34.10-2012      |
| `ecc::ec_kcdsa`       | Korean EC-KCDSA (Q = x⁻¹·G convention)                       | TTAS.KO-12.0011        |
| `binary_ecc`          | Binary-field ECC over F_{2^m}                                | NIST B-curves          |

### Pairings

| Module        | Algorithm                                | Notes                       |
|---------------|------------------------------------------|-----------------------------|
| `bls12_381`   | BLS12-381 pairing-friendly curve         | Optimal Ate pairing, Fq/Fq2/Fq6/Fq12 towers |

### Asymmetric / public-key

| Module                      | Algorithm                          | Standard         |
|-----------------------------|------------------------------------|------------------|
| `asymmetric::rsa`           | RSA keygen (Miller-Rabin), enc, sig, CRT-CT decrypt | PKCS#1 / RFC 8017 |
| `asymmetric::paillier`      | Paillier additively-homomorphic encryption | Paillier 1999 |
| `asymmetric::elgamal`       | ElGamal encryption (multiplicative group) | ElGamal 1985 |
| `asymmetric::ec_elgamal`    | EC-ElGamal (point-on-curve homomorphic) | — |

### Key derivation / MAC

| Module          | Algorithm                       | Standard   |
|-----------------|---------------------------------|------------|
| `kdf::hkdf`     | HMAC-SHA256, HKDF extract+expand| RFC 5869   |
| `kdf::pbkdf2`   | PBKDF2-HMAC-SHA256              | RFC 8018   |
| `kdf::hmac_drbg`| HMAC-DRBG deterministic RNG     | NIST SP 800-90A |

### Post-quantum (educational)

| Module                       | Algorithm                                | Notes                              |
|------------------------------|------------------------------------------|------------------------------------|
| `pqc::ml_kem`                | ML-KEM-512/768/1024 (Kyber)              | FIPS 203; NIST ACVP KATs pass      |
| `pqc::ml_dsa`                | ML-DSA-65 (Dilithium)                    | FIPS 204; NIST ACVP KATs pass      |
| `pqc::slh_dsa`               | SLH-DSA (SPHINCS+)                       | FIPS 205                           |
| `pqc::sqisign`               | SQIsign (isogeny-based signature)        | Round-3 on-ramp; toy p = 431, BFS in place of KLPT |
| `pqc::uov`                   | UOV (unbalanced oil & vinegar)           | Round-3 on-ramp; toy GF(256) params |
| `pqc::mayo`                  | MAYO (whipped UOV)                       | Round-3 on-ramp; toy GF(16) params |
| `pqc::qr_uov`                | QR-UOV (quotient-ring UOV)               | Round-3 on-ramp; F_31³ blocks, toy |
| `pqc::snova`                 | SNOVA (UOV over a matrix ring)           | Round-3 on-ramp; M₂(GF(16)), toy   |
| `pqc::hawk`                  | HAWK (lattice-isomorphism signature)     | Round-3 on-ramp; toy dim 32        |
| `pqc::fn_dsa`                | FN-DSA / Falcon (NTRU hash-and-sign)     | Draft FIPS 206; toy n = 16, Babai for ffSampling |
| `pqc::sdith`                 | SDitH (syndrome decoding in the head)    | Round-3 on-ramp; MPC-in-the-head, toy |
| `pqc::mqom`                  | MQOM (MQ on my mind)                     | Round-3 on-ramp; MPC-in-the-head, toy |
| `pqc::faest`                 | FAEST (AES in the head)                  | Round-3 on-ramp; MPC-in-the-head, toy |
| `pqc::mpcith`                | Shared MPC-in-the-head proof engine      | Underlies SDitH / MQOM / FAEST     |
| `pqc::kyber`                 | Kyber / ML-KEM (simplified toy)          | Not FIPS-203 compatible            |
| `pqc::frodo`                 | FrodoKEM (LWE-based)                     | Conservative simplified            |
| `pqc::ntru`                  | NTRU lattice cryptosystem                | NTRU encrypt 1996                  |
| `pqc::ntru_prime`            | NTRU Prime (Streamlined / NTRU LPRime)   | NTRU Prime spec                    |
| `pqc::mceliece`              | Educational binary-Goppa McEliece (toy params) | Original 1978 |
| `pqc::classic_mceliece`      | Classic McEliece (NIST round-3) skeleton | NIST round-3 spec                  |
| `pqc::hqc`                   | HQC (code-based KEM)                     | NIST round-3 / round-4             |
| `pqc::bike`                  | BIKE (QC-MDPC code-based)                | NIST round-3                       |
| `pqc::csidh`                 | CSIDH (isogeny-based) — group action     | Castryck–Lange–Martindale–Panny–Renes 2018 |
| `pqc::x_wing`                | X-Wing hybrid (X25519 + ML-KEM)          | draft-connolly-cfrg-xwing-kem      |
| `pqc::fast::ml_kem`          | ML-KEM-512/768/1024, speed-oriented      | Differentially tested against `pqc::ml_kem` |
| `pqc::fast::ml_dsa`          | ML-DSA-65, speed-oriented                | Differentially tested against `pqc::ml_dsa` |
| `pqc::fast::keccak`          | Unrolled Keccak-f[1600] and its sponges  | 2.4x the reference SHA3-256        |
| `pqc::fast::isogeny`         | SQIsign-scale F_p² and 2-power isogenies | p = 3·2³²⁴ − 1, 326 bits; a 2³²⁴-isogeny in 1.8 ms |

Every scheme in the table is reachable from the command line:

```bash
# What is here, and what parameters each one runs at
crypto pqc list

# Run one scheme end to end (keygen, use, and a negative check), or all 25
crypto pqc run --scheme ml-kem-768
crypto pqc run --scheme all

# The guided tour, with commentary
crypto pqc

# The speed-oriented implementations: self-tests, benchmarks, a real
# 2^324-isogeny walk
crypto pqc-fast selftest
crypto pqc-fast bench
crypto pqc-fast isogeny --op chain
```

`pqc run` is a check, not a demo: a KEM must agree on the shared secret *and*
give a different one for a tampered ciphertext; a signature must verify its own
output *and* reject a tampered one. Measured costs for the `fast` modules are in
[`docs/pqc-speed.md`](docs/pqc-speed.md).

### Cryptanalysis of ML-KEM and ML-DSA

Lattice-attack estimates at real parameters, working sieves, and the
implementation attacks that actually recover keys. Full write-up in
[`docs/mlwe-cryptanalysis.md`](docs/mlwe-cryptanalysis.md).

| Module                          | What it does                                                            |
|---------------------------------|-------------------------------------------------------------------------|
| `cryptanalysis::mlwe::cost`     | BKZ profiles (GSA, q-ary z-shape, simulator) and five SVP cost models   |
| `cryptanalysis::mlwe::primal`   | Primal uSVP, two independent conditions; the ML-DSA MSIS forgery side   |
| `cryptanalysis::mlwe::dual`     | Dual, MATZOV-style dual, Ducas–Pulles and Pouly–Shen regime diagnostics |
| `cryptanalysis::mlwe::hybrid`   | Guessing hybrids — and why they do not pay at these parameters          |
| `cryptanalysis::mlwe::sieve`    | Gauss, Nguyen–Vidick and bucketed sieves; progressive BKZ               |
| `cryptanalysis::ml_kem_pco`     | **Full ML-KEM key recovery** from decapsulation leakage, in 8 queries   |
| `cryptanalysis::ml_dsa_leakage` | **Full ML-DSA-65 `s1` recovery** from 4 leaky signatures, then a forgery |
| `cryptanalysis::ml_dsa_fault`   | **Full `s1` recovery** from one faulted signature; three faults         |

```bash
crypto mlwe margins                  # every set against its NIST category floor
crypto mlwe estimate --scheme ml-kem-768 --model gate-count --tours
crypto mlwe kem-pco --param 512      # recover an ML-KEM key and decapsulate with it
crypto mlwe dsa-leak --per-poly 64   # recover ML-DSA s1 and forge
crypto mlwe dsa-fault --fault all    # three faults on the rejection loop
```

Two things the estimators are arranged to prevent, both of which produced wrong
numbers before they were caught: quoting a dual cost without its
contradictory-regime diagnostic, and pairing one attack's cost model with
another's success condition. The doc explains both.

### Zero-knowledge / commitments

| Module                | Algorithm                                       |
|-----------------------|-------------------------------------------------|
| `zk::schnorr_zkp`     | Schnorr identification proof                    |
| `zk::pedersen`        | Pedersen commitments                            |
| `zk::chaum_pedersen`  | Chaum-Pedersen equality-of-discrete-logs proof  |
| `zk::merkle`          | Merkle tree commitments                         |
| `zk::polynomial`      | Polynomial arithmetic over a field              |
| `zk::kzg`             | KZG polynomial commitments                      |
| `zk::bulletproofs`    | Bulletproofs range proofs                       |
| `zk::groth16`         | Groth16 zk-SNARK skeleton: R1CS/QAP layers only; **`verify` is non-functional** (the pairing rejects honest proofs too) |
| `zk::plonk`           | PLONK polynomial IOP: **educational, unaudited, not zero-knowledge, not succinct** (polynomials sent in the clear in place of KZG commitments). The Fiat–Shamir transcript absorbs the circuit and public inputs before any challenge; `check` compares each sent evaluation with its polynomial and then the gate (with public inputs), copy-constraint and `Z(1) = 1` identity at `ζ`, and names the comparison that failed. Soundness is not quantified; must not back a research claim |
| `zk::stark` / `stark_v2` | STARK-style proof skeletons: **educational, unaudited, not zero-knowledge, no grinding, no stated security level; must not back a research claim**. `stark_v2` is DEEP-ALI: coset LDE, composition polynomial, an out-of-domain sample `z` (the AIR checked at `z`) and degree-bounded FRI on the DEEP quotient; its conjectured soundness (Reed–Solomon proximity conjecture, random-oracle Fiat–Shamir) is `ε ≲ β^(−q) + ε_field + ε_hash`, capped at 128 bits by SHA-256 Merkle commitments, over the BLS12-381 scalar field. `stark` is a spot-check argument, not a STARK (see the module docs) |

---

## Cryptanalysis suite

This is the part of the repo that's grown the most.  Every implemented algorithm
above has at least one attack module that *targets it*, plus a generic framework
that makes adding new attacks cheap.

### Core analytical primitives

| Module                                   | What it gives you |
|------------------------------------------|-------------------|
| `cryptanalysis::sbox`                    | DDT, LAT, BCT (Cid et al. 2018), DLCT (Bar-On et al. 2019), truncated DDT, differential / linear uniformity, nonlinearity, algebraic degree, boomerang uniformity |
| `cryptanalysis::boolean`                 | Walsh-Hadamard, ANF, algebraic degree |
| `cryptanalysis::avalanche`               | Full avalanche matrix, SAC, BIC |
| `cryptanalysis::statistical`             | Chi-squared, monobit, runs test |
| `cryptanalysis::lattice`                 | LLL, BKZ reduction |

### Symmetric-cipher attacks

| Module                                      | Attack                              |
|---------------------------------------------|-------------------------------------|
| `cryptanalysis::boomerang`                  | **Generic boomerang distinguisher + rectangle + sandwich + branch-and-bound trail search** (Wagner FSE 1999 → Cid et al. EUROCRYPT 2018) |
| `cryptanalysis::aes::reduced`               | Reduced-round AES-128 with configurable `Nr` |
| `cryptanalysis::aes::square`                | Square / integral attack (Daemen-Knudsen-Rijmen 1997) |
| `cryptanalysis::aes::differential`          | Differential cryptanalysis on 2-round AES |
| `cryptanalysis::aes::linear`                | Matsui-style linear cryptanalysis |
| `cryptanalysis::aes::impossible`            | Biham-Biryukov-Shamir impossible differential |
| `cryptanalysis::aes::mixture`               | Grassi-Rechberger-Rønjom mixture quadruples |
| `cryptanalysis::aes::boomerang`             | AES-specific boomerang + BCT |
| `cryptanalysis::aes::yoyo`                  | Rønjom-Bardeh-Helleseth yoyo distinguisher |
| `cryptanalysis::aes::mitm`                  | Demirci-Selçuk MITM on 2-round AES |
| `cryptanalysis::aes::small_scale`           | Cid-Murphy-Robshaw SR(n,2,2,4) variant |
| `cryptanalysis::aes::algebraic`             | Multivariate quadratic equations |
| `cryptanalysis::aes::milp`                  | MILP encoding of differential trail search |
| `cryptanalysis::aes::quantum_grover`        | Grover-style quantum key-recovery cost model |
| `cryptanalysis::aes::biclique`              | Biclique attack skeleton |
| `cryptanalysis::aes::related_key`           | **Related-key attack framework** — key-schedule difference propagation, related-key avalanche, related-key boomerang, Biryukov-Khovratovich local-collision demo |
| `cryptanalysis::aes::truncated_diff`        | **Truncated differential cryptanalysis** (Knudsen FSE 1994) — active-byte trail propagation, MixColumns branch-number filter, minimum-active-S-box bounds |
| `cryptanalysis::aes::higher_order`          | **Higher-order differential** (Lai 1994, Knudsen 1995) — d-th derivatives, 3-round Square integral distinguisher, algebraic-degree probe |
| `cryptanalysis::aes::dfa`                   | **DFA / Piret-Quisquater fault attack** (FDTC 2003) — single-byte fault before round 9 reduces last-round-key entropy by ~29 bits per fault |
| `cryptanalysis::aes::visualize`             | **ASCII visualization helpers** — state grids, active-byte patterns, trail diagrams, heat maps, bar charts, boomerang quartet diagrams, recovery progress bars |
| `cryptanalysis::md5_differential`           | MD5 differential collision (Wang et al. 2004) |
| `cryptanalysis::sha1_differential`          | SHA-1 differential analysis (Wang-Yin-Yu 2005) |

### Discrete-log / ECDLP attacks

| Module                                       | Attack                                                  |
|----------------------------------------------|---------------------------------------------------------|
| `cryptanalysis::pollard_rho`                 | Pollard ρ for DLP / ECDLP, multi-shard, distinguished-points |
| `cryptanalysis::pollard_collab`              | **Collaborative p2p rho**: indexed work units, self-verifying DP check-ins, CRDT merge, mailbox + TCP gossip + [cairn](https://github.com/aburan28/cairn) piecework transports — [design](docs/POLLARD_COLLAB_DESIGN.md) |
| `cryptanalysis::preprocessing_rho`           | Bernstein-Lange precomputation rho                       |
| `cryptanalysis::ml_rho_walks`                | Pollard ρ walks under learned partition functions       |
| `cryptanalysis::aut_folded_rho`              | Automorphism-folded rho (CM curves)                      |
| `cryptanalysis::ec_index_calculus`           | Semaev S₃ index calculus on prime-field curves          |
| `cryptanalysis::residual_walk`               | Partial-decomposition residual walks: rho-style collision search over factor-base decompositions, measured against plain rho |
| `cryptanalysis::gaudry_cubic`                | Gaudry-style index calculus on E(F_{p³}) with the subspace factor base {x ∈ F_p}: Weil-restricted S₃ pair test, meet-in-the-middle triple oracle, Gaudry's O(1) three-unknown S₄ solve (symmetrised Weil restriction, Macaulay matrix with row selection, eigenvalues of the multiplication matrix), sparse Wiedemann linear algebra with singleton filtering, the double-large-prime variation, rho reference |
| `cryptanalysis::ec_index_calculus_j0`        | ζ-orbit-reduced IC on j=0 curves + Eisenstein-smooth FB |
| `cryptanalysis::koblitz_index_calculus`      | Frobenius-invariant-factor-base IC on Koblitz curves (GGMP) |
| `cryptanalysis::koblitz_groebner`            | Semaev S₃ Weil restriction + matrix-F4 decomposition oracle |
| `cryptanalysis::semaev_sat`                  | CNF encoding of Semaev systems for the CDCL solver (3rd oracle) |
| `cryptanalysis::koblitz_bench`               | Scaling harness: system profiles, first fall degree, oracle cost |
| `cryptanalysis::koblitz_index_calculus`      | …also: cyclotomic classification of invariant factor bases |
| `cryptanalysis::coordinate_search`           | Algorithmic search for point coordinates that shrink the decomposition system (symmetry detection, linearising frames, interpolated summation polynomials) |
| `cryptanalysis::koblitz_symmetrised`         | The symmetrised (Artin–Schreier frame) Koblitz decomposition systems in the F4 and SAT oracles, with a paired, enumeration-gated benchmark |
| `cryptanalysis::coordinate_quotients`        | Invariants of any finite group of point maps by orbit sums: relation subgroup by experiment, minimal-degree relation, exact collapse |
| `cryptanalysis::f4_fp`                        | Degree-bounded F4 over a small prime field: normal strategy, symbolic preprocessing, parallel dense row reduction mod `p`, cooperative deadline, solving by root finding and substitution — the engine that times the coordinate-descent systems at `m = 3` |
| `cryptanalysis::coordinate_descent`          | Fixed-target quotient systems over `F_{p^k}` descended to `F_p` (Gaudry's setting) and timed on the F_p Gröbner engine; `Chart` puts frames on the `y`-line, where 3-torsion translations of `j = 0` curves are Möbius maps (`examples/three_torsion.rs`) |
| `cryptanalysis::j0_twists`                   | 6-twist enumeration on j=0 curves + smoothness flagging |
| `cryptanalysis::canonical_lift`              | Smart attack on anomalous curves (canonical lifting)    |
| `cryptanalysis::cm_canonical_lift`           | CM-curve canonical lift + p-adic logarithm              |
| `cryptanalysis::nonanom_formal_log`          | Non-anomalous formal-group logarithm                    |
| `cryptanalysis::mazur_tate_sigma`            | Mazur-Tate σ function for anomalous curves              |
| `cryptanalysis::coleman_integration`         | Coleman integration on hyperelliptic curves             |
| `cryptanalysis::ai_schoof`                   | AI-assisted Schoof's algorithm                          |
| `cryptanalysis::ecm`                         | Lenstra elliptic-curve method (ECM) factoring           |
| `cryptanalysis::modular_polynomial`          | Modular polynomials Φ_ℓ(X, Y)                            |
| `cryptanalysis::hilbert_class_poly`          | Hilbert class polynomial computation                    |
| `cryptanalysis::fght_snfs`                   | FGHT toy SNFS pipeline for trapdoored F_p* DLP          |
| `cryptanalysis::shor`                        | Shor's quantum factoring + order-finding                |
| `cryptanalysis::quantum_estimator`           | Resource estimator for quantum attacks                  |

### Signature / nonce attacks

| Module                                      | Attack                                              |
|---------------------------------------------|-----------------------------------------------------|
| `cryptanalysis::hnp_ecdsa`                  | Hidden Number Problem on ECDSA (LLL / BKZ)          |
| `cryptanalysis::multi_key_hnp`              | Multi-key HNP master-key recovery                   |
| `cryptanalysis::bleichenbacher`             | Bleichenbacher direct bias attack (Mironov / Tibouchi) |
| `cryptanalysis::ecdsa_audit`                | ECDSA transcript audit + quick-bias score           |
| `cryptanalysis::signature_corpus`           | Corpus-level reuse / weak-RNG / bias detection      |
| `cryptanalysis::orbit_homology`             | Orbit-homology bias detector                        |
| `cryptanalysis::cga_hnc`                    | Continued-fraction / HNC variant                    |
| `cryptanalysis::b_seed_profile`             | Behaviour-seed profile attack                       |

### Structural / curve-specific

| Module                                | Attack                                                  |
|---------------------------------------|---------------------------------------------------------|
| `cryptanalysis::p256_attacks`         | P-256 specific attack vectors                            |
| `cryptanalysis::p256_structural`      | P-256 structural / lattice attacks                       |
| `cryptanalysis::p256_isogeny_cover`   | Isogeny-cover speculation targeting P-256                |
| `cryptanalysis::solinas_correlations` | Solinas-prime reduction correlations                     |

### Binary-curve Weil descent (GHS / Hess scaffold)

A bounded structural scaffold for Weil descent on binary-field elliptic
curves. The only end-to-end path is the toy `m=1` case, where the descended
Jacobian is the elliptic curve itself and generic bounded search is used.
The `m=2` construction remains symbolic and lacks a smooth hyperelliptic
model; higher-genus descent, explicit isogeny lifting, and Jacobian index
calculus are not implemented.

| Module                                | Role                                                     |
|---------------------------------------|----------------------------------------------------------|
| `cryptanalysis::ghs_descent`          | Frey-Rück / GHS cover-curve construction                 |
| `cryptanalysis::ghs_full_attack`      | Bounded orchestrator producing structured `AttackReport`    |
| `cryptanalysis::ec_trapdoor`          | EC trapdoor / weak-curve detection                       |
| `cryptanalysis::ghs_screen`           | Exact all-factorisation GHS structural screen and cover towers |
| `cryptanalysis::binary_isogeny`       | Vélu-style isogeny computation in characteristic 2       |
| `binary_ecc::hyperelliptic`           | Genus-`g` hyperelliptic curve arithmetic over F_{2^m}    |
| `binary_ecc::poly_f2m`                | Polynomial arithmetic over F_{2^m}                        |
| `prime_hyperelliptic`                 | Hyperelliptic curves over prime fields (Coleman / odd-char descent) |

Toy end-to-end `m=1` ECDLP recovery runs on F_{2^6}; `m=2` type-II symbolic
descent is demonstrated on F_{2^6} with (n=3, ℓ=2), without a smooth model
or HCDLP run. See `examples/ghs_attack_demo.rs` for the bounded scenarios. The
native [`ghs_screen`](docs/GHS_SCREEN.md) CLI validates a polynomial-basis
field and reports every GHS tower without fixed-width genus truncation; that
screen is not a higher-genus solver.

### Auto-attack framework + CLI

| Module                                | Purpose                                                 |
|---------------------------------------|---------------------------------------------------------|
| `cryptanalysis::cipher_registry`      | Named-cipher catalog (`toyspn-{1..4}r`, `aes-{1..4}r`, `toyspn-present-2r`) with `BlockCipher` adapter |
| `cryptanalysis::auto_attack`          | Discovers and runs every applicable attack against a named cipher; emits Markdown report |
| `cryptanalysis::research_bench`       | Falsifiable-hypothesis bench with `linear_fit` / `log_log_fit`, polynomial and exponential scaling regimes |

---

## Cryptanalysis CLI

```bash
# Discover what's registered
crypto cryptanalysis list-ciphers

# Run every applicable attack against a named cipher
crypto cryptanalysis auto --cipher toyspn-2r
crypto cryptanalysis auto --cipher aes-2r --boomerang-pairs 4096

# Drive individual attacks
crypto cryptanalysis sbox      --cipher aes-2r
crypto cryptanalysis boomerang --cipher toyspn-3r --pairs 65536
crypto cryptanalysis boomerang --cipher toyspn-2r --alpha 0100 --delta 0100
crypto cryptanalysis rectangle --cipher toyspn-1r --pool 2048

# Run the full research bench
crypto cryptanalysis bench
```

Auto-attack discovery logic (`auto --cipher <name>`):

| Section                  | Condition                          |
|--------------------------|------------------------------------|
| S-box DDT/LAT/BCT/DLCT   | cipher exposes a single S-box      |
| Boomerang distinguisher  | always                             |
| Rectangle attack         | always                             |
| Differential trail search| cipher is 4×4-bit SPN (`entry.trail_searchable`); skipped for AES (8-bit S-box outside the current SPN model — see `aes/milp.rs` for the MILP route) |

Sample output (`auto --cipher toyspn-2r`):

```
# Auto-cryptanalysis: `toyspn-2r`
**Block size**: 2 bytes (16 bits)
**Rounds**: 2
**Canonical (α, δ)**: 0x0100 / 0x0100

## S-box analysis
| differential uniformity | 4    |
| max DP                  | 0.25 |
| boomerang uniformity    | 16   |

## Boomerang distinguisher
- right quartets: 4099 / 16384
- empirical (pq)²: 2.50e-1
- random baseline: 1.53e-5
- distinguishes from random (10×): ✓

## Rectangle attack
- right rectangles: 2 (pool 1024)

## Differential trail search
| rank | input α | output ω | probability | log₂ p |
| 1    | 0x0001  | 0xccc0   | 7.8e-3      | -7.00  |

**Total**: 4 sections in 30 ms.
```

---

## Research bench

A continuously-updated empirical study of cryptanalytic-attack complexity.  Each
attack is registered as a falsifiable [`Hypothesis`] with a theoretical complexity
claim; the bench runs it at multiple problem sizes, fits the measured
exponent by log-log regression, and prints a verdict.

The proposed
[comprehensive elliptic-curve private-key recovery audit](research/notes/ecdlp-general/RESEARCH_COMPREHENSIVE_ECDLP_AUDIT_PLAN.md)
adds the cross-cutting control plane: exact audit units, a five-lane
non-overlapping taxonomy, E0–E7 evidence gates, literature and incident
coverage, common cost accounting, and independent governance. Its
[machine-readable twin](docs/ecdlp-audit/ECDLP_AUDIT_PLAN.mock.json) is a
non-authoritative planning mock and cannot promote a claim.
The dated [execution checkpoint](research/notes/ecdlp-general/RESEARCH_ECDLP_AUDIT_EXECUTION_CHECKPOINT_20261014.md)
records the native validator, the exact cover/Jacobian evidence boundary, and
the still-open gates for each of the eight workstreams.

Two scaling regimes are supported:

- **Polynomial** (`time ∝ n^α`): default; ECDLP attacks, IC variants, twist enum.
- **Exponential** (`time ∝ 2^(c·rounds)`): boomerang attack on r-round ToySpn,
  fits bits-per-round directly via `fit_boomerang_decay`.

Run:

```bash
cargo test --lib --release bench_demo -- --ignored --nocapture
# or
cargo run --release -- cryptanalysis bench
```

Live measurements: see [`research/notes/ecdlp-general/RESEARCH_BENCH_LOG.md`](research/notes/ecdlp-general/RESEARCH_BENCH_LOG.md).

Headline empirical findings (most recent):

| Hypothesis                          | Theoretical  | Measured | R²    | Verdict        |
|-------------------------------------|-------------:|---------:|------:|----------------|
| Pollard ρ ECDLP (7–20 bits)         | α = 0.500    | 0.807    | 0.996 | ≈ approx       |
| Index calculus (generic)            | α = 1.500    | 0.691    | 0.970 | ✗ toy regime   |
| IC on j=0 (ζ-orbit reduced)         | α = 1.500    | 0.752    | 0.895 | ✗ toy regime   |
| Eisenstein-smooth IC (j=0)          | α = 1.500    | 0.825    | 0.992 | ✗ falsified speculation |
| j=0 twist enumeration               | α = 1.000    | 1.035    | 0.999 | ✓ matches      |
| Boomerang decay (ToySpn r=1..4)     | ~8 bits/round| 5.05     | 0.990 | empirical signature |

See also [`docs/ECDLP_ATTACK_MATRIX.md`](docs/ECDLP_ATTACK_MATRIX.md) for the
attack/curve-family applicability matrix,
[`docs/ic/BOUNDARY_TARGETS.md`](docs/ic/BOUNDARY_TARGETS.md) for the
per-stage index-calculus records agents should try to beat (binary / Koblitz /
prime), and [`research/notes/index-calculus/RESEARCH_IC_BOUNDARY_LEDGER.md`](research/notes/index-calculus/RESEARCH_IC_BOUNDARY_LEDGER.md)
for the operation-counted boundary ledger of all three regimes (`ic boundary`),
which supersedes the wall-clock exponents in the table above as the reference
for index calculus.

---

## CLI demo for non-cryptanalysis features

```bash
# Hash
crypto hash sha256 "hello world"
crypto hash sha3   "hello world"
crypto hash blake3 "hello world"
# Hash exact bytes, including NUL and non-UTF-8 values
crypto hash sha256 --hex 00ff0180
crypto hash sha3-256 --file ./message.bin
crypto hash sha-3-512 --file ./message.bin
crypto hash shake-256 --output-bytes 64 --file ./message.bin
crypto cryptanalysis hash-auto --hash sha-3-256

# ECC / ECDSA / ECDH
crypto ecc keygen
crypto ecdsa sign   "my message"
crypto ecdsa verify "my message" <pubkey-hex> <r-hex> <s-hex>
crypto ecdh

# RSA (slow — 1024-bit keygen)
crypto rsa keygen
crypto rsa demo

# Symmetric AEAD
crypto aes
crypto chacha

# Key derivation
crypto hkdf

# Post-quantum
crypto pqc

# Run all of the above demos at once
crypto demo
```

---

## Mathematics background

### Elliptic curves

An elliptic curve over a prime field **F_p** is the set of points satisfying:

```
y² ≡ x³ + ax + b  (mod p)
```

together with a special "point at infinity" **O** that acts as the additive identity.

**Point addition** (P ≠ Q):  λ = (y₂ − y₁) / (x₂ − x₁) mod p ; x₃ = λ² − x₁ − x₂ ; y₃ = λ(x₁ − x₃) − y₁.

**Point doubling** (P = Q):  λ = (3x₁² + a) / (2y₁) mod p.

**Scalar multiplication** k·P uses double-and-add in `O(log k)` group operations.

#### Curve families we support

- **Bitcoin/Ethereum**: secp256k1 (a=0, b=7, p ≈ 2²⁵⁶).
- **NIST / TLS**: P-192, P-224, P-256, P-384, P-521.
- **Brainpool** (RFC 5639): P{160,192,224,256,320,384,512}r1.
- **French ANSSI**: FRP256v1.
- **Chinese**: SM2 (`a = −3 mod p`).
- **Russian GOST**: tc26-256 and tc26-512 paramsets.
- **Korean**: EC-KCDSA convention `Q = x⁻¹·G`.
- **CFRG / RFC 7748**: Curve25519 (Montgomery) + Ed25519 (Edwards).

### AES

AES operates on a 4×4 byte state through `Nr` rounds (10/14 for AES-128/256).
Each round applies:

1. **SubBytes** — non-linear S-box (inverse in GF(2⁸) + affine map).
2. **ShiftRows** — cyclic rotation of rows 0..3 by 0..3 positions.
3. **MixColumns** — matrix mul over GF(2⁸) (omitted in the final round).
4. **AddRoundKey** — XOR with the round key.

**GCM** adds GHASH (polynomial mul over GF(2¹²⁸)) for authentication.

The cryptanalysis side studies all four operations: the S-box DDT/LAT/BCT
(`cryptanalysis::sbox`), the MixColumns branch number = 5 (`aes::differential`),
the Square/integral structure (`aes::square`), etc.

### Boomerang attack

Split `E = E₁ ∘ E₀`.  Find differential α →_{E₀} β with prob p, γ →_{E₁} δ with
prob q.  For random P: encrypt (P, P⊕α) to (C, C⊕β?); XOR δ onto both; decrypt.
Claim: P' ⊕ P'' = α with probability ≈ (pq)² (Wagner FSE 1999).

The **Boomerang Connectivity Table** (Cid–Huang–Peyrin–Sasaki–Song EUROCRYPT 2018)
corrects this naive estimate — at the boundary the two trails interact through
the S-box and the BCT entry replaces `(pq)²` with `(p²·q²·BCT[β][γ]/2^n)`.  We
implement BCT (per-S-box) and the **sandwich attack** (Dunkelman-Keller-Shamir
CRYPTO 2010) that uses BCT directly.

### Pollard ρ for DLP

Random walk on the cyclic group; collision via Floyd's tortoise-and-hare.
Expected `√(πn/2)` group operations to recover the discrete log.

**Collaborative mode** (`cryptanalysis::pollard_collab`): many machines share
one instance.  The job id seeds the walk, so walker `i`'s start point is a
pure function of `i` and the search space divides into index ranges; peers
check in distinguished points as `(x, y, a, b)` with `a·P + b·Q = (x, y)`,
which anyone can verify, and merge each other's check-ins as a CRDT with no
coordinator.  Try it on one machine:

```bash
crypto cryptanalysis rho-collab init --curve demo-40 --secret 1badc0de --mailbox /tmp/collab
crypto cryptanalysis rho-collab work --mailbox /tmp/collab --node alice --threads 2 &
crypto cryptanalysis rho-collab work --mailbox /tmp/collab --node bob
crypto cryptanalysis rho-collab status --mailbox /tmp/collab
```

Or get paid for it: a [cairn](https://github.com/aburan28/cairn) node
([download](https://github.com/aburan28/cairn/releases/latest), or
`curl -fsSL https://github.com/aburan28/cairn/releases/latest/download/install.sh | sh`)
can post the same search as a `piecework` objective, where each distinguished
point is a verified artifact paid from a pool
([design](https://github.com/aburan28/cairn/blob/main/docs/design/rho-piecework.md),
built in [aburan28/cairn#144](https://github.com/aburan28/cairn/pull/144)).
`--cairn` commits and reveals every point as a claim and reads the objective's
log back as the shared DP table, so a collision with anyone else's point is
seen here and, with `--answer-objective`, `k` is claimed too:

```bash
crypto cryptanalysis rho-collab work --job nums-50-rho.json --node carol \
    --cairn http://127.0.0.1:8080 --objective sha256:… --answer-objective sha256:… \
    --identity carol.json          # or --submitter carol for an unsigned nickname
crypto cryptanalysis rho-collab status --job nums-50-rho.json --cairn http://127.0.0.1:8080 --objective sha256:…
```

Design notes: [`docs/POLLARD_COLLAB_DESIGN.md`](docs/POLLARD_COLLAB_DESIGN.md).

### Index calculus (ECDLP, prime fields)

Semaev's summation polynomials `S_n(x_1, …, x_n)` vanish iff there exist
y-coords making (x_i, y_i) on the curve sum to zero.  We use `S_3` for
2-decompositions; cost `O(p · m)` per relation with factor-base size `m`,
optimum at `m = √p` giving `O(p^{3/2})` — asymptotically worse than ρ on prime
curves, but the bench studies the empirical exponent.

### Hidden Number Problem

ECDSA with biased nonces `k = k_low + 2^B · k_high` leaks `k_high` through
linear relations; LLL on the right lattice recovers the secret in polynomial
time given enough biased signatures.  See `hnp_ecdsa`, `multi_key_hnp`,
`bleichenbacher`.

---

## Project structure

```
src/
├── lib.rs / main.rs           — library root + CLI
├── ecc/                       — ECC core + curve zoo + ECDSA/ECDH/Schnorr/SM2/GOST/EC-KCDSA
├── binary_ecc/                — Binary-field ECC + polynomial-over-F_{2^m} + hyperelliptic Jacobians
├── prime_hyperelliptic/       — Odd-char hyperelliptic curves (for Coleman / descent)
├── bls12_381/                 — Pairing-friendly BLS12-381 curve + pairing
├── symmetric/                 — AES, ChaCha, Serpent, Threefish, SM4, Magma, Kuznyechik
├── hash/                      — SHA-2/3, BLAKE3, RIPEMD-160, SipHash, SM3, Streebog
├── asymmetric/                — RSA, Paillier, ElGamal, EC-ElGamal
├── pqc/                       — ML-KEM, ML-DSA, SLH-DSA, SQIsign, Kyber (toy), Frodo, NTRU/NTRU-Prime, McEliece, HQC, BIKE, CSIDH, X-Wing
├── kdf/                       — HKDF, PBKDF2, HMAC-DRBG
├── zk/                        — Schnorr, Pedersen, Chaum-Pedersen, Merkle, KZG, Bulletproofs, Groth16, PLONK, STARK
├── cryptanalysis/             — see Cryptanalysis suite section above
│   ├── aes/                   — Reduced-round + Square + linear + diff + impossible + mixture + boomerang + yoyo + MITM + small-scale + algebraic + MILP + Grover + biclique
│   ├── boomerang.rs           — Generic distinguisher + rectangle + sandwich + trail search
│   ├── ghs_descent.rs         — Binary-curve Weil descent (cover construction)
│   ├── ghs_full_attack.rs     — GHS attack orchestrator
│   ├── ghs_screen.rs          — Exact all-factorisation GHS screener
│   ├── binary_isogeny.rs      — Char-2 Vélu isogenies
│   ├── ec_trapdoor.rs         — Weak-curve / trapdoor detection
│   ├── cipher_registry.rs     — Named-cipher catalog
│   ├── auto_attack.rs         — Auto-discovery + dispatch
│   ├── research_bench.rs      — Falsifiable-hypothesis bench
│   ├── ecdlp_variants/        — The Galbraith-Wang-Zhang BSGS and Gaudry-Schost table
│   ├── bsgs_fast.rs           — Same BSGS, single-word Montgomery + flat table + rayon
│   └── …45+ other attack modules
├── examples/
│   └── ghs_attack_demo.rs     — Three runnable GHS scenarios
├── ct_bignum.rs               — Constant-time big-integer experiments
├── ecc_safety.rs              — ECC parameter-safety auditor
└── utils/                     — Modular arithmetic, encoding, randomness

gpu/ecc/                       — CUDA kernels: 256-bit prime field, EC points, batched Pollard rho, parallel BSGS
gpu/ecc2k/                     — CUDA kernels: F(2^m) Koblitz curves, Frobenius-class rho (ECC2K-95)
gpu/btcpuzzle/                 — CUDA kernels: Pollard kangaroo for interval ECDLP (Bitcoin puzzle series)
hdl/sha1/                      — VHDL: pipelined SHA-1 core + collision search
hdl/ecc/                       — VHDL: pipelined secp256k1 modular multiplier + point adder
hdl/ecc2k130/                  — VHDL: GF(2^131) normal-basis multiplier, ECC2K-130 step unit, rho walker
```

### Hardware acceleration

Two hardware back-ends for the same ECDLP workload, each verified against
the pure-Python oracle in `gpu/ecc/ecref.py`:

```bash
# CUDA kernels — arithmetic verified on the CPU, no GPU required
# (also interprets the FP_PTX inline assembly and checks it against the
#  portable path, which the host would otherwise never execute)
cd gpu/ecc && make test

# static instruction-count and occupancy analysis for Hopper / Blackwell
cd gpu/ecc && ./ptx_stats.sh --setup && ./ptx_stats.sh

# on a machine with a GPU
cd gpu/ecc && make bench && ./bench selftest && ./bench rho
cd gpu/ecc && ./bench bsgs --wbits 44      # baby-step giant-step, table on the device

# Koblitz curves over F(2^m): ECC2K-95 plus two solvable toy curves
cd gpu/ecc2k && make test

# Interval ECDLP: Pollard kangaroo, solves planted keys end to end
cd gpu/btcpuzzle && make test

# FPGA datapath — GHDL simulation of the multiplier and the point adder
cd hdl/ecc && make

# FPGA engine for ECC2K-130 — GF(2^131) multiplier, step unit, walker,
# checked against the ecc2k130 client's field model
cd hdl/ecc2k130 && make
```

`gpu/ecc/` covers batch scalar multiplication, a distinguished-point
r-adding rho walk with the negation map and fruitless-cycle escape, and a
parallel baby-step giant-step engine for full-group and interval logs: both
phases run as independent chains sharing one inversion per thread, the baby
table is an x-keyed lock-free hash table in device memory, and every hit is
verified on the host. Measured on the toy curve at `S ≈ 1.07` against rho's
`0.85`, in exchange for `16 · √n` bytes of table — and `0.56` per target
once a batch shares one table.

The same engine is ported to the CPU as
[`src/cryptanalysis/bsgs_fast.rs`](./src/cryptanalysis/bsgs_fast.rs):
single-word Montgomery arithmetic, the same flat x-keyed table, chains on
`rayon`. It is **6.3× to 10.9×** the crate's general `BigUint` baby-step
giant-step on the same curves and runs at 37–49 Msteps/s on four threads
(`cargo run --release --example bsgs_fast_bench`).
`hdl/ecc/` implements the same walk's datapath: a 256-bit modular
multiplier at one multiply per clock, and a point adder that interleaves
independent walks to keep it saturated at three clocks per addition.

`hdl/ecc2k130/` is the FPGA counterpart of the `ecc2k130/` GPU client: the
same permuted type-II normal basis, in which squaring is wiring, so
inversion is eight multiplies and a whole walk step `R + sigma^j(R)` is ten.
A Karatsuba GF(2^131) multiplier at one product per clock with no DSPs, a
step unit that shares one inversion across sixteen walks through a product
tree and streams batches of independent multiplies to run the multiplier
saturated at 5.3 clocks per step (measured in simulation), and a sequencer
that reports distinguished points to the host; the testbenches replay walks
from the client's own reference model.

`gpu/ecc2k/` targets Koblitz curves over F(2^m), where the Frobenius map is
a free endomorphism: walking on the classes {±τ^i P} shortens the search by
√(2m), which is 13.9× for the 97-bit field of ECC2K-95. Measured over 24
solves on a toy curve, the class walk lands within 1% of its predicted step
count and at 0.21× a negation-only walk.

`gpu/btcpuzzle/` solves the *interval* discrete log — the key is known to lie
in a range — with Pollard kangaroo, which costs about 2√W for a range of
width W instead of the 2^128 a full-group search would. That is the shape of
the Bitcoin puzzle challenges, and of biased-nonce and small-range key
problems generally. It runs across several GPUs the way the deployed
kangaroo solvers do: one process, one host thread per device, disjoint herds,
one distinguished-point table (`--gpu 0,1,2`).

---

## Documentation

**Published site:** <https://aburan28.github.io/crypto/> — the
[index-calculus scoreboard](https://aburan28.github.io/crypto/scoreboard/) and
the live [ECC2K-130 campaign status](https://aburan28.github.io/crypto/status/).
Assembled from this repository by `scripts/site/build.py`; see
[`scripts/site/README.md`](scripts/site/README.md).

**Contributing compute to ECC2K-130:** the walk is a Pollard rho over disjoint
seed spaces, so any machine walking its own `--run-id` adds points to the same
search. Run the client in [`ecc2k130/`](ecc2k130/README.md#contribute-compute),
or **[download cairn](https://github.com/aburan28/cairn/releases/latest)**
(`curl -fsSL https://github.com/aburan28/cairn/releases/latest/download/install.sh | sh`)
for the paid path. cairn posts this search as
[`objective-ecc2k130-orbit-batch`](https://github.com/aburan28/cairn/blob/main/examples/certicom-ecdlp/objective-ecc2k130-orbit-batch.json),
paying per novel **orbit** rather than per point, because Frobenius and
negation give one point 262 names. What is not ready is on this side: a point
here cannot carry `(a, b)` without a 129-bit modular multiplication per step,
so the claim needs the eight branch counters that make a trail checkable in
about 227 group operations. The kernel does not carry them yet and should:
the campaign's packed backend already has the branch index as a scalar, so a
counter is two instructions (+0.09%, ~36 GPU-hours across the campaign) and
makes every orbit claimable. For points already collected without counters,
`ecc2k130/build/witness` replays a trail and emits the checked artifact.

- [`SECURITY.md`](SECURITY.md) — structural limitations + recommended alternatives.
- [`AGENTS.md`](AGENTS.md) — how cryptanalysis progress is reported here: state a boundary, put every variant in one table in one unit, and classify each change by whether the ratio to that boundary moved.
- [`docs/index-calculus-scoreboard.html`](docs/index-calculus-scoreboard.html) — one-page visual scoreboard of the ECDLP cost ledger: every index-calculus variant against Pollard rho and the generic-group floor, the solve-constant ledger, and the fitted exponents. Open it in a browser, or read the published copy at [/scoreboard/](https://aburan28.github.io/crypto/scoreboard/).
- [`research/notes/index-calculus/RESEARCH_IC_BOUNDARY_LEDGER.md`](research/notes/index-calculus/RESEARCH_IC_BOUNDARY_LEDGER.md) — the three regimes of index calculus (generic prime field, generic binary field, Koblitz) run end to end on the same planted logarithms and priced phase by phase in one unit — group-addition equivalents per `√r`, exact native counts with host-measured conversions — against the generic floor `√(π/2A)` and a counted Pollard rho on the same instance; the decomposition oracles (enumeration, meet in the middle, `S₄` pairs-and-solve, matrix-F4, CDCL SAT) priced per target with each system's first fall degree; fitted exponents per phase; and the boundaries the next rounds iterate against (`ic boundary`, `docs/ic/runs/ic-boundary-ledger-2026-09-21.json`). Its §10 is the second round: an engineering ledger (pair tables folded by negation and, on Koblitz curves, by the Frobenius; walk-drawn targets; two-summand rows; a base sized to the folded table; the exact class-aware counting ceiling) with every first-round row kept as its before mark and a saved baseline/candidate comparison (`docs/ic/runs/ic-boundary-ledger-round2-2026-09-21.json`). §10.2 records the defect that round caught: a run that decomposes one group element twice is pinned by that collision rather than by its relations, which ends about a quarter of unguarded two-summand runs and 82% of those whose walk segments share a jump table, so both target sources are now guarded and 22 of the first round's rows were corrected. Its §11 is the third round: the walk's *restarts* — which Round 2 paid for with sixteen fresh jumps, thirty-two scalar multiplications each, and which now cost one group operation — balanced prime and binary bases, and a derived shape law for the whole family, `S_family = 0.75·(#E·t/k)^{2/3}/(t·√r)` with `t` the table fold and `k` the column fold, which is `Θ(r^{1/6})` on a prime-order curve and so bounds what any amount of base-size tuning can win (`docs/ic/runs/ic-boundary-ledger-round3-2026-09-21.json`). The companion `ic corpus` writes Trimoska-style Weil-descended `S₄` instances with certified labels for Magma, XOR-aware SAT solvers and ANF tools (`docs/ic/corpus/`).
- `RESEARCH.md` — research notes (no longer in the repository: the file is absent from the checkout and from every ref of this clone; see [`research/notes/README.md`](research/notes/README.md) for the current note index).
- [`RESEARCH_P256.md`](./research/notes/cm-isogeny/RESEARCH_P256.md) — P-256 specific structural studies.
- [`RESEARCH_RESIDUAL_WALKS.md`](./research/notes/index-calculus/RESEARCH_RESIDUAL_WALKS.md) — finding points vs finding relations: collision search over partial factor-base decompositions, measured against Pollard rho (`experiments/20_residual_walk_panel.*`); optimisation ledger, frozen baseline and tuned scoreboards (`experiments/20_residual_walk_{baseline,tuned}.json`, `scripts/residual_walk_scoreboard.py`); round 3 on the count factor: signed-pair seeding and `j = 0` automorphism folding (`experiments/20_residual_walk_{seeded,structure}.json`).
- [`RESEARCH_TII_MCELIECE.md`](./research/notes/code-based/RESEARCH_TII_MCELIECE.md) — TII McEliece key-recovery challenges: attack ideas + imported keys (`research/tii_mceliece/`).
- [`RESEARCH_EXOTIC_COORDINATES.md`](./research/notes/index-calculus/RESEARCH_EXOTIC_COORDINATES.md) — algorithmic search for exotic point coordinates that make decomposition relations cheaper (prime, binary, Koblitz).
- [`DEFERRED.md`](./docs/DEFERRED.md) — known gaps + deferred work.
- [`docs/ECDLP_ATTACK_MATRIX.md`](./docs/ECDLP_ATTACK_MATRIX.md) — ECDLP attack taxonomy.
- [`docs/ic/BOUNDARY_TARGETS.md`](./docs/ic/BOUNDARY_TARGETS.md) — index-calculus per-stage boundary ledger (beat targets for agents).
- [`research/sat_factor_base_review_20260908/autolab/`](./research/sat_factor_base_review_20260908/autolab/) — agent autolab runner wired to the IC boundary ledger.
- [`RESEARCH_BENCH_LOG.md`](./research/notes/ecdlp-general/RESEARCH_BENCH_LOG.md) — live empirical bench measurements.
- [`gpu/ecc/README.md`](./gpu/ecc/README.md) — GPU elliptic-curve kernels.
- [`gpu/ecc/OPTIMIZATION_BLACKWELL.md`](./gpu/ecc/OPTIMIZATION_BLACKWELL.md) — Blackwell tuning: cost model + measured occupancy.
- [`gpu/ecc2k/README.md`](./gpu/ecc2k/README.md) — Koblitz / ECC2K-95 kernels and the Frobenius-class walk.
- [`gpu/btcpuzzle/README.md`](./gpu/btcpuzzle/README.md) — Pollard kangaroo for interval ECDLP.
- [`hdl/ecc/README.md`](./hdl/ecc/README.md) — FPGA secp256k1 datapath.
- [`hdl/ecc2k130/README.md`](./hdl/ecc2k130/README.md) — FPGA ECC2K-130 engine: normal-basis multiplier, step unit, walker.
- [`docs/ecc_fpga_cost_model.md`](./docs/ecc_fpga_cost_model.md) — ECDLP: FPGA vs GPU cost model.
- [`docs/sha1_fpga_cost_model.md`](./docs/sha1_fpga_cost_model.md) — SHA-1 collisions: FPGA vs GPU cost model.
- [`research/notes/cm-isogeny/RESEARCH_P256.md`](research/notes/cm-isogeny/RESEARCH_P256.md) — P-256 specific structural studies.
- [`research/notes/index-calculus/RESEARCH_RESIDUAL_WALKS.md`](research/notes/index-calculus/RESEARCH_RESIDUAL_WALKS.md) — finding points vs finding relations: collision search over partial factor-base decompositions, measured against Pollard rho (`experiments/20_residual_walk_panel.*`); optimisation ledger, frozen baseline and tuned scoreboards (`experiments/20_residual_walk_{baseline,tuned}.json`, `scripts/residual_walk_scoreboard.py`); round 3 on the count factor: signed-pair seeding and `j = 0` automorphism folding (`experiments/20_residual_walk_{seeded,structure}.json`); the S₃/S₄ decomposition oracles and Gaudry's subspace setting on E(F_{p³}) (`experiments/20_residual_walk_{oracle,s4,mitm3}.json`, `experiments/21_gaudry_cubic.json`); Gaudry's O(1) three-unknown S₄ solve and its measured constant `C₃` (`experiments/21_gaudry_cubic_groebner.json`), the `C₃` optimisation ledger (`experiments/21_gaudry_cubic_c3.json`, §11.5–11.6), and the linear algebra: dense vs sparse Wiedemann with filtering, and the double-large-prime variation measured at `n^{4/9}` (`experiments/21_gaudry_cubic_la.json`, §11.7).
- [`research/notes/index-calculus/RESEARCH_GLV_INDEX_CALCULUS.md`](research/notes/index-calculus/RESEARCH_GLV_INDEX_CALCULUS.md) — GLV / `C₃` levers on the `E(F_{p³})` subspace harness at `j = 0`: the `⟨ψ⟩` orbit quotient of the factor base with orientation `λ^k` (columns, relations, residuals, NNZ, Wiedemann all `÷ 3`, count on its fold-aware floor; `experiments/22_glv_quotient.json`, six seeds with 48 rho walks per size in `22_glv_quotient_seeds6.json`), canonical residual/decomposition generation (zero saved on the uniform stream, `95 %` of a pair sieve's rows `ψ`-trivial; `22_glv_canonical.json`), the `Z/3`-graded Macaulay matrix and block-aware F4 on the `ψ`-homogeneous orbit system (`22_glv_graded.json`), and the `C₃`-invariant, Veronese (20 cubic invariants) and function-first `L(4O)` PDP formulations against the symmetrised Semaev `S₄` solve (`22_glv_invariant.json`, `22_glv_veronese.json`); tables by `scripts/glv_gaudry_tables.py`.
- [`research/notes/index-calculus/RESEARCH_RHO_PARITY_PROGRAMME.md`](research/notes/index-calculus/RESEARCH_RHO_PARITY_PROGRAMME.md) — the rho-parity ledger: every measured index-calculus route on the `E(F_{p^k})` subspace harness, its fitted exponents and the numeric condition parity would need (`k = 3` plain bottoms at `26–177×` rho and never crosses; double large primes `2^237`; `k = 4` full `2^151`), and the one route whose distance to parity is a constant, Joux–Vitse three-point decompositions at `k = 4`, built and measured end to end: `6,945×` rho flat from `2^32` to `2^40`, one three-point test costing `1.6·10⁵` `F_p` multiplications (`107×` the value the residual-walk note had borrowed), every logarithm verified and `85,277` residuals cross-checked against an independent oracle; `k = 5` with torsion symmetries registered as the next stage (`experiments/26_jv_quartic_{cprime,dlp}.json`, tables by `scripts/parity_ledger.py`).  Its closing section (§8, 2026-10-04) states the boundary: on every generic curve of the harness no route reaches parity below `2^{150}`; the one route that closes is the cover on a weak class over `F_{p⁶}`, where the crossover with rho is now *measured* at `p ≈ 370–430` (`ℓ ≈ 2^{49–50}`) and the walk that reaches the class is priced above rho below `p ≈ 8,000`, so walk plus attack stays above rho at every size the harness reaches.
- [`research/notes/index-calculus/RESEARCH_K5_TORSION_JOUX_VITSE.md`](research/notes/index-calculus/RESEARCH_K5_TORSION_JOUX_VITSE.md) — the `k = 5` stage the parity programme registered, built and measured: `F_{p⁵}`, prime-order Weierstrass and Edwards curves over it, the symmetrised `S₅` in four points (plain: `495` monomials of degree `8`; with the 2-torsion symmetry of Faugère–Gaudry–Huot–Renault in the Edwards `y`-coordinate: `70 + 35` monomials of degrees `4` and `3` plus a product variable), the F4 four-point test cross-checked against a pair-table oracle; one test costs `C″ = 3.0·10¹⁰` `F_p` multiplications plain and `7.3·10⁷` with the symmetry (`416×`), flat in `p`, putting the route's parity crossing at `2^302` and `2^233` (extrapolated on `n^{2/5}` and `n^{1/2}`, in the order of the group the logarithm lives in; the Edwards residual rate `1/(192p)` counted exactly by a census, correcting the first round's `1/(24p)` and its `2^203`), against `2^135–2^168` registered — the route is falsified as a machine-size parity programme.  The second round built the 4-torsion variant the first had registered as a `4–10×` lever and retracted it: the rational point of order four swaps the coordinates and halves no degree (the involution that would needs `√d ∈ F_p`), and saturating the residual over its four translates doubles the rate for `2.01×` the test, a wash measured at four sizes; the one lever left, a trace-driven elimination, is priced (`experiments/27_jv_quintic{,_edwards}_csecond.json`, `experiments/28_jv_quintic_edwards4_csecond.json`, `experiments/28_jv_quintic_edwards_rate_census.json`, `scripts/parity_ledger.py` section D).
- [`research/notes/index-calculus/RESEARCH_COVER_DECOMPOSITION_LEDGER.md`](research/notes/index-calculus/RESEARCH_COVER_DECOMPOSITION_LEDGER.md) — the Joux–Vitse cover-and-decomposition route on `E(F_{p⁶})` (curves `y² = h(x)(x − α)(x − σα)` with a genus-3 GHS cover over `F_{p²}`), registered before it was built (six predictions with falsification lines) and then measured: `F_{p²}`, `F_{p⁶}`, a Cantor Jacobian, the cover and the transfer homomorphism, a Nagao six-point test (six quadrics in six unknowns, F4 and a zero-dimensional solver) cross-checked against a meet-in-the-middle oracle, and the method end to end against rho on the same group; one test costs `5.2·10⁶` `F_p` multiplications (`c_add = 331`), flat in `p`, and `S / rho` falls as `p^{−1.92 ± 0.12}` from `~2,100×` (`2^{32}`) to `8–10×` (`2^{58}`), extrapolating to parity near `2^{67}` on the weak class — a reproduction of a published route (accounting and engineering, no advance), with the isogeny walk to a weak curve not priced, and four defects found and kept as superseded runs (`experiments/30_jv_cover_*.json`, `scripts/parity_ledger.py` section E).  §13 prices the isogeny walk the route needs on a generic curve of order divisible by `4`: the weak class is exactly the curves with full 2-torsion one of whose cross-ratios has norm one down to `F_{p²}` (`3/q` of them, measured), a 2,3-isogeny step costs `3–7·10⁵` multiplications, and a walk of `q/3` steps is above rho below `p ≈ 8,000`; the reachable 2,3-isogeny components were too small to sample a class, so the cited `≈ q` steps stay cited (`experiments/34_jv_isogeny_walk*.json`, ledger section G; accounting).  §10 then stops F4 at the Bézout staircase (`64` standard monomials, at which point the partial basis is already a Gröbner basis): `3.2·10⁶` per test, `S / rho` `5–6×` at `2^{58}` and parity extrapolated near `2^{65}`, the same relations from the same residuals, a `1.61×` constant and nothing on the exponent — engineering (`experiments/31_jv_cover_stop_*.json`, ledger section E.2).  §11 registers and then builds the sieving variant of the relation phase ([JV12] §3.2; `src/cryptanalysis/jv_sieve.rs`): relations read off a sieve over the factor base's abscissae instead of Nagao tests, `C_rel = 3–6·10⁶` per relation at `m = 9` (`720·C_cov / C_rel = 566`), and `S / rho` measured at `3.2–8.5×` (`p = 251`), `1.05×` and `0.11×` (`503`), `0.039–0.069×` (`1009`) and `0.012–0.014×` (`p = 1511`, `2^{61.4}`), so the crossover with rho on the weak class is *measured* at `p ≈ 430` (`ℓ ≈ 2^{50}`) where §6 extrapolated one at `2^{67}`; the descent (two Nagao tests) is `46–86 %` of the cost from `p = 503` up, all ten logarithms above `p = 101` were recovered, and the class stays reproduction of a published route (`experiments/32_jv_cover_sieve_dlp_*.json`, ledger section F).  §12 then has F4 replay a trace recorded once per size (Joux–Vitse's F4 variant: the pair rows every new pivot is a combination of, replayed on every later system of the same shape, a diverging replay finishing as a full run): `1.6·10⁶` per test (`2.0×` on the test, `3.2×` against §6), `S / rho` `3.0×` and `2.4×` at `2^{58}`, exponent `−1.96 ± 0.11`, parity extrapolated near `2^{62}`, and `1.3–1.8×` on the sieve route's descent; three defects found by the oracle and the planted residuals and kept under their own names — engineering (`experiments/33_jv_cover_trace_*.json`, ledger sections E.3 and F.2).  §16 runs the sieved route on twenty primes (ten near `500`, ten near `1,000`, one instance each, all solved: `0.04–0.67×` and `0.008–0.032×` rho, the spread the instance's factor base and not the prime, the crossover from the band means `p ≈ 333`), extends the size to the 64-bit arithmetic's limit (`p = 1,777` and `1,823`, `ℓ ≈ 2^{63}`, `0.003–0.005×`), and states why the construction's other members were not built: `n = 2` is a subfield curve, `k = 1` is the ordinary genus-3 index calculus the hyperelliptic panels measure, `k ≥ 3` needs nine-point decompositions, and even characteristic is a build of its own (`experiments/37_jv_cover_sieve_primes_*.json`, `38_jv_cover_*.json`, ledger section F.4).
- [`research/notes/code-based/RESEARCH_TII_MCELIECE.md`](research/notes/code-based/RESEARCH_TII_MCELIECE.md) — TII McEliece key-recovery challenges: attack ideas + imported keys (`research/tii_mceliece/`).
- [`research/notes/index-calculus/RESEARCH_EXOTIC_COORDINATES.md`](research/notes/index-calculus/RESEARCH_EXOTIC_COORDINATES.md) — algorithmic search for exotic point coordinates that make decomposition relations cheaper (prime, binary, Koblitz).
- [`research/nagao_relations/`](research/nagao_relations/README.md) — implemented Riemann–Roch incidence and norm alternatives to summation polynomials, plus function-coefficient search using exact subspace support divisibility; exhaustive toy correctness controls, with no ECDLP speedup claim.
- [`research/notes/ecc2k130/RESEARCH_ISOGENY_CLASS_SEARCH.md`](research/notes/ecc2k130/RESEARCH_ISOGENY_CLASS_SEARCH.md) — exhaustive search of the ECC2K-130 isogeny class for a curve whose Gröbner solving degree is lower: the class structure derived exactly (`Σ_{f|c} h(O_f) = 2^65.06`, conductor `263 · 146505763881528721`), the 263 vertices a computable isogeny reaches, and the proof that the curve coefficient enters the descended Semaev system *below* the leading form — so the degree of regularity is constant on the whole class (`experiments/isogeny_class_search.json`).
- [`research/notes/ecc2k130/RESEARCH_ECC2K130_EXTENSION.md`](research/notes/ecc2k130/RESEARCH_ECC2K130_EXTENSION.md) — whether base-changing ECC2K-130 to `F_2^(131e)` buys a cheaper attack: the target group and its automorphisms are invariant under base change, and because 131 is prime every subfield and every Frobenius-stable subspace of `F_2^(131e)` is either too large to enumerate (`2^131` factor base, `2^70.19×` rho) or too small to generate (contained in the subgroup `E(F_2^e)`, so no relation exists), with nothing in between at any `e` (`experiments/ecc2k130_extension_field_boundary.json`).
- [`research/notes/ecc2k130/RESEARCH_ECC2K130_HYPERELLIPTIC.md`](research/notes/ecc2k130/RESEARCH_ECC2K130_HYPERELLIPTIC.md) — whether ECC2K-130 maps to a hyperelliptic curve of another genus: covers over `F_2^131` exist in every genus and all cost at least `2^131` (`2^70.19×` rho), while for the ordinary GHS/MMT model descending from `F_2^131` to `F_2`, the attainable magic numbers are `1` and `131`, giving genus `1`, `2^130−1`, or `2^130` (2 is a primitive root mod 131; corrected 2026-10-13 from the plain-orbit `m = 130` / `2^129` branch, see `docs/audits/GHS_MAGIC_NUMBER_MMT_CORRECTION_20261013.md`); on the challenge curve's genus-1 branch the transfer is exactly the zero map on `⟨G⟩`. The genus that would pay sits in the window `[130, 290…300]`; the nearest nontrivial GHS branch is `2^121.77` away (corrected 2026-10-06: not from every construction). `⟨G⟩` is `A(F_2)` for a simple 130-dimensional `A` with `#A(F_2) = r` exactly, so any correspondence over `F_2` needs genus `≥ 130` (`experiments/ecc2k130_hyperelliptic_cover_boundary.json`).
- [`research/notes/ecc2k130/RESEARCH_ECC2K130_CURVE_CONSTRUCTION.md`](research/notes/ecc2k130/RESEARCH_ECC2K130_CURVE_CONSTRUCTION.md) — whether a curve carrying the ECC2K-130 subgroup can be produced, by four routes in native Rust (`cryptanalysis::curve_construction`): the reduction of the modular curve `X_H(3²·7²·263²)` carries `A` explicitly at genus `508,799,809 ≈ 2^28.92`, a hundred bits below GHS but `2^20.69` above the window; every geometrically cyclic degree-131 cover of a curve of genus ≤ 1 needs genus `≥ 1300`; exhaustive toys over `F_2` find `A_n` is never itself a Jacobian at `n = 3, 5`, while genus-3 curves carry it at `n = 3`; the Klein quartic is the `n = 3` instance and the non-GHS counterexample that corrects the hyperelliptic note (`research/notes/ecc2k130/curve_construction_20261006/`).
- [`research/notes/ecc2k130/RESEARCH_ECC2K130_DECOMPOSITION.md`](research/notes/ecc2k130/RESEARCH_ECC2K130_DECOMPOSITION.md) — whether an ECC2K-130 point decomposes into a sum of factor-base points, answered in three parts: they **exist** (the yield law `C(|F|,m)/#E` confirmed to within `1.09×` over twelve toy cells, one small-base outlier at `0.57×` aside; `dim V ≥ 45` suffices at `m = 3`), they are **admissible** (the cofactor-4 class histogram measured on the challenge curve admits every `m ≥ 2`, with class parity `= Tr(x(P))` on every sample, and certified `m = 2, 3, 4` witnesses at full size with `S₄ = 0`; a base inside `ker Tr` sits in the index-2 subgroup `2E`, so its sums are spread over `#E/2` and yield **twice** what the law says — measured exhaustively as `0.50×#E` against `1.00×#E` at `n = 13, 17, 19`, worth exactly one bit; and a whole-base yes/no detector **localises its own witness** by swapping a candidate summand for a class-matched base point, measured over eight rungs with zero sub-base queries and both failure modes tracking the `Θ(m/|F|)` collision law, so deciding and localising are the same problem), and they cannot be **found** — `relations × targets × oracle = m·2^131` independently of `dim V`, so the best implicit-base variant is `2^132.58 = 2^71.77×` rho and the best Frobenius-stable one `2^124.99 = 2^64.18×` rho on a materialised base; no table budget from `2^30` to `2^70` entries beats plain BSGS on the same memory, and the oracle would have to beat exhaustive search over its own candidate set by `2^(70.19 + log₂ m)` (`experiments/ecc2k130_point_decomposition.json`).
- [`research/notes/ecc2k130/RESEARCH_ECC2K130_RR_SOLVER_PANEL.md`](research/notes/ecc2k130/RESEARCH_ECC2K130_RR_SOLVER_PANEL.md) — the Riemann-Roch (Nagao) decomposition solvers run on the **real** ECC2K-130 curve against matched Semaev controls, one factor base, one arity, one budget: at `d = 6` the two RR solvers resolve **32/32** slots and both controls **0/32**; 128 trials, zero errors, **28 independently verified three-summand relations** on the challenge curve, every complete planted run recovering its planted triple; `quadratic-image` is the strongest at full size (`0.827x` the counted field operations of `quadratic-optimized` on the same candidate sequence). It prices an **oracle**, not an attack: at `d in {6,7}` a uniform target decomposes with probability at most `5.4e-36`, against `d = 45` for existence, so no yield, `S` or rho ratio is claimed. Then the null-object control lands: brute-force **pair enumeration** exhausts the same `d = 6` instances in **0.494x** the counted field operations and returns identical solution sets, and the method-ceiling measurement to `d = 8` shows the RR encoding visiting about `|F|^2` candidates where pair enumeration visits `|F|^2/2` — same `Theta(|F|^2)` order, constant near two, in the wrong direction. The correct reading is therefore *the better of two algebraic encodings under one SAT solver*, not a good oracle; and the one route that genuinely exploits the `F_2`-subspace structure rather than re-indexing a search — Weil descent of `S_4` in the V-basis, never run at `n = 131` before — yields a **linear NO-certificate** (poly(`d`), no search) that is available only for `d <= 6`, because the `S_4` value set saturates `F_2^131` at `d = 7` while decompositions start at `d = 45`, measured at `d = 45` itself; the falsification target needs a different exponent and nine rounds produced constants. Batching is priced too and cuts the same way
- [`research/notes/ecc2k130/RESEARCH_ECC2K130_DECOMPOSITION_TARGETS.md`](research/notes/ecc2k130/RESEARCH_ECC2K130_DECOMPOSITION_TARGETS.md) — six follow-on experiments with boundaries derived in advance: a scale-model ladder of prime `n` with `2` primitive (the ECC2K-130 obstruction, `n = 11…67`, `Λ = ops/2^n` predicted flat at `m`), the dimension-flatness sweep, the **target-agnosticism** split (there is only *one* free-oracle floor: a whole-base yes/no detector localises its own witness by swapping a candidate summand for a class-matched base point and re-querying, so it is under rho from `m = 4` monotonically, reaching `2^35.86` with no table; only an oracle artificially restricted to a fixed family of targets pays for a witness, and no proposed detector has that shape), guarded large primes, the Poisson yield test, and orbit-union bases — the artefact holds their derived boundaries, and a seven-bit accounting correction to the note above found while stating what E6 would have to measure (`experiments/ecc2k130_decomposition_targets.json`). **All six have now been run**: see the entry below.
- [`research/notes/ecc2k130/RESEARCH_ECC2K130_DECOMPOSITION_RUNS.md`](research/notes/ecc2k130/RESEARCH_ECC2K130_DECOMPOSITION_RUNS.md) — the six experiments above, **run against the boundaries frozen before them**; **no falsifier fired**. `Λ = ops/2^n` on the ladder at `n = 13, 19` with every planted logarithm recovered (slope `1.037` under the full-rank stopping rule; **`0.976 ± 0.024`** under the relation budget the law actually charges, fitted on three rungs `n = 13, 19, 23` — `1.1` standard errors *above* the `0.95` falsifier, where the two-rung fit it supersedes read `0.944 ± 0.028`, *below* it, so the third rung reversed the sign. **There is no fourth rung:** `n = 29` and `n = 37` were never rungs — their prime subgroups are a small part of the curve, cofactors `33 412` and `596` — and censused over `11 ≤ n ≤ 61` only `13, 19, 23, 41` have the ECC2K-130 shape, with `41` costing `6.6 × 10¹²` oracle operations. E1's four-rung falsifier is unfireable on this curve family, which is a fact about the family rather than the tooling; `n = 11` is separately *excluded* because its 23-torsion has rank two); `λ` swept `6 600×` at `n = 19` moves `Λ` by `2.4×`, so the factor-base dimension is measured not to be a lever, and the model's predicted rise above saturation does not occur; large-prime pairing satisfies its guard and at `m = 2` its relations are *differences*, so they cannot span (**the `5–11×` redundancy is withdrawn**, class accounting: it divided rank by however many relations the harness collected, a statistic that spans `52×` across cells and reads `0.0069` on a small base run long; measured at the rank ceiling the cost is `3×`, stable to `2.0×`, and it tracks `2/ln|F|` — the same coupon-collector error as the retraction below, in a second guise); the yield is Poisson to `0.90–1.10` over eight exhaustively-counted cells once `±P` degeneracies are removed (the raw over-dispersion of `1.44–2.98` is entirely those); and the Frobenius orbit collapse delivers **exactly `n`** with independent relations, confirming §6.1; and a real solver's price per oracle call is flat in the descent target to `6.3%` in F4 word operations across seven targets, which is the premise §3.2's swap localisation rests on (a **stage diagnostic** under `AGENTS.md` §8 — one oracle call on one rung, no speedup claimed; `experiments/ecc2k130_e3_solver_panel.json`). **Retracted, class accounting:** this note previously reported that "relations needed to reach full rank run `2.0×` `|F|`" because harvested relations are correlated. Both halves are withdrawn — the excess is the coupon collector `ln|F|/m`, so it grows with the base rather than being a constant; `first_hit`, which shares no target between relations, shows the same excess; and full rank is not what a descent needs. At the `|F|` relations the law budgets, every descent landed and `Λ = 3.103` against a predicted `m = 3`. The `2^124.99` headline is unchanged: `cost_cell` always priced `ρ = 1`, so the retraction removes a caveat rather than buying a bit (`experiments/ecc2k130_decomposition_runs.json`).
- [`research/notes/index-calculus/RESEARCH_INDEX_CALCULUS_FACTOR_BASE.md`](research/notes/index-calculus/RESEARCH_INDEX_CALCULUS_FACTOR_BASE.md) — structured factor bases over GF(p): four open fronts (factor-base no-go, Weil descent, last-fall degree, initial-minors conjecture).
- [`research/notes/ecdlp-general/RESEARCH_SRS_CHEON_CENSUS.md`](research/notes/ecdlp-general/RESEARCH_SRS_CHEON_CENSUS.md) — Cheon's attack priced on the powers-of-tau setups actually deployed, with each setup's size read from its own specification: EIP-4844 mainnet gives away **5.74 bits** against rho (floor `2^121.51`), Zcash Sapling 10.82, Filecoin 13.82, Aztec Ignition 13.12, the Perpetual Powers of Tau **14.32** (floor `2^112.30`). The loss is `½·log₂ d − 0.17` with `d` within 11% of the published exponent on every row, so the leak size, not the curve, sets it. Cross-checked against the public analysis (ethresear.ch #6692): its power-of-two divisors leave half the admissible `d` unused, and the largest admissible divisor makes each attack ≈0.5 bit cheaper (accounting). Floors, not measurements at size; no setup broken; nothing touches the plain ECDLP (`research/srs_auxiliary_census_20260927/`).
- [`research/notes/ecdlp-general/RESEARCH_REPRESENTATION_STRUCTURE.md`](research/notes/ecdlp-general/RESEARCH_REPRESENTATION_STRUCTURE.md) — where exploitable structure can come from, and an admissibility test for candidate handles. Shoup forces any subexponential attack to consume *representation-level* structure, and every attack that has done so shares one architecture: **transfer the problem into a different algebraic category carrying a non-generic algorithm**, licensed by a specific published object — a subfield for Weil descent/Diem (abelian variety, dim `n`), a **torsion-point image** for the SIDH break (Kani 1997, dim 2/4/8), a small **embedding degree** for MOV/Frey-Rück (`F_{q^k}^*`), **trace 1** for SSSA (`(Z_p,+)`, polynomial time), a biased nonce for HNP (a lattice), and leaked **auxiliary inputs** `[α^d]G` for Cheon (a subgroup of `F_p^*`, measured at exponent `0.23` against rho's `0.50` in `RESEARCH_TORSION_AUXILIARY_INPUTS.md`). Five requirements tabulated (R1 consumable object, R2 homomorphism out of the group, R3 algorithm with no generic-group analogue, R4 payload not already poly-time, R5 available at cryptographic parameters), and **murmurations fail all five**, decisively at R4: their payload is the Frobenius trace, which SEA computes in polynomial time and which sits in the parameter set. **Revision 2 records the note's own falsifier F4 firing** (§9.1): the first version demanded a target of dimension >= 2, which MOV and SSSA violate outright; the test was repaired, the murmuration verdict untouched. §9.3 sweeps the repository's measured threads — §9.6 corrects it, since the lattice-HNP folder was skipped and already held measured key recoveries on eight standard curves — with no further counterexample, six in-category threads unanimous at *constants, never exponents*, and R5 split into **R5a** (regime gap, the `S₄` certificate at `d <= 6` against `d = 45`) and **R5b** (the target is worse: ECC2K-130 covers exist in every genus and all cost `>= 2^131`).
- [`docs/DEFERRED.md`](docs/DEFERRED.md) — known gaps + deferred work.
- [`docs/ECDLP_ATTACK_MATRIX.md`](docs/ECDLP_ATTACK_MATRIX.md) — ECDLP attack taxonomy.
- [`docs/ic/BOUNDARY_TARGETS.md`](docs/ic/BOUNDARY_TARGETS.md) — index-calculus per-stage boundary ledger (beat targets for agents).
- [`research/sat_factor_base_review_20260908/autolab/`](research/sat_factor_base_review_20260908/autolab) — agent autolab runner wired to the IC boundary ledger.
- [`research/notes/ecdlp-general/RESEARCH_BENCH_LOG.md`](research/notes/ecdlp-general/RESEARCH_BENCH_LOG.md) — live empirical bench measurements.
- [`gpu/ecc/README.md`](gpu/ecc/README.md) — GPU elliptic-curve kernels.
- [`gpu/ecc/OPTIMIZATION_BLACKWELL.md`](gpu/ecc/OPTIMIZATION_BLACKWELL.md) — Blackwell tuning: cost model + measured occupancy.
- [`gpu/ecc2k/README.md`](gpu/ecc2k/README.md) — Koblitz / ECC2K-95 kernels and the Frobenius-class walk.
- [`gpu/btcpuzzle/README.md`](gpu/btcpuzzle/README.md) — Pollard kangaroo for interval ECDLP.
- [`hdl/ecc/README.md`](hdl/ecc/README.md) — FPGA secp256k1 datapath.
- [`hdl/ecc2k130/README.md`](hdl/ecc2k130/README.md) — FPGA ECC2K-130 engine: normal-basis multiplier, step unit, walker.
- [`docs/ecc_fpga_cost_model.md`](docs/ecc_fpga_cost_model.md) — ECDLP: FPGA vs GPU cost model.
- [`docs/sha1_fpga_cost_model.md`](docs/sha1_fpga_cost_model.md) — SHA-1 collisions: FPGA vs GPU cost model.

---

## References

### Standards

- FIPS 197 — AES
- FIPS 180-4 — SHA-2
- FIPS 202 — SHA-3 / Keccak
- FIPS 203 — ML-KEM (Kyber)
- FIPS 204 — ML-DSA (Dilithium)
- FIPS 205 — SLH-DSA (SPHINCS+)
- FIPS 206 (draft) — FN-DSA (Falcon)
- NIST PQC additional-signatures on-ramp (round 3) — UOV, MAYO, QR-UOV, SNOVA, HAWK, SQIsign, SDitH, MQOM, FAEST
- FIPS 186-4 — ECDSA + NIST curves
- RFC 8439 — ChaCha20-Poly1305
- RFC 7748 — X25519 / X448
- RFC 8032 — EdDSA / Ed25519
- RFC 5869 — HKDF
- RFC 8018 — PBKDF2
- RFC 5639 — Brainpool curves
- RFC 6979 — Deterministic ECDSA nonces
- SEC 1 / SEC 2 — Elliptic curve standards (Certicom)
- GB/T 32905 / 32907 / 32918 — SM3 / SM4 / SM2
- GOST R 34.10-2012, 34.11-2012, 34.12-2015 — Russian GOST suite

### Cryptanalysis literature

- **D. Wagner**, *The Boomerang Attack*, FSE 1999.
- **E. Biham, O. Dunkelman, N. Keller**, *The Rectangle Attack*, EUROCRYPT 2001.
- **O. Dunkelman, N. Keller, A. Shamir**, *A Practical-Time Related-Key Attack
  on KASUMI*, CRYPTO 2010.
- **C. Cid, T. Huang, T. Peyrin, Y. Sasaki, L. Song**, *Boomerang Connectivity
  Table*, EUROCRYPT 2018.
- **A. Bar-On, O. Dunkelman, N. Keller, A. Weizman**, *DLCT: A New Tool for
  Differential-Linear Cryptanalysis*, EUROCRYPT 2019.
- **J. Daemen, L. Knudsen, V. Rijmen**, *The Block Cipher Square*, FSE 1997.
- **E. Biham, A. Shamir**, *Differential Cryptanalysis of DES-like
  Cryptosystems*, CRYPTO 1990.
- **M. Matsui**, *Linear Cryptanalysis Method for DES Cipher*, EUROCRYPT 1993.
- **I. Semaev**, *Summation polynomials and the discrete logarithm problem
  on elliptic curves*, ePrint 2004/031.
- **C. Diem**, *On the discrete logarithm problem in elliptic curves*,
  Compositio Math. 147 (2011).
- **N. Smart**, *The discrete logarithm problem on elliptic curves of trace
  one*, J. Cryptology 12 (1999).
- **P. Q. Nguyen, I. Shparlinski**, *The insecurity of the digital signature
  algorithm with partially known nonces*, J. Cryptology 15 (2002).
- **D. Bleichenbacher**, *On the generation of one-time keys in DL signature
  schemes*, IEEE P1363 submission (2000).
- **P. W. Shor**, *Polynomial-time algorithms for prime factorization and
  discrete logarithms on a quantum computer*, SIAM 1997.
- **A. K. Lenstra, H. W. Lenstra Jr., L. Lovász**, *Factoring polynomials
  with rational coefficients*, Math. Ann. 261 (1982).
- **Fried, Gaudry, Heninger, Thomé**, *A kilobit hidden SNFS discrete
  logarithm computation*, EUROCRYPT 2017.

## Verified Boolean solver comparisons

See [the Gröbner comparison protocol](groebner_compare/README.md) for the bounded
Boolean worker runner, independent basis certificates, learn/apply fallback
accounting, and immutable diagnostic receipts. These are solver-stage controls;
no full-DLP speedup or research-state transition is implied.

## Certicom ECC2-131 and ECCp-131

The random binary ECC2-131 and prime-field ECCp-131 challenges are in the
curve catalog. `ECC2-130` and `ECCp-130` are accepted aliases for these
published 131-bit names. ECC2K-130 retains its separate Koblitz parameters.
Both challenge loaders in [`src/ecc/certicom.rs`](src/ecc/certicom.rs)
return the published generator, subgroup order, cofactor, and target Q from
[Certicom's parameter list](https://www.certicom.com/en/curves-list).

```sh
cargo run --release --bin icx -- inspect ECC2-130 --json
cargo run --release --bin icx -- inspect ECCp-130 --json
cargo run --release --bin ecdlp-nist -- solve ECCp-130 --secret 42 --interval-bits 8 --method bsgs --json
```

`ecdlp-nist solve <curve> --challenge` selects the published Q for either
field. Full-width solving retains the existing feasibility and iteration
budgets. The tests check both published points on each curve and verify
`[n]G = [n]Q = O`; interval tests recover planted scalars. This adds parameter
and arithmetic coverage; it does not establish a full-width challenge solution.

All three requested solvers also share an exact-curve entry point:

```sh
cargo run --release --bin icx -- solve ECC2-130 --method bsgs --secret 12345 --interval-width 65536 --json
cargo run --release --bin icx -- solve ECCp-130 --method rho --challenge --max-iterations 16 --max-restarts 0 --json
cargo run --release --bin icx -- solve ECC2-130 --method index-calculus --challenge --factor-base-size 16 --max-iterations 32 --json
```

Each method accepts either challenge and aliases. `icx solve` uses the exact
published field, curve, generator, subgroup order and target; `icx run` remains
the separate smaller-analogue experiment interface. `--point X,Y` supplies an
external target and `--secret K` constructs a known-answer target. Scalars,
coordinates, interval bounds and matrix coefficients retain their full width.
Unfinished searches report `budget_exhausted`, no scalar, and a nonzero exit.
BSGS caps its baby table with `--max-table-entries`; rho's iteration limit is
per restart. IC caps relation and descent queries separately and bounds its
signed-point table and dense matrix with `--max-table-entries` and
`--max-matrix-entries`.

The native [solver API](src/cryptanalysis/certicom_dlp/mod.rs) exposes `rho`,
`bsgs`, and `index_calculus`. IC constructs a cofactor-cleared low-x factor
base, decomposes public queries into signed pairs, collects verified relations,
solves their full-width system modulo the subgroup order, checks every base
log by scalar replay, and descends the target. It requires full matrix rank;
it never substitutes rho or BSGS for a failed IC stage.

For externally prepared IC work, `--preparation FILE.json` accepts these fields:

| field | contents |
| --- | --- |
| `curve` | The exact challenge name or its alias. |
| `factor_base` | An array of `{ "x": "0x...", "y": "0x..." }` public subgroup points. |
| `relation_queries` | Integer strings `a` whose points `[a]G` are decomposed to build the relation matrix. |
| `descent_shifts` | Integer strings `a` for the target queries `Q + [a]G`. |
| `label` | Optional provenance text retained in the output. |

Integers accept decimal or `0x` hex. Preparation files contain no factor-base
logs or target log. Points, subgroup membership, duplicate sign orbits, matrix
rank and scalar replay are checked. See the [functional tests](tests/certicom_solvers.rs)
for constructed examples on both exact curves: BSGS recovers a scalar above
`2^100`, rho recovers the special known answer `Q = -G`, and IC learns three
base logs through a full-rank relation system and performs target descent.
These are correctness fixtures, not natural-target yield or speed measurements.

The same three methods support portable CPUs, NVIDIA CUDA and Apple Metal.
CPU execution is the default. Build the matching native worker and select it
explicitly:

```sh
make -C gpu/certicom cuda ARCH=sm_80
target/release/icx solve ECCp-130 --method rho --challenge --max-iterations 16 --max-restarts 0 --backend cuda --gpu-worker gpu/certicom/certicom_cuda --json
# On a Mac with Metal:
make -C gpu/certicom metal
target/release/icx solve ECC2-130 --method bsgs --secret 12345 --interval-width 65536 --backend metal --gpu-worker gpu/certicom/certicom_metal --json
```

Explicit GPU selection fails if the requested device is unavailable.
`--backend auto` may choose CPU and reports its choice; `gpu-emulator` is
explicitly labelled host execution. GPU rho runs parallel full-width walks;
BSGS batches point generation; IC offloads query generation and decomposition
while its modular linear algebra and independent verification stay on CPU.
See [GPU setup and hardware qualification](gpu/certicom/README.md) for build
requirements, device ordinals, batch/walk budgets, deadlines and tests.
cargo build --release --bin ecbench
ECBENCH=target/release/ecbench bash research/ecbench_rootfind_engine_20261012/run.sh
```
