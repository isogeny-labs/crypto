exec bash research/f4_f5_ecbench_20261019/run-ecbench.sh
