import WalkWeighted

/-! Exact ideal random-function in-degree moments for finite step supports.
The graph uses actual addition, not an assumed random-map transition table.
No collision-time or mixing-time asymptotic is asserted. -/
namespace WalkWeightedGeneralAudit
noncomputable section
open scoped BigOperators ENNReal
variable {G I : Type*} [Fintype G] [Fintype I] [DecidableEq G] [DecidableEq I]

abbrev Hash (G I : Type*) := G → I

def weight (p : I → ℝ) (h : Hash G I) : ℝ := ∏ x : G,p (h x)
def expectation (p : I → ℝ) (F : Hash G I → ℝ) : ℝ :=
  ∑ h : Hash G I,weight p h*F h

def delta (i j : I) : ℝ := if i=j then 1 else 0

def coordinateGate (y : G) (i : I) (x : G) (j : I) : ℝ :=
  if x=y then delta j i else 1

theorem weight_sum (p : I → ℝ) (hp : ∑ i,p i=1) :
    (∑ h : Hash G I,weight p h)=1 := by
  unfold weight
  rw [←Fintype.prod_sum]
  simp only [hp,Finset.prod_const_one]

theorem weight_nonnegative (p : I → ℝ) (hp : ∀ i,0≤p i) (h : Hash G I) :
    0≤weight p h := Finset.prod_nonneg (fun x _=>hp (h x))

def hashLaw (p : I → ℝ) (hp0 : ∀ i,0≤p i) (hp : ∑ i,p i=1) : PMF (Hash G I) :=
  PMF.ofFintype (fun h=>ENNReal.ofReal (weight p h)) (by
    rw [←ENNReal.ofReal_sum_of_nonneg (fun h _=>weight_nonnegative p hp0 h)]
    rw [weight_sum p hp]
    simp)

theorem hashLaw_real_mass (p : I → ℝ) (hp0 : ∀ i,0≤p i) (hp : ∑ i,p i=1)
    (h : Hash G I) : (hashLaw p hp0 hp h).toReal=weight p h := by
  exact ENNReal.toReal_ofReal (weight_nonnegative p hp0 h)

theorem expectation_product (p : I → ℝ) (F : G → I → ℝ) :
    expectation p (fun h=>∏ x : G,F x (h x))=∏ x : G,∑ i : I,p i*F x i := by
  unfold expectation weight
  simp only [←Finset.prod_mul_distrib]
  exact (Fintype.prod_sum _).symm

theorem expectation_sum {J : Type*} [Fintype J] (p : I → ℝ)
    (F : J → Hash G I → ℝ) :
    expectation p (fun h=>∑ i : J,F i h)=∑ i : J,expectation p (F i) := by
  unfold expectation
  simp only [Finset.mul_sum]
  exact Finset.sum_comm

theorem coordinate_product (y : G) (i : I) (h : Hash G I) :
    (∏ x : G,coordinateGate y i x (h x))=delta (h y) i := by
  exact Fintype.prod_ite_eq' y (fun x=>delta (h x) i)

theorem expectation_coordinate (p : I → ℝ) (hp : ∑ i,p i=1) (y : G) (i : I) :
    expectation p (fun h=>delta (h y) i)=p i := by
  calc
    _=expectation p (fun h=>∏ x : G,coordinateGate y i x (h x)) := by
      simp only [coordinate_product]
    _=∏ x : G,∑ j : I,p j*coordinateGate y i x j := expectation_product p _
    _=∏ x : G,if x=y then p i else 1 := by
      congr 1
      ext x
      by_cases hx : x=y <;> simp [coordinateGate,hx,delta,mul_ite,hp]
    _=p i := Fintype.prod_ite_eq' y (fun _=>p i)

theorem expectation_two_coordinates (p : I → ℝ) (hp : ∑ i,p i=1)
    (y z : G) (hyz : y≠z) (i j : I) :
    expectation p (fun h=>delta (h y) i*delta (h z) j)=p i*p j := by
  calc
    _=expectation p (fun h=>∏ x : G,
        coordinateGate y i x (h x)*coordinateGate z j x (h x)) := by
      simp only [Finset.prod_mul_distrib,coordinate_product]
    _=∏ x : G,∑ k : I,p k*(coordinateGate y i x k*coordinateGate z j x k) :=
      expectation_product p _
    _=∏ x : G,(if x=y then p i else 1)*(if x=z then p j else 1) := by
      congr 1
      ext x
      by_cases hxy : x=y
      · subst x
        simp [coordinateGate,hyz,delta,mul_ite,hp]
      · by_cases hxz : x=z
        · subst x
          simp [coordinateGate,hxy,delta,mul_ite,hp]
        · simp [coordinateGate,hxy,hxz,hp]
    _=p i*p j := by simp only [Finset.prod_mul_distrib,Fintype.prod_ite_eq']

theorem delta_idempotent (i j : I) : delta i j*delta i j=delta i j := by
  unfold delta
  split_ifs <;> norm_num

section Graph
variable [AddCommGroup G]

def step (increments : I → G) (h : Hash G I) (x : G) : G := x+increments (h x)

def inDegree (increments : I → G) (h : Hash G I) (target : G) : ℝ :=
  ((Finset.univ.filter (fun x : G=>step increments h x=target)).card : ℝ)

theorem inDegree_eq_coordinates (increments : I → G) (h : Hash G I) (target : G) :
    inDegree increments h target=∑ i : I,delta (h (target-increments i)) i := by
  classical
  have hs : (∑ x : G,if x+increments (h x)=target then (1:ℝ) else 0)=
      ∑ i : I,delta (h (target-increments i)) i := by
    calc
      _=∑ x : G,∑ i : I,if h x=i then
          (if x+increments i=target then (1:ℝ) else 0) else 0 := by simp
      _=∑ i : I,∑ x : G,if x=target-increments i then delta (h x) i else 0 := by
        rw [Finset.sum_comm]
        congr 1
        ext i
        congr 1
        ext x
        simp only [eq_sub_iff_add_eq]
        by_cases hi : h x=i <;> by_cases hx : x+increments i=target <;>
          simp [delta,hi,hx]
      _=∑ i : I,delta (h (target-increments i)) i := by simp
  unfold inDegree step
  rw [Finset.card_filter]
  norm_cast
  exact hs

theorem inDegree_mean (p : I → ℝ) (hp : ∑ i,p i=1) (increments : I → G)
    (target : G) : expectation p (fun h=>inDegree increments h target)=1 := by
  simp_rw [inDegree_eq_coordinates]
  rw [expectation_sum]
  simp only [expectation_coordinate p hp,hp]

end Graph

#print axioms inDegree_mean
end
end WalkWeightedGeneralAudit
