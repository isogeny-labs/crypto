#!/usr/bin/env python3
"""Approved storage I/O only. Credentials enter via echo-disabled stdin, never files/argv."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import termios
import time

ROOT = Path('/workspace/crypto-fb-excess')
BASE = Path('/workspace/fb-excess-validation-20261026')
OUT = BASE / ('publication-' + time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()))
OUT.mkdir()
ART = BASE / 'artifacts-storage-current.py'
GATE = BASE / 'checkpoint-storage-current.sh'
AWS = Path('/workspace/fb-s3-cli-venv/bin/aws')
EXPECTED = 'fb2b6e1f4c4283f82f2ef7e33cddbb3b9774d6003e6c1892a9f7f02afd7b4982'
REL = Path('research/factor_base_excess_20261026/validation/checks.tar.xz')
URI = 's3://setec-astronomy-artifacts/store/sha256/fb/' + EXPECTED

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def git_blob(path):
    b = Path(path).read_bytes()
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()

assert git_blob(ART) == '002ea0e9d6810960a2fca133a0f308af327ba835'
assert git_blob(GATE) == 'e2008d31938f48996b3a485f2dfa4c64154615de'
assert sha(BASE / 'checks.tar.xz') == EXPECTED
assert (BASE / 'checks.tar.xz').stat().st_size == 73608

fd = sys.stdin.fileno()
settings = termios.tcgetattr(fd)
settings[3] &= ~termios.ECHO
termios.tcsetattr(fd, termios.TCSANOW, settings)
print('Ephemeral credential input ready; terminal echo disabled. Records: ' + str(OUT), flush=True)
try:
    supplied = json.loads(sys.stdin.readline())
    key = supplied.pop('access_key_id')
    secret = supplied.pop('secret_access_key')
    assert not supplied and isinstance(key, str) and isinstance(secret, str)
except Exception:
    print('Credential input rejected; no input contents logged.', flush=True)
    raise SystemExit(2)

def sanitize(b):
    for value in (key, secret):
        b = b.replace(value.encode(), b'[REDACTED]')
    return b

env = os.environ.copy()
env.pop('AWS_PROFILE', None)
env.pop('AWS_SESSION_TOKEN', None)
env['AWS_ACCESS_KEY_ID'] = key
env['AWS_SECRET_ACCESS_KEY'] = secret
env.setdefault('AWS_DEFAULT_REGION', 'us-east-2')
env['ARTIFACTS_AWS'] = str(AWS)
env['ARTIFACTS_CACHE'] = str(OUT / 'cache-upload')
env['ARTIFACTS_NO_READ_URL'] = '1'
env['GIT_CONFIG_COUNT'] = '1'
env['GIT_CONFIG_KEY_0'] = 'gc.auto'
env['GIT_CONFIG_VALUE_0'] = '0'
env['TMPDIR'] = str(OUT / 'tmp')
(OUT / 'tmp').mkdir()

# Transparent AWS CLI relay captures only the checkpoint payload's non-secret hash before upload.
relay = OUT / 'bin'
relay.mkdir()
(relay / 'aws').write_text('''#!/usr/bin/env python3
import os,sys,json,hashlib
from pathlib import Path
a=sys.argv[1:]
if 's3' in a:
 i=a.index('s3')
 if len(a)>i+3 and a[i+1]=='cp':
  src,dst=a[i+2:i+4]
  if Path(src).is_file() and dst.startswith('s3://setec-astronomy-artifacts/checkpoints/') and dst.endswith('/checkpoint.tar.gz'):
   p=Path(src)
   with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
   Path(os.environ['CHECKPOINT_HASH_RECEIPT']).write_text(json.dumps({'sha256':h,'bytes':p.stat().st_size,'target':dst})+'\\n')
os.execv('/workspace/fb-s3-cli-venv/bin/aws',['/workspace/fb-s3-cli-venv/bin/aws']+a)
''')
(relay / 'aws').chmod(0o700)
env['PATH'] = str(relay) + ':' + str(AWS.parent) + ':' + env['PATH']
env['CHECKPOINT_HASH_RECEIPT'] = str(OUT / 'checkpoint-upload-source.json')

class Failure(Exception):
    pass

def run(label, args, cwd=ROOT, child_env=None, timeout=180):
    (OUT / (label + '.command.json')).write_text(json.dumps(args, indent=2) + '\n')
    try:
        p = subprocess.run(args, cwd=cwd, env=child_env or env, capture_output=True, timeout=timeout)
        out, err, code = p.stdout, p.stderr, p.returncode
    except subprocess.TimeoutExpired as e:
        out, err, code = e.stdout or b'', e.stderr or b'', 124
    (OUT / (label + '.stdout')).write_bytes(sanitize(out))
    (OUT / (label + '.stderr')).write_bytes(sanitize(err))
    (OUT / (label + '.exit')).write_text(str(code) + '\n')
    print(label + ': exit ' + str(code), flush=True)
    if code:
        print(sanitize(err).decode(errors='replace')[-1800:], flush=True)
        raise Failure(label)
    return out

status = {'schema': 'approved_storage_publication/v1', 'artifact_uri': URI,
          'artifact_sha256': EXPECTED, 'artifact_bytes': 73608,
          'artifact_published': False, 'fresh_download_verified': False,
          'checkpoint_uploaded': False, 'checkpoint_readback_verified': False,
          'credentials_written_to_files': False, 'new_research_runs': 0}
try:
    if (ROOT / REL).exists():
        assert sha(ROOT / REL) == EXPECTED
    else:
        shutil.copyfile(BASE / 'checks.tar.xz', ROOT / REL)
    run('artifact-push', ['python3', str(ART), 'push', str(REL), '--jobs', '1'])
    status['artifact_published'] = True
    run('artifact-verify-remote', ['python3', str(ART), 'verify', str(REL), '--remote'])
    shutil.move(ROOT / REL, OUT / 'verified-upload-local-copy.tar.xz')
    fresh = dict(env)
    fresh['ARTIFACTS_CACHE'] = str(OUT / 'cache-fresh-download')
    assert not Path(fresh['ARTIFACTS_CACHE']).exists()
    run('artifact-fresh-pull', ['python3', str(ART), 'pull', str(REL), '--jobs', '1'], child_env=fresh)
    assert sha(ROOT / REL) == EXPECTED and (ROOT / REL).stat().st_size == 73608
    run('artifact-fresh-verify', ['python3', str(ART), 'verify', str(REL), '--remote'], child_env=fresh)
    status['fresh_download_verified'] = True
    extracted = OUT / 'archive-extracted'
    extracted.mkdir()
    run('archive-extract', ['tar', '-xJf', str(ROOT / REL), '-C', str(extracted)])
    run('archive-members', ['sha256sum', '-c', str(ROOT / REL.parent / 'CHECKS_SHA256SUMS')], cwd=extracted)
    resume = ROOT / '.resume/RESUME.md'
    resume.write_text(resume.read_text() + '\nCurrent storage follow-up: explicit newly supplied credential pair used only in child-process memory. The exact validation archive is now uploaded by canonical tools at ' + URI + '; remote checksum/metadata and a complete fresh-cache download/hash verified. Actual source remains named historical7d; current main sources are not thereby validated. No experiment launched. Storage records: ' + str(OUT) + '. Checkpoint creation follows; final outcome is recorded externally, with no key values.\n')
    run('checkpoint-gate', ['bash', str(GATE), 'gate'], timeout=240)
    status['checkpoint_uploaded'] = True
    last = (ROOT / '.resume/.last-push').read_text().strip().split()[-1]
    assert last.startswith('s3://setec-astronomy-artifacts/checkpoints/')
    status['checkpoint_uri'] = last
    pack = OUT / 'checkpoint-fresh-readback.tar.gz'
    run('checkpoint-fresh-download', [str(AWS), 's3', 'cp', last + 'checkpoint.tar.gz', str(pack), '--no-progress', '--only-show-errors'])
    source_receipt = OUT / 'checkpoint-upload-source.json'
    if source_receipt.exists():
        source = json.loads(source_receipt.read_text())
        assert sha(pack) == source['sha256'] and pack.stat().st_size == source['bytes']
        status['checkpoint_payload_source_hash_matches_readback'] = True
    else:
        status['checkpoint_payload_source_hash_matches_readback'] = None
    with tarfile.open(pack, 'r:gz') as t:
        members = {m.name.removeprefix('./'): m for m in t.getmembers()}
        rb = t.extractfile(members['RESUME.md']).read()
        meta = json.load(t.extractfile(members['meta.json']))
    assert rb == resume.read_bytes()
    assert meta['head'] == subprocess.check_output(['git', '-c', 'gc.auto=0', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    status['checkpoint_readback_verified'] = True
    status['checkpoint_payload_sha256'] = sha(pack)
    print('Archive remote checksum/full fresh readback and checkpoint full readback verified.', flush=True)
except Failure as e:
    status['failed_step'] = str(e)
except Exception as e:
    status['failed_step'] = 'verification: ' + type(e).__name__
    print('Verification did not complete: ' + type(e).__name__, flush=True)
finally:
    (OUT / 'RESULT.json').write_text(json.dumps(status, indent=2) + '\n')
    env.pop('AWS_ACCESS_KEY_ID', None)
    env.pop('AWS_SECRET_ACCESS_KEY', None)
    key = secret = None
    print('RESULT: ' + str(OUT / 'RESULT.json'), flush=True)
raise SystemExit(0 if status['checkpoint_readback_verified'] else 1)
