#!/usr/bin/env bash
set -u
root=/workspace/fb-shape-leads-20261018
study=/workspace/crypto-fb-sweeper/research/factor_base_shape_leads_20261018
mkdir -p "$root/runs"
date -u +%Y-%m-%dT%H:%M:%SZ > "$root/runs/started.txt"
uname -a > "$root/runs/uname.txt"
lscpu > "$root/runs/lscpu.txt"
sha256sum /home/agent/.local/bin/factor-base-sweep > "$root/runs/executable.sha256"
git -C /workspace/crypto-fb-sweeper rev-parse HEAD > "$root/runs/protocol-commit.txt"
cp "$study/plans/primary.json" "$study/plans/secondary.json" "$study/plans/SHA256SUMS" "$root/runs/"
result=0
for panel in primary secondary; do
  factor-base-sweep run --plan "$study/plans/$panel.json" --out "$root/runs/$panel" > "$root/runs/$panel.stdout.json" 2> "$root/runs/$panel.stderr.log"
  status=$?
  printf '%s\n' "$status" > "$root/runs/$panel.exit"
  if [ "$status" -ne 0 ]; then result=1; fi
  factor-base-sweep verify --run "$root/runs/$panel" > "$root/runs/$panel.verify.json" 2> "$root/runs/$panel.verify.stderr"
  status=$?
  printf '%s\n' "$status" > "$root/runs/$panel.verify.exit"
  if [ "$status" -ne 0 ]; then result=1; fi
done
date -u +%Y-%m-%dT%H:%M:%SZ > "$root/runs/finished.txt"
printf '%s\n' "$result" > "$root/runs/pipeline.exit"
exit "$result"
