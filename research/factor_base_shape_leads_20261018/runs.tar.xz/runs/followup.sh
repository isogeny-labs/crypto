#!/usr/bin/env bash
set -u
root=/workspace/fb-shape-leads-20261018
study=/workspace/crypto-fb-sweeper/research/factor_base_shape_leads_20261018
date -u +%Y-%m-%dT%H:%M:%SZ > "$root/runs/followup-started.txt"
git -C /workspace/crypto-fb-sweeper rev-parse HEAD > "$root/runs/followup-protocol-commit.txt"
cp "$study/plans/confirmation.json" "$study/plans/representation.json" "$study/plans/FOLLOWUP_SHA256SUMS" "$root/runs/"
result=0
for panel in confirmation representation; do
  factor-base-sweep run --plan "$study/plans/$panel.json" --out "$root/runs/$panel" > "$root/runs/$panel.stdout.json" 2> "$root/runs/$panel.stderr.log"
  status=$?
  printf '%s\n' "$status" > "$root/runs/$panel.exit"
  if [ "$status" -ne 0 ]; then result=1; fi
  factor-base-sweep verify --run "$root/runs/$panel" > "$root/runs/$panel.verify.json" 2> "$root/runs/$panel.verify.stderr"
  status=$?
  printf '%s\n' "$status" > "$root/runs/$panel.verify.exit"
  if [ "$status" -ne 0 ]; then result=1; fi
done
date -u +%Y-%m-%dT%H:%M:%SZ > "$root/runs/followup-finished.txt"
printf '%s\n' "$result" > "$root/runs/followup.exit"
exit "$result"
