study=research/factor_base_shape_leads_20261018
replay="$RUNNER_TEMP/factor-base-shape-evidence"
mkdir -p "$replay"
(cd "$study" && sha256sum -c runs.tar.xz.sha256)
tar -xJf "$study/runs.tar.xz" -C "$replay"
(cd "$replay" && sha256sum -c "$GITHUB_WORKSPACE/$study/RUNS_SHA256SUMS")
for panel in primary secondary confirmation representation subgroup-guard; do
  "$CARGO_TARGET_DIR/release/factor-base-sweep" verify --run "$replay/runs/$panel"
done
"$CARGO_TARGET_DIR/release/factor-base-lead-audit" "$replay/runs" primary secondary confirmation representation > "$replay/observations.json"
cmp "$study/observations.json" "$replay/observations.json"
"$CARGO_TARGET_DIR/release/factor-base-lead-audit" --coverage "$replay/runs" docs/curves/registry.json primary secondary confirmation representation > "$replay/coverage.json"
cmp "$study/exact-coverage.json" "$replay/coverage.json"
