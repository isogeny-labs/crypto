p=59;A=1;B=13;c=55;identifier="icv1-fp6-tm7-fc20da94";
jstr(z)=Str(Strchr(34),z,Strchr(34));
H=hyperellcharpoly(Mod(1,p)*((x^2+c)^3+A*(x^2+c)+B));
print("{",jstr("fixture"),":",jstr(identifier),",",jstr("coefficients"),":",Vec(H),",",jstr("jacobian_order"),":",subst(H,variable(H),1),"}");
quit;
