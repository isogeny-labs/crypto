p=251;A=248;B=104;c=127;identifier="icv1-fp8-tm5-23216e9c";
jstr(z)=Str(Strchr(34),z,Strchr(34));
H=hyperellcharpoly(Mod(1,p)*((x^2+c)^3+A*(x^2+c)+B));
print("{",jstr("fixture"),":",jstr(identifier),",",jstr("coefficients"),":",Vec(H),",",jstr("jacobian_order"),":",subst(H,variable(H),1),"}");
quit;
