p=2879;A=2876;B=66;c=1525;identifier="icv1-fp12-t61-a9fcb1fd";
jstr(z)=Str(Strchr(34),z,Strchr(34));
H=hyperellcharpoly(Mod(1,p)*((x^2+c)^3+A*(x^2+c)+B));
print("{",jstr("fixture"),":",jstr(identifier),",",jstr("coefficients"),":",Vec(H),",",jstr("jacobian_order"),":",subst(H,variable(H),1),"}");
quit;
