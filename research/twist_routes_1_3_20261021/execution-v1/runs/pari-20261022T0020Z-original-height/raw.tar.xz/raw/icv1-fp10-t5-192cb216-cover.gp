p=827;A=1;B=15;c=431;identifier="icv1-fp10-t5-192cb216";
jstr(z)=Str(Strchr(34),z,Strchr(34));
H=hyperellcharpoly(Mod(1,p)*((x^2+c)^3+A*(x^2+c)+B));
print("{",jstr("fixture"),":",jstr(identifier),",",jstr("coefficients"),":",Vec(H),",",jstr("jacobian_order"),":",subst(H,variable(H),1),"}");
quit;
