#!/usr/bin/env bash
set -euo pipefail
cd /workspace/crypto-ecbench-hashed
task_receipts=/workspace/scratch/point-hash-accounting-20261115
task_ordinary=/tmp/hashed-ecbench-target/release/examples/native_point_hash_study
task_accounting=/tmp/hashed-ecbench-target/release/examples/native_point_hash_accounting
mkdir "$task_receipts/historical"
tar -xf research/native_point_hashing_20261105/pilot-v1/orchestration-development.tar.xz -C "$task_receipts/historical" orchestration-development/cli-control-qualified
"$task_ordinary" execute-plan "$task_receipts/development-plan.json" "$task_receipts/accounting-final" "$(( $(date +%s) + 30 ))" "$task_accounting" > "$task_receipts/execute-accounting.final.stdout.log" 2> "$task_receipts/execute-accounting.final.stderr.log"
"$task_ordinary" execute-plan "$task_receipts/development-plan.json" "$task_receipts/plain-final" "$(( $(date +%s) + 30 ))" > "$task_receipts/execute-plain.final.stdout.log" 2> "$task_receipts/execute-plain.final.stderr.log"
"$task_ordinary" analyze-plan "$task_receipts/development-plan.json" "$task_receipts/accounting-final" "$task_receipts/accounting-final-analysis.json" > "$task_receipts/analyze-accounting.final.stdout.log" 2> "$task_receipts/analyze-accounting.final.stderr.log"
"$task_ordinary" qualify-development-accounting "$task_receipts/development-plan.json" "$task_receipts/plain-final" "$task_receipts/accounting-final" "$task_receipts/historical/orchestration-development/cli-control-qualified" > "$task_receipts/parity.final.json" 2> "$task_receipts/parity.final.stderr.log"
"$task_ordinary" check-plan research/native_point_hashing_20261105/pilot-v1/pilot-plan.json > "$task_receipts/check-production-plan.final.stdout.log" 2> "$task_receipts/check-production-plan.final.stderr.log"
cat "$task_receipts/parity.final.json"
