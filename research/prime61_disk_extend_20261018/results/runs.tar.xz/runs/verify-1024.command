timeout 900 /workspace/prime61-frozen-target/release/examples/isogeny_disk_walk verify research/prime61_disk_extend_20261018/spec.json research/prime61_disk_extend_20261018/results/runs/walk.db 0 
