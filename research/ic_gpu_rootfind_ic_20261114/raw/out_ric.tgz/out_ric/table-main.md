| session | arm | method | curve | log2 r | verified | mean S | 95% interval | theory S | S / theory | S / floor | S / reference | lower bound | med wall ms | levels | flags |
|---|---|---|---|---:|---:|---:|---|---:|---:|---:|---:|---|---:|---|---|
| ECBS1h4e6f1172cc49 | rho-neg | rho.negation | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 0.977 | [0.081, 11.790] indicative | 0.886 | 1.103 | 1.103 | 1.000 | yes | 1.484 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rho-neg | rho.negation | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 1.369 | [1.252, 1.496] indicative | 0.886 | 1.545 | 1.545 | 1.000 | yes | 4.575 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rho-neg | rho.negation | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 1.132 | [0.020, 62.479] indicative | 0.886 | 1.277 | 1.277 | 1.000 | yes | 4.565 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rf2-cpu-F4096 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 6259.093 | [5321.814, 7361.445] indicative | – | – | 7062.630 | 6403.353 | yes | 1940.294 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rf2-cpu-F4096 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 18006.622 | [14480.828, 22390.878] indicative | – | – | 20318.298 | 13154.246 | yes | 12927.942 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rf2-cpu-F4096 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 26009.558 | [18135.565, 37302.234] indicative | – | – | 29348.643 | 22985.902 | yes | 28855.627 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rf2-gpu-F4096 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 6259.093 | [5321.814, 7361.445] indicative | – | – | 7062.630 | 6403.353 | yes | 489.794 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rf2-gpu-F4096 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 18006.622 | [14480.828, 22390.878] indicative | – | – | 20318.298 | 13154.246 | yes | 508.628 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rf2-gpu-F4096 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 26009.558 | [18135.565, 37302.234] indicative | – | – | 29348.643 | 22985.902 | yes | 673.031 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rf2-cpu-F16384 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 3639.036 | [1545.380, 8569.141] indicative | – | – | 4106.212 | 3722.909 | yes | 2776.992 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rf2-cpu-F16384 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 14371.028 | [9221.373, 22396.497] indicative | – | – | 16215.969 | 10498.362 | yes | 12467.529 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rf2-cpu-F16384 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 23264.856 | [8753.077, 61835.798] indicative | – | – | 26251.579 | 20560.277 | yes | 28670.041 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rf2-gpu-F16384 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 3639.036 | [1545.380, 8569.141] indicative | – | – | 4106.212 | 3722.909 | yes | 1134.455 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rf2-gpu-F16384 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 14371.028 | [9221.373, 22396.497] indicative | – | – | 16215.969 | 10498.362 | yes | 1415.625 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rf2-gpu-F16384 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 23264.856 | [8753.077, 61835.798] indicative | – | – | 26251.579 | 20560.277 | yes | 1523.103 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rho-neg-aa | rho.negation | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 0.977 | [0.081, 11.790] indicative | 0.886 | 1.103 | 1.103 | 1.000 | yes | 1.506 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rho-neg-aa | rho.negation | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 1.369 | [1.252, 1.496] indicative | 0.886 | 1.545 | 1.545 | 1.000 | yes | 4.578 | L0×4 | – |
| ECBS1h4e6f1172cc49 | rho-neg-aa | rho.negation | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 1.132 | [0.020, 62.479] indicative | 0.886 | 1.277 | 1.277 | 1.000 | yes | 4.696 | L0×4 | – |
