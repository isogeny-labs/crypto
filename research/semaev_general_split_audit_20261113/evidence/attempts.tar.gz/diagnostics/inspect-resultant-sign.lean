import RetainedInterchange
import CanonicalBridge
open Polynomial SemaevReassociationAudit ResultantInterchangeAudit
variable {R : Type*} [CommRing R] (r : Polynomial R) (E : ℕ) (b2 b4 b6 b8 z : R)
set_option pp.all true in
#check (Polynomial.resultant_comm (s3Bi b2 b4 b6 b8 z) (lift r) 2 E)
set_option pp.all true in
#check ((-1:Polynomial R)^(2*E))
