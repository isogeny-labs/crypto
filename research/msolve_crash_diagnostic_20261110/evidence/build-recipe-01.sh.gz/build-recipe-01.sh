#!/usr/bin/env bash
set -euo pipefail
: "${MSOLVE_SOURCE:?unmodified pinned source tree}"
: "${DEPS:?extracted dependency prefix}"
: "${DIAGNOSTIC_BUILD:?new output directory}"
[ "$(git -C "$MSOLVE_SOURCE" rev-parse HEAD)" = 5e72b9d99eaea55fe87eb8ac945ec9e914a69327 ]
[ -z "$(git -C "$MSOLVE_SOURCE" status --porcelain)" ]
mkdir -p "$DIAGNOSTIC_BUILD"
printf '/* Scalar diagnostic configuration; optional SIMD disabled. */\n' > "$DIAGNOSTIC_BUILD/config.h"
cd "$MSOLVE_SOURCE"
gcc -O1 -g -fno-omit-frame-pointer -fsanitize=address,undefined -fno-sanitize-recover=all \
  -fopenmp -DHAVE_CONFIG_H=1 "-I$DIAGNOSTIC_BUILD" "-I$DEPS/usr/include" \
  "-L$DEPS/usr/lib/x86_64-linux-gnu" "-Wl,-rpath,$DEPS/usr/lib/x86_64-linux-gnu" \
  src/msolve/main.c src/neogb/gb.c src/fglm/fglm_core.c src/usolve/usolve.c \
  -o "$DIAGNOSTIC_BUILD/msolve" -lflint -lmpfr -lgmp -lm
