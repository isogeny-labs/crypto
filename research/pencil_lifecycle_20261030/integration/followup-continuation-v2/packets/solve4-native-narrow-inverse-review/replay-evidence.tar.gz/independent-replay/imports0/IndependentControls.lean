import GraphAlgebra
open SignedGraphAlgebra
abbrev F := ZMod 17
-- All four combinations match the direct signed root equation.
theorem all_union_signs : ∀cu∈([1,-1] : List F),∀cv∈([1,-1] : List F),
 let a:=cu*4+cv*7-3*2
 eval (unionPotential cu cv a 3) 7 2=4 ∧
 eval (reverse (unionPotential cu cv a 3)) 4 2=7 := by decide
-- Positive sign fixed-child transport has subtraction, not addition.
theorem positive_fixed_child : (6:F)=1*(14-2)+(1*(0-3))*2 := by decide
theorem wrong_positive_anchor : (6:F)≠1*(14+2)+(1*(0+3))*2 := by decide
-- Non-involutive sign fails to reverse the represented edge.
theorem invalid_sign_reversal : eval (reverse (⟨2,0,0⟩ : Potential F)) 6 0≠3 := by decide
-- First and second fixed anchors imply a target constraint; no solve is inferred from equal anchors.
theorem consistent_anchor_difference : (5:F)+6*2=0 := by decide
theorem equal_anchor_zero_coefficient : (3:F)-3=0 ∧ (4:F)-4=0 := by decide
#print axioms all_union_signs
#print axioms positive_fixed_child
#print axioms wrong_positive_anchor
#print axioms invalid_sign_reversal
#print axioms consistent_anchor_difference
#print axioms equal_anchor_zero_coefficient
