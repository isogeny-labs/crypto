import Narrow
namespace RecoverNarrowPow
set_option maxRecDepth 4096
theorem exponent_zero : modpow 7 0 0 = 1 := by decide
theorem inverse_two : inverseGenerator 2 1 = 1 := by decide
theorem odd_exponent : modpow 7 3 5 = 5 := by decide
theorem even_exponent : modpow 7 3 4 = 4 := by decide
theorem final_square : nextA 7 3 = 2 ∧ nextR 7 3 1 1 = 3 ∧ half 1 = 0 := by decide
theorem upper_exponent : modpow 2 1 18446744073709551615 = 1 := by decide
theorem bound_counterexample : WordComparator.mul 4294967297 4294967296 4294967296 = 0 ∧
 (4294967296 * 4294967296 : Nat) % 4294967297 = 1 := by decide
end RecoverNarrowPow
