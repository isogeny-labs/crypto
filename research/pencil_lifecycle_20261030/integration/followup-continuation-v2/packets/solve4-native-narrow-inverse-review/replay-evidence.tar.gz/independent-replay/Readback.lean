import Controls
#print axioms RecoverNarrowPow.lowbit_one
#print axioms RecoverNarrowPow.binary_step
#print axioms RecoverNarrowPow.nextR_canonical
#print axioms RecoverNarrowPow.nextA_canonical
#print axioms RecoverNarrowPow.next_step
#print axioms RecoverNarrowPow.loop_decode
#print axioms RecoverNarrowPow.modpow_decode
#print axioms RecoverNarrowPow.inverse_exponent
#print axioms RecoverNarrowPow.generator_product
#print axioms RecoverNarrowPow.generator_decode
#print axioms RecoverNarrowPow.exponent_zero
#print axioms RecoverNarrowPow.inverse_two
#print axioms RecoverNarrowPow.odd_exponent
#print axioms RecoverNarrowPow.even_exponent
#print axioms RecoverNarrowPow.final_square
#print axioms RecoverNarrowPow.upper_exponent
#print axioms RecoverNarrowPow.bound_counterexample
