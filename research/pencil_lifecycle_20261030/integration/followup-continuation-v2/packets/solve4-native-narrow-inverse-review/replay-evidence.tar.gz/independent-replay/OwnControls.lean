import Narrow
namespace IndependentNarrow
set_option maxRecDepth 4096
theorem zero_input_not_unit : RecoverNarrowPow.inverseGenerator 7 0 = 0 ∧ WordComparator.mul 7 0 (RecoverNarrowPow.inverseGenerator 7 0) ≠ 1 := by decide
theorem composite_not_inverse : RecoverNarrowPow.inverseGenerator 15 2 = 2 ∧ WordComparator.mul 15 2 (RecoverNarrowPow.inverseGenerator 15 2) ≠ 1 := by decide
theorem insufficient_fuel : RecoverNarrowPow.loop 0 7 3 1 1 = 1 ∧ RecoverNarrowPow.modpow 7 3 1 = 3 := by decide
theorem narrow_boundary_product : WordComparator.mul 4294967296 4294967295 4294967295 = 1 := by decide
end IndependentNarrow
