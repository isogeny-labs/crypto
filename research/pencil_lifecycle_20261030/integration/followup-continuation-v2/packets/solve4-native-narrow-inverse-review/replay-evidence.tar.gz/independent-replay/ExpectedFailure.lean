import Narrow
example : RecoverNarrowPow.inverseGenerator 7 3 = 4 := by decide
