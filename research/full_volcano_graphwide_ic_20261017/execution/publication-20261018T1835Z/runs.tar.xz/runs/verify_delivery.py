"""Byte/file validation only; no experiments or numerical aggregation."""
import datetime
import json
import pathlib
import subprocess
import sys
import tarfile

sys.path.insert(0, '/workspace/repos/crypto/research/full_volcano_graphwide_ic_20261017/execution')
from package_checkpoint import archive_tree, digest

receipt = pathlib.Path('/workspace/volcano_publication_staging_20261018T1835Z')
package = json.loads((receipt / 'package-attempt02.json').read_text())
archive = pathlib.Path(package['path'])
assert archive.stat().st_size == package['bytes'] and digest(archive) == package['sha256']
extracted = pathlib.Path('/workspace/volcano_repaired_6137_extracted_20261018')
extracted.mkdir()
with tarfile.open(archive) as packed:
    members = packed.getmembers()
    for member in members:
        name = pathlib.PurePosixPath(member.name)
        assert not name.is_absolute() and '..' not in name.parts
        assert member.isfile() or member.isdir(), member.name
    archived_files = {m.name for m in members if m.isfile()}
subprocess.run(['tar', '-xJf', str(archive), '-C', str(extracted)], check=True)
with (receipt / 'manifest-check.log').open('w') as log:
    subprocess.run(['sha256sum', '-c', 'MANIFEST.sha256'], cwd=extracted,
                   stdout=log, stderr=subprocess.STDOUT, check=True)
listed = {line.split('  ', 1)[1] for line in (extracted / 'MANIFEST.sha256').read_text().splitlines()}
assert listed == archived_files - {'MANIFEST.sha256'}
assert not (extracted / 'campaign/ledger.sqlite-wal').exists()
assert not (extracted / 'campaign/ledger.sqlite-shm').exists()
# Extraction makes the archive self-contained; a new archive from its regular
# files must have the same bytes as the linked-stage production archive.
repack = pathlib.Path('/workspace/volcano_REPAIRED_6137_repack_20261018.tar.xz')
archive_tree(extracted, repack)
assert digest(repack) == package['sha256']
verified = {'schema': 'volcano-byte-preserving-publication/v1',
            'verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'archive': package, 'fresh_extraction': 'PASS',
            'every_manifest_entry': 'PASS', 'exact_manifest_file_population': 'PASS',
            'only_directories_and_regular_archive_members': 'PASS',
            'outer_repack_byte_identical': 'PASS',
            'manifest_sha256': digest(extracted / 'MANIFEST.sha256'),
            'manifest_check_log_sha256': digest(receipt / 'manifest-check.log'),
            'manifest_entries': len(listed),
            'scope': 'Byte/file handling and native receipt binding, not fresh or independent solver replay; no speed claim.'}
(receipt / 'archive-verified.json').write_text(json.dumps(verified, indent=2) + '\n')
print(json.dumps(verified), flush=True)
