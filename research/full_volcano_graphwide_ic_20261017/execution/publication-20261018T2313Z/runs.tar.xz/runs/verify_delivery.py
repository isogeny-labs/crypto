"""File/byte checks only; native scientific inventory is separate."""
import datetime,json,pathlib,subprocess,sys,tarfile
sys.path.insert(0,'/workspace/repos/crypto/research/full_volcano_graphwide_ic_20261017/execution')
from package_checkpoint import digest
r=pathlib.Path('/workspace/volcano_publication_20261018T2313Z');p=json.loads((r/'package.json').read_text());a=pathlib.Path(p['path']);assert a.stat().st_size==p['bytes'] and digest(a)==p['sha256']
out=pathlib.Path('/workspace/volcano_repaired_7937_extracted_20261019');out.mkdir()
with tarfile.open(a) as packed:
 members=packed.getmembers()
 for m in members:
  path=pathlib.PurePosixPath(m.name);assert not path.is_absolute() and '..' not in path.parts and (m.isfile() or m.isdir()),m.name
 files={m.name for m in members if m.isfile()}
subprocess.run(['tar','-xJf',str(a),'-C',str(out)],check=True)
with (r/'manifest-check.log').open('w') as log:subprocess.run(['sha256sum','-c','MANIFEST.sha256'],cwd=out,stdout=log,stderr=subprocess.STDOUT,check=True)
listed={x.split('  ',1)[1] for x in (out/'MANIFEST.sha256').read_text().splitlines()};assert listed==files-{'MANIFEST.sha256'}
expected={'campaign/driver.rs':'4be4a900afee3f7256c634b9af45bc0c9f65ad134073dbdcaaff99634cf4ec8d','campaign/ecbench':'35d89073f4d666b094c213a1d31b0c819b63600123e067c111af3c947d7609a9','bin/volcano-ic-driver':'b8b489c7225c64ed492ffce39286c995f5ca820960956cf706c0d3110f5bdd2d','campaign/queue.jsonl':'45e277bede6017c30a49405096afefab3d34a18553ecd6b1a79238f2b9559728'}
for name,sha in expected.items():assert digest(out/name)==sha,name
assert not (out/'campaign/ledger.sqlite-wal').exists() and not (out/'campaign/ledger.sqlite-shm').exists()
v={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':p,'fresh_extraction':'PASS','every_manifest_entry':'PASS','exact_file_population':'PASS','only_regular_files_and_directories':'PASS','manifest_entries':len(listed),'manifest_sha256':digest(out/'MANIFEST.sha256'),'manifest_check_log_sha256':digest(r/'manifest-check.log'),'frozen_archived_source_binary_queue_hashes':expected,'outer_repack':'Not rechecked for this publication; unchanged staging/archive implementation has separate actual production copy/extract/repack evidence in publication-20261018T1835Z.','scope':'File/byte validation and existing native receipt binding, not fresh independent solver replay or qualified runtime.'}
(r/'archive-verified.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
