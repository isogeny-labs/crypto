from pathlib import Path
from datetime import datetime, timezone
import fcntl, hashlib, json, math, os, shutil, subprocess, time
root=Path('/workspace/volcano_ic_repaired_survey_20261017')
pub=Path('/workspace/repos/crypto/research/full_volcano_graphwide_ic_20261017/execution/publication-20261018T2313Z')
w=Path('/workspace/volcano_publication_20261018T2313Z')
assert (w/'root-library-result.json').exists(), 'validation must finish first'
assert (pub/'receipt-archive.json').exists(), 'publication receipts required'
assert not (pub/'resumed-launch.json').exists(), 'never launch twice'
bench=open('/tmp/crypto-bench.lock','a')
fcntl.flock(bench,fcntl.LOCK_EX|fcntl.LOCK_NB)
lock=open(root/'writer.lock','a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
expected={'ecbench':'35d89073f4d666b094c213a1d31b0c819b63600123e067c111af3c947d7609a9','volcano-ic-driver':'b8b489c7225c64ed492ffce39286c995f5ca820960956cf706c0d3110f5bdd2d','queue.jsonl':'45e277bede6017c30a49405096afefab3d34a18553ecd6b1a79238f2b9559728','driver.rs':'4be4a900afee3f7256c634b9af45bc0c9f65ad134073dbdcaaff99634cf4ec8d'}
for name,sha in expected.items():
    with (root/name).open('rb') as f: assert hashlib.file_digest(f,'sha256').hexdigest()==sha,name
before=json.loads(subprocess.check_output([str(root/'volcano-ic-driver'),'status',str(root)]))
assert not any(r['state']=='running' for r in before['coverage']),before
exit=json.loads((root/'worker-exit.json').read_text())
worker=json.loads((root/'worker.json').read_text())
assert worker['pid']==exit['pid']==50943 and exit['reason']=='stop_requested'
stop=root/'STOP';st=stop.lstat()
assert stop.is_file() and not stop.is_symlink() and st.st_size==0 and st.st_uid==os.getuid()
deadline=1792527222570
remaining=math.floor((deadline-time.time()*1000)/1000)
assert remaining>0
cap=6442450944
spool=sum(f.stat().st_size for f in root.rglob('*') if f.is_file())
free=shutil.disk_usage(root).free
assert free >= max(0,cap-spool)+1073741824,(free,spool)
argv=['nohup',str(root/'volcano-ic-driver'),'run',str(root),'24823',str(remaining),str(cap)]
envelope={'schema':'volcano-preserved-deadline-resume/v1','created_utc':datetime.now(timezone.utc).isoformat(),'baseline_vertices':7937,'queue_vertices':24823,'argv':argv,'original_deadline_ms':str(deadline),'original_deadline_utc':'2026-10-20T20:13:42.570Z','remaining_seconds':remaining,'max_spool_bytes':cap,'free_bytes_before':free,'spool_logical_bytes_before':spool,'frozen_sha256':expected,'before_status':before,'previous_clean_stop':exit,'authoring_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/repos/crypto',text=True).strip(),'scope':'Unchanged frozen bounded survey; original deadline and child budgets preserved, clocks unqualified; no survival guarantee.'}
(pub/'resume-envelope.json').write_text(json.dumps(envelope,indent=2)+'\n')
log=root/'worker-resume-20261018T2313Z.log'
with log.open('xb') as out:
    stop.unlink()
    fcntl.flock(lock,fcntl.LOCK_UN)
    process=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
launch={'schema':'volcano-detached-launch/v1','launched_utc':datetime.now(timezone.utc).isoformat(),'pid':process.pid,'log':str(log),'argv':argv,'scope':'Launch only. Requires separate own-session/non-zombie process readback AND new audited progress.'}
(pub/'resumed-launch.json').write_text(json.dumps(launch,indent=2)+'\n')
print(json.dumps(launch))
