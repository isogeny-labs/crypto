from pathlib import Path
import hashlib,json,re,subprocess
from datetime import datetime,timezone
w=Path('/workspace/volcano_publication_20261018T2313Z')
p=Path('/workspace/repos/crypto/research/full_volcano_graphwide_ic_20261017/execution/publication-20261018T2313Z')
r=json.loads((w/'root-library-result.json').read_text())
log=(w/'root-library.log').read_text()
result_lines=[line for line in log.splitlines() if line.startswith('test result:')]
assert result_lines, 'inspect non-test failure manually'
metadata={'run':r,'source_head':'39ebf63386db3f04cc55caf2864e9f5e5bc130e4','result_lines':result_lines,'source_scope':'Library validation of imported head; not frozen-worker binary equivalence, independent solver replay, performance qualification or completion of the original experiment.','log_sha256':hashlib.sha256(log.encode()).hexdigest(),'environment':json.loads((w/'root-library-environment.json').read_text())}
b=Path('/workspace/volcano_validation_39eb_20261019/target/release/deps/crypto_lib-565bcb20cb4d5bb4')
if b.exists():
 with b.open('rb') as f: metadata['test_binary']={'path':str(b),'bytes':b.stat().st_size,'sha256':hashlib.file_digest(f,'sha256').hexdigest()}
(w/'root-library-validation.json').write_text(json.dumps(metadata,indent=2)+'\n')
(p/'root-library-validation.json').write_text(json.dumps(metadata,indent=2)+'\n')
v=json.loads((p/'validation.json').read_text());v['subsequent_release_library']=metadata;v['source']='Frozen ROOT driver/source/binaries/queue unchanged. Current repository copy inherits base drop(emit) deletion and is not used for campaign. Later imported-head library result recorded separately; no byte-equivalence or independent replay claim.'
(p/'validation.json').write_text(json.dumps(v,indent=2)+'\n');(w/'validation.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
