# Lead 4 native development controls

This is producer development checking only, not a scientific benchmark or runtime result.
Base: crypto main 88112c5a930009c883059c1c2e3c6c92c4b23f18.
Owned source: crates/hashed-ecdl-tensor/src/witness_policy.rs; exact digest is in module.sha256.
Tests compiled this module through the temporary test-only lib.rs registration in test-module-registration.patch. That registration was restored before the owned-file commit; root must declare and wire the real module, then qualify combined source.

Commands (PATH=/home/agent/.cargo/bin:$PATH; CARGO_TARGET_DIR=/workspace/scratch/point-five-targets/witnesses):
- cargo test --release --locked --manifest-path crates/hashed-ecdl-tensor/Cargo.toml --lib witness_policy
- cargo fmt --manifest-path crates/hashed-ecdl-tensor/Cargo.toml --check
- cargo clippy --release --locked --manifest-path crates/hashed-ecdl-tensor/Cargo.toml --lib --tests -- -D warnings
- rustfmt --edition 2021 --check crates/hashed-ecdl-tensor/src/witness_policy.rs

Observed: 12 policy tests pass; fmt and strict lib/test clippy pass with the temporary registration. The initial fmt-only line-wrap failure is retained in fmt-initial.txt and corrected. No native performance, target-scalar or signed audit claim follows.

Sources checked: applicable AGENTS.md, report-evidence skill, current prepared.rs scan and existing L4/source/atlas review in research/point_hash_next_leads_20261116/reports/REPORT.md. No KB tools were loaded; repository wrapper status exited127 (no executable). Conductor was unavailable. No new literature/novelty claim or scientific run.

Integration obligations: next() represents one checked prepared candidate, including misses; full replay must precede ScanStep::Witness. Root must keep target u/v and planted scalar out of the opaque point/graph payload, and use slot-tagged graph keys. Batch arithmetic and precomputed tails must be charged separately. A graph-closing selection may still have zero combined v, to be handled by the collector. Cap-zero witness identity is preserved, not identical meter totals because selector bookkeeping is charged.
