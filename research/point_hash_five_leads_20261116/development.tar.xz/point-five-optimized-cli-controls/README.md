# Optimized CLI development handoff

This commit adds only the new CLI arm/import/usage and dedicated CLI controls.
The real optimized core is being implemented concurrently by root; no combined compile/test pass is claimed for this snapshot. No mock/stub core was used. Rustfmt and whitespace checks pass. Source digests are in source.sha256. Initial rustfmt test-file wrapping differences remain in fmt-initial.txt.

Command: solve-hashed-optimized PROBLEM.json OPTIONS.json NEW_RECEIPT.json.
Both JSON files use existing bounded read(); output uses exclusive create_new(true).
Diagnostics keys: backend PreparedOptimized, options (effective serialized configuration), statistics (real core diagnostics), charged_steps, scalar_decimal.
Receipt/v1 and its existing verify command are unchanged.

Seven committed CLI controls are pending execution on matching combined core: default options vs old joint certificate/replay/exclusive receipt, all-five F17 v1 replay, strict options (duplicates including escaped/null/nested, unknowns and wrong shapes), strict Problem duplicate, 16MiB options read bound, diagnostics distrust/scalar tamper, and exact arity.

No scientific, benchmark, timing or cloud work. Root owns integration, mirror and publication. Sources reused: applicable AGENTS.md/report-evidence and current native CLI/strict-JSON/replay tests; previous KB/Conductor unavailability is in the L4 control handoff.
