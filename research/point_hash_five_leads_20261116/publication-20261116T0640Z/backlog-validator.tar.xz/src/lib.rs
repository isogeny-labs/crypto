pub mod hash {
    pub mod sha1;
    pub mod sha256;
}
