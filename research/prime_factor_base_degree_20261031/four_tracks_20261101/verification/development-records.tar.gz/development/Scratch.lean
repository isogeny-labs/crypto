import PencilTop
noncomputable section
open MvPolynomial Finsupp
set_option maxHeartbeats 20000
def ee : Fin 7 →₀ ℕ := single 0 1+single 2 1+single 3 1+single 4 1+single 5 1
example : ¬ single 0 2 ≤ ee := by
  intro h
  have hh := h 0
  simp only [ee, Finsupp.single_apply, Finsupp.add_apply, Fin.ext_iff, Fin.coe_ofNat_eq_mod] at hh
  norm_num at hh
example : single 2 1+single 0 1 ≤ ee := by
  intro i
  fin_cases i <;>
    simp only [ee, Finsupp.single_apply, Finsupp.add_apply, Fin.ext_iff, Fin.coe_ofNat_eq_mod] <;> norm_num
example : ee-(single 3 1+single 4 1) = single 0 1+single 2 1+single 5 1 := by
  ext i
  fin_cases i <;>
    simp only [ee, Finsupp.single_apply, Finsupp.add_apply, Finsupp.tsub_apply, Fin.ext_iff, Fin.coe_ofNat_eq_mod] <;> norm_num
