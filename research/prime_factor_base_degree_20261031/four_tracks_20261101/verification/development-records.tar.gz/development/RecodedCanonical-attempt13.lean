import Recoding
import RecodedTop

noncomputable section
open MvPolynomial
namespace RecodedCanonical
variable {K : Type*} [Field K]
local notation "P" => MvPolynomial (Fin 7) K
set_option maxHeartbeats 1000000

def affine (c : K) (v : Fin 7 → K) : P := C c+∑ i, C (v i)*X i
theorem affine_above (c : K) (v : Fin 7 → K) (d : ℕ) (hd : 2 ≤ d) :
    homogeneousComponent d (affine c v) = 0 := by
  have h0 : d ≠ 0 := by omega
  have h1 : d ≠ 1 := by omega
  have hc : homogeneousComponent d (C c : P) = 0 := by
    simpa [h0] using (homogeneousComponent_of_mem (isHomogeneous_C (Fin 7) c) (m := d))
  have hx (i : Fin 7) : homogeneousComponent d (X i : P) = 0 := by
    simpa [h1] using (homogeneousComponent_of_mem (isHomogeneous_X K i) (m := d))
  simp only [affine, _root_.map_add, _root_.map_sum, homogeneousComponent_C_mul,
    hc, hx, mul_zero, Finset.sum_const_zero, add_zero]

theorem split_degree (H : P) (hH : H.IsHomogeneous 2) (hne : H ≠ 0)
    (c : K) (v : Fin 7 → K) : (H+affine c v).totalDegree = 2 := by
  apply DegreeBridge.degree_eq_of_components
  · intro d hd
    have h2 : d ≠ 2 := by omega
    simp only [_root_.map_add, affine_above c v d (by omega), add_zero]
    simpa [h2] using (homogeneousComponent_of_mem hH (m := d))
  · simpa only [_root_.map_add, affine_above c v 2 (by decide), add_zero,
      homogeneousComponent_of_mem hH, if_pos rfl] using hne

theorem split_top (H : P) (hH : H.IsHomogeneous 2) (hne : H ≠ 0)
    (c : K) (v : Fin 7 → K) : DegreeBridge.top (H+affine c v) = H := by
  unfold DegreeBridge.top
  rw [split_degree H hH hne c v]
  simp only [_root_.map_add, affine_above c v 2 (by decide), add_zero,
    homogeneousComponent_of_mem hH, if_pos rfl]

def h1 : P := X 2^2
def h2 (r : K) : P := X 0*X 1-C r*X 2^2
def hx (a : K) : P := C a*(X 0^2-X 3*X 4)-X 2*X 0
def hz (b : K) : P := C b*(X 1^2-X 5*X 6)-X 2*X 1
def G1 (r : K) : P := h1+affine (-r) ![-1,-1,0,0,0,0,0]
def G2 (A r s : K) : P := h2 r+affine (-(r^2+A)) ![0,0,-2*s,0,0,0,0]
def Qx (a r s b c w1 w2 : K) : P := hx a+affine (c+s) ![b,0,r,w1,w2,0,0]
def Qz (a r s b c w1 w2 : K) : P := hz a+affine (c+s) ![0,b,r,0,0,w1,w2]
def bit (i : Fin 4) : P := X (i.val+3 : Fin 7)^2-X (i.val+3 : Fin 7)
def generators (A r s a b cx cz dx dz wx1 wx2 wz1 wz2 : K) : Set P :=
  {G1 r,G2 A r s,Qx a r s cx dx wx1 wx2,Qz b r s cz dz wz1 wz2} ∪ Set.range bit

def probe : P →+* K := eval ![1,1,0,0,0,0,0]
@[simp] theorem probe_X (i : Fin 7) : probe (X i) = (![1,1,0,0,0,0,0] i : K) :=
  eval_X _ _
@[simp] theorem probe_C (c : K) : probe (C c) = c := eval_C _ _

theorem h1_homogeneous : (h1 : P).IsHomogeneous 2 := isHomogeneous_X_pow _ _
theorem h2_homogeneous (r : K) : (h2 r : P).IsHomogeneous 2 :=
  ((isHomogeneous_X K 0).mul (isHomogeneous_X K 1)).sub
    ((isHomogeneous_X_pow _ _).C_mul r)
theorem hx_homogeneous (a : K) : (hx a : P).IsHomogeneous 2 :=
  (((isHomogeneous_X_pow 0 2).sub ((isHomogeneous_X K 3).mul
    (isHomogeneous_X K 4))).C_mul a).sub ((isHomogeneous_X K 2).mul (isHomogeneous_X K 0))
theorem hz_homogeneous (a : K) : (hz a : P).IsHomogeneous 2 :=
  (((isHomogeneous_X_pow 1 2).sub ((isHomogeneous_X K 5).mul
    (isHomogeneous_X K 6))).C_mul a).sub ((isHomogeneous_X K 2).mul (isHomogeneous_X K 1))

theorem h1_ne_zero : (h1 : P) ≠ 0 := by simp [h1]
theorem h2_ne_zero (r : K) : (h2 r : P) ≠ 0 := by
  intro h
  have hh := congrArg (probe (K := K)) h
  simp [h2, _root_.map_sub, _root_.map_mul, _root_.map_pow] at hh
theorem hx_ne_zero (a : K) (ha : a ≠ 0) : (hx a : P) ≠ 0 := by
  intro h
  have hh := congrArg (probe (K := K)) h
  simp [hx, _root_.map_sub, _root_.map_mul, _root_.map_pow] at hh
  exact ha hh
theorem hz_ne_zero (a : K) (ha : a ≠ 0) : (hz a : P) ≠ 0 := by
  intro h
  have hh := congrArg (probe (K := K)) h
  simp [hz, _root_.map_sub, _root_.map_mul, _root_.map_pow] at hh
  exact ha hh

theorem bit_top (i : Fin 4) : DegreeBridge.top (bit (K := K) i) = X (i.val+3 : Fin 7)^2 := by
  let j : Fin 7 := (i.val+3 : Fin 7)
  have hdeg : (bit (K := K) i).totalDegree = 2 := by
    apply DegreeBridge.degree_eq_of_components
    · intro d hd
      have h2 : d ≠ 2 := by omega
      have h1 : d ≠ 1 := by omega
      simp only [bit, _root_.map_sub,
        homogeneousComponent_of_mem (isHomogeneous_X_pow j 2),
        homogeneousComponent_of_mem (isHomogeneous_X K j), if_neg h2, if_neg h1, sub_zero]
    · simp only [bit, _root_.map_sub,
        homogeneousComponent_of_mem (isHomogeneous_X_pow j 2),
        homogeneousComponent_of_mem (isHomogeneous_X K j)]
      norm_num
  unfold DegreeBridge.top
  rw [hdeg]
  simp only [bit, _root_.map_sub,
    homogeneousComponent_of_mem (isHomogeneous_X_pow j 2),
    homogeneousComponent_of_mem (isHomogeneous_X K j)]
  norm_num

theorem high_forms (A r s a b cx cz dx dz wx1 wx2 wz1 wz2 : K)
    (ha : a ≠ 0) (hb : b ≠ 0) :
    DegreeBridge.top '' generators A r s a b cx cz dx dz wx1 wx2 wz1 wz2 =
      {h1,h2 r,hx a,hz b} ∪ Set.range (fun i : Fin 4 => (X (i.val+3 : Fin 7) : P)^2) := by
  simp only [generators, Set.image_union, Set.image_insert_eq, Set.image_singleton,
    ← Set.range_comp', G1, G2, Qx, Qz, split_top _ h1_homogeneous h1_ne_zero,
    split_top _ (h2_homogeneous r) (h2_ne_zero r),
    split_top _ (hx_homogeneous a) (hx_ne_zero a ha),
    split_top _ (hz_homogeneous b) (hz_ne_zero b hb)]
  congr 1
  congr 1
  funext i
  exact bit_top i

end RecodedCanonical
