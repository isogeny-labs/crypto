import Recoding
noncomputable section
open MvPolynomial Finsupp
namespace SupportOneHot
variable {K : Type*} [Field K]
set_option maxHeartbeats 2000000

def OneHot (u : Fin 3 → K) : Prop := PencilSelector.Boolean u ∧
  u 0*u 1 = 0 ∧ u 0*u 2 = 0 ∧ u 1*u 2 = 0

theorem classification (u : Fin 3 → K) : OneHot u ↔
    u = ![0,0,0] ∨ u = ![1,0,0] ∨ u = ![0,1,0] ∨ u = ![0,0,1] := by
  constructor
  · rintro ⟨hb,h01,h02,h12⟩
    rcases hb 0 with h0|h0 <;> rcases hb 1 with h1|h1 <;> rcases hb 2 with h2|h2
    all_goals simp_all
    all_goals first | left; funext i; fin_cases i <;> simp_all
      | right; left; funext i; fin_cases i <;> simp_all
      | right; right; left; funext i; fin_cases i <;> simp_all
      | right; right; right; funext i; fin_cases i <;> simp_all
  · rintro (rfl|rfl|rfl|rfl) <;>
      simp [OneHot, PencilSelector.Boolean, Fin.forall_fin_succ]

def offset (u : Fin 3 → K) := 2*u 0+10*u 1+12*u 2
theorem offset_image (t : K) : (∃ u, OneHot u ∧ t = offset u) ↔
    t = 0 ∨ t = 2 ∨ t = 10 ∨ t = 12 := by
  simp only [classification]
  simp [offset, exists_or, and_or_left, or_and_right]

abbrev P := PencilTop.P K 6
def extra : Set (P (K := K)) :=
  {X (Sum.inr 0)*X (Sum.inr 1), X (Sum.inr 0)*X (Sum.inr 2),
    X (Sum.inr 1)*X (Sum.inr 2), X (Sum.inr 3)*X (Sum.inr 4),
    X (Sum.inr 3)*X (Sum.inr 5), X (Sum.inr 4)*X (Sum.inr 5)}
def ideal (a b : K) : Ideal P := PencilTop.ideal 6 a b ⊔ Ideal.span extra

theorem extra_mem {p : P (K := K)} (a b : K) (h : p ∈ extra) : p ∈ ideal a b :=
  (show Ideal.span extra ≤ ideal a b from le_sup_right) (Ideal.subset_span h)

theorem high_monomials (a b : K) (e : PencilTop.Vars 6 →₀ ℕ)
    (he : 5 ≤ e.degree) (c : K) : monomial e c ∈ ideal a b := by
  classical
  have inc : PencilTop.ideal (K := K) 6 a b ≤ ideal a b := le_sup_left
  by_cases hbits : ∃ i : Fin 6, 2 ≤ e (Sum.inr i)
  · obtain ⟨i, hi⟩ := hbits
    apply PencilTop.monomial_upward _ (single_le_iff.mpr hi) _ c
    have hh : (X (Sum.inr i) : P)^2 ∈ PencilTop.ideal 6 a b :=
      Ideal.subset_span (by simp [PencilTop.ideal])
    simpa [← X_pow_eq_monomial] using inc hh
  have hb (i : Fin 6) : e (Sum.inr i) ≤ 1 := by
    have := not_exists.mp hbits i
    omega
  by_cases hp :
      (1 ≤ e (Sum.inr 0) ∧ 1 ≤ e (Sum.inr 1)) ∨
      (1 ≤ e (Sum.inr 0) ∧ 1 ≤ e (Sum.inr 2)) ∨
      (1 ≤ e (Sum.inr 1) ∧ 1 ≤ e (Sum.inr 2)) ∨
      (1 ≤ e (Sum.inr 3) ∧ 1 ≤ e (Sum.inr 4)) ∨
      (1 ≤ e (Sum.inr 3) ∧ 1 ≤ e (Sum.inr 5)) ∨
      (1 ≤ e (Sum.inr 4) ∧ 1 ≤ e (Sum.inr 5))
  · rcases hp with hp|hp|hp|hp|hp|hp
    · apply PencilTop.monomial_upward _ (show single (Sum.inr 0) 1+single (Sum.inr 1) 1 ≤ e from ?_) ?_ c
      · intro l
        rcases l with l|l <;> fin_cases l <;> simp_all
      · simpa [X, monomial_mul] using extra_mem a b
          (by simp [extra] : (X (Sum.inr 0)*X (Sum.inr 1) : P) ∈ extra)
    · apply PencilTop.monomial_upward _ (show single (Sum.inr 0) 1+single (Sum.inr 2) 1 ≤ e from ?_) ?_ c
      · intro l
        rcases l with l|l <;> fin_cases l <;> simp_all
      · simpa [X, monomial_mul] using extra_mem a b
          (by simp [extra] : (X (Sum.inr 0)*X (Sum.inr 2) : P) ∈ extra)
    · apply PencilTop.monomial_upward _ (show single (Sum.inr 1) 1+single (Sum.inr 2) 1 ≤ e from ?_) ?_ c
      · intro l
        rcases l with l|l <;> fin_cases l <;> simp_all
      · simpa [X, monomial_mul] using extra_mem a b
          (by simp [extra] : (X (Sum.inr 1)*X (Sum.inr 2) : P) ∈ extra)
    · apply PencilTop.monomial_upward _ (show single (Sum.inr 3) 1+single (Sum.inr 4) 1 ≤ e from ?_) ?_ c
      · intro l
        rcases l with l|l <;> fin_cases l <;> simp_all
      · simpa [X, monomial_mul] using extra_mem a b
          (by simp [extra] : (X (Sum.inr 3)*X (Sum.inr 4) : P) ∈ extra)
    · apply PencilTop.monomial_upward _ (show single (Sum.inr 3) 1+single (Sum.inr 5) 1 ≤ e from ?_) ?_ c
      · intro l
        rcases l with l|l <;> fin_cases l <;> simp_all
      · simpa [X, monomial_mul] using extra_mem a b
          (by simp [extra] : (X (Sum.inr 3)*X (Sum.inr 5) : P) ∈ extra)
    · apply PencilTop.monomial_upward _ (show single (Sum.inr 4) 1+single (Sum.inr 5) 1 ≤ e from ?_) ?_ c
      · intro l
        rcases l with l|l <;> fin_cases l <;> simp_all
      · simpa [X, monomial_mul] using extra_mem a b
          (by simp [extra] : (X (Sum.inr 4)*X (Sum.inr 5) : P) ∈ extra)
  have hs : (∑ i : Fin 6, e (Sum.inr i)) ≤ 2 := by
    have h0 := hb 0; have h1 := hb 1; have h2 := hb 2
    have h3 := hb 3; have h4 := hb 4; have h5 := hb 5
    simp only [Fin.sum_univ_succ]
    omega
  rw [PencilTop.degree_vars] at he
  have hcore : 3 ≤ e (Sum.inl 0)+e (Sum.inl 1)+e (Sum.inl 2) := by omega
  obtain ⟨hm,hxz,hx3,hz3,hxm,hzm⟩ := PencilTop.core_members 6 a b
  by_cases hm' : 2 ≤ e (Sum.inl 2)
  · apply PencilTop.monomial_upward _ (single_le_iff.mpr hm') _ c
    simpa [← X_pow_eq_monomial] using inc hm
  by_cases hxz' : 1 ≤ e (Sum.inl 0) ∧ 1 ≤ e (Sum.inl 1)
  · apply PencilTop.monomial_upward _
      (show single (Sum.inl 0) 1+single (Sum.inl 1) 1 ≤ e from ?_) ?_ c
    · intro i
      rcases i with i|i <;> fin_cases i <;> simp_all
    · simpa [X, monomial_mul] using inc hxz
  by_cases hx3' : 3 ≤ e (Sum.inl 0)
  · apply PencilTop.monomial_upward _ (single_le_iff.mpr hx3') _ c
    simpa [← X_pow_eq_monomial] using inc hx3
  by_cases hz3' : 3 ≤ e (Sum.inl 1)
  · apply PencilTop.monomial_upward _ (single_le_iff.mpr hz3') _ c
    simpa [← X_pow_eq_monomial] using inc hz3
  have hh : (2 ≤ e (Sum.inl 0) ∧ 1 ≤ e (Sum.inl 2)) ∨
      (2 ≤ e (Sum.inl 1) ∧ 1 ≤ e (Sum.inl 2)) := by omega
  rcases hh with hh|hh
  · apply PencilTop.monomial_upward _
      (show single (Sum.inl 0) 2+single (Sum.inl 2) 1 ≤ e from ?_) ?_ c
    · intro i
      rcases i with i|i <;> fin_cases i <;> simp_all
    · simpa [X_pow_eq_monomial, X, monomial_mul] using inc hxm
  · apply PencilTop.monomial_upward _
      (show single (Sum.inl 1) 2+single (Sum.inl 2) 1 ≤ e from ?_) ?_ c
    · intro i
      rcases i with i|i <;> fin_cases i <;> simp_all
    · simpa [X_pow_eq_monomial, X, monomial_mul] using inc hzm

theorem vanishes (a b : K) : SecantIdeal.Vanishes (ideal a b) 5 := by
  classical
  intro p hp
  rw [p.as_sum]
  apply Ideal.sum_mem
  intro e he
  apply high_monomials a b e _ _
  have := SecantIdeal.homogeneous_degree hp he
  omega

end SupportOneHot
