import KoblitzRound20
namespace KoblitzRound21Equivariant
open scoped BigOperators
abbrev S := Fin 4→ZMod 5
abbrev T := Fin 4→Fin 5→ZMod 5

def rotate (v:S) : S := ![-(v 0+v 1+v 2+v 3),v 0,v 1,v 2]
def cycle (v:T) : T := fun i j=>v i (j+1)
def sourceNorm (v:S) : S := ∑k:Fin 5,(rotate^[k.val]) v
def targetNorm (v:T) : T := ∑k:Fin 5,(cycle^[k.val]) v

theorem source_norm_zero (v:S) : sourceNorm v=0 := by
 funext i
 fin_cases i <;> simp [sourceNorm,rotate,Fin.sum_univ_succ,Function.iterate_succ_apply] <;> abel

theorem actual_fixed_source : rotate (fun _=>1)=(fun _=>1) := by decide +kernel

theorem target_norm_coordinates (v:T) : targetNorm v=fun i _=>∑j:Fin 5,v i j := by
 funext i j
 fin_cases j <;> simp [targetNorm,cycle,Fin.sum_univ_succ,Function.iterate_succ_apply] <;> abel

theorem fixed_target_is_norm (v:T) (hv:cycle v=v) : ∃w:T,targetNorm w=v := by
 have hcol (i:Fin 4) (j:Fin 5) : v i (j+1)=v i j := congrFun (congrFun hv i) j
 have hall (i:Fin 4) (j:Fin 5) : v i j=v i 0 := by
  have h0:=hcol i 0
  have h1:=hcol i 1
  have h2:=hcol i 2
  have h3:=hcol i 3
  fin_cases j <;> simp_all
 refine ⟨fun i j=>if j=0 then v i 0 else 0,?_⟩
 rw [target_norm_coordinates]
 funext i j
 simp [Fin.sum_univ_succ,hall]

theorem intertwine_iterates (g:T→ₗ[ZMod 5]S)
 (hg:∀w,g (cycle w)=rotate (g w)) (n:Nat) (w:T) :
 g ((cycle^[n]) w)=(rotate^[n]) (g w) := by
 induction n with
 | zero=>rfl
 | succ n ih=>
  rw [Function.iterate_succ_apply,Function.iterate_succ_apply,hg,ih]

theorem equivariant_scalar_recovery_zero
 (f:S→ₗ[ZMod 5]T) (g:T→ₗ[ZMod 5]S)
 (hf:∀v,f (rotate v)=cycle (f v)) (hg:∀w,g (cycle w)=rotate (g w))
 (d:ZMod 5) (hgf:∀v,g (f v)=d • v) : d=0 := by
 let v:S:=fun _=>1
 have hv:rotate v=v := actual_fixed_source
 have hfix:cycle (f v)=f v := by rw [←hf,hv]
 obtain ⟨w,hw⟩:=fixed_target_is_norm (f v) hfix
 have hz:g (f v)=0 := by
  rw [←hw]
  change g (∑k:Fin 5,(cycle^[k.val]) w)=0
  rw [map_sum]
  simp_rw [intertwine_iterates g hg]
  exact source_norm_zero (g w)
 rw [hgf] at hz
 have he:=congrFun hz 0
 simpa [v] using he

theorem no_equivariant_retraction
 (f:S→ₗ[ZMod 5]T) (g:T→ₗ[ZMod 5]S)
 (hf:∀v,f (rotate v)=cycle (f v)) (hg:∀w,g (cycle w)=rotate (g w)) :
 ¬(∀v,g (f v)=v) := by
 intro h
 have he:=equivariant_scalar_recovery_zero f g hf hg 1 (by simpa using h)
 exact one_ne_zero he
end KoblitzRound21Equivariant
#print axioms KoblitzRound21Equivariant.source_norm_zero
#print axioms KoblitzRound21Equivariant.actual_fixed_source
#print axioms KoblitzRound21Equivariant.target_norm_coordinates
#print axioms KoblitzRound21Equivariant.fixed_target_is_norm
#print axioms KoblitzRound21Equivariant.intertwine_iterates
#print axioms KoblitzRound21Equivariant.equivariant_scalar_recovery_zero
#print axioms KoblitzRound21Equivariant.no_equivariant_retraction
