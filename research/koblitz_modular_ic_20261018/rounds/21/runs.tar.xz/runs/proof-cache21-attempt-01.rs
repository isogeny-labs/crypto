//! Verification infrastructure only: byte-identical compiled-object cache locality.
use crate::sha256_impl;
use serde_json::json;
use std::{
    fs,
    path::{Path, PathBuf},
    sync::{
        atomic::{AtomicUsize, Ordering},
        Mutex,
    },
};
fn selected(p: &Path) -> bool {
    let s = p.file_name().unwrap().to_str().unwrap();
    [".olean", ".olean.private", ".olean.server", ".ir", ".so"]
        .iter()
        .any(|x| s.ends_with(x))
}
fn gather(root: &Path, dir: &Path, index: usize, out: &mut Vec<(usize, PathBuf, PathBuf, u64)>) {
    for e in fs::read_dir(dir).unwrap() {
        let p = e.unwrap().path();
        if p.is_dir() {
            gather(root, &p, index, out)
        } else if selected(&p) {
            let size = fs::metadata(&p).unwrap().len();
            out.push((index, p.clone(), p.strip_prefix(root).unwrap().into(), size));
        }
    }
}
pub fn run(list: &Path, dest: &Path, receipt: &Path) {
    assert!(
        !dest.exists(),
        "new cache directory required;reconcile any previous cache first"
    );
    assert!(!receipt.exists());
    let roots = fs::read_to_string(list)
        .unwrap()
        .lines()
        .filter(|s| !s.is_empty())
        .map(PathBuf::from)
        .collect::<Vec<_>>();
    assert!(roots.len() >= 2);
    let mut jobs = vec![];
    for (i, p) in roots.iter().enumerate() {
        gather(p, p, i, &mut jobs);
    }
    jobs.sort_by(|a, b| (&a.0, &a.2).cmp(&(&b.0, &b.2)));
    let bytes = jobs.iter().map(|j| j.3).sum::<u64>();
    println!(
        "cache preflight:{} roots,{} files,{bytes} bytes;8GiB limit",
        roots.len(),
        jobs.len()
    );
    assert!(
        bytes <= 8 * 1024 * 1024 * 1024,
        "verification cache envelope"
    );
    fs::create_dir(dest).unwrap();
    let next = AtomicUsize::new(0);
    let records = Mutex::new(vec![]);
    std::thread::scope(|s| {
        for _ in 0..8 {
            s.spawn(|| loop {
                let n = next.fetch_add(1, Ordering::Relaxed);
                if n >= jobs.len() {
                    break;
                }
                let (i, src, rel, size) = &jobs[n];
                let data = fs::read(src).unwrap();
                assert_eq!(data.len() as u64, *size);
                let hash = hex::encode(sha256_impl::sha256(&data));
                let target = dest.join(format!("root-{i:02}")).join(rel);
                fs::create_dir_all(target.parent().unwrap()).unwrap();
                fs::write(&target, &data).unwrap();
                let copied = fs::read(&target).unwrap();
                assert_eq!(copied.len(), data.len());
                assert_eq!(hex::encode(sha256_impl::sha256(&copied)), hash);
                records.lock().unwrap().push((
                    n,
                    json!({"root":i,"relative":rel,"bytes":size,"sha256":hash}),
                ));
            });
        }
    });
    let mut records = records.into_inner().unwrap();
    records.sort_by_key(|v| v.0);
    assert_eq!(records.len(), jobs.len());
    let mapped = (0..roots.len())
        .map(|i| dest.join(format!("root-{i:02}")))
        .collect::<Vec<_>>();
    let lean_path = mapped
        .iter()
        .map(|p| p.to_str().unwrap())
        .collect::<Vec<_>>()
        .join(":");
    fs::write(dest.join("lean-path.txt"), format!("{lean_path}\n")).unwrap();
    let value = json!({"schema":"koblitz.round21-proof-cache/v1","source_roots":roots,"local_roots":mapped,"files":records.len(),"bytes":bytes,"all_source_destination_hashes_equal":true,"members":records.into_iter().map(|v|v.1).collect::<Vec<_>>()});
    fs::write(receipt, serde_json::to_vec_pretty(&value).unwrap()).unwrap();
    println!("PASS:{} cached files;all SHA256 and byte lengths match;source/dependency/theorem bytes unchanged",jobs.len());
}
