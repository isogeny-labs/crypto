# Round21 execution and provenance

UTC24 October2026,parent63bc0895df3d2cbd38e22a3efe828a52a0fad731.
ConductorT-299 scoped check clear before edits;claim not adopted by a
second Codex process. No new external job or generator.

All research arithmetic and result/hash assembly is the Rust runner:
export PATH=/home/ec2-user/.cargo/bin:/home/ec2-user/.elan/bin:$PATH
cargo build --release --locked --manifest-path native/Cargo.toml
runner=native/target/release/koblitz-modular-carriers

Protocol and amendments precede their respective native commands:
--round21-tangent runs:Q35; --round21-descent runs:G31;
--round21-boundary runs:Q36; --round21-quotients runs:Q37;
--round21-final-boundary runs:Q38; --round21-families runs:Q39;
--round21-last-boundary runs:Q40. Each uses timeout1200 and one native
thread. Initial direct runs did not set a virtual-memory rlimit;the final
REPLAY.sh enforces4GiB per native experiment. Retained outputs expose all
bounds,matrices,polynomials,models and caps. No timing/IC assessment.

Inputs are copied byte-identically from frozen Round20 runs. They retain
the actual four Q8 graphs,Q13–Q17 constraints,Q23/25/27/31 families,
Q33/Q34,G25 and G28. No historical algorithm or artifact is rewritten.
REPLAY.sh regenerates seven mathematical JSONs,seven generated Lean
modules and the native summary,and compares all byte for byte. It checks
two source-bound IDC records,not reissuing them. The temporary regeneration
before strict replay retained original boundary exports as attempt01
while adding explicit checks of every new linear pair and refactoring
three repeated runners into one stage selector. Final strict replay has
no acceptance/skip flag. Original outputs and sources remain in this tree.

Native build01 includes an unused-import warning;build04 fails only on
Vec<usize> inference in the new pure-source family. Corrected builds and
all sources/logs are retained. Summary01 rejects the mistaken1340 count;
summary02 records the actual1330. No failed assertion is called a result.
Native cargo test --release --locked --manifest-path native/Cargo.toml
passes129 tests with1 ignored;AST tests independently issue/check both
universal identities. Final source-bound issuer/checker use64 issuer
checks and128 extra parsed checks per record.

Lean initial direct invocations with a broad unused historical import
were interrupted during NFS loading;they supplied no proof result.
The final two structural modules use narrow Mathlib imports. Initial
manual compile diagnoses an unavailable Finset.sum_div;the final proof
uses sum_mul. Initial equivariant imports name absent Matrix.Notation;
corrected VecNotation imports,Fin sum import and iterate orientation are
retained. Every failed build/output remains here. No admitted result is
accepted merely because an unsuccessful Lean run prints its name.

Final validation runs the exact full lake build and AuditAxioms stages of
tools/lean/proof-gate.sh against existing pinned4.34.1/mathlib dependencies.
The cache-prefetch failure is already documented in frozen Round20 and is
not repeated or called passed. CI retains the complete proof-gate script.
The full audit enumerates every compiled local module,not only Round21.
It must report zero failing and zero trusted,and contain every206 new
named statement. The exact command/output/status are retained. Only
propext,Classical.choice,Quot.sound are accepted. No lean4checker or new
independent host is claimed. CyclicWindow.lean is checked separately.

Root validation:CARGO_TARGET_DIR=/home/ec2-user/crypto/target cargo test
--release --lib. The first parallel run has4491 passed,2 failed,119 ignored;
failures are existing untouched F4-count and support-local timer tests.
Both isolated single-thread controls pass. A complete --test-threads=1
rerun is retained with its actual final status;no assertion is weakened.
Site tests:scripts/site/test_build.py. Workflow parsing:
scripts/test_workflows_parse.py. Budget tests:
.github/scripts/test-pr-budgets.py. The touched workflow is checked
separately at its unchanged25-minute cap. Backlog validation uses the
existing release backlog binary with the card ID. Dashboard render/check
uses pinned Node22. Python only edits sources,runs existing site/policy
tests,and renders/inspects the recorded report. It performs no research
arithmetic,result assembly,hashing or verification.

The final native record issues source pins/raw member hashes only after
all required checks and source-bound identities. Raw evidence is sealed
before deterministic archiving. Native manifests and standard tar/xz
fresh-extraction,strict replay,current/R20 historical source checks and
byte-identical repacking receipts live beside the validation tree. No
post-seal raw edit is permitted. Publication uses a guarded descendant of
63bc089 and updates existing ready PR2215,without force/rebase/merge.

Verification locality amendment:the first complete audit exits124 during
cold NFS import and reports no theorem result. Its log/status are retained
as lean-full-audit-cold-timeout.log / lean-full-status-cold-timeout.txt.
The Rust --round21-proof-cache helper copies the exact required library
objects to /dev/shm/koblitz-round21-proof-cache,verifying every source/
destination SHA256 and size. The receipt covers45808 objects and
8586455504 bytes,below8GiB. One originally absent search root becomes an
empty local root. The initial absent-root error and interrupted metadata
setup are retained in proof-cache-recovery.md and attempt sources/logs.
The final unchanged AuditAxioms.lean runs directly with the verified
local LEAN_PATH,the same local compiled modules and the unchanged
trusted-native policy. Audit limit8GiB/1200s;scientific limits unchanged.
The final record requires exact build=0/audit=0 and checks the cache
receipt before sealing. No failed/cold import is substituted for a pass.
Native release tests after the infrastructure helper still pass129/1.

Final audit completes1032 theorems,0 failing,0 trusted,exit0 with -j1
-M16384 after the documented8GiB interpreter exhaustion. The prior virtual
address/thread error,missing IR execution metadata and partial memory8
run each retain their separate log/status. The verified signature
supplement has11426 files and the combined cache payload is8588466480
bytes. The final complete9079-job build has exit0. Native record sealing
requires these exact successes and checks every206 new named statement.
