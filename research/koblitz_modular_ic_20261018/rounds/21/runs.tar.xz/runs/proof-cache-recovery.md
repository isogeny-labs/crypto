Cold audit watchdog exits124 before any audit result;the full9079-job
build passed. Its checker is an inactive orphan zombie with zero RSS,
not an active second auditor. Initial cache-copy preflight encounters an
originally nonexistent LEAN_PATH directory;no cache directory or verified
receipt is created. Such entries must remain empty search roots. The
second setup launcher is stopped before running its copier to move
metadata reads outside the receipt mutex. Its source/build output is
retained;no scientific command or external job is interrupted. The final
copy still requires every file's source/destination SHA256 and length
match within the same declared cache limits.

Correction to the second-launcher note:its helper had already entered
metadata discovery when the launcher was stopped. That owned timeout and
helper(3257463/3257464) were explicitly terminated before accepting the
next copy. No cache directory or verified receipt had been created. This
was verification setup only;no science generator or EKS job was touched.
