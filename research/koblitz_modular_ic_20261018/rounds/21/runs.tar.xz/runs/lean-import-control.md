Initial direct Lean invocations imported KoblitzRound20 even though neither
new structural proof used a historical declaration. They made no theorem
claim before interruption while loading transitive Mathlib dependencies
on NFS. The two owned Lean workers were sent SIGTERM and original sources
and logs retained. New structural modules use their actual narrow Mathlib
imports. The full historical project build/audit is still required.
