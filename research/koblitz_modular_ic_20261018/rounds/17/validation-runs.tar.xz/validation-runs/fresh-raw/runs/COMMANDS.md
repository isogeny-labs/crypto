# Round17 invocation and receipt map

Working directory: /home/ec2-user/crypto-modular-ic, unless the Lean project
is explicitly named. Scientific parent dcc9802; local base merge74359952fb
has parents dcc9802 and6ed792. environment.log records the inspection host,
compiler versions and hardware; this shared cloud host has no isolation tier
for performance measurement. No performance interval is reported.

Final experiment commands use
research/koblitz_modular_ic_20261018/native/target/release/koblitz-modular-carriers
with --round17-survivors, --round17-integral, --round17-theta,
--round17-repair, --round17-lifts and --round17-lift-proof, each followed by
the output/input directory. REPLAY.sh gives the complete current commands,
frozen copied inputs and byte comparisons. Seeds and deterministic bounds
are explicit in the pinned native sources and PROTOCOL.md. Final receipts:
survivors-01, integral-02, theta-04, repair-01, lifts-03 and lift-proof-02.
Regenerated proof-only outputs in proofs-final reproduce their mathematical
JSON; copied final Lean modules are compared again by replay.

Builds: cargo build --release --locked --manifest-path
research/koblitz_modular_ic_20261018/native/Cargo.toml.
Native tests use cargo test with the same three options. Root tests use
cargo test --release --lib. Their completed logs include the exit summaries.
Final native-tests-03 passes115/1 ignored; root-release-tests passes4487/119.
The first theta and lifts build failures, and stale lifts-01 command, remain.

Lean: tools/lean/proof-gate.sh --out
research/koblitz_modular_ic_20261018/rounds/17/runs/full-gate
research/koblitz_modular_ic_20261018/lean. Targeted lake builds were executed
from that Lean project. The full gate builds and audits all project modules;
its nested cache/build/audit/status and copied lean-full-audit.log are retained.
The structural01 and lift-proof01 failures are followed by successful builds.

Packaging checks: python3 scripts/site/test_build.py;
python3 scripts/test_workflows_parse.py;
python3 .github/scripts/test-pr-budgets.py;
python3 .github/scripts/check-pr-budgets.py TMP_DIRECTORY containing the
one affected workflow; /home/ec2-user/crypto/target/release/backlog validate
XP-20261021-koblitz-level77-map; Node22 tools/render_ic_dashboard.mjs and
its --check option; /home/ec2-user/.venvs/report/bin/python rounds/17/render.py
(with the full study-relative path). The first budget/backlog CLI errors
remain; corrected02 logs pass. The unpinned root lean --version query failed
because no default toolchain is configured; the explicit pinned executable's
version was recorded instead. No research invocation used an unpinned Lean.

No failed attempt counts as a successful experiment. Final byte replay,
archive rechecks, current/historical pins and post-freeze receipts are kept
outside this raw tree in validation-runs and ARCHIVE_VALIDATION.txt.
