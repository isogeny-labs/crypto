# Round18 command/receipt map

Repository: /home/ec2-user/crypto-modular-ic. Scientific parent76e409c.
The protocol fixes caps before arithmetic; environment.log records the
inspection host, pinned compilers and hardware. This shared cloud host has
no performance-isolation tier and no performance interval is claimed.

Build: cargo build --release --locked --manifest-path
research/koblitz_modular_ic_20261018/native/Cargo.toml. Native tests use
cargo test with those same options. Root tests use cargo test --release
--lib with CARGO_TARGET_DIR=/home/ec2-user/crypto/target.

The runner is native/target/release/koblitz-modular-carriers beneath the
study. All twelve exact experiment flags and copied inputs are specified
in REPLAY.sh. Initial accepted receipts are companion-01, repair-01,
squares-01, square-repair-01, symmetric-01, frobenius-01, diamond-01,
hecke-01, maps-01, holdouts-01, refinement-01 and map-proof-01. Stronger
Hecke/refinement checks are in hecke-02/refinement-02; initial artifacts
are retained. Q28 metadata is clarified in square-repair-02. Replay enforces a1200-second wall cap per command. Initial companion,
repair, symmetric and Frobenius invocations relied on their algorithmic
bounds and completed normally; they did not use an external timeout wrapper.
There are no claimed timeouts or undisclosed retries.
The native search and holdout JSON retain full bounds, seeds (where used),
attempt counts, accepted points and all finite-fit counterexamples.

Targeted Lean builds run from study/lean using lake build on the named
Round18 modules. lean-initial-01 fails; lean-corrected-02 and
lean-final-modules-03 pass. Full gate:
tools/lean/proof-gate.sh --out
research/koblitz_modular_ic_20261018/rounds/18/runs/full-gate
research/koblitz_modular_ic_20261018/lean.
It passes651 transitive theorem audits with0 failing/0 trusted. The94
new named results are counted separately from generated equation lemmas.

Site: python3 scripts/site/test_build.py. Workflow: python3
scripts/test_workflows_parse.py and .github/scripts/test-pr-budgets.py.
The affected workflow is copied to a temporary directory before running
.github/scripts/check-pr-budgets.py on that directory. Backlog:
/home/ec2-user/crypto/target/release/backlog validate
XP-20261021-koblitz-level77-map. Dashboard: Node22 runs
 tools/render_ic_dashboard.mjs and --check. Report: the report virtualenv
runs rounds/18/render.py using its full study-relative path. Python is
restricted to existing tests, file editing and layout/PDF inspection.

The first Rust build diagnostic and its corrected import are retained.
The original missing-import source byte snapshot was not captured; the
exact compiler diagnostic and final source are retained, and this compile
failure is not scientific evidence. The failed Lean source was captured
before its correction. No source/result artifact from a failed build is
promoted. Replays, archive checks and post-freeze receipts live outside
this raw tree in validation-runs and ARCHIVE_VALIDATION.txt.
