# Actual commands and resource boundaries

Repository working directory: /home/ec2-user/crypto-modular-ic.
S=research/koblitz_modular_ic_20261018; R=$S/rounds/14; D=$R/runs.
The executable is $S/native/target/release/koblitz-modular-carriers.
All native research commands use timeout1200. Protocol amendments precede
changed limits, added families and both coordinate-convention corrections.

- cargo build/test --release --locked --offline --manifest-path $S/native/Cargo.toml.
  Build attempts01..23, final/seal/odd-alignment/archive-tools and test logs
  preserve actual outcomes. The final native suite is native-tests-07.log.
- --round14-norms $D; --round14-supports $D; --round14-middles $D.
- --round14-fiber $D INDEX, INDEX=0..24. Initial one-billion reduction cap;
  indices13/14 fail. AmendmentE freezes5b O22 cap before their -02 retries.
- --round14-verify-point $D INDEX for all25 indices. One-billion cap;
  indices13/14 verified after their successful producer retries.
- --round14-assemble $D: parses/reconstructs all functions, supports and fibers.
- --round14-products $D; --round14-quadrics $D; --round14-boundary-lean $D.
- --round14-geometry $D: first wrong H binding rejected; then linear dual
  only; final Cartier action corrected under AmendmentF. All outputs retained.
- --round14-images7 $D and --round14-images-point $D INDEX for
  INDEX=0,1,2,5,12,17,20. After AmendmentL all eight direct fibers rerun
  with both pairing/F32 and odd F4-root conventions transported from F30.
- --round14-relations $D: actual old/new matrices, all projected principal
  and separate deck rows, small-field image checks and two rank algorithms.
  The first generated rank proofs fail without a prime-field instance;
  the corrected final generator retains the same mathematical matrices.
- lake env lean KoblitzRound14.lean and lake build KoblitzRound14Relations:
  failed/passing elaboration logs retained. Full final proof gate is
  tools/lean/proof-gate.sh $S/lean --out CACHE; gate05 includes the aligned images and O28 cusp certificates.
- CARGO_TARGET_DIR=/home/ec2-user/crypto/target cargo test --release --lib
  --offline --locked -- --test-threads=1: root-tests-01.log.
- python3 scripts/site/test_build.py and scripts/test_workflows_parse.py:
  site-tests-01.log and workflow-tests-01.log. These are existing tests.
- node tools/render_ic_dashboard.mjs and --check: dashboard receipts.
- /home/ec2-user/.venvs/report/bin/python $R/render.py: layout only;
  every final PDF page is visually inspected. render01/02/03 logs retained.
- The first REPLAY.sh execution reconstructs93 earlier outputs and2 Lean
  files but predates odd-root alignment. It is preserved as superseded.
  The final102-output/4-Lean/5-ID replay uses fresh extracted archived
  inputs, at most4 independent point workers, and separate validation logs.

The shared /tmp filled during build17 and proof-gate01. Subsequent commands
use TMPDIR=/home/ec2-user/.cache/koblitz-round14-tmp; the failed logs remain.
Correctness test durations are not treated as IC performance measurements.

- --round14-cusps $D (AmendmentM):44 normalized orbits, all480 labels,
  exact old22-product control, all eight closed signed divisors. First Lean
  attempt02 exposes opaque mergeSort reduction and lexical spacing; those
  failed sources/logs remain. Coverage is then checked by exact occurrence
  counts in the kernel, without a native decision oracle.
- --record-round14 ROUND, --round14-check-identities ROUND,
  --round14-verify-sources ROUND and --round14-validation-manifest ROUND
  produce and check the sealed native ledger and the separate replay bundle.
