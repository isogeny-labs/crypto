import KoblitzRound15
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace KoblitzRound15Jets
def residuals0 (x : Nat → ZMod 2) : List (ZMod 2) := [(1)]
theorem actual_first_jet_obstruction0 (x : Nat → ZMod 2) : (residuals0 x).sum=1 := by
 simp only [residuals0,List.sum_cons,List.sum_nil]
 ring
theorem actual_first_jet_nonzero0 (x : Nat → ZMod 2) : (residuals0 x).sum ≠ 0 := by
 rw [actual_first_jet_obstruction0]
 decide
def residuals1 (x : Nat → ZMod 2) : List (ZMod 2) := [(1)]
theorem actual_first_jet_obstruction1 (x : Nat → ZMod 2) : (residuals1 x).sum=1 := by
 simp only [residuals1,List.sum_cons,List.sum_nil]
 ring
theorem actual_first_jet_nonzero1 (x : Nat → ZMod 2) : (residuals1 x).sum ≠ 0 := by
 rw [actual_first_jet_obstruction1]
 decide
def residuals2 (x : Nat → ZMod 2) : List (ZMod 2) := [(1)]
theorem actual_first_jet_obstruction2 (x : Nat → ZMod 2) : (residuals2 x).sum=1 := by
 simp only [residuals2,List.sum_cons,List.sum_nil]
 ring
theorem actual_first_jet_nonzero2 (x : Nat → ZMod 2) : (residuals2 x).sum ≠ 0 := by
 rw [actual_first_jet_obstruction2]
 decide
def residuals3 (x : Nat → ZMod 2) : List (ZMod 2) := [(1)]
theorem actual_first_jet_obstruction3 (x : Nat → ZMod 2) : (residuals3 x).sum=1 := by
 simp only [residuals3,List.sum_cons,List.sum_nil]
 ring
theorem actual_first_jet_nonzero3 (x : Nat → ZMod 2) : (residuals3 x).sum ≠ 0 := by
 rw [actual_first_jet_obstruction3]
 decide
end KoblitzRound15Jets
