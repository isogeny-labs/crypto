import KoblitzRound20Picard
set_option maxHeartbeats 0
namespace KoblitzRound20Kernel
open scoped BigOperators
theorem zero_of_left_inverse {F:Type*} [Field F] (L:Matrix (Fin 8) (Fin 40) F) (M:Matrix (Fin 40) (Fin 8) F) (h:L*M=1) (v:Fin 8→F) (hv:M.mulVec v=0) : v=0 := by
 have hz : (L*M).mulVec v=0 := by rw [← Matrix.mulVec_mulVec,hv,Matrix.mulVec_zero]
 simpa [h] using hz

end KoblitzRound20Kernel
#print axioms KoblitzRound20Kernel.zero_of_left_inverse
