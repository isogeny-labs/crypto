//! Actual Pic2 comparison and complete common kernels for the weighted orbit system.
use super::*;
use serde_json::json;
fn save_lean(dir: &Path, name: &str, text: String) {
    assert!(!dir.join(name).exists());
    std::fs::write(dir.join(name), text).unwrap();
}
pub fn picard(dir: &Path) {
    let data=read(&dir.join("g25-correct-polarization-orbit-sections.json"));
    let prior=read(&dir.join("g15-theta-class-descent.json"));
    let mut bias=[0i64;4];
    for k in 0..4 { for j in 0..5 { for (i,z) in bias.iter_mut().enumerate() {
        let a=data["orbits"][k][j][i][0].as_i64().unwrap();
        let b=data["orbits"][k][j][i][1].as_i64().unwrap();
        *z=(*z+data["weights"][k].as_i64().unwrap()*a*b).rem_euclid(2);
    }}}
    let bits=bias.iter().enumerate().fold(0u64,|z,(i,b)|z|((*b as u64)<<i));
    let p=[[1u8,1,0,0],[1,0,1,0],[1,0,0,1],[1,0,0,0]];
    let fixed=(0u8..16).filter(|v|(0..4).all(|i| {
        let y=(0..4).fold(0,|z,j|z^(p[i][j]*((v>>j)&1)));
        y==((v>>i)&1)
    })).collect::<Vec<_>>();
    assert_eq!(fixed,vec![0]);
    let records=[0,2].map(|g| {
        let correction=prior["records"][g]["actual_theta_correction_bits"].as_u64().unwrap();
        assert_eq!(bits,correction);
        json!({"graph":g,"orbit_axis_bias":bias,"target_correction_bits":correction,"difference_bits":bits^correction,"canonical_class_matches_under_written_Pic0_bridge":true})
    });
    let lean=String::from("import KoblitzRound19OrbitCover\nimport KoblitzRound15Theta\nnamespace KoblitzRound20Picard\nopen scoped BigOperators\ndef orbitBias (i:Fin 4) : ZMod 2 := ∑ k:Fin 4,∑ j:Fin 5,((KoblitzRound19OrbitCover.weights k)*(KoblitzRound19OrbitCover.rows k j i).1*(KoblitzRound19OrbitCover.rows k j i).2:ℤ)\ntheorem actual_axis_match0 : orbitBias=KoblitzRound15Theta.corr0 := by decide +kernel\ntheorem actual_axis_match2 : orbitBias=KoblitzRound15Theta.corr2 := by decide +kernel\ntheorem no_fixed_Pic2_0 : ∀v:Fin 4→ZMod 2,KoblitzRound15Theta.pic0.mulVec v=v→v=0 := by decide +kernel\ntheorem no_fixed_Pic2_2 : ∀v:Fin 4→ZMod 2,KoblitzRound15Theta.pic2.mulVec v=v→v=0 := by decide +kernel\ntheorem canonical_difference_vanishes (d:Fin 4→ZMod 2) (h:KoblitzRound15Theta.pic0.mulVec d=d) : d=0 := no_fixed_Pic2_0 d h\nend KoblitzRound20Picard\n#print axioms KoblitzRound20Picard.actual_axis_match0\n#print axioms KoblitzRound20Picard.actual_axis_match2\n#print axioms KoblitzRound20Picard.no_fixed_Pic2_0\n#print axioms KoblitzRound20Picard.no_fixed_Pic2_2\n#print axioms KoblitzRound20Picard.canonical_difference_vanishes\n");
    save_lean(dir,"KoblitzRound20Picard.lean",lean);
    crate::round02::save(dir,"g26-canonical-orbit-Pic2-matching.json",&json!({"schema":"koblitz.round20/g26-v1","records":records,"Pic2_Frobenius":p,"all_fixed_vectors":fixed,"scope":"actual axis biases and no fixed geometric Pic0[2] class;written symmetric/F2 line-bundle comparison;no explicit rational trivializing function or full Lean geometry"}));
    println!("G26:graphs0/2 actual orbit axis bias{bits};canonical correction matches;only zero fixed Pic2 vector");
}
fn modpow(mut x:i64,mut n:i64,p:i64)->i64 {let mut y=1;while n>0 {if n&1!=0 {y=y*x%p;}x=x*x%p;n>>=1;}y}
fn nullspace(mut a:Vec<Vec<i64>>,p:i64,n:usize)->(usize,Vec<Vec<i64>>,Vec<Vec<i64>>) {
    let mut piv=vec![];
    for j in 0..n {
        let k=piv.len();
        let Some(i)=(k..a.len()).find(|i|a[*i][j]!=0) else {continue};
        a.swap(k,i);let inv=modpow(a[k][j],p-2,p);
        for z in &mut a[k] {*z=*z*inv%p;}
        for i in 0..a.len() {if i!=k {let q=a[i][j];for t in 0..n {a[i][t]=(a[i][t]-q*a[k][t]).rem_euclid(p);}}}
        piv.push(j);
    }
    let basis=(0..n).filter(|j|!piv.contains(j)).map(|j| {
        let mut v=vec![0;n];v[j]=1;for (i,k) in piv.iter().enumerate(){v[*k]=(-a[i][j]).rem_euclid(p);}v
    }).collect::<Vec<_>>();
    (piv.len(),basis,a)
}
fn pair(c:&crate::binary_ecc::BinaryCurve,base:&[P;2],v:&[i64])->P {
    lf::plus(c,&lf::times(c,&base[0],v[0] as u64),&lf::times(c,&base[1],v[1] as u64))
}
fn encode_point(c:&crate::binary_ecc::BinaryCurve,base:&[P;2],target:&P,p:i64)->[i64;2] {
    let found=(0..p).flat_map(|a|(0..p).map(move|b|[a,b])).filter(|v|pair(c,base,v)==*target).collect::<Vec<_>>();
    assert_eq!(found.len(),1);found[0]
}
fn decode_rows(data:&Value)->[[[Cm;4];5];4] {
    std::array::from_fn(|i|std::array::from_fn(|j|std::array::from_fn(|k| {
        (data["orbits"][i][j][k][0].as_i64().unwrap(),data["orbits"][i][j][k][1].as_i64().unwrap())
    })))
}
pub fn kernels(dir:&Path) {
    let data=read(&dir.join("g25-correct-polarization-orbit-sections.json"));
    let old=read(&dir.join("g17-odd-cover-kernel-and-commutators.json"));
    let rows=decode_rows(&data);
    let f=F::new(168,95);
    let mut records=vec![];
    let mut lean=String::from("import KoblitzRound20Picard\nnamespace KoblitzRound20Kernel\n");
    for (sign,record) in old["records"].as_array().unwrap().iter().enumerate() {
        let a=u64::from(record["trace"]==1);let c=f.curve(f.e(a),f.o());let mut primary=vec![];
        for t in record["torsion_bases"].as_array().unwrap() {
            let p=t["prime"].as_i64().unwrap();
            let base=[point(&f,&t["P"]),point(&f,&t["Q"])];
            let w=base.each_ref().map(|v|{let z=f.frobp(v,1);if a==1 {lf::neg(&z)}else{z}});
            let wc=w.each_ref().map(|v|encode_point(&c,&base,v,p));
            let mut matrix=vec![];
            for orbit in &rows {for row in orbit {
                for i in 0..2 {matrix.push((0..8).map(|j| {
                    let (aa,b)=row[j/2];(if j%2==i {aa}else{0}+b*wc[j%2][i]).rem_euclid(p)
                }).collect::<Vec<_>>());}
            }}
            let (rank,basis,rref)=nullspace(matrix.clone(),p,8);
            for v in &basis {assert!(matrix.iter().all(|r|r.iter().zip(v).map(|(a,b)|a*b).sum::<i64>()%p==0));}
            let mut witnesses=vec![];
            for v in &basis {
                let tuple=(0..4).map(|j|pair(&c,&base,&v[2*j..2*j+2])).collect::<Vec<_>>();
                assert!(tuple.iter().any(|q|*q!=P::Infinity));
                assert!(rows.iter().flatten().all(|r|act(&f,&c,&tuple,r,a)==P::Infinity));
                witnesses.push(json!({"basis_coordinates":v,"actual_points":tuple.iter().map(lf::pj).collect::<Vec<_>>()}));
            }
            let cardinality=(p as u64).pow((8-rank) as u32);
            let matrix_lit=format!("![{}]",matrix.iter().map(|r|format!("![{}]",r.iter().map(ToString::to_string).collect::<Vec<_>>().join(","))).collect::<Vec<_>>().join(","));
            let basis_lit=format!("![{}]",basis.iter().map(|r|format!("![{}]",r.iter().map(ToString::to_string).collect::<Vec<_>>().join(","))).collect::<Vec<_>>().join(","));
            lean.push_str(&format!("def matrix{sign}_{p} : Matrix (Fin 40) (Fin 8) (ZMod {p}) := {matrix_lit}\ndef basis{sign}_{p} : Fin {}→Fin 8→ZMod {p} := {basis_lit}\ntheorem actual_kernel_vectors{sign}_{p} : ∀i:Fin {},(matrix{sign}_{p}).mulVec (basis{sign}_{p} i)=0 := by decide +kernel\n",basis.len(),basis.len()));
            println!("G27 kernel:a{a},p{p},rank{rank},dimension{},order{cardinality}",8-rank);
            primary.push(json!({"prime":p,"w_matrix_columns":wc,"matrix":matrix,"RREF":rref,"rank":rank,"nullspace_basis":basis,"dimension":8-rank,"cardinality":cardinality,"verified_actual_point_generators":witnesses,"complete_linear_nullspace":true}));
        }
        records.push(json!({"graph":record["graph"],"ordinary_a":a,"primary":primary}));
    }
    lean.push_str("end KoblitzRound20Kernel\n");
    for sign in 0..2 {for p in [3,5,7] {lean.push_str(&format!("#print axioms KoblitzRound20Kernel.actual_kernel_vectors{sign}_{p}\n"));}}
    save_lean(dir,"KoblitzRound20Kernel.lean",lean);
    crate::round02::save(dir,"g27-common-orbit-map-kernel.json",&json!({"schema":"koblitz.round20/g27-kernel-v1","records":records,"kernel_containment":"all row maps zero implies C(P)=0;B*C=105I implies105P=0","scope":"complete native primary nullspaces plus actual point verification;Lean checks basis annihilation only,not native completeness or field/group semantics"}));
}
