# Round20 command and failure map

Working checkout /home/ec2-user/crypto-modular-ic on ef4f01db0d7539a2f954fe9fd633039660bbae59,
scientific parent11b2f23f97195b5e3eda5f5764d46a1dd7818f92. Commands below use
S=research/koblitz_modular_ic_20261018, R=$S/rounds/20, and the release
native runner $S/native/target/release/koblitz-modular-carriers.
The installed Rust and Lean bins are explicitly placed on PATH. Protocol
and amendments predate their dependent native searches;1200s per native
experiment command. No timing comparison is made. All native successful
math commands exit0;their exact result files and retained attempt logs
are named below. Output JSON and generated Lean are write-once per output
directory;replacement exports use fresh attempt directories.

Migration:approved handoff receipt and /run/spot-legacy/diem.json read first;
no duplicate Diem generator,EKS job or source waiting-freeze followup launched.
RECOVERY.md identifies the completed R19 evidence and external reconciliation.
Conductor T-291/check clear before code changes;the managed agent is not
restarted merely to attach an ephemeral CLI lease. No task budget enlarged.

Native production commands:
--round20-picard $R/runs (picard-01.log,G26).
--round20-kernel $R/runs (kernel-01.log;initial vacuous zero-basis Lean export).
--round20-kernel $R/runs/kernel-02 (kernel-02.log;actual left-inverse proofs,
960 point-column controls;final G27 JSON and Lean copied to raw root).
--round20-retraction $R/runs (retraction-01.log,G28).
--round20-sections $R/runs (sections-01.log,G29).
--round20-projector $R/runs (projector-01.log,G30).
--round20-maps $R/runs q for q=0..7 (maps-q0..7.log,CM25).
--round20-map-summary $R/runs (map-summary-01.log,CM26).
--round20-quotient $R/runs (quotient-01.log;initial hopeful Lean rejection
is false and never built;actual boundary residue already zero).
--round20-quotient $R/runs/quotient-02 (quotient-02.log;corrected actual
constant denominator degree,zero satisfaction and inv98 binding;final
Q33 JSON and Lean copied to raw root).
--round20-boundary $R/runs (boundary-01.log,Q34;all four complete models).
REPLAY.sh is the exact final native replay:24 inputs,16 commands,16 JSON
outputs and8 generated Lean modules. It checks three source-bound IDs.

Native builds use cargo build --release --locked --manifest-path
$S/native/Cargo.toml. build-01 passes;build-02 fails BigInt scalar inference,
source retained;build-03 passes;build-projector-04 passes. Recorder
build-record-05 fails usize/u32 exponent types;source retained and
build-record-06 passes. The first native suite fails one IDC test because
the sparse char2 identity is false over the certificate's fixed odd prime;
no ID was issued. A matching universal power factorization replaces that
certificate statement,and the char2 theorem remains separate. Final
native-tests-02.log passes126 with1 ignored. build-final-07 is the final
release executable for recording/replay;rustfmt.log is cargo fmt --check.

Root:cargo test --release --lib with CARGO_TARGET_DIR=/home/ec2-user/crypto/target.
root-release-tests.log fails only the existing F4 cheaper-count threshold
(observed18,requires20). root-f4-recheck.log passes the isolated exact test;
root-release-tests-02.log passes4493 with119 ignored. No root algorithm or
test assertion is changed. These are correctness runs,not isolated timings.

Lean:lake build KoblitzRound20 KoblitzRound20Sections
KoblitzRound20Separators KoblitzRound20Boundary KoblitzRound20Maps in $S/lean.
lean-01 launch used the wrong cwd for preparation and failed;lean-02.log
is the corrected build. All final modules must be built and all local
compiled modules audited with tools/lean/AuditAxioms.lean under the pinned
4.34.1/mathlib manifest. Later build/audit logs state actual outcomes;
PROOF_MAP.md exposes all native/geometric gaps. CyclicWindow.lean is the
separate pinned numerical control,cyclic-axioms.log. No lean4checker or
independent-host audit is claimed. Kernel-norm-control sources/logs retain
the attempt to reduce the finite-matrix proof's compile cost;the initial
preparation used a wrong relative cwd and is not a passing proof receipt.

Existing checks:python3 scripts/site/test_build.py (49),python3
scripts/test_workflows_parse.py (4),python3 .github/scripts/test-pr-budgets.py
(18). A temporary copy of the touched workflow is checked with
.github/scripts/check-pr-budgets.py (0 violations,25-minute cap retained).
backlog validate XP-20261021-koblitz-level77-map passes;the initial wrong
path argument fails and is retained. Node22 tools/render_ic_dashboard.mjs
and --check pass. Python only edits files,runs existing tests and renders
recorded values/PDFs;it performs no research arithmetic or verification.

The final source-bound --round20-issue-identities and --record-round20
commands occur only after stable source and a passing complete audit.
After ledger/raw manifest issuance no raw file is changed. The deterministic
raw/validation archives use24 October UTC mtime,gnu tar,normalized owner,
mode and xz -6 -T1. Fresh extraction/native hashes/full REPLAY.sh/current
pins/historical R19 pins and both byte-identical repacks are recorded outside
runs,in validation-runs and ARCHIVE_VALIDATION.txt. The generic manifest and
source-verifier CLIs retain their historical --round16 names.

Proof continuation:lean-02 is interrupted after the Kernel worker exceeds
20 minutes,with lean-02-interruption.txt. Norm controls02/03 fail on
unexpanded matrix multiplication and then unnormalized ZMod numerals;
these failed scratch modules are not project proof targets. Attempt04
adds kernel reduction only to the resulting scalar numeric goals. The
G28 import is changed from Kernel to Picard without a statement change;
retraction-02 regenerates identical JSON and the updated source module.
lean-central-03 builds the actual retraction,manual structural statements,
sections and literal projector. Final full gate/audit logs follow.

The final finite-matrix proof is regenerated in kernel-03:identical G27
JSON,entrywise normalization plus scalar decide+kernel. The one-matrix
control04 passes without nonstandard axioms. The first central manual
compile diagnoses missing Matrix annotations,rectangular rewrite names,
a field ratio normalization and binder spacing. Its source/log are kept.
The corrected manual module passes all16 names with standard foundations.
All8 final generated modules match their raw sources. Final native tests
in native-tests-final-03.log pass126 with1 ignored after proof-export edits.
The three stable-source IDs are issued only after the manual build passes;
identity-check.log retains128 additional parsed checks for each.

Additional proof controls retain the row-first normalization of the p7
certificate(control05),the generic Field lemma(control06),and the full
actual p3 recovery implication using an explicitly typed CommRing
instance(control07);all three pass with standard foundations. The combined
Field-instantiated module is interrupted without a passing result;the
ring-level generalization needs no division and keeps all actual matrices
and native JSON unchanged. kernel-05 regenerates the final module and
lean-kernel-06.log records its build. Interrupted sources and logs remain
raw;none is substituted for a completed audit. The pre-freeze replay
passes16 JSON/8 Lean outputs before this proof-only generalization;the
final replay uses the final generator and checks every final source byte.

The final combined CommRing Kernel module passes all13 names in99 seconds
(lean-kernel-06.log). Final preflight replay again matches16 JSON/8 Lean
modules and all3 IDs. The final recorder build12 and native suite06 pass
126/1 ignored,and formatting passes. The complete proof-gate invocation
starts a cache preflight;it is interrupted with empty output and a worker
blocked in folio_wait_bit_common on NFS,recorded in lean-cache-preflight*
and lean-proof-gate.log. It is not called a passing proof-gate script.
Equivalent exact stages are:in the pinned Lean project,timeout1200 lake
build;then enumerate every .lake/build/lib/lean/**/*.olean module and
run timeout1200 lake env lean --run tools/lean/AuditAxioms.lean --trusted
tools/lean/trusted-native.txt with that complete list. The full build
passes9061 jobs;the completed audit and status have their own receipts.

Final complete audit passes821 project theorems,zero failing and zero
trusted(lean-full-audit.log,exit0 and lean-full-status.txt). The recorder
requires every one of76 new explicit theorem names and exact named count76.
The completed main process briefly waits for shutdown RPC cleanup;it
resolves before the proc probe/signalling command,so no signal is sent.
The original wrapper exits0. No independent-host or lean4checker run is
available. All native/test/proof processes are complete before the
write-once raw ledger/manifest seal.
