# Round13 executed commands and receipts

Repository /home/ec2-user/crypto-modular-ic; parent7fde2b9498ec30ea2e111f1b178ae000e465331d.
Frozen arithmetic resources and amendments are in ../PROTOCOL.md.
All commands use the study native Cargo.lock and pinned Lean project.

- cargo build --release --offline --locked (build-01 through17 logs retain failures).
- timeout1200 native/target/release/koblitz-modular-carriers --round13-norm runs
- --round13-supports runs (support-01 rejected,02 accepted)
- --round13-middles runs
- --round13-fibers runs (01 capped at100m;02 accepted underAmendmentB1b)
- --round13-images runs (generated Lean array syntax corrected with failed source retained;JSON unchanged)
- --round13-saturation runs
- --round13-pair-colon runs
- --round13-square-colon runs
- --round13-boundary-lean runs and --round13-square-lean runs (generated source representations retained)
- --verify-round13 runs (all15 outputs/checkpoints and three generated modules are byte replayed by ../REPLAY.sh)
- cargo test --release --offline --locked --manifest-path study/native/Cargo.toml:110 passed,1 ignored;native-tests-02.log.
- CARGO_TARGET_DIR=/home/ec2-user/crypto/target cargo test --release --lib --offline --locked -- --test-threads=1:4405 passed,118 ignored;root-lib-tests-serial-01.log. Serial invocation follows the retained shared profiling-counter race from round12;no test is weakened.
- lake build KoblitzRound13:lean-build-03.log accepted.
- lake build KoblitzRound13Data:lean-data-build-03.log accepted.
- lake build KoblitzRound13Square:lean-square-build-03.log accepted.
- lake build KoblitzRound13Boundary KoblitzRound13SquareData:final sparse representation;prior interrupted dense proofs retained.
- tools/lean/proof-gate.sh study/lean --out /home/ec2-user/.cache/koblitz-round13-proof-gate:receipt copied only afterexit0.
- python3 -m unittest discover -s scripts/site -p test_build.py:49 passing tests.
- python3 -m unittest scripts.test_workflows_parse:4 passing tests;repeated afterworkflow edit.
- node tools/render_ic_dashboard.mjs and --check:generated page/data and historical pins.

No timing comparison, IC solver run or external CAS audit is performed.
Python is used only for report layout/PDF inspection and existing repository tests.

Final review strengthens the nonbacktracking guard to distinct endpoint
j-invariants on every49 chain,checked again by O18. native-tests-03.log
and replay-02.log retain the fresh test/replay. This replaces a comparison
of kernel polynomials on different intermediate curves;all exported
results remain byte-identical. No new family or resource cap is used.
