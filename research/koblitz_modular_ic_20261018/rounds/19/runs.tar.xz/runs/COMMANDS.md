# Round19 command and receipt map

Repository: /home/ec2-user/crypto-modular-ic. Scientific parent is
a2b8f27be5fb3faac9362430ef43245b3bce819d. PROTOCOL.md records the
registered bounds and amendments. environment.log records the compilers,
host kernel and parent tree. The shared host has no performance-isolation
tier; no elapsed-time performance result or IC efficiency verdict is made.

Build: cargo build --release --locked --manifest-path
research/koblitz_modular_ic_20261018/native/Cargo.toml. Native tests use
cargo test with the same options. The final receipts are
build-record-final-17.log and native-tests-final-06.log (123 pass,1 ignored).
Root tests use CARGO_TARGET_DIR=/home/ec2-user/crypto/target cargo test
--release --lib: root-release-tests.log fails the F4 threshold, the isolated
root-f4-recheck.log passes, and root-release-tests-02.log passes4487 with119
ignored. Formatting uses cargo fmt with the native manifest and -- --check.

All15 exact native commands, their18 input JSON files, per-command1200s
wall caps and byte comparisons are in REPLAY.sh. Initial accepted receipts
are poles-q0..4-01, map-proof-01, mixed-01, polarization-01, profile-01,
resultant-02, repair-01 and family-01. List representation and actual gate
binding are finalized in resultant-03. Companion accounting is strengthened
in mixed-02; final Q32 metadata is in final-repair-02. G24's corrected
certificate is orbit-obstruction-02; G25's final metadata/fixed-divisor
checks are orbit-cover-02 and final-mixed-02. The initial metadata and
source snapshots remain alongside them. Preflight regenerates all outputs;
its stdout/session receipt was lost during migration, but the recovered
bytes pass every comparison (preflight-recovery.log). No experiment timeout
or unexpanded affine solution space is claimed.

Lean targeted builds run from study/lean with lake build and the named
Round19 modules. The final G24 and G25 receipts are
lean-polarization-11.log and lean-orbit-cover-13.log. Full initial gate:
tools/lean/proof-gate.sh --out
research/koblitz_modular_ic_20261018/rounds/19/runs/full-gate
research/koblitz_modular_ic_20261018/lean.
After the additional modules, lake build is recorded in
lean-final-project-build-14.log. Every .olean beneath
.lake/build/lib/lean is converted to a sorted module name in
lean-final-project-modules.txt, then passed to:
lake env lean --run /home/ec2-user/crypto-modular-ic/tools/lean/AuditAxioms.lean
--trusted /home/ec2-user/crypto-modular-ic/tools/lean/trusted-native.txt
MODULES. lean-full-audit.log is the final result. The first empty audit log
is retained as lean-full-audit-migration-interrupted.log. The native recorder
also requires all79 new theorem names to be present, preventing omission
of a late module. Interrupted duplicate elaboration and failed proofs are
documented in PROOF_MAP.md and retained rather than used as passing evidence.
The first audit restart fails opening a mathlib signature with "Disk quota
exceeded" (lean-full-audit-quota-attempt-02.log). Copying that existing
176-byte file to /tmp then succeeds. The subsequent audit retry uses the
same complete module list under an explicit timeout1200 wrapper.

Site: python3 scripts/site/test_build.py. Workflow: python3
scripts/test_workflows_parse.py and python3 .github/scripts/test-pr-budgets.py.
The touched workflow is copied to a temporary directory for
.github/scripts/check-pr-budgets.py. Backlog: the root release backlog
binary validates XP-20261021-koblitz-level77-map. Dashboard: Node22 runs
tools/render_ic_dashboard.mjs and --check. Report: the report virtualenv
runs rounds/19/render.py; Python only edits files, runs existing tests and
lays out/inspects recorded results. Final PDF page images are inspected
as described in VISUAL_REVIEW.md.

The final write-once --record-round19 invocation issues the ledger,
source/member hashes and three IDC records, then raw files are frozen.
Post-freeze source-pin checks, fresh archive extraction/member hashes,
REPLAY.sh and byte-identical repacks live outside runs/ in validation-runs
and ARCHIVE_VALIDATION.txt. No Round01–18 frozen artifact is rewritten.
