The first fresh replay stopped before arithmetic:the migrated shell lacked
~/.cargo/bin in PATH. Its log and copied inputs remain in replay-attempt-01.
The existing compiler is still Rust/Cargo1.99.1. The complete fresh replay
uses PATH=/home/ec2-user/.cargo/bin:/usr/local/bin:/usr/bin:/bin, leaving
the frozen replay script and sources unchanged. No toolchain was installed
or changed. Raw extraction and member hashes had already passed and were
not repeated. Subsequent commands resume after this failed replay step.
