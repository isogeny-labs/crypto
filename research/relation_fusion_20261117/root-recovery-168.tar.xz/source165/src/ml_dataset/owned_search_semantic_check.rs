//! Captured equation lineage and committed basis identities, relative to the
//! captured normalized generators. No original descent or complete-search claim.
use super::{
    bqi, bridge,
    scheduler::{ProofTerm, Row},
    sparse::{self, Charge, Polynomial},
    wire::{self, Value},
};
use std::{mem::size_of, time::Instant};
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Failure {
    Cap,
    Owner,
    Deadline,
    Overflow,
    Allocation,
    Malformed,
    Lineage,
    Unavailable,
    Certificate(bridge::Failure),
}
#[derive(Clone, Copy)]
pub struct Limits {
    pub variables: u32,
    pub partitions: usize,
    pub nodes: usize,
    pub rows: usize,
    pub generators: usize,
    pub terms: usize,
    pub degree: usize,
    pub proof: usize,
    pub work: u64,
    pub bytes: u64,
    pub certificate: bridge::Limits,
    pub checker: bqi::Limits,
}
impl Limits {
    pub fn conservative(work: u64, bytes: u64) -> Self {
        let work = work.min(4_000_000);
        let bytes = bytes.min(8_000_000);
        Self {
            variables: 4096,
            partitions: 4096,
            nodes: 4096,
            rows: 4096,
            generators: 4096,
            terms: 4096,
            degree: 64,
            proof: 4096,
            work,
            bytes,
            certificate: bridge::Limits {
                variables: 4096,
                generators: 4096,
                terms: 4096,
                degree: 64,
                proof: 4096,
                wire: 65536,
                work,
                bytes,
            },
            checker: bqi::Limits {
                variables: 4096,
                generators: 4096,
                polynomial_terms: 4096,
                proof_terms: 4096,
                accumulator_entries: 4096,
                caps: [
                    65536, 262144, 262144, 262144, 262144, 65536, 1024, 1048576, 262144,
                ],
            },
        }
    }
}
pub struct RowAudit {
    pub partition: usize,
    pub node: usize,
    pub row: usize,
    pub certificate: bridge::Certificate,
}
pub struct Audit {
    pub result: Result<(), Failure>,
    pub charge: Charge,
    pub partitions: usize,
    pub nodes: usize,
    pub partial: usize,
    pub rows: Vec<RowAudit>,
    pub original_descent_verified: bool,
    pub search_complete: bool,
}
struct Meter<'a, T: wire::Admission> {
    owner: &'a mut T,
    limits: Limits,
    deadline: Instant,
    charge: Charge,
    nodes: usize,
    rows: usize,
}
impl<T: wire::Admission> Meter<'_, T> {
    fn pay(&mut self, w: u64, b: u64) -> Result<(), Failure> {
        if Instant::now() >= self.deadline {
            return Err(Failure::Deadline);
        }
        let q = Charge {
            work: self.charge.work.checked_add(w).ok_or(Failure::Overflow)?,
            bytes: self.charge.bytes.checked_add(b).ok_or(Failure::Overflow)?,
        };
        if q.work > self.limits.work || q.bytes > self.limits.bytes {
            return Err(Failure::Cap);
        }
        self.owner.reserve(w, b).map_err(|_| Failure::Owner)?;
        self.charge = q;
        self.owner.check().map_err(|_| Failure::Owner)?;
        if Instant::now() >= self.deadline {
            return Err(Failure::Deadline);
        }
        Ok(())
    }
    fn scan(&mut self, n: usize) -> Result<(), Failure> {
        self.pay(
            u64::try_from(n)
                .map_err(|_| Failure::Overflow)?
                .checked_add(1)
                .ok_or(Failure::Overflow)?,
            0,
        )
    }
    fn vec<V>(&mut self, n: usize, cap: usize) -> Result<Vec<V>, Failure> {
        if n > cap {
            return Err(Failure::Cap);
        }
        let bytes = n
            .checked_mul(size_of::<V>())
            .and_then(|v| v.checked_add(64))
            .ok_or(Failure::Overflow)?;
        self.pay(1, u64::try_from(bytes).map_err(|_| Failure::Overflow)?)?;
        let mut v = Vec::new();
        v.try_reserve_exact(n).map_err(|_| Failure::Allocation)?;
        Ok(v)
    }
    fn eq_poly(&mut self, a: &Polynomial, b: &Polynomial) -> Result<(), Failure> {
        for p in [a, b] {
            self.scan(p.len())?;
            for t in p {
                self.scan(t.len())?
            }
        }
        need(a == b)
    }
}
struct Nested<'a, 'b, T: wire::Admission> {
    meter: &'a mut Meter<'b, T>,
    failure: Option<Failure>,
}
impl<T: wire::Admission> sparse::Owner for Nested<'_, '_, T> {
    fn reserve(&mut self, q: Charge) -> Result<(), ()> {
        self.meter.pay(q.work, q.bytes).map_err(|e| {
            self.failure = Some(e);
        })
    }
    fn check(&mut self) -> Result<(), ()> {
        self.meter.pay(0, 0).map_err(|e| {
            self.failure = Some(e);
        })
    }
}
fn need(v: bool) -> Result<(), Failure> {
    if v {
        Ok(())
    } else {
        Err(Failure::Lineage)
    }
}
fn array(v: &Value) -> Result<&[Value], Failure> {
    v.as_array().ok_or(Failure::Malformed)
}
fn uint(v: &Value) -> Result<usize, Failure> {
    usize::try_from(v.as_u64().ok_or(Failure::Malformed)?).map_err(|_| Failure::Overflow)
}
fn bit(v: &Value) -> Result<bool, Failure> {
    v.as_bool().ok_or(Failure::Malformed)
}
fn optional(v: &Value) -> Result<Option<usize>, Failure> {
    if matches!(v, Value::Null) {
        Ok(None)
    } else {
        uint(v).map(Some)
    }
}
fn field<'a, T: wire::Admission>(
    v: &'a Value,
    k: &str,
    m: &mut Meter<T>,
) -> Result<&'a Value, Failure> {
    let fields = v.as_object().ok_or(Failure::Malformed)?;
    let mut found = None;
    for (name, value) in fields {
        m.scan(name.len())?;
        if name == k {
            if found.is_some() {
                return Err(Failure::Malformed);
            }
            found = Some(value)
        }
    }
    found.ok_or(Failure::Malformed)
}
fn text<'a, T: wire::Admission>(v: &'a Value, m: &mut Meter<T>) -> Result<&'a str, Failure> {
    let s = v.as_str().ok_or(Failure::Malformed)?;
    if s.len() > 128 {
        return Err(Failure::Cap);
    }
    m.scan(s.len())?;
    Ok(s)
}
fn mono<T: wire::Admission>(v: &Value, n: u32, m: &mut Meter<T>) -> Result<Vec<u32>, Failure> {
    let a = array(v)?;
    let mut out = m.vec(a.len(), m.limits.degree)?;
    let mut prev = None;
    for x in a {
        m.pay(1, 0)?;
        let x =
            u32::try_from(x.as_u64().ok_or(Failure::Malformed)?).map_err(|_| Failure::Malformed)?;
        if x >= n || prev.is_some_and(|p| p >= x) {
            return Err(Failure::Malformed);
        }
        out.push(x);
        prev = Some(x)
    }
    Ok(out)
}
fn poly<T: wire::Admission>(v: &Value, n: u32, m: &mut Meter<T>) -> Result<Polynomial, Failure> {
    let a = array(v)?;
    let mut out: Polynomial = m.vec(a.len(), m.limits.terms)?;
    for t in a {
        let t = mono(t, n, m)?;
        if let Some(prev) = out.last() {
            m.scan(prev.len().checked_add(t.len()).ok_or(Failure::Overflow)?)?;
            if (prev.len(), prev) >= (t.len(), &t) {
                return Err(Failure::Malformed);
            }
        }
        out.push(t)
    }
    Ok(out)
}
fn polys<T: wire::Admission>(
    v: &Value,
    n: u32,
    m: &mut Meter<T>,
) -> Result<Vec<Polynomial>, Failure> {
    let a = array(v)?;
    let mut out = m.vec(a.len(), m.limits.generators)?;
    for p in a {
        out.push(poly(p, n, m)?)
    }
    Ok(out)
}
fn bits<T: wire::Admission>(v: &Value, n: u32, m: &mut Meter<T>) -> Result<Vec<bool>, Failure> {
    let a = array(v)?;
    let mut out = m.vec(a.len(), n as usize)?;
    for x in a {
        m.pay(1, 0)?;
        out.push(bit(x)?)
    }
    Ok(out)
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Origin {
    Original(usize),
    Branch {
        parent: usize,
        variable: u32,
        value: bool,
    },
}
fn decimal(s: &str) -> Result<usize, Failure> {
    if s.is_empty() || (s.len() > 1 && s.starts_with('0')) || !s.bytes().all(|b| b.is_ascii_digit())
    {
        return Err(Failure::Malformed);
    }
    s.parse().map_err(|_| Failure::Malformed)
}
fn origin<T: wire::Admission>(v: &Value, m: &mut Meter<T>) -> Result<Origin, Failure> {
    let s = text(v, m)?;
    m.scan(s.len().checked_mul(4).ok_or(Failure::Overflow)?)?;
    if let Some(s) = s
        .strip_prefix("Original(")
        .and_then(|s| s.strip_suffix(')'))
    {
        return Ok(Origin::Original(decimal(s)?));
    }
    let s = s
        .strip_prefix("Branch { parent: ")
        .and_then(|s| s.strip_suffix(" }"))
        .ok_or(Failure::Malformed)?;
    let (p, s) = s.split_once(", variable: ").ok_or(Failure::Malformed)?;
    let (v, b) = s.split_once(", value: ").ok_or(Failure::Malformed)?;
    let value = match b {
        "true" => true,
        "false" => false,
        _ => return Err(Failure::Malformed),
    };
    Ok(Origin::Branch {
        parent: decimal(p)?,
        variable: u32::try_from(decimal(v)?).map_err(|_| Failure::Malformed)?,
        value,
    })
}
#[derive(Clone, Copy, PartialEq, Eq)]
enum PStatus {
    Building,
    Ready,
    Running,
    Candidate,
    Splitting,
    Excluded,
    Refuted,
}
#[derive(Clone, Copy, PartialEq, Eq)]
enum NStatus {
    Building,
    Ready,
    Running,
    Branching,
    Branched,
    Refuted,
    Witness,
}
struct Node {
    parent: Option<usize>,
    status: NStatus,
    equations: Vec<Polynomial>,
    origins: Vec<Origin>,
    decisions: Vec<(u32, bool)>,
    children: [Option<usize>; 2],
    candidate: Vec<bool>,
    basis: Vec<Row>,
}
struct Search {
    nodes: Vec<Node>,
    witness: Option<usize>,
}
struct Partition {
    parent: Option<usize>,
    prefix: Vec<bool>,
    status: PStatus,
    equations: Vec<Polynomial>,
    children: Vec<usize>,
    search: Option<Search>,
}
fn row<T: wire::Admission>(v: &Value, n: u32, g: usize, m: &mut Meter<T>) -> Result<Row, Failure> {
    let polynomial = poly(field(v, "polynomial", m)?, n, m)?;
    let ps = array(field(v, "proof", m)?)?;
    let mut proof: Vec<ProofTerm> = m.vec(ps.len(), m.limits.proof)?;
    for p in ps {
        m.pay(1, 0)?;
        let p = array(p)?;
        if p.len() != 2 {
            return Err(Failure::Malformed);
        }
        let generator = uint(&p[0])?;
        if generator >= g {
            return Err(Failure::Malformed);
        }
        let multiplier = mono(&p[1], n, m)?;
        if let Some(prev) = proof.last() {
            m.scan(
                prev.multiplier
                    .len()
                    .checked_add(multiplier.len())
                    .ok_or(Failure::Overflow)?,
            )?;
            if (prev.generator, &prev.multiplier) >= (generator, &multiplier) {
                return Err(Failure::Malformed);
            }
        }
        proof.push(ProofTerm {
            generator,
            multiplier,
        })
    }
    Ok(Row { polynomial, proof })
}
fn node<T: wire::Admission>(v: &Value, n: u32, m: &mut Meter<T>) -> Result<Node, Failure> {
    let parent = optional(field(v, "parent", m)?)?;
    let status = match text(field(v, "status", m)?, m)? {
        "Building" => NStatus::Building,
        "Ready" => NStatus::Ready,
        "Running" => NStatus::Running,
        "Branching" => NStatus::Branching,
        "Branched" => NStatus::Branched,
        "Refuted" => NStatus::Refuted,
        "Witness" => NStatus::Witness,
        _ => return Err(Failure::Malformed),
    };
    let equations = polys(field(v, "equations", m)?, n, m)?;
    let os = array(field(v, "origins", m)?)?;
    let mut origins = m.vec(os.len(), m.limits.generators)?;
    for o in os {
        origins.push(origin(o, m)?)
    }
    let ds = array(field(v, "decisions", m)?)?;
    let mut decisions = m.vec(ds.len(), n as usize)?;
    for d in ds {
        m.pay(1, 0)?;
        let d = array(d)?;
        if d.len() != 2 {
            return Err(Failure::Malformed);
        }
        let v = u32::try_from(uint(&d[0])?).map_err(|_| Failure::Malformed)?;
        if v >= n {
            return Err(Failure::Malformed);
        }
        decisions.push((v, bit(&d[1])?))
    }
    let cs = array(field(v, "children", m)?)?;
    if cs.len() != 2 {
        return Err(Failure::Malformed);
    }
    let children = [optional(&cs[0])?, optional(&cs[1])?];
    let candidate = bits(field(v, "candidate", m)?, n, m)?;
    let native = field(v, "native", m)?;
    let mut basis = Vec::new();
    if !matches!(native, Value::Null) {
        let rs = array(field(native, "basis", m)?)?;
        m.rows = m.rows.checked_add(rs.len()).ok_or(Failure::Overflow)?;
        if m.rows > m.limits.rows {
            return Err(Failure::Cap);
        }
        basis = m.vec(rs.len(), m.limits.rows)?;
        for r in rs {
            basis.push(row(r, n, equations.len(), m)?)
        }
    }
    Ok(Node {
        parent,
        status,
        equations,
        origins,
        decisions,
        children,
        candidate,
        basis,
    })
}
fn partitions<T: wire::Admission>(
    v: &Value,
    n: u32,
    m: &mut Meter<T>,
) -> Result<Vec<Partition>, Failure> {
    let ps = array(field(v, "partitions", m)?)?;
    if ps.is_empty() {
        return Err(Failure::Unavailable);
    }
    let mut out = m.vec(ps.len(), m.limits.partitions)?;
    for p in ps {
        let parent = optional(field(p, "parent", m)?)?;
        let prefix = bits(field(p, "prefix", m)?, n, m)?;
        let status = match text(field(p, "status", m)?, m)? {
            "Building" => PStatus::Building,
            "Ready" => PStatus::Ready,
            "Running" => PStatus::Running,
            "Candidate" => PStatus::Candidate,
            "Splitting" => PStatus::Splitting,
            "Excluded" => PStatus::Excluded,
            "Refuted" => PStatus::Refuted,
            _ => return Err(Failure::Malformed),
        };
        let equations = polys(field(p, "equations", m)?, n, m)?;
        let cs = array(field(p, "children", m)?)?;
        let mut children = m.vec(cs.len(), n as usize)?;
        for c in cs {
            m.pay(1, 0)?;
            children.push(uint(c)?)
        }
        let s = field(p, "search", m)?;
        let search = if matches!(s, Value::Null) {
            None
        } else {
            let ns = array(field(s, "nodes", m)?)?;
            m.nodes = m.nodes.checked_add(ns.len()).ok_or(Failure::Overflow)?;
            if m.nodes > m.limits.nodes {
                return Err(Failure::Cap);
            }
            let mut nodes = m.vec(ns.len(), m.limits.nodes)?;
            for v in ns {
                nodes.push(node(v, n, m)?)
            }
            Some(Search {
                nodes,
                witness: optional(field(s, "witness_node", m)?)?,
            })
        };
        out.push(Partition {
            parent,
            prefix,
            status,
            equations,
            children,
            search,
        })
    }
    Ok(out)
}
fn constraint<T: wire::Admission>(
    p: &Polynomial,
    v: u32,
    b: bool,
    m: &mut Meter<T>,
) -> Result<(), Failure> {
    for t in p {
        m.scan(t.len())?
    }
    need(if b {
        p.len() == 2 && p[0].is_empty() && p[1].as_slice() == [v]
    } else {
        p.len() == 1 && p[0].as_slice() == [v]
    })
}
fn sequence_len(actual: usize, expected: usize, partial: bool) -> Result<(), Failure> {
    need(if partial {
        actual <= expected
    } else {
        actual == expected
    })
}
fn lineage<T: wire::Admission>(
    g: &[Polynomial],
    ps: &[Partition],
    n: u32,
    m: &mut Meter<T>,
    out: &mut Audit,
) -> Result<(), Failure> {
    for (i, p) in ps.iter().enumerate() {
        m.pay(1, 0)?;
        let building = p.status == PStatus::Building;
        if i == 0 {
            need(p.parent.is_none() && p.prefix.is_empty())?
        } else {
            let parent = p.parent.ok_or(Failure::Lineage)?;
            need(parent < i)?;
            let q = &ps[parent];
            need(matches!(q.status, PStatus::Splitting | PStatus::Excluded))?;
            m.scan(q.children.len())?;
            let mut ordinal = None;
            for (j, &c) in q.children.iter().enumerate() {
                if c == i {
                    need(ordinal.is_none())?;
                    ordinal = Some(j)
                }
            }
            let ordinal = ordinal.ok_or(Failure::Lineage)?;
            let s = q.search.as_ref().ok_or(Failure::Lineage)?;
            let w = s.witness.ok_or(Failure::Lineage)?;
            let model = &s.nodes.get(w).ok_or(Failure::Lineage)?.candidate;
            need(model.len() == n as usize)?;
            let fixed = q.prefix.len();
            m.scan(fixed)?;
            need(model[..fixed] == q.prefix)?;
            let j = fixed.checked_add(ordinal).ok_or(Failure::Overflow)?;
            need(j < n as usize)?;
            sequence_len(p.prefix.len(), j + 1, building)?;
            for (k, &b) in p.prefix.iter().enumerate() {
                m.pay(1, 0)?;
                need(b == if k == j { !model[k] } else { model[k] })?
            }
        }
        for (j, &c) in p.children.iter().enumerate() {
            m.scan(j)?;
            need(c > i && c < ps.len() && !p.children[..j].contains(&c))?;
            need(ps[c].parent == Some(i))?
        }
        if p.status == PStatus::Excluded {
            need(p.children.len() == n as usize - p.prefix.len())?
        }
        if !matches!(p.status, PStatus::Splitting | PStatus::Excluded) {
            need(p.children.is_empty())?
        }
        if p.status == PStatus::Splitting {
            out.partial += 1
        }
        sequence_len(
            p.equations.len(),
            g.len()
                .checked_add(p.prefix.len())
                .ok_or(Failure::Overflow)?,
            building,
        )?;
        for (j, eq) in p.equations.iter().enumerate() {
            if j < g.len() {
                m.eq_poly(eq, &g[j])?
            } else {
                constraint(eq, (j - g.len()) as u32, p.prefix[j - g.len()], m)?
            }
        }
        if building {
            out.partial += 1
        }
        out.partitions += 1;
        let Some(search) = &p.search else { continue };
        need(!building)?;
        if search.nodes.is_empty() {
            out.partial += 1
        }
        for (k, node) in search.nodes.iter().enumerate() {
            m.pay(1, 0)?;
            let building = node.status == NStatus::Building;
            if k == 0 {
                need(node.parent.is_none())?;
                sequence_len(node.equations.len(), p.equations.len(), building)?;
                sequence_len(node.origins.len(), p.equations.len(), building)?;
                need(node.decisions.is_empty())?;
                for (j, eq) in node.equations.iter().enumerate() {
                    m.eq_poly(eq, &p.equations[j])?
                }
                for (j, o) in node.origins.iter().enumerate() {
                    m.pay(1, 0)?;
                    need(*o == Origin::Original(j))?
                }
            } else {
                let parent = node.parent.ok_or(Failure::Lineage)?;
                need(parent < k)?;
                let q = &search.nodes[parent];
                need(matches!(q.status, NStatus::Branching | NStatus::Branched))?;
                need(q.children.iter().filter(|c| **c == Some(k)).count() == 1)?;
                let value = q.children[1] == Some(k);
                for (j, (v, _)) in q.decisions.iter().enumerate() {
                    m.scan(j)?;
                    need(!q.decisions[..j].iter().any(|(w, _)| w == v))?
                }
                let mut variable = 0;
                loop {
                    m.scan(q.decisions.len())?;
                    if !q.decisions.iter().any(|(v, _)| *v == variable) {
                        break;
                    }
                    variable = variable.checked_add(1).ok_or(Failure::Overflow)?
                }
                need(variable < n)?;
                sequence_len(
                    node.equations.len(),
                    q.equations.len().checked_add(1).ok_or(Failure::Overflow)?,
                    building,
                )?;
                sequence_len(
                    node.origins.len(),
                    q.origins.len().checked_add(1).ok_or(Failure::Overflow)?,
                    building,
                )?;
                sequence_len(
                    node.decisions.len(),
                    q.decisions.len().checked_add(1).ok_or(Failure::Overflow)?,
                    building,
                )?;
                for (j, eq) in node.equations.iter().enumerate() {
                    if j < q.equations.len() {
                        m.eq_poly(eq, &q.equations[j])?
                    } else {
                        constraint(eq, variable, value, m)?
                    }
                }
                for (j, o) in node.origins.iter().enumerate() {
                    m.pay(1, 0)?;
                    need(
                        *o == if j < q.origins.len() {
                            q.origins[j]
                        } else {
                            Origin::Branch {
                                parent,
                                variable,
                                value,
                            }
                        },
                    )?
                }
                for (j, d) in node.decisions.iter().enumerate() {
                    m.pay(1, 0)?;
                    need(
                        *d == if j < q.decisions.len() {
                            q.decisions[j]
                        } else {
                            (variable, value)
                        },
                    )?
                }
            }
            need(node.equations.len() == node.origins.len())?;
            for c in node.children.into_iter().flatten() {
                need(c > k && c < search.nodes.len())?;
                need(search.nodes[c].parent == Some(k))?
            }
            let cs = node.children;
            need(cs[0].is_none() || cs[0] != cs[1])?;
            if node.status == NStatus::Branching {
                out.partial += 1
            }
            if !matches!(node.status, NStatus::Branching | NStatus::Branched) {
                need(cs == [None, None])?
            }
            need(cs[0].is_none() || cs[1].is_some())?;
            if node.status == NStatus::Branched {
                need(cs.iter().all(Option::is_some))?
            }
            if let [Some(f), Some(t)] = cs {
                need(t < f)?
            }
            if building {
                out.partial += 1
            }
            out.nodes += 1;
        }
    }
    Ok(())
}
/// Successful result means lineage and the listed committed basis identities
/// only. Partial builders are retained/skipped, and no complete search is inferred.
pub fn verify(
    root: &Value,
    variables: u32,
    limits: Limits,
    deadline: Instant,
    owner: &mut impl wire::Admission,
) -> Audit {
    let mut out = Audit {
        result: Ok(()),
        charge: Charge::default(),
        partitions: 0,
        nodes: 0,
        partial: 0,
        rows: Vec::new(),
        original_descent_verified: false,
        search_complete: false,
    };
    let mut m = Meter {
        owner,
        limits,
        deadline,
        charge: Charge::default(),
        nodes: 0,
        rows: 0,
    };
    out.result = (|| {
        m.pay(1, 0)?;
        if variables > limits.variables {
            return Err(Failure::Cap);
        }
        let g = polys(field(root, "normalized", &mut m)?, variables, &mut m)?;
        let c = field(root, "continuation", &mut m)?;
        if matches!(c, Value::Null) {
            return Err(Failure::Unavailable);
        }
        let ps = partitions(c, variables, &mut m)?;
        lineage(&g, &ps, variables, &mut m, &mut out)?;
        out.rows = m.vec(m.rows, limits.rows)?;
        for (pi, p) in ps.iter().enumerate() {
            let Some(search) = &p.search else { continue };
            for (ni, node) in search.nodes.iter().enumerate() {
                if node.status == NStatus::Building {
                    continue;
                }
                for (ri, row) in node.basis.iter().enumerate() {
                    m.pay(1, 0)?;
                    let mut nested = Nested {
                        meter: &mut m,
                        failure: None,
                    };
                    let certificate = bridge::certify(
                        variables,
                        &node.equations,
                        row,
                        limits.certificate,
                        limits.checker,
                        deadline,
                        &mut nested,
                    );
                    let failure = nested.failure;
                    let result = certificate.result;
                    out.rows.push(RowAudit {
                        partition: pi,
                        node: ni,
                        row: ri,
                        certificate,
                    });
                    if let Some(e) = failure {
                        return Err(e);
                    }
                    if let Err(e) = result {
                        return Err(Failure::Certificate(e));
                    }
                }
            }
        }
        m.pay(1, 0)
    })();
    out.charge = m.charge;
    out
}
