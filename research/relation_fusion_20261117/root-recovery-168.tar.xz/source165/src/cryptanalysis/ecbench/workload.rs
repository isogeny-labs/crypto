//! Workloads: one curve, one prime-order subgroup, one generator, one
//! target.
//!
//! A workload is the unit every comparison is paired on.  It is built
//! from a *construction* (a rule the repository already uses to make a
//! curve) rather than from pasted coordinates, so a run can be replayed
//! from its record on any host, and its identity is computed from what
//! was built — the ICV1 model, the subgroup, the generator and the target
//! point — so two constructions that land on the same curve and point
//! are the same workload.
//!
//! The planted logarithm is derived from the workload seed by SHA-256
//! (`canonical::derive_u64`), never from an RNG stream, and no solver is
//! handed it: the runner verifies the solver's answer afterwards.

use num_traits::ToPrimitive;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::sync::OnceLock;

use crate::binary_ecc::IrreduciblePoly;
use crate::cryptanalysis::ec_index_calculus_curves::CurveKind;
use crate::cryptanalysis::ecbench::canonical::{bare_id, derive_biguint, derive_u128, derive_u64};
use crate::cryptanalysis::ecbench::conductor_gap::{self, GapLevel};
use crate::cryptanalysis::ecbench::exact_scalar::ExactScalar;
use crate::cryptanalysis::ecbench::ext::ExtInstance;
use crate::cryptanalysis::ecbench::fp4::Fp4Instance;
use crate::cryptanalysis::ecbench::ghs_cover::GhsInstance;
use crate::cryptanalysis::ecbench::hec::{thread_scalar, HecInstance};
use crate::cryptanalysis::ecbench::hyper::HyperInstance;
use crate::cryptanalysis::ecbench::jacobian::Genus2Instance;
use crate::cryptanalysis::ecbench::plane_quartic::QuarticInstance;
use crate::cryptanalysis::ecbench_large_prime::binary_explicit_instance;
use crate::cryptanalysis::gaudry_quartic::Pt4;
use crate::cryptanalysis::gaudry_quartic_bin::{find_bin_curve, BinCurve, PtB, TowerBasis};
use crate::cryptanalysis::gaudry_quartic_d4::{find_d4_curve, pack_e4, unpack_e4, D4Curve};
use crate::cryptanalysis::ic_boundary::{
    find_prime_order_curve, koblitz_instance, random_binary_instance, roster_prime_instance,
    BinaryGroup, BinaryInstance, CountedGroup, CubicClasses, GroupOps, PrimeCurve, PrimeInstance,
    PrimePoint, PrimeRepresentation, QuarticClasses,
};
use crate::cryptanalysis::isogeny_eval::counted_fp::is_prime_u64;
use crate::cryptanalysis::koblitz_big::{BigKoblitz, BigStrongRho, BIG_DEGREES, W192};
use crate::cryptanalysis::koblitz_strong_rho::{RawPointG, RhoScalar, WideStrongRho};
use crate::cryptanalysis::koblitz_wide::WideKoblitz;
use crate::cryptanalysis::prime_orbit_index_calculus::{
    generate_instance, Coefficient, ScaledShape,
};

/// How to build the curve.  Each variant is a constructor the repository
/// already has, so the registry's `generator_call` names the same curve.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
pub enum CurveSpec {
    /// `ic_boundary::find_prime_order_curve(bits, seed)`: prime order,
    /// cofactor 1, `8 ≤ bits ≤ 32`.
    PrimeSearch { bits: u32, seed: u64 },
    /// `prime_orbit_index_calculus::generate_instance`: a certified
    /// scaled curve retaining the requested shape (`generic`,
    /// `generic_a_minus_3`, `j0`, `j0_b7`, or `j1728`).
    /// The runner converts it to an explicit prime curve before starting
    /// a measured child, so curve search is never in the timed region.
    PrimeOrbitShape { shape: String, bits: u32, seed: u64 },
    /// `ic_boundary::roster_prime_instance(bits)`: the bench roster.
    PrimeRoster { bits: u32 },
    /// `ic_boundary::koblitz_instance(a, n)`: `K_a / F_{2^n}`, `n ≤ 62`;
    /// for `64 ≤ n ≤ 127`, `koblitz_wide::WideKoblitz` over the registry's
    /// modulus for that `K_a` (the m = 83 gate curve of AGENTS.md §8a);
    /// for `128 ≤ n ≤ 191`, `koblitz_big::BigKoblitz` over the registry's
    /// modulus (ECC2K-130's field at `n = 131`, K-163 at `n = 163`).
    Koblitz { a: u8, n: u32 },
    /// `ic_boundary::random_binary_instance(n, seed, max_cofactor)`.
    BinaryRandom {
        n: u32,
        seed: u64,
        max_cofactor: u64,
    },
    /// `conductor_gap::{crater, floor}(params(ell, t), seed)`: a curve of
    /// the CM pair over `GF((t² + 19ℓ²)/4)` with prime order `q + 1 − t`,
    /// at the crater (endomorphism conductor 1) or the floor (conductor
    /// `ℓ`), certified from the Frobenius discriminant `−19ℓ²` alone.
    /// `seed` drives the floor search and is ignored at the crater.
    ConductorGap {
        ell: u64,
        t: u64,
        level: GapLevel,
        seed: u64,
    },
    /// A prime curve given outright: `y² = x³ + ax + b` over `F_p`, the
    /// group order, the prime subgroup order `r` and a generator of it.
    /// Checked on build (non-singular, generator on the curve, `[r]G =
    /// O`, `r · cofactor = #E`); the order itself is trusted, as the
    /// registry's recorded orders are.  The runner hands measured
    /// children this form so a child never repeats a curve search.
    PrimeExplicit {
        p: u64,
        a: u64,
        b: u64,
        group_order: u64,
        r: u64,
        gx: u64,
        gy: u64,
    },
    /// An EFD model/chart: the engine builds the short-Weierstrass curve
    /// through the EFD bridge and decodes the generator in `chart`.
    Efd {
        model: String,
        chart: String,
        p: u64,
        params: std::collections::BTreeMap<String, u64>,
        r: u64,
        cofactor: u64,
        generator: Vec<u64>,
        lift: u32,
    },
    /// An externally supplied public point with no logarithm in the fixture,
    /// retained verbatim in measured child inputs. Restricted to certified
    /// cofactor-one prime-order regression cohorts.
    PrimePublicFixture {
        p: u64,
        a: u64,
        b: u64,
        group_order: u64,
        r: u64,
        gx: u64,
        gy: u64,
        qx: u64,
        qy: u64,
    },
    /// `gaudry_quartic_d4::find_d4_curve(p, seed, max_cofactor)`: a curve
    /// over `F_{p⁴} = F_p[t]/(t⁴ − c)` with a rational 2-torsion point
    /// `T = (x₀, 0)`, `f'(x₀)` a square in `F_p`, `#E = h·r`, `r` prime,
    /// `h ≤ max_cofactor` (even), `p` a prime `≡ 1 (mod 4)` up to 1021.  A point is
    /// written as two packed words `x₀ + p x₁ + p² x₂ + p³ x₃`.
    Fp4Torsion {
        p: u64,
        seed: u64,
        max_cofactor: u64,
    },
    /// `gaudry_quartic_bin::find_bin_curve(m, seed, max_cofactor)`: an
    /// ordinary curve `y² + xy = x³ + ax² + b` over the tower
    /// `F_{q⁴} = F_q[z]/(quartic)`, `q = 2^m`, `4 ≤ m ≤ 15`, `b ∉ F_{q²}`,
    /// `#E = h·r`, `r` prime, `h ≤ max_cofactor` (even: `T = (0, √b)`).  A
    /// point is written as two packed words (coefficient `i` of the tower
    /// basis in bits `[im, (i + 1)m)`).
    F2m4Torsion {
        m: u32,
        seed: u64,
        max_cofactor: u64,
    },
    /// `ecbench::xline_bin::find_bin_curve_a0(m, seed, max_cofactor)`: the
    /// curve `y² + xy = x³ + b` (`a = 0`, so `Tr(a) = 0`) over the same tower
    /// `F_{q⁴}`, `q = 2^m`, `4 ≤ m ≤ 15`, `b ∉ F_{q²}`, `#E = h·r`, `r`
    /// prime, `h ≤ max_cofactor`: the C1 end-to-end study's family
    /// (`research/c1_end_to_end_solve_20261107`), on which the twisted
    /// all-lift line exists.  Built as an `f2m4_torsion` instance, so every
    /// method that runs there runs here.
    F2m4A0 {
        m: u32,
        seed: u64,
        max_cofactor: u64,
    },
    /// A binary curve given outright in polynomial basis. `modulus` is
    /// the complete integer bitmask, including its degree-`n` leading bit.
    /// The constructor checks irreducibility, subgroup divisibility,
    /// generator membership, and `[r]G = O`.
    BinaryExplicit {
        n: u32,
        modulus: u64,
        a: u64,
        b: u64,
        group_order: u64,
        r: u64,
        gx: u64,
        gy: u64,
    },
    /// `ecbench::fp4::Fp4Instance::build(p, seed)`: a curve over
    /// `F_{p⁴}` with rational 2-torsion `T = (x₀, 0)`, `f'(x₀) = c²`
    /// (`quartic_folds::generate_translation_instance(p, seed, 16)`),
    /// `p ≡ 1 (mod 4)`, `p < 2^15`.  Unregistered: ICV1 has no
    /// extension-field form.
    Fp4Translation { p: u64, seed: u64 },
    /// Frozen finite-extension fixture for the three-leads study. The source
    /// is a short odd curve or normalized ordinary binary curve, never a
    /// Jacobian masquerading as an elliptic input.
    ThreeLeads {
        p: u64,
        n: u32,
        modulus: u64,
        a: u64,
        b: u64,
        group_order: u64,
        r: u64,
        gx: u64,
        gy: u64,
        family: String,
        parameter: u64,
    },
    /// `gls_fp2::generate_gls_instance(p_bits, seed, max_cofactor)`: the
    /// GLS twist over `F_{p²} = F_p[s]/(s² − ν)` of a curve over `F_p`,
    /// `p` of `p_bits ≤ 24` bits, with the verified `ψ` (`ψ² = −1` on the
    /// subgroup, `A = 4`).  A point is two packed words `c₀ + c₁ p`.
    GlsFp2 {
        p_bits: u32,
        seed: u64,
        max_cofactor: u64,
    },
    /// `subfield_fp3::generate_subfield_instance(p_bits, seed, false,
    /// max_cofactor_ratio)`: a curve over `F_p` (`j ≠ 0`) on its group
    /// over `F_{p³} = F_p[s]/(s³ − ν)`, `p ≡ 1 (mod 3)` of `p_bits ≤ 20`
    /// bits, the prime subgroup outside `E(F_p)`, with the verified
    /// Frobenius of order 3 on it (`A = 6`).  A point is two packed words
    /// `c₀ + c₁ p + c₂ p²`.
    SubfieldFp3 {
        p_bits: u32,
        seed: u64,
        max_cofactor_ratio: u64,
    },
    /// `jacobian::Genus2Instance::search(p_bits, seed, max_cofactor)`: the
    /// Jacobian of an imaginary genus-2 curve `y² = f(x)`, `deg f = 5`,
    /// over `F_p` (`5 ≤ p_bits ≤ 16`), `#J(F_p) = h·r`.  A class is
    /// `[deg u·p² + u₁p + u₀, v₁p + v₀]`.  Unregistered: ICV1 names
    /// elliptic curves only, so the slug is `jcv1-g2-…`.
    Genus2Search {
        p_bits: u32,
        seed: u64,
        max_cofactor: u64,
    },
    /// The same Jacobian given outright (what a measured child rebuilds):
    /// `f` lowest degree first, `f[5] = 1`; the order is trusted, `G` is
    /// checked to have order `r`.
    Genus2Explicit {
        p: u64,
        f: [u64; 6],
        group_order: u64,
        r: u64,
        gx: u64,
        gy: u64,
    },
    /// `plane_quartic::QuarticInstance::search(p_bits, seed, max_cofactor)`:
    /// the Jacobian of a smooth plane quartic (a non-hyperelliptic curve of
    /// genus 3) over `F_p` (`5 ≤ p_bits ≤ 11`, `p ≥ 29`), `#J(F_p) = h·r`.
    /// A class is two 120-digit hex strings (a canonical 3×10 echelon form).
    PlaneQuarticSearch {
        p_bits: u32,
        seed: u64,
        max_cofactor: u64,
    },
    /// The same Jacobian given outright: the 15 coefficients of `F` in the
    /// order `X⁴, X³Y, X³Z, X²Y², …, Z⁴` (`X`-degree descending, then
    /// `Y`), `X⁴` coefficient 1.
    PlaneQuarticExplicit {
        p: u64,
        f: [u64; 15],
        group_order: u64,
        r: u64,
        generator: [String; 2],
    },
    /// `ghs_cover::GhsInstance::search(p, seed)`: `E : y² = x(x − α)(x −
    /// σα)` over `F_{q³}`, `q = p²`, `α ∉ F_q`, `#E = 4ℓ` with `ℓ` prime,
    /// whose GHS cover is a genus-3 hyperelliptic curve over `F_q`
    /// (`jv_cover::generate_spec`; prime `11 ≤ p ≤ 1,600`, `p ≠ 3`).  A
    /// coordinate is its six base-`p` digits packed in one word.  Its own
    /// `ghs-…` slug: the tower is not one `F_p`-modulus, so no ICV1 name.
    GhsFp6Search { p: u64, seed: u64 },
    /// The same curve given outright: `α`'s six digits (`F_q` coefficient
    /// of `1, θ, θ²`, each `c₀ + c₁t`), `ℓ` trusted, `G` checked.
    GhsFp6Explicit {
        p: u64,
        alpha: [u64; 6],
        l: u64,
        generator: [String; 2],
    },
    /// `hyperelliptic_ic_bench::thread_instance(p, genus)`: the
    /// hyperelliptic thread's curve `y² = f(x)`, `deg f = 2g + 1`, over
    /// `F_p` (`p < 256`, `g ∈ {2, 3, 4}`), its generator `D₁` of prime
    /// order `r`, and `#J` from point counts over `F_{p^k}`, `k < g`, and
    /// an exponent test (`ecbench::hyper`).  A divisor is two packed
    /// words.  Unregistered: ICV1 has no hyperelliptic form.
    HyperellipticThread { p: u64, genus: u32 },
    /// A hyperelliptic Jacobian given outright: `f` (lowest degree first,
    /// `deg f = 2g + 1`), `#J`, the prime `r` and a generator `(gu, gv)`
    /// (`gu` with its leading 1, both lowest degree first).  Checked on
    /// build (squarefree `f`, `G` reduced, `[r]G = 0`, `r | #J`, `#J` in
    /// the Hasse–Weil interval and killing eight random divisors); the
    /// order is otherwise trusted.  What measured children rebuild.
    HyperellipticExplicit {
        p: u64,
        genus: u32,
        f: Vec<u64>,
        group_order: u64,
        r: u64,
        gu: Vec<u64>,
        gv: Vec<u64>,
    },
    /// `hyperelliptic_ic_bench::thread_instance(p, genus)`: the
    /// hyperelliptic thread's instance rule (`ecbench::hec`), the Jacobian
    /// of `y² = f(x)` over `F_p` for the first `c` with a prime subgroup
    /// above 1000, genus 2 to 4, `p < 2^15`.  A reduced divisor is written
    /// as two packed words.  `#Jac` is not computed, so only planted
    /// targets exist.  Unregistered: ICV1 has no Jacobian form.
    HecThread { p: u64, genus: u32 },
}

impl CurveSpec {
    /// Preserve an external public point when making a measured-child input.
    pub fn for_child(&self, inst: &Instance) -> CurveSpec {
        if matches!(self, Self::PrimePublicFixture { .. }) {
            self.clone()
        } else {
            Self::explicit(inst).unwrap_or_else(|| self.clone())
        }
    }
    /// Build the instance, or say why it cannot be built.
    pub fn build(&self) -> Result<Instance, String> {
        match *self {
            CurveSpec::ThreeLeads {
                p,
                n,
                modulus,
                a,
                b,
                group_order,
                r,
                gx,
                gy,
                ref family,
                parameter,
            } => {
                if r < 3 || n == 0 || n > 30 || (p != 2 && n > 2) {
                    return Err("invalid three-leads field or subgroup parameters".into());
                }
                let f = crate::cryptanalysis::three_leads::Field::new(p, n as usize, modulus);
                let c = if p == 2 { [b, 0, a, 1] } else { [b, a, 0, 1] };
                let i = crate::cryptanalysis::three_leads::StudyInstance {
                    curve: crate::cryptanalysis::three_leads::Elliptic {
                        f,
                        c,
                        binary: p == 2,
                    },
                    order: group_order,
                    r,
                    h: group_order / r,
                    generator: crate::cryptanalysis::three_leads::Point::affine(gx, gy),
                    family: family.clone(),
                    parameter,
                    evidence: json!({"source":"frozen three-leads fixture manifest"}),
                };
                i.validate()?;
                Ok(Instance::ThreeLeads(Box::new(i)))
            }
            CurveSpec::PrimePublicFixture {
                p,
                a,
                b,
                group_order,
                r,
                gx,
                gy,
                qx,
                qy,
            } => {
                if r != group_order {
                    return Err("public fixture requires cofactor one".into());
                }
                if p < 5
                    || !crate::prime_hyperelliptic::fp2::is_prime_u64(p)
                    || !crate::prime_hyperelliptic::fp2::is_prime_u64(r)
                {
                    return Err(
                        "public fixture requires a prime field and prime group order".into(),
                    );
                }
                let trace = p as i128 + 1 - r as i128;
                if trace.unsigned_abs().pow(2) > 4 * p as u128
                    || (r as u128).pow(2) <= 16 * p as u128
                {
                    return Err(
                        "public fixture order needs a Hasse-unique prime-order witness".into(),
                    );
                }
                let a2 = (a as u128 * a as u128) % p as u128;
                let a3 = (a2 * a as u128) % p as u128;
                let b2 = (b as u128 * b as u128) % p as u128;
                if (4 * a3 + 27 * b2).is_multiple_of(p as u128) || gx >= p || gy >= p {
                    return Err(
                        "public fixture requires a nonsingular curve and canonical generator"
                            .into(),
                    );
                }
                let inst = CurveSpec::PrimeExplicit {
                    p,
                    a,
                    b,
                    group_order,
                    r,
                    gx,
                    gy,
                }
                .build()?;
                let Instance::Prime(ref i) = inst else {
                    unreachable!()
                };
                let q = PrimePoint::affine(qx, qy);
                if qx >= p
                    || qy >= p
                    || !i.curve.is_on_curve(q)
                    || !i.curve.mul(&mut GroupOps::default(), q, r).infinity
                {
                    return Err("fixture target is not in the prime subgroup".into());
                }
                Ok(inst)
            }
            CurveSpec::PrimeSearch { bits, seed } => {
                if !(8..=32).contains(&bits) {
                    return Err(format!("prime_search takes 8 ≤ bits ≤ 32, not {bits}"));
                }
                Ok(Instance::Prime(find_prime_order_curve(bits, seed)))
            }
            CurveSpec::PrimeOrbitShape {
                ref shape,
                bits,
                seed,
            } => {
                let scaled = match shape.as_str() {
                    "generic" => ScaledShape::of_kind(CurveKind::Generic),
                    "generic_a_minus_3" => ScaledShape {
                        kind: CurveKind::Generic,
                        a: Coefficient::Fixed(-3),
                        b: Coefficient::Random,
                        max_cofactor: 1,
                    },
                    "j0" => ScaledShape::of_kind(CurveKind::J0),
                    "j0_b7" => ScaledShape {
                        kind: CurveKind::J0,
                        a: Coefficient::Fixed(0),
                        b: Coefficient::Fixed(7),
                        max_cofactor: 1,
                    },
                    "j1728" => ScaledShape::of_kind(CurveKind::J1728),
                    other => {
                        return Err(format!(
                            "prime_orbit_shape is generic, generic_a_minus_3, j0, j0_b7 or j1728, not `{other}`"
                        ))
                    }
                };
                let generated = generate_instance(scaled, bits, Some(1), seed)?;
                let params = generated.curve.params("ecbench-prime-orbit-shape");
                let word = |name: &str, value: &num_bigint::BigUint| {
                    value
                        .to_u64()
                        .ok_or_else(|| format!("generated {name} does not fit a word"))
                };
                let curve = PrimeCurve {
                    p: word("prime", &params.p)?,
                    a: word("a", &params.a)?,
                    b: word("b", &params.b)?,
                };
                let mut instance = PrimeInstance {
                    name: String::new(),
                    curve,
                    group_order: generated.certificate.group_order,
                    r: generated.certificate.subgroup_order,
                    cofactor: generated.certificate.cofactor,
                    generator: (
                        word("generator x", &params.gx)?,
                        word("generator y", &params.gy)?,
                    ),

                    representation: None,
                };
                instance.name = instance.curve_id().slug;
                Ok(Instance::Prime(instance))
            }
            CurveSpec::PrimeRoster { bits } => roster_prime_instance(bits)
                .map(Instance::Prime)
                .ok_or_else(|| format!("the bench roster has no {bits}-bit curve")),
            CurveSpec::Koblitz { a, n } if BIG_DEGREES.contains(&n) && a <= 1 => {
                let irr = registry_koblitz_modulus(a, n).ok_or_else(|| {
                    format!("K_{a} over F_2^{n} is not in docs/curves/registry.json; register it first (AGENTS.md §11)")
                })?;
                let kc = BigKoblitz::new(a, &irr)?;
                let rho = kc.strong_rho();
                Ok(Instance::Big(Box::new(BigInstance { kc, rho })))
            }
            CurveSpec::Koblitz { a, n } if (64..=127).contains(&n) && a <= 1 => {
                let irr = registry_koblitz_modulus(a, n).ok_or_else(|| {
                    format!("K_{a} over F_2^{n} is not in docs/curves/registry.json; register it first (AGENTS.md §11)")
                })?;
                let kc = WideKoblitz::new(a, &irr)?;
                let rho = kc.strong_rho();
                Ok(Instance::Wide(Box::new(WideInstance { kc, rho })))
            }
            CurveSpec::Koblitz { a, n } => {
                if a > 1 || !(3..=62).contains(&n) {
                    return Err(format!(
                        "koblitz takes a ∈ {{0,1}} and 3 ≤ n ≤ 62, 64 ≤ n ≤ 127 (wide) or 128 ≤ n ≤ 191 (big), not a={a} n={n}"
                    ));
                }
                koblitz_instance(a, n).map(|i| Instance::Binary(Box::new(i))).ok_or_else(|| {
                    format!("K_{a} over F_2^{n} has no usable prime-order subgroup in the repository's constructor")
                })
            }
            CurveSpec::BinaryRandom {
                n,
                seed,
                max_cofactor,
            } => random_binary_instance(n, seed, max_cofactor)
                .map(|i| Instance::Binary(Box::new(i)))
                .ok_or_else(|| format!("no binary curve found for n={n} seed={seed}")),
            CurveSpec::ConductorGap {
                ell,
                t,
                level,
                seed,
            } => {
                let p = conductor_gap::params(ell, t)?;
                match level {
                    GapLevel::Crater => conductor_gap::crater(p),
                    GapLevel::Floor => conductor_gap::floor(p, seed),
                }
                .map(Instance::Prime)
            }
            CurveSpec::Efd {
                ref model,
                ref chart,
                p,
                ref params,
                r,
                cofactor,
                ref generator,
                lift,
            } => PrimeInstance::from_efd(model, chart, p, params, r, cofactor, generator, lift)
                .map(Instance::Prime),
            CurveSpec::PrimeExplicit {
                p,
                a,
                b,
                group_order,
                r,
                gx,
                gy,
            } => {
                if !(5..1 << 62).contains(&p) || a >= p || b >= p {
                    return Err("prime_explicit takes 5 ≤ p < 2^62 and a, b < p".into());
                }
                if r < 2 || group_order % r != 0 {
                    return Err(format!("r = {r} does not divide #E = {group_order}"));
                }
                let curve = PrimeCurve { p, a, b };
                let g = PrimePoint::affine(gx, gy);
                if !curve.is_on_curve(g) {
                    return Err("the generator is not on the curve".into());
                }
                let mut scratch = GroupOps::default();
                if !curve.mul(&mut scratch, g, r).infinity {
                    return Err("[r]G is not the identity".into());
                }
                let mut inst = PrimeInstance {
                    name: String::new(),
                    curve,
                    group_order,
                    r,
                    cofactor: group_order / r,
                    generator: (gx, gy),

                    representation: None,
                };
                inst.name = inst.curve_id().slug;
                Ok(Instance::Prime(inst))
            }
            CurveSpec::BinaryExplicit {
                n,
                modulus,
                a,
                b,
                group_order,
                r,
                gx,
                gy,
            } => binary_explicit_instance(n, modulus, a, b, group_order, r, gx, gy)
                .map(|i| Instance::Binary(Box::new(i))),
            CurveSpec::Fp4Torsion {
                p,
                seed,
                max_cofactor,
            } => {
                // The order search walks the Hasse window of 4p² + 1 points.
                if p % 4 != 1 || !(5..=1021).contains(&p) || !is_prime_u64(p) {
                    return Err(format!(
                        "fp4_torsion takes a prime p ≡ 1 (mod 4) from 5 to 1021, not {p}"
                    ));
                }
                find_d4_curve(p, seed, max_cofactor).map(|c| Instance::Fp4Torsion(Box::new(c)))
            }
            CurveSpec::F2m4Torsion {
                m,
                seed,
                max_cofactor,
            } => {
                // Points pack into 4m ≤ 80 bits (one word while m ≤ 15;
                // past that the orders are u128 and the methods go
                // through `ic_wide`); the order search takes ≈ 2q baby
                // and giant steps per point.
                if !(4..=20).contains(&m) {
                    return Err(format!("f2m4_torsion takes m from 4 to 20, not {m}"));
                }
                find_bin_curve(m, seed, max_cofactor).map(|c| Instance::F2m4(Box::new(c)))
            }
            CurveSpec::F2m4A0 {
                m,
                seed,
                max_cofactor,
            } => crate::cryptanalysis::ecbench::xline_bin::find_bin_curve_a0(m, seed, max_cofactor)
                .map(|c| Instance::F2m4(Box::new(c))),
            CurveSpec::Fp4Translation { p, seed } => {
                Fp4Instance::build(p, seed).map(|i| Instance::Fp4(Box::new(i)))
            }
            CurveSpec::GlsFp2 {
                p_bits,
                seed,
                max_cofactor,
            } => ExtInstance::build_gls(p_bits, seed, max_cofactor)
                .map(|i| Instance::Ext(Box::new(i))),
            CurveSpec::SubfieldFp3 {
                p_bits,
                seed,
                max_cofactor_ratio,
            } => ExtInstance::build_subfield(p_bits, seed, max_cofactor_ratio)
                .map(|i| Instance::Ext(Box::new(i))),
            CurveSpec::Genus2Search {
                p_bits,
                seed,
                max_cofactor,
            } => Genus2Instance::search(p_bits, seed, max_cofactor)
                .map(|i| Instance::Genus2(Box::new(i))),
            CurveSpec::Genus2Explicit {
                p,
                f,
                group_order,
                r,
                gx,
                gy,
            } => Genus2Instance::explicit(p, f, group_order, r, [gx, gy])
                .map(|i| Instance::Genus2(Box::new(i))),
            CurveSpec::PlaneQuarticSearch {
                p_bits,
                seed,
                max_cofactor,
            } => QuarticInstance::search(p_bits, seed, max_cofactor)
                .map(|i| Instance::Quartic(Box::new(i))),
            CurveSpec::PlaneQuarticExplicit {
                p,
                f,
                group_order,
                r,
                ref generator,
            } => QuarticInstance::explicit(p, f, group_order, r, generator)
                .map(|i| Instance::Quartic(Box::new(i))),
            CurveSpec::GhsFp6Search { p, seed } => {
                GhsInstance::search(p, seed).map(|i| Instance::Ghs(Box::new(i)))
            }
            CurveSpec::GhsFp6Explicit {
                p,
                alpha,
                l,
                ref generator,
            } => GhsInstance::explicit(p, alpha, l, generator).map(|i| Instance::Ghs(Box::new(i))),
            CurveSpec::HyperellipticThread { p, genus } => {
                HyperInstance::build_thread(p, genus).map(|i| Instance::Hyper(Box::new(i)))
            }
            CurveSpec::HyperellipticExplicit {
                p,
                genus,
                ref f,
                group_order,
                r,
                ref gu,
                ref gv,
            } => HyperInstance::build_explicit(p, genus, f, group_order, r, gu, gv)
                .map(|i| Instance::Hyper(Box::new(i))),
            CurveSpec::HecThread { p, genus } => {
                HecInstance::build(p, genus).map(|i| Instance::Hec(Box::new(i)))
            }
        }
    }

    /// The same curve as an explicit form, when it has one: what a
    /// measured child rebuilds instead of repeating a search.
    pub fn explicit(inst: &Instance) -> Option<CurveSpec> {
        match inst {
            Instance::Prime(i) => Some(CurveSpec::PrimeExplicit {
                p: i.curve.p,
                a: i.curve.a,
                b: i.curve.b,
                group_order: i.group_order,
                r: i.r,
                gx: i.generator.0,
                gy: i.generator.1,
            }),
            Instance::Binary(i) if i.koblitz.is_none() => {
                let modulus = i
                    .irreducible
                    .low_terms
                    .iter()
                    .fold(1u64 << i.n, |v, &term| v | (1u64 << term));
                Some(CurveSpec::BinaryExplicit {
                    n: i.n,
                    modulus,
                    a: i.a,
                    b: i.b,
                    group_order: i.group_order,
                    r: i.r,
                    gx: i.generator.x,
                    gy: i.generator.y,
                })
            }
            // Preserve the original Koblitz constructor: it carries the
            // certified Frobenius action and endomorphism identity that a
            // generic explicit binary instance intentionally does not claim.
            // The search is the constructor (cheap and deterministic).
            Instance::Genus2(i) => {
                let (gx, gy) = super::jacobian::encode_g2(i.p(), &i.generator);
                Some(CurveSpec::Genus2Explicit {
                    p: i.p(),
                    f: i.curve.f(),
                    group_order: i.group_order,
                    r: i.r,
                    gx,
                    gy,
                })
            }
            Instance::Quartic(i) => Some(CurveSpec::PlaneQuarticExplicit {
                p: i.jac.p,
                f: i.jac.f,
                group_order: i.group_order,
                r: i.r,
                generator: i.encode(&i.generator),
            }),
            Instance::Ghs(i) => Some(CurveSpec::GhsFp6Explicit {
                p: i.p,
                alpha: i.alpha_digits(),
                l: i.l,
                generator: i.encode(&i.generator),
            }),
            Instance::Binary(_)
            | Instance::Wide(_)
            | Instance::Big(_)
            | Instance::Fp4(_)
            | Instance::Fp4Torsion(_)
            | Instance::F2m4(_)
            | Instance::ThreeLeads(_)
            | Instance::Ext(_)
            | Instance::Hec(_) => None,
            // The thread rule and the order's point counts are the slow
            // part; a child rebuilds from the explicit model.
            Instance::Hyper(i) => {
                let (gu, gv) = i.generator_coeffs();
                Some(CurveSpec::HyperellipticExplicit {
                    p: i.p,
                    genus: i.genus,
                    f: i.f.clone(),
                    group_order: i.group_order,
                    r: i.r,
                    gu,
                    gv,
                })
            }
        }
    }

    /// The constructor call, in the registry's `generator_call` form.
    pub fn call(&self) -> String {
        match *self {
            CurveSpec::PrimeSearch { bits, seed } => {
                format!("find_prime_order_curve({bits}, {seed})")
            }
            CurveSpec::Efd {
                ref model,
                ref chart,
                p,
                ..
            } => format!("PrimeInstance::from_efd({model}, {chart}, {p}, ...)"),
            CurveSpec::PrimeOrbitShape {
                ref shape,
                bits,
                seed,
            } => format!(
                "prime_orbit_index_calculus::generate_instance({shape}, {bits}, {seed})"
            ),
            CurveSpec::PrimeRoster { bits } => format!("roster_prime_instance({bits})"),
            CurveSpec::Koblitz { a, n } if n >= 128 => {
                format!("BigKoblitz::new({a}, registry modulus for n = {n})")
            }
            CurveSpec::Koblitz { a, n } if n >= 64 => {
                format!("WideKoblitz::new({a}, registry modulus for n = {n})")
            }
            CurveSpec::Koblitz { a, n } => format!("KoblitzCurve::new({a}, {n})"),
            CurveSpec::BinaryRandom {
                n,
                seed,
                max_cofactor,
            } => format!("random_binary_instance({n}, {seed}, {max_cofactor})"),
            CurveSpec::ConductorGap {
                ell,
                t,
                level,
                seed,
            } => match level {
                GapLevel::Crater => format!("conductor_gap::crater(params({ell}, {t}))"),
                GapLevel::Floor => format!("conductor_gap::floor(params({ell}, {t}), {seed})"),
            },
            CurveSpec::PrimeExplicit { p, a, b, .. }
            | CurveSpec::PrimePublicFixture { p, a, b, .. } => {
                format!("PrimeCurve {{ p: {p}, a: {a}, b: {b} }} (explicit)")
            }
            CurveSpec::BinaryExplicit {
                n, modulus, a, b, ..
            } => format!("binary_explicit_instance({n}, 0x{modulus:x}, 0x{a:x}, 0x{b:x}, ...)"),
            CurveSpec::Fp4Torsion {
                p,
                seed,
                max_cofactor,
            } => format!("gaudry_quartic_d4::find_d4_curve({p}, {seed}, {max_cofactor})"),
            CurveSpec::F2m4Torsion {
                m,
                seed,
                max_cofactor,
            } => format!("gaudry_quartic_bin::find_bin_curve({m}, {seed}, {max_cofactor})"),
            CurveSpec::F2m4A0 {
                m,
                seed,
                max_cofactor,
            } => format!("ecbench::xline_bin::find_bin_curve_a0({m}, {seed}, {max_cofactor})"),
            CurveSpec::Fp4Translation { p, seed } => {
                format!("quartic_folds::generate_translation_instance({p}, {seed}, 16)")
            }
            CurveSpec::ThreeLeads { p, n, a, b, ref family, parameter, .. } => format!(
                "three_leads_explicit(p={p},n={n},a={a},b={b},family={family},parameter={parameter})"
            ),
            CurveSpec::GlsFp2 {
                p_bits,
                seed,
                max_cofactor,
            } => format!("gls_fp2::generate_gls_instance({p_bits}, {seed}, {max_cofactor})"),
            CurveSpec::SubfieldFp3 {
                p_bits,
                seed,
                max_cofactor_ratio,
            } => format!(
                "subfield_fp3::generate_subfield_instance({p_bits}, {seed}, false, {max_cofactor_ratio})"
            ),
            CurveSpec::Genus2Search {
                p_bits,
                seed,
                max_cofactor,
            } => format!("jacobian::Genus2Instance::search({p_bits}, {seed}, {max_cofactor})"),
            CurveSpec::Genus2Explicit { p, f, .. } => {
                format!("Genus2Curve::new({p}, {f:?}) (explicit)")
            }
            CurveSpec::PlaneQuarticSearch {
                p_bits,
                seed,
                max_cofactor,
            } => format!("plane_quartic::QuarticInstance::search({p_bits}, {seed}, {max_cofactor})"),
            CurveSpec::PlaneQuarticExplicit { p, f, .. } => {
                format!("QuarticJacobian::new({p}, {f:?}) (explicit)")
            }
            CurveSpec::GhsFp6Search { p, seed } => format!("ghs_cover::GhsInstance::search({p}, {seed})"),
            CurveSpec::GhsFp6Explicit { p, alpha, .. } => {
                format!("GHS curve over F_{{{p}^6}}, α = {alpha:?} (explicit)")
            }
            CurveSpec::HyperellipticThread { p, genus } => {
                format!("hyperelliptic_ic_bench::thread_instance({p}, {genus})")
            }
            CurveSpec::HyperellipticExplicit {
                p, genus, ref f, ..
            } => format!("HCurve {{ p: {p}, genus: {genus}, f: {f:?} }} (explicit)"),
            CurveSpec::HecThread { p, genus } => {
                format!("hyperelliptic_ic_bench::thread_instance({p}, {genus})")
            }
        }
    }
}

/// A built curve instance.
pub enum Instance {
    ThreeLeads(Box<crate::cryptanalysis::three_leads::StudyInstance>),
    Prime(PrimeInstance),
    /// A curve over `F_{p⁴}` with rational 2-torsion (`fp4_torsion`).
    Fp4Torsion(Box<D4Curve>),
    /// A curve over the tower `F_{(2^m)⁴}` (`f2m4_torsion`).
    F2m4(Box<BinCurve>),
    Binary(Box<BinaryInstance>),
    /// A Koblitz curve past one word (`64 ≤ n ≤ 127`).
    Wide(Box<WideInstance>),
    /// A Koblitz curve past two words (`128 ≤ n ≤ 191`), whose subgroup
    /// order is past `2^128`.
    Big(Box<BigInstance>),
    /// A curve over `F_{p⁴}` (`ecbench::fp4`); a point is one 64-bit word
    /// per coordinate, four 16-bit limbs.
    Fp4(Box<Fp4Instance>),
    /// A GLS curve over `F_{p²}` or a subfield curve on `E(F_{p³})`
    /// (`ecbench::ext`); a coordinate is one packed word.
    Ext(Box<ExtInstance>),
    /// The Jacobian of a genus-2 curve (`ecbench::jacobian`).
    Genus2(Box<Genus2Instance>),
    /// The Jacobian of a smooth plane quartic (`ecbench::plane_quartic`).
    Quartic(Box<QuarticInstance>),
    /// An elliptic curve over `F_{p⁶}` with a genus-3 GHS cover
    /// (`ecbench::ghs_cover`).
    Ghs(Box<GhsInstance>),
    /// A hyperelliptic Jacobian of genus 2 to 4 over `F_p`, `p < 256`
    /// (`ecbench::hyper`); a divisor is two packed words.
    Hyper(Box<HyperInstance>),
    /// A hyperelliptic Jacobian over `F_p` (`ecbench::hec`); a reduced
    /// divisor is two packed words.
    Hec(Box<HecInstance>),
}

/// A wide Koblitz curve and the strong reference's arithmetic on it, which
/// every wide method and the workload's own `[k]G` use.
pub struct WideInstance {
    pub kc: WideKoblitz,
    pub rho: WideStrongRho,
}

/// A Koblitz curve over a three-word field and the strong reference's
/// arithmetic on it, which every big method and the workload's own `[k]G`
/// use.
pub struct BigInstance {
    pub kc: BigKoblitz,
    pub rho: BigStrongRho,
}

/// The registry's modulus for `K_a` over `F_{2^n}`, if it lists one.
pub fn registry_koblitz_modulus(a: u8, n: u32) -> Option<IrreduciblePoly> {
    let entry = registry_curves().iter().find(|c| {
        let p = c.get("params");
        c.get("family").and_then(Value::as_str) == Some("koblitz")
            && p.and_then(|p| p.get("a")).and_then(Value::as_u64) == Some(u64::from(a))
            && p.and_then(|p| p.get("n")).and_then(Value::as_u64) == Some(u64::from(n))
    })?;
    let hex = entry.get("params")?.get("modulus")?.as_str()?;
    let bits = num_bigint::BigUint::parse_bytes(hex.trim_start_matches("0x").as_bytes(), 16)?;
    if bits.bits() != u64::from(n) + 1 {
        return None;
    }
    let low_terms = (0..n).filter(|&i| bits.bit(u64::from(i))).collect();
    Some(IrreduciblePoly {
        degree: n,
        low_terms,
    })
}

/// The facts about a built curve every record carries.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct CurveFacts {
    /// The ICV1 slug: the curve's name in prose and tables (AGENTS.md §11).
    pub slug: String,
    pub icv1: String,
    /// `prime`, `koblitz`, `binary`, `fp4`, `extension` or
    /// `hyperelliptic`.
    pub family: String,
    pub construction: String,
    /// Field degree for binary curves; `None` for prime fields.
    pub field_degree: Option<u32>,
    /// Bits of the field characteristic for prime curves.
    pub field_bits: Option<u32>,
    /// Orders exactly, through 256 bits; a value that fits a `u64` is
    /// written as the number it always was, and a wider one as a decimal
    /// string ([`ExactScalar`], byte for byte the `canonical::compat_u128`
    /// encoding these fields had while they were `u128`).
    /// HEC thread Jacobian order/cofactor zero means unknown.
    pub group_order: ExactScalar,
    pub r: ExactScalar,
    pub cofactor: ExactScalar,
    /// Generator coordinates as lower-case hex.
    pub generator: [String; 2],
    /// Automorphisms a generic algorithm may use, under the floor rule
    /// [`FLOOR_RULE_V2`] that new records are written with: 2 (negation);
    /// `2n` on a Koblitz curve (signed Frobenius), constructed or explicit;
    /// 6 on a `j = 0` prime curve and 4 on a `j = 1728` one when the
    /// rational order-3 (order-4) automorphism acts on the subgroup
    /// ([`prime_automorphisms`]).  Records written before that rule carry
    /// [`legacy_automorphisms`] (negation only on every prime curve) and
    /// no `floor_rule`; the audit recomputes them under it.
    pub automorphisms_available: u32,
    /// The slug is in `docs/curves/registry.json`.
    pub registered: bool,
    /// EC1 alias and curve UID of the registered representation whose
    /// subgroup and generator are exactly this one; `None` when the
    /// registry has no such representation (never inferred).
    pub ec1: Option<String>,
    pub curve_uid: Option<String>,
}

/// The floor rule records are written with from this version on
/// (`boundaries.floor_rule`).  A record without the field was written under
/// the first rule, [`legacy_automorphisms`]: `A = 2` on every prime curve.
pub const FLOOR_RULE_V2: &str = "automorphisms/v2";

/// The automorphism count the first floor rule gave a curve: 2 (negation)
/// on every prime curve, `j = 0` and `j = 1728` included; on every other
/// family the count [`FLOOR_RULE_V2`] also gives (`2n` on a Koblitz curve,
/// the class size on an `extension` curve: 4 for GLS ψ, 6 for a subfield
/// curve's π; 2 elsewhere), because the second rule changed prime curves
/// only.  Kept so that a committed record, which carries no `floor_rule`,
/// recomputes to the floor it was written with.
pub fn legacy_automorphisms(curve: &CurveFacts) -> u32 {
    if curve.family == "prime" {
        2
    } else {
        curve.automorphisms_available
    }
}

/// The automorphisms a generic algorithm may use on a prime curve's
/// order-`r` subgroup: 6 on a `j = 0` curve with `p ≡ 1 (mod 3)` and 4 on a
/// `j = 1728` curve with `p ≡ 1 (mod 4)`, when the rational order-3
/// (order-4) automorphism acts on the subgroup as a scalar (verified with
/// the same structure `rho.cubic` and `rho.quartic` need); 2 otherwise.
/// The count includes negation, so it is the `A` of the floor
/// `√(π / 2A)`.
pub fn prime_automorphisms(curve: &PrimeCurve, generator: PrimePoint, r: u64) -> u32 {
    let mut scratch = GroupOps::default();
    if CubicClasses::new(curve, generator, r, &mut scratch).is_some() {
        6
    } else if QuarticClasses::new(curve, generator, r, &mut scratch).is_some() {
        4
    } else {
        2
    }
}

const REGISTRY: &str = include_str!("../../../docs/curves/registry.json");
/// The registry's index: one decimal byte offset per line, the offset of
/// the opening quote of a slug's value in `REGISTRY` (its first
/// `"slug": "…"` pair in document order), the lines ordered by that slug.
/// The slugs themselves are read from `REGISTRY` at the offsets, so the
/// index stays small (offsets only).  Written with the registry by
/// `scripts/build_curve_registry.py` (`registry_index_text` in
/// `scripts/curve_id.py`); `check_curve_names.py` and the test below fail
/// when it is stale, so an index miss means the document has no such
/// entry.  (A `build.rs` could generate it, but a build script makes Cargo
/// list every file of the package to fingerprint it, which this
/// repository's size and CI's partial clones do not bear.)
const REGISTRY_INDEX: &str = include_str!("registry_index.txt");

/// The slug whose value's opening quote is at byte `at` of `REGISTRY`.
fn registry_slug_at(at: usize) -> Option<&'static str> {
    let rest = REGISTRY.get(at..)?.strip_prefix('"')?;
    Some(&rest[..rest.find('"')?])
}

/// The byte offset in `REGISTRY` of `slug`'s value, by binary search over
/// the lines of `REGISTRY_INDEX`; `None` when the index has no such slug.
fn registry_index_offset(slug: &str) -> Option<usize> {
    let text = REGISTRY_INDEX.as_bytes();
    let (mut lo, mut hi) = (0usize, text.len());
    // Every line that can match starts in [lo, hi), at `lo` or just after
    // a newline; probe the line that contains the midpoint.
    while lo < hi {
        let mid = lo + (hi - lo) / 2;
        let start = text[lo..mid]
            .iter()
            .rposition(|&b| b == b'\n')
            .map_or(lo, |i| lo + i + 1);
        let end = text[start..hi]
            .iter()
            .position(|&b| b == b'\n')
            .map_or(hi, |i| start + i);
        let at: usize = std::str::from_utf8(&text[start..end]).ok()?.parse().ok()?;
        match registry_slug_at(at)?.cmp(slug) {
            std::cmp::Ordering::Equal => return Some(at),
            std::cmp::Ordering::Less => lo = (end + 1).min(hi),
            std::cmp::Ordering::Greater => hi = start,
        }
    }
    None
}

/// The registry's curves, parsed once per process, for the lookups that
/// scan every entry (a wide Koblitz modulus) and as the fallback of
/// [`registry_entry`]; several megabytes, so nothing on the per-execution
/// path parses it.
fn registry_curves() -> &'static [Value] {
    static CURVES: OnceLock<Vec<Value>> = OnceLock::new();
    CURVES.get_or_init(|| {
        serde_json::from_str::<Value>(REGISTRY)
            .ok()
            .and_then(|mut doc| doc.get_mut("curves").map(Value::take))
            .and_then(|curves| match curves {
                Value::Array(curves) => Some(curves),
                _ => None,
            })
            .unwrap_or_default()
    })
}

/// The registry entry of `slug`, parsed from its own text alone.
///
/// The document is 20.8 MB and every measured execution is a fresh child
/// process, so parsing it whole cost 97% of a toy solve's instructions
/// (callgrind, 2026-10-18: 147.6M of 153M Ir in `ecbench exec`); a
/// per-process cache cannot help a child.  A slug is a plain `icv1-…`
/// string that occurs in the document as its own entry's `"slug"` value,
/// the first key of the entry, so the entry is cut out between the brace
/// before that key and its string-aware match and parsed on its own.  The
/// extracted object is checked to carry the slug, and anything the fast
/// path cannot place falls back to the full parse, so the answer is the
/// one the full parse gives: the first entry with that slug.
///
/// The scan itself is now the fallback: `REGISTRY_INDEX` (written with the
/// document) names the byte offset of every slug's first `"slug": "…"`
/// pair, so the entry is cut out at that offset and the scan runs only
/// when the index cannot place it.  A slug without an index entry has no
/// such pair in the document and so no entry.  Scanning the 20.8 MB
/// document to an entry deep in it cost 37M of the 39M instructions a
/// 32-bit `rho.negation` child spent before its solve marker (2026-11-01,
/// Callgrind), the same for every child of that curve.
fn registry_entry(slug: &str) -> Option<Value> {
    let at = registry_index_offset(slug)?;
    if let Some(entry) = registry_entry_around(at) {
        if entry.get("slug").and_then(Value::as_str) == Some(slug) {
            return Some(entry);
        }
    }
    let needle = format!("\"{slug}\"");
    let mut from = 0;
    while let Some(pos) = REGISTRY[from..].find(&needle) {
        let at = from + pos;
        from = at + needle.len();
        let Some(entry) = registry_entry_around(at) else {
            // A slug quoted somewhere the fast path cannot read: the
            // full parse decides.
            return registry_curves()
                .iter()
                .find(|c| c.get("slug").and_then(Value::as_str) == Some(slug))
                .cloned();
        };
        if entry.get("slug").and_then(Value::as_str) == Some(slug) {
            return Some(entry);
        }
    }
    None
}

/// The object whose first key, `"slug"`, has its value at byte `at` of
/// the registry; `None` when the text around `at` is not that shape.
fn registry_entry_around(at: usize) -> Option<Value> {
    let before = REGISTRY[..at].trim_end_matches(|c: char| c == ':' || c.is_whitespace());
    let key = before.strip_suffix("\"slug\"")?;
    let open = key.rfind('{')?;
    if !key[open + 1..].trim().is_empty() {
        return None;
    }
    let close = json_object_end(REGISTRY.as_bytes(), open)?;
    serde_json::from_str(&REGISTRY[open..=close]).ok()
}

/// The index of the `}` closing the object that opens at `open`, reading
/// strings and their escapes so braces inside them do not count.
fn json_object_end(text: &[u8], open: usize) -> Option<usize> {
    let mut depth = 0usize;
    let mut in_string = false;
    let mut escaped = false;
    for (i, &b) in text.iter().enumerate().skip(open) {
        if in_string {
            if escaped {
                escaped = false;
            } else if b == b'\\' {
                escaped = true;
            } else if b == b'"' {
                in_string = false;
            }
            continue;
        }
        match b {
            b'"' => in_string = true,
            b'{' => depth += 1,
            b'}' => {
                depth -= 1;
                if depth == 0 {
                    return Some(i);
                }
            }
            _ => {}
        }
    }
    None
}

fn parse_hex(s: &str) -> Option<num_bigint::BigUint> {
    num_bigint::BigUint::parse_bytes(s.trim_start_matches("0x").as_bytes(), 16)
}

/// `(ec1, curve_uid)` of the representation with this subgroup and
/// generator.  Compared as exact integers: a registry value that a `u128`
/// could not hold matches nothing narrower, as it never did.
fn matching_representation(
    entry: &Value,
    r: &num_bigint::BigUint,
    gx: &num_bigint::BigUint,
    gy: &num_bigint::BigUint,
) -> Option<(String, String)> {
    entry
        .get("representations")?
        .as_array()?
        .iter()
        .find_map(|rep| {
            let c = rep.get("curve")?;
            let order: num_bigint::BigUint = c.get("subgroup_order")?.as_str()?.parse().ok()?;
            let g = c.get("generator")?.as_array()?;
            let x = parse_hex(g.first()?.as_str()?)?;
            let y = parse_hex(g.get(1)?.as_str()?)?;
            if order != *r || x != *gx || y != *gy {
                return None;
            }
            Some((
                rep.get("ec1")?.as_str()?.to_string(),
                rep.get("curve_uid")?.as_str()?.to_string(),
            ))
        })
}

impl Instance {
    /// The prime subgroup order, exactly.
    pub fn r(&self) -> ExactScalar {
        if let Instance::Big(i) = self {
            return ExactScalar::from_biguint(&i.kc.r).expect("r < 2^192");
        }
        ExactScalar::from(self.r_narrow())
    }

    /// The subgroup order of every class but [`Instance::Big`].
    fn r_narrow(&self) -> u128 {
        match self {
            Instance::Big(_) => unreachable!("a big instance's order is past u128"),
            Instance::ThreeLeads(i) => u128::from(i.r),
            Instance::Prime(i) => u128::from(i.r),
            Instance::Binary(i) => u128::from(i.r),
            Instance::Wide(i) => i.kc.r,
            Instance::Fp4(i) => u128::from(i.r),
            Instance::Fp4Torsion(i) => u128::from(i.r),
            Instance::F2m4(i) => i.r,
            Instance::Ext(i) => u128::from(i.r()),
            Instance::Genus2(i) => u128::from(i.r),
            Instance::Quartic(i) => u128::from(i.r),
            Instance::Ghs(i) => u128::from(i.l),
            Instance::Hyper(i) => u128::from(i.r()),
            Instance::Hec(i) => u128::from(i.r),
        }
    }

    pub fn facts(&self, spec: &CurveSpec) -> CurveFacts {
        if let Instance::ThreeLeads(i) = self {
            return super::three_leads::facts(i, spec);
        }
        let jac = match self {
            Instance::Genus2(i) => Some((
                i.names(),
                "genus2",
                i.p(),
                i.group_order,
                i.r,
                i.cofactor,
                i.encode(&i.generator),
            )),
            Instance::Quartic(i) => Some((
                i.names(),
                "plane_quartic",
                i.jac.p,
                i.group_order,
                i.r,
                i.cofactor,
                i.encode(&i.generator),
            )),
            _ => None,
        };
        if let Some(((icv1, slug), family, p, order, r, h, generator)) = jac {
            // A Jacobian's model is not an elliptic curve: it has no ICV1
            // identity or registry entry (`jacobian` module docs).
            return CurveFacts {
                slug,
                icv1,
                family: family.into(),
                construction: spec.call(),
                field_degree: None,
                field_bits: Some(64 - p.leading_zeros()),
                group_order: ExactScalar::from(order),
                r: ExactScalar::from(r),
                cofactor: ExactScalar::from(h),
                generator,
                automorphisms_available: 2,
                registered: false,
                ec1: None,
                curve_uid: None,
            };
        }
        if let Instance::Ghs(i) = self {
            let (icv1, slug) = i.names();
            return CurveFacts {
                slug,
                icv1,
                family: "ghs_fp6".into(),
                construction: spec.call(),
                field_degree: Some(6),
                field_bits: Some(64 - i.p.leading_zeros()),
                group_order: ExactScalar::from(i.group_order()),
                r: ExactScalar::from(i.l),
                cofactor: ExactScalar::from(4u64),
                generator: i.encode(&i.generator),
                automorphisms_available: 2,
                registered: false,
                ec1: None,
                curve_uid: None,
            };
        }
        if let Instance::Ext(i) = self {
            let id = i.id();
            return CurveFacts {
                slug: id.slug,
                icv1: id.icv1,
                family: "extension".into(),
                construction: spec.call(),
                field_degree: None,
                field_bits: Some(64 - i.p().leading_zeros()),
                group_order: ExactScalar::from(i.group_order()),
                r: ExactScalar::from(i.r()),
                cofactor: ExactScalar::from(i.cofactor()),
                generator: i.generator_hex(),
                automorphisms_available: i.automorphisms_available(),
                registered: false,
                ec1: None,
                curve_uid: None,
            };
        }
        if let Instance::Hyper(i) = self {
            let (icv1, slug) = i.names();
            return CurveFacts {
                slug,
                icv1,
                family: "hyperelliptic".into(),
                construction: spec.call(),
                field_degree: None,
                field_bits: Some(64 - i.p.leading_zeros()),
                group_order: ExactScalar::from(i.group_order),
                r: ExactScalar::from(i.r),
                cofactor: ExactScalar::from(i.cofactor),
                generator: i.generator_hex(),
                automorphisms_available: 2,
                registered: false,
                ec1: None,
                curve_uid: None,
            };
        }
        if let Instance::Fp4(i) = self {
            let (icv1, slug) = i.names();
            let g = Fp4Instance::encode(&i.g).unwrap_or_default();
            return CurveFacts {
                slug,
                icv1,
                family: "fp4".into(),
                construction: spec.call(),
                field_degree: None,
                field_bits: Some(64 - i.p.leading_zeros()),
                group_order: ExactScalar::from(i.group_order),
                r: ExactScalar::from(i.r),
                cofactor: ExactScalar::from(i.cofactor),
                generator: g,
                automorphisms_available: 2,
                registered: false,
                ec1: None,
                curve_uid: None,
            };
        }
        if let Instance::Hec(i) = self {
            let (icv1, slug) = i.names();
            return CurveFacts {
                slug,
                icv1,
                family: "hyperelliptic".into(),
                construction: spec.call(),
                field_degree: None,
                field_bits: Some(64 - i.p.leading_zeros()),
                group_order: 0u64.into(),
                r: i.r.into(),
                cofactor: 0u64.into(),
                generator: i.generator_hex(),
                automorphisms_available: 2,
                registered: false,
                ec1: None,
                curve_uid: None,
            };
        }
        if let Instance::Big(i) = self {
            let id = i.kc.curve_id();
            let entry = registry_entry(&id.slug);
            let (gx, gy) = (i.kc.generator.0, i.kc.generator.1);
            let rep = entry.as_ref().and_then(|e| {
                matching_representation(e, &i.kc.r, &gx.to_biguint(), &gy.to_biguint())
            });
            let exact = |v: &num_bigint::BigUint| {
                ExactScalar::from_biguint(v).expect("an order below 2^192")
            };
            return CurveFacts {
                slug: id.slug,
                icv1: id.icv1,
                family: "koblitz".into(),
                construction: spec.call(),
                field_degree: Some(i.kc.n),
                field_bits: None,
                group_order: exact(&i.kc.group_order),
                r: exact(&i.kc.r),
                cofactor: ExactScalar::from(i.kc.cofactor),
                generator: [gx.hex(), gy.hex()],
                automorphisms_available: 2 * i.kc.n,
                registered: entry.is_some(),
                ec1: rep.as_ref().map(|(a, _)| a.clone()),
                curve_uid: rep.map(|(_, u)| u),
            };
        }
        let (id, family, degree, bits, order, r, h, gx, gy, aut) = match self {
            Instance::Prime(i) => (
                i.curve_id(),
                "prime",
                None,
                Some(64 - i.curve.p.leading_zeros()),
                u128::from(i.group_order),
                u128::from(i.r),
                u128::from(i.cofactor),
                u128::from(i.generator.0),
                u128::from(i.generator.1),
                prime_automorphisms(&i.curve, i.generator_point(), i.r),
            ),
            Instance::Binary(i) => (
                i.curve_id(),
                if i.koblitz.is_some() {
                    "koblitz"
                } else {
                    "binary"
                },
                Some(i.n),
                None,
                u128::from(i.group_order),
                u128::from(i.r),
                u128::from(i.cofactor),
                u128::from(i.generator.x),
                u128::from(i.generator.y),
                if i.koblitz.is_some() { 2 * i.n } else { 2 },
            ),
            Instance::Fp4(_)
            | Instance::ThreeLeads(_)
            | Instance::Ext(_)
            | Instance::Genus2(_)
            | Instance::Quartic(_)
            | Instance::Ghs(_)
            | Instance::Hyper(_)
            | Instance::Hec(_)
            | Instance::Big(_) => {
                unreachable!("returned above")
            }
            Instance::Wide(i) => (
                i.kc.curve_id(),
                "koblitz",
                Some(i.kc.n),
                None,
                i.kc.group_order,
                i.kc.r,
                i.kc.cofactor,
                i.kc.generator.0,
                i.kc.generator.1,
                2 * i.kc.n,
            ),
            Instance::Fp4Torsion(i) => {
                let f = &i.inst.curve.f;
                let p = f.p;
                let id = crate::cryptanalysis::curve_id::extension(
                    p,
                    &[(p - f.c % p) % p, 0, 0, 0],
                    &i.inst.curve.a.0,
                    &i.inst.curve.b.0,
                    &num_bigint::BigUint::from(i.group_order),
                )
                .expect("a found curve is non-singular and inside the Hasse interval");
                (
                    id,
                    "extension",
                    None,
                    Some(64 - p.leading_zeros()),
                    u128::from(i.group_order),
                    u128::from(i.r),
                    u128::from(i.cofactor),
                    u128::from(pack_e4(p, &i.generator.x)),
                    u128::from(pack_e4(p, &i.generator.y)),
                    2,
                )
            }
            Instance::F2m4(i) => {
                // The identity of the curve over F_{2^{4m}} in the polynomial
                // basis of the tower's canonical generator θ.
                let c = &i.curve;
                let f = &c.f;
                let tb = TowerBasis::new(f);
                let big = num_bigint::BigUint::from;
                let id = crate::cryptanalysis::curve_id::binary(
                    4 * f.f.m,
                    &big(tb.modulus),
                    &big(tb.coords(f, &c.a)),
                    &big(tb.coords(f, &c.b)),
                    &big(i.group_order),
                    None,
                )
                .expect("a found curve is non-singular and inside the Hasse interval");
                (
                    id,
                    "extension",
                    None,
                    Some(f.f.m),
                    i.group_order,
                    i.r,
                    i.cofactor,
                    f.pack(&i.generator.x),
                    f.pack(&i.generator.y),
                    2,
                )
            }
        };
        let entry = registry_entry(&id.slug);
        let rep = entry.as_ref().and_then(|e| {
            matching_representation(
                e,
                &num_bigint::BigUint::from(r),
                &num_bigint::BigUint::from(gx),
                &num_bigint::BigUint::from(gy),
            )
        });
        CurveFacts {
            slug: id.slug,
            icv1: id.icv1,
            family: family.into(),
            construction: spec.call(),
            field_degree: degree,
            field_bits: bits,
            group_order: order.into(),
            r: r.into(),
            cofactor: h.into(),
            generator: [format!("0x{gx:x}"), format!("0x{gy:x}")],
            automorphisms_available: aut,
            registered: entry.is_some(),
            ec1: rep.as_ref().map(|(a, _)| a.clone()),
            curve_uid: rep.map(|(_, u)| u),
        }
    }

    /// `[k]G` for an exact scalar. Reduction happens before conversion, so
    /// no high bits are discarded: a big instance multiplies by the reduced
    /// scalar on its own three-word arithmetic, every other instance (whose
    /// order fits a `u128`) through [`Self::mul_generator_hex`].
    pub fn mul_generator_exact(&self, k: ExactScalar) -> Option<[String; 2]> {
        let reduced = k.to_biguint() % self.r().to_biguint();
        if let Instance::Big(i) = self {
            let k = <crate::cryptanalysis::koblitz_big::U192 as RhoScalar>::from_biguint(&reduced)?;
            return match i.rho.scalar_mul(i.rho.generator(), k) {
                RawPointG::Affine { x, y } => Some([x.hex(), y.hex()]),
                RawPointG::Infinity => None,
            };
        }
        let narrow = ExactScalar::from_biguint(&reduced)?.checked_u128()?;
        self.mul_generator_hex(narrow)
    }

    /// `[k]G` as hex coordinates, computed by the instance's own counted
    /// double-and-add on a ledger nobody reads.  Used to build the
    /// target and, separately, to verify an answer.
    pub fn mul_generator_hex(&self, k: u128) -> Option<[String; 2]> {
        if let Instance::Big(_) = self {
            return self.mul_generator_exact(ExactScalar::from(k));
        }
        let mut scratch = GroupOps::default();
        if let Instance::Wide(i) = self {
            return match i.rho.scalar_mul(i.rho.generator(), k % i.kc.r) {
                RawPointG::Affine { x, y } => Some([format!("0x{x:x}"), format!("0x{y:x}")]),
                RawPointG::Infinity => None,
            };
        }
        // A curve over F_{(2^m)^4} may have a two-word order (m ≥ 16);
        // its own u128 double-and-add gives the same point either way.
        if let Instance::F2m4(i) = self {
            let c = &i.curve;
            let pt = c.mul(&i.generator, k % i.r);
            return (!pt.inf).then(|| {
                [
                    format!("0x{:x}", c.f.pack(&pt.x)),
                    format!("0x{:x}", c.f.pack(&pt.y)),
                ]
            });
        }
        // A one-word instance's subgroup order fits a word, so a reduced
        // scalar does too.
        let k = u64::try_from(k % self.r_narrow()).ok()?;
        if let Instance::Fp4(i) = self {
            return i.mul_generator_hex(k);
        }
        if let Instance::ThreeLeads(i) = self {
            let p = i.curve.mul(i.generator, k);
            return (!p.inf).then(|| [format!("0x{:x}", p.x), format!("0x{:x}", p.y)]);
        }
        if let Instance::Ext(i) = self {
            return i.mul_generator_hex(k);
        }
        if let Instance::Genus2(i) = self {
            return i.mul_generator_hex(k);
        }
        if let Instance::Quartic(i) = self {
            return i.mul_generator_hex(k);
        }
        if let Instance::Ghs(i) = self {
            return i.mul_generator_hex(k);
        }
        if let Instance::Hec(i) = self {
            return i.mul_generator_hex(k);
        }
        if let Instance::Hyper(i) = self {
            return i.mul_generator_hex(k);
        }
        match self {
            Instance::Prime(i) => {
                let p = i.curve.mul(&mut scratch, i.generator_point(), k);
                (!p.infinity).then(|| [format!("0x{:x}", p.x), format!("0x{:x}", p.y)])
            }
            Instance::Binary(i) => {
                let g = BinaryGroup(&i.fast);
                let p = g.mul(&mut scratch, i.generator, k);
                (!p.infinity).then(|| [format!("0x{:x}", p.x), format!("0x{:x}", p.y)])
            }
            Instance::Fp4Torsion(i) => {
                let c = &i.inst.curve;
                let pt = CountedGroup::mul(c, &mut scratch, i.generator, k);
                let p = c.f.p;
                (!pt.inf).then(|| {
                    [
                        format!("0x{:x}", pack_e4(p, &pt.x)),
                        format!("0x{:x}", pack_e4(p, &pt.y)),
                    ]
                })
            }
            Instance::F2m4(i) => {
                let c = &i.curve;
                let pt = CountedGroup::mul(c, &mut scratch, i.generator, k);
                (!pt.inf).then(|| {
                    [
                        format!("0x{:x}", c.f.pack(&pt.x)),
                        format!("0x{:x}", c.f.pack(&pt.y)),
                    ]
                })
            }
            Instance::Wide(_)
            | Instance::Big(_)
            | Instance::Fp4(_)
            | Instance::ThreeLeads(_)
            | Instance::Ext(_)
            | Instance::Genus2(_)
            | Instance::Quartic(_)
            | Instance::Ghs(_)
            | Instance::Hyper(_)
            | Instance::Hec(_) => {
                unreachable!("returned above")
            }
        }
    }
}

impl Instance {
    /// A public target: for `counter = 0, 1, …`, an abscissa derived from
    /// `(model, r, seed, index, counter)` by SHA-256, lifted to a point
    /// (the ordinate's choice also hashed), times the cofactor; the first
    /// that is not the identity.  When `r ∤ h` (so `r² ∤ #E`, which
    /// `Workload::on` checks) the r-torsion is cyclic and that point lies
    /// in `⟨G⟩`.
    pub fn hash_to_subgroup(
        &self,
        curve: &CurveFacts,
        seed: u64,
        index: u64,
    ) -> Option<([String; 2], u64)> {
        self.hash_to_subgroup_counted(curve, seed, index, &mut HashWork::default())
    }

    /// [`Instance::hash_to_subgroup`], also tallying into `work` what the
    /// derivation did, including the draws that found no point. Only the
    /// prime-field branch fills `work.draws`, `sqrt_field_muls` and
    /// `on_curve_checks`; every branch adds its cofactor multiplications to
    /// `work.group_ops`. The result is the same function of the inputs.
    pub fn hash_to_subgroup_counted(
        &self,
        curve: &CurveFacts,
        seed: u64,
        index: u64,
        work: &mut HashWork,
    ) -> Option<([String; 2], u64)> {
        let model = model_hash(curve);
        let scratch = &mut work.group_ops;
        if let Instance::Fp4(_)
        | Instance::Fp4Torsion(_)
        | Instance::F2m4(_)
        | Instance::ThreeLeads(_)
        | Instance::Hyper(_)
        | Instance::Hec(_) = self
        {
            // Planted targets only on E(F_{p^4}), the tower, the three-leads
            // study and the hyperelliptic Jacobians: no public-target law yet.
            return None;
        }
        if let Instance::Big(i) = self {
            // PUBLIC_TARGET_LAW_BIG: the same inputs as decimal strings, the
            // whole 256-bit digest; its low n bits are the abscissa and its
            // top bit (bit 255, never one of them) chooses the ordinate.
            let f = i.kc.field();
            let h = crate::cryptanalysis::koblitz_big::U192::from_u128(u128::from(i.kc.cofactor));
            let mask = (num_bigint::BigUint::from(1u8) << i.kc.n) - 1u8;
            for counter in 0..10_000u64 {
                let parts = [
                    model.to_string(),
                    curve.r.to_string(),
                    seed.to_string(),
                    index.to_string(),
                    counter.to_string(),
                ];
                let d = derive_biguint(PUBLIC_TARGET_LAW_BIG, &parts);
                let flip = d.bit(255);
                let x = W192::from_biguint(&(&d & &mask)).expect("n ≤ 191 bits");
                let pts = i.kc.points_with_x(&f, x);
                let Some(&(x, y)) = pts.get(usize::from(flip && pts.len() > 1)) else {
                    continue;
                };
                if let RawPointG::Affine { x, y } = i.rho.scalar_mul(RawPointG::Affine { x, y }, h)
                {
                    return Some(([x.hex(), y.hex()], counter));
                }
            }
            return None;
        }
        if let Instance::Wide(i) = self {
            // PUBLIC_TARGET_LAW_WIDE: the same inputs as decimal strings, a
            // 128-bit draw, its top bit choosing the ordinate.
            for counter in 0..10_000u64 {
                let parts = [
                    model.to_string(),
                    curve.r.to_string(),
                    seed.to_string(),
                    index.to_string(),
                    counter.to_string(),
                ];
                let h = derive_u128(PUBLIC_TARGET_LAW_WIDE, &parts);
                let flip = h >> 127 == 1;
                let pts = i.kc.points_with_x(h & ((1u128 << i.kc.n) - 1));
                let Some(&(x, y)) = pts.get(usize::from(flip && pts.len() > 1)) else {
                    continue;
                };
                if let RawPointG::Affine { x, y } =
                    i.rho.scalar_mul(RawPointG::Affine { x, y }, i.kc.cofactor)
                {
                    return Some(([format!("0x{x:x}"), format!("0x{y:x}")], counter));
                }
            }
            return None;
        }
        for counter in 0..10_000u64 {
            // One-word curves only: their order fits the law's u64 parts.
            let r = curve.r.checked_u64()?;
            let h = derive_u64(PUBLIC_TARGET_LAW, &[model, r, seed, index, counter]);
            let flip = (h >> 63) & 1 == 1;
            match self {
                Instance::Prime(i) => {
                    let c = &i.curve;
                    let x = h % c.p;
                    work.draws += 1;
                    let Some(y) = c.sqrt_counted(c.rhs(x), &mut work.sqrt_field_muls) else {
                        continue;
                    };
                    let y = if flip && y != 0 { c.p - y } else { y };
                    let p = PrimePoint::affine(x, y);
                    work.on_curve_checks += 1;
                    if !c.is_on_curve(p) {
                        continue;
                    }
                    let q = c.mul(scratch, p, i.cofactor);
                    if !q.infinity {
                        return Some(([format!("0x{:x}", q.x), format!("0x{:x}", q.y)], counter));
                    }
                }
                Instance::Wide(_)
                | Instance::Big(_)
                | Instance::Fp4(_)
                | Instance::ThreeLeads(_)
                | Instance::Hyper(_)
                | Instance::Hec(_) => {
                    unreachable!("handled above")
                }
                Instance::Ext(i) => {
                    if let Some(t) = i.hash_to_subgroup_hex(h) {
                        return Some((t, counter));
                    }
                }
                Instance::Genus2(i) => {
                    if let Some(t) = i.hash_to_subgroup_hex(h) {
                        return Some((t, counter));
                    }
                }
                Instance::Quartic(i) => {
                    if let Some(t) = i.hash_to_subgroup_hex(h) {
                        return Some((t, counter));
                    }
                }
                Instance::Ghs(i) => {
                    if let Some(t) = i.hash_to_subgroup_hex(h) {
                        return Some((t, counter));
                    }
                }
                Instance::Fp4Torsion(i) => {
                    let c = &i.inst.curve;
                    let p = c.f.p;
                    let x = unpack_e4(p, h % p.pow(4));
                    // The square root's sampler is seeded by the draw, so
                    // the target is a function of the law's inputs.
                    let mut rng = <rand::rngs::StdRng as rand::SeedableRng>::seed_from_u64(h);
                    let Some(pt) = c.lift_x(&x, &mut rng) else {
                        continue;
                    };
                    let k = CountedGroup::key(c, &pt);
                    let pt = if (k & 1 == 1) != flip { pt } else { c.neg(&pt) };
                    let q: Pt4 = CountedGroup::mul(c, scratch, pt, i.cofactor);
                    if !q.inf {
                        return Some((
                            [
                                format!("0x{:x}", pack_e4(p, &q.x)),
                                format!("0x{:x}", pack_e4(p, &q.y)),
                            ],
                            counter,
                        ));
                    }
                }
                Instance::F2m4(i) => {
                    let c = &i.curve;
                    let bits = 4 * c.f.f.m;
                    // One word of hash while 4m < 64 (every committed
                    // target); past that a second, derived word on top.
                    let raw = if bits < 64 {
                        u128::from(h & ((1u64 << bits) - 1))
                    } else {
                        let hi = h.rotate_left(32).wrapping_mul(0x9e37_79b9_7f4a_7c15);
                        (u128::from(h) | (u128::from(hi) << 64)) & ((1u128 << bits) - 1)
                    };
                    let x = c.f.unpack(raw);
                    let mut rng = <rand::rngs::StdRng as rand::SeedableRng>::seed_from_u64(h);
                    let Some(pt) = c.lift_x(&x, &mut rng) else {
                        continue;
                    };
                    let k = CountedGroup::key(c, &pt);
                    let pt = if (k & 1 == 1) != flip { pt } else { c.neg(&pt) };
                    let cof = u64::try_from(i.cofactor).expect("a small cofactor");
                    let q: PtB = CountedGroup::mul(c, scratch, pt, cof);
                    if !q.inf {
                        return Some((
                            [
                                format!("0x{:x}", c.f.pack(&q.x)),
                                format!("0x{:x}", c.f.pack(&q.y)),
                            ],
                            counter,
                        ));
                    }
                }
                Instance::Binary(i) => {
                    let mask = if i.n >= 64 {
                        u64::MAX
                    } else {
                        (1u64 << i.n) - 1
                    };
                    let pts = i.points_with_x(h & mask);
                    let Some(&p) = pts.get(usize::from(flip && pts.len() > 1)) else {
                        continue;
                    };
                    let g = BinaryGroup(&i.fast);
                    let q = g.mul(scratch, p, i.cofactor);
                    if !q.infinity {
                        return Some(([format!("0x{:x}", q.x), format!("0x{:x}", q.y)], counter));
                    }
                }
            }
        }
        None
    }
}

/// What one [`Instance::hash_to_subgroup_counted`] call did: the cofactor
/// multiplications' group operations, and, on a prime field, the draws (each
/// one SHA-256 hash, one curve-equation evaluation and one square-root
/// attempt), the modular multiplications of those square roots and the
/// on-curve checks. Nothing here is priced by the derivation itself.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct HashWork {
    pub group_ops: GroupOps,
    pub draws: u64,
    pub sqrt_field_muls: u64,
    pub on_curve_checks: u64,
}

/// ICV1's last field: the first 12 hex digits of the model hash.
fn model_hash(curve: &CurveFacts) -> u64 {
    curve
        .icv1
        .rsplit(':')
        .next()
        .and_then(|h| u64::from_str_radix(h, 16).ok())
        .unwrap_or(0)
}

/// How planted targets are drawn: a scalar derived by SHA-256, `Q = [k]G`.
pub const TARGET_LAW: &str = "uniform_scalar_sha256_v1";

/// How public targets are drawn: an abscissa derived by SHA-256, lifted to
/// a point, the cofactor cleared.  Nobody ever knows the logarithm, which
/// is what the IC claim rules ask of a target ("previously unseen public
/// target"; `identity.py` refuses a planted workload).
pub const PUBLIC_TARGET_LAW: &str = "hash_to_subgroup_v1";

/// The public-target law for a subgroup order past `2^64`: the same
/// inputs, hashed as decimal strings, with a 128-bit draw.
pub const PUBLIC_TARGET_LAW_WIDE: &str = "hash_to_subgroup_v2";

/// The public-target law of the three-word Koblitz class
/// ([`Instance::Big`], subgroup order past `2^128`): the same inputs as
/// [`PUBLIC_TARGET_LAW_WIDE`], hashed as decimal strings, with the whole
/// 256-bit digest ([`derive_biguint`]): its low `n` bits are the
/// abscissa, its bit 255 chooses the ordinate.  Used for no other class.
pub const PUBLIC_TARGET_LAW_BIG: &str = "hash_to_subgroup_big_v3";

/// Whether a workload's target was built from a known scalar.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TargetKind {
    /// `Q = [k]G` for a derived `k`, kept to check the answer against.
    #[default]
    Planted,
    /// The same `k` on every curve of one order: the derivation hashes
    /// `[r, target_seed, index]` only, so a paired comparison can
    /// divide the same planted scalar's cost on two isogenous curves
    /// (their `r` is equal) and resample targets jointly.  A paired
    /// quotient is a different statistic from the independent-target
    /// law, not a replacement for it.
    PlantedShared,
    /// `Q` hashed to the subgroup; the answer is checked by `[d]G = Q`.
    Public,
    /// `Q = [k]D₁` with `k = ⌊r/3⌋ + 7 + index` (`HEC_THREAD_TARGET_LAW`):
    /// the fixed target of the hyperelliptic thread's studies, so their
    /// rows can be reproduced as records.  `hec_thread` curves only.
    PlantedHecThread,
}

impl TargetKind {
    pub fn is_planted(&self) -> bool {
        matches!(
            self,
            TargetKind::Planted | TargetKind::PlantedShared | TargetKind::PlantedHecThread
        )
    }
    /// Only the default kind stays unserialised.
    pub fn is_plain_planted(&self) -> bool {
        *self == TargetKind::Planted
    }
}

/// The hyperelliptic thread's fixed target, `k = ⌊r/3⌋ + 7 + index`
/// (`examples/hyperelliptic_ic_vs_rho_bitops.rs` uses `k = N/3 + 7`).  Not
/// drawn from the seed: it exists to reproduce that thread's rows.
pub const HEC_THREAD_TARGET_LAW: &str = "hec_thread_scalar_v1";

const NOT_HEC: &str = "planted_hec_thread targets need a hec_thread curve";
const HEC_NO_PUBLIC: &str =
    "a hec_thread Jacobian has no public-target law (its order is not computed)";

/// The planted-scalar law for a subgroup order past `2^64`: the same
/// inputs, hashed as decimal strings, with a 128-bit draw.  A one-word
/// order keeps [`TARGET_LAW`], so every existing workload is unchanged.
pub const TARGET_LAW_WIDE: &str = "uniform_scalar_sha256_v2";

/// The planted-scalar law for a subgroup order past `2^128` (the
/// three-word Koblitz class): the same inputs as [`TARGET_LAW_WIDE`],
/// hashed as decimal strings, with the whole 256-bit digest
/// ([`derive_biguint`]); `k = 1 + D mod (r − 1)`, a modulo bias below
/// `2^-64` for `r < 2^192`.  An order that fits a `u128` keeps its law, so
/// every existing workload is unchanged.
pub const TARGET_LAW_BIG: &str = "uniform_scalar_sha256_big_v3";

/// The paired planted-scalar law: `k` derives from `[r, target_seed,
/// index]` alone — no curve model — so every curve of the same subgroup
/// order draws the same scalar list.  One-word orders only (the paired
/// comparisons this serves run on one-word instances).
pub const SHARED_TARGET_LAW: &str = "uniform_scalar_sha256_shared_v1";

/// `k ∈ [1, r−1]` for target `index` under `target_seed`, the same on
/// every curve of subgroup order `r`.
pub fn shared_planted_scalar(r: u64, target_seed: u64, index: u64) -> u128 {
    u128::from(1 + derive_u64(SHARED_TARGET_LAW, &[r, target_seed, index]) % (r - 1))
}

/// `k ∈ [1, r−1]` for target `index` under `target_seed`, and the law
/// that drew it: [`TARGET_LAW`] for a one-word order, [`TARGET_LAW_WIDE`]
/// for an order that fits a `u128`, [`TARGET_LAW_BIG`] past that.
pub fn planted_scalar_exact(
    curve: &CurveFacts,
    target_seed: u64,
    index: u64,
) -> (ExactScalar, &'static str) {
    // The curve's model hash and subgroup enter the derivation, so the
    // same seed on two curves gives unrelated scalars.
    let model = model_hash(curve);
    if let Some(r) = curve.r.checked_u64() {
        let k = 1 + derive_u64(TARGET_LAW, &[model, r, target_seed, index]) % (r - 1);
        return (ExactScalar::from(k), TARGET_LAW);
    }
    let parts = [model, target_seed, index].map(|v| v.to_string());
    let parts = [
        parts[0].clone(),
        curve.r.to_string(),
        parts[1].clone(),
        parts[2].clone(),
    ];
    if let Some(r) = curve.r.checked_u128() {
        // The modulo bias of a 128-bit draw over r < 2^127 is below 2^-1.
        let k = 1 + derive_u128(TARGET_LAW_WIDE, &parts) % (r - 1);
        return (ExactScalar::from(k), TARGET_LAW_WIDE);
    }
    let r = curve.r.to_biguint();
    let k = derive_biguint(TARGET_LAW_BIG, &parts) % (&r - 1u8) + 1u8;
    (
        ExactScalar::from_biguint(&k).expect("k < r < 2^256"),
        TARGET_LAW_BIG,
    )
}

/// `k ∈ [1, r−1]` for target `index` under `target_seed`, for an order
/// that fits a `u128` (every class but [`Instance::Big`]); `None` past it,
/// where [`planted_scalar_exact`] draws.
pub fn planted_scalar(curve: &CurveFacts, target_seed: u64, index: u64) -> Option<u128> {
    curve.r.checked_u128()?;
    planted_scalar_exact(curve, target_seed, index)
        .0
        .checked_u128()
}

/// One built single-target workload.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Workload {
    /// `W` + 12 hex of the workload record (no `h`, so it composes into
    /// a run id as the repository's convention does).
    pub workload_id: String,
    pub workload_sha256: String,
    pub curve_spec: CurveSpec,
    pub curve: CurveFacts,
    pub target_law: String,
    pub target_seed: u64,
    pub target_index: u64,
    /// `Q`, hex.
    pub target: [String; 2],
    /// The planted `k` with `Q = [k]G`, for a planted target.  Not in the
    /// identity (the target point is) and never passed to a solver.
    /// `None` for a public target, whose logarithm nobody knows.
    #[serde(default)]
    pub planted: Option<ExactScalar>,
    /// The hash counter that landed a public target in the subgroup.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub target_counter: Option<u64>,
    /// EFD model/chart used for input and output, when one was selected.
    /// This does not change the group or the priced workload; it is kept so
    /// a record names the representation its generator and target came from.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub representation: Option<PrimeRepresentation>,
}

impl Workload {
    /// Build workload `index` on `spec` under `target_seed`.  This builds
    /// the curve; for several targets on one curve, build it once and
    /// call [`Workload::on`] for each (a 26-bit prime search counts
    /// points in `O(p)` per candidate curve).
    pub fn build(
        spec: &CurveSpec,
        target_seed: u64,
        index: u64,
        kind: TargetKind,
    ) -> Result<(Workload, Instance), String> {
        let inst = spec.build()?;
        let w = Self::on(spec, &inst, target_seed, index, kind)?;
        Ok((w, inst))
    }

    /// Workload `index` under `target_seed` on `inst`, already built from
    /// `spec`.
    pub fn on(
        spec: &CurveSpec,
        inst: &Instance,
        target_seed: u64,
        index: u64,
        kind: TargetKind,
    ) -> Result<Workload, String> {
        let curve = inst.facts(spec);
        if curve.r < ExactScalar::from(5u64) {
            return Err(format!(
                "subgroup order {} is too small to measure",
                curve.r
            ));
        }
        let (law, target, planted, counter) = if let CurveSpec::PrimePublicFixture {
            qx, qy, ..
        } = *spec
        {
            if kind != TargetKind::Public || index != 0 {
                return Err("external fixture is exactly one public target per curve".into());
            }
            (
                "ecbench.public-fixture/v1",
                [format!("0x{qx:x}"), format!("0x{qy:x}")],
                None,
                None,
            )
        } else {
            match kind {
                TargetKind::Planted => {
                    let (k, law) = planted_scalar_exact(&curve, target_seed, index);
                    let q = match k.checked_u128() {
                        Some(k) => inst.mul_generator_hex(k),
                        None => inst.mul_generator_exact(k),
                    }
                    .ok_or("the planted scalar gave the identity; the subgroup order is wrong")?;
                    (law, q, Some(k), None)
                }
                TargetKind::PlantedShared => {
                    let r = curve
                        .r
                        .checked_u64()
                        .ok_or("planted_shared targets need a one-word subgroup order")?;
                    let k = shared_planted_scalar(r, target_seed, index);
                    let q = inst.mul_generator_hex(k).ok_or(
                        "the planted scalar gave the identity; the subgroup order is wrong",
                    )?;
                    (SHARED_TARGET_LAW, q, Some(ExactScalar::from(k)), None)
                }
                TargetKind::PlantedHecThread => {
                    let Instance::Hec(i) = inst else {
                        return Err(NOT_HEC.into());
                    };
                    let k = thread_scalar(i.r, index);
                    let q = inst.mul_generator_hex(k).ok_or("k gave the identity")?;
                    (HEC_THREAD_TARGET_LAW, q, Some(ExactScalar::from(k)), None)
                }
                TargetKind::Public if matches!(inst, Instance::Hec(_)) => {
                    return Err(HEC_NO_PUBLIC.into());
                }
                TargetKind::Public => {
                    // With r | h the r-torsion can be Z/r × Z/r, and a cleared
                    // point need not lie in <G>.
                    if (curve.cofactor.to_biguint() % curve.r.to_biguint())
                        == num_bigint::BigUint::from(0u8)
                    {
                        return Err(format!(
                            "r = {} divides the cofactor {}: a hashed target need not lie in <G>",
                            curve.r, curve.cofactor
                        ));
                    }
                    let (q, c) = inst
                        .hash_to_subgroup(&curve, target_seed, index)
                        .ok_or("no public target found in 10 000 hash attempts")?;
                    let law = if curve.r.checked_u64().is_some() {
                        PUBLIC_TARGET_LAW
                    } else if matches!(inst, Instance::Big(_)) {
                        PUBLIC_TARGET_LAW_BIG
                    } else {
                        PUBLIC_TARGET_LAW_WIDE
                    };
                    (law, q, None, Some(c))
                }
            }
        };
        let (workload_id, workload_sha256) = bare_id(
            "W",
            &Self::identity_view(&curve, law, target_seed, index, &target),
        )?;
        let representation = match inst {
            Instance::Prime(prime) => prime.representation.clone(),
            _ => None,
        };
        Ok(Workload {
            workload_id,
            workload_sha256,
            curve_spec: spec.clone(),
            curve,
            target_law: law.into(),
            target_seed,
            target_index: index,
            target,
            planted,
            target_counter: counter,
            representation,
        })
    }

    /// The target's kind, from its law.
    pub fn kind(&self) -> TargetKind {
        if self.target_law == PUBLIC_TARGET_LAW
            || self.target_law == PUBLIC_TARGET_LAW_WIDE
            || self.target_law == PUBLIC_TARGET_LAW_BIG
            || self.target_law == "ecbench.public-fixture/v1"
        {
            TargetKind::Public
        } else if self.target_law == SHARED_TARGET_LAW {
            TargetKind::PlantedShared
        } else if self.target_law == HEC_THREAD_TARGET_LAW {
            TargetKind::PlantedHecThread
        } else {
            TargetKind::Planted
        }
    }

    /// What the workload id is a hash of: the exact curve model, the
    /// subgroup, the generator and the target point, plus the law that
    /// drew it.  One target, cold.
    fn identity_view(
        curve: &CurveFacts,
        law: &str,
        target_seed: u64,
        index: u64,
        target: &[String; 2],
    ) -> Value {
        json!({
            "schema": "ecbench.workload/v1",
            "icv1": curve.icv1,
            "subgroup_order": curve.r.to_string(),
            "cofactor": curve.cofactor.to_string(),
            "generator": curve.generator,
            "target": target,
            "target_law": law,
            "target_seed": target_seed.to_string(),
            "target_index": index.to_string(),
            "target_count": 1,
            "cache_policy": "cold",
        })
    }

    /// Recompute the identity from the fields; an audit compares it.
    pub fn recompute_id(&self) -> Result<String, String> {
        Ok(bare_id(
            "W",
            &Self::identity_view(
                &self.curve,
                &self.target_law,
                self.target_seed,
                self.target_index,
                &self.target,
            ),
        )?
        .0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn exact_scalar_verification_preserves_high_bits_until_subgroup_reduction() {
        use super::super::exact_scalar::ExactScalar;
        let inst = CurveSpec::Koblitz { a: 0, n: 7 }.build().unwrap();
        for scalar in [0u128, 1, 13, u64::MAX as u128, u128::MAX] {
            assert_eq!(
                inst.mul_generator_exact(scalar.into()),
                inst.mul_generator_hex(scalar)
            );
        }
        let wide = (num_bigint::BigUint::from(1u8) << 200usize) * inst.r().to_biguint() + 13u8;
        let exact = ExactScalar::from_biguint(&wide).unwrap();
        assert!(exact.checked_u128().is_none());
        assert_eq!(inst.mul_generator_exact(exact), inst.mul_generator_hex(13));
    }

    #[test]
    fn prime_orbit_shapes_keep_the_requested_coefficients_and_freeze_explicitly() {
        for (shape, seed) in [
            ("generic_a_minus_3", 2026110101),
            ("j0_b7", 2026110103),
            ("j1728", 2026110105),
        ] {
            let spec = CurveSpec::PrimeOrbitShape {
                shape: shape.into(),
                bits: 14,
                seed,
            };
            let instance = spec.build().unwrap();
            let Instance::Prime(prime) = &instance else {
                panic!("prime orbit shapes build prime instances")
            };
            match shape {
                "generic_a_minus_3" => assert_eq!(prime.curve.a, prime.curve.p - 3),
                "j0_b7" => assert_eq!((prime.curve.a, prime.curve.b), (0, 7)),
                "j1728" => assert_eq!(prime.curve.b, 0),
                _ => unreachable!(),
            }
            let frozen = spec.for_child(&instance);
            assert!(matches!(frozen, CurveSpec::PrimeExplicit { .. }));
            let Instance::Prime(rebuilt) = frozen.build().unwrap() else {
                panic!()
            };
            assert_eq!(
                (
                    rebuilt.curve.p,
                    rebuilt.curve.a,
                    rebuilt.curve.b,
                    rebuilt.r,
                    rebuilt.generator,
                ),
                (
                    prime.curve.p,
                    prime.curve.a,
                    prime.curve.b,
                    prime.r,
                    prime.generator,
                )
            );
        }
    }

    #[test]
    fn extension_variants_have_distinct_constructors_and_subgroup_arithmetic() {
        for spec in [
            CurveSpec::Fp4Torsion {
                p: 13,
                seed: 1,
                max_cofactor: 16,
            },
            CurveSpec::F2m4Torsion {
                m: 4,
                seed: 1,
                max_cofactor: 16,
            },
            CurveSpec::Fp4Translation { p: 13, seed: 1 },
        ] {
            let encoded = serde_json::to_string(&spec).unwrap();
            assert_eq!(serde_json::from_str::<CurveSpec>(&encoded).unwrap(), spec);
            let inst = spec.build().unwrap();
            let facts = inst.facts(&spec);
            assert_eq!(inst.r(), facts.r);
            assert_eq!(inst.mul_generator_hex(1).unwrap(), facts.generator);
            assert!(inst.mul_generator_hex(0).is_none());
            assert!(inst
                .mul_generator_hex(inst.r().checked_u128().unwrap())
                .is_none());
            assert!(inst.mul_generator_hex(2).is_some());
            assert!(
                inst.hash_to_subgroup(&facts, 1, 0).is_none(),
                "quartic translation and torsion variants retain planted-only policy"
            );
            if !matches!(&inst, Instance::Fp4(_)) {
                // Check subgroup arithmetic on the known fixture 2G, without
                // enabling the deliberately unavailable public-target route.
                let target = inst.mul_generator_hex(2).unwrap();
                assert_eq!(inst.mul_generator_hex(2), Some(target.clone()));
                let x = u64::from_str_radix(target[0].trim_start_matches("0x"), 16).unwrap();
                let y = u64::from_str_radix(target[1].trim_start_matches("0x"), 16).unwrap();
                let mut scratch = GroupOps::default();
                match &inst {
                    Instance::Fp4Torsion(i) => {
                        let c = &i.inst.curve;
                        let point = Pt4 {
                            x: unpack_e4(i.p(), x),
                            y: unpack_e4(i.p(), y),
                            inf: false,
                        };
                        assert!(c.on_curve(&point));
                        assert!(CountedGroup::mul(c, &mut scratch, point, i.r).inf);
                    }
                    Instance::F2m4(i) => {
                        let c = &i.curve;
                        let point = crate::cryptanalysis::gaudry_quartic_bin::PtB {
                            x: c.f.unpack(u128::from(x)),
                            y: c.f.unpack(u128::from(y)),
                            inf: false,
                        };
                        assert!(c.on_curve(&point));
                        assert!(
                            CountedGroup::mul(
                                c,
                                &mut scratch,
                                point,
                                u64::try_from(i.r).expect("small test subgroup order"),
                            )
                            .inf
                        );
                    }
                    _ => unreachable!(),
                }
            }
        }
        assert!(CurveSpec::Fp4Torsion {
            p: 9,
            seed: 1,
            max_cofactor: 16
        }
        .build()
        .is_err());
        assert!(CurveSpec::F2m4Torsion {
            m: 3,
            seed: 1,
            max_cofactor: 16
        }
        .build()
        .is_err());
    }

    /// `registry_index_text` of `scripts/curve_id.py`, restated: the offset
    /// of the value's opening quote of every `"slug": "…"` pair's first
    /// occurrence, ordered by slug.
    fn expected_registry_index(text: &str) -> String {
        let key = "\"slug\"";
        let mut pairs: Vec<(&str, usize)> = Vec::new();
        let mut from = 0;
        while let Some(pos) = text[from..].find(key) {
            let after = from + pos + key.len();
            from = after;
            let Some(rest) = text[after..].trim_start().strip_prefix(':') else {
                continue;
            };
            let rest = rest.trim_start();
            let Some(value) = rest.strip_prefix('"') else {
                continue;
            };
            let Some(end) = value.find('"') else {
                continue;
            };
            if value[..end].contains('\\') {
                continue;
            }
            pairs.push((&value[..end], text.len() - rest.len()));
        }
        pairs.sort_by(|a, b| a.0.cmp(b.0).then(a.1.cmp(&b.1)));
        pairs.dedup_by(|later, first| later.0 == first.0);
        pairs.iter().map(|(_, at)| format!("{at}\n")).collect()
    }

    /// The slug-targeted extraction answers exactly as the full parse:
    /// the first entry carrying the slug, or none.
    #[test]
    fn registry_entry_matches_the_full_parse() {
        let all = registry_curves();
        assert!(all.len() > 100, "the registry is populated");
        for c in all.iter().step_by(97) {
            let slug = c.get("slug").and_then(Value::as_str).unwrap();
            let fast = registry_entry(slug).unwrap_or_else(|| panic!("{slug} not found"));
            let full = all
                .iter()
                .find(|x| x.get("slug").and_then(Value::as_str) == Some(slug))
                .unwrap();
            assert_eq!(&fast, full, "{slug}");
        }
        assert!(registry_entry("icv1-no-such-curve-00000000").is_none());
        // A slug that is a prefix of a real one is not that one.
        let first = all[0].get("slug").and_then(Value::as_str).unwrap();
        assert!(registry_entry(&first[..first.len() - 1]).is_none());
        // The committed index is the one this registry text yields (so a
        // stale index fails here as it fails `check_curve_names.py`), it
        // has one line per entry, and the search finds every line.
        assert_eq!(
            REGISTRY_INDEX,
            expected_registry_index(REGISTRY),
            "registry_index.txt is stale"
        );
        assert_eq!(REGISTRY_INDEX.lines().count(), all.len());
        let mut previous = "";
        for (i, line) in REGISTRY_INDEX.lines().enumerate() {
            let at: usize = line.parse().unwrap();
            let slug = registry_slug_at(at).unwrap();
            assert!(previous < slug, "{slug} out of order at line {i}");
            previous = slug;
            if i % 97 == 0 {
                assert_eq!(registry_index_offset(slug), Some(at), "{slug}");
            }
        }
        assert_eq!(registry_index_offset(""), None);
        assert_eq!(registry_index_offset("icv1-no-such-curve-00000000"), None);
        assert_eq!(registry_index_offset("zzzz"), None);
        // A string with braces and escaped quotes inside is skipped as text.
        assert_eq!(json_object_end(br#"{"a":"}\"{","b":{}}"#, 0), Some(18));
    }

    fn public_fixture() -> CurveSpec {
        CurveSpec::PrimePublicFixture {
            p: 343073,
            a: 36086,
            b: 72172,
            group_order: 342833,
            r: 342833,
            gx: 0,
            gy: 2882,
            qx: 314327,
            qy: 50562,
        }
    }

    #[test]
    fn public_fixture_survives_measured_child_normalization() {
        let spec = public_fixture();
        let (parent, inst) = Workload::build(&spec, 7, 0, TargetKind::Public).unwrap();
        let child = spec.for_child(&inst);
        let rebuilt = Workload::build(&child, 7, 0, TargetKind::Public).unwrap().0;
        assert_eq!(parent.workload_id, rebuilt.workload_id);
        assert_eq!(parent.target, rebuilt.target);
        assert_eq!(rebuilt.kind(), TargetKind::Public);
        assert!(rebuilt.planted.is_none());
    }

    #[test]
    fn fixture_rejects_invalid_points_and_reuse_as_planted_or_multiple_targets() {
        let spec = public_fixture();
        assert!(Workload::build(&spec, 7, 0, TargetKind::Planted).is_err());
        assert!(Workload::build(&spec, 7, 1, TargetKind::Public).is_err());
        let mut value = serde_json::to_value(spec).unwrap();
        value["qx"] = json!(343073);
        assert!(serde_json::from_value::<CurveSpec>(value)
            .unwrap()
            .build()
            .is_err());
    }

    #[test]
    fn public_fixture_rejects_composite_or_impossible_order_claims() {
        for (key, value) in [("p", 343075u64), ("r", 342835), ("r", 17)] {
            let mut v = serde_json::to_value(public_fixture()).unwrap();
            v[key] = json!(value);
            if key == "r" {
                v["group_order"] = json!(value);
            }
            assert!(serde_json::from_value::<CurveSpec>(v)
                .unwrap()
                .build()
                .is_err());
        }
    }

    #[test]
    fn public_fixture_rejects_a_singular_additive_group_despite_hasse_witness() {
        let mut v = serde_json::to_value(public_fixture()).unwrap();
        v["a"] = json!(0);
        v["b"] = json!(0);
        v["r"] = v["p"].clone();
        v["group_order"] = v["p"].clone();
        for key in ["gx", "gy", "qx", "qy"] {
            v[key] = json!(1);
        }
        assert!(serde_json::from_value::<CurveSpec>(v)
            .unwrap()
            .build()
            .is_err());
    }

    #[test]
    fn registered_prime_curve_resolves_its_slug_and_ec1() {
        let spec = CurveSpec::PrimeSearch {
            bits: 20,
            seed: 59297,
        };
        let (w, _) = Workload::build(&spec, 1, 0, TargetKind::Planted).unwrap();
        assert_eq!(w.curve.slug, "icv1-fp20-t727-cd198a38");
        assert!(w.curve.registered);
        assert_eq!(w.curve.ec1.as_deref(), Some("EC1P20Cfphd19e740ea95d"));
        assert!(w.workload_id.starts_with('W') && w.workload_id.len() == 13);
        assert_eq!(w.recompute_id().unwrap(), w.workload_id);
    }

    #[test]
    fn targets_differ_by_index_and_are_stable() {
        let spec = CurveSpec::Koblitz { a: 0, n: 13 };
        let (a, _) = Workload::build(&spec, 7, 0, TargetKind::Planted).unwrap();
        let (b, _) = Workload::build(&spec, 7, 1, TargetKind::Planted).unwrap();
        let (a2, _) = Workload::build(&spec, 7, 0, TargetKind::Planted).unwrap();
        assert_ne!(a.workload_id, b.workload_id);
        assert_eq!(a, a2);
        assert_eq!(a.curve.family, "koblitz");
        assert_eq!(a.curve.automorphisms_available, 26);
    }

    #[test]
    fn public_targets_lie_in_the_subgroup_and_have_no_planted_answer() {
        for spec in [
            CurveSpec::Koblitz { a: 0, n: 13 },
            CurveSpec::PrimeSearch {
                bits: 16,
                seed: 59297,
            },
        ] {
            let (w, inst) = Workload::build(&spec, 7, 0, TargetKind::Public).unwrap();
            let (w1, _) = Workload::build(&spec, 7, 1, TargetKind::Public).unwrap();
            let (p, _) = Workload::build(&spec, 7, 0, TargetKind::Planted).unwrap();
            assert_eq!(w.target_law, PUBLIC_TARGET_LAW);
            assert_eq!(w.kind(), TargetKind::Public);
            assert!(w.planted.is_none() && w.target_counter.is_some());
            assert_ne!(w.workload_id, w1.workload_id);
            assert_ne!(w.workload_id, p.workload_id);
            assert_eq!(w.recompute_id().unwrap(), w.workload_id);
            assert_eq!(
                Workload::build(&spec, 7, 0, TargetKind::Public).unwrap().0,
                w
            );
            // In <G>, by exhaustion on a subgroup this small.
            assert!((1..w.curve.r.checked_u128().unwrap())
                .any(|k| inst.mul_generator_hex(k).as_ref() == Some(&w.target)));
        }
    }

    #[test]
    fn explicit_form_rebuilds_the_same_workload() {
        let spec = CurveSpec::PrimeSearch {
            bits: 16,
            seed: 59297,
        };
        let (w, inst) = Workload::build(&spec, 3, 2, TargetKind::Planted).unwrap();
        let ex = CurveSpec::explicit(&inst).unwrap();
        let (w2, _) = Workload::build(&ex, 3, 2, TargetKind::Planted).unwrap();
        assert_eq!(w.workload_id, w2.workload_id);
        assert_eq!(w.planted, w2.planted);
        let CurveSpec::PrimeExplicit {
            p,
            a,
            b,
            group_order,
            r,
            gx,
            ..
        } = ex
        else {
            unreachable!()
        };
        let bad = CurveSpec::PrimeExplicit {
            p,
            a,
            b,
            group_order,
            r,
            gx,
            gy: 1,
        };
        assert!(bad.build().is_err());
    }

    #[test]
    fn hyperelliptic_explicit_form_rebuilds_the_same_workload_and_serialises() {
        let spec = CurveSpec::HyperellipticThread { p: 23, genus: 3 };
        let (w, inst) = Workload::build(&spec, 3, 1, TargetKind::Planted).unwrap();
        assert_eq!(w.curve.family, "hyperelliptic");
        assert!(!w.curve.registered);
        let ex = CurveSpec::explicit(&inst).unwrap();
        let text = serde_json::to_string(&ex).unwrap();
        assert!(text.contains("\"kind\":\"hyperelliptic_explicit\""));
        let back: CurveSpec = serde_json::from_str(&text).unwrap();
        assert_eq!(back, ex);
        let (w2, _) = Workload::build(&back, 3, 1, TargetKind::Planted).unwrap();
        assert_eq!(w.workload_id, w2.workload_id);
        assert_eq!(w.planted, w2.planted);
        assert_eq!(w.curve.icv1, w2.curve.icv1);
        assert_ne!(model_hash(&w.curve), 0);
        // No public-target law on a Jacobian yet.
        assert!(Workload::build(&spec, 3, 1, TargetKind::Public).is_err());
    }

    #[test]
    fn planted_scalars_are_uniform() {
        // Kolmogorov–Smirnov against U(0, 1) for k / r over 20 000 indices,
        // and the mean distance |k − r/2| / r against its 0.25.  The draw
        // is deterministic, so this is a fixed check of the derivation,
        // not a flaky statistical test.
        let (w, _) = Workload::build(
            &CurveSpec::Koblitz { a: 0, n: 13 },
            0,
            0,
            TargetKind::Planted,
        )
        .unwrap();
        let n = 20_000u64;
        let mut xs: Vec<f64> = (0..n)
            .map(|i| planted_scalar(&w.curve, 20261002, i).unwrap() as f64 / w.curve.r.to_f64())
            .collect();
        xs.sort_by(f64::total_cmp);
        let d = xs
            .iter()
            .enumerate()
            .map(|(i, x)| ((i + 1) as f64 / n as f64 - x).max(x - i as f64 / n as f64))
            .fold(0.0, f64::max);
        // 1.63 / √n is the 1 % critical value.
        assert!(d < 1.63 / (n as f64).sqrt(), "KS D = {d}");
        let gap = xs.iter().map(|x| (x - 0.5).abs()).sum::<f64>() / n as f64;
        assert!((gap - 0.25).abs() < 0.005, "mean gap {gap}");
    }

    #[test]
    fn conductor_gap_pair_shares_order_and_differs_in_j() {
        let crater = CurveSpec::ConductorGap {
            ell: 263,
            t: 241,
            level: GapLevel::Crater,
            seed: 0,
        };
        let floor = CurveSpec::ConductorGap {
            ell: 263,
            t: 241,
            level: GapLevel::Floor,
            seed: 3,
        };
        let (Instance::Prime(c), Instance::Prime(f)) =
            (crater.build().unwrap(), floor.build().unwrap())
        else {
            panic!("conductor_gap builds prime instances");
        };
        assert_eq!(
            (c.curve.p, c.group_order, c.cofactor),
            (343_073, 342_833, 1)
        );
        assert_eq!(
            (f.curve.p, f.group_order, f.cofactor),
            (343_073, 342_833, 1)
        );
        assert_ne!(
            conductor_gap::j_invariant(&c.curve),
            conductor_gap::j_invariant(&f.curve)
        );
        assert_eq!(
            conductor_gap::j_invariant(&c.curve),
            343_073 - 884_736 % 343_073
        );
        // The explicit form a measured child receives rebuilds the same curve.
        let ex = CurveSpec::explicit(&Instance::Prime(f.clone())).unwrap();
        let Instance::Prime(f2) = ex.build().unwrap() else {
            panic!()
        };
        assert_eq!(
            (f2.curve.a, f2.curve.b, f2.generator),
            (f.curve.a, f.curve.b, f.generator)
        );
        assert_eq!(crater.call(), "conductor_gap::crater(params(263, 241))");
        assert!(CurveSpec::ConductorGap {
            ell: 263,
            t: 3,
            level: GapLevel::Crater,
            seed: 0
        }
        .build()
        .is_err());
    }

    #[test]
    fn unusable_koblitz_curve_is_refused() {
        assert!(CurveSpec::Koblitz { a: 0, n: 17 }.build().is_err());
    }
}

#[cfg(test)]
mod merged_variant_tests {
    use super::*;
    #[test]
    fn distinct_quartic_constructors_keep_their_metadata_and_generators() {
        let specs = [
            CurveSpec::Fp4Translation { p: 29, seed: 1 },
            CurveSpec::Fp4Torsion {
                p: 29,
                seed: 1,
                max_cofactor: 16,
            },
            CurveSpec::F2m4Torsion {
                m: 4,
                seed: 1,
                max_cofactor: 16,
            },
        ];
        for spec in specs {
            let i = spec.build().unwrap();
            let facts = i.facts(&spec);
            assert!(facts.r > 2u64.into());
            assert_eq!(i.mul_generator_hex(1).unwrap(), facts.generator);
            assert!(i.mul_generator_hex(i.r().checked_u128().unwrap()).is_none());
            assert_eq!(
                serde_json::from_str::<CurveSpec>(&serde_json::to_string(&spec).unwrap()).unwrap(),
                spec
            );
        }
    }

    #[test]
    fn efd_spec_builds_and_records_the_representation() {
        let spec = CurveSpec::Efd {
            model: "montgom".into(),
            chart: "xz".into(),
            p: 1019,
            params: std::collections::BTreeMap::from([
                ("a".to_string(), 131u64),
                ("b".to_string(), 1u64),
            ]),
            r: 269,
            cofactor: 4,
            generator: vec![604, 1],
            lift: 0,
        };
        let instance = spec.build().unwrap();
        let facts = instance.facts(&spec);
        assert_eq!(facts.family, "prime");
        assert_eq!(facts.r, 269u64.into());
        let (workload, _) = Workload::build(&spec, 1, 0, TargetKind::Planted).unwrap();
        let representation = workload.representation.expect("EFD representation");
        assert_eq!(representation.model, "montgom");
        assert_eq!(representation.chart, "montgom/xz");
        assert_eq!(
            serde_json::from_str::<CurveSpec>(&serde_json::to_string(&spec).unwrap()).unwrap(),
            spec
        );
    }
}

#[cfg(test)]
mod big_koblitz_tests {
    //! The three-word Koblitz class and the scalar laws past `2^128`.
    use super::*;
    use crate::cryptanalysis::koblitz_big::U192;

    fn spec(a: u8, n: u32) -> CurveSpec {
        CurveSpec::Koblitz { a, n }
    }

    /// ECC2K-130's field and K-163 build as big instances, by their
    /// registered moduli, with exact orders past `2^128` in the facts.
    #[test]
    fn big_koblitz_curves_build_with_their_registered_identities() {
        for (a, n, slug, r) in [
            (
                0u8,
                131u32,
                "icv1-f2m131-tm22283658519494248867-115e0dc5",
                "680564733841876926932320129493409985129",
            ),
            (
                1,
                163,
                "icv1-f2m163-tm4845466632539410776804317-e15e581e",
                "5846006549323611672814741753598448348329118574063",
            ),
        ] {
            let s = spec(a, n);
            let inst = s.build().unwrap();
            assert!(matches!(inst, Instance::Big(_)));
            let f = inst.facts(&s);
            assert_eq!(f.slug, slug);
            // The registry document lists the curve (with the modulus the
            // build used).  `f.registered` reads it through
            // `registry_index.txt`, which must be current for the flag to
            // be true.
            assert!(
                registry_curves()
                    .iter()
                    .any(|c| c.get("slug").and_then(Value::as_str) == Some(slug)),
                "{slug} is in docs/curves/registry.json"
            );
            assert_eq!(f.family, "koblitz");
            assert_eq!(f.field_degree, Some(n));
            assert_eq!(f.automorphisms_available, 2 * n);
            assert_eq!(f.r.to_string(), r);
            assert!(f.r.checked_u128().is_none());
            assert_eq!(
                f.group_order.to_biguint(),
                f.r.to_biguint() * f.cofactor.to_biguint()
            );
            assert_eq!(inst.r(), f.r);
            assert_eq!(
                f.construction,
                format!("BigKoblitz::new({a}, registry modulus for n = {n})")
            );
            // The constructor's generator is not the published point.
            assert_eq!(f.ec1, None);
            // [1]G is the generator, [r]G and [0]G the identity.
            assert_eq!(
                inst.mul_generator_exact(ExactScalar::from(1u64)).unwrap(),
                f.generator
            );
            assert!(inst.mul_generator_exact(f.r).is_none());
            assert!(inst.mul_generator_hex(0).is_none());
            // A scalar past r reduces before it multiplies.
            let k = ExactScalar::from_biguint(&(f.r.to_biguint() * 3u8 + 2u8)).unwrap();
            assert_eq!(
                inst.mul_generator_exact(k),
                inst.mul_generator_exact(ExactScalar::from(2u64))
            );
            // The facts serialise the wide orders as decimal strings.
            let v = serde_json::to_value(&f).unwrap();
            assert_eq!(v["r"], serde_json::json!(r));
            assert_eq!(serde_json::from_value::<CurveFacts>(v).unwrap(), f);
        }
        // Degrees 128..=191 with no usable prime are refused, as are a > 1.
        assert!(spec(0, 137).build().is_err());
        assert!(spec(2, 131).build().is_err());
        assert!(spec(0, 192).build().is_err());
    }

    /// The planted law past `2^128`: `1 + D mod (r − 1)` of the whole digest,
    /// `[k]G` the target, the workload serialising and re-deriving its id.
    #[test]
    fn planted_targets_past_2_128_use_the_big_law_and_round_trip() {
        let s = spec(0, 131);
        let inst = s.build().unwrap();
        let mut seen = std::collections::BTreeSet::new();
        for index in 0..4 {
            let w = Workload::on(&s, &inst, 77, index, TargetKind::Planted).unwrap();
            assert_eq!(w.target_law, TARGET_LAW_BIG);
            assert_eq!(w.kind(), TargetKind::Planted);
            let k = w.planted.unwrap();
            assert!(k >= ExactScalar::from(1u64) && k < w.curve.r);
            assert!(seen.insert(k));
            // The law, by hand.
            let parts = [
                model_hash(&w.curve).to_string(),
                w.curve.r.to_string(),
                "77".to_string(),
                index.to_string(),
            ];
            let want =
                derive_biguint(TARGET_LAW_BIG, &parts) % (w.curve.r.to_biguint() - 1u8) + 1u8;
            assert_eq!(k.to_biguint(), want);
            assert_eq!(inst.mul_generator_exact(k).unwrap(), w.target);
            // Q is in the order-r subgroup.
            let Instance::Big(bi) = &inst else {
                unreachable!()
            };
            let q = RawPointG::Affine {
                x: W192::parse_hex(&w.target[0]).unwrap(),
                y: W192::parse_hex(&w.target[1]).unwrap(),
            };
            assert_eq!(bi.rho.scalar_mul(q, bi.kc.r192()), RawPointG::Infinity);
            let text = serde_json::to_string(&w).unwrap();
            assert!(text.contains(&format!("\"planted\":\"{k}\"")));
            let back: Workload = serde_json::from_str(&text).unwrap();
            assert_eq!(back, w);
            assert_eq!(back.recompute_id().unwrap(), w.workload_id);
        }
        assert!(
            Workload::on(&s, &inst, 77, 0, TargetKind::PlantedShared).is_err(),
            "the shared law is one-word only"
        );
    }

    /// The public law past `2^128`: a hashed abscissa lifted to the
    /// subgroup, no planted answer, stable in its inputs.
    #[test]
    fn public_targets_past_2_128_use_the_big_law() {
        for (a, n) in [(0u8, 131u32), (1, 163)] {
            let s = spec(a, n);
            let inst = s.build().unwrap();
            let Instance::Big(bi) = &inst else {
                unreachable!()
            };
            let w = Workload::on(&s, &inst, 5, 1, TargetKind::Public).unwrap();
            assert_eq!(w.target_law, PUBLIC_TARGET_LAW_BIG);
            assert_eq!(w.kind(), TargetKind::Public);
            assert_eq!(w.planted, None);
            let again = Workload::on(&s, &inst, 5, 1, TargetKind::Public).unwrap();
            assert_eq!(again, w);
            let other = Workload::on(&s, &inst, 5, 2, TargetKind::Public).unwrap();
            assert_ne!(other.target, w.target);
            let q = RawPointG::Affine {
                x: W192::parse_hex(&w.target[0]).unwrap(),
                y: W192::parse_hex(&w.target[1]).unwrap(),
            };
            assert_ne!(q, RawPointG::Infinity);
            assert_eq!(bi.rho.scalar_mul(q, bi.kc.r192()), RawPointG::Infinity);
            // The abscissa law by hand: the counter's digest, its low n bits
            // lifted, bit 255 choosing the ordinate, the cofactor cleared.
            let parts = [
                model_hash(&w.curve).to_string(),
                w.curve.r.to_string(),
                "5".to_string(),
                "1".to_string(),
                w.target_counter.unwrap().to_string(),
            ];
            let d = derive_biguint(PUBLIC_TARGET_LAW_BIG, &parts);
            let mask = (num_bigint::BigUint::from(1u8) << n) - 1u8;
            let x = W192::from_biguint(&(&d & &mask)).unwrap();
            let pts = bi.kc.points_with_x(&bi.kc.field(), x);
            let (px, py) = pts[usize::from(d.bit(255) && pts.len() > 1)];
            let h = U192::from_u128(u128::from(bi.kc.cofactor));
            assert_eq!(bi.rho.scalar_mul(RawPointG::Affine { x: px, y: py }, h), q);
        }
    }

    /// The laws of every order that fits a `u128` are the committed ones:
    /// the one-word and the wide planted scalar, recomputed by the formulas
    /// they were written with before the big law existed.
    #[test]
    fn existing_laws_draw_the_scalars_they_always_drew() {
        for s in [spec(0, 41), spec(1, 47), spec(0, 83)] {
            let inst = s.build().unwrap();
            let f = inst.facts(&s);
            let model = model_hash(&f);
            for index in 0..5u64 {
                let (k, law) = planted_scalar_exact(&f, 9, index);
                let want = match f.r.checked_u64() {
                    Some(r) => {
                        assert_eq!(law, TARGET_LAW);
                        u128::from(1 + derive_u64(TARGET_LAW, &[model, r, 9, index]) % (r - 1))
                    }
                    None => {
                        assert_eq!(law, TARGET_LAW_WIDE);
                        let r = f.r.checked_u128().unwrap();
                        let parts = [
                            model.to_string(),
                            r.to_string(),
                            "9".into(),
                            index.to_string(),
                        ];
                        1 + derive_u128(TARGET_LAW_WIDE, &parts) % (r - 1)
                    }
                };
                assert_eq!(k, ExactScalar::from(want));
                assert_eq!(planted_scalar(&f, 9, index), Some(want));
                let w = Workload::on(&s, &inst, 9, index, TargetKind::Planted).unwrap();
                assert_eq!(w.planted, Some(ExactScalar::from(want)));
                assert_eq!(Some(w.target.clone()), inst.mul_generator_hex(want));
            }
        }
    }
}
