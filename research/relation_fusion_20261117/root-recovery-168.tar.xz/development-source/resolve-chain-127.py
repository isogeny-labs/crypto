from pathlib import Path
import re
s=Path('/workspace/chain-merge-125.rs').read_text()
ms=list(re.finditer(r'(?ms)^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',s));assert len(ms)==8
r=[]
r.append('    product_kernel: ChainProductKernel,\n    pub(crate) next: u32,\n')
r.append(ms[1][1])
r.append(ms[2][1].replace('    fn product(', '    pub(crate) fn product('))
r.append(ms[3][2]);r.append(ms[4][2]);r.append(ms[5][2])
r.append('        let mut circuit = Circuit::new_with_kernel(irr, kernel);\n        if fold_constants {\n            circuit.enable_constant_folding();\n        }\n')
r.append(ms[7][2])
for m,t in reversed(list(zip(ms,r))):s=s[:m.start()]+t+s[m.end():]
s=s.replace('impl Circuit {\n','impl Circuit {\n    pub(crate) fn new(irr: &IrreduciblePoly) -> Self {\n        Self::new_with_kernel(irr, ChainProductKernel::Schoolbook)\n    }\n\n',1)
s=s.replace('        fold_constants: bool,\n    ) -> Result<Self, ChainBuildError>', '        fold_constants: bool,\n        kernel: ChainProductKernel,\n    ) -> Result<Self, ChainBuildError>',1)
for common,fold in [('None','false'),('None','true'),('Some(&common)','true')]:
 old=f'            {common},\n            {fold},\n        )'
 new=f'            {common},\n            {fold},\n            ChainProductKernel::Schoolbook,\n        )'
 assert old in s,(common,fold)
 s=s.replace(old,new)
anchor='    /// Constant field multiplication is linear.'
wrapper='''    /// Build the original S3 equations with an explicitly chosen multiplication
    /// circuit. Constant folding remains disabled for these retained kernel arms.
    pub fn build_with_kernel(
        m: usize,
        irr: &IrreduciblePoly,
        b: &F2mElement,
        target_x: Option<&F2mElement>,
        identity_mask: u32,
        max_variables: u32,
        kernel: ChainProductKernel,
    ) -> Result<Self, ChainBuildError> {
        Self::build_internal(m, irr, b, target_x, identity_mask, max_variables, None, false, kernel)
    }

'''
assert anchor in s;s=s.replace(anchor,wrapper+anchor,1)
# Preserve both prior APIs' ordering state, and extend it with the original
# per-adjacent-domain primary data. No approximate domain comparison.
s=s.replace('    all_summands_ordered: bool,','    all_summands_ordered: bool,\n    adjacent_domains_equal: Vec<bool>,\n    adjacent_ordered: Vec<bool>,',1)
s=s.replace('            all_summands_ordered: false,','            all_summands_ordered: false,\n            adjacent_domains_equal: vec![false; m - 1],\n            adjacent_ordered: vec![false; m - 1],',1)
s=s.replace('        self.first_pair_exchangeable = true;','        self.first_pair_exchangeable = true;\n        self.adjacent_domains_equal.fill(true);')
s=s.replace('        self.first_pair_exchangeable = sorted_domains[0] == sorted_domains[1];','        self.first_pair_exchangeable = sorted_domains[0] == sorted_domains[1];\n        self.adjacent_domains_equal = sorted_domains.windows(2).map(|pair| pair[0] == pair[1]).collect();')
s=s.replace('if self.first_pair_ordered || !self.first_pair_exchangeable {','if self.first_pair_ordered || self.adjacent_ordered[0] || !self.first_pair_exchangeable {')
s=s.replace('        self.first_pair_ordered = true;','        self.first_pair_ordered = true;\n        self.adjacent_ordered[0] = true;')
s=s.replace('if self.first_pair_ordered || self.all_summands_ordered || !self.all_summands_exchangeable {','if self.first_pair_ordered || self.all_summands_ordered || self.adjacent_ordered.iter().any(|x| *x) || !self.all_summands_exchangeable {')
s=s.replace('        self.all_summands_ordered = true;','        self.all_summands_ordered = true;\n        self.adjacent_ordered.fill(true);')
c=Path('/workspace/chain-cdaa-126.rs').read_text()
start=c.index('    /// Canonically order every still-unordered adjacent pair')
end=c.index('    fn decode_block',start)
method=c[start:end];assert '    fn decode_block' in s;s=s.replace('    fn decode_block',method+'    fn decode_block',1)
start=c.index('    #[test]\n    fn equal_domain_run_ordering_preserves_first_pair_and_preflights_all_edges')
test=c[start:c.rfind('\n}')]
# The last top-level test module is the original tests module.
s=s[:s.rfind('\n}')]+ '\n'+test+s[s.rfind('\n}'):]
assert '<<<<<<<' not in s
Path('/workspace/chain-resolved-127.rs').write_text(s)
