from pathlib import Path
import re,json
pattern=r'(?ms)^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n'
def resolve(s,choices):
 ms=list(re.finditer(pattern,s));assert len(ms)==len(choices),(len(ms),len(choices))
 for m,choice in reversed(list(zip(ms,choices))):
  value=choice(m) if callable(choice) else m[choice] if isinstance(choice,int) else choice
  s=s[:m.start()]+value+s[m.end():]
 return s
sol=Path('/workspace/ml-solvers-items-116.rs').read_text()
def capabilities(m):
 a=m[1]
 a=a.replace('"m_scope":"base routes; additional supervised profiles are separately gated","supervised_koblitz_m3_profile":','"supervised_wide_prime_dynamic_profile":{"m":[4,15],"modulus_min_inclusive":"4294967296","modulus_max_inclusive":"2305843009213693951","requires_original_execution_context":true,"completion":"replay-gated bounded partials"},"m_scope":"base routes; additional supervised profiles are separately gated","supervised_koblitz_m3_profile":',1)
 a=a.replace('wide-prime elimination under solver id f4 requires supervised context and m2 or m3; m4..15 uses separate f4-wide-dynamic-v1','wide-prime elimination requires original supervised context; m4..15 also retains the bounded legacy f4 route and separate f4-wide-dynamic-v1')
 return a
sol=resolve(sol,[capabilities])
old='        curves::verify_factor_base_config(config, &case.public_instance, &case.factor_base)'
new='''        if case.factor_base["rule"] == "planted-known-log-subgroup/v1" {
            curves::verify_planted(config, case)
        } else {
            curves::verify_factor_base_config(config, &case.public_instance, &case.factor_base)
        }'''
assert old in sol;sol=sol.replace(old,new,1)
# Preserve the later unsupported-policy regression/current guard as well.
current=Path('src/ml_dataset/solvers.rs').read_text()
guard_start=current.index('    if case.factor_base["schema"] == "ml-ecdlp-factor-base/v2"')
guard_end=current.index('    let group = Group::read(case)?;',guard_start)
guard=current[guard_start:guard_end]
if guard not in sol:
 anchor=sol.index('    let group = Group::read(case)?;',sol.index('pub(super) fn solve_with_context'))
 sol=sol[:anchor]+guard+sol[anchor:]
name='    #[test]\n    fn unsupported_factor_base_policy_does_not_become_empty_domain_success()'
start=current.index(name);end=current.index('    #[test]',start+len(name))
test=current[start:end]
anchor='mod tests {\n'
assert anchor in sol;sol=sol.replace(anchor,anchor+test,1)
Path('/workspace/ml-solvers-resolved-130.rs').write_text(sol)
curves=Path('/workspace/ml-curves-items-116.rs').read_text()
curves=resolve(curves,[lambda m:'    if base["schema"] == "ml-ecdlp-factor-base/v2" {\n        return super::factor_bases::verify(public, base);\n    }\n'+m[2]])
Path('/workspace/ml-curves-resolved-130.rs').write_text(curves)
mod=Path('/workspace/ml-mod-items-116.rs').read_text()
mod=resolve(mod,[1,1,1,1,1,lambda m:m[1]+m[2],1])
# Include planted legacy plans only with their original absent policy/channel axes.
old='            "crypto.ml-dataset.plan/v1" if self.channels.is_none() && self.factor_base_policies.is_empty() => false,'
new='            "crypto.ml-dataset.plan/v1" | "crypto.ml-dataset.plan/planted-pdp-v1" if self.channels.is_none() && self.factor_base_policies.is_empty() => false,'
assert old in mod;mod=mod.replace(old,new,1)
old='                schema: if channels.is_some() {"crypto.ml-dataset.plan/v3"}'
new='''                schema: if a.population == "planted-pdp-v1" {
                    if channels.is_some() || !factor_base_policies.is_empty() {
                        return Err("planted plans require their original absent policy/channel axes".into());
                    }
                    PLANTED_PLAN_SCHEMA
                } else if a.population != "natural" {
                    return Err("unknown dataset population".into());
                } else if channels.is_some() {"crypto.ml-dataset.plan/v3"}'''
assert old in mod;mod=mod.replace(old,new,1)
# The line merge correctly combines the inner verifier body; item-level merge
# avoids confusing the new wrapper with that body. Reconcile its two remaining
# conflicts explicitly, and keep all new caller/custody wrappers from ff027.
line=Path('/workspace/ml-mod.rs-merge-112').read_text()
start=line.index('    checked_directory(dir, false)?;',line.index('fn verify_cell_with_replay_session'))
end=line.index('\nfn publication_confirmations',start)
body=line[start:end]
def known(m):
 a=m[1];b=m[2]
 # Preserve the full restricted planted replay, then the bounded natural gate.
 pre=b[:b.index('    } else if replay')]
 return pre+'    } else '+a.lstrip().replace('if replay','if replay',1).replace('        && complete_known_answer','        && !plan.planted()\n        && complete_known_answer',1)
def base(m):
 a=m[1]
 a=a.replace('        curves::verify_factor_base_config(&manifest.config, &public, &base)?;','        if !plan.planted() {\n            curves::verify_factor_base_config(&manifest.config, &public, &base)?;\n        }',1)
 a=a.replace('            && !censored_m3_prefix','            && !censored_m3_prefix\n            && !verified_dynamic',1)
 return a
body=resolve(body,[known,base])
start=mod.index('    checked_directory(dir, false)?;',mod.index('fn verify_cell_with_replay_session'))
end=mod.index('\nfn publication_confirmations',start)
mod=mod[:start]+'    let mut boolean_projection=None;\n'+body+mod[end:]
# ff027 helper supersedes the old artifact loop; retain d4 reserved counter path.
old='        "worker-process.json",\n        "host.json",'
assert old in mod;mod=mod.replace(old,'        "worker-process.json",\n        "whole-worker-counter.json",\n        "host.json",',1)
Path('/workspace/ml-mod-resolved-130.rs').write_text(mod)
