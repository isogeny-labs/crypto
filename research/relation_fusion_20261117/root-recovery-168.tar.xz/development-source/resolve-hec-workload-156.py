from pathlib import Path
import re
s=Path('/workspace/workload-hec-merge-154.rs').read_text();ms=list(re.finditer(r'(?ms)^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',s));assert len(ms)==15
choices=[]
for i,m in enumerate(ms):
 a,b=m[1],m[2]
 if i in [0,1,2,4,5]:r=a+b
 elif i==3:r=a.replace('| Instance::Ext(_) => None,','| Instance::Ext(_)\n            | Instance::Hec(_) => None,',1)
 elif i==6:r=a.replace('    pub group_order: ExactScalar,','    /// HEC thread Jacobian order/cofactor zero means unknown.\n    pub group_order: ExactScalar,',1)
 elif i==7:r=a+'            Instance::Hec(i) => u128::from(i.r),\n'
 elif i==8:
  # Both complete early returns are preserved. Add a complete HEC return
  # before the current Big return, sharing neither closing brace.
  h=b+'            };\n        }\n';h=h.replace('group_order: 0,','group_order: 0u64.into(),').replace('r: u128::from(i.r),','r: i.r.into(),').replace('cofactor: 0,','cofactor: 0u64.into(),');r=h+a
 elif i in [9,11]:r=a.replace('| Instance::Hyper(_)','| Instance::Hyper(_)\n            | Instance::Hec(_)',1)
 elif i==10:r=a.replace('        if let Instance::Hyper(i) = self {','        if let Instance::Hec(i) = self {\n            return i.mul_generator_hex(k);\n        }\n        if let Instance::Hyper(i) = self {',1)
 elif i==12:r=a.replace('| Instance::Hyper(_) = self','| Instance::Hyper(_)\n        | Instance::Hec(_) = self',1)
 elif i==13:r=a.replace('| Instance::Hyper(_) => {','| Instance::Hyper(_)\n                | Instance::Hec(_) => {',1)
 elif i==14:r=a
 else:raise ValueError(i)
 choices.append(r)
for m,r in reversed(list(zip(ms,choices))):s=s[:m.start()]+r+s[m.end():]
# Replace the entire Workload::on unit with the current complete implementation
# plus the primary HEC branch, avoiding a falsely aligned scalar/public tail.
current=Path('/workspace/workload-current-153.rs').read_text()
start=current.index('    pub fn on(');end=current.index('    /// The target\'s kind',start)
on=current[start:end]
anchor='                TargetKind::Public => {'
branch='''                TargetKind::PlantedHecThread => {
                    let Instance::Hec(i) = inst else { return Err(NOT_HEC.into()); };
                    let k = thread_scalar(i.r, index);
                    let q = inst.mul_generator_hex(k).ok_or("k gave the identity")?;
                    (HEC_THREAD_TARGET_LAW, q, Some(ExactScalar::from(k)), None)
                }
                TargetKind::Public if matches!(inst, Instance::Hec(_)) => {
                    return Err(HEC_NO_PUBLIC.into());
                }
'''
assert anchor in on;on=on.replace(anchor,branch+anchor,1)
start=s.index('    pub fn on(');end=s.index('    /// The target\'s kind',start);s=s[:start]+on+s[end:]
# The primitive-counted target transport must use the same HEC arithmetic.
anchor='        if let Instance::Hyper(i) = self {\n            return i.mul_generator_hex(k);'
assert anchor in s
# Keep all existing families, including large Koblitz, exact scalar conversion
# and counted hashing. Additional missing exhaustive arms are checked by rustc.
assert '<<<<<<<' not in s
Path('/workspace/workload-hec-resolved-156.rs').write_text(s)
