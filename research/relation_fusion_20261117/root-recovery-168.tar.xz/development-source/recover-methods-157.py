from pathlib import Path
import subprocess
p=Path('src/cryptanalysis/ecbench/methods.rs');s=p.read_text();primary=subprocess.check_output(['git','show','8c37d9a6e7:src/cryptanalysis/ecbench/methods.rs'],text=True)
s=s.replace('use crate::cryptanalysis::ecbench::full_price;','use crate::cryptanalysis::ecbench::full_price;\nuse crate::cryptanalysis::ecbench::hec;',1)
a=primary.index('/// The arm\'s solver seed:');b=primary.index('const RHO_PARAMS:',a);s=s.replace('const RHO_PARAMS:',primary[a:b]+'const RHO_PARAMS:',1)
a=primary.index('        MethodDecl {\n            id: "hec.ic_fb_walk"');b=primary.index('        MethodDecl {\n            id: "ic.pipeline"',a);s=s.replace('        MethodDecl {\n            id: "ic.pipeline"',primary[a:b]+'        MethodDecl {\n            id: "ic.pipeline"',1)
a=primary.index('    if let Instance::Hec(i) = inst {');b=primary.index('    if m.id == "ic.k4_gaudry"',a)
s=s.replace('    if let Instance::Ext(i) = inst {',primary[a:b]+'    if let Instance::Ext(i) = inst {',1)
s=s.replace('        | (Instance::Hyper(_), _) => {','        | (Instance::Hyper(_), _)\n        | (Instance::Hec(_), _) => {',1)
s=s.replace('    if let Instance::Fp4Torsion(_) | Instance::F2m4(_) = &inst {','    if let Instance::Fp4Torsion(_) | Instance::F2m4(_) | Instance::Hec(_) = &inst {',1)
s=s.replace('        | Instance::Hyper(_)\n        | Instance::ThreeLeads(_) => unreachable!("returned above"),','        | Instance::Hyper(_)\n        | Instance::Hec(_) => unreachable!("returned above"),',1)
p.write_text(s)
p=Path('src/ml_dataset/solvers.rs');s=p.read_text().replace('pub(super) enum OwnedReplayVerdict {\n    CheckedScope,','pub(super) enum OwnedReplayVerdict {\n    CheckedScope,\n    HistoricalCheckedScope,',1).replace('            Verdict::CheckedScope => OwnedReplayVerdict::CheckedScope,','            Verdict::CheckedScope => OwnedReplayVerdict::CheckedScope,\n            Verdict::HistoricalCheckedScope => OwnedReplayVerdict::HistoricalCheckedScope,',1);p.write_text(s)
p=Path('src/cryptanalysis/genus_ladder.rs');s=p.read_text().replace('            invmod(h % r, r)\n','''            let Some(inverse) = invmod(h % r, r) else {
                // Unit-T cannot recover log T when the cofactor is not a unit.
                res.la_wied.merge(w_nat);
                res.la.merge(w_nat);
                res.exhausted = true;
                break 'outer;
            };
            inverse
''',1);p.write_text(s)
