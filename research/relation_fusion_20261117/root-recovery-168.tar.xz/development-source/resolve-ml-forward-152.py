from pathlib import Path
import re
pat=r'(?ms)^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n'
def apply(s,choices):
 ms=list(re.finditer(pat,s));assert len(ms)==len(choices)
 for m,c in reversed(list(zip(ms,choices))):
  v=m[c] if isinstance(c,int) else c(m)
  s=s[:m.start()]+v+s[m.end():]
 return s
mod=Path('/workspace/ml-mod-forward-151.rs').read_text()
mod=apply(mod,[2,2,2,2,2,2])
# Keep current population axis as well as the later primary owned-replay fields.
mod=mod.replace('            protocol_sha256:None,\n        })}).unwrap();','            protocol_sha256:None,population:"natural".into(),\n        })}).unwrap();',1)
# Preserve both overlapping Unix/Linux guard tests without dropping assertions.
old='''    fn supervisor_guard_reaps_child_on_error_path() {
        use std::os::unix::process::CommandExt;'''
new='''    fn plain_snapshot_guard_reaps_child_on_error_path() {
        use std::os::unix::process::CommandExt;
        use std::process::Command;'''
assert old in mod;mod=mod.replace(old,new,1)
old='''        drop(SupervisedChild {
            child,
            finished: false,
        });'''
assert old in mod;mod=mod.replace(old,'        drop(live::snapshot_child_for_test(child));',1)
Path('src/ml_dataset/mod.rs').write_text(mod)
sol=apply(Path('/workspace/ml-solvers-forward-151.rs').read_text(),[2,2,2]);Path('src/ml_dataset/solvers.rs').write_text(sol)
types=apply(Path('/workspace/ml-types-forward-151.rs').read_text(),[1]);Path('src/ml_dataset/types.rs').write_text(types)
def projection(m):return m[1]+'                    None\n                } else '+m[2].lstrip().replace('let inputs = if','if',1)
def version(m):
 return m[2].replace('structural_allowlist_version(&plan)','if planted {"strict-structural-allowlist-v7-planted"} else {structural_allowlist_version(&plan)}').replace('"only_features_jsonl_is_model_input":false,','"cross_population_pooling_permitted":false,"only_features_jsonl_is_model_input":false,')
export=apply(Path('/workspace/ml-export-forward-151.rs').read_text(),[projection,version]);Path('src/ml_dataset/export.rs').write_text(export)
p=Path('src/ml_dataset/live.rs');s=p.read_text();s+='''\n#[cfg(test)]
pub(super) fn snapshot_child_for_test(child: Child) -> impl Sized {
    SnapshotChild { child, finished: false }
}
''';p.write_text(s)
