from pathlib import Path
import json,re
rows={x['path']:x['items'] for x in map(json.loads,Path('/workspace/sat-item-index-134.jsonl').read_text().splitlines())}
def off(s,pos):return sum(len(l) for l in s.splitlines(keepends=True)[:pos[0]-1])+pos[1]
def method(path,name):
 s=Path(path).read_text();impl=next(x for x in rows[path] if x['key']=='impl::Solver:construct-search');i=next(x for x in impl['children'] if x['key']=='method:'+name)
 return s[off(s,i['start']):off(s,i['end'])]
s=Path('/workspace/sat-items-135.rs').read_text();a='/workspace/sat-current-132.rs';c='/workspace/sat-ff027-131.rs'
# Replace whole method units, avoiding accidental movement of accounting code
# into legacy helpers. Both actual primary implementations remain intact.
for name,next_name in [('propagate_xors','propagate'),('reduce_db','propagate_root')]:
 # The exact next item is selected from the source index, not a text heuristic.
 key='method:'+name;items=next(x for x in rows[a] if x['key']=='impl::Solver:construct-search')['children'];idx=next(i for i,x in enumerate(items) if x['key']==key)
 legacy=method(a,name).replace('fn '+name+'(', 'fn '+name+'_legacy(',1)
 admitted=method(c,name).replace('fn '+name+'(', 'fn '+name+'_admitted(',1)
 # Find this method in the unresolved item merge and its end at the next method.
 signature='fn '+name+'('
 start=s.index(signature);line=s.rfind('\n',0,start)+1
 # Leading method docs were preserved outside the replacement.
 next_candidates=[x['key'].split(':',1)[1] for x in items[idx+1:] if x['key'].startswith('method:')]
 end=None
 for candidate in next_candidates:
  m=re.search(r'(?m)^(?:pub(?:\([^)]*\))? )?(?:unsafe )?fn '+re.escape(candidate)+r'(?:<|\()',s[start:])
  if m:
   end=start+m.start();break
 assert end is not None,name
 # Any leading docs/attributes of the next method stay with it. The original
 # source index reconstructed this layout without indentation at item boundaries.
 segment=s[line:end]
 # Count structural brace balance after resolving the method conflicts only.
 clean=re.sub(r'(?ms)^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',lambda m:m[1],segment)
 # The segment can include helper methods added on either branch; do not replace
 # them. Find the closing method brace with a source lexer via syn after resolving
 # the conflict, then use that exact span in a temporary parsed method wrapper.
 temp=Path('/workspace/sat-method-'+name+'-137.rs');temp.write_text('impl Solver {\n'+clean+'\n}\n')
 import subprocess
 result=subprocess.check_output(['/workspace/source-item-index/target/release/source-item-index',str(temp)],text=True)
 parsed=json.loads(result)['items'][0]['children'][0];text=temp.read_text();code=text[off(text,parsed['start']):off(text,parsed['end'])]
 # Primary merge segment is the conflicted method followed by untouched helpers.
 # Locate the last source brace before the first next method using its parsed
 # counterpart; all conflict blocks lie inside the first method.
 clean_tail=clean[clean.index(code)+len(code):]
 if name=='propagate_xors':
  dispatcher='fn propagate_xors(&mut self) -> XorStep {\n if self.native_admission.is_some() { self.propagate_xors_admitted() } else { self.propagate_xors_legacy() }\n}\n'
 else:
  dispatcher='fn reduce_db(&mut self) {\n if self.native_admission.is_some() { self.reduce_db_admitted() } else { self.reduce_db_legacy() }\n}\n'
 s=s[:line]+dispatcher+'\n'+legacy+'\n\n'+admitted+'\n'+clean_tail+s[end:]
# Retain phase/storage diagnostics around every exit of the original public
# wrapper, and transplant the exact native admission/acknowledgement guards.
wrapper=method(a,'solve_with_lazy_clauses')
wrapper=wrapper.replace('            if self.event_failure.is_some() {','            if self.event_failure.is_some() || self.native_failure.is_some() {')
wrapper=wrapper.replace('        let result = (|| {','        let result = (|| {\n            if !self.native_entry(!trigger_vars.is_empty()) { return SolveResult::Unknown; }',1)
wrapper=wrapper.replace('                self.emit(SolverEvent::SolveBegin {','                if !self.native_event_payload(0, 0) { return SolveResult::Unknown; }\n                self.emit(SolverEvent::SolveBegin {',1)
wrapper=wrapper.replace('                self.emit(SolverEvent::SolveEnd {','                if !self.native_event_payload(16, 1) { return SolveResult::Unknown; }\n                self.emit(SolverEvent::SolveEnd {',1)
wrapper=wrapper.replace('            if self.event_failure.is_some() || self.native_failure.is_some() {\n                SolveResult::Unknown','            if !self.native_charge(NativeOperation::Entry, 0) { return SolveResult::Unknown; }\n            if self.event_failure.is_some() || self.native_failure.is_some() {\n                SolveResult::Unknown',1)
# Its only remaining conflict is the wrapper body; preserve the generic signature.
m=list(re.finditer(r'(?ms)^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',s));assert len(m)==1
s=re.sub(r'(?ms)^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',lambda m:m[1],s)
temp=Path('/workspace/sat-clean-wrapper-137.rs');temp.write_text(s)
import subprocess
parsed=json.loads(subprocess.check_output(['/workspace/source-item-index/target/release/source-item-index',str(temp)],text=True))
impls=[x for x in parsed['items'] if x['key']=='impl::Solver']
item=next(x for i in impls for x in i['children'] if x['key']=='method:solve_with_lazy_clauses')
start,end=off(s,item['start']),off(s,item['end'])
s=s[:start]+wrapper+s[end:]
assert '<<<<<<<' not in s
Path('/workspace/sat-resolved-137.rs').write_text(s)
