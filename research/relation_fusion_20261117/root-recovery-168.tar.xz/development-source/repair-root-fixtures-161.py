from pathlib import Path
import json,re
edits=json.loads(Path('/workspace/root-fixture-edits-159.json').read_text())
for path in dict.fromkeys(x['path'] for x in edits):
 p=Path(path);s=p.read_text();lines=s.splitlines(keepends=True)
 def off(lc):return sum(map(len,lines[:lc[0]-1]))+lc[1]
 for x in sorted([x for x in edits if x['path']==path],key=lambda x:off(x['start']),reverse=True):
  a,b=off(x['start']),off(x['end'])
  if x['kind']=='duplicate':
   assert s[b]==',';b+=1
  s=s[:a]+x['text']+s[b:]
 p.write_text(s)
def change(path,old,new):
 p=Path(path);s=p.read_text();assert old in s,(path,old);p.write_text(s.replace(old,new,1))
change('src/cryptanalysis/ecbench/methods.rs','fn phase_of(','pub(crate) fn phase_of(')
change('src/cryptanalysis/ecbench/hashed_native.rs','assert_eq!(a.recovered, Some(3));','assert_eq!(a.recovered, Some(3u64.into()));')
change('src/cryptanalysis/ecbench/hec.rs','assert_eq!(w.curve.r, 1321);','assert_eq!(w.curve.r, 1321u64.into());')
change('src/cryptanalysis/ecbench/hec.rs','inst.mul_generator_hex(k).as_ref()','inst.mul_generator_exact(k).as_ref()')
change('src/cryptanalysis/ecbench/hec.rs','assert_eq!(w.planted, Some(447));','assert_eq!(w.planted, Some(447u64.into()));')
change('src/cryptanalysis/ecbench/orbit_ic.rs','Some(u128::from(scalar))','Some(u128::from(scalar).into())')
change('src/cryptanalysis/ecbench/orbit_ic.rs','assert_eq!(rep.recovered, Some(123));','assert_eq!(rep.recovered, Some(123u64.into()));')
change('src/cryptanalysis/gaudry_quartic_bin_wide/tests.rs','old_point(narrow.mul(&p, k))','old_point(narrow.mul(&p, u128::from(k)))')
for f in ['group_order','r','cofactor']:
 change('src/cryptanalysis/ic_framework/mod.rs',f'{f}: u128::from(inst.{f}),',f'{f}: u128::from(inst.{f}).into(),')
change('src/cryptanalysis/curve_traits/mod.rs','registry_sha256: "abc".into(),','catalog: cover_catalog::MANIFEST_PATH.into(),\n            catalog_rows_sha256: "abc".into(),')
p=Path('src/cryptanalysis/curve_traits/query.rs');s=p.read_text()
s=s.replace('        let inputs = [\n            ("docs/curves/registry.json", include_str!("../../../docs/curves/registry.json")),','''        let catalog = include_str!("../../../docs/curves/cover-catalog.json");
        let rows = crate::cryptanalysis::cover_catalog::restrict(
            include_str!("../../../docs/curves/registry.json"), catalog
        ).unwrap();
        let inputs = [
            ("docs/curves/registry.json (rows named by docs/curves/cover-catalog.json)", rows.as_str()),
            ("docs/curves/cover-catalog.json", catalog),''',1)
s=s.replace('assert_eq!(file.registry_sha256, digests[0].sha256);','''assert_eq!(file.catalog, crate::cryptanalysis::cover_catalog::MANIFEST_PATH);
        assert_eq!(file.catalog_rows_sha256, digests[0].sha256);''',1);p.write_text(s)
# Latest primary source is a superset of the original616 implementation, with
# complete Ferrari/SGE routing and their original latest tests. Retain our
# checked no-inverse refusal in place of the primary's assertion.
p=Path('src/cryptanalysis/genus_ladder.rs');current=p.read_text();source=Path('/workspace/genus-cd125-160.rs').read_text()
a=current.index('            let Some(inverse) = invmod(h % r, r) else {');b=current.index('\n        } else {',a)
source=source.replace('            invmod(h % r, r).expect("h is a unit modulo the prime r")',current[a:b],1)
p.write_text(source)
