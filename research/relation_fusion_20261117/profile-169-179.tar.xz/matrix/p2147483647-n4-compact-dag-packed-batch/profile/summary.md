# cpu profile: p2147483647-n4-compact-dag-packed-batch

- status: **ok**
- command: `/workspace/relation-native-qualifiers/fusion-96/fused-native compact-dag packed packed-batch /workspace/fusion-profile-matrix-169/p2147483647-n4-compact-dag-packed-batch/proof`
- binary: `/workspace/relation-native-qualifiers/fusion-96/fused-native` sha256 `559d6d7591e37970…`
- commit: `da0157df0c2c` (6 dirty tracked files)
- host: AMD EPYC 9V74 80-Core Processor, 1 logical CPUs, kernel 6.18.57, PMU absent, perf_event_paranoid 2
- valgrind: valgrind-3.24.0
- isolation: none; wall 0.460 s (profiled run: not a timing measurement)
- started: 2026-11-17T11:13:51Z

## Hotspots (callgrind, self Ir)

Total: 13123458 Ir (deterministic, simulated; not cycles).

| # | self % | Ir | function | object |
|---|---:|---:|---|---|
| 1 | 12.06 | 1582484 | `certified_relations::axpy_in_place::<alloc::vec::Vec<usize>>` | fused-native |
| 2 | 7.19 | 944085 | `free` | libc.so.6 |
| 3 | 4.6 | 603369 | `malloc` | libc.so.6 |
| 4 | 4.03 | 529496 | `<alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<usize>, core::slice::iter::Iter<usize>>, certified_relations::plus::{closure#0}>>>::from_iter` | fused-native |
| 5 | 3.72 | 488192 | `0x00000000000a0fe0` | libc.so.6 |
| 6 | 3.54 | 464506 | `<relation_replay_checker::packed::Arithmetic<2147483647>>::identity` | fused-native |
| 7 | 3.21 | 421418 | `certified_relations::normal_form` | fused-native |
| 8 | 2.7 | 354970 | `<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Owned, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::LeafOrInternal>>::bulk_push::<alloc::collections::btree::dedup_sorted_iter::DedupSortedIter<alloc::vec::Vec<usize>, u64, alloc::vec::into_iter::IntoIter<(alloc::vec::Vec<usize>, u64)>>, alloc::alloc::Global>` | fused-native |
| 9 | 2.38 | 311825 | `certified_relations::lead` | fused-native |
| 10 | 2.37 | 311358 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Keys<alloc::vec::Vec<usize>, u64>, certified_relations::degree::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::cmp::Ord>::max>` | fused-native |
| 11 | 2.25 | 295838 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::remove::<alloc::vec::Vec<usize>>` | fused-native |
| 12 | 2.23 | 292061 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::insert` | fused-native |
| 13 | 2.16 | 283133 | `0x00000000000a02e0` | libc.so.6 |
| 14 | 2.06 | 270941 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<(alloc::vec::Vec<usize>, u64), <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)>>::extend_trusted<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 15 | 1.69 | 221833 | `certified_relations::axpy_owned::<u128>` | fused-native |
| 16 | 1.49 | 195453 | `<alloc::collections::btree::map::IntoIter<alloc::vec::Vec<usize>, u64>>::dying_next` | fused-native |
| 17 | 1.48 | 194622 | `0x0000000000162880` | libc.so.6 |
| 18 | 1.43 | 187164 | `core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(alloc::vec::Vec<usize>, u64), <[(alloc::vec::Vec<usize>, u64)]>::sort_by<<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64> as core::iter::traits::collect::FromIterator<(alloc::vec::Vec<usize>, u64)>>::from_iter<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 19 | 1.32 | 173455 | `certified_relations::quotient::rewrite` | fused-native |
| 20 | 1.16 | 152009 | `<serde_json::de::Deserializer<serde_json::read::SliceRead>>::parse_integer` | fused-native |
| 21 | 1.13 | 147954 | `certified_relations::verify` | fused-native |
| 22 | 1.11 | 145171 | `<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_key::<str>` | fused-native |
| 23 | 1.1 | 144034 | `core::str::converts::from_utf8` | fused-native |
| 24 | 1 | 131238 | `__rustc::__rdl_alloc` | fused-native |
| 25 | 0.92 | 120842 | `<alloc::collections::btree::node::Handle<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Dying, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::Leaf>, alloc::collections::btree::node::marker::Edge>>::deallocating_next::<alloc::alloc::Global>` | fused-native |

## Files

- `annotate-inclusive.txt`
- `annotate.txt`
- `callgrind.out`
- `command.stderr`
- `command.stdout`
- `hotspots.json`
- `hotspots.svg`
- `manifest.json`

Raw profiler output (perf.data, *.ncu-rep, *.nsys-rep, callgrind.out) is large: push it with `crypto store push` (AGENTS.md section 13) rather than committing it.
