# cpu profile: p9007199254740881-n6-compact-sparse-packed-batch

- status: **ok**
- command: `/workspace/relation-native-qualifiers/fusion-85/fused-native compact-sparse packed packed-batch /workspace/fusion-profile-matrix-169/p9007199254740881-n6-compact-sparse-packed-batch/proof`
- binary: `/workspace/relation-native-qualifiers/fusion-85/fused-native` sha256 `6b689556a5c764a7…`
- commit: `da0157df0c2c` (6 dirty tracked files)
- host: AMD EPYC 9V74 80-Core Processor, 1 logical CPUs, kernel 6.18.57, PMU absent, perf_event_paranoid 2
- valgrind: valgrind-3.24.0
- isolation: none; wall 0.500 s (profiled run: not a timing measurement)
- started: 2026-11-17T11:14:09Z

## Hotspots (callgrind, self Ir)

Total: 22094796 Ir (deterministic, simulated; not cycles).

| # | self % | Ir | function | object |
|---|---:|---:|---|---|
| 1 | 12.88 | 2845807 | `certified_relations::axpy_in_place::<alloc::vec::Vec<usize>>` | fused-native |
| 2 | 6.37 | 1407707 | `free` | libc.so.6 |
| 3 | 4.35 | 961092 | `<alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<usize>, core::slice::iter::Iter<usize>>, certified_relations::plus::{closure#0}>>>::from_iter` | fused-native |
| 4 | 4.07 | 899298 | `malloc` | libc.so.6 |
| 5 | 3.6 | 796307 | `<relation_replay_checker::packed::Arithmetic<9007199254740881>>::identity` | fused-native |
| 6 | 3.5 | 772482 | `0x00000000000a0fe0` | libc.so.6 |
| 7 | 3.49 | 770578 | `certified_relations::normal_form` | fused-native |
| 8 | 2.72 | 600421 | `certified_relations::lead` | fused-native |
| 9 | 2.59 | 572942 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Keys<alloc::vec::Vec<usize>, u64>, certified_relations::degree::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::cmp::Ord>::max>` | fused-native |
| 10 | 2.45 | 541279 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::insert` | fused-native |
| 11 | 2.42 | 534470 | `<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Owned, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::LeafOrInternal>>::bulk_push::<alloc::collections::btree::dedup_sorted_iter::DedupSortedIter<alloc::vec::Vec<usize>, u64, alloc::vec::into_iter::IntoIter<(alloc::vec::Vec<usize>, u64)>>, alloc::alloc::Global>` | fused-native |
| 12 | 2.4 | 530323 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::remove::<alloc::vec::Vec<usize>>` | fused-native |
| 13 | 2.14 | 472598 | `__umodti3` | fused-native |
| 14 | 1.94 | 429665 | `0x00000000000a02e0` | libc.so.6 |
| 15 | 1.88 | 415269 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<(alloc::vec::Vec<usize>, u64), <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)>>::extend_trusted<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 16 | 1.65 | 364278 | `core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(alloc::vec::Vec<usize>, u64), <[(alloc::vec::Vec<usize>, u64)]>::sort_by<<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64> as core::iter::traits::collect::FromIterator<(alloc::vec::Vec<usize>, u64)>>::from_iter<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 17 | 1.47 | 325177 | `<serde_json::de::Deserializer<serde_json::read::SliceRead>>::parse_integer` | fused-native |
| 18 | 1.43 | 314952 | `0x0000000000162880` | libc.so.6 |
| 19 | 1.31 | 290377 | `certified_relations::axpy_in_place::<(usize, alloc::vec::Vec<usize>)>` | fused-native |
| 20 | 1.3 | 287593 | `<alloc::collections::btree::map::IntoIter<alloc::vec::Vec<usize>, u64>>::dying_next` | fused-native |
| 21 | 1.29 | 284757 | `certified_relations::quotient::rewrite` | fused-native |
| 22 | 1.17 | 258193 | `certified_relations::axpy_owned::<u128>` | fused-native |
| 23 | 1.02 | 226409 | `certified_relations::verify` | fused-native |
| 24 | 0.98 | 216825 | `<serde_json::de::SeqAccess<_> as serde_core::de::SeqAccess>::next_element_seed::has_next_element::<serde_json::read::SliceRead>` | fused-native |
| 25 | 0.97 | 213502 | `core::str::converts::from_utf8` | fused-native |

## Files

- `annotate-inclusive.txt`
- `annotate.txt`
- `callgrind.out`
- `command.stderr`
- `command.stdout`
- `hotspots.json`
- `hotspots.svg`
- `manifest.json`

Raw profiler output (perf.data, *.ncu-rep, *.nsys-rep, callgrind.out) is large: push it with `crypto store push` (AGENTS.md section 13) rather than committing it.
