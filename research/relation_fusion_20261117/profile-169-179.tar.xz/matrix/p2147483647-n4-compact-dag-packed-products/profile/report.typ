#set page(paper: "a4", margin: 1.5cm)
#set text(size: 9pt)
#show raw: set text(size: 8pt)
#set table(stroke: 0.4pt + luma(180), inset: 3.5pt)
#show table: set text(size: 7.5pt)

= cpu profile: p2147483647-n4-compact-dag-packed-products

- status: *ok*
- command: #raw("/workspace/relation-native-qualifiers/fusion-96/fused-native compact-dag packed packed-products /workspace/fusion-profile-matrix-169/p2147483647-n4-compact-dag-packed-products/proof")
- binary: #raw("/workspace/relation-native-qualifiers/fusion-96/fused-native") sha256 #raw("559d6d7591e37970…")
- commit: #raw("da0157df0c2c") (6 dirty tracked files)
- host: AMD EPYC 9V74 80-Core Processor, 1 logical CPUs, kernel 6.18.57, PMU absent, perf\_event\_paranoid 2
- valgrind: valgrind-3.24.0
- isolation: none; wall 0.590 s (profiled run: not a timing measurement)
- started: 2026-11-17T11:13:50Z

== Hotspots (callgrind, self Ir)

Total: 13322432 Ir (deterministic, simulated; not cycles).

#table(columns: 5,
  [*\#*],  [*self %*],  [*Ir*],  [*function*],  [*object*],
  [1],  [12.03],  [1603150],  [#raw("certified_relations::axpy_in_place::<alloc::vec::Vec<usize>>")],  [fused-native],
  [2],  [7.25],  [966215],  [#raw("free")],  [libc.so.6],
  [3],  [4.65],  [618902],  [#raw("malloc")],  [libc.so.6],
  [4],  [4.08],  [544104],  [#raw("<alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<usize>, core::slice::iter::Iter<usize>>, certified_relations::plus::{closure#0}>>>::from_iter")],  [fused-native],
  [5],  [3.7],  [492910],  [#raw("0x00000000000a0fe0")],  [libc.so.6],
  [6],  [3.49],  [464506],  [#raw("<relation_replay_checker::packed::Arithmetic<2147483647>>::identity")],  [fused-native],
  [7],  [3.16],  [421418],  [#raw("certified_relations::normal_form")],  [fused-native],
  [8],  [2.71],  [361354],  [#raw("<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Owned, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::LeafOrInternal>>::bulk_push::<alloc::collections::btree::dedup_sorted_iter::DedupSortedIter<alloc::vec::Vec<usize>, u64, alloc::vec::into_iter::IntoIter<(alloc::vec::Vec<usize>, u64)>>, alloc::alloc::Global>")],  [fused-native],
  [9],  [2.38],  [316926],  [#raw("<core::iter::adapters::map::Map<alloc::collections::btree::map::Keys<alloc::vec::Vec<usize>, u64>, certified_relations::degree::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::cmp::Ord>::max>")],  [fused-native],
  [10],  [2.38],  [316532],  [#raw("certified_relations::lead")],  [fused-native],
  [11],  [2.25],  [300114],  [#raw("<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::remove::<alloc::vec::Vec<usize>>")],  [fused-native],
  [12],  [2.21],  [294359],  [#raw("<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::insert")],  [fused-native],
  [13],  [2.19],  [291495],  [#raw("0x00000000000a02e0")],  [libc.so.6],
  [14],  [2.08],  [276875],  [#raw("<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<(alloc::vec::Vec<usize>, u64), <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)>>::extend_trusted<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>")],  [fused-native],
  [15],  [1.67],  [221833],  [#raw("certified_relations::axpy_owned::<u128>")],  [fused-native],
  [16],  [1.5],  [199672],  [#raw("<alloc::collections::btree::map::IntoIter<alloc::vec::Vec<usize>, u64>>::dying_next")],  [fused-native],
  [17],  [1.48],  [196614],  [#raw("0x0000000000162880")],  [libc.so.6],
  [18],  [1.43],  [190044],  [#raw("core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(alloc::vec::Vec<usize>, u64), <[(alloc::vec::Vec<usize>, u64)]>::sort_by<<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64> as core::iter::traits::collect::FromIterator<(alloc::vec::Vec<usize>, u64)>>::from_iter<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>")],  [fused-native],
  [19],  [1.33],  [177622],  [#raw("certified_relations::quotient::rewrite")],  [fused-native],
  [20],  [1.14],  [152009],  [#raw("<serde_json::de::Deserializer<serde_json::read::SliceRead>>::parse_integer")],  [fused-native],
  [21],  [1.14],  [151714],  [#raw("certified_relations::verify")],  [fused-native],
  [22],  [1.09],  [145171],  [#raw("<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_key::<str>")],  [fused-native],
  [23],  [1.08],  [144064],  [#raw("core::str::converts::from_utf8")],  [fused-native],
  [24],  [1.01],  [134631],  [#raw("__rustc::__rdl_alloc")],  [fused-native],
  [25],  [0.92],  [122803],  [#raw("<alloc::collections::btree::node::Handle<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Dying, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::Leaf>, alloc::collections::btree::node::marker::Edge>>::deallocating_next::<alloc::alloc::Global>")],  [fused-native],
)

== Files

- #raw("annotate-inclusive.txt")
- #raw("annotate.txt")
- #raw("callgrind.out")
- #raw("command.stderr")
- #raw("command.stdout")
- #raw("hotspots.json")
- #raw("hotspots.svg")
- #raw("manifest.json")

Raw profiler output (perf.data, \*.ncu-rep, \*.nsys-rep, callgrind.out) is large: push it with #raw("crypto store push") (AGENTS.md section 13) rather than committing it.

== Graphs

#figure(image("hotspots.svg", width: 100%))

