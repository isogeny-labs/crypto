# cpu profile: p2147483647-n6-compact-sparse-packed-batch

- status: **ok**
- command: `/workspace/relation-native-qualifiers/fusion-85/fused-native compact-sparse packed packed-batch /workspace/fusion-profile-matrix-169/p2147483647-n6-compact-sparse-packed-batch/proof`
- binary: `/workspace/relation-native-qualifiers/fusion-85/fused-native` sha256 `6b689556a5c764a7…`
- commit: `da0157df0c2c` (6 dirty tracked files)
- host: AMD EPYC 9V74 80-Core Processor, 1 logical CPUs, kernel 6.18.57, PMU absent, perf_event_paranoid 2
- valgrind: valgrind-3.24.0
- isolation: none; wall 0.500 s (profiled run: not a timing measurement)
- started: 2026-11-17T11:13:54Z

## Hotspots (callgrind, self Ir)

Total: 21676739 Ir (deterministic, simulated; not cycles).

| # | self % | Ir | function | object |
|---|---:|---:|---|---|
| 1 | 13.36 | 2897035 | `certified_relations::axpy_in_place::<alloc::vec::Vec<usize>>` | fused-native |
| 2 | 6.49 | 1407704 | `free` | libc.so.6 |
| 3 | 4.43 | 961092 | `<alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<usize>, core::slice::iter::Iter<usize>>, certified_relations::plus::{closure#0}>>>::from_iter` | fused-native |
| 4 | 4.15 | 899298 | `malloc` | libc.so.6 |
| 5 | 3.61 | 783001 | `certified_relations::normal_form` | fused-native |
| 6 | 3.56 | 772482 | `0x00000000000a0fe0` | libc.so.6 |
| 7 | 3.3 | 715398 | `<relation_replay_checker::packed::Arithmetic<2147483647>>::identity` | fused-native |
| 8 | 2.77 | 600421 | `certified_relations::lead` | fused-native |
| 9 | 2.64 | 572942 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Keys<alloc::vec::Vec<usize>, u64>, certified_relations::degree::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::cmp::Ord>::max>` | fused-native |
| 10 | 2.5 | 541279 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::insert` | fused-native |
| 11 | 2.47 | 534470 | `<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Owned, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::LeafOrInternal>>::bulk_push::<alloc::collections::btree::dedup_sorted_iter::DedupSortedIter<alloc::vec::Vec<usize>, u64, alloc::vec::into_iter::IntoIter<(alloc::vec::Vec<usize>, u64)>>, alloc::alloc::Global>` | fused-native |
| 12 | 2.45 | 530323 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::remove::<alloc::vec::Vec<usize>>` | fused-native |
| 13 | 1.98 | 429710 | `0x00000000000a02e0` | libc.so.6 |
| 14 | 1.92 | 415269 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<(alloc::vec::Vec<usize>, u64), <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)>>::extend_trusted<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 15 | 1.68 | 364278 | `core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(alloc::vec::Vec<usize>, u64), <[(alloc::vec::Vec<usize>, u64)]>::sort_by<<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64> as core::iter::traits::collect::FromIterator<(alloc::vec::Vec<usize>, u64)>>::from_iter<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 16 | 1.46 | 315916 | `0x0000000000162880` | libc.so.6 |
| 17 | 1.36 | 294135 | `certified_relations::axpy_in_place::<(usize, alloc::vec::Vec<usize>)>` | fused-native |
| 18 | 1.33 | 287593 | `<alloc::collections::btree::map::IntoIter<alloc::vec::Vec<usize>, u64>>::dying_next` | fused-native |
| 19 | 1.31 | 284757 | `certified_relations::quotient::rewrite` | fused-native |
| 20 | 1.25 | 271403 | `<serde_json::de::Deserializer<serde_json::read::SliceRead>>::parse_integer` | fused-native |
| 21 | 1.19 | 256871 | `certified_relations::axpy_owned::<u128>` | fused-native |
| 22 | 1.04 | 226409 | `certified_relations::verify` | fused-native |
| 23 | 1 | 216825 | `<serde_json::de::SeqAccess<_> as serde_core::de::SeqAccess>::next_element_seed::has_next_element::<serde_json::read::SliceRead>` | fused-native |
| 24 | 0.98 | 213179 | `core::str::converts::from_utf8` | fused-native |
| 25 | 0.97 | 211168 | `<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_key::<str>` | fused-native |

## Files

- `annotate-inclusive.txt`
- `annotate.txt`
- `callgrind.out`
- `command.stderr`
- `command.stdout`
- `hotspots.json`
- `hotspots.svg`
- `manifest.json`

Raw profiler output (perf.data, *.ncu-rep, *.nsys-rep, callgrind.out) is large: push it with `crypto store push` (AGENTS.md section 13) rather than committing it.
