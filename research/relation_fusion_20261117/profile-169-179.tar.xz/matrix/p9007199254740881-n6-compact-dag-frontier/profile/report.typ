#set page(paper: "a4", margin: 1.5cm)
#set text(size: 9pt)
#show raw: set text(size: 8pt)
#set table(stroke: 0.4pt + luma(180), inset: 3.5pt)
#show table: set text(size: 7.5pt)

= cpu profile: p9007199254740881-n6-compact-dag-frontier

- status: *ok*
- command: #raw("/workspace/relation-native-qualifiers/fusion-96/fused-native compact-dag packed frontier /workspace/fusion-profile-matrix-169/p9007199254740881-n6-compact-dag-frontier/proof")
- binary: #raw("/workspace/relation-native-qualifiers/fusion-96/fused-native") sha256 #raw("559d6d7591e37970…")
- commit: #raw("da0157df0c2c") (6 dirty tracked files)
- host: AMD EPYC 9V74 80-Core Processor, 1 logical CPUs, kernel 6.18.57, PMU absent, perf\_event\_paranoid 2
- valgrind: valgrind-3.24.0
- isolation: none; wall 0.485 s (profiled run: not a timing measurement)
- started: 2026-11-17T11:14:10Z

== Hotspots (callgrind, self Ir)

Total: 21833387 Ir (deterministic, simulated; not cycles).

#table(columns: 5,
  [*\#*],  [*self %*],  [*Ir*],  [*function*],  [*object*],
  [1],  [13.27],  [2898362],  [#raw("certified_relations::axpy_in_place::<alloc::vec::Vec<usize>>")],  [fused-native],
  [2],  [6.83],  [1491239],  [#raw("free")],  [libc.so.6],
  [3],  [4.7],  [1026927],  [#raw("<alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<usize>, core::slice::iter::Iter<usize>>, certified_relations::plus::{closure#0}>>>::from_iter")],  [fused-native],
  [4],  [4.36],  [952303],  [#raw("malloc")],  [libc.so.6],
  [5],  [3.98],  [869802],  [#raw("certified_relations::normal_form")],  [fused-native],
  [6],  [3.38],  [738172],  [#raw("<relation_replay_checker::packed::Arithmetic<9007199254740881>>::identity")],  [fused-native],
  [7],  [3.23],  [704769],  [#raw("0x00000000000a0fe0")],  [libc.so.6],
  [8],  [2.91],  [635916],  [#raw("certified_relations::lead")],  [fused-native],
  [9],  [2.9],  [633487],  [#raw("<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::insert")],  [fused-native],
  [10],  [2.47],  [538720],  [#raw("<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Owned, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::LeafOrInternal>>::bulk_push::<alloc::collections::btree::dedup_sorted_iter::DedupSortedIter<alloc::vec::Vec<usize>, u64, alloc::vec::into_iter::IntoIter<(alloc::vec::Vec<usize>, u64)>>, alloc::alloc::Global>")],  [fused-native],
  [11],  [2.45],  [534291],  [#raw("<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::remove::<alloc::vec::Vec<usize>>")],  [fused-native],
  [12],  [2.43],  [530646],  [#raw("<core::iter::adapters::map::Map<alloc::collections::btree::map::Keys<alloc::vec::Vec<usize>, u64>, certified_relations::degree::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::cmp::Ord>::max>")],  [fused-native],
  [13],  [2.2],  [481306],  [#raw("__umodti3")],  [fused-native],
  [14],  [2.06],  [448851],  [#raw("<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<(alloc::vec::Vec<usize>, u64), <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)>>::extend_trusted<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>")],  [fused-native],
  [15],  [1.93],  [421200],  [#raw("0x00000000000a02e0")],  [libc.so.6],
  [16],  [1.62],  [354153],  [#raw("core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(alloc::vec::Vec<usize>, u64), <[(alloc::vec::Vec<usize>, u64)]>::sort_by<<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64> as core::iter::traits::collect::FromIterator<(alloc::vec::Vec<usize>, u64)>>::from_iter<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>")],  [fused-native],
  [17],  [1.49],  [325021],  [#raw("<serde_json::de::Deserializer<serde_json::read::SliceRead>>::parse_integer")],  [fused-native],
  [18],  [1.44],  [313836],  [#raw("0x0000000000162880")],  [libc.so.6],
  [19],  [1.4],  [305438],  [#raw("<alloc::collections::btree::map::IntoIter<alloc::vec::Vec<usize>, u64>>::dying_next")],  [fused-native],
  [20],  [1.37],  [298477],  [#raw("certified_relations::quotient::rewrite")],  [fused-native],
  [21],  [1],  [217575],  [#raw("<serde_json::de::SeqAccess<_> as serde_core::de::SeqAccess>::next_element_seed::has_next_element::<serde_json::read::SliceRead>")],  [fused-native],
  [22],  [0.97],  [212267],  [#raw("core::str::converts::from_utf8")],  [fused-native],
  [23],  [0.96],  [210074],  [#raw("<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_key::<str>")],  [fused-native],
  [24],  [0.95],  [207648],  [#raw("__rustc::__rdl_alloc")],  [fused-native],
  [25],  [0.93],  [202041],  [#raw("certified_relations::axpy_in_place::<(usize, alloc::vec::Vec<usize>)>")],  [fused-native],
)

== Files

- #raw("annotate-inclusive.txt")
- #raw("annotate.txt")
- #raw("callgrind.out")
- #raw("command.stderr")
- #raw("command.stdout")
- #raw("hotspots.json")
- #raw("hotspots.svg")
- #raw("manifest.json")

Raw profiler output (perf.data, \*.ncu-rep, \*.nsys-rep, callgrind.out) is large: push it with #raw("crypto store push") (AGENTS.md section 13) rather than committing it.

== Graphs

#figure(image("hotspots.svg", width: 100%))

