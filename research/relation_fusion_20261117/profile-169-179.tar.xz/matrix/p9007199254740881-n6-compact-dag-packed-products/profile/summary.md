# cpu profile: p9007199254740881-n6-compact-dag-packed-products

- status: **ok**
- command: `/workspace/relation-native-qualifiers/fusion-96/fused-native compact-dag packed packed-products /workspace/fusion-profile-matrix-169/p9007199254740881-n6-compact-dag-packed-products/proof`
- binary: `/workspace/relation-native-qualifiers/fusion-96/fused-native` sha256 `559d6d7591e37970…`
- commit: `da0157df0c2c` (6 dirty tracked files)
- host: AMD EPYC 9V74 80-Core Processor, 1 logical CPUs, kernel 6.18.57, PMU absent, perf_event_paranoid 2
- valgrind: valgrind-3.24.0
- isolation: none; wall 0.452 s (profiled run: not a timing measurement)
- started: 2026-11-17T11:14:11Z

## Hotspots (callgrind, self Ir)

Total: 21082897 Ir (deterministic, simulated; not cycles).

| # | self % | Ir | function | object |
|---|---:|---:|---|---|
| 1 | 12.01 | 2532200 | `certified_relations::axpy_in_place::<alloc::vec::Vec<usize>>` | fused-native |
| 2 | 6.51 | 1371576 | `free` | libc.so.6 |
| 3 | 4.15 | 875422 | `malloc` | libc.so.6 |
| 4 | 4.13 | 871695 | `<alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<usize>, core::slice::iter::Iter<usize>>, certified_relations::plus::{closure#0}>>>::from_iter` | fused-native |
| 5 | 4.13 | 869802 | `certified_relations::normal_form` | fused-native |
| 6 | 3.5 | 738172 | `<relation_replay_checker::packed::Arithmetic<9007199254740881>>::identity` | fused-native |
| 7 | 3.24 | 682463 | `0x00000000000a0fe0` | libc.so.6 |
| 8 | 3.02 | 635916 | `certified_relations::lead` | fused-native |
| 9 | 2.53 | 533350 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::remove::<alloc::vec::Vec<usize>>` | fused-native |
| 10 | 2.52 | 530746 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Keys<alloc::vec::Vec<usize>, u64>, certified_relations::degree::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::cmp::Ord>::max>` | fused-native |
| 11 | 2.44 | 514567 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::insert` | fused-native |
| 12 | 2.33 | 491190 | `<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Owned, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::LeafOrInternal>>::bulk_push::<alloc::collections::btree::dedup_sorted_iter::DedupSortedIter<alloc::vec::Vec<usize>, u64, alloc::vec::into_iter::IntoIter<(alloc::vec::Vec<usize>, u64)>>, alloc::alloc::Global>` | fused-native |
| 13 | 2.28 | 481306 | `__umodti3` | fused-native |
| 14 | 1.85 | 390637 | `0x00000000000a02e0` | libc.so.6 |
| 15 | 1.8 | 379193 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<(alloc::vec::Vec<usize>, u64), <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)>>::extend_trusted<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 16 | 1.6 | 336744 | `core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(alloc::vec::Vec<usize>, u64), <[(alloc::vec::Vec<usize>, u64)]>::sort_by<<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64> as core::iter::traits::collect::FromIterator<(alloc::vec::Vec<usize>, u64)>>::from_iter<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 17 | 1.54 | 325021 | `<serde_json::de::Deserializer<serde_json::read::SliceRead>>::parse_integer` | fused-native |
| 18 | 1.5 | 316140 | `0x0000000000162880` | libc.so.6 |
| 19 | 1.42 | 298647 | `certified_relations::quotient::rewrite` | fused-native |
| 20 | 1.4 | 294680 | `<alloc::collections::btree::map::IntoIter<alloc::vec::Vec<usize>, u64>>::dying_next` | fused-native |
| 21 | 1.22 | 258193 | `certified_relations::axpy_owned::<u128>` | fused-native |
| 22 | 1.03 | 217575 | `<serde_json::de::SeqAccess<_> as serde_core::de::SeqAccess>::next_element_seed::has_next_element::<serde_json::read::SliceRead>` | fused-native |
| 23 | 1.01 | 212337 | `core::str::converts::from_utf8` | fused-native |
| 24 | 1 | 210074 | `<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_key::<str>` | fused-native |
| 25 | 0.91 | 190809 | `__rustc::__rdl_alloc` | fused-native |

## Files

- `annotate-inclusive.txt`
- `annotate.txt`
- `callgrind.out`
- `command.stderr`
- `command.stdout`
- `hotspots.json`
- `hotspots.svg`
- `manifest.json`

Raw profiler output (perf.data, *.ncu-rep, *.nsys-rep, callgrind.out) is large: push it with `crypto store push` (AGENTS.md section 13) rather than committing it.
