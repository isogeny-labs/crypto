# cpu profile: p9007199254740881-n3-compact-dag-frontier

- status: **ok**
- command: `/workspace/relation-native-qualifiers/fusion-96/fused-native compact-dag packed frontier /workspace/fusion-profile-matrix-169/p9007199254740881-n3-compact-dag-frontier/proof`
- binary: `/workspace/relation-native-qualifiers/fusion-96/fused-native` sha256 `559d6d7591e37970…`
- commit: `da0157df0c2c` (6 dirty tracked files)
- host: AMD EPYC 9V74 80-Core Processor, 1 logical CPUs, kernel 6.18.57, PMU absent, perf_event_paranoid 2
- valgrind: valgrind-3.24.0
- isolation: none; wall 0.384 s (profiled run: not a timing measurement)
- started: 2026-11-17T11:14:00Z

## Hotspots (callgrind, self Ir)

Total: 11025210 Ir (deterministic, simulated; not cycles).

| # | self % | Ir | function | object |
|---|---:|---:|---|---|
| 1 | 12.87 | 1419164 | `certified_relations::axpy_in_place::<alloc::vec::Vec<usize>>` | fused-native |
| 2 | 7.8 | 859493 | `free` | libc.so.6 |
| 3 | 4.99 | 550489 | `malloc` | libc.so.6 |
| 4 | 4.51 | 497576 | `<alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<usize>, core::slice::iter::Iter<usize>>, certified_relations::plus::{closure#0}>>>::from_iter` | fused-native |
| 5 | 3.91 | 431281 | `0x00000000000a0fe0` | libc.so.6 |
| 6 | 3.7 | 408106 | `<relation_replay_checker::packed::Arithmetic<9007199254740881>>::identity` | fused-native |
| 7 | 3.06 | 336880 | `<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Owned, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::LeafOrInternal>>::bulk_push::<alloc::collections::btree::dedup_sorted_iter::DedupSortedIter<alloc::vec::Vec<usize>, u64, alloc::vec::into_iter::IntoIter<(alloc::vec::Vec<usize>, u64)>>, alloc::alloc::Global>` | fused-native |
| 8 | 2.69 | 296758 | `__umodti3` | fused-native |
| 9 | 2.56 | 282322 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::insert` | fused-native |
| 10 | 2.56 | 282108 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<(alloc::vec::Vec<usize>, u64), <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)>>::extend_trusted<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 11 | 2.15 | 236810 | `certified_relations::normal_form` | fused-native |
| 12 | 2.1 | 231801 | `0x00000000000a02e0` | libc.so.6 |
| 13 | 2.01 | 221871 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Keys<alloc::vec::Vec<usize>, u64>, certified_relations::degree::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::cmp::Ord>::max>` | fused-native |
| 14 | 1.88 | 207225 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::remove::<alloc::vec::Vec<usize>>` | fused-native |
| 15 | 1.73 | 190482 | `certified_relations::lead` | fused-native |
| 16 | 1.46 | 161306 | `<alloc::collections::btree::map::IntoIter<alloc::vec::Vec<usize>, u64>>::dying_next` | fused-native |
| 17 | 1.34 | 147954 | `core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(alloc::vec::Vec<usize>, u64), <[(alloc::vec::Vec<usize>, u64)]>::sort_by<<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64> as core::iter::traits::collect::FromIterator<(alloc::vec::Vec<usize>, u64)>>::from_iter<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 18 | 1.34 | 147274 | `0x0000000000162880` | libc.so.6 |
| 19 | 1.26 | 138972 | `<alloc::collections::btree::node::Handle<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Dying, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::Leaf>, alloc::collections::btree::node::marker::Edge>>::deallocating_next::<alloc::alloc::Global>` | fused-native |
| 20 | 1.21 | 133342 | `certified_relations::verify` | fused-native |
| 21 | 1.19 | 131648 | `<serde_json::de::Deserializer<serde_json::read::SliceRead>>::parse_integer` | fused-native |
| 22 | 1.1 | 121624 | `certified_relations::quotient::rewrite` | fused-native |
| 23 | 1.09 | 119736 | `__rustc::__rdl_alloc` | fused-native |
| 24 | 1.03 | 113469 | `<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_key::<str>` | fused-native |
| 25 | 1.01 | 111015 | `0x0000000000162120` | libc.so.6 |

## Files

- `annotate-inclusive.txt`
- `annotate.txt`
- `callgrind.out`
- `command.stderr`
- `command.stdout`
- `hotspots.json`
- `hotspots.svg`
- `manifest.json`

Raw profiler output (perf.data, *.ncu-rep, *.nsys-rep, callgrind.out) is large: push it with `crypto store push` (AGENTS.md section 13) rather than committing it.
