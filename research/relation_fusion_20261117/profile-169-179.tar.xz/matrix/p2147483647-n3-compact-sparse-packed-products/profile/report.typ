#set page(paper: "a4", margin: 1.5cm)
#set text(size: 9pt)
#show raw: set text(size: 8pt)
#set table(stroke: 0.4pt + luma(180), inset: 3.5pt)
#show table: set text(size: 7.5pt)

= cpu profile: p2147483647-n3-compact-sparse-packed-products

- status: *ok*
- command: #raw("/workspace/relation-native-qualifiers/fusion-85/fused-native compact-sparse packed packed-products /workspace/fusion-profile-matrix-169/p2147483647-n3-compact-sparse-packed-products/proof")
- binary: #raw("/workspace/relation-native-qualifiers/fusion-85/fused-native") sha256 #raw("6b689556a5c764a7…")
- commit: #raw("da0157df0c2c") (6 dirty tracked files)
- host: AMD EPYC 9V74 80-Core Processor, 1 logical CPUs, kernel 6.18.57, PMU absent, perf\_event\_paranoid 2
- valgrind: valgrind-3.24.0
- isolation: none; wall 0.536 s (profiled run: not a timing measurement)
- started: 2026-11-17T11:13:41Z

== Hotspots (callgrind, self Ir)

Total: 11611736 Ir (deterministic, simulated; not cycles).

#table(columns: 5,
  [*\#*],  [*self %*],  [*Ir*],  [*function*],  [*object*],
  [1],  [12.84],  [1490723],  [#raw("certified_relations::axpy_in_place::<alloc::vec::Vec<usize>>")],  [fused-native],
  [2],  [7.32],  [849911],  [#raw("free")],  [libc.so.6],
  [3],  [4.72],  [547918],  [#raw("malloc")],  [libc.so.6],
  [4],  [4.36],  [506668],  [#raw("0x00000000000a0fe0")],  [libc.so.6],
  [5],  [4.31],  [500774],  [#raw("<alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<usize>, core::slice::iter::Iter<usize>>, certified_relations::plus::{closure#0}>>>::from_iter")],  [fused-native],
  [6],  [3.61],  [419118],  [#raw("<relation_replay_checker::packed::Arithmetic<2147483647>>::identity")],  [fused-native],
  [7],  [3.04],  [353012],  [#raw("<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Owned, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::LeafOrInternal>>::bulk_push::<alloc::collections::btree::dedup_sorted_iter::DedupSortedIter<alloc::vec::Vec<usize>, u64, alloc::vec::into_iter::IntoIter<(alloc::vec::Vec<usize>, u64)>>, alloc::alloc::Global>")],  [fused-native],
  [8],  [2.57],  [298034],  [#raw("0x00000000000a02e0")],  [libc.so.6],
  [9],  [2.36],  [273660],  [#raw("<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<(alloc::vec::Vec<usize>, u64), <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)>>::extend_trusted<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>")],  [fused-native],
  [10],  [2.28],  [264631],  [#raw("<core::iter::adapters::map::Map<alloc::collections::btree::map::Keys<alloc::vec::Vec<usize>, u64>, certified_relations::degree::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::cmp::Ord>::max>")],  [fused-native],
  [11],  [2.02],  [234238],  [#raw("<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::insert")],  [fused-native],
  [12],  [1.92],  [223224],  [#raw("certified_relations::axpy_in_place::<(usize, alloc::vec::Vec<usize>)>")],  [fused-native],
  [13],  [1.86],  [216462],  [#raw("<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::remove::<alloc::vec::Vec<usize>>")],  [fused-native],
  [14],  [1.76],  [204314],  [#raw("certified_relations::axpy_owned::<u128>")],  [fused-native],
  [15],  [1.54],  [178813],  [#raw("certified_relations::verify")],  [fused-native],
  [16],  [1.49],  [173248],  [#raw("certified_relations::lead")],  [fused-native],
  [17],  [1.48],  [171775],  [#raw("certified_relations::normal_form")],  [fused-native],
  [18],  [1.35],  [157068],  [#raw("core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(alloc::vec::Vec<usize>, u64), <[(alloc::vec::Vec<usize>, u64)]>::sort_by<<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64> as core::iter::traits::collect::FromIterator<(alloc::vec::Vec<usize>, u64)>>::from_iter<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>")],  [fused-native],
  [19],  [1.35],  [156582],  [#raw("0x0000000000162880")],  [libc.so.6],
  [20],  [1.33],  [154154],  [#raw("<alloc::collections::btree::map::IntoIter<alloc::vec::Vec<usize>, u64>>::dying_next")],  [fused-native],
  [21],  [1.14],  [132460],  [#raw("<alloc::collections::btree::node::Handle<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Dying, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::Leaf>, alloc::collections::btree::node::marker::Edge>>::deallocating_next::<alloc::alloc::Global>")],  [fused-native],
  [22],  [1.09],  [126502],  [#raw("0x0000000000162120")],  [libc.so.6],
  [23],  [1.05],  [121692],  [#raw("certified_relations::quotient::rewrite")],  [fused-native],
  [24],  [1.03],  [119052],  [#raw("__rustc::__rdl_alloc")],  [fused-native],
  [25],  [0.99],  [114547],  [#raw("<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_key::<str>")],  [fused-native],
)

== Files

- #raw("annotate-inclusive.txt")
- #raw("annotate.txt")
- #raw("callgrind.out")
- #raw("command.stderr")
- #raw("command.stdout")
- #raw("hotspots.json")
- #raw("hotspots.svg")
- #raw("manifest.json")

Raw profiler output (perf.data, \*.ncu-rep, \*.nsys-rep, callgrind.out) is large: push it with #raw("crypto store push") (AGENTS.md section 13) rather than committing it.

== Graphs

#figure(image("hotspots.svg", width: 100%))

