# cpu profile: p9007199254740881-n3-compact-dag-packed-products

- status: **ok**
- command: `/workspace/relation-native-qualifiers/fusion-96/fused-native compact-dag packed packed-products /workspace/fusion-profile-matrix-169/p9007199254740881-n3-compact-dag-packed-products/proof`
- binary: `/workspace/relation-native-qualifiers/fusion-96/fused-native` sha256 `559d6d7591e37970…`
- commit: `da0157df0c2c` (6 dirty tracked files)
- host: AMD EPYC 9V74 80-Core Processor, 1 logical CPUs, kernel 6.18.57, PMU absent, perf_event_paranoid 2
- valgrind: valgrind-3.24.0
- isolation: none; wall 0.420 s (profiled run: not a timing measurement)
- started: 2026-11-17T11:14:01Z

## Hotspots (callgrind, self Ir)

Total: 10489108 Ir (deterministic, simulated; not cycles).

| # | self % | Ir | function | object |
|---|---:|---:|---|---|
| 1 | 11.15 | 1169558 | `certified_relations::axpy_in_place::<alloc::vec::Vec<usize>>` | fused-native |
| 2 | 7.3 | 765189 | `free` | libc.so.6 |
| 3 | 4.67 | 490253 | `malloc` | libc.so.6 |
| 4 | 3.99 | 418630 | `0x00000000000a0fe0` | libc.so.6 |
| 5 | 3.89 | 408106 | `<relation_replay_checker::packed::Arithmetic<9007199254740881>>::identity` | fused-native |
| 6 | 3.81 | 399504 | `<alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<usize>, core::slice::iter::Iter<usize>>, certified_relations::plus::{closure#0}>>>::from_iter` | fused-native |
| 7 | 2.83 | 296758 | `__umodti3` | fused-native |
| 8 | 2.83 | 296436 | `<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Owned, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::LeafOrInternal>>::bulk_push::<alloc::collections::btree::dedup_sorted_iter::DedupSortedIter<alloc::vec::Vec<usize>, u64, alloc::vec::into_iter::IntoIter<(alloc::vec::Vec<usize>, u64)>>, alloc::alloc::Global>` | fused-native |
| 9 | 2.26 | 236810 | `certified_relations::normal_form` | fused-native |
| 10 | 2.15 | 225716 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<(alloc::vec::Vec<usize>, u64), <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)>>::extend_trusted<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 11 | 2.12 | 221911 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Keys<alloc::vec::Vec<usize>, u64>, certified_relations::degree::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::cmp::Ord>::max>` | fused-native |
| 12 | 2.06 | 216060 | `0x00000000000a02e0` | libc.so.6 |
| 13 | 1.97 | 207121 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::remove::<alloc::vec::Vec<usize>>` | fused-native |
| 14 | 1.97 | 206674 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::insert` | fused-native |
| 15 | 1.96 | 205378 | `certified_relations::axpy_owned::<u128>` | fused-native |
| 16 | 1.82 | 190482 | `certified_relations::lead` | fused-native |
| 17 | 1.45 | 152168 | `<alloc::collections::btree::map::IntoIter<alloc::vec::Vec<usize>, u64>>::dying_next` | fused-native |
| 18 | 1.38 | 144974 | `0x0000000000162880` | libc.so.6 |
| 19 | 1.27 | 133342 | `certified_relations::verify` | fused-native |
| 20 | 1.26 | 132228 | `core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(alloc::vec::Vec<usize>, u64), <[(alloc::vec::Vec<usize>, u64)]>::sort_by<<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64> as core::iter::traits::collect::FromIterator<(alloc::vec::Vec<usize>, u64)>>::from_iter<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 21 | 1.26 | 131648 | `<serde_json::de::Deserializer<serde_json::read::SliceRead>>::parse_integer` | fused-native |
| 22 | 1.16 | 121692 | `certified_relations::quotient::rewrite` | fused-native |
| 23 | 1.08 | 113469 | `<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_key::<str>` | fused-native |
| 24 | 1.05 | 110091 | `core::str::converts::from_utf8` | fused-native |
| 25 | 1.02 | 106542 | `__rustc::__rdl_alloc` | fused-native |

## Files

- `annotate-inclusive.txt`
- `annotate.txt`
- `callgrind.out`
- `command.stderr`
- `command.stdout`
- `hotspots.json`
- `hotspots.svg`
- `manifest.json`

Raw profiler output (perf.data, *.ncu-rep, *.nsys-rep, callgrind.out) is large: push it with `crypto store push` (AGENTS.md section 13) rather than committing it.
