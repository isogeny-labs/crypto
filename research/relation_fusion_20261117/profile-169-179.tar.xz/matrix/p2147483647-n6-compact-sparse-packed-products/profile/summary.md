# cpu profile: p2147483647-n6-compact-sparse-packed-products

- status: **ok**
- command: `/workspace/relation-native-qualifiers/fusion-85/fused-native compact-sparse packed packed-products /workspace/fusion-profile-matrix-169/p2147483647-n6-compact-sparse-packed-products/proof`
- binary: `/workspace/relation-native-qualifiers/fusion-85/fused-native` sha256 `6b689556a5c764a7…`
- commit: `da0157df0c2c` (6 dirty tracked files)
- host: AMD EPYC 9V74 80-Core Processor, 1 logical CPUs, kernel 6.18.57, PMU absent, perf_event_paranoid 2
- valgrind: valgrind-3.24.0
- isolation: none; wall 0.470 s (profiled run: not a timing measurement)
- started: 2026-11-17T11:13:53Z

## Hotspots (callgrind, self Ir)

Total: 22131800 Ir (deterministic, simulated; not cycles).

| # | self % | Ir | function | object |
|---|---:|---:|---|---|
| 1 | 13.31 | 2945471 | `certified_relations::axpy_in_place::<alloc::vec::Vec<usize>>` | fused-native |
| 2 | 6.57 | 1453871 | `free` | libc.so.6 |
| 3 | 4.49 | 993960 | `<alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<usize>, core::slice::iter::Iter<usize>>, certified_relations::plus::{closure#0}>>>::from_iter` | fused-native |
| 4 | 4.21 | 930871 | `malloc` | libc.so.6 |
| 5 | 3.55 | 785438 | `0x00000000000a0fe0` | libc.so.6 |
| 6 | 3.54 | 783001 | `certified_relations::normal_form` | fused-native |
| 7 | 3.23 | 715398 | `<relation_replay_checker::packed::Arithmetic<2147483647>>::identity` | fused-native |
| 8 | 2.76 | 611870 | `certified_relations::lead` | fused-native |
| 9 | 2.65 | 585946 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Keys<alloc::vec::Vec<usize>, u64>, certified_relations::degree::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::cmp::Ord>::max>` | fused-native |
| 10 | 2.48 | 547766 | `<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Owned, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::LeafOrInternal>>::bulk_push::<alloc::collections::btree::dedup_sorted_iter::DedupSortedIter<alloc::vec::Vec<usize>, u64, alloc::vec::into_iter::IntoIter<(alloc::vec::Vec<usize>, u64)>>, alloc::alloc::Global>` | fused-native |
| 11 | 2.47 | 546883 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::insert` | fused-native |
| 12 | 2.44 | 540603 | `<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::remove::<alloc::vec::Vec<usize>>` | fused-native |
| 13 | 2.03 | 448663 | `0x00000000000a02e0` | libc.so.6 |
| 14 | 1.93 | 427137 | `<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<(alloc::vec::Vec<usize>, u64), <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)>>::extend_trusted<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 15 | 1.68 | 371952 | `core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(alloc::vec::Vec<usize>, u64), <[(alloc::vec::Vec<usize>, u64)]>::sort_by<<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64> as core::iter::traits::collect::FromIterator<(alloc::vec::Vec<usize>, u64)>>::from_iter<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>` | fused-native |
| 16 | 1.46 | 323415 | `certified_relations::axpy_in_place::<(usize, alloc::vec::Vec<usize>)>` | fused-native |
| 17 | 1.45 | 319991 | `0x0000000000162880` | libc.so.6 |
| 18 | 1.35 | 298647 | `certified_relations::quotient::rewrite` | fused-native |
| 19 | 1.34 | 296342 | `<alloc::collections::btree::map::IntoIter<alloc::vec::Vec<usize>, u64>>::dying_next` | fused-native |
| 20 | 1.23 | 271403 | `<serde_json::de::Deserializer<serde_json::read::SliceRead>>::parse_integer` | fused-native |
| 21 | 1.16 | 256871 | `certified_relations::axpy_owned::<u128>` | fused-native |
| 22 | 1.06 | 233929 | `certified_relations::verify` | fused-native |
| 23 | 0.98 | 216825 | `<serde_json::de::SeqAccess<_> as serde_core::de::SeqAccess>::next_element_seed::has_next_element::<serde_json::read::SliceRead>` | fused-native |
| 24 | 0.96 | 213209 | `core::str::converts::from_utf8` | fused-native |
| 25 | 0.95 | 211168 | `<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_key::<str>` | fused-native |

## Files

- `annotate-inclusive.txt`
- `annotate.txt`
- `callgrind.out`
- `command.stderr`
- `command.stdout`
- `hotspots.json`
- `hotspots.svg`
- `manifest.json`

Raw profiler output (perf.data, *.ncu-rep, *.nsys-rep, callgrind.out) is large: push it with `crypto store push` (AGENTS.md section 13) rather than committing it.
