//! From-scratch CDCL SAT solver for cryptanalytic boolean problems.
//!
//! Modern SAT solving for cryptanalysis goes back to Massacci-Marraro
//! (2000) and exploded after Soos-Nohl-Castelluccia's CryptoMiniSat
//! (2009) added XOR-clause reasoning. The technique is now standard for:
//!
//! - **Algebraic attacks**: solve the polynomial system describing a
//!   reduced-round cipher (see `cryptanalysis::aes::algebraic`).
//! - **Differential trail search**: encode active S-box constraints as
//!   clauses (Mouha-Preneel 2013, Sun et al. 2014).
//! - **Index calculus**: decide whether a point decomposes over a
//!   factor base (see [`crate::cryptanalysis::semaev_sat`]).
//! - **Preimage / collision search**: encode reduced hash functions.
//!
//! This module ships a **Conflict-Driven Clause Learning (CDCL)** SAT
//! solver from scratch — no external crate:
//!
//! - Two-watched-literal unit propagation,
//! - 1-UIP conflict analysis with clause learning and local
//!   minimization,
//! - Non-chronological backjumping,
//! - VSIDS variable activity over a position-tracked heap,
//! - Phase saving and Luby-sequence restarts,
//! - Periodic learnt-clause forgetting.
//!
//! # Two features that matter for algebraic cryptanalysis
//!
//! Both exist because the systems this solver is pointed at are not
//! generic CNF — they are *gate-structured parity systems*, and a
//! solver that treats them as opaque clauses does badly on them.
//!
//! **Native XOR constraints** ([`Solver::add_xor`]).  Parity rows are
//! held outside the CNF and reasoned about by Gauss-Jordan elimination
//! interleaved with unit propagation.  Refuting a dense parity
//! constraint by resolution alone takes exponentially many steps
//! (Urquhart 1987), so a plain CDCL has to rediscover linear algebra
//! one conflict at a time.
//!
//! **Branching priority** ([`Solver::set_branch_priority`]).  In a gate
//! encoding most variables are *defined* by others; deciding one is
//! case-splitting on something propagation already knew.  Naming the
//! genuinely free variables collapses the search tree to `2^(free)`.
//! On a Weil-descended Semaev system that is the single largest win
//! available — `2^18` rather than `2^767`.
//!
//! It is **not competitive** with state-of-the-art solvers like kissat
//! on general CNF.  Its data layout is close to MiniSat's — one clause
//! arena named by 32-bit offsets, watch lists indexed by literal — but
//! there is no inprocessing, vivification, or LBD-based clause scoring,
//! and forgotten clauses are never compacted out of the arena.
//!
//! ## DIMACS I/O
//!
//! [`parse_dimacs`] parses the standard `.cnf` format; [`to_dimacs`]
//! emits it; [`parse_dimacs_xor`] additionally reads CryptoMiniSat's
//! `x`-prefixed parity lines.  This lets you round-trip with `kissat`,
//! `cadical`, or `cryptominisat` while developing.
//!
//! ## Worked example
//!
//! ```
//! use crypto_lib::cryptanalysis::sat::{Solver, SolveResult};
//!
//! let mut s = Solver::new(3);
//! // (x1 ∨ x2) ∧ (¬x1 ∨ x3) ∧ (¬x2 ∨ ¬x3)
//! s.add_clause(vec![1, 2]);
//! s.add_clause(vec![-1, 3]);
//! s.add_clause(vec![-2, -3]);
//! assert!(matches!(s.solve(), SolveResult::Sat));
//! let model = s.model();
//! // Verify the model satisfies all clauses.
//! ```
//!
//! ## References
//!
//! - **N. Eén, N. Sörensson**, *An extensible SAT-solver*, SAT 2003 —
//!   the MiniSat design this follows.
//! - **M. Soos, K. Nohl, C. Castelluccia**, *Extending SAT solvers to
//!   cryptographic problems*, SAT 2009 — XOR-native reasoning.
//! - **A. Urquhart**, *Hard examples for resolution*, JACM 1987.

use std::sync::atomic::{AtomicU64, AtomicU8, Ordering};

use std::sync::Arc;

/// Standard SAT literal encoding: positive integer = positive
/// literal, negative integer = negated literal, `|lit| - 1` = variable
/// index (0-based internally; 1-based in DIMACS).
pub type Lit = i32;

fn capacity_bytes<T>(buffer: &Vec<T>) -> u64 {
    buffer.capacity() as u64 * std::mem::size_of::<T>() as u64
}

fn storage_snapshot_due(phase: &str, conflicts: u64) -> bool {
    matches!(phase, "solve_enter" | "solve_return")
        || (phase == "conflict_snapshot" && conflicts.is_multiple_of(10_000))
}

/// Typed semantic search events, not an independently checked UNSAT proof. Clause IDs
/// retain the legacy arena-offset names at attachment and remain immutable
/// through physical reclamation. Later clauses use unrecycled virtual offsets;
/// XOR row IDs are indices in the current matrix,
/// reset by `XorMatrixReset`. Literal/variable names use DIMACS indexing.
/// A unit clause may be declared before assignment and again after installation;
/// repeated clause IDs must carry the same literal set.
#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum SolverEvent {
    Snapshot {
        version: u32,
        variables: u32,
        trail_limits: Vec<usize>,
        already_unsat: bool,
    },
    Clause {
        clause_id: u32,
        literals: Vec<Lit>,
        existing: bool,
        detached: bool,
    },
    XorConstraint {
        row_id: usize,
        mask: Vec<u64>,
        rhs: bool,
    },
    /// A newly added constraint refuted immediately, before arena storage.
    /// The clause is retained before root simplification; XOR duplicates are
    /// retained so a consumer can independently check their cancellation.
    FormulaContradiction {
        level: usize,
        constraint: SolverEventConstraint,
    },
    XorMatrixReset,
    XorMatrixRow {
        row_id: usize,
        mask: Vec<u64>,
        rhs: bool,
    },
    XorRowXor {
        destination: usize,
        source: usize,
    },
    XorImplication {
        row_id: usize,
        literal: Lit,
        explanation: Vec<Lit>,
    },
    XorConflict {
        row_id: usize,
        explanation: Vec<Lit>,
    },
    SolveBegin {
        conflicts: u64,
        conflict_budget: u64,
    },
    Decision {
        literal: Lit,
        level: usize,
        trail_index: usize,
        activity_bits: u64,
        priority: bool,
    },
    Assignment {
        literal: Lit,
        level: i32,
        trail_index: usize,
        initial: bool,
        reason: SolverEventReason,
    },
    Conflict {
        level: usize,
        reason: SolverEventReason,
        literals: Vec<Lit>,
    },
    AnalysisReason {
        resolved_literal: Lit,
        reason: SolverEventReason,
        literals: Vec<Lit>,
    },
    Learned {
        clause_id: u32,
        literals: Vec<Lit>,
        backjump_level: i32,
    },
    Backjump {
        from_level: usize,
        to_level: usize,
        retained_trail: usize,
        removed: Vec<Lit>,
    },
    Restart {
        restart: u64,
        conflicts: u64,
    },
    DeleteClause {
        clause_id: u32,
    },
    SolveEnd {
        result: String,
    },
}

#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum SolverEventConstraint {
    Clause { literals: Vec<Lit> },
    Xor { variables: Vec<u32>, rhs: bool },
}

#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum SolverEventReason {
    Decision,
    Clause {
        clause_id: u32,
    },
    /// Copy the explanation immediately: native XOR reason buffers are reused.
    Xor {
        explanation: Vec<Lit>,
    },
}

type EventObserver = Box<dyn FnMut(&SolverEvent) -> Result<(), String> + Send + Sync>;

fn emit_to(observer: &mut Option<EventObserver>, failure: &mut Option<String>, event: SolverEvent) {
    if failure.is_none() {
        if let Some(observer) = observer {
            if let Err(error) = observer(&event) {
                *failure = Some(error);
            }
        }
    }
}

#[inline]
fn var_of(lit: Lit) -> u32 {
    lit.unsigned_abs() - 1
}

#[inline]
fn is_neg(lit: Lit) -> bool {
    lit < 0
}

/// A watch-list entry: the clause, plus one of its other literals.
///
/// The **blocker** is checked first.  If it is already true the clause
/// is satisfied and can be skipped without dereferencing it at all —
/// which is the point, since touching a clause is a likely cache miss.
///
/// The clause is named by its `u32` arena offset (every push goes
/// through [`Solver::next_cref`], which checks it fits), so an entry is
/// eight bytes and a watch list scan reads half the memory it did with
/// a `usize` index.
#[derive(Debug, Clone, Copy)]
struct Watcher {
    cref: u32,
    blocker: Lit,
}

/// The clause stored at arena offset `cref`: a length word, then the
/// literals.  A free function over the arena alone, so a caller can hold
/// the clause while it writes other solver fields.
///
/// The length goes through `u32` so it widens without a sign extension,
/// and the literals are cut from the tail after the length word, which
/// leaves two bounds checks and no overflow check.
#[inline]
fn clause_in(arena: &[Lit], cref: u32) -> &[Lit] {
    let (&len, lits) = arena[cref as usize..]
        .split_first()
        .expect("a clause offset names a length word");
    &lits[..len as u32 as usize]
}

/// [`clause_in`], mutably: watched-literal propagation reorders a
/// clause's literals in place.
#[inline]
fn clause_in_mut(arena: &mut [Lit], cref: u32) -> &mut [Lit] {
    let (&mut len, lits) = arena[cref as usize..]
        .split_first_mut()
        .expect("a clause offset names a length word");
    &mut lits[..len as u32 as usize]
}

/// Decision levels bucketed into 32 bits, so "could this literal's
/// reason stay inside the clause's levels?" is one AND.
#[inline]
fn abstract_level(level: i32) -> u32 {
    1u32 << (level & 31)
}

/// Outcome of solving.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SolveResult {
    Sat,
    Unsat,
    /// Hit conflict / restart budget without resolving.
    Unknown,
}

/// Outcome of a level-zero propagation pass before CDCL search.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RootPropagationResult {
    Fixpoint,
    Unsat,
    /// A fallible event observer stopped propagation; never a refutation.
    Unknown,
}

/// Coarse location of an instrumented solver. A concurrent observer can see
/// this and the counters at slightly different instants.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum SolverProgressPhase {
    Idle = 0,
    ClausePropagation = 1,
    XorPropagation = 2,
    ConflictAnalysis = 3,
    Restart = 4,
    BranchSelection = 5,
    Complete = 6,
}

impl SolverProgressPhase {
    fn from_code(code: u8) -> Self {
        match code {
            1 => Self::ClausePropagation,
            2 => Self::XorPropagation,
            3 => Self::ConflictAnalysis,
            4 => Self::Restart,
            5 => Self::BranchSelection,
            6 => Self::Complete,
            _ => Self::Idle,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SolverProgressSnapshot {
    pub phase: SolverProgressPhase,
    pub decisions: u64,
    pub conflicts: u64,
    pub restarts: u64,
    pub xor_passes: u64,
    pub xor_nanoseconds: u64,
    pub xor_row_scans: u64,
    pub xor_repivots: u64,
    pub xor_row_ops: u64,
}

/// Optional diagnostic counters. Relaxed atomics provide observational
/// samples; they do not synchronize or change the solver's search.
#[derive(Debug, Default)]
pub struct SolverProgress {
    phase: AtomicU8,
    decisions: AtomicU64,
    conflicts: AtomicU64,
    restarts: AtomicU64,
    xor_passes: AtomicU64,
    xor_nanoseconds: AtomicU64,
    xor_row_scans: AtomicU64,
    xor_repivots: AtomicU64,
    xor_row_ops: AtomicU64,
}

impl SolverProgress {
    pub fn snapshot(&self) -> SolverProgressSnapshot {
        SolverProgressSnapshot {
            phase: SolverProgressPhase::from_code(self.phase.load(Ordering::Relaxed)),
            decisions: self.decisions.load(Ordering::Relaxed),
            conflicts: self.conflicts.load(Ordering::Relaxed),
            restarts: self.restarts.load(Ordering::Relaxed),
            xor_passes: self.xor_passes.load(Ordering::Relaxed),
            xor_nanoseconds: self.xor_nanoseconds.load(Ordering::Relaxed),
            xor_row_scans: self.xor_row_scans.load(Ordering::Relaxed),
            xor_repivots: self.xor_repivots.load(Ordering::Relaxed),
            xor_row_ops: self.xor_row_ops.load(Ordering::Relaxed),
        }
    }
}

/// Reason a literal was assigned: a free decision, a unit-propagation
/// source clause, or a parity row.
#[derive(Debug, Clone, Copy)]
enum Reason {
    Decision,
    Propagated(u32), // clause offset in `arena`
    /// Implied by a reduced XOR row.  The reason clause lives in
    /// `xor_reason[var]` and is rewritten in place on each such
    /// implication, so parity reasoning does not grow the clause
    /// database — an earlier version pushed one clause per parity
    /// implication and never reclaimed it.
    XorPropagated,
}

/// What `propagate` ran into.
#[derive(Debug, Clone, Copy)]
enum Conflict {
    /// The clause at this arena offset is falsified.
    Clause(u32),
    /// A parity row is inconsistent; the falsified clause witnessing it
    /// is in `xor_conflict`.
    Xor,
}

/// Counters for one solve.  Cheap to maintain and the only way to tell
/// which engine is actually costing the time.
#[derive(Debug, Clone, Copy, Default)]
pub struct SolverStats {
    /// Completed in-place arena compactions and words removed, cumulative.
    pub arena_reclamations: u64,
    pub arena_reclaimed_words: u64,
    pub decisions: u64,
    pub conflicts: u64,
    pub restarts: u64,
    /// Literals assigned by clause propagation.
    pub propagations: u64,
    /// Gauss-Jordan passes run.
    pub xor_passes: u64,
    /// Literals implied by a parity row.
    pub xor_propagations: u64,
    pub xor_conflicts: u64,
    /// Times a row had to choose a new pivot, the only work the
    /// incremental matrix does beyond a popcount per row.
    pub xor_repivots: u64,
    pub learnt_clauses: u64,

    // ── work counters ───────────────────────────────────────────────
    // Proxies for where the time goes.  Timing each call would cost
    // more than the calls do; counting the operations does not.
    /// Row-into-row XORs performed by re-pivoting, each `O(words)`.
    pub xor_row_ops: u64,
    /// Rows examined in the parity read-off, each `O(words)`.
    pub xor_row_scans: u64,
    /// Actual 64-bit matrix updates (dense or indexed engine).
    pub xor_word_updates: u64,
    /// Word positions visited while merging nonzero supports.
    pub xor_support_visits: u64,
    /// Literals written into parity reason clauses.
    pub xor_reason_lits: u64,
    /// Clauses examined by watched-literal propagation.
    pub clause_visits: u64,
    /// Literals scanned while looking for a replacement watch.
    pub clause_lit_visits: u64,
    /// Literals walked across reason clauses during conflict analysis.
    pub analyze_lit_visits: u64,
    /// Literals in learnt clauses, before and after minimization.
    pub learnt_lits_raw: u64,
    pub learnt_lits_kept: u64,
    // ── phase timings, in nanoseconds ───────────────────────────────
    // `Instant::now` costs ~25 ns against ~80 µs per conflict, so
    // timing the phases directly is cheaper than guessing at them.
    pub ns_propagate_clauses: u64,
    pub ns_propagate_xors: u64,
    pub ns_analyze: u64,
    pub ns_minimize: u64,
    pub ns_reduce_db: u64,
    /// Summed decision level at conflict, and the deepest level seen.
    /// If the free-variable set really determines everything, the level
    /// should never exceed the number of free variables.
    pub conflict_level_sum: u64,
    pub max_level: u64,

    // ── `bitop/v1` accounting ───────────────────────────────────────
    // [`Solver::word_ops`] charges the whole run in 64-bit word
    // operations (`docs/units/BITOPS.md`, `word_op`): these two
    // counters hold the work no counter above already measures, and
    // `word_ops` adds the per-unit constants of the ones that do.  One
    // unit is one inner-loop iteration that reads, compares, XORs or
    // writes one word of clause, watch, trail, bitset or matrix data.
    // Neither feeds back into the search.
    /// Search-side word operations not implied by the counters above.
    pub word_ops: u64,
    /// Word operations of building the encoding before the search:
    /// Tseitin definitions, parity expansion or rows, blocking clauses.
    /// Written by the encoders (`semaev_sat`).
    pub encode_word_ops: u64,
}

/// Max-heap of variables by VSIDS activity, with position tracking so a
/// bumped variable percolates up in place.
///
/// Replaces a linear scan over every variable per decision, which on an
/// `n = 19` Semaev instance meant 767 comparisons for each of millions
/// of decisions.
#[derive(Debug, Clone)]
struct VarHeap {
    heap: Vec<u32>,
    /// `pos[v]` is `v`'s index in `heap`, or `-1` when absent.
    pos: Vec<i32>,
    /// Word operations spent in the heap (`bitop/v1` accounting, see
    /// [`Solver::word_ops`]): one per call (the membership or root
    /// test), one per percolate-up step (a key compare), two per
    /// percolate-down step (a key compare between the children, then
    /// against the moving key).
    steps: u64,
}

/// Branching order key: priority class first, then VSIDS activity,
/// packed into one integer so the heap compares one word per variable
/// instead of looking up two flags and two floats.
///
/// The priority flag takes the top bit and the activity's IEEE bits the
/// rest.  That orders exactly as "priority, then activity" because every
/// activity is a non-negative non-NaN double: it starts at `+0.0` and
/// only ever grows by a positive increment or shrinks by the positive
/// factor `1e-100`, so its sign bit is always clear and, for such
/// doubles, bit order *is* numeric order — and equal values have equal
/// bits, so the strict comparison ties exactly where the float one did.
#[inline]
fn order_key(activity: f64, priority: bool) -> u64 {
    debug_assert!(activity >= 0.0 && activity.is_sign_positive());
    ((priority as u64) << 63) | activity.to_bits()
}

impl VarHeap {
    fn new(n_vars: u32) -> Self {
        // With all activities equal, any permutation is a valid heap.
        Self {
            heap: (0..n_vars).collect(),
            pos: (0..n_vars as i32).collect(),
            steps: 2 * n_vars as u64,
        }
    }

    #[inline]
    fn contains(&self, v: u32) -> bool {
        self.pos[v as usize] >= 0
    }

    fn percolate_up(&mut self, mut i: usize, key: &[u64]) {
        let v = self.heap[i];
        let kv = key[v as usize];
        self.steps += 1;
        while i > 0 {
            self.steps += 1;
            let parent = (i - 1) >> 1;
            if kv <= key[self.heap[parent] as usize] {
                break;
            }
            self.heap[i] = self.heap[parent];
            self.pos[self.heap[i] as usize] = i as i32;
            i = parent;
        }
        self.heap[i] = v;
        self.pos[v as usize] = i as i32;
    }

    fn percolate_down(&mut self, mut i: usize, key: &[u64]) {
        let v = self.heap[i];
        let kv = key[v as usize];
        self.steps += 1;
        loop {
            self.steps += 2;
            let left = 2 * i + 1;
            if left >= self.heap.len() {
                break;
            }
            let right = left + 1;
            let child = if right < self.heap.len()
                && key[self.heap[right] as usize] > key[self.heap[left] as usize]
            {
                right
            } else {
                left
            };
            if key[self.heap[child] as usize] <= kv {
                break;
            }
            self.heap[i] = self.heap[child];
            self.pos[self.heap[i] as usize] = i as i32;
            i = child;
        }
        self.heap[i] = v;
        self.pos[v as usize] = i as i32;
    }

    /// Re-insert a variable that left the heap (on unassignment).
    ///
    /// Forced inline, so `backjump` pays only the membership test for
    /// the many variables still in the heap; left to itself (even with
    /// `#[inline]`) the compiler made this an out-of-line call per
    /// unassigned variable, about 3% of a random 3-SAT solve.
    #[inline(always)]
    fn insert(&mut self, v: u32, key: &[u64]) {
        self.steps += 1;
        if self.contains(v) {
            return;
        }
        self.heap.push(v);
        self.pos[v as usize] = (self.heap.len() - 1) as i32;
        self.percolate_up(self.heap.len() - 1, key);
    }

    /// A variable's activity rose; restore the heap property.
    fn bumped(&mut self, v: u32, key: &[u64]) {
        self.steps += 1;
        if self.contains(v) {
            let i = self.pos[v as usize] as usize;
            self.percolate_up(i, key);
        }
    }

    /// Rebuild after a wholesale change of the ordering key.
    fn rebuild(&mut self, n_vars: u32, key: &[u64]) {
        self.heap.clear();
        self.steps += self.pos.len() as u64;
        self.pos.iter_mut().for_each(|p| *p = -1);
        for v in 0..n_vars {
            self.insert(v, key);
        }
    }

    fn pop_max(&mut self, key: &[u64]) -> Option<u32> {
        self.steps += 1;
        if self.heap.is_empty() {
            return None;
        }
        let top = self.heap[0];
        self.pos[top as usize] = -1;
        let last = self.heap.pop().unwrap();
        if !self.heap.is_empty() {
            self.heap[0] = last;
            self.pos[last as usize] = 0;
            self.percolate_down(0, key);
        }
        Some(top)
    }
}

pub struct Solver {
    native_admission: Option<NativeAdmission>,
    native_failure: Option<NativeAdmissionFailure>,
    native_pending_model: Option<Vec<bool>>,
    // Slot, original vector, next unread index, compacted prefix length.
    // On sticky refusal the actual allocation stays owned without suffix copying.
    native_pending_watch: Option<(usize, Vec<Watcher>, usize, usize)>,
    native_partial_xor: Option<(usize, usize, usize, bool)>,
    native_sort_scratch: Vec<usize>,
    native_pending_clause: Option<Vec<Lit>>,
    native_pending_reduction: Option<(Vec<bool>, Vec<usize>)>,
    progress: Option<Arc<SolverProgress>>,
    event_observer: Option<EventObserver>,
    event_failure: Option<String>,
    // Legacy observer names are offsets before any reclamation. Keep a separate
    // name per immutable insertion slot so moving storage never changes a key.
    event_clause_ids: Vec<u32>,
    event_next_clause_id: u32,
    /// Number of variables (1-indexed externally).
    n_vars: u32,
    /// Centre of the literal-indexed tables `values` and `watches`:
    /// literal `l` lives at slot `l + lit_base`.  Always at least
    /// `n_vars`; the slots of variables beyond `n_vars` are unassigned
    /// and watched by nothing.  They would read as unassigned variables,
    /// so no literal or variable from outside the solver may reach them:
    /// [`Solver::add_clause`] and the lazy-clause path refuse a clause
    /// naming a variable past `n_vars`, and trigger variables are read
    /// through the `n_vars`-long [`Solver::assignment`] slice.
    ///
    /// It is not simply `n_vars` because widening the tables moves every
    /// slot.  Centred on `n_vars`, each [`Solver::add_vars`] call cost
    /// `O(n_vars)`, and a caller that adds its auxiliaries one at a time
    /// paid quadratically for its encoding.  [`Solver::add_vars`] grows
    /// the base geometrically instead, so only `O(log n_vars)` calls
    /// re-centre.  The price is up to twice the table size the variable
    /// count needs, kept for the solver's lifetime.
    lit_base: u32,
    /// **Clause arena**: every clause, original and learnt, stored back
    /// to back as a length word followed by its literals, and named
    /// everywhere (watchers, reasons, conflicts) by the offset of that
    /// length word.  Clauses are only ever appended — forgetting one
    /// detaches it from the watch lists and leaves it here — so offsets
    /// never move.
    ///
    /// A vector per clause cost a heap allocation per learnt clause and,
    /// on every visit, a load of the vector's header before the load of
    /// its literals; here the header is the literal array's first word.
    ///
    /// Keeping every clause in one vector has two costs, both of which
    /// only show at tens of gigabytes.  Offsets are `u32`, so the arena
    /// holds at most `2^32` words (16 GiB of literals) and
    /// [`Solver::next_cref`] panics past that, where per-clause vectors
    /// had no cap.  And growing it by doubling briefly holds the old and
    /// the new buffer together, about three times the arena at once.
    /// At reductions, detached clauses are compacted to small tautology
    /// tombstones and excess capacity is returned to the allocator.
    arena: Vec<Lit>,
    /// `clause_at[i]` is clause `i`'s arena offset, in the order clauses
    /// were added; learnt clauses start at `n_orig_clauses`.  Offsets
    /// increase with `i`, so an offset's index is a binary search away.
    clause_at: Vec<u32>,
    n_orig_clauses: usize,
    /// Truth value of every *literal* under the trail, indexed by
    /// `lit + lit_base`: slot `lit_base + 1 + v` holds variable `v`'s
    /// value, slot `lit_base - 1 - v` its negation's, and slot
    /// `lit_base` (literal 0) is never used.
    ///
    /// Watched-literal propagation asks "is this literal true?" a few
    /// times per clause visit.  Against a per-variable `Option<bool>`
    /// each answer cost an absolute value, a sign test and a
    /// conditional negation; here it is one add and one load, paid for
    /// by a second byte store per assignment.  The upper half starts
    /// with the per-variable assignment itself (`None` = unassigned),
    /// which is what `assignment()` hands out.
    values: Vec<Option<bool>>,
    /// Bitset mirror of the assignment: `assigned_w` marks assigned
    /// variables, `value_w` their values.  Parity rows are bitmasks, so
    /// with this the whole read-off is `mask & !assigned` and a
    /// popcount — `O(words)` per row instead of `O(set bits)` with a
    /// two-byte `Option<bool>` lookup for each one.
    assigned_w: Vec<u64>,
    value_w: Vec<u64>,
    /// Per-variable decision level when assigned.
    level: Vec<i32>,
    /// Per-variable reason for assignment.
    reason: Vec<Reason>,
    /// Per-variable last-phase, for phase saving.
    saved_phase: Vec<bool>,
    /// Per-variable VSIDS activity.
    activity: Vec<f64>,
    activity_inc: f64,
    activity_decay: f64,
    /// Trail: order in which literals were assigned.
    trail: Vec<Lit>,
    /// Index into `trail` of first unpropagated literal.
    qhead: usize,
    /// `trail_lim[d] = trail.len() when decision level d began`.
    trail_lim: Vec<usize>,
    /// Two-watched-literal scheme: for each literal, at slot
    /// `lit + lit_base` exactly as in `values`, the clauses watching it.
    watches: Vec<Vec<Watcher>>,
    /// Counter of conflicts since the last restart.
    conflicts_since_restart: u64,
    /// Total conflicts across the whole solve.
    conflicts: u64,
    /// Maximum total conflicts before giving up. `u64::MAX` means
    /// no limit.
    pub conflict_budget: u64,
    /// Wall-clock deadline; checked at the start of every solve-loop
    /// iteration and after conflicts. A single propagation pass can still
    /// overrun it, so a hard outer process watchdog remains necessary.
    /// `None` means no deadline.
    pub deadline: Option<std::time::Instant>,
    /// Run the XOR matrix after every N decision levels, and always at
    /// level zero or a complete assignment. One preserves the original
    /// propagation policy. Larger values trade weaker intermediate XOR
    /// propagation for fewer full-matrix passes without omitting the final
    /// original XOR check before SAT.
    xor_decision_cadence: usize,
    /// Set when `add_clause` detects UNSAT (empty clause or
    /// conflict-on-unit).  `solve()` short-circuits to UNSAT when set.
    is_unsat: bool,
    /// Native XOR (parity) constraints, held *outside* the CNF.  Each
    /// row is `(variable-set bitmask, right-hand side)`, meaning
    /// `⊕_{v ∈ mask} x_v = rhs`.  See [`Solver::add_xor`].
    xors: Vec<XorRow>,
    /// Bumped on every assignment and every backjump.  Lets
    /// [`Solver::propagate`] skip the Gauss-Jordan pass when nothing
    /// has moved since the last one.
    epoch: u64,
    /// `epoch` as of the last completed Gauss-Jordan pass.
    xor_epoch: u64,
    /// Per-variable reason clause for parity implications, rewritten in
    /// place rather than appended to the clause database.
    xor_reason: Vec<Vec<Lit>>,
    /// Reason clause for a parity conflict, likewise reused.
    xor_conflict: Vec<Lit>,
    /// **Live Gauss-Jordan matrix**: row-reduced linear combinations of
    /// `xors`, carried across propagations instead of re-eliminated
    /// from scratch each time.  Row operations are algebraically valid
    /// whatever the trail says, so they are never undone — not on
    /// propagation, not on backjump.
    ///
    /// The invariant that makes per-row reasoning *complete*:
    ///
    /// > every row has a **pivot** variable that is unassigned and
    /// > occurs in no other row.
    ///
    /// Restricted to the unassigned columns the matrix is then `[I | B]`
    /// after permutation, so any sum of `k` rows still contains all `k`
    /// of their distinct pivots.  A combination can therefore be unit
    /// only for `k = 1`, and inconsistent only if some single row is
    /// fully assigned — which is exactly what a per-row check finds.
    /// Nothing is missed by not re-eliminating.
    ///
    /// Backjumping only *unassigns* variables, which cannot break the
    /// invariant, so it costs no work there either.
    ///
    /// Stored flat, row `i` at `matrix[i * words .. (i + 1) * words]`
    /// with its right-hand side in `matrix_rhs[i]`: the elimination's
    /// column test and row XOR then index one allocation instead of
    /// chasing a pointer per row.
    matrix: Vec<u64>,
    matrix_rhs: Vec<bool>,
    /// Sorted exact nonzero word positions; never a stale superset.
    matrix_support: Vec<Vec<usize>>,
    indexed_xors: bool,
    xor_support_src: Vec<usize>,
    xor_support_merge: Vec<usize>,
    /// `pivot[i]` is row `i`'s basic variable; `None` once the row has
    /// no unassigned variable left.
    pivot: Vec<Option<u32>>,
    /// Scratch copy of the row being pivoted on, reused across passes.
    xor_src: Vec<u64>,
    /// `analyze` scratch: which variables have been resolved on.  Only
    /// the entries in `seen_stack` are dirty, so clearing is O(touched)
    /// rather than O(variables).
    seen: Vec<bool>,
    seen_stack: Vec<u32>,
    /// Scratch stack for recursive clause minimization.
    redundant_stack: Vec<Lit>,
    /// Accumulator for the learnt clause, reused across conflicts.  It
    /// grows to a few hundred literals before minimization, so letting
    /// it reallocate per conflict was pure waste.
    learnt_buf: Vec<Lit>,
    /// Branching order by activity.
    order: VarHeap,
    /// Variables to branch on before any others.  See
    /// [`Solver::set_branch_priority`].
    branch_priority: Vec<bool>,
    /// `order_key(activity[v], branch_priority[v])`, the heap's
    /// comparison key, refreshed wherever either input changes.
    heap_key: Vec<u64>,
    /// Learnt clauses that have been detached from the watch lists and
    /// are no longer propagated, by clause index. Compaction preserves
    /// their indices so database-reduction scheduling is unchanged.
    detached: Vec<bool>,
    /// Reclaim detached clause storage at database reductions. Disabling
    /// this retains the append-only layout for matched diagnostic controls.
    pub reclaim_detached_clauses: bool,
    /// Learnt-clause budget before the next reduction.  Set it before
    /// `solve()` to force more aggressive forgetting; left at 0 it is
    /// chosen from the problem size.
    pub max_learnts: usize,
    /// Counters for the current solve.
    pub stats: SolverStats,
}

/// One parity constraint: `⊕_{v ∈ mask} x_v = rhs`, with `mask` a
/// bitmask over 0-indexed variables.
#[derive(Clone, Debug)]
struct XorRow {
    mask: Vec<u64>,
    rhs: bool,
}

/// Outcome of one Gauss-Jordan pass over the XOR rows.
enum XorStep {
    /// Sticky native admission refusal, never a fixpoint or contradiction.
    Refused,
    /// Nothing new could be derived.
    Fixpoint,
    /// At least one literal was enqueued; re-run clause propagation.
    Propagated,
    /// A row is inconsistent; the falsified clause witnessing it has
    /// been written into `xor_conflict`.
    Conflict,
}

#[inline]
fn bs_words(n_vars: u32) -> usize {
    (n_vars as usize).div_ceil(64)
}

#[inline]
fn bs_get(mask: &[u64], v: u32) -> bool {
    (mask[v as usize / 64] >> (v % 64)) & 1 == 1
}

#[inline]
fn bs_flip(mask: &mut [u64], v: u32) {
    mask[v as usize / 64] ^= 1u64 << (v % 64);
}

/// `dst ^= src`, word by word.  Kept out of line on purpose: inlined
/// into the elimination's column scan, which calls it for about a third
/// of the rows, its vectorised loop made the compiler carry several
/// row pointers through the scan and spill them.
#[inline(never)]
fn xor_into(dst: &mut [u64], src: &[u64]) {
    for (d, &s) in dst.iter_mut().zip(src) {
        *d ^= s;
    }
}

#[inline]
#[allow(dead_code)]
fn negated(lit: Lit) -> Lit {
    -lit
}

impl Solver {
    /// Create a fresh solver for `n_vars` variables, indexed 1..=n_vars.
    pub fn new(n_vars: u32) -> Self {
        let n = n_vars as usize;
        Solver {
            progress: None,
            event_observer: None,
            event_failure: None,
            event_clause_ids: Vec::new(),
            event_next_clause_id: 0,
            native_admission: None,
            native_failure: None,
            native_pending_model: None,
            native_pending_watch: None,
            native_partial_xor: None,
            native_sort_scratch: Vec::new(),
            native_pending_clause: None,
            native_pending_reduction: None,
            n_vars,
            lit_base: n_vars,
            arena: Vec::new(),
            clause_at: Vec::new(),
            n_orig_clauses: 0,
            values: vec![None; 2 * n + 1],
            assigned_w: vec![0; bs_words(n_vars)],
            value_w: vec![0; bs_words(n_vars)],
            level: vec![-1; n],
            reason: vec![Reason::Decision; n],
            saved_phase: vec![true; n],
            activity: vec![0.0; n],
            activity_inc: 1.0,
            activity_decay: 0.95,
            trail: Vec::new(),
            qhead: 0,
            trail_lim: Vec::new(),
            watches: vec![Vec::new(); 2 * n + 1],
            conflicts_since_restart: 0,
            conflicts: 0,
            conflict_budget: u64::MAX,
            deadline: None,
            xor_decision_cadence: 1,
            is_unsat: false,
            xors: Vec::new(),
            epoch: 0,
            xor_epoch: u64::MAX,
            xor_reason: vec![Vec::new(); n],
            xor_conflict: Vec::new(),
            matrix: Vec::new(),
            matrix_rhs: Vec::new(),
            matrix_support: Vec::new(),
            indexed_xors: true,
            xor_support_src: Vec::new(),
            xor_support_merge: Vec::new(),
            pivot: Vec::new(),
            xor_src: Vec::new(),
            seen: vec![false; n],
            seen_stack: Vec::new(),
            redundant_stack: Vec::new(),
            learnt_buf: Vec::new(),
            order: VarHeap::new(n_vars),
            branch_priority: vec![false; n],
            heap_key: vec![order_key(0.0, false); n],
            detached: Vec::new(),
            reclaim_detached_clauses: true,
            max_learnts: 0,
            // Initialising the tables: the two literal-indexed ones
            // (`values`, `watches`), eight per-variable ones and the two
            // bitsets, one unit per slot.  The heap charges its own two.
            stats: SolverStats {
                word_ops: 2 * (2 * n as u64 + 1) + 8 * n as u64 + 2 * bs_words(n_vars) as u64,
                ..SolverStats::default()
            },
        }
    }

    /// Attach before search. Emits the existing formula and trail immediately,
    /// allowing attachment after encoding-time unit assignments. Observation
    /// never changes native operation counters. The first sink error is sticky:
    /// later solves return Unknown and callers can inspect the exact error.
    pub fn set_event_observer(
        &mut self,
        observer: impl FnMut(&SolverEvent) -> Result<(), String> + Send + Sync + 'static,
    ) -> Result<(), String> {
        if self.native_admission.is_some() || self.native_failure.is_some() {
            return Err("SAT observer must be installed before native admission".into());
        }
        if self.event_observer.is_some() || self.event_failure.is_some() {
            return Err("SAT event observer already installed or failed".into());
        }
        self.event_clause_ids
            .try_reserve_exact(self.clause_at.len())
            .map_err(|_| "SAT event clause-name allocation refused".to_string())?;
        self.event_clause_ids.extend_from_slice(&self.clause_at);
        self.event_next_clause_id = self.next_cref();
        self.event_observer = Some(Box::new(observer));
        self.emit(SolverEvent::Snapshot {
            version: 1,
            variables: self.n_vars,
            trail_limits: self.trail_lim.clone(),
            already_unsat: self.is_unsat,
        });
        for i in 0..self.clause_at.len() {
            if self.event_failure.is_some() {
                break;
            }
            let cref = self.clause_at[i];
            self.emit(SolverEvent::Clause {
                clause_id: self.event_clause_id(cref),
                literals: clause_in(&self.arena, cref).to_vec(),
                existing: true,
                detached: self.detached.get(i).copied().unwrap_or(false),
            });
        }
        for i in 0..self.xors.len() {
            if self.event_failure.is_some() {
                break;
            }
            self.emit(SolverEvent::XorConstraint {
                row_id: i,
                mask: self.xors[i].mask.clone(),
                rhs: self.xors[i].rhs,
            });
        }
        // An observer attached after a root pass must retain its actual matrix.
        for i in 0..self.matrix_rhs.len() {
            if self.event_failure.is_some() {
                break;
            }
            let words = bs_words(self.n_vars);
            self.emit(SolverEvent::XorMatrixRow {
                row_id: i,
                mask: self.matrix[i * words..(i + 1) * words].to_vec(),
                rhs: self.matrix_rhs[i],
            });
        }
        for index in 0..self.trail.len() {
            if self.event_failure.is_some() {
                break;
            }
            let literal = self.trail[index];
            let v = var_of(literal) as usize;
            self.emit(SolverEvent::Assignment {
                literal,
                level: self.level[v],
                trail_index: index,
                initial: true,
                reason: self.event_reason(self.reason[v], v),
            });
        }
        self.event_failure.clone().map_or(Ok(()), Err)
    }

    pub fn event_observer_error(&self) -> Option<&str> {
        self.event_failure.as_deref()
    }

    #[inline]
    fn observing(&self) -> bool {
        self.event_observer.is_some() && self.event_failure.is_none()
    }

    fn emit(&mut self, event: SolverEvent) {
        emit_to(&mut self.event_observer, &mut self.event_failure, event);
    }

    fn event_clause_id(&self, cref: u32) -> u32 {
        let index = match self.clause_at.binary_search(&cref) {
            Ok(index) => index,
            Err(index) => {
                assert_eq!(cref, self.next_cref());
                assert_eq!(index, self.clause_at.len());
                index
            }
        };
        if index < self.event_clause_ids.len() {
            self.event_clause_ids[index]
        } else {
            assert_eq!(index, self.clause_at.len());
            self.event_next_clause_id
        }
    }

    fn event_reason(&self, reason: Reason, variable: usize) -> SolverEventReason {
        match reason {
            Reason::Decision => SolverEventReason::Decision,
            Reason::Propagated(cref) => SolverEventReason::Clause {
                clause_id: self.event_clause_id(cref),
            },
            Reason::XorPropagated => SolverEventReason::Xor {
                explanation: self.xor_reason[variable].clone(),
            },
        }
    }

    fn conflict_event(
        &self,
        conflict: Conflict,
        resolved_literal: Lit,
    ) -> (SolverEventReason, Vec<Lit>) {
        match conflict {
            Conflict::Clause(clause_id) => (
                SolverEventReason::Clause {
                    clause_id: self.event_clause_id(clause_id),
                },
                clause_in(&self.arena, clause_id).to_vec(),
            ),
            Conflict::Xor => {
                let literals = if resolved_literal == 0 {
                    self.xor_conflict.clone()
                } else {
                    self.xor_reason[var_of(resolved_literal) as usize].clone()
                };
                (
                    SolverEventReason::Xor {
                        explanation: literals.clone(),
                    },
                    literals,
                )
            }
        }
    }

    /// Install an observer before search. Existing counters are copied so a
    /// staged root pass or incremental solve starts from its actual totals.
    pub fn set_progress_observer(&mut self, progress: Arc<SolverProgress>) {
        progress
            .decisions
            .store(self.stats.decisions, Ordering::Relaxed);
        progress
            .conflicts
            .store(self.stats.conflicts, Ordering::Relaxed);
        progress
            .restarts
            .store(self.stats.restarts, Ordering::Relaxed);
        progress
            .xor_passes
            .store(self.stats.xor_passes, Ordering::Relaxed);
        progress
            .xor_nanoseconds
            .store(self.stats.ns_propagate_xors, Ordering::Relaxed);
        progress
            .xor_row_scans
            .store(self.stats.xor_row_scans, Ordering::Relaxed);
        progress
            .xor_repivots
            .store(self.stats.xor_repivots, Ordering::Relaxed);
        progress
            .xor_row_ops
            .store(self.stats.xor_row_ops, Ordering::Relaxed);
        progress
            .phase
            .store(SolverProgressPhase::Idle as u8, Ordering::Relaxed);
        self.progress = Some(progress);
    }

    #[inline]
    fn progress_phase(&self, phase: SolverProgressPhase) {
        if let Some(progress) = &self.progress {
            progress.phase.store(phase as u8, Ordering::Relaxed);
        }
    }

    /// **The whole run in `bitop/v1` word operations**: encoding,
    /// propagation over clauses and parity rows, conflict analysis and
    /// minimisation, branching heap, backjumps, restarts, clause-database
    /// reduction and model read-out (the last charged by the caller that
    /// reads the model; see [`Solver::model`]).
    ///
    /// Per-unit constants for the counters measured elsewhere:
    ///
    /// - `clause_visits` × 2: the clause's length word and watched pair,
    ///   and the other watch's value;
    /// - `clause_lit_visits` × 1: one literal's value lookup;
    /// - `propagations` × 2: an assignment writes the two literal slots
    ///   and the two bitset words (level, reason, phase and trail are
    ///   counted with it as stores, not gates);
    /// - `analyze_lit_visits` × 1: a reason literal's seen/level test;
    /// - `learnt_lits_raw` × 2: the abstract-level fold and the
    ///   redundancy test of each literal before minimisation;
    /// - `learnt_lits_kept` × 2: the asserting clause's copy and its
    ///   backjump-level scan;
    /// - the heap's own steps (see `VarHeap::steps`).
    ///
    /// Everything else is in `word_ops` and `encode_word_ops`, counted
    /// at the site that does it.
    pub fn word_ops(&self) -> u64 {
        let st = &self.stats;
        st.word_ops
            + st.encode_word_ops
            + 2 * st.clause_visits
            + st.clause_lit_visits
            + 2 * st.propagations
            + st.analyze_lit_visits
            + 2 * st.learnt_lits_raw
            + 2 * st.learnt_lits_kept
            + self.order.steps
    }

    /// **Add a native XOR (parity) constraint** `x_{v₁} ⊕ … ⊕ x_{v_k}
    /// = rhs`, with variables given 1-indexed exactly as in
    /// [`Solver::add_clause`].  Returns `false` if the constraint is
    /// trivially unsatisfiable (`0 = 1`).
    ///
    /// XOR rows are held outside the CNF and reasoned about by
    /// Gauss-Jordan elimination in [`Solver::propagate`], rather than
    /// being Tseitin-expanded into clauses.  This is the difference
    /// between polynomial-time and exponential-time handling of a
    /// dense parity constraint: resolution needs exponentially many
    /// steps to refute one (Urquhart 1987), which is why a plain CDCL
    /// stalls on Weil-descended Semaev systems.
    ///
    /// Duplicated variables cancel (`x ⊕ x = 0`), so the caller need
    /// not deduplicate.
    pub fn add_xor(&mut self, vars: &[u32], rhs: bool) -> bool {
        if self.native_admission.is_some() {
            self.native_failure
                .get_or_insert(NativeAdmissionFailure::UncoveredPath);
            return false;
        }
        let mut mask = vec![0u64; bs_words(self.n_vars)];
        // One per variable flipped, and the row's words twice: the
        // emptiness test and the copy into the row store.
        self.stats.word_ops += vars.len() as u64 + 2 * mask.len() as u64;
        for &v in vars {
            debug_assert!(v >= 1 && v <= self.n_vars, "xor var {v} out of range");
            bs_flip(&mut mask, v - 1); // duplicates cancel
        }
        if mask.iter().all(|w| *w == 0) {
            // Empty parity: `0 = rhs`.  Satisfiable iff rhs is false.
            if rhs {
                if self.observing() {
                    self.emit(SolverEvent::FormulaContradiction {
                        level: self.trail_lim.len(),
                        constraint: SolverEventConstraint::Xor {
                            variables: vars.to_vec(),
                            rhs,
                        },
                    });
                }
                self.is_unsat = true;
                return false;
            }
            return true;
        }
        self.xors.push(XorRow { mask, rhs });
        if self.observing() {
            let row_id = self.xors.len() - 1;
            self.emit(SolverEvent::XorConstraint {
                row_id,
                mask: self.xors[row_id].mask.clone(),
                rhs,
            });
        }
        self.clear_matrix(); // rebuilt on the next pass
        self.xor_epoch = u64::MAX; // force a pass on the next propagate
        true
    }

    /// Number of native XOR constraints installed.
    pub fn n_xors(&self) -> usize {
        self.xors.len()
    }

    /// **Add `count` fresh variables**, returning their 1-indexed
    /// range.  Every per-variable structure grows, the parity bitmasks
    /// are widened, and the live Gauss-Jordan matrix is rebuilt on the
    /// next propagation.  Meant for callers that layer constraints —
    /// symmetry breaking, cardinality chains — over an encoding they
    /// did not size themselves; call it before `solve`, at level 0.
    pub fn add_vars(&mut self, count: u32) -> std::ops::RangeInclusive<u32> {
        if self.native_admission.is_some() {
            self.native_failure
                .get_or_insert(NativeAdmissionFailure::UncoveredPath);
            return 1..=0;
        }
        if self.observing() && count != 0 {
            self.event_failure =
                Some("changing variable count after event attachment is not supported".into());
        }
        debug_assert!(
            self.trail_lim.is_empty(),
            "add_vars must be called at decision level 0"
        );
        let old = self.n_vars;
        let new_total = old + count;
        let n = new_total as usize;
        let words = bs_words(new_total);
        // Ten per-variable slots and two literal slots per new variable
        // (the heap charges its own insertions), and every parity row
        // widened to the new word count.
        self.stats.word_ops += 12 * count as u64 + (self.xors.len() * words) as u64;
        if new_total > self.lit_base {
            self.recentre_literal_tables(new_total);
        }
        self.assigned_w.resize(words, 0);
        self.value_w.resize(words, 0);
        self.level.resize(n, -1);
        self.reason.resize(n, Reason::Decision);
        self.saved_phase.resize(n, true);
        self.activity.resize(n, 0.0);
        self.xor_reason.resize(n, Vec::new());
        self.seen.resize(n, false);
        self.branch_priority.resize(n, false);
        self.heap_key.resize(n, order_key(0.0, false));
        self.order.pos.resize(n, -1);
        for row in &mut self.xors {
            row.mask.resize(words, 0);
        }
        self.clear_matrix();
        self.pivot.clear();
        self.xor_epoch = u64::MAX;
        self.n_vars = new_total;
        for v in old..new_total {
            self.order.insert(v, &self.heap_key);
        }
        (old + 1)..=new_total
    }

    /// Re-centre `values` and `watches` on a base of at least `n_vars`.
    ///
    /// The base at least doubles, so a run of [`Solver::add_vars`]
    /// calls re-centres `O(log n_vars)` times and each call costs
    /// amortised `O(count)`, as it did before the tables were indexed
    /// by literal.  Doubling stops at `i32::MAX / 2`, past which
    /// `lit + lit_base` could overflow; only `n_vars` itself can take
    /// the base beyond that.
    fn recentre_literal_tables(&mut self, n_vars: u32) {
        let base = n_vars.max(self.lit_base.saturating_mul(2).min(i32::MAX as u32 / 2));
        let len = 2 * base as usize + 1;
        // Literal `l` moves from `l + lit_base` to `l + base`, so both
        // tables shift up whole by the difference.  The slots of
        // variables not yet added are unassigned and watched by nothing,
        // and move along with the rest.
        let shift = (base - self.lit_base) as usize;
        // Both literal tables rewritten in full.
        self.stats.word_ops += 2 * len as u64;
        let mut values = vec![None; len];
        values[shift..shift + self.values.len()].copy_from_slice(&self.values);
        self.values = values;
        let mut watches: Vec<Vec<Watcher>> = Vec::with_capacity(len);
        watches.resize_with(shift, Vec::new);
        watches.append(&mut self.watches);
        watches.resize_with(len, Vec::new);
        self.watches = watches;
        self.lit_base = base;
    }

    /// **Branch on these variables first**, exhausting them before any
    /// other variable is ever chosen as a decision.
    ///
    /// In a gate-style encoding most variables are *defined*: monomial
    /// auxiliaries are conjunctions of other variables, and parity rows
    /// determine the rest.  Deciding one of those is wasted work — its
    /// value was already implied, so the solver is case-splitting on
    /// something propagation would have told it.  Naming the genuinely
    /// free variables collapses the search tree from `2^(all vars)` to
    /// `2^(free vars)`; on the `n = 19, l = 6` Semaev instance that is
    /// `2^18` rather than `2^767`.
    ///
    /// This is only a branching *order*, not a restriction: if the
    /// priority set is exhausted while something is still unassigned,
    /// the solver carries on with the rest, so a caller that names an
    /// incomplete set gets a slower solve rather than a wrong answer.
    ///
    /// Variables are 1-indexed, as in [`Solver::add_clause`].
    pub fn set_branch_priority(&mut self, vars: &[u32]) {
        // Clear and re-key every variable, mark each named one; the heap
        // rebuild charges itself.
        self.stats.word_ops += 2 * self.n_vars as u64 + vars.len() as u64;
        self.branch_priority.iter_mut().for_each(|p| *p = false);
        for &v in vars {
            debug_assert!(v >= 1 && v <= self.n_vars, "priority var {v} out of range");
            self.branch_priority[(v - 1) as usize] = true;
        }
        for (k, (&a, &p)) in self
            .heap_key
            .iter_mut()
            .zip(self.activity.iter().zip(&self.branch_priority))
        {
            *k = order_key(a, p);
        }
        self.order.rebuild(self.n_vars, &self.heap_key);
    }

    /// Choose how often a search decision triggers native XOR elimination.
    /// A complete assignment and the root level always run the XOR engine,
    /// so a slower cadence cannot turn an XOR-violating assignment into SAT.
    pub fn set_xor_decision_cadence(&mut self, cadence: usize) {
        assert!(cadence > 0, "XOR decision cadence must be positive");
        self.xor_decision_cadence = cadence;
    }

    /// Propagate to fixpoint at the current level without deciding.
    /// Returns `true` on conflict.  Test hook for checking what the
    /// parity engine derives, with no search on top.
    #[cfg(test)]
    pub(crate) fn propagate_to_fixpoint_for_test(&mut self) -> bool {
        if self.is_unsat {
            return true;
        }
        self.propagate().is_some()
    }

    /// Current value of a variable (1-indexed), if assigned.
    #[cfg(test)]
    pub(crate) fn value_of_for_test(&self, v: u32) -> Option<bool> {
        self.var_value((v - 1) as usize)
    }

    /// Verify a model against the installed XOR rows.  The CNF part is
    /// checked separately by [`check_model`].
    pub fn check_xors(&self, model: &[bool]) -> bool {
        self.xors.iter().all(|row| {
            let mut parity = false;
            for v in 0..self.n_vars {
                if bs_get(&row.mask, v) && model[v as usize] {
                    parity = !parity;
                }
            }
            parity == row.rhs
        })
    }

    /// Check a complete external assignment against the exact original
    /// CNF and XOR rows, before accepting any independently produced model.
    /// Learned clauses are deliberately excluded: they are not part of the
    /// exported instance and may depend on a particular search history.
    pub fn check_original_assignment(&self, model: &[bool]) -> bool {
        if self.is_unsat || model.len() != self.n_vars as usize {
            return false;
        }
        self.clause_at
            .iter()
            .take(self.n_orig_clauses)
            .all(|&cref| {
                clause_in(&self.arena, cref).iter().any(|&literal| {
                    let value = model[var_of(literal) as usize];
                    if is_neg(literal) {
                        !value
                    } else {
                        value
                    }
                })
            })
            && self.check_xors(model)
    }

    /// Add a clause `lits` (DIMACS literal encoding). Returns false if
    /// the empty clause is added (immediately UNSAT).
    pub fn add_clause(&mut self, mut lits: Vec<Lit>) -> bool {
        if self.native_admission.is_some() {
            self.native_failure
                .get_or_insert(NativeAdmissionFailure::UncoveredPath);
            return false;
        }
        // Normalisation: the sort's `k⌈log₂ k⌉` comparisons, then one
        // pass each to deduplicate and to test for a tautology.
        let k = lits.len() as u64;
        self.stats.word_ops += k * (64 - k.leading_zeros()) as u64 + 2 * k;
        // Deduplicate and remove tautologies.
        lits.sort_by_key(|&l| (var_of(l), l));
        lits.dedup();
        for w in lits.windows(2) {
            if w[0] == -w[1] {
                return true; // tautology — drop
            }
        }
        self.assert_names_variables(&lits);
        let observed_input = self.observing().then(|| lits.clone());
        // Incremental clauses may arrive after root propagation has
        // already consumed the trail. Remove root-false literals before
        // choosing watches: otherwise both watches can be false with no
        // pending event to visit them, losing a unit or conflicting clause.
        // Root assignments persist across reset_search and are consequences
        // of the permanent formula, so this simplification is sound.
        if self.trail_lim.is_empty() {
            // Two passes of value lookups over the clause.
            self.stats.word_ops += 2 * lits.len() as u64;
            if lits.iter().any(|&l| self.lit_value(l) == Some(true)) {
                return true;
            }
            lits.retain(|&l| self.lit_value(l) != Some(false));
        }
        match lits.len() {
            0 => {
                if let Some(literals) = observed_input {
                    self.emit(SolverEvent::FormulaContradiction {
                        level: self.trail_lim.len(),
                        constraint: SolverEventConstraint::Clause { literals },
                    });
                }
                self.is_unsat = true;
                false
            }
            1 => {
                // Unit clause: assign now (at level 0).
                let l = lits[0];
                // The native unit path assigns before storage. Declare its
                // stable ID first so an incremental trace has no forward
                // reference; push_clause confirms the same declaration.
                if self.observing() {
                    self.emit(SolverEvent::Clause {
                        clause_id: self.event_clause_id(self.next_cref()),
                        literals: vec![l],
                        existing: false,
                        detached: false,
                    });
                }
                match self.enqueue(l, Reason::Propagated(self.next_cref())) {
                    Ok(()) => {
                        self.push_clause(&[l]);
                        self.n_orig_clauses = self.clause_at.len();
                        true
                    }
                    Err(()) => {
                        if let Some(literals) = observed_input {
                            self.emit(SolverEvent::FormulaContradiction {
                                level: self.trail_lim.len(),
                                constraint: SolverEventConstraint::Clause { literals },
                            });
                        }
                        self.is_unsat = true;
                        false
                    }
                }
            }
            _ => {
                let idx = self.push_clause(&lits);
                let (l0, l1) = (lits[0], lits[1]);
                // The two watchers.
                self.stats.word_ops += 2;
                let (w0, w1) = (self.watch_slot(l0), self.watch_slot(l1));
                self.watches[w0].push(Watcher {
                    cref: idx,
                    blocker: l1,
                });
                self.watches[w1].push(Watcher {
                    cref: idx,
                    blocker: l0,
                });
                self.n_orig_clauses = self.clause_at.len();
                true
            }
        }
    }

    /// Install a normalized, non-unit permanent clause without discarding the
    /// current trail. Lazy theory clauses arrive at a propagation fixpoint, so
    /// their watches must be selected from literals that are not currently
    /// false. If only one such literal remains, the clause is unit and is
    /// enqueued immediately; if none remain, the installed clause is the
    /// current conflict.
    ///
    /// False fallback watches are ordered by decreasing decision level. When
    /// conflict analysis backjumps, those are the first literals to become
    /// unassigned, preserving the two-watch invariant without replaying the
    /// whole trail.
    fn add_lazy_clause_at_current_level(&mut self, mut lits: Vec<Lit>) -> Option<Conflict> {
        debug_assert!(lits.len() >= 2);
        // The sort by (not false, level), the non-false prefix scan, two
        // watchers and the unit test.
        let k = lits.len() as u64;
        self.stats.word_ops += 2 * k * (64 - k.leading_zeros()) as u64 + k + 3;
        lits.sort_by(|&left, &right| {
            let key = |lit: Lit| {
                (
                    self.lit_value(lit) != Some(false),
                    self.level[var_of(lit) as usize],
                )
            };
            key(right).cmp(&key(left))
        });
        let non_false = lits
            .iter()
            .take_while(|&&lit| self.lit_value(lit) != Some(false))
            .count();
        let (l0, l1) = (lits[0], lits[1]);
        let idx = self.push_clause(&lits);
        let (w0, w1) = (self.watch_slot(l0), self.watch_slot(l1));
        self.watches[w0].push(Watcher {
            cref: idx,
            blocker: l1,
        });
        self.watches[w1].push(Watcher {
            cref: idx,
            blocker: l0,
        });
        if !self.native_fill_detached(self.clause_at.len()) {
            return None;
        }
        // Theory clauses are permanent propagation lemmas. Advancing this
        // boundary also retains any learnt clauses that preceded them, which
        // costs memory but cannot change an answer.
        self.n_orig_clauses = self.clause_at.len();
        match non_false {
            0 => Some(Conflict::Clause(idx)),
            1 if self.lit_value(l0).is_none() => {
                if self.enqueue(l0, Reason::Propagated(idx)).is_err() {
                    Some(Conflict::Clause(idx))
                } else {
                    None
                }
            }
            _ => None,
        }
    }

    /// Panic unless every literal of `sorted` (sorted by variable, as
    /// [`Solver::add_clause`] sorts) names one of the `n_vars` variables.
    ///
    /// The literal tables are centred on `lit_base`, which can exceed
    /// `n_vars`: a literal past `n_vars` would read the spare slots as an
    /// unassigned variable that nothing watches and quietly weaken the
    /// clause, where the per-variable tables before them panicked on the
    /// index.  0 ends a clause in DIMACS and is no literal; it has the
    /// unused centre slot.  `var_of(0)` underflows: with overflow checks
    /// that is already a panic, and without them it is `u32::MAX`, above
    /// every variable, so 0 and any literal out of range sort last and
    /// one comparison checks the clause.  A scan of the clause cost an
    /// encoding-heavy kernel 0.3% of its instructions.
    #[inline]
    fn assert_names_variables(&self, sorted: &[Lit]) {
        if let Some(&last) = sorted.last() {
            assert!(last != 0, "0 is not a literal");
            assert!(
                var_of(last) < self.n_vars,
                "literal {last} names no variable of this solver ({} variables)",
                self.n_vars
            );
        }
    }

    /// Look up the truth value of a literal under the current trail.
    ///
    /// Literal 0 has a slot of its own, the centre, which is never
    /// assigned: it would read as a literal that is never false.  Debug
    /// builds catch it here, and [`Solver::add_clause`] refuses it in
    /// release builds too.
    #[inline]
    fn lit_value(&self, lit: Lit) -> Option<bool> {
        debug_assert!(lit != 0, "0 is not a literal");
        debug_assert!(var_of(lit) < self.n_vars, "literal {lit} out of range");
        self.values[(lit + self.lit_base as i32) as usize]
    }

    /// Value of 0-indexed variable `v`, if assigned.
    #[inline]
    fn var_value(&self, v: usize) -> Option<bool> {
        debug_assert!(v < self.n_vars as usize, "variable {v} out of range");
        self.values[self.lit_base as usize + 1 + v]
    }

    /// Per-variable assignment, 0-indexed (`None` = unassigned): the
    /// first `n_vars` slots of the positive-literal half of `values`.
    fn assignment(&self) -> &[Option<bool>] {
        &self.values[self.lit_base as usize + 1..][..self.n_vars as usize]
    }

    /// Arena offset the next clause pushed will have, as the `u32` that
    /// watchers and reasons store.  Every push takes its offset from
    /// here, so every stored offset fits.
    fn next_cref(&self) -> u32 {
        u32::try_from(self.arena.len()).expect("clause arena exceeds 2^32 words")
    }

    /// Append a clause to the arena, returning its offset.
    fn push_clause(&mut self, lits: &[Lit]) -> u32 {
        if !self.native_charge(NativeOperation::ClauseGrowth, lits.len() as u64 + 8) {
            return 0;
        }
        let Some(needed) = self
            .arena
            .len()
            .checked_add(lits.len())
            .and_then(|n| n.checked_add(1))
        else {
            self.native_failure = Some(NativeAdmissionFailure::Overflow);
            return 0;
        };
        if !native_reserve(
            &mut self.arena,
            needed,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::ClauseGrowth,
        ) {
            return 0;
        }
        let needed = self.clause_at.len() + 1;
        if !native_reserve(
            &mut self.clause_at,
            needed,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::ClauseGrowth,
        ) {
            return 0;
        }
        if self.observing() && !self.native_event_payload(lits.len(), std::mem::size_of::<Lit>()) {
            return 0;
        }
        let cref = self.next_cref();
        let len = Lit::try_from(lits.len()).expect("clause exceeds 2^31 literals");
        // The length word, the literals, and the index entry.
        self.stats.word_ops += lits.len() as u64 + 2;
        self.arena.push(len);
        self.arena.extend_from_slice(lits);
        self.clause_at.push(cref);
        if self.observing() {
            // Observation remains optional and never changes native work counts.
            // Failure is sticky and censors the trace rather than reusing a key.
            if self.event_clause_ids.try_reserve(1).is_err() {
                self.event_failure = Some("SAT event clause-name allocation refused".into());
            } else if let Some(next) = self.event_next_clause_id.checked_add(len as u32 + 1) {
                self.event_clause_ids.push(self.event_next_clause_id);
                self.event_next_clause_id = next;
            } else {
                self.event_failure = Some("SAT event clause-name space exhausted".into());
            }
        }
        if self.observing() {
            self.emit(SolverEvent::Clause {
                clause_id: self.event_clause_id(cref),
                literals: lits.to_vec(),
                existing: false,
                detached: false,
            });
        }
        cref
    }

    /// Watch-list slot of `lit`.
    #[inline]
    fn watch_slot(&self, lit: Lit) -> usize {
        debug_assert!(lit != 0, "0 is not a literal");
        debug_assert!(var_of(lit) < self.n_vars, "literal {lit} out of range");
        (lit + self.lit_base as i32) as usize
    }

    /// Assign `lit` to true with the given reason. Returns `Err` if it
    /// conflicts with the current assignment.
    fn enqueue(&mut self, lit: Lit, r: Reason) -> Result<(), ()> {
        // The value test; `assign` is charged through `propagations`.
        self.stats.word_ops += 1;
        match self.lit_value(lit) {
            Some(true) => Ok(()),
            Some(false) => Err(()),
            None => {
                self.assign(lit, r);
                Ok(())
            }
        }
    }

    /// [`Self::enqueue`] for a literal the caller knows is unassigned.
    ///
    /// The unit site of clause propagation has just read the literal's
    /// value, and a decision variable has just been checked free; going
    /// through `enqueue` there re-derived a value already in hand, behind
    /// an out-of-line call on the hottest path of the solve.  Forced
    /// inline: left to itself the compiler keeps it out of line, and the
    /// call then costs more than the check it saves.
    #[inline(always)]
    fn assign(&mut self, lit: Lit, r: Reason) {
        if !self.native_charge(NativeOperation::Assignment, 32) {
            return;
        }
        let needed = self.trail.len() + 1;
        if !native_reserve(
            &mut self.trail,
            needed,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::TrailGrowth,
        ) {
            return;
        }
        debug_assert!(self.lit_value(lit).is_none(), "assign over {lit}");
        let v = var_of(lit) as usize;
        let n = self.lit_base as i32;
        self.values[(n + lit) as usize] = Some(true);
        self.values[(n - lit) as usize] = Some(false);
        let (w, bit) = (v / 64, 1u64 << (v % 64));
        self.assigned_w[w] |= bit;
        if is_neg(lit) {
            self.value_w[w] &= !bit;
        } else {
            self.value_w[w] |= bit;
        }
        self.level[v] = self.trail_lim.len() as i32;
        self.reason[v] = r;
        self.saved_phase[v] = !is_neg(lit);
        self.trail.push(lit);
        self.epoch += 1;
        self.stats.propagations += 1;
        if self.observing() {
            if !self.native_assignment_payload(r, v) {
                return;
            }
            self.emit(SolverEvent::Assignment {
                literal: lit,
                level: self.level[v],
                trail_index: self.trail.len() - 1,
                initial: false,
                reason: self.event_reason(r, v),
            });
        }
    }

    /// Propagate to fixpoint over *both* reasoning engines: watched-
    /// literal unit propagation over the CNF, and Gauss-Jordan
    /// elimination over the native XOR rows.  Each engine can feed the
    /// other, so we alternate until neither derives anything new.
    ///
    /// Returns `Some(clause_idx)` on conflict.  For an XOR conflict the
    /// index points at a freshly installed clause that is falsified by
    /// the current trail, so `analyze()` and `backjump()` handle it with
    /// no special-casing.
    fn propagate(&mut self) -> Option<Conflict> {
        loop {
            if (self.event_failure.is_some() || self.native_failure.is_some()) {
                return None;
            }
            self.progress_phase(SolverProgressPhase::ClausePropagation);
            let t = std::time::Instant::now();
            let cnf = self.propagate_clauses();
            self.stats.ns_propagate_clauses += t.elapsed().as_nanos() as u64;
            self.progress_phase(SolverProgressPhase::Idle);
            if (self.event_failure.is_some() || self.native_failure.is_some()) {
                return None;
            }
            if let Some(c) = cnf {
                return Some(Conflict::Clause(c));
            }
            if self.xors.is_empty() || self.epoch == self.xor_epoch {
                // Nothing has moved since the last Gauss-Jordan pass.
                return None;
            }
            if self.xor_decision_cadence > 1
                && !self
                    .trail_lim
                    .len()
                    .is_multiple_of(self.xor_decision_cadence)
                && self.trail.len() != self.n_vars as usize
            {
                // CNF is at a fixpoint. A later decision-level boundary,
                // restart, or complete assignment must still check XOR.
                return None;
            }
            self.xor_epoch = self.epoch;
            self.progress_phase(SolverProgressPhase::XorPropagation);
            let t = std::time::Instant::now();
            let step = self.propagate_xors();
            self.stats.ns_propagate_xors += t.elapsed().as_nanos() as u64;
            if let Some(progress) = &self.progress {
                progress
                    .xor_passes
                    .store(self.stats.xor_passes, Ordering::Relaxed);
                progress
                    .xor_nanoseconds
                    .store(self.stats.ns_propagate_xors, Ordering::Relaxed);
                progress
                    .xor_row_scans
                    .store(self.stats.xor_row_scans, Ordering::Relaxed);
                progress
                    .xor_repivots
                    .store(self.stats.xor_repivots, Ordering::Relaxed);
                progress
                    .xor_row_ops
                    .store(self.stats.xor_row_ops, Ordering::Relaxed);
            }
            self.progress_phase(SolverProgressPhase::Idle);
            match step {
                XorStep::Refused => return None,
                XorStep::Conflict => return Some(Conflict::Xor),
                XorStep::Propagated => continue,
                XorStep::Fixpoint => return None,
            }
        }
    }

    /// One Gauss-Jordan pass over the XOR rows under the current trail.
    ///
    /// Each row carries the *full* variable set of its combination, and
    /// its right-hand side is the combination's original rhs; the value
    /// implied by the current assignment is therefore
    /// `rhs ⊕ parity(mask ∩ assigned-true)`.  Because both mask and rhs
    /// XOR when two rows are combined, that relation survives
    /// elimination — which is what lets us read a reason clause straight
    /// off a reduced row.
    fn propagate_xors(&mut self) -> XorStep {
        if self.native_admission.is_some() {
            self.propagate_xors_admitted()
        } else {
            self.propagate_xors_legacy()
        }
    }

    /// One Gauss-Jordan pass over the XOR rows under the current trail.
    ///
    /// Each row carries the *full* variable set of its combination, and
    /// its right-hand side is the combination's original rhs; the value
    /// implied by the current assignment is therefore
    /// `rhs ⊕ parity(mask ∩ assigned-true)`.  Because both mask and rhs
    /// XOR when two rows are combined, that relation survives
    /// elimination — which is what lets us read a reason clause straight
    /// off a reduced row.
    fn propagate_xors_legacy(&mut self) -> XorStep {
        self.stats.xor_passes += 1;
        let words = bs_words(self.n_vars);
        if self.matrix_rhs.len() != self.xors.len() {
            self.rebuild_matrix();
        }
        let rows = self.matrix_rhs.len();
        // Each pass tests every row's pivot (phase 1) and every row's
        // pivot slot again (phase 2): two per row, plus the epoch test.
        self.stats.word_ops += 2 * rows as u64 + 1;

        // ── Phase 1: restore the pivot invariant ────────────────────
        //
        // Only rows whose pivot has since been assigned are touched, so
        // the usual cost is `O(broken rows × rows × words)` rather than
        // the `O(rows² × words)` of re-eliminating from scratch.
        let mut step = XorStep::Fixpoint;
        for i in 0..rows {
            if self.event_failure.is_some() {
                return XorStep::Fixpoint;
            }
            let intact = match self.pivot[i] {
                Some(p) => self.var_value(p as usize).is_none(),
                None => false,
            };
            if intact {
                continue;
            }
            self.stats.xor_repivots += 1;

            let row_i = i * words..(i + 1) * words;
            let next_pivot = if self.indexed_xors {
                self.matrix_support[i].iter().find_map(|&w| {
                    let free = self.matrix[i * words + w] & !self.assigned_w[w];
                    (free != 0).then(|| (w * 64) as u32 + free.trailing_zeros())
                })
            } else {
                self.lowest_unassigned(&self.matrix[row_i.clone()])
            };
            match next_pivot {
                None => {
                    // No unassigned variable left: the row is decided.
                    // Its words were scanned for a pivot, then for the
                    // residual parity.
                    self.stats.word_ops += 2 * words as u64;
                    self.pivot[i] = None;
                    if self.row_residual(i, words) {
                        let mut buf = std::mem::take(&mut self.xor_conflict);
                        self.write_xor_reason(&self.matrix[row_i], None, &mut buf);
                        // The reason: one per row word, one per literal.
                        self.stats.word_ops += (words + buf.len()) as u64;
                        self.xor_conflict = buf;
                        self.stats.xor_conflicts += 1;
                        if self.observing() {
                            self.emit(SolverEvent::XorConflict {
                                row_id: i,
                                explanation: self.xor_conflict.clone(),
                            });
                        }
                        return XorStep::Conflict;
                    }
                }
                Some(p) => {
                    self.pivot[i] = Some(p);
                    // Clear `p` from every other row, so it lives in
                    // this one alone.  The row is copied out once, the
                    // matrix is walked through local slices with a local
                    // counter, and the row XOR is out of line: the
                    // column test then compiles to a load and a test per
                    // row instead of sharing registers with the XOR.
                    let (pw, pbit) = (p as usize / 64, 1u64 << (p % 64));
                    let src_rhs = self.matrix_rhs[i];
                    let mut src = std::mem::take(&mut self.xor_src);
                    let mut support = std::mem::take(&mut self.xor_support_src);
                    let mut merged = std::mem::take(&mut self.xor_support_merge);
                    if self.indexed_xors {
                        src.resize(words, 0);
                        support.clear();
                        support.extend_from_slice(&self.matrix_support[i]);
                        for &w in &support {
                            src[w] = self.matrix[i * words + w];
                        }
                    } else {
                        src.clear();
                        src.extend_from_slice(&self.matrix[row_i]);
                    }
                    let matrix = &mut self.matrix[..rows * words];
                    let matrix_rhs = &mut self.matrix_rhs[..rows];
                    let mut row_ops = 0u64;
                    for j in 0..rows {
                        if j == i || matrix[j * words + pw] & pbit == 0 {
                            continue;
                        }
                        row_ops += 1;
                        matrix_rhs[j] ^= src_rhs;
                        let target = &mut matrix[j * words..(j + 1) * words];
                        if self.indexed_xors {
                            for &w in &support {
                                target[w] ^= src[w];
                            }
                            self.stats.xor_word_updates += support.len() as u64;
                            // Merge the sorted supports after cancellation, preserving
                            // ascending word/pivot/reason order exactly.
                            merged.clear();
                            let old = &self.matrix_support[j];
                            let (mut a, mut b) = (0, 0);
                            while a < old.len() || b < support.len() {
                                let w = match (old.get(a), support.get(b)) {
                                    (Some(&x), Some(&y)) => x.min(y),
                                    (Some(&x), None) => x,
                                    (None, Some(&y)) => y,
                                    _ => unreachable!(),
                                };
                                if old.get(a) == Some(&w) {
                                    a += 1;
                                }
                                if support.get(b) == Some(&w) {
                                    b += 1;
                                }
                                self.stats.xor_support_visits += 1;
                                if target[w] != 0 {
                                    merged.push(w);
                                }
                            }
                            std::mem::swap(&mut self.matrix_support[j], &mut merged);
                        } else {
                            xor_into(target, &src);
                            self.stats.xor_word_updates += words as u64;
                        }
                        if self.event_observer.is_some() && self.event_failure.is_none() {
                            emit_to(
                                &mut self.event_observer,
                                &mut self.event_failure,
                                SolverEvent::XorRowXor {
                                    destination: j,
                                    source: i,
                                },
                            );
                        }
                    }
                    self.stats.xor_row_ops += row_ops;
                    // Pivot search up to `p`'s word, the row copied out,
                    // the column tested in every row, and each row
                    // operation's `words` XORs plus its rhs.
                    self.stats.word_ops +=
                        (pw + 1 + words + rows) as u64 + row_ops * (words as u64 + 1);
                    self.xor_src = src;
                    self.xor_support_src = support;
                    self.xor_support_merge = merged;
                }
            }
        }

        // ── Phase 2: read off unit implications ─────────────────────
        //
        // With the invariant restored, a row implies something exactly
        // when its pivot is its *only* unassigned variable — so this is
        // a popcount, and no further elimination is needed.
        let mut propagated = false;
        'rows: for i in 0..rows {
            if self.event_failure.is_some() {
                return XorStep::Fixpoint;
            }
            let p = match self.pivot[i] {
                Some(p) => p,
                None => continue, // decided in phase 1
            };
            self.stats.xor_row_scans += 1;
            let parity = if self.indexed_xors {
                let Some(parity) =
                    self.unit_parity(i, words, p, self.matrix_support[i].iter().copied())
                else {
                    continue 'rows;
                };
                parity
            } else {
                let row = &self.matrix[i * words..(i + 1) * words];
                let mut parity = self.matrix_rhs[i];
                for (w, ((&m, &assigned), &value)) in row
                    .iter()
                    .zip(&self.assigned_w)
                    .zip(&self.value_w)
                    .enumerate()
                {
                    if m == 0 {
                        continue;
                    }
                    let free = m & !assigned;
                    if free.count_ones() > 1
                        || (free != 0 && free.trailing_zeros() + (w * 64) as u32 != p)
                    {
                        self.stats.word_ops += w as u64 + 1;
                        continue 'rows;
                    }
                    parity ^= ((m & assigned & value).count_ones() & 1) == 1;
                }
                parity
            };

            // The read-off reached the end of the row.
            self.stats.word_ops += words as u64;
            let lit = if parity {
                (p + 1) as Lit
            } else {
                -((p + 1) as Lit)
            };
            let mut buf = std::mem::take(&mut self.xor_reason[p as usize]);
            self.write_xor_reason(
                &self.matrix[i * words..(i + 1) * words],
                Some(lit),
                &mut buf,
            );
            self.stats.xor_reason_lits += buf.len() as u64;
            // The reason: one per row word, one per literal.
            self.stats.word_ops += (words + buf.len()) as u64;
            self.xor_reason[p as usize] = buf;
            self.stats.xor_propagations += 1;
            if self.observing() {
                self.emit(SolverEvent::XorImplication {
                    row_id: i,
                    literal: lit,
                    explanation: self.xor_reason[p as usize].clone(),
                });
            }
            if self.enqueue(lit, Reason::XorPropagated).is_err() {
                // Unreachable while the invariant holds — the pivot was
                // unassigned — but treat it as a conflict rather than
                // silently dropping an implication.
                std::mem::swap(&mut self.xor_conflict, &mut self.xor_reason[p as usize]);
                self.stats.xor_conflicts += 1;
                return XorStep::Conflict;
            }
            propagated = true;
        }

        match step {
            XorStep::Conflict => XorStep::Conflict,
            _ if propagated => {
                step = XorStep::Propagated;
                step
            }
            _ => XorStep::Fixpoint,
        }
    }

    /// One Gauss-Jordan pass over the XOR rows under the current trail.
    ///
    /// Each row carries the *full* variable set of its combination, and
    /// its right-hand side is the combination's original rhs; the value
    /// implied by the current assignment is therefore
    /// `rhs ⊕ parity(mask ∩ assigned-true)`.  Because both mask and rhs
    /// XOR when two rows are combined, that relation survives
    /// elimination — which is what lets us read a reason clause straight
    /// off a reduced row.
    fn propagate_xors_admitted(&mut self) -> XorStep {
        if !self.native_charge(NativeOperation::XorSetup, 32) {
            return XorStep::Refused;
        }
        self.stats.xor_passes += 1;
        let words = bs_words(self.n_vars);
        if self.matrix_rhs.len() != self.xors.len() {
            self.rebuild_matrix();
            if self.native_failure.is_some() || self.native_observer_refused() {
                return XorStep::Refused;
            }
        }
        let rows = self.matrix_rhs.len();
        // Each pass tests every row's pivot (phase 1) and every row's
        // pivot slot again (phase 2): two per row, plus the epoch test.
        self.stats.word_ops += 2 * rows as u64 + 1;

        // ── Phase 1: restore the pivot invariant ────────────────────
        //
        // Only rows whose pivot has since been assigned are touched, so
        // the usual cost is `O(broken rows × rows × words)` rather than
        // the `O(rows² × words)` of re-eliminating from scratch.
        let mut step = XorStep::Fixpoint;
        for i in 0..rows {
            if self.native_failure.is_some() || self.native_observer_refused() {
                return XorStep::Refused;
            }
            if self.event_failure.is_some() {
                return XorStep::Fixpoint;
            }
            if !self.native_charge(NativeOperation::XorPivot, 16) {
                return XorStep::Refused;
            }
            let intact = match self.pivot[i] {
                Some(p) => self.var_value(p as usize).is_none(),
                None => false,
            };
            if intact {
                continue;
            }
            self.stats.xor_repivots += 1;

            let row_i = i * words..(i + 1) * words;
            // Prepay bounded scans before helpers borrow the matrix.
            if !self.native_charge(NativeOperation::XorScan, 2 * words as u64 + 1) {
                return XorStep::Refused;
            }
            let lowest = if self.native_admission.is_some() {
                match self.native_lowest(row_i.clone()) {
                    Ok(v) => v,
                    Err(()) => return XorStep::Refused,
                }
            } else {
                self.lowest_unassigned(&self.matrix[row_i.clone()])
            };
            match lowest {
                None => {
                    // No unassigned variable left: the row is decided.
                    // Its words were scanned for a pivot, then for the
                    // residual parity.
                    self.stats.word_ops += 2 * words as u64;
                    self.pivot[i] = None;
                    let residual = if self.native_admission.is_some() {
                        match self.native_residual(i, words) {
                            Ok(v) => v,
                            Err(()) => return XorStep::Refused,
                        }
                    } else {
                        self.row_residual(i, words)
                    };
                    if residual {
                        if !self.native_charge(
                            NativeOperation::XorReason,
                            (words + self.n_vars as usize + 1) as u64,
                        ) {
                            return XorStep::Refused;
                        }
                        if !native_reserve(
                            &mut self.xor_conflict,
                            self.n_vars as usize,
                            &mut self.native_admission,
                            &mut self.native_failure,
                            self.deadline,
                            NativeOperation::XorGrowth,
                        ) {
                            return XorStep::Refused;
                        }
                        let mut buf = std::mem::take(&mut self.xor_conflict);
                        if self.native_admission.is_some() {
                            if !self.native_reason(row_i, None, &mut buf) {
                                self.xor_conflict = buf;
                                return XorStep::Refused;
                            }
                        } else {
                            self.write_xor_reason(&self.matrix[row_i], None, &mut buf);
                        }
                        // The reason: one per row word, one per literal.
                        self.stats.word_ops += (words + buf.len()) as u64;
                        self.xor_conflict = buf;
                        self.stats.xor_conflicts += 1;
                        if self.observing() {
                            if !self.native_event_payload(
                                self.xor_conflict.len(),
                                std::mem::size_of::<Lit>(),
                            ) {
                                return XorStep::Refused;
                            }
                            self.emit(SolverEvent::XorConflict {
                                row_id: i,
                                explanation: self.xor_conflict.clone(),
                            });
                        }
                        if self.native_observer_refused() {
                            return XorStep::Refused;
                        }
                        return XorStep::Conflict;
                    }
                }
                Some(p) => {
                    self.pivot[i] = Some(p);
                    // Clear `p` from every other row, so it lives in
                    // this one alone.  The row is copied out once, the
                    // matrix is walked through local slices with a local
                    // counter, and the row XOR is out of line: the
                    // column test then compiles to a load and a test per
                    // row instead of sharing registers with the XOR.
                    let (pw, pbit) = (p as usize / 64, 1u64 << (p % 64));
                    let src_rhs = self.matrix_rhs[i];
                    if !self.native_charge(NativeOperation::XorScan, words as u64) {
                        return XorStep::Refused;
                    }
                    if !native_reserve(
                        &mut self.xor_src,
                        words,
                        &mut self.native_admission,
                        &mut self.native_failure,
                        self.deadline,
                        NativeOperation::XorGrowth,
                    ) {
                        return XorStep::Refused;
                    }
                    let mut src = std::mem::take(&mut self.xor_src);
                    src.clear();
                    if self.native_admission.is_some() {
                        for chunk in self.matrix[row_i].chunks(64) {
                            if !native_pay(
                                &mut self.native_admission,
                                &mut self.native_failure,
                                self.deadline,
                                NativeOperation::XorScan,
                                0,
                                0,
                            ) {
                                self.xor_src = src;
                                return XorStep::Refused;
                            }
                            src.extend_from_slice(chunk);
                        }
                    } else {
                        src.extend_from_slice(&self.matrix[row_i]);
                    }
                    let matrix = &mut self.matrix[..rows * words];
                    let matrix_rhs = &mut self.matrix_rhs[..rows];
                    let mut row_ops = 0u64;
                    for j in 0..rows {
                        if !native_pay(
                            &mut self.native_admission,
                            &mut self.native_failure,
                            self.deadline,
                            NativeOperation::XorScan,
                            1,
                            0,
                        ) {
                            break;
                        }
                        if j == i || matrix[j * words + pw] & pbit == 0 {
                            continue;
                        }
                        if !native_pay(
                            &mut self.native_admission,
                            &mut self.native_failure,
                            self.deadline,
                            NativeOperation::XorWord,
                            words as u64 + 1,
                            0,
                        ) {
                            break;
                        }
                        row_ops += 1;
                        if self.native_admission.is_some() {
                            self.native_partial_xor = Some((i, j, 0, true));
                        }
                        matrix_rhs[j] ^= src_rhs;
                        if self.native_admission.is_some() {
                            for (dest, source) in matrix[j * words..(j + 1) * words]
                                .chunks_mut(64)
                                .zip(src.chunks(64))
                            {
                                if !native_pay(
                                    &mut self.native_admission,
                                    &mut self.native_failure,
                                    self.deadline,
                                    NativeOperation::XorWord,
                                    dest.len() as u64,
                                    0,
                                ) {
                                    break;
                                }
                                xor_into(dest, source);
                                if let Some(partial) = &mut self.native_partial_xor {
                                    partial.2 += dest.len();
                                }
                            }
                            if self.native_failure.is_some() {
                                break;
                            }
                        } else {
                            xor_into(&mut matrix[j * words..(j + 1) * words], &src);
                        }
                        if self.event_observer.is_some()
                            && (self.event_failure.is_none() && self.native_failure.is_none())
                        {
                            if !native_pay(
                                &mut self.native_admission,
                                &mut self.native_failure,
                                self.deadline,
                                NativeOperation::EventPayload,
                                32,
                                128,
                            ) {
                                break;
                            }
                            emit_to(
                                &mut self.event_observer,
                                &mut self.event_failure,
                                SolverEvent::XorRowXor {
                                    destination: j,
                                    source: i,
                                },
                            );
                        }
                        if self.native_admission.is_some() && self.event_failure.is_some() {
                            break;
                        }
                        if self.event_failure.is_none() {
                            self.native_partial_xor = None;
                        }
                    }
                    self.stats.xor_row_ops += row_ops;
                    // Pivot search up to `p`'s word, the row copied out,
                    // the column tested in every row, and each row
                    // operation's `words` XORs plus its rhs.
                    self.stats.word_ops +=
                        (pw + 1 + words + rows) as u64 + row_ops * (words as u64 + 1);
                    self.xor_src = src;
                    if self.native_failure.is_some() || self.native_observer_refused() {
                        return XorStep::Refused;
                    }
                }
            }
        }

        // ── Phase 2: read off unit implications ─────────────────────
        //
        // With the invariant restored, a row implies something exactly
        // when its pivot is its *only* unassigned variable — so this is
        // a popcount, and no further elimination is needed.
        let mut propagated = false;
        'rows: for i in 0..rows {
            if self.native_failure.is_some() || self.native_observer_refused() {
                return XorStep::Refused;
            }
            if self.event_failure.is_some() {
                return XorStep::Fixpoint;
            }
            if !self.native_charge(NativeOperation::XorPivot, 16) {
                return XorStep::Refused;
            }
            let p = match self.pivot[i] {
                Some(p) => p,
                None => continue, // decided in phase 1
            };
            self.stats.xor_row_scans += 1;
            let row = &self.matrix[i * words..(i + 1) * words];
            let mut parity = self.matrix_rhs[i];
            for (w, ((&m, &assigned), &value)) in row
                .iter()
                .zip(&self.assigned_w)
                .zip(&self.value_w)
                .enumerate()
            {
                if !native_pay(
                    &mut self.native_admission,
                    &mut self.native_failure,
                    self.deadline,
                    NativeOperation::XorWord,
                    8,
                    0,
                ) {
                    return XorStep::Refused;
                }
                if m == 0 {
                    continue;
                }
                let free = m & !assigned;
                if free.count_ones() > 1
                    || (free != 0 && free.trailing_zeros() + (w * 64) as u32 != p)
                {
                    // The read-off stopped at word `w`.
                    self.stats.word_ops += w as u64 + 1;
                    continue 'rows;
                }
                parity ^= ((m & assigned & value).count_ones() & 1) == 1;
            }

            // The read-off reached the end of the row.
            self.stats.word_ops += words as u64;
            let lit = if parity {
                (p + 1) as Lit
            } else {
                -((p + 1) as Lit)
            };
            if !self.native_charge(
                NativeOperation::XorReason,
                (words + self.n_vars as usize + 1) as u64,
            ) {
                return XorStep::Refused;
            }
            if !native_reserve(
                &mut self.xor_reason[p as usize],
                self.n_vars as usize,
                &mut self.native_admission,
                &mut self.native_failure,
                self.deadline,
                NativeOperation::XorGrowth,
            ) {
                return XorStep::Refused;
            }
            let mut buf = std::mem::take(&mut self.xor_reason[p as usize]);
            if self.native_admission.is_some() {
                if !self.native_reason(i * words..(i + 1) * words, Some(lit), &mut buf) {
                    self.xor_reason[p as usize] = buf;
                    return XorStep::Refused;
                }
            } else {
                self.write_xor_reason(
                    &self.matrix[i * words..(i + 1) * words],
                    Some(lit),
                    &mut buf,
                );
            }
            self.stats.xor_reason_lits += buf.len() as u64;
            // The reason: one per row word, one per literal.
            self.stats.word_ops += (words + buf.len()) as u64;
            self.xor_reason[p as usize] = buf;
            self.stats.xor_propagations += 1;
            if self.observing() {
                if !self.native_event_payload(
                    self.xor_reason[p as usize].len(),
                    std::mem::size_of::<Lit>(),
                ) {
                    return XorStep::Refused;
                }
                self.emit(SolverEvent::XorImplication {
                    row_id: i,
                    literal: lit,
                    explanation: self.xor_reason[p as usize].clone(),
                });
            }
            if self.native_observer_refused() {
                return XorStep::Refused;
            }
            if self.enqueue(lit, Reason::XorPropagated).is_err() {
                // Unreachable while the invariant holds — the pivot was
                // unassigned — but treat it as a conflict rather than
                // silently dropping an implication.
                std::mem::swap(&mut self.xor_conflict, &mut self.xor_reason[p as usize]);
                self.stats.xor_conflicts += 1;
                return XorStep::Conflict;
            }
            if self.native_failure.is_some() || self.native_observer_refused() {
                return XorStep::Refused;
            }
            propagated = true;
        }

        if !self.native_charge(NativeOperation::XorSetup, 1) {
            return XorStep::Refused;
        }
        match step {
            XorStep::Refused => XorStep::Refused,
            XorStep::Conflict => XorStep::Conflict,
            _ if propagated => {
                step = XorStep::Propagated;
                step
            }
            _ => XorStep::Fixpoint,
        }
    }

    /// Reset the working matrix to the original rows, dropping every
    /// pivot assignment.  The next pass re-eliminates from scratch.
    ///
    /// Row operations are never undone, so the matrix accumulates
    /// fill-in over a long solve: rows drift denser, which lengthens
    /// the reason clauses read off them.  Rebuilding at restarts, where
    /// the trail is empty anyway, bounds that drift.
    fn rebuild_matrix(&mut self) {
        if !self.native_charge(NativeOperation::XorSetup, self.xors.len() as u64) {
            return;
        }
        let mut total = 0usize;
        for row in &self.xors {
            if !native_pay(
                &mut self.native_admission,
                &mut self.native_failure,
                self.deadline,
                NativeOperation::XorSetup,
                0,
                0,
            ) {
                return;
            }
            let Some(next) = total.checked_add(row.mask.len()) else {
                self.native_failure = Some(NativeAdmissionFailure::Overflow);
                return;
            };
            total = next;
        }
        if !native_reserve(
            &mut self.matrix,
            total,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::XorGrowth,
        ) {
            return;
        }
        if !native_reserve(
            &mut self.matrix_rhs,
            self.xors.len(),
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::XorGrowth,
        ) {
            return;
        }
        if !native_reserve(
            &mut self.pivot,
            self.xors.len(),
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::XorGrowth,
        ) {
            return;
        }
        if !self.native_charge(
            NativeOperation::XorSetup,
            total as u64 + 2 * self.xors.len() as u64,
        ) {
            return;
        }
        // Every row's words copied, its rhs and its pivot slot reset.
        self.stats.word_ops += total as u64 + 2 * self.xors.len() as u64;
        self.matrix.clear();
        self.matrix_rhs.clear();
        self.matrix_support.clear();
        for row in &self.xors {
            if self.native_admission.is_some() {
                for chunk in row.mask.chunks(64) {
                    if !native_pay(
                        &mut self.native_admission,
                        &mut self.native_failure,
                        self.deadline,
                        NativeOperation::XorWord,
                        chunk.len() as u64,
                        0,
                    ) {
                        return;
                    }
                    self.matrix.extend_from_slice(chunk);
                }
            } else {
                self.matrix.extend_from_slice(&row.mask);
            }
            self.matrix_rhs.push(row.rhs);
            self.matrix_support.push(if self.indexed_xors {
                row.mask
                    .iter()
                    .enumerate()
                    .filter_map(|(w, &m)| (m != 0).then_some(w))
                    .collect()
            } else {
                Vec::new()
            });
        }
        self.pivot.clear();
        if self.native_admission.is_some() {
            while self.pivot.len() < self.matrix_rhs.len() {
                let end = self
                    .pivot
                    .len()
                    .saturating_add(64)
                    .min(self.matrix_rhs.len());
                if !self.native_charge(NativeOperation::XorPivot, (end - self.pivot.len()) as u64) {
                    return;
                }
                self.pivot.resize(end, None);
            }
        } else {
            self.pivot.resize(self.matrix_rhs.len(), None);
        }
        if self.observing() {
            if !self.native_event_payload(0, 0) {
                return;
            }
            self.emit(SolverEvent::XorMatrixReset);
        }
    }

    /// Select the dense reference or exact nonzero-word engine. Resetting the
    /// matrix preserves the original constraints and trail.
    pub fn set_indexed_xors(&mut self, indexed: bool) {
        self.indexed_xors = indexed;
        self.clear_matrix();
        self.xor_epoch = u64::MAX;
    }

    /// Drop the working matrix; the next pass rebuilds it from `xors`.
    fn clear_matrix(&mut self) {
        self.matrix.clear();
        self.matrix_rhs.clear();
        self.matrix_support.clear();
    }

    fn unit_parity(
        &self,
        i: usize,
        words: usize,
        p: u32,
        positions: impl Iterator<Item = usize>,
    ) -> Option<bool> {
        let mut parity = self.matrix_rhs[i];
        for w in positions {
            let m = self.matrix[i * words + w];
            if m == 0 {
                continue;
            }
            let free = m & !self.assigned_w[w];
            if free.count_ones() > 1 || (free != 0 && free.trailing_zeros() + (w * 64) as u32 != p)
            {
                return None;
            }
            parity ^= ((m & self.assigned_w[w] & self.value_w[w]).count_ones() & 1) == 1;
        }
        Some(parity)
    }

    /// `rhs ⊕ parity(assigned-true variables of the row)` — zero when a
    /// fully assigned row is satisfied.
    fn row_residual(&self, i: usize, words: usize) -> bool {
        let mut parity = self.matrix_rhs[i];
        if self.indexed_xors {
            for &w in &self.matrix_support[i] {
                parity ^= ((self.matrix[i * words + w] & self.assigned_w[w] & self.value_w[w])
                    .count_ones()
                    & 1)
                    == 1;
            }
            return parity;
        }
        for (w, &m) in self.matrix[i * words..(i + 1) * words].iter().enumerate() {
            if m != 0 {
                parity ^= ((m & self.assigned_w[w] & self.value_w[w]).count_ones() & 1) == 1;
            }
        }
        parity
    }

    /// Lowest-numbered unassigned variable in `mask`, if any.
    fn lowest_unassigned(&self, mask: &[u64]) -> Option<u32> {
        for (w, &word) in mask.iter().enumerate() {
            let free = word & !self.assigned_w[w];
            if free != 0 {
                return Some((w * 64) as u32 + free.trailing_zeros());
            }
        }
        None
    }

    /// Build the clause witnessing what a reduced XOR row implies:
    /// every assigned variable of the row appears negated-as-assigned,
    /// so the clause is false under the current trail except for
    /// `implied` (absent for a conflict clause, which is wholly false).
    ///
    /// Only the row's *assigned* variables are walked, and each sign is
    /// read from the `value_w` bit already in the word being scanned.
    /// Every variable of the row but `implied`'s is assigned — that is
    /// what made the row unit or conflicting — and `implied`'s is not,
    /// so this writes exactly the literals the per-variable lookup did.
    fn write_xor_reason(&self, mask: &[u64], implied: Option<Lit>, clause: &mut Vec<Lit>) {
        clause.clear();
        if let Some(l) = implied {
            debug_assert!(
                self.lit_value(l).is_none(),
                "implied literal already assigned"
            );
            clause.push(l);
        }
        for (w, &word) in mask.iter().enumerate() {
            if cfg!(debug_assertions) {
                let implied_bit = match implied {
                    Some(l) if var_of(l) as usize / 64 == w => 1u64 << (var_of(l) % 64),
                    _ => 0,
                };
                assert_eq!(
                    word & !self.assigned_w[w] & !implied_bit,
                    0,
                    "reason clause over an unassigned variable"
                );
            }
            let (mut bits, value) = (word & self.assigned_w[w], self.value_w[w]);
            while bits != 0 {
                let b = bits.trailing_zeros();
                bits &= bits - 1;
                let v = ((w * 64) as u32 + b + 1) as Lit;
                clause.push(if (value >> b) & 1 == 1 { -v } else { v });
            }
        }
    }

    /// Unit propagation over the CNF. Returns the falsified clause's
    /// offset on conflict.
    ///
    /// The loop reads the clause arena, the value table and the watch
    /// lists as separate fields, so a clause stays borrowed while values
    /// are looked up and watches moved.  The two work counters are
    /// bumped in `stats` directly: moved into locals they did not get
    /// registers, and the spills also pushed the watch list's pointer
    /// out of one in the blocker loop, which cost up to 2% more
    /// instructions than the in-place increments.
    fn propagate_clauses(&mut self) -> Option<u32> {
        let n = self.lit_base as i32;
        let mut conflict: Option<u32> = None;
        while conflict.is_none()
            && self.qhead < self.trail.len()
            && (self.event_failure.is_none() && self.native_failure.is_none())
        {
            let lit = self.trail[self.qhead];
            self.qhead += 1;
            // Clauses watching `¬lit` — that watcher has just become
            // false, so each needs a replacement or is unit.
            let false_lit = -lit;
            let wi = (false_lit + n) as usize;
            // Compact the watch list in place with a read and a write
            // cursor.  Building a fresh vector here meant one heap
            // allocation per propagated literal, which at ~280
            // propagations a conflict is millions per solve.
            if !self.native_charge(
                NativeOperation::WatchList,
                1 + self.watches[wi].len() as u64,
            ) {
                return None;
            }
            let mut ws = std::mem::take(&mut self.watches[wi]);
            // The trail read, then every watcher once: its blocker test
            // and write-back in the scan, or its copy after a conflict.
            // (Clause dereferences and replacement searches are charged
            // through `clause_visits` and `clause_lit_visits`.)
            self.stats.word_ops += 1 + ws.len() as u64;
            let (mut i, mut j) = (0usize, 0usize);

            while i < ws.len() {
                if (self.event_failure.is_some() || self.native_failure.is_some()) {
                    break;
                }
                if !self.native_charge(NativeOperation::Watcher, 32) {
                    break;
                }
                let w = ws[i];
                i += 1;
                // Blocker: if this literal is already true the clause is
                // satisfied and is never dereferenced.
                if self.values[(w.blocker + n) as usize] == Some(true) {
                    ws[j] = w;
                    j += 1;
                    continue;
                }
                let cref = w.cref;
                self.stats.clause_visits += 1;

                // Canonical layout: the false watcher sits at [0].  A
                // watched clause has at least two literals, so splitting
                // off the watched pair is the one length check here.
                let (watch, rest) = clause_in_mut(&mut self.arena, cref).split_at_mut(2);
                if watch[0] != false_lit {
                    watch.swap(0, 1);
                }
                let other = watch[1];
                let other_value = self.values[(other + n) as usize];
                if other_value == Some(true) {
                    ws[j] = Watcher {
                        cref,
                        blocker: other,
                    };
                    j += 1;
                    continue;
                }

                // Look for a literal that is not false to watch instead.
                let mut moved = false;
                for slot in rest.iter_mut() {
                    if !native_pay(
                        &mut self.native_admission,
                        &mut self.native_failure,
                        self.deadline,
                        NativeOperation::Literal,
                        1,
                        0,
                    ) {
                        break;
                    }
                    self.stats.clause_lit_visits += 1;
                    let l = *slot;
                    if self.values[(l + n) as usize] != Some(false) {
                        let destination = (l + n) as usize;
                        let needed = self.watches[destination].len() + 1;
                        if !native_reserve(
                            &mut self.watches[destination],
                            needed,
                            &mut self.native_admission,
                            &mut self.native_failure,
                            self.deadline,
                            NativeOperation::WatchGrowth,
                        ) {
                            break;
                        }
                        // Swap it into the watched position.
                        *slot = watch[0];
                        watch[0] = l;
                        // `l` is not false and `¬lit` is, so this never
                        // writes back into the list being compacted.
                        self.watches[(l + n) as usize].push(Watcher {
                            cref,
                            blocker: other,
                        });
                        // The literal swap and the new watcher.
                        self.stats.word_ops += 2;
                        moved = true;
                        break;
                    }
                }
                if self.native_failure.is_some() {
                    ws[j] = w;
                    j += 1;
                    break;
                }
                if moved {
                    continue; // the watch now lives elsewhere
                }

                // No replacement: the clause is unit in `other`, or
                // falsified.
                watch[0] = false_lit;
                ws[j] = Watcher {
                    cref,
                    blocker: other,
                };
                j += 1;
                match other_value {
                    // Nothing has been assigned since `other_value` was
                    // read, so `other` is still free.
                    None => self.assign(other, Reason::Propagated(cref)),
                    Some(false) => {
                        conflict = Some(cref);
                        break;
                    }
                    Some(true) => unreachable!("handled above"),
                }
            }

            // Refusal retains both the compacted prefix and untouched suffix.
            if self.native_admission.is_some()
                && (self.native_failure.is_some() || self.event_failure.is_some())
            {
                self.native_pending_watch = Some((wi, ws, i, j));
                return None;
            }
            // Successful/conflict cleanup was prepaid by WatchList; check the
            // original deadline before every bounded copy batch.
            while i < ws.len() {
                if i % 64 == 0 && !self.native_charge(NativeOperation::WatchList, 0) {
                    self.native_pending_watch = Some((wi, ws, i, j));
                    return None;
                }
                ws[j] = ws[i];
                i += 1;
                j += 1;
            }
            ws.truncate(j);
            self.watches[wi] = ws;
        }
        conflict
    }

    /// **Is `p` implied by the rest of the learnt clause?**
    ///
    /// Walks the implication graph backwards rather than looking only
    /// one step at a reason (Eén–Sörensson's `litRedundant`).  The
    /// distinction matters far more with a parity engine than in
    /// ordinary CDCL: every parity implication's reason names each
    /// assigned variable of its row, so reasons overlap heavily and a
    /// literal is usually reachable through a chain rather than
    /// directly.
    ///
    /// Marks made on a successful walk are kept — those variables are
    /// now known to be implied by the clause — and rolled back on
    /// failure, which is what `top` records.
    fn lit_redundant(&mut self, p: Lit, abstract_levels: u32, stack: &mut Vec<Lit>) -> bool {
        if !self.native_charge(NativeOperation::Analyze, 8 + self.seen_stack.len() as u64) {
            return false;
        }
        let top = self.seen_stack.len();
        stack.clear();
        if !native_reserve(
            stack,
            stack.len() + 1,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::AnalyzeGrowth,
        ) {
            return false;
        }
        stack.push(p);
        while let Some(q) = stack.pop() {
            if !self.native_charge(NativeOperation::Analyze, 8) {
                return false;
            }
            let qv = var_of(q) as usize;
            // The reason is borrowed once per step, field by field, so the
            // walk below is a slice iteration; re-matching the source and
            // re-indexing two vectors for every literal was most of what
            // this loop did.
            let reason: &[Lit] = match self.reason[qv] {
                Reason::Decision => continue,
                Reason::Propagated(cref) => clause_in(&self.arena, cref),
                Reason::XorPropagated => &self.xor_reason[qv],
            };
            // The step's reason test, then each reason literal's
            // seen/level/reason tests, charged at the reason's full
            // length (a failing walk stops early, and is then charged
            // for literals it did not reach).
            self.stats.word_ops += 1 + reason.len() as u64;
            for &r in reason {
                if !native_pay(
                    &mut self.native_admission,
                    &mut self.native_failure,
                    self.deadline,
                    NativeOperation::Analyze,
                    16,
                    0,
                ) {
                    return false;
                }
                let rv = var_of(r) as usize;
                // The propagated literal itself, anything already in the
                // clause, and anything fixed at level 0 are all fine.
                if rv == qv || self.seen[rv] || self.level[rv] <= 0 {
                    continue;
                }
                let has_reason = !matches!(self.reason[rv], Reason::Decision);
                if has_reason && (abstract_level(self.level[rv]) & abstract_levels) != 0 {
                    let needed = self.seen_stack.len() + 1;
                    if !native_reserve(
                        &mut self.seen_stack,
                        needed,
                        &mut self.native_admission,
                        &mut self.native_failure,
                        self.deadline,
                        NativeOperation::AnalyzeGrowth,
                    ) || !native_reserve(
                        stack,
                        stack.len() + 1,
                        &mut self.native_admission,
                        &mut self.native_failure,
                        self.deadline,
                        NativeOperation::AnalyzeGrowth,
                    ) {
                        return false;
                    }
                    self.seen[rv] = true;
                    self.seen_stack.push(rv as u32);
                    stack.push(r);
                } else {
                    // The rollback of this walk's marks.
                    self.stats.word_ops += (self.seen_stack.len() - top) as u64;
                    for j in top..self.seen_stack.len() {
                        if !self.native_charge(NativeOperation::Analyze, 0) {
                            return false;
                        }
                        self.seen[self.seen_stack[j] as usize] = false;
                    }
                    self.seen_stack.truncate(top);
                    return false;
                }
            }
        }
        true
    }

    fn analyze(&mut self, conflict: Conflict) -> (Vec<Lit>, i32) {
        if !self.native_charge(NativeOperation::Analyze, 32) {
            return (Vec::new(), 0);
        }
        if !native_reserve(
            &mut self.learnt_buf,
            self.n_vars as usize,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::AnalyzeGrowth,
        ) {
            return (Vec::new(), 0);
        }
        if !native_reserve(
            &mut self.seen_stack,
            self.n_vars as usize,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::AnalyzeGrowth,
        ) {
            return (Vec::new(), 0);
        }
        if !native_reserve(
            &mut self.redundant_stack,
            self.n_vars as usize,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::AnalyzeGrowth,
        ) {
            return (Vec::new(), 0);
        }
        let current_level = self.trail_lim.len() as i32;
        let mut learnt = std::mem::take(&mut self.learnt_buf);
        learnt.clear();
        let mut counter = 0i32;
        let mut p: Lit = 0;
        let mut src = conflict;
        let mut trail_pos = self.trail.len();

        loop {
            if !self.native_charge(NativeOperation::Analyze, 16) {
                self.learnt_buf = learnt;
                return (Vec::new(), 0);
            }
            if self.observing() {
                if !self.native_conflict_payload(src, p) {
                    self.learnt_buf = learnt;
                    return (Vec::new(), 0);
                }
                let (reason, literals) = self.conflict_event(src, p);
                self.emit(SolverEvent::AnalysisReason {
                    resolved_literal: p,
                    reason,
                    literals,
                });
            }
            if self.native_observer_refused() {
                self.learnt_buf = learnt;
                return (Vec::new(), 0);
            }
            // Read the reason in place.  Copying it into a scratch
            // buffer was a memcpy of up to a hundred literals at every
            // resolution step, and conflict analysis is the hottest
            // phase of the solve.  It is borrowed once per step, from
            // the fields alone, so the bookkeeping below can still
            // write `seen`, the activities and the heap while the walk
            // is a plain slice iteration.
            let reason: &[Lit] = match src {
                Conflict::Clause(cref) => clause_in(&self.arena, cref),
                Conflict::Xor if p == 0 => &self.xor_conflict,
                Conflict::Xor => &self.xor_reason[var_of(p) as usize],
            };

            self.stats.analyze_lit_visits += reason.len() as u64;
            for &q in reason {
                if !native_pay(
                    &mut self.native_admission,
                    &mut self.native_failure,
                    self.deadline,
                    NativeOperation::Analyze,
                    16 + (u32::BITS - self.n_vars.leading_zeros()) as u64 * 8,
                    0,
                ) {
                    self.learnt_buf = learnt;
                    return (Vec::new(), 0);
                }
                // `p` is 0 on the first step, which no literal equals.
                if q == p {
                    continue;
                }
                let v = var_of(q) as usize;
                // Skip variables fixed at level 0.  Their literals are
                // permanently false in the learnt clause, so carrying
                // them adds nothing and costs a great deal: this
                // encoding propagates heavily at level 0, and including
                // those literals was leaving learnt clauses averaging
                // 188 literals on an `n = 19` instance.
                if !self.seen[v] && self.level[v] > 0 {
                    // The mark, the activity bump and its new key, and the
                    // clause or counter update; the heap charges itself.
                    self.stats.word_ops += 4;
                    let needed = self.seen_stack.len() + 1;
                    if !native_reserve(
                        &mut self.seen_stack,
                        needed,
                        &mut self.native_admission,
                        &mut self.native_failure,
                        self.deadline,
                        NativeOperation::AnalyzeGrowth,
                    ) {
                        self.learnt_buf = learnt;
                        return (Vec::new(), 0);
                    }
                    self.seen[v] = true;
                    self.seen_stack.push(v as u32);
                    // Bump activity, and reposition in the branching heap.
                    self.activity[v] += self.activity_inc;
                    if self.activity[v] > 1e100 {
                        if !native_pay(
                            &mut self.native_admission,
                            &mut self.native_failure,
                            self.deadline,
                            NativeOperation::Analyze,
                            2 * self.activity.len() as u64 + 1,
                            0,
                        ) {
                            self.learnt_buf = learnt;
                            return (Vec::new(), 0);
                        }
                        // Rescale: every activity and key rewritten.
                        self.stats.word_ops += 2 * self.activity.len() as u64;
                        for (a, (k, &prio)) in self
                            .activity
                            .iter_mut()
                            .zip(self.heap_key.iter_mut().zip(&self.branch_priority))
                        {
                            if !native_pay(
                                &mut self.native_admission,
                                &mut self.native_failure,
                                self.deadline,
                                NativeOperation::Analyze,
                                0,
                                0,
                            ) {
                                self.learnt_buf = learnt;
                                return (Vec::new(), 0);
                            }
                            *a *= 1e-100;
                            *k = order_key(*a, prio);
                        }
                        self.activity_inc *= 1e-100;
                    }
                    self.heap_key[v] = order_key(self.activity[v], self.branch_priority[v]);
                    self.order.bumped(v as u32, &self.heap_key);
                    if self.level[v] >= current_level {
                        counter += 1;
                    } else {
                        let needed = learnt.len() + 1;
                        if !native_reserve(
                            &mut learnt,
                            needed,
                            &mut self.native_admission,
                            &mut self.native_failure,
                            self.deadline,
                            NativeOperation::AnalyzeGrowth,
                        ) {
                            self.learnt_buf = learnt;
                            return (Vec::new(), 0);
                        }
                        learnt.push(q);
                    }
                }
            }

            // Find the next literal to resolve on — walk back the trail.
            while trail_pos > 0 {
                if !self.native_charge(NativeOperation::Analyze, 4) {
                    self.learnt_buf = learnt;
                    return (Vec::new(), 0);
                }
                trail_pos -= 1;
                let l = self.trail[trail_pos];
                if self.seen[var_of(l) as usize] {
                    p = l;
                    break;
                }
            }
            let v = var_of(p) as usize;
            self.seen[v] = false;
            // The resolution step's own bookkeeping: the reason fetch,
            // unmarking `p` and the counter.
            self.stats.word_ops += 2;
            counter -= 1;
            if counter <= 0 {
                break;
            }
            // The reason of p must be a propagation (not a decision).
            match self.reason[v] {
                Reason::Propagated(cref) => src = Conflict::Clause(cref),
                Reason::XorPropagated => src = Conflict::Xor,
                Reason::Decision => break,
            }
        }

        // **Local clause minimization** (MiniSat's `analyze` follow-up).
        // A literal whose own reason is built entirely from literals
        // already in the clause is implied by them and adds nothing.
        //
        // This matters far more here than in an ordinary CDCL: a parity
        // row's reason names *every* assigned variable of its combined
        // mask, and Gauss-Jordan makes those masks dense, so unminimized
        // learnt clauses run to hundreds of literals and then have to be
        // walked on every propagation.
        //
        // `seen` is still marked for exactly the clause's literals at
        // this point, which is what makes the test a lookup.
        self.stats.learnt_lits_raw += learnt.len() as u64;
        // The trail walked back to find each resolved literal: one seen
        // test per trail entry passed.
        self.stats.word_ops += (self.trail.len() - trail_pos) as u64;
        if learnt.len() > 1 {
            // Cheap filter: a literal can only be redundant if its
            // reason stays inside the levels the clause already covers.
            if !self.native_charge(NativeOperation::Analyze, learnt.len() as u64) {
                self.learnt_buf = learnt;
                return (Vec::new(), 0);
            }
            let mut abstract_levels = 0u32;
            for &q in &learnt {
                if !native_pay(
                    &mut self.native_admission,
                    &mut self.native_failure,
                    self.deadline,
                    NativeOperation::Analyze,
                    0,
                    0,
                ) {
                    self.learnt_buf = learnt;
                    return (Vec::new(), 0);
                }
                abstract_levels |= abstract_level(self.level[var_of(q) as usize]);
            }
            let t_min = std::time::Instant::now();
            learnt = match self.minimize_for_search(learnt, abstract_levels) {
                Some(kept) => kept,
                None => return (Vec::new(), 0),
            };
            self.stats.ns_minimize += t_min.elapsed().as_nanos() as u64;
        }
        self.stats.learnt_lits_kept += learnt.len() as u64;

        if !self.native_charge(
            NativeOperation::Analyze,
            self.seen_stack.len() as u64 + learnt.len() as u64 + 8,
        ) {
            self.learnt_buf = learnt;
            return (Vec::new(), 0);
        }
        // Clear only the marks we set.
        self.stats.word_ops += self.seen_stack.len() as u64;
        if self.native_admission.is_some() {
            for i in 0..self.seen_stack.len() {
                if !self.native_charge(NativeOperation::Analyze, 0) {
                    self.learnt_buf = learnt;
                    return (Vec::new(), 0);
                }
                self.seen[self.seen_stack[i] as usize] = false;
            }
            self.seen_stack.clear();
        } else {
            for v in self.seen_stack.drain(..) {
                self.seen[v as usize] = false;
            }
        }

        // Asserting literal: ¬p, then the clause exactly sized for the
        // database.  The accumulator goes back for the next conflict.
        let mut clause: Vec<Lit> = if self.native_admission.is_none() {
            Vec::with_capacity(learnt.len() + 1)
        } else {
            Vec::new()
        };
        if !native_reserve(
            &mut clause,
            learnt.len() + 1,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::AnalyzeGrowth,
        ) {
            self.learnt_buf = learnt;
            return (Vec::new(), 0);
        }
        clause.push(-p);
        if self.native_admission.is_some() {
            for chunk in learnt.chunks(64) {
                if !native_pay(
                    &mut self.native_admission,
                    &mut self.native_failure,
                    self.deadline,
                    NativeOperation::Analyze,
                    0,
                    0,
                ) {
                    self.native_pending_clause = Some(clause);
                    self.learnt_buf = learnt;
                    return (Vec::new(), 0);
                }
                clause.extend_from_slice(chunk);
            }
        } else {
            clause.extend_from_slice(&learnt);
        }
        learnt.clear();
        self.learnt_buf = learnt;

        // Backjump level: the second-highest level in the clause.
        let mut bj_level = 0;
        if clause.len() > 1 {
            let mut max_i = 1;
            for i in 2..clause.len() {
                if !self.native_charge(NativeOperation::Analyze, 0) {
                    self.native_pending_clause = Some(clause);
                    return (Vec::new(), 0);
                }
                if self.level[var_of(clause[i]) as usize]
                    > self.level[var_of(clause[max_i]) as usize]
                {
                    max_i = i;
                }
            }
            clause.swap(1, max_i);
            bj_level = self.level[var_of(clause[1]) as usize];
        }
        // Decay activity.
        self.activity_inc /= self.activity_decay;
        (clause, bj_level)
    }

    /// Undo all assignments above `level`.
    fn backjump(&mut self, level: i32) {
        let level = level.max(0) as usize;
        if self.trail_lim.len() <= level {
            return;
        }
        let target = self.trail_lim[level];
        let work = (self.trail.len() - target) as u64
            * (16 + 8 * (u32::BITS - self.n_vars.leading_zeros()) as u64);
        if !self.native_charge(NativeOperation::Backjump, work) {
            return;
        }
        if !native_reserve(
            &mut self.order.heap,
            self.n_vars as usize,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::AnalyzeGrowth,
        ) {
            return;
        }
        if self.observing() {
            if !self.native_event_payload(self.trail.len() - target, std::mem::size_of::<Lit>()) {
                return;
            }
            self.emit(SolverEvent::Backjump {
                from_level: self.trail_lim.len(),
                to_level: level,
                retained_trail: target,
                removed: self.trail[target..].to_vec(),
            });
        }
        if self.native_observer_refused() {
            return;
        }
        // Each unassignment: the two literal slots, the bitset word and
        // the level; the heap re-insertion charges itself.
        self.stats.word_ops += 3 * (self.trail.len() - target) as u64 + 1;
        while self.trail.len() > target {
            if !self.native_charge(NativeOperation::Backjump, 0) {
                return;
            }
            let l = self.trail.pop().unwrap();
            let v = var_of(l) as usize;
            let n = self.lit_base as i32;
            self.values[(n + l) as usize] = None;
            self.values[(n - l) as usize] = None;
            self.assigned_w[v / 64] &= !(1u64 << (v % 64));
            self.level[v] = -1;
            self.order.insert(v as u32, &self.heap_key);
        }
        self.trail_lim.truncate(level);
        self.qhead = target;
        self.epoch += 1;
    }

    /// Pick the unassigned variable with the highest activity.  Returns
    /// `None` if all variables are assigned.
    ///
    /// Variables are popped from the activity heap; an assigned one may
    /// surface because unassignment re-inserts rather than repositions,
    /// so we skip those.
    fn pick_branching_variable(&mut self) -> Option<u32> {
        let work =
            (self.n_vars as u64 + 1) * (u32::BITS - self.n_vars.leading_zeros() + 1) as u64 * 8;
        if !self.native_charge(NativeOperation::Heap, work) {
            return None;
        }
        loop {
            if !self.native_charge(NativeOperation::Heap, 0) {
                return None;
            }
            let Some(v) = self.order.pop_max(&self.heap_key) else {
                break;
            };
            // The popped variable's value test.
            self.stats.word_ops += 1;
            if self.var_value(v as usize).is_none() {
                return Some(v);
            }
        }
        None
    }

    /// **Drop the least useful half of the learnt clauses.**
    ///
    /// Learning never stops, so without this the watch lists grow for
    /// the whole solve and every propagation pays for clauses that
    /// stopped earning their keep.  Clauses are ranked by length, the
    /// cheap stand-in for LBD: a short clause prunes more.
    ///
    /// Detached clauses are unhooked from the watch lists; they are
    /// learnt, hence implied by the original problem, so dropping them
    /// can cost propagation power but never soundness.  A clause that
    /// is currently some variable's reason is kept, or conflict
    /// analysis would resolve against something no longer there.
    ///
    /// Called only at decision level 0, just after a restart, where the
    /// trail holds nothing but level-0 implications.
    fn reduce_db(&mut self) {
        if self.native_admission.is_some() {
            self.reduce_db_admitted()
        } else {
            self.reduce_db_legacy()
        }
    }

    /// **Drop the least useful half of the learnt clauses.**
    ///
    /// Learning never stops, so without this the watch lists grow for
    /// the whole solve and every propagation pays for clauses that
    /// stopped earning their keep.  Clauses are ranked by length, the
    /// cheap stand-in for LBD: a short clause prunes more.
    ///
    /// Detached clauses are unhooked from the watch lists; they are
    /// learnt, hence implied by the original problem, so dropping them
    /// can cost propagation power but never soundness.  A clause that
    /// is currently some variable's reason is kept, or conflict
    /// analysis would resolve against something no longer there.
    ///
    /// Called only at decision level 0, just after a restart, where the
    /// trail holds nothing but level-0 implications.
    fn reduce_db_legacy(&mut self) {
        let n_clauses = self.clause_at.len();
        self.detached.resize(n_clauses, false);
        // The lock table cleared, each trail literal's reason tested and
        // a propagated one's clause found by binary search over the index.
        let log_clauses = (64 - (n_clauses as u64).leading_zeros()) as u64;
        self.stats.word_ops += n_clauses as u64 + self.trail.len() as u64 * (1 + log_clauses);

        let mut locked = vec![false; n_clauses];
        for &l in &self.trail {
            if let Reason::Propagated(cref) = self.reason[var_of(l) as usize] {
                let idx = self
                    .clause_at
                    .binary_search(&cref)
                    .expect("a reason is a stored clause");
                locked[idx] = true;
            }
        }

        let clause_len = |i: usize| clause_in(&self.arena, self.clause_at[i]).len();
        let mut candidates: Vec<usize> = (self.n_orig_clauses..n_clauses)
            .filter(|&i| !self.detached[i] && !locked[i] && clause_len(i) > 2)
            .collect();
        // The learnt clauses filtered: detached, locked, length.
        self.stats.word_ops += 3 * (n_clauses - self.n_orig_clauses) as u64;
        if candidates.len() < 2 {
            return;
        }
        // The sort's `c⌈log₂ c⌉` comparisons of two lengths each, and
        // the front half marked.
        let c = candidates.len() as u64;
        self.stats.word_ops += 2 * c * (64 - c.leading_zeros()) as u64 + c / 2;
        // Longest first, so the front half is the one to drop.
        candidates.sort_by_key(|&i| std::cmp::Reverse(clause_len(i)));
        for &i in candidates.iter().take(candidates.len() / 2) {
            self.detached[i] = true;
            if self.observing() {
                self.emit(SolverEvent::DeleteClause {
                    clause_id: self.event_clause_id(self.clause_at[i]),
                });
            }
        }

        if self.reclaim_detached_clauses {
            self.reclaim_clause_arena();
        }
        self.rebuild_clause_watches();
    }

    /// **Drop the least useful half of the learnt clauses.**
    ///
    /// Learning never stops, so without this the watch lists grow for
    /// the whole solve and every propagation pays for clauses that
    /// stopped earning their keep.  Clauses are ranked by length, the
    /// cheap stand-in for LBD: a short clause prunes more.
    ///
    /// Detached clauses stay in the arena and are only unhooked from
    /// the watch lists, so every stored offset stays valid; they are
    /// learnt, hence implied by the original problem, so dropping them
    /// can cost propagation power but never soundness.  A clause that
    /// is currently some variable's reason is kept, or conflict
    /// analysis would resolve against something no longer there.
    ///
    /// Called only at decision level 0, just after a restart, where the
    /// trail holds nothing but level-0 implications.
    fn reduce_db_admitted(&mut self) {
        let n_clauses = self.clause_at.len();
        let work = (n_clauses as u64 + 1)
            * (32 + 8 * (usize::BITS - n_clauses.leading_zeros()) as u64)
            + self.trail.len() as u64 * 64
            + self.watches.len() as u64;
        if !self.native_charge(NativeOperation::Reduction, work) {
            return;
        }
        if !native_reserve(
            &mut self.detached,
            n_clauses,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::Reduction,
        ) {
            return;
        }
        if !self.native_fill_detached(n_clauses) {
            return;
        }
        // The lock table cleared, each trail literal's reason tested and
        // a propagated one's clause found by binary search over the index.
        let log_clauses = (64 - (n_clauses as u64).leading_zeros()) as u64;
        self.stats.word_ops += n_clauses as u64 + self.trail.len() as u64 * (1 + log_clauses);

        let mut locked = if self.native_admission.is_none() {
            vec![false; n_clauses]
        } else {
            Vec::new()
        };
        if !native_reserve(
            &mut locked,
            n_clauses,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::Reduction,
        ) {
            self.native_pending_reduction = Some((locked, Vec::new()));
            return;
        }
        while locked.len() < n_clauses {
            if !self.native_charge(NativeOperation::Reduction, 0) {
                self.native_pending_reduction = Some((locked, Vec::new()));
                return;
            }
            locked.resize(locked.len().saturating_add(64).min(n_clauses), false);
        }
        for &l in &self.trail {
            if !native_pay(
                &mut self.native_admission,
                &mut self.native_failure,
                self.deadline,
                NativeOperation::Reduction,
                0,
                0,
            ) {
                self.native_pending_reduction = Some((locked, Vec::new()));
                return;
            }
            if let Reason::Propagated(cref) = self.reason[var_of(l) as usize] {
                let idx = self
                    .clause_at
                    .binary_search(&cref)
                    .expect("a reason is a stored clause");
                locked[idx] = true;
            }
        }

        let clause_len = |i: usize| clause_in(&self.arena, self.clause_at[i]).len();
        let mut candidates = Vec::new();
        if !native_reserve(
            &mut candidates,
            n_clauses - self.n_orig_clauses,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::Reduction,
        ) {
            self.native_pending_reduction = Some((locked, candidates));
            return;
        }
        for i in self.n_orig_clauses..n_clauses {
            if !native_pay(
                &mut self.native_admission,
                &mut self.native_failure,
                self.deadline,
                NativeOperation::Reduction,
                0,
                0,
            ) {
                self.native_pending_reduction = Some((locked, candidates));
                return;
            }
            if !self.detached[i] && !locked[i] && clause_len(i) > 2 {
                candidates.push(i);
            }
        }
        // The learnt clauses filtered: detached, locked, length.
        self.stats.word_ops += 3 * (n_clauses - self.n_orig_clauses) as u64;
        if candidates.len() < 2 {
            return;
        }
        // The sort's `c⌈log₂ c⌉` comparisons of two lengths each, and
        // the front half marked.
        let c = candidates.len() as u64;
        self.stats.word_ops += 2 * c * (64 - c.leading_zeros()) as u64 + c / 2;
        // Longest first, so the front half is the one to drop.
        if !self.native_clause_sort(&mut candidates) {
            self.native_pending_reduction = Some((locked, candidates));
            return;
        }
        for &i in candidates.iter().take(candidates.len() / 2) {
            if !self.native_charge(NativeOperation::Reduction, 2) {
                self.native_pending_reduction = Some((locked, candidates));
                return;
            }
            self.detached[i] = true;
            if self.observing() {
                if !self.native_event_payload(0, 0) {
                    self.native_pending_reduction = Some((locked, candidates));
                    return;
                }
                self.emit(SolverEvent::DeleteClause {
                    clause_id: self.clause_at[i],
                });
            }
            if self.native_observer_refused() {
                self.native_pending_reduction = Some((locked, candidates));
                return;
            }
        }

        // Rebuild the watch lists from what survives.  Cheaper and much
        // less error-prone than unhooking clauses one at a time.  One per
        // list cleared, two per clause (offset, length and detached
        // test) and two watchers per survivor, charged as every clause.
        self.stats.word_ops += self.watches.len() as u64 + 4 * n_clauses as u64;
        for w in self.watches.iter_mut() {
            if !native_pay(
                &mut self.native_admission,
                &mut self.native_failure,
                self.deadline,
                NativeOperation::Reduction,
                0,
                0,
            ) {
                self.native_pending_reduction = Some((locked, candidates));
                return;
            }
            w.clear();
        }
        let n = self.lit_base as i32;
        for idx in 0..n_clauses {
            if !self.native_charge(NativeOperation::Reduction, 0) {
                self.native_pending_reduction = Some((locked, candidates));
                return;
            }
            let cref = self.clause_at[idx];
            let c = clause_in(&self.arena, cref);
            if c.len() < 2 || self.detached.get(idx).copied().unwrap_or(false) {
                continue;
            }
            let (l0, l1) = (c[0], c[1]);
            let (w0, w1) = ((l0 + n) as usize, (l1 + n) as usize);
            let need0 = self.watches[w0].len() + 2;
            let need1 = self.watches[w1].len() + 2;
            if !native_reserve(
                &mut self.watches[w0],
                need0,
                &mut self.native_admission,
                &mut self.native_failure,
                self.deadline,
                NativeOperation::WatchGrowth,
            ) || !native_reserve(
                &mut self.watches[w1],
                need1,
                &mut self.native_admission,
                &mut self.native_failure,
                self.deadline,
                NativeOperation::WatchGrowth,
            ) {
                self.native_pending_reduction = Some((locked, candidates));
                return;
            }
            self.watches[w0].push(Watcher { cref, blocker: l1 });
            self.watches[w1].push(Watcher { cref, blocker: l0 });
        }
    }

    /// Compact in place, preserving every clause ordinal and live clause's
    /// literal order. Three-word tautologies keep detached slots harmless
    /// if incremental clause addition later promotes the learnt prefix to
    /// originals (including DIMACS export); empty tombstones would be UNSAT.
    /// No live reason may be detached. Stale reasons of unassigned variables
    /// are cleared, and every surviving reason offset is relocated.
    ///
    /// Only compact when at least a quarter of used words can be recovered.
    /// Retain 50% headroom to avoid an immediate doubling on the next learnt
    /// clause. Copying in place avoids holding a second full-sized arena;
    /// the allocator's subsequent shrink may still move its allocation.
    fn reclaim_clause_arena(&mut self) {
        debug_assert!(self.trail_lim.is_empty());
        let reclaimable: usize = self
            .clause_at
            .iter()
            .enumerate()
            .filter(|(i, _)| self.detached.get(*i).copied().unwrap_or(false))
            .map(|(_, &cref)| clause_in(&self.arena, cref).len().saturating_sub(2))
            .sum();
        if reclaimable == 0 || reclaimable < self.arena.len() / 4 {
            return;
        }
        let old_offsets = self.clause_at.clone();
        let mut end = 0usize;
        for (i, &offset) in old_offsets.iter().enumerate() {
            let start = offset as usize;
            let words = self.arena[start] as usize + 1;
            self.clause_at[i] = u32::try_from(end).expect("compacted arena offset");
            if self.detached.get(i).copied().unwrap_or(false) && words > 3 {
                self.arena[end..end + 3].copy_from_slice(&[2, 1, -1]);
                end += 3;
            } else {
                self.arena.copy_within(start..start + words, end);
                end += words;
            }
        }
        for v in 0..self.reason.len() {
            if let Reason::Propagated(offset) = self.reason[v] {
                let i = old_offsets
                    .binary_search(&offset)
                    .expect("stored reason offset");
                self.reason[v] = if self.detached.get(i).copied().unwrap_or(false) {
                    assert!(self.var_value(v).is_none(), "detached live reason");
                    Reason::Decision
                } else {
                    Reason::Propagated(self.clause_at[i])
                };
            }
        }
        self.stats.arena_reclamations += 1;
        self.stats.arena_reclaimed_words += (self.arena.len() - end) as u64;
        self.arena.truncate(end);
        self.arena
            .shrink_to(end.saturating_add((end / 2).max(4096)));
    }

    fn rebuild_clause_watches(&mut self) {
        // Rebuild the watch lists from what survives.  Cheaper and much
        // less error-prone than unhooking clauses one at a time.  One per
        // list cleared, two per clause (offset, length and detached
        // test) and two watchers per survivor, charged as every clause.
        self.stats.word_ops += self.watches.len() as u64 + 4 * self.clause_at.len() as u64;
        for w in self.watches.iter_mut() {
            w.clear();
        }
        let n = self.lit_base as i32;
        for idx in 0..self.clause_at.len() {
            let cref = self.clause_at[idx];
            let c = clause_in(&self.arena, cref);
            if c.len() < 2 || self.detached.get(idx).copied().unwrap_or(false) {
                continue;
            }
            let (l0, l1) = (c[0], c[1]);
            self.watches[(l0 + n) as usize].push(Watcher { cref, blocker: l1 });
            self.watches[(l1 + n) as usize].push(Watcher { cref, blocker: l0 });
        }
    }

    /// Propagate at decision level zero and retain the trail, watches and XOR
    /// matrix for a later [`Self::solve`] call. This deliberately has no
    /// internal wall check: callers that need a hard limit must provide an
    /// outer process cap and preserve a checkpoint before entering it.
    pub fn propagate_root(&mut self) -> RootPropagationResult {
        if !self.native_entry(false) {
            return RootPropagationResult::Unknown;
        }
        assert!(
            self.trail_lim.is_empty(),
            "root propagation requires decision level zero"
        );
        if (self.event_failure.is_some() || self.native_failure.is_some()) {
            return RootPropagationResult::Unknown;
        }
        let conflict = if self.is_unsat {
            None
        } else {
            self.propagate()
        };
        if let Some(conflict) = conflict {
            if self.observing() {
                if !self.native_conflict_payload(conflict, 0) {
                    return RootPropagationResult::Unknown;
                }
                let (reason, literals) = self.conflict_event(conflict, 0);
                self.emit(SolverEvent::Conflict {
                    level: 0,
                    reason,
                    literals,
                });
            }
        }
        if (self.event_failure.is_some() || self.native_failure.is_some()) {
            return RootPropagationResult::Unknown;
        }
        if !self.native_charge(NativeOperation::Entry, 0) {
            return RootPropagationResult::Unknown;
        }
        if self.is_unsat || conflict.is_some() {
            self.is_unsat = true;
            RootPropagationResult::Unsat
        } else {
            RootPropagationResult::Fixpoint
        }
    }

    /// Main solve loop. Runs until SAT/UNSAT or conflict budget hits.
    pub fn solve(&mut self) -> SolveResult {
        let mut no_theory = |_: &[Option<bool>]| None;
        let result = self.solve_with_lazy_clauses(&[], &mut no_theory);
        self.progress_phase(SolverProgressPhase::Complete);
        result
    }

    /// Solve while allowing a theory callback to install globally valid lazy
    /// clauses whenever every `trigger_var` is assigned.
    ///
    /// The callback sees the current partial assignment and may return guarded
    /// consequence clauses. Non-unit clauses are attached at the current
    /// propagation fixpoint, where they can imply theory variables without
    /// losing the decisions that selected the current pattern. Empty or unit
    /// consequences use the conservative level-zero [`Self::add_clause`] path.
    /// Returning `None` means the current frontier has already been handled and
    /// ordinary CDCL should continue.
    ///
    /// The caller is responsible for clause soundness.  This is intended for
    /// small theory propagators whose consequences are expensive to encode
    /// eagerly, such as finite-field root relations.
    pub fn solve_with_lazy_clauses<F>(
        &mut self,
        trigger_vars: &[u32],
        theory: &mut F,
    ) -> SolveResult
    where
        F: FnMut(&[Option<bool>]) -> Option<Vec<Vec<Lit>>>,
    {
        let trace = (std::env::var("N83_SAT_PHASE_TRACE").as_deref() == Ok("1"))
            .then(std::time::Instant::now);
        self.trace_solve_phase(trace, "solve_enter", None);
        let result = (|| {
            if !self.native_entry(!trigger_vars.is_empty()) {
                return SolveResult::Unknown;
            }
            if self.event_failure.is_some() || self.native_failure.is_some() {
                return SolveResult::Unknown;
            }
            if self.observing() {
                if !self.native_event_payload(0, 0) {
                    return SolveResult::Unknown;
                }
                self.emit(SolverEvent::SolveBegin {
                    conflicts: self.conflicts,
                    conflict_budget: self.conflict_budget,
                });
            }
            if self.event_failure.is_some() || self.native_failure.is_some() {
                return SolveResult::Unknown;
            }
            let result = self.solve_with_lazy_clauses_inner(trigger_vars, theory, trace);
            if self.event_failure.is_some() || self.native_failure.is_some() {
                return SolveResult::Unknown;
            }
            if self.observing() {
                if !self.native_event_payload(16, 1) {
                    return SolveResult::Unknown;
                }
                self.emit(SolverEvent::SolveEnd {
                    result: format!("{result:?}"),
                });
            }
            if !self.native_charge(NativeOperation::Entry, 0) {
                return SolveResult::Unknown;
            }
            if self.event_failure.is_some() || self.native_failure.is_some() {
                SolveResult::Unknown
            } else {
                result
            }
        })();
        self.trace_solve_phase(trace, "solve_return", Some(result));
        result
    }

    /// Exact buffer ownership at this point, excluding allocator overhead and
    /// everything outside this solver. Capacity bytes are not resident bytes.
    /// The glibc/process observations are captured before allocating the JSON.
    fn storage_inventory(&self) -> serde_json::Value {
        #[cfg(all(target_os = "linux", target_env = "gnu"))]
        let allocator = {
            // SAFETY: mallinfo2 takes no pointers and returns process allocator
            // counters by value. This does not inspect or modify allocations.
            let info = unsafe { libc::mallinfo2() };
            serde_json::json!({"backend":"glibc_mallinfo2",
                "arena_bytes":info.arena,"in_use_arena_bytes":info.uordblks,
                "mmap_bytes":info.hblkhd,"free_arena_bytes":info.fordblks})
        };
        #[cfg(not(all(target_os = "linux", target_env = "gnu")))]
        let allocator = serde_json::Value::Null;
        let process_status: Option<Vec<String>> = std::fs::read_to_string("/proc/self/status")
            .ok()
            .map(|raw| {
                raw.lines()
                    .filter(|line| {
                        [
                            "VmSize:", "VmRSS:", "VmHWM:", "RssAnon:", "RssFile:", "VmSwap:",
                        ]
                        .iter()
                        .any(|prefix| line.starts_with(prefix))
                    })
                    .map(str::to_owned)
                    .collect()
            });
        let mut components = std::collections::BTreeMap::from([
            ("clause_arena", capacity_bytes(&self.arena)),
            ("clause_offsets", capacity_bytes(&self.clause_at)),
            ("detached_flags", capacity_bytes(&self.detached)),
            ("watch_headers", capacity_bytes(&self.watches)),
            (
                "watch_entries",
                self.watches.iter().map(capacity_bytes).sum(),
            ),
            ("xor_row_headers", capacity_bytes(&self.xors)),
            (
                "xor_row_masks",
                self.xors.iter().map(|row| capacity_bytes(&row.mask)).sum(),
            ),
            ("xor_matrix", capacity_bytes(&self.matrix)),
            ("xor_matrix_rhs", capacity_bytes(&self.matrix_rhs)),
            ("xor_support_headers", capacity_bytes(&self.matrix_support)),
            (
                "xor_support_words",
                self.matrix_support.iter().map(capacity_bytes).sum(),
            ),
            (
                "xor_support_scratch",
                capacity_bytes(&self.xor_support_src) + capacity_bytes(&self.xor_support_merge),
            ),
            ("xor_reason_headers", capacity_bytes(&self.xor_reason)),
            (
                "xor_reason_literals",
                self.xor_reason.iter().map(capacity_bytes).sum(),
            ),
            ("xor_conflict", capacity_bytes(&self.xor_conflict)),
            ("xor_pivots", capacity_bytes(&self.pivot)),
            ("xor_row_scratch", capacity_bytes(&self.xor_src)),
            ("literal_values", capacity_bytes(&self.values)),
            (
                "assignment_bitsets",
                capacity_bytes(&self.assigned_w) + capacity_bytes(&self.value_w),
            ),
            (
                "levels_and_reasons",
                capacity_bytes(&self.level) + capacity_bytes(&self.reason),
            ),
            (
                "phase_and_activity",
                capacity_bytes(&self.saved_phase) + capacity_bytes(&self.activity),
            ),
            (
                "trail",
                capacity_bytes(&self.trail) + capacity_bytes(&self.trail_lim),
            ),
            (
                "analysis_scratch",
                capacity_bytes(&self.seen)
                    + capacity_bytes(&self.seen_stack)
                    + capacity_bytes(&self.redundant_stack)
                    + capacity_bytes(&self.learnt_buf),
            ),
            (
                "branch_heap",
                capacity_bytes(&self.order.heap)
                    + capacity_bytes(&self.order.pos)
                    + capacity_bytes(&self.branch_priority)
                    + capacity_bytes(&self.heap_key),
            ),
        ]);
        // Admission refusals retain the actual in-flight allocations. They
        // remain solver-owned even while moved out of their ordinary slots.
        if self.native_admission.is_some()
            || self.native_pending_model.is_some()
            || self.native_pending_watch.is_some()
            || self.native_pending_clause.is_some()
            || self.native_pending_reduction.is_some()
            || self.native_sort_scratch.capacity() != 0
        {
            components.extend([
                (
                    "native_pending_model",
                    self.native_pending_model.as_ref().map_or(0, capacity_bytes),
                ),
                (
                    "native_pending_watch",
                    self.native_pending_watch
                        .as_ref()
                        .map_or(0, |(_, buffer, _, _)| capacity_bytes(buffer)),
                ),
                (
                    "native_sort_scratch",
                    capacity_bytes(&self.native_sort_scratch),
                ),
                (
                    "native_pending_clause",
                    self.native_pending_clause
                        .as_ref()
                        .map_or(0, capacity_bytes),
                ),
                (
                    "native_pending_reduction_locked",
                    self.native_pending_reduction
                        .as_ref()
                        .map_or(0, |(locked, _)| capacity_bytes(locked)),
                ),
                (
                    "native_pending_reduction_candidates",
                    self.native_pending_reduction
                        .as_ref()
                        .map_or(0, |(_, candidates)| capacity_bytes(candidates)),
                ),
            ]);
        }
        if self.event_clause_ids.capacity() != 0 {
            components.insert("event_clause_ids", capacity_bytes(&self.event_clause_ids));
        }
        let mut original_words = 0u64;
        let mut active_learnt_words = 0u64;
        let mut detached_learnt_words = 0u64;
        let mut detached_learnt_clauses = 0u64;
        for (index, &offset) in self.clause_at.iter().enumerate() {
            let words = 1 + clause_in(&self.arena, offset).len() as u64;
            if index < self.n_orig_clauses {
                original_words += words;
            } else if self.detached.get(index).copied().unwrap_or(false) {
                detached_learnt_words += words;
                detached_learnt_clauses += 1;
            } else {
                active_learnt_words += words;
            }
        }
        serde_json::json!({"schema":"n83.sat-storage/v1",
            "scope":"owned Vec buffer capacities, not RSS or allocator usable sizes; allocator/process counters include non-solver storage",
            "components_capacity_bytes":components,
            "owned_capacity_bytes":components.values().sum::<u64>(),
            "arena_used_words":self.arena.len(),"arena_capacity_words":self.arena.capacity(),
            "arena_reclamations":self.stats.arena_reclamations,
            "arena_reclaimed_words":self.stats.arena_reclaimed_words,
            "literal_word_bytes":std::mem::size_of::<Lit>(),
            "original_clause_words":original_words,"active_learnt_clause_words":active_learnt_words,
            "detached_learnt_clause_words":detached_learnt_words,
            "stored_clauses":self.clause_at.len(),"original_clauses":self.n_orig_clauses,
            "detached_learnt_clauses":detached_learnt_clauses,
            "allocator":allocator,"worker_pid_in_namespace":std::process::id(),
            "worker_process_status":process_status})
    }

    /// Opt-in diagnostic snapshots. Timers and counters are cumulative for this
    /// solver instance; elapsed time is relative to this particular solve call.
    /// Writing only at boundaries and every 1,000 conflicts avoids a per-step
    /// trace cost. Ownership snapshots add a read-only scan at solve boundaries
    /// and every 10,000 conflicts. A killed worker's last snapshot is not terminal.
    fn trace_solve_phase(
        &self,
        started: Option<std::time::Instant>,
        phase: &str,
        outcome: Option<SolveResult>,
    ) {
        if let Some(started) = started {
            use std::io::Write;
            let storage =
                storage_snapshot_due(phase, self.stats.conflicts).then(|| self.storage_inventory());
            let record = serde_json::json!({
                "schema":"n83.sat-phase/v1", "phase":phase,
                "elapsed_ms":started.elapsed().as_secs_f64()*1000.0,
                "outcome":outcome.map(|v| format!("{v:?}")),
                "counter_scope":"solver_instance_cumulative",
                "conflicts":self.stats.conflicts, "decisions":self.stats.decisions,
                "propagations":self.stats.propagations, "xor_passes":self.stats.xor_passes,
                "xor_propagations":self.stats.xor_propagations,
                "ns_propagate_clauses":self.stats.ns_propagate_clauses,
                "ns_propagate_xors":self.stats.ns_propagate_xors,
                "ns_analyze":self.stats.ns_analyze, "ns_minimize":self.stats.ns_minimize,
                "ns_reduce_db":self.stats.ns_reduce_db,
                "storage":storage,
            });
            let mut stderr = std::io::stderr().lock();
            let _ = writeln!(stderr, "{record}");
            let _ = stderr.flush();
        }
    }

    fn solve_with_lazy_clauses_inner<F>(
        &mut self,
        trigger_vars: &[u32],
        theory: &mut F,
        trace: Option<std::time::Instant>,
    ) -> SolveResult
    where
        F: FnMut(&[Option<bool>]) -> Option<Vec<Vec<Lit>>>,
    {
        if self.is_unsat {
            return SolveResult::Unsat;
        }
        // A previous call may have stopped mid-search (budget or
        // deadline), with a conflict found but not analysed.  Resuming
        // from that trail answered wrongly; restart from level zero
        // instead, keeping learnt clauses.
        self.backjump(0);
        // Initial propagation at level 0 catches trivial UNSAT from
        // unit clauses.
        self.trace_solve_phase(trace, "initial_propagation_begin", None);
        let initial_conflict = self.propagate();
        self.trace_solve_phase(trace, "initial_propagation_complete", None);
        if let Some(conflict) = initial_conflict {
            if self.observing() {
                if !self.native_conflict_payload(conflict, 0) {
                    return SolveResult::Unknown;
                }
                let (reason, literals) = self.conflict_event(conflict, 0);
                self.emit(SolverEvent::Conflict {
                    level: self.trail_lim.len(),
                    reason,
                    literals,
                });
            }
            return SolveResult::Unsat;
        }
        if (self.event_failure.is_some() || self.native_failure.is_some()) {
            return SolveResult::Unknown;
        }
        if self.max_learnts == 0 {
            self.max_learnts = (self.n_orig_clauses / 3).max(4000);
        }
        // The detached flags extended over the clauses, a word per 64.
        self.stats.word_ops += (self.clause_at.len() as u64).div_ceil(64);
        if !native_reserve(
            &mut self.detached,
            self.clause_at.len(),
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::DetachedGrowth,
        ) {
            return SolveResult::Unknown;
        }
        if !self.native_fill_detached(self.clause_at.len()) {
            return SolveResult::Unknown;
        }
        let mut luby_index = 1u64;
        let mut restart_limit = 100u64 * luby(luby_index);
        let mut pending_conflict = None;
        self.trace_solve_phase(trace, "cdcl_enter", None);
        loop {
            if !self.native_charge(NativeOperation::Loop, 64) {
                return SolveResult::Unknown;
            }
            if (self.event_failure.is_some() || self.native_failure.is_some()) {
                return SolveResult::Unknown;
            }
            if self
                .deadline
                .is_some_and(|deadline| std::time::Instant::now() >= deadline)
            {
                return SolveResult::Unknown;
            }
            if let Some(conflict_idx) = pending_conflict.take().or_else(|| self.propagate()) {
                if self.native_admission.is_some() {
                    self.native_failure = Some(NativeAdmissionFailure::UncoveredPath);
                    return SolveResult::Unknown;
                }
                if self.observing() {
                    if !self.native_conflict_payload(conflict_idx, 0) {
                        return SolveResult::Unknown;
                    }
                    let (reason, literals) = self.conflict_event(conflict_idx, 0);
                    self.emit(SolverEvent::Conflict {
                        level: self.trail_lim.len(),
                        reason,
                        literals,
                    });
                }
                if (self.event_failure.is_some() || self.native_failure.is_some()) {
                    return SolveResult::Unknown;
                }
                self.conflicts += 1;
                self.stats.conflicts += 1;
                if let Some(progress) = &self.progress {
                    progress
                        .conflicts
                        .store(self.stats.conflicts, Ordering::Relaxed);
                }
                if trace.is_some()
                    && (self.stats.conflicts == 1 || self.stats.conflicts % 1000 == 0)
                {
                    self.trace_solve_phase(trace, "conflict_snapshot", None);
                }
                let lvl = self.trail_lim.len() as u64;
                self.stats.conflict_level_sum += lvl;
                self.stats.max_level = self.stats.max_level.max(lvl);
                self.conflicts_since_restart += 1;
                // The conflict's counters and budget and level tests.
                self.stats.word_ops += 3;
                if self.conflicts >= self.conflict_budget
                    || self
                        .deadline
                        .is_some_and(|d| std::time::Instant::now() >= d)
                {
                    return SolveResult::Unknown;
                }
                if self.trail_lim.is_empty() {
                    return SolveResult::Unsat;
                }
                self.progress_phase(SolverProgressPhase::ConflictAnalysis);
                let t = std::time::Instant::now();
                let Some((learnt, bj_level)) = self.analyze_for_search(conflict_idx) else {
                    return SolveResult::Unknown;
                };
                self.stats.ns_analyze += t.elapsed().as_nanos() as u64;
                if self.observing() {
                    if !self.native_event_payload(learnt.len(), std::mem::size_of::<Lit>()) {
                        self.native_pending_clause = Some(learnt);
                        return SolveResult::Unknown;
                    }
                    self.emit(SolverEvent::Learned {
                        clause_id: self.event_clause_id(self.next_cref()),
                        literals: learnt.clone(),
                        backjump_level: bj_level,
                    });
                }
                if (self.event_failure.is_some() || self.native_failure.is_some()) {
                    self.native_pending_clause = Some(learnt);
                    return SolveResult::Unknown;
                }
                self.backjump(bj_level);
                if self.native_failure.is_some() || self.native_observer_refused() {
                    self.native_pending_clause = Some(learnt);
                    return SolveResult::Unknown;
                }
                self.progress_phase(SolverProgressPhase::Idle);
                // Install the learnt clause.
                if learnt.len() == 1 {
                    // It's a unit at the backjump level (which is 0).
                    let _ = self.enqueue(learnt[0], Reason::Propagated(self.next_cref()));
                    if self.native_failure.is_some() || self.native_observer_refused() {
                        self.native_pending_clause = Some(learnt);
                        return SolveResult::Unknown;
                    }
                    self.push_clause(&learnt);
                } else {
                    self.stats.learnt_clauses += 1;
                    let l0 = learnt[0];
                    let l1 = learnt[1];
                    // The two watchers; the arena push charges itself.
                    self.stats.word_ops += 2;
                    let (w0, w1) = (self.watch_slot(l0), self.watch_slot(l1));
                    let n0 = self.watches[w0].len() + 2;
                    let n1 = self.watches[w1].len() + 2;
                    if !native_reserve(
                        &mut self.watches[w0],
                        n0,
                        &mut self.native_admission,
                        &mut self.native_failure,
                        self.deadline,
                        NativeOperation::WatchGrowth,
                    ) || !native_reserve(
                        &mut self.watches[w1],
                        n1,
                        &mut self.native_admission,
                        &mut self.native_failure,
                        self.deadline,
                        NativeOperation::WatchGrowth,
                    ) {
                        self.native_pending_clause = Some(learnt);
                        return SolveResult::Unknown;
                    }
                    let idx = self.push_clause(&learnt);
                    if self.native_failure.is_some() || self.native_observer_refused() {
                        self.native_pending_clause = Some(learnt);
                        return SolveResult::Unknown;
                    }
                    self.watches[w0].push(Watcher {
                        cref: idx,
                        blocker: l1,
                    });
                    self.watches[w1].push(Watcher {
                        cref: idx,
                        blocker: l0,
                    });
                    // The first lit is the asserting one — it's
                    // implied at the new (lower) level.
                    let _ = self.enqueue(l0, Reason::Propagated(idx));
                }
                if self.native_failure.is_some() || self.native_observer_refused() {
                    self.native_pending_clause = Some(learnt);
                    return SolveResult::Unknown;
                }
                // Restart?
                if self.conflicts_since_restart >= restart_limit {
                    if !self.native_charge(NativeOperation::Restart, 128) {
                        return SolveResult::Unknown;
                    }
                    if self.observing() {
                        if !self.native_event_payload(0, 0) {
                            return SolveResult::Unknown;
                        }
                        self.emit(SolverEvent::Restart {
                            restart: self.stats.restarts + 1,
                            conflicts: self.conflicts,
                        });
                    }
                    if self.native_observer_refused() {
                        return SolveResult::Unknown;
                    }
                    self.progress_phase(SolverProgressPhase::Restart);
                    self.backjump(0);
                    if self.native_failure.is_some() || self.native_observer_refused() {
                        return SolveResult::Unknown;
                    }
                    self.stats.restarts += 1;
                    // The restart's own bookkeeping: the limit tests, and
                    // the Luby recurrence's at most `⌈log₂ i⌉` steps.
                    self.stats.word_ops += 2 + (64 - luby_index.leading_zeros()) as u64;
                    self.conflicts_since_restart = 0;
                    // Level 0: a good moment to shed accumulated
                    // fill-in in the parity matrix.
                    if !self.xors.is_empty() {
                        self.rebuild_matrix();
                        if self.native_failure.is_some() || self.native_observer_refused() {
                            return SolveResult::Unknown;
                        }
                        self.xor_epoch = u64::MAX;
                    }
                    let learnt_now = self.clause_at.len() - self.n_orig_clauses;
                    if learnt_now > self.max_learnts {
                        let t = std::time::Instant::now();
                        self.reduce_db();
                        if self.native_failure.is_some() || self.native_observer_refused() {
                            return SolveResult::Unknown;
                        }
                        self.stats.ns_reduce_db += t.elapsed().as_nanos() as u64;
                        // Let the budget grow, so reductions get rarer
                        // as the solve goes deeper.
                        self.max_learnts = self.max_learnts + self.max_learnts / 2;
                    }
                    luby_index += 1;
                    restart_limit = 100u64 * luby(luby_index);
                    if let Some(progress) = &self.progress {
                        progress
                            .restarts
                            .store(self.stats.restarts, Ordering::Relaxed);
                    }
                    self.progress_phase(SolverProgressPhase::Idle);
                }
            } else {
                if (self.event_failure.is_some() || self.native_failure.is_some()) {
                    return SolveResult::Unknown;
                }
                // Through the `n_vars`-long assignment, so a trigger past the
                // variables panics on the index as it did before the tables
                // had spare slots, instead of reading as never assigned.
                // The trigger test, one value read per trigger variable.
                self.stats.word_ops += trigger_vars.len() as u64;
                if !trigger_vars.is_empty() && {
                    let assignment = self.assignment();
                    trigger_vars
                        .iter()
                        .all(|&variable| assignment[(variable - 1) as usize].is_some())
                } {
                    if let Some(clauses) = theory(self.assignment()) {
                        assert!(!clauses.is_empty(), "lazy theory returned an empty update");
                        let mut normalized = Vec::with_capacity(clauses.len());
                        // Normalising each theory clause: the sort, the
                        // deduplication and tautology passes, and the
                        // all-false test.
                        self.stats.word_ops += clauses
                            .iter()
                            .map(|c| {
                                let k = c.len() as u64;
                                k * (64 - k.leading_zeros()) as u64 + 3 * k
                            })
                            .sum::<u64>();
                        for mut clause in clauses {
                            clause.sort_by_key(|&lit| (var_of(lit), lit));
                            clause.dedup();
                            if clause.windows(2).any(|pair| pair[0] == -pair[1]) {
                                continue;
                            }
                            self.assert_names_variables(&clause);
                            normalized.push(clause);
                        }
                        let has_current_conflict = normalized.iter().any(|clause| {
                            !clause.is_empty()
                                && clause.iter().all(|&lit| self.lit_value(lit) == Some(false))
                        });
                        if has_current_conflict || normalized.iter().any(|clause| clause.len() < 2)
                        {
                            self.backjump(0);
                            for clause in normalized {
                                if !self.add_clause(clause) {
                                    return SolveResult::Unsat;
                                }
                            }
                            if !self.native_fill_detached(self.clause_at.len()) {
                                return SolveResult::Unknown;
                            }
                        } else {
                            for clause in normalized {
                                let conflict = self.add_lazy_clause_at_current_level(clause);
                                if pending_conflict.is_none() {
                                    pending_conflict = conflict;
                                }
                            }
                        }
                        continue;
                    }
                }
                // No conflict — pick a new variable.
                self.progress_phase(SolverProgressPhase::BranchSelection);
                match self.pick_branching_variable() {
                    None => {
                        return if self.native_failure.is_some() || self.native_observer_refused() {
                            SolveResult::Unknown
                        } else {
                            SolveResult::Sat
                        }
                    }
                    Some(v) => {
                        let needed = self.trail_lim.len() + 1;
                        if !native_reserve(
                            &mut self.trail_lim,
                            needed,
                            &mut self.native_admission,
                            &mut self.native_failure,
                            self.deadline,
                            NativeOperation::LevelGrowth,
                        ) {
                            return SolveResult::Unknown;
                        }
                        self.stats.decisions += 1;
                        self.stats.word_ops += 2;
                        self.trail_lim.push(self.trail.len());
                        let lit = if self.saved_phase[v as usize] {
                            (v + 1) as i32
                        } else {
                            -((v + 1) as i32)
                        };
                        if self.observing() {
                            if !self.native_event_payload(0, 0) {
                                return SolveResult::Unknown;
                            }
                            self.emit(SolverEvent::Decision {
                                literal: lit,
                                level: self.trail_lim.len(),
                                trail_index: self.trail.len(),
                                activity_bits: self.activity[v as usize].to_bits(),
                                priority: self.branch_priority[v as usize],
                            });
                        }
                        if (self.event_failure.is_some() || self.native_failure.is_some()) {
                            return SolveResult::Unknown;
                        }
                        self.assign(lit, Reason::Decision);
                        if let Some(progress) = &self.progress {
                            progress
                                .decisions
                                .store(self.stats.decisions, Ordering::Relaxed);
                        }
                        self.progress_phase(SolverProgressPhase::Idle);
                    }
                }
            }
        }
    }

    /// Get the satisfying assignment after a successful `solve()`.
    pub fn model(&self) -> Vec<bool> {
        self.assignment()
            .iter()
            .map(|a| a.unwrap_or(false))
            .collect()
    }

    /// Number of variables.
    pub fn n_vars(&self) -> u32 {
        self.n_vars
    }

    /// Total number of (original + learnt) clauses.
    /// **Return the solver to decision level 0**, undoing the
    /// assignments a previous [`Self::solve`] left on the trail.
    ///
    /// [`Self::add_clause`] assumes it is called before search: a unit
    /// clause is enqueued at the current level, and the two watched
    /// literals are chosen without regard to what is already assigned.
    /// After a SAT answer the trail sits at a non-zero decision level,
    /// so adding a clause there can silently corrupt those invariants.
    /// Calling this first makes incremental use — add a blocking clause,
    /// solve again — safe, which is how a caller enumerates models
    /// without rebuilding the whole encoding each time.
    pub fn reset_search(&mut self) {
        self.backjump(0);
    }

    /// Scramble phase-saving polarity with a deterministic xorshift seed.
    ///
    /// Intended for multi-shot search: after a conflict-budget timeout,
    /// [`Self::reset_search`] then scramble phases so the next shot explores
    /// a different decision polarity trajectory while keeping learnt clauses.
    pub fn scramble_saved_phases(&mut self, seed: u64) {
        let mut state = seed | 1;
        for phase in &mut self.saved_phase {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            *phase = (state & 1) != 0;
        }
    }

    /// Force every saved phase to a constant polarity (search-polarity lever).
    pub fn set_all_saved_phases(&mut self, value: bool) {
        self.saved_phase.fill(value);
    }

    /// Set the initial decision polarity of selected 1-indexed variables.
    /// This changes search order only; it adds no constraint to the formula.
    pub fn set_saved_phase_for_vars(&mut self, vars: &[u32], value: bool) {
        for &var in vars {
            assert!(
                var >= 1 && var <= self.n_vars,
                "saved-phase variable out of range"
            );
            self.saved_phase[(var - 1) as usize] = value;
        }
    }

    /// Per-variable VSIDS activity, indexed by `var − 1`.  Read-only;
    /// for studies that learn a branching order from finished solves.
    pub fn activities(&self) -> &[f64] {
        &self.activity
    }

    /// Variables assigned at decision level zero.
    pub fn root_fixed_count(&self) -> usize {
        self.trail_lim.first().copied().unwrap_or(self.trail.len())
    }

    /// Cumulative conflicts across all calls to [`Self::solve`].
    ///
    /// A machine-independent measure of search effort: unlike wall
    /// clock it is comparable across runs and machines, which is what
    /// a benchmark wants when comparing encodings.
    pub fn conflicts(&self) -> u64 {
        self.conflicts
    }

    pub fn n_clauses(&self) -> usize {
        self.clause_at.len()
    }

    /// Attach once without replacing the existing event observer or deadline.
    /// This increment supports only the audited conflict-free CNF subset.
    pub fn set_search_admission(
        &mut self,
        mut hook: impl FnMut(NativeCharge) -> Result<(), NativeAdmissionFailure> + Send + Sync + 'static,
    ) -> Result<(), NativeAdmissionFailure> {
        if self.native_admission.is_some()
            || self.native_failure.is_some()
            || self.stats.decisions != 0
            || self.conflicts != 0
            || !self.trail_lim.is_empty()
        {
            return Err(NativeAdmissionFailure::UncoveredPath);
        }
        if self
            .deadline
            .is_some_and(|d| std::time::Instant::now() >= d)
        {
            self.native_failure = Some(NativeAdmissionFailure::Deadline);
            return Err(NativeAdmissionFailure::Deadline);
        }
        let charge = NativeCharge {
            operation: NativeOperation::Entry,
            work: 1,
            requested_replacement_bytes: std::mem::size_of_val(&hook) as u64,
        };
        if let Err(error) = hook(charge) {
            self.native_failure = Some(error);
            return Err(error);
        }
        if self
            .deadline
            .is_some_and(|d| std::time::Instant::now() >= d)
        {
            self.native_failure = Some(NativeAdmissionFailure::Deadline);
            return Err(NativeAdmissionFailure::Deadline);
        }
        self.native_admission = Some(Box::new(hook));
        Ok(())
    }

    pub fn search_admission_failure(&self) -> Option<NativeAdmissionFailure> {
        self.native_failure
    }

    fn native_charge(&mut self, op: NativeOperation, work: u64) -> bool {
        if self.native_observer_refused() {
            return false;
        }
        native_pay(
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            op,
            work,
            0,
        )
    }

    fn native_observer_refused(&self) -> bool {
        self.native_admission.is_some() && self.event_failure.is_some()
    }

    fn native_fill_detached(&mut self, length: usize) -> bool {
        if self.native_admission.is_none() {
            self.detached.resize(length, false);
            return true;
        }
        while self.detached.len() < length {
            let end = self.detached.len().saturating_add(64).min(length);
            if !self.native_charge(
                NativeOperation::DetachedGrowth,
                (end - self.detached.len()) as u64,
            ) {
                return false;
            }
            self.detached.resize(end, false);
        }
        self.detached.truncate(length);
        true
    }

    fn native_event_payload(&mut self, elements: usize, element_bytes: usize) -> bool {
        let Some(bytes) = elements
            .checked_mul(element_bytes)
            .and_then(|b| b.checked_add(128))
            .and_then(|b| u64::try_from(b).ok())
        else {
            self.native_failure = Some(NativeAdmissionFailure::Overflow);
            return false;
        };
        native_pay(
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::EventPayload,
            elements as u64 + 32,
            bytes,
        )
    }

    fn native_conflict_payload(&mut self, conflict: Conflict, resolved: Lit) -> bool {
        let n = match conflict {
            Conflict::Clause(id) => clause_in(&self.arena, id).len(),
            Conflict::Xor if resolved == 0 => self.xor_conflict.len(),
            Conflict::Xor => self.xor_reason[var_of(resolved) as usize].len(),
        };
        let copies = if matches!(conflict, Conflict::Xor) {
            2
        } else {
            1
        };
        match n.checked_mul(copies) {
            Some(n) => self.native_event_payload(n, std::mem::size_of::<Lit>()),
            None => {
                self.native_failure = Some(NativeAdmissionFailure::Overflow);
                false
            }
        }
    }

    fn native_assignment_payload(&mut self, reason: Reason, variable: usize) -> bool {
        let n = if matches!(reason, Reason::XorPropagated) {
            self.xor_reason[variable].len()
        } else {
            0
        };
        self.native_event_payload(n, std::mem::size_of::<Lit>())
    }

    fn native_lowest(&mut self, row: std::ops::Range<usize>) -> Result<Option<u32>, ()> {
        for (w, index) in row.enumerate() {
            if !self.native_charge(NativeOperation::XorWord, 4) {
                return Err(());
            }
            let free = self.matrix[index] & !self.assigned_w[w];
            if free != 0 {
                return Ok(Some((w * 64) as u32 + free.trailing_zeros()));
            }
        }
        Ok(None)
    }

    fn native_residual(&mut self, i: usize, words: usize) -> Result<bool, ()> {
        let mut parity = self.matrix_rhs[i];
        for w in 0..words {
            if !self.native_charge(NativeOperation::XorWord, 8) {
                return Err(());
            }
            let m = self.matrix[i * words + w];
            parity ^= ((m & self.assigned_w[w] & self.value_w[w]).count_ones() & 1) == 1;
        }
        Ok(parity)
    }

    fn native_reason(
        &mut self,
        row: std::ops::Range<usize>,
        implied: Option<Lit>,
        clause: &mut Vec<Lit>,
    ) -> bool {
        clause.clear();
        if let Some(l) = implied {
            clause.push(l);
        }
        for (w, index) in row.enumerate() {
            if !self.native_charge(NativeOperation::XorReason, 8) {
                return false;
            }
            let mut bits = self.matrix[index] & self.assigned_w[w];
            let value = self.value_w[w];
            while bits != 0 {
                if !self.native_charge(NativeOperation::XorReason, 4) {
                    return false;
                }
                let b = bits.trailing_zeros();
                bits &= bits - 1;
                let v = ((w * 64) as u32 + b + 1) as Lit;
                clause.push(if (value >> b) & 1 == 1 { -v } else { v });
            }
        }
        true
    }

    /// Stable descending clause-length order with admitted comparisons/copies.
    /// Partial scratch remains owned on every refusal.
    fn native_clause_sort(&mut self, candidates: &mut Vec<usize>) -> bool {
        if self.native_admission.is_none() {
            candidates.sort_by_key(|&i| {
                std::cmp::Reverse(clause_in(&self.arena, self.clause_at[i]).len())
            });
            return true;
        }
        let n = candidates.len();
        if !native_reserve(
            &mut self.native_sort_scratch,
            n,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::Reduction,
        ) {
            return false;
        }
        self.native_sort_scratch.clear();
        for _ in 0..n {
            if !self.native_charge(NativeOperation::Reduction, 1) {
                return false;
            }
            self.native_sort_scratch.push(0);
        }
        let mut width = 1usize;
        while width < n {
            let mut start = 0usize;
            while start < n {
                let middle = start.saturating_add(width).min(n);
                let end = middle.saturating_add(width).min(n);
                let (mut left, mut right) = (start, middle);
                for dest in start..end {
                    if !self.native_charge(NativeOperation::Reduction, 8) {
                        return false;
                    }
                    let take_left = right == end
                        || (left < middle
                            && clause_in(&self.arena, self.clause_at[candidates[left]]).len()
                                >= clause_in(&self.arena, self.clause_at[candidates[right]]).len());
                    self.native_sort_scratch[dest] = if take_left {
                        let v = candidates[left];
                        left += 1;
                        v
                    } else {
                        let v = candidates[right];
                        right += 1;
                        v
                    };
                }
                start = end;
            }
            std::mem::swap(candidates, &mut self.native_sort_scratch);
            width = width.saturating_mul(2);
        }
        true
    }

    fn native_entry(&mut self, theory: bool) -> bool {
        if !self.native_charge(NativeOperation::Entry, 32) {
            return false;
        }
        if self.native_admission.is_some()
            && (self.event_observer.is_some()
                || !self.xors.is_empty()
                || theory
                || !self.trail_lim.is_empty())
        {
            self.native_failure = Some(NativeAdmissionFailure::UncoveredPath);
            return false;
        }
        true
    }

    /// Prepaid copy of the actual native assignment; no second solver/model.
    pub fn admitted_model(&mut self) -> Option<Vec<bool>> {
        if !self.native_charge(NativeOperation::Model, self.n_vars as u64) {
            return None;
        }
        let mut model = Vec::new();
        if !native_reserve(
            &mut model,
            self.n_vars as usize,
            &mut self.native_admission,
            &mut self.native_failure,
            self.deadline,
            NativeOperation::Model,
        ) {
            return None;
        }
        for start in (0..self.n_vars as usize).step_by(64) {
            let end = start.saturating_add(64).min(self.n_vars as usize);
            if !self.native_charge(NativeOperation::Model, (end - start) as u64) {
                self.native_pending_model = Some(model);
                return None;
            }
            model.extend(
                self.assignment()[start..end]
                    .iter()
                    .map(|a| a.unwrap_or(false)),
            );
        }
        if !self.native_charge(NativeOperation::Model, 0) {
            self.native_pending_model = Some(model);
            return None;
        }
        Some(model)
    }

    /// Own both actual minimization buffers through every admission boundary.
    fn minimize_for_search(
        &mut self,
        mut learnt: Vec<Lit>,
        abstract_levels: u32,
    ) -> Option<Vec<Lit>> {
        let mut stack = std::mem::take(&mut self.redundant_stack);
        let mut w = 0usize;
        for r in 0..learnt.len() {
            // Decision reasons skip lit_redundant, but still perform real work.
            if !self.native_charge(NativeOperation::Analyze, 4) {
                self.redundant_stack = stack;
                self.learnt_buf = learnt;
                return None;
            }
            let q = learnt[r];
            let v = var_of(q) as usize;
            let redundant = !matches!(self.reason[v], Reason::Decision)
                && self.lit_redundant(q, abstract_levels, &mut stack);
            if self.native_failure.is_some() || self.native_observer_refused() {
                self.redundant_stack = stack;
                self.learnt_buf = learnt;
                return None;
            }
            if !redundant {
                learnt[w] = q;
                w += 1;
            }
        }
        learnt.truncate(w);
        self.redundant_stack = stack;
        Some(learnt)
    }

    /// 1-UIP conflict analysis. Returns `(learnt_clause, backjump_level)`.
    ///
    /// The `seen` marks are cleared through `seen_stack` rather than by
    /// re-zeroing a per-variable vector, and reason clauses are copied
    /// into a reused buffer rather than cloned — both were per-conflict
    /// allocations on a path taken millions of times.
    /// Search boundary preserves analysis-owned partial output on refusal.
    fn analyze_for_search(&mut self, conflict: Conflict) -> Option<(Vec<Lit>, i32)> {
        let result = self.analyze(conflict);
        if self.native_failure.is_some() || self.native_observer_refused() {
            if self.native_pending_clause.is_none() && !result.0.is_empty() {
                self.native_pending_clause = Some(result.0);
            }
            return None;
        }
        Some(result)
    }
}

/// Luby sequence `1, 1, 2, 1, 1, 2, 4, 1, 1, 2, 1, 1, 2, 4, 8, …`
/// (Luby-Sinclair-Zuckerman 1993). Used for restart timing.
/// Iterative — the natural recursion grows logarithmically but on
/// pathological inputs we don't want to risk the stack.
fn luby(i: u64) -> u64 {
    // i is 1-indexed in this codebase; the sequence starts at i = 1.
    // Luby recurrence (Luby-Sinclair-Zuckerman 1993):
    //   t_i = 2^{k-1}            if i = 2^k - 1
    //        t_{i - 2^{k-1} + 1}  otherwise (with k = ⌊log₂ i⌋ + 1)
    let mut n = i;
    loop {
        if n == 0 {
            return 1; // guard; shouldn't happen with i >= 1
        }
        // Find the smallest k with 2^k > n  (i.e. 2^k >= n + 1).
        let mut k: u64 = 0;
        while (1u64 << k) < n + 1 {
            k += 1;
        }
        // Now (1 << k) >= n + 1.  Two cases:
        if n + 1 == 1u64 << k {
            // n == 2^k - 1: base case, return 2^{k-1} (= 1 when k = 0).
            return if k == 0 { 1 } else { 1u64 << (k - 1) };
        }
        // Otherwise, recurse on n - (2^{k-1} - 1).
        n -= (1u64 << (k - 1)) - 1;
    }
}

/// Parse a DIMACS CNF string.
///
/// Format:
/// ```text
/// c comment
/// p cnf <n_vars> <n_clauses>
/// 1 -2 3 0
/// -1 2 0
/// ```
pub fn parse_dimacs(input: &str) -> Result<Solver, String> {
    let mut n_vars: Option<u32> = None;
    let mut current: Vec<Lit> = Vec::new();
    let mut clauses: Vec<Vec<Lit>> = Vec::new();
    for (lineno, line) in input.lines().enumerate() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('c') {
            continue;
        }
        if line.starts_with("p ") {
            let parts: Vec<&str> = line.split_whitespace().collect();
            if parts.len() < 4 || parts[1] != "cnf" {
                return Err(format!("line {}: bad header `{line}`", lineno + 1));
            }
            n_vars = Some(
                parts[2]
                    .parse()
                    .map_err(|e| format!("line {}: {e}", lineno + 1))?,
            );
            continue;
        }
        // Literal stream; 0 terminates a clause.
        for tok in line.split_whitespace() {
            let l: Lit = tok
                .parse()
                .map_err(|e| format!("line {}: {e}", lineno + 1))?;
            if l == 0 {
                clauses.push(std::mem::take(&mut current));
            } else {
                current.push(l);
            }
        }
    }
    if !current.is_empty() {
        clauses.push(current);
    }
    let n = n_vars.ok_or("missing `p cnf` header")?;
    let mut solver = Solver::new(n);
    for c in clauses {
        if !solver.add_clause(c) {
            // Empty clause → UNSAT but still a valid instance.
            break;
        }
    }
    Ok(solver)
}

/// Parse an **extended DIMACS** string in which lines beginning with
/// `x` are XOR (parity) constraints, as emitted by CryptoMiniSat and by
/// the `EC-Index-Calculus-Benchmarks` generator.
///
/// The convention is that `x 1 2 3 0` means `x₁ ⊕ x₂ ⊕ x₃ = 1`, and
/// each negated literal flips the right-hand side, so
/// `x -1 2 3 0` means `x₁ ⊕ x₂ ⊕ x₃ = 0`.  Ordinary clause lines are
/// parsed exactly as in [`parse_dimacs`].
///
/// XOR rows go to [`Solver::add_xor`] rather than being Tseitin-
/// expanded, so the returned solver reasons about them by Gaussian
/// elimination.
pub fn parse_dimacs_xor(input: &str) -> Result<Solver, String> {
    let mut n_vars: Option<u32> = None;
    let mut clauses: Vec<Vec<Lit>> = Vec::new();
    let mut xors: Vec<(Vec<u32>, bool)> = Vec::new();

    for (lineno, line) in input.lines().enumerate() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('c') {
            continue;
        }
        if line.starts_with("p ") {
            let parts: Vec<&str> = line.split_whitespace().collect();
            if parts.len() < 3 || parts[1] != "cnf" {
                return Err(format!("line {}: bad header `{line}`", lineno + 1));
            }
            n_vars = Some(
                parts[2]
                    .parse()
                    .map_err(|e| format!("line {}: {e}", lineno + 1))?,
            );
            continue;
        }
        let is_xor = line.starts_with('x');
        let payload = if is_xor { &line[1..] } else { line };
        let mut lits: Vec<Lit> = Vec::new();
        for tok in payload.split_whitespace() {
            let l: Lit = tok
                .parse()
                .map_err(|_| format!("line {}: bad literal `{tok}`", lineno + 1))?;
            if l == 0 {
                break;
            }
            lits.push(l);
        }
        if lits.is_empty() {
            if !is_xor && payload.split_whitespace().any(|token| token == "0") {
                clauses.push(Vec::new());
            }
            continue;
        }
        if is_xor {
            // rhs starts true and flips once per negated literal.
            let negations = lits.iter().filter(|l| **l < 0).count();
            let rhs = negations % 2 == 0;
            xors.push((lits.iter().map(|l| l.unsigned_abs()).collect(), rhs));
        } else {
            clauses.push(lits);
        }
    }

    let n = n_vars.ok_or("missing `p cnf` header")?;
    let mut solver = Solver::new(n);
    for c in clauses {
        if !solver.add_clause(c) {
            break;
        }
    }
    for (vars, rhs) in xors {
        if !solver.add_xor(&vars, rhs) {
            break;
        }
    }
    Ok(solver)
}

/// Emit a DIMACS string for a solver's *original* clauses.
pub fn to_dimacs(solver: &Solver) -> String {
    let mut s = format!("p cnf {} {}\n", solver.n_vars, solver.n_orig_clauses);
    for &cref in solver.clause_at.iter().take(solver.n_orig_clauses) {
        for &l in clause_in(&solver.arena, cref) {
            s.push_str(&l.to_string());
            s.push(' ');
        }
        s.push_str("0\n");
    }
    s
}

impl Solver {
    /// The native parity rows as 1-indexed variable lists with their
    /// right-hand sides, in the order they were added.
    pub fn xor_rows(&self) -> Vec<(Vec<u32>, bool)> {
        self.xors
            .iter()
            .map(|row| {
                let vars = (0..self.n_vars)
                    .filter(|&v| (row.mask[(v / 64) as usize] >> (v % 64)) & 1 == 1)
                    .map(|v| v + 1)
                    .collect();
                (vars, row.rhs)
            })
            .collect()
    }

    /// Number of original (non-learnt) clauses.
    pub fn n_original_clauses(&self) -> usize {
        self.n_orig_clauses
    }
}

/// Emit the solver's original CNF clauses and native parity rows as
/// CryptoMiniSat-style extended DIMACS.
///
/// An XOR row with right-hand side one is emitted as `x 1 2 ... 0`.
/// For right-hand side zero the first literal is negated, matching
/// [`parse_dimacs_xor`].  A solver that is already inconsistent also emits an
/// explicit empty clause so root UNSAT survives export.
pub fn to_dimacs_xor(solver: &Solver) -> String {
    let constraints = solver.n_orig_clauses + solver.xors.len() + usize::from(solver.is_unsat);
    let mut output = format!("p cnf {} {}\n", solver.n_vars, constraints);
    for &cref in solver.clause_at.iter().take(solver.n_orig_clauses) {
        for &literal in clause_in(&solver.arena, cref) {
            output.push_str(&literal.to_string());
            output.push(' ');
        }
        output.push_str("0\n");
    }
    for row in &solver.xors {
        output.push('x');
        let mut first = true;
        for variable in 0..solver.n_vars {
            if !bs_get(&row.mask, variable) {
                continue;
            }
            let literal = if first && !row.rhs {
                -((variable + 1) as Lit)
            } else {
                (variable + 1) as Lit
            };
            output.push(' ');
            output.push_str(&literal.to_string());
            first = false;
        }
        output.push_str(" 0\n");
    }
    if solver.is_unsat {
        output.push_str("0\n");
    }
    output
}

/// Convenience: verify that a model satisfies all clauses.
pub fn check_model(clauses: &[Vec<Lit>], model: &[bool]) -> bool {
    for c in clauses {
        let mut sat = false;
        for &l in c {
            let v = var_of(l) as usize;
            let val = if is_neg(l) { !model[v] } else { model[v] };
            if val {
                sat = true;
                break;
            }
        }
        if !sat {
            return false;
        }
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;

    fn observer_pigeonhole(pigeons: u32, holes: u32) -> Solver {
        let mut s = Solver::new(pigeons * holes);
        for pigeon in 0..pigeons {
            s.add_clause(
                (0..holes)
                    .map(|hole| (pigeon * holes + hole + 1) as Lit)
                    .collect(),
            );
        }
        for hole in 0..holes {
            for a in 0..pigeons {
                for b in a + 1..pigeons {
                    s.add_clause(vec![
                        -((a * holes + hole + 1) as Lit),
                        -((b * holes + hole + 1) as Lit),
                    ]);
                }
            }
        }
        s.max_learnts = 8;
        s.conflict_budget = 400;
        s
    }

    /// Replay semantic changes with an independent representation. This checks
    /// propagation reasons and parity operations, not learned-clause proofs.
    fn replay_observer(events: &[SolverEvent]) -> Result<Vec<Option<bool>>, String> {
        use std::collections::BTreeMap;
        let mut assignment = Vec::new();
        let mut trail = Vec::<Lit>::new();
        let mut clauses = BTreeMap::<u32, Vec<Lit>>::new();
        let mut xors = BTreeMap::<usize, (Vec<u64>, bool)>::new();
        let mut matrix = BTreeMap::<usize, (Vec<u64>, bool)>::new();
        let lit_value = |a: &[Option<bool>], lit: Lit| {
            a.get(var_of(lit) as usize)
                .copied()
                .flatten()
                .map(|v| v != (lit < 0))
        };
        for event in events {
            match event {
                SolverEvent::Snapshot { variables, .. } => {
                    assignment = vec![None; *variables as usize]
                }
                SolverEvent::Clause {
                    clause_id,
                    literals,
                    ..
                }
                | SolverEvent::Learned {
                    clause_id,
                    literals,
                    ..
                } => {
                    if let Some(old) = clauses.insert(*clause_id, literals.clone()) {
                        let mut old = old;
                        let mut new = literals.clone();
                        old.sort();
                        new.sort();
                        if old != new {
                            return Err("clause ID changed literals".into());
                        }
                    }
                }
                SolverEvent::XorConstraint { row_id, mask, rhs } => {
                    xors.insert(*row_id, (mask.clone(), *rhs));
                }
                SolverEvent::XorMatrixReset => matrix = xors.clone(),
                SolverEvent::XorMatrixRow { row_id, mask, rhs } => {
                    matrix.insert(*row_id, (mask.clone(), *rhs));
                }
                SolverEvent::XorRowXor {
                    destination,
                    source,
                } => {
                    let (source_mask, source_rhs) = matrix
                        .get(source)
                        .ok_or("missing source parity row")?
                        .clone();
                    let (mask, rhs) = matrix
                        .get_mut(destination)
                        .ok_or("missing destination parity row")?;
                    if mask.len() != source_mask.len() {
                        return Err("parity width differs".into());
                    }
                    for (a, b) in mask.iter_mut().zip(source_mask) {
                        *a ^= b;
                    }
                    *rhs ^= source_rhs;
                }
                SolverEvent::XorImplication {
                    row_id,
                    literal,
                    explanation,
                } => {
                    let (mask, rhs) = matrix.get(row_id).ok_or("missing implication row")?;
                    let mut free = Vec::new();
                    let mut parity = *rhs;
                    for (v, a) in assignment.iter().enumerate() {
                        if mask[v / 64] >> (v % 64) & 1 == 0 {
                            continue;
                        }
                        match a {
                            Some(value) => parity ^= *value,
                            None => free.push(v),
                        }
                    }
                    if free != vec![var_of(*literal) as usize]
                        || parity != (*literal > 0)
                        || !explanation.contains(literal)
                    {
                        return Err("invalid parity implication".into());
                    }
                }
                SolverEvent::XorConflict {
                    row_id,
                    explanation,
                } => {
                    let (mask, rhs) = matrix.get(row_id).ok_or("missing conflict parity row")?;
                    let mut parity = *rhs;
                    for (v, a) in assignment.iter().enumerate() {
                        if mask[v / 64] >> (v % 64) & 1 != 0 {
                            parity ^= a.ok_or("free variable in parity conflict")?;
                        }
                    }
                    if !parity
                        || explanation
                            .iter()
                            .any(|l| lit_value(&assignment, *l) != Some(false))
                    {
                        return Err("invalid parity conflict".into());
                    }
                }
                SolverEvent::Assignment {
                    literal,
                    trail_index,
                    reason,
                    ..
                } => {
                    if *trail_index != trail.len() || lit_value(&assignment, *literal).is_some() {
                        return Err("invalid assignment trail".into());
                    }
                    let explanation = match reason {
                        SolverEventReason::Decision => None,
                        SolverEventReason::Clause { clause_id } => {
                            Some(clauses.get(clause_id).ok_or("unknown reason clause")?)
                        }
                        SolverEventReason::Xor { explanation } => Some(explanation),
                    };
                    if let Some(explanation) = explanation {
                        if !explanation.contains(literal)
                            || explanation
                                .iter()
                                .filter(|l| **l != *literal)
                                .any(|l| lit_value(&assignment, *l) != Some(false))
                        {
                            return Err("reason was not unit on prior trail".into());
                        }
                    }
                    assignment[var_of(*literal) as usize] = Some(*literal > 0);
                    trail.push(*literal);
                }
                SolverEvent::Decision {
                    literal,
                    trail_index,
                    ..
                } => {
                    if *trail_index != trail.len() || lit_value(&assignment, *literal).is_some() {
                        return Err("invalid decision".into());
                    }
                }
                SolverEvent::Backjump {
                    retained_trail,
                    removed,
                    ..
                } => {
                    if *retained_trail > trail.len()
                        || &trail[*retained_trail..] != removed.as_slice()
                    {
                        return Err("invalid backjump suffix".into());
                    }
                    for lit in trail.drain(*retained_trail..) {
                        assignment[var_of(lit) as usize] = None;
                    }
                }
                SolverEvent::Conflict { literals, .. } => {
                    if literals
                        .iter()
                        .any(|l| lit_value(&assignment, *l) != Some(false))
                    {
                        return Err("conflict is not falsified".into());
                    }
                }
                SolverEvent::FormulaContradiction { constraint, .. } => match constraint {
                    SolverEventConstraint::Clause { literals } => {
                        if literals
                            .iter()
                            .any(|l| lit_value(&assignment, *l) != Some(false))
                        {
                            return Err("added clause is not falsified".into());
                        }
                    }
                    SolverEventConstraint::Xor { variables, rhs } => {
                        let mut odd = std::collections::BTreeSet::new();
                        for variable in variables {
                            if *variable == 0 || *variable as usize > assignment.len() {
                                return Err("invalid added XOR variable".into());
                            }
                            if !odd.insert(*variable) {
                                odd.remove(variable);
                            }
                        }
                        if !odd.is_empty() || !rhs {
                            return Err("added XOR is not an immediate contradiction".into());
                        }
                    }
                },
                SolverEvent::DeleteClause { clause_id } if !clauses.contains_key(clause_id) => {
                    return Err("deleted unknown clause".into());
                }
                _ => {}
            }
        }
        Ok(assignment)
    }

    #[test]
    fn observer_preserves_answers_all_work_counters_and_reconstructs_cnf_search() {
        use std::sync::Mutex;
        let mut saw_restart = false;
        let mut saw_deletion = false;
        for (pigeons, holes) in [(5, 4), (7, 6)] {
            let mut plain = observer_pigeonhole(pigeons, holes);
            let mut observed = observer_pigeonhole(pigeons, holes);
            let events = Arc::new(Mutex::new(Vec::new()));
            let output = Arc::clone(&events);
            observed
                .set_event_observer(move |event| {
                    output.lock().unwrap().push(event.clone());
                    Ok(())
                })
                .unwrap();
            let expected = plain.solve();
            let actual = observed.solve();
            assert_eq!(actual, expected);
            let deterministic = |mut st: SolverStats| {
                st.ns_propagate_clauses = 0;
                st.ns_propagate_xors = 0;
                st.ns_analyze = 0;
                st.ns_minimize = 0;
                st.ns_reduce_db = 0;
                format!("{st:?}")
            };
            assert_eq!(deterministic(plain.stats), deterministic(observed.stats));
            assert_eq!(plain.word_ops(), observed.word_ops());
            assert_eq!(plain.assignment(), observed.assignment());
            let events = events.lock().unwrap();
            assert_eq!(replay_observer(&events).unwrap(), observed.assignment());
            assert!(events
                .iter()
                .any(|e| matches!(e, SolverEvent::Learned { .. })));
            assert!(events
                .iter()
                .any(|e| matches!(e, SolverEvent::Backjump { .. })));
            saw_restart |= events
                .iter()
                .any(|e| matches!(e, SolverEvent::Restart { .. }));
            saw_deletion |= events
                .iter()
                .any(|e| matches!(e, SolverEvent::DeleteClause { .. }));
            let mut corrupted = events.clone();
            let assignment = corrupted
                .iter_mut()
                .find(|e| {
                    matches!(
                        e,
                        SolverEvent::Assignment {
                            reason: SolverEventReason::Clause { .. },
                            ..
                        }
                    )
                })
                .unwrap();
            if let SolverEvent::Assignment { reason, .. } = assignment {
                *reason = SolverEventReason::Clause {
                    clause_id: u32::MAX,
                };
            }
            assert!(replay_observer(&corrupted).is_err());
        }
        assert!(saw_restart, "fixture must exercise actual restart events");
        assert!(saw_deletion, "fixture must exercise actual deletion events");
    }

    #[test]
    fn observer_reconstructs_xor_operations_and_copies_reasons() {
        use std::sync::Mutex;
        let mut solver = Solver::new(5);
        solver.add_xor(&[1, 2, 3], true);
        solver.add_xor(&[1, 2, 4], false);
        solver.add_xor(&[3, 4, 5], false);
        solver.add_clause(vec![1]);
        solver.add_clause(vec![-2]);
        let events = Arc::new(Mutex::new(Vec::new()));
        let output = Arc::clone(&events);
        solver
            .set_event_observer(move |event| {
                output.lock().unwrap().push(event.clone());
                Ok(())
            })
            .unwrap();
        assert_eq!(solver.solve(), SolveResult::Sat);
        let events = events.lock().unwrap();
        assert!(events
            .iter()
            .any(|e| matches!(e, SolverEvent::XorRowXor { .. })));
        assert!(events
            .iter()
            .any(|e| matches!(e, SolverEvent::XorImplication { .. })));
        assert_eq!(replay_observer(&events).unwrap(), solver.assignment());
        for event in events.iter() {
            let encoded = serde_json::to_vec(event).unwrap();
            assert_eq!(
                serde_json::from_slice::<SolverEvent>(&encoded).unwrap(),
                *event
            );
        }
    }

    #[test]
    fn observer_replays_incremental_units_and_censors_root_conflicts() {
        use std::sync::Mutex;
        fn assert_send_sync<T: Send + Sync>() {}
        assert_send_sync::<Solver>();
        let mut solver = Solver::new(2);
        solver.add_clause(vec![-1, 2]);
        let events = Arc::new(Mutex::new(Vec::new()));
        let output = Arc::clone(&events);
        solver
            .set_event_observer(move |event| {
                output.lock().unwrap().push(event.clone());
                Ok(())
            })
            .unwrap();
        assert!(solver.add_clause(vec![1]));
        assert_eq!(solver.propagate_root(), RootPropagationResult::Fixpoint);
        assert_eq!(
            replay_observer(&events.lock().unwrap()).unwrap(),
            solver.assignment()
        );

        let mut root_conflict = Solver::new(2);
        root_conflict.add_clause(vec![-1, 2]);
        root_conflict.add_clause(vec![-1, -2]);
        root_conflict.add_clause(vec![1]);
        root_conflict
            .set_event_observer(|event| {
                if matches!(event, SolverEvent::Conflict { .. }) {
                    Err("root conflict sink failure".into())
                } else {
                    Ok(())
                }
            })
            .unwrap();
        assert_eq!(
            root_conflict.propagate_root(),
            RootPropagationResult::Unknown
        );
        assert!(!root_conflict.is_unsat);
        assert_eq!(root_conflict.solve(), SolveResult::Unknown);
    }

    #[test]
    fn observer_retains_immediate_incremental_contradictions_and_censors_sink_errors() {
        use std::sync::Mutex;
        fn base() -> Solver {
            let mut solver = Solver::new(2);
            solver.add_clause(vec![1]);
            solver.add_clause(vec![-2]);
            solver
        }
        fn contradict(solver: &mut Solver, which: u8) -> bool {
            match which {
                0 => solver.add_clause(vec![]),
                1 => solver.add_clause(vec![-1, 2]),
                _ => solver.add_xor(&[1, 1], true),
            }
        }
        for which in 0..3 {
            let mut solver = base();
            let mut plain = base();
            let events = Arc::new(Mutex::new(Vec::new()));
            let output = Arc::clone(&events);
            solver
                .set_event_observer(move |event| {
                    output.lock().unwrap().push(event.clone());
                    Ok(())
                })
                .unwrap();
            assert!(!contradict(&mut solver, which));
            assert!(!contradict(&mut plain, which));
            assert_eq!(solver.solve(), SolveResult::Unsat);
            assert_eq!(plain.solve(), SolveResult::Unsat);
            assert_eq!(solver.word_ops(), plain.word_ops());
            let events = events.lock().unwrap();
            assert_eq!(replay_observer(&events).unwrap(), solver.assignment());
            let event = events
                .iter()
                .find(|e| matches!(e, SolverEvent::FormulaContradiction { .. }))
                .unwrap();
            let expected = match which {
                0 => SolverEventConstraint::Clause { literals: vec![] },
                1 => SolverEventConstraint::Clause {
                    literals: vec![-1, 2],
                },
                _ => SolverEventConstraint::Xor {
                    variables: vec![1, 1],
                    rhs: true,
                },
            };
            assert_eq!(
                event,
                &SolverEvent::FormulaContradiction {
                    level: 0,
                    constraint: expected
                }
            );
            assert_eq!(
                serde_json::from_slice::<SolverEvent>(&serde_json::to_vec(event).unwrap()).unwrap(),
                *event
            );

            let mut censored = base();
            censored
                .set_event_observer(|event| {
                    if matches!(event, SolverEvent::FormulaContradiction { .. }) {
                        Err("contradiction sink failed".into())
                    } else {
                        Ok(())
                    }
                })
                .unwrap();
            assert!(!contradict(&mut censored, which));
            assert_eq!(censored.solve(), SolveResult::Unknown);
            assert_eq!(censored.propagate_root(), RootPropagationResult::Unknown);
            assert_eq!(
                censored.event_observer_error(),
                Some("contradiction sink failed")
            );
        }
    }

    #[test]
    fn observer_errors_always_censor_including_terminal_unsat() {
        for stop in ["snapshot", "assignment", "conflict", "learned", "finish"] {
            let mut solver = observer_pigeonhole(5, 4);
            let install = solver.set_event_observer(move |event| {
                let fail = match stop {
                    "snapshot" => matches!(event, SolverEvent::Snapshot { .. }),
                    "assignment" => matches!(event, SolverEvent::Assignment { .. }),
                    "conflict" => matches!(event, SolverEvent::Conflict { .. }),
                    "learned" => matches!(event, SolverEvent::Learned { .. }),
                    _ => matches!(event, SolverEvent::SolveEnd { .. }),
                };
                if fail {
                    Err(format!("test sink failed at {stop}"))
                } else {
                    Ok(())
                }
            });
            assert_eq!(install.is_err(), stop == "snapshot");
            assert_eq!(solver.solve(), SolveResult::Unknown, "{stop}");
            assert!(solver.event_observer_error().unwrap().contains(stop));
            assert_eq!(solver.solve(), SolveResult::Unknown);
            solver.reset_search();
            assert_eq!(solver.propagate_root(), RootPropagationResult::Unknown);
        }
    }
    use std::collections::HashSet;

    /// Re-entering `solve` after a conflict-budget stop must give the
    /// same answer as one unbounded call.  Before the level-zero restart
    /// on entry, a resumed solve could return SAT with a model that
    /// violates the formula, or UNSAT on a satisfiable one.
    #[test]
    fn resume_after_budget_stop_is_sound() {
        let mut state = 0x2026_1027u64;
        let mut next = || {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            state
        };
        let (vars, clauses_n) = (60u32, 255usize);
        let (mut sat, mut unsat) = (0, 0);
        for _ in 0..60 {
            let clauses: Vec<Vec<Lit>> = (0..clauses_n)
                .map(|_| {
                    (0..3)
                        .map(|_| {
                            let v = (next() % vars as u64) as i32 + 1;
                            if next() & 1 == 1 {
                                v
                            } else {
                                -v
                            }
                        })
                        .collect()
                })
                .collect();
            let build = || {
                let mut s = Solver::new(vars);
                for c in &clauses {
                    s.add_clause(c.clone());
                }
                s
            };
            let expected = build().solve();
            let mut s = build();
            let mut budget = 1u64;
            let got = loop {
                s.conflict_budget = budget;
                match s.solve() {
                    SolveResult::Unknown => budget += 1 + budget / 4,
                    r => break r,
                }
            };
            assert_eq!(got, expected);
            if got == SolveResult::Sat {
                assert!(check_model(&clauses, &s.model()));
                sat += 1;
            } else {
                unsat += 1;
            }
        }
        assert!(sat > 0 && unsat > 0, "sat={sat} unsat={unsat}");
    }

    #[test]
    fn storage_inventory_partitions_clause_words_and_nested_buffers() {
        let mut s = Solver::new(8);
        s.add_clause(vec![1, 2, 3]);
        s.add_clause(vec![-1, 4]);
        let originals = s.arena.len() as u64;
        s.push_clause(&[2, 4, 5, 6]);
        s.push_clause(&[-2, 7]);
        s.detached.resize(s.clause_at.len(), false);
        s.detached[s.n_orig_clauses] = true;
        s.xor_reason[0] = Vec::with_capacity(19);
        let inventory = s.storage_inventory();
        assert_eq!(inventory["original_clause_words"], originals);
        assert_eq!(inventory["active_learnt_clause_words"], 3);
        assert_eq!(inventory["detached_learnt_clause_words"], 5);
        assert_eq!(inventory["detached_learnt_clauses"], 1);
        assert_eq!(inventory["arena_used_words"], originals + 8);
        let components = inventory["components_capacity_bytes"].as_object().unwrap();
        assert_eq!(components["clause_arena"], capacity_bytes(&s.arena));
        assert_eq!(components["xor_reason_literals"], 19 * 4);
        assert_eq!(
            inventory["owned_capacity_bytes"].as_u64().unwrap(),
            components
                .values()
                .map(|v| v.as_u64().unwrap())
                .sum::<u64>()
        );
    }

    #[test]
    fn storage_observation_leaves_the_search_and_model_unchanged() {
        let clauses = [vec![1, 2], vec![-1, 3], vec![-2, -3]];
        let build = || {
            let mut solver = Solver::new(4);
            for clause in &clauses {
                solver.add_clause(clause.clone());
            }
            solver.add_xor(&[2, 3, 4], true);
            solver
        };
        let mut observed = build();
        let mut reference = build();
        let before_arena = observed.arena.clone();
        let before_capacity = observed.arena.capacity();
        let _ = observed.storage_inventory();
        assert_eq!(observed.arena, before_arena);
        assert_eq!(observed.arena.capacity(), before_capacity);
        assert_eq!(observed.solve(), reference.solve());
        assert_eq!(observed.model(), reference.model());
        assert_eq!(observed.stats.conflicts, reference.stats.conflicts);
        assert_eq!(observed.stats.decisions, reference.stats.decisions);
        assert_eq!(observed.stats.propagations, reference.stats.propagations);
        assert!(check_model(&clauses, &observed.model()));
    }

    #[test]
    fn storage_sampling_is_limited_to_boundaries_and_ten_thousand_conflicts() {
        assert!(storage_snapshot_due("solve_enter", 0));
        assert!(storage_snapshot_due("solve_return", 450_000));
        assert!(storage_snapshot_due("conflict_snapshot", 10_000));
        assert!(!storage_snapshot_due("conflict_snapshot", 1_000));
        assert!(!storage_snapshot_due("initial_propagation_complete", 0));
    }

    // ── native XOR reasoning ────────────────────────────────────────

    /// `x₁ ⊕ x₂ = 1` and `x₂ ⊕ x₃ = 1` and `x₁ ⊕ x₃ = 1` is the odd-
    /// cycle parity contradiction: summing all three rows gives `0 = 1`.
    /// Gaussian elimination must see it; resolution would have to search.
    #[test]
    fn xor_odd_cycle_is_unsat() {
        let mut s = Solver::new(3);
        assert!(s.add_xor(&[1, 2], true));
        assert!(s.add_xor(&[2, 3], true));
        assert!(s.add_xor(&[1, 3], true));
        assert_eq!(s.solve(), SolveResult::Unsat);
    }

    /// A triangular XOR system with a unique solution, derivable by
    /// propagation alone (no decisions needed).
    #[test]
    fn xor_system_propagates_to_unique_solution() {
        let mut s = Solver::new(3);
        s.add_xor(&[1], true); //           x₁ = 1
        s.add_xor(&[1, 2], false); //  x₁ ⊕ x₂ = 0  → x₂ = 1
        s.add_xor(&[2, 3], true); //   x₂ ⊕ x₃ = 1  → x₃ = 0
        assert_eq!(s.solve(), SolveResult::Sat);
        let m = s.model();
        assert_eq!((m[0], m[1], m[2]), (true, true, false));
        assert!(s.check_xors(&m));
    }

    #[test]
    fn optional_progress_observer_preserves_sat_and_unsat_search() {
        fn instance(contradictory: bool) -> Solver {
            let mut solver = Solver::new(3);
            solver.add_xor(&[1, 2], false);
            solver.add_clause(vec![1, 2]);
            if contradictory {
                solver.add_clause(vec![-1, -2]);
            } else {
                solver.add_clause(vec![2, 3]);
            }
            solver
        }
        for contradictory in [false, true] {
            let mut direct = instance(contradictory);
            let direct_result = direct.solve();
            assert!(direct.stats.decisions > 0);
            if contradictory {
                assert!(direct.stats.conflicts > 0);
            }
            let direct_model = (direct_result == SolveResult::Sat).then(|| direct.model());

            let mut observed = instance(contradictory);
            let progress = Arc::new(SolverProgress::default());
            observed.set_progress_observer(Arc::clone(&progress));
            let observed_result = observed.solve();
            let observed_model = (observed_result == SolveResult::Sat).then(|| observed.model());
            assert_eq!(observed_result, direct_result);
            assert_eq!(observed_model, direct_model);
            if let Some(model) = observed_model {
                assert!(observed.check_xors(&model));
            }
            let snapshot = progress.snapshot();
            assert_eq!(snapshot.phase, SolverProgressPhase::Complete);
            assert_eq!(snapshot.decisions, observed.stats.decisions);
            assert_eq!(snapshot.conflicts, observed.stats.conflicts);
            assert_eq!(snapshot.restarts, observed.stats.restarts);
            assert_eq!(snapshot.xor_passes, observed.stats.xor_passes);
            assert_eq!(snapshot.xor_nanoseconds, observed.stats.ns_propagate_xors);
            assert_eq!(snapshot.xor_row_scans, observed.stats.xor_row_scans);
            assert_eq!(snapshot.xor_repivots, observed.stats.xor_repivots);
            assert_eq!(snapshot.xor_row_ops, observed.stats.xor_row_ops);
        }
    }

    #[test]
    fn root_propagation_keeps_sat_state_for_solve() {
        fn instance() -> Solver {
            let mut s = Solver::new(3);
            s.add_xor(&[1, 2], false);
            s.add_xor(&[2, 3], true);
            s.add_clause(vec![1]);
            s
        }
        let mut direct = instance();
        assert_eq!(direct.solve(), SolveResult::Sat);
        let expected = direct.model();
        let mut staged = instance();
        assert_eq!(staged.propagate_root(), RootPropagationResult::Fixpoint);
        assert_eq!(staged.stats.decisions, 0);
        assert_eq!(staged.solve(), SolveResult::Sat);
        assert_eq!(staged.model(), expected);
        assert!(staged.check_xors(&staged.model()));
    }

    #[test]
    fn root_propagation_keeps_unsat_state_for_solve() {
        fn instance() -> Solver {
            let mut s = Solver::new(3);
            assert!(s.add_xor(&[1, 2], true));
            assert!(s.add_xor(&[2, 3], true));
            assert!(s.add_xor(&[1, 3], true));
            s
        }
        let mut direct = instance();
        assert_eq!(direct.solve(), SolveResult::Unsat);
        let mut staged = instance();
        assert_eq!(staged.propagate_root(), RootPropagationResult::Unsat);
        assert_eq!(staged.solve(), SolveResult::Unsat);
    }

    /// Duplicated variables inside one row must cancel: `x ⊕ x ⊕ y = 1`
    /// is just `y = 1`.
    #[test]
    fn xor_duplicate_vars_cancel() {
        let mut s = Solver::new(2);
        assert!(s.add_xor(&[1, 1, 2], true));
        assert_eq!(s.solve(), SolveResult::Sat);
        assert!(s.model()[1], "y must be forced true");
    }

    /// `x ⊕ x = 1` reduces to `0 = 1` and is rejected at add time.
    #[test]
    fn xor_empty_row_with_true_rhs_is_unsat() {
        let mut s = Solver::new(2);
        assert!(!s.add_xor(&[1, 1], true));
        assert_eq!(s.solve(), SolveResult::Unsat);
    }

    /// XOR rows and CNF clauses must constrain each other: the parity
    /// rows admit two solutions, and the clause rules one out.
    #[test]
    fn xor_and_cnf_interact() {
        let mut s = Solver::new(3);
        s.add_xor(&[1, 2], false); // x₁ = x₂
        s.add_xor(&[2, 3], false); // x₂ = x₃
        s.add_clause(vec![1]); //     x₁ = 1  ⇒ all true
        assert_eq!(s.solve(), SolveResult::Sat);
        let m = s.model();
        assert_eq!((m[0], m[1], m[2]), (true, true, true));
        assert!(s.check_xors(&m));
    }

    /// **The incremental matrix must lose nothing.**
    ///
    /// The whole design rests on one claim: with every row carrying an
    /// unassigned pivot that occurs in no other row, a per-row check
    /// finds every implication that re-running Gaussian elimination
    /// would.  This tests that claim directly rather than trusting the
    /// argument — for random systems under random partial assignments,
    /// the solver's implications are compared against an oracle that
    /// eliminates from scratch every time.
    ///
    /// A silent incompleteness here would show up as a missed
    /// propagation, not a crash, so it is worth checking explicitly.
    #[test]
    fn indexed_words_match_dense_across_growth_and_blocking() {
        let mut rng = 0x83a9_47d2_1bce_7731u64;
        fn next(rng: &mut u64) -> u64 {
            *rng ^= *rng << 13;
            *rng ^= *rng >> 7;
            *rng ^= *rng << 17;
            *rng
        }
        for n in [1u32, 63, 64, 65, 127, 130] {
            for _ in 0..12 {
                let mut dense = Solver::new(n);
                dense.set_indexed_xors(false);
                let mut indexed = Solver::new(n);
                let truth: Vec<bool> = (0..n).map(|_| next(&mut rng) & 1 != 0).collect();
                for _ in 0..40 {
                    let vars: Vec<u32> = (0..5)
                        .map(|_| 1 + (next(&mut rng) % n as u64) as u32)
                        .collect();
                    let rhs = vars.iter().fold(false, |p, &v| p ^ truth[v as usize - 1]);
                    assert_eq!(dense.add_xor(&vars, rhs), indexed.add_xor(&vars, rhs));
                }
                for _ in 0..40 {
                    let mut clause: Vec<Lit> = (0..4)
                        .map(|_| {
                            let v = (1 + next(&mut rng) % n as u64) as Lit;
                            if next(&mut rng) & 1 == 0 {
                                v
                            } else {
                                -v
                            }
                        })
                        .collect();
                    if !clause
                        .iter()
                        .any(|&l| truth[l.unsigned_abs() as usize - 1] == (l > 0))
                    {
                        clause[0] = -clause[0];
                    }
                    assert_eq!(dense.add_clause(clause.clone()), indexed.add_clause(clause));
                }
                for _ in 0..3 {
                    dense.conflict_budget = 1000;
                    indexed.conflict_budget = 1000;
                    let a = dense.solve();
                    let b = indexed.solve();
                    assert_eq!(a, b, "width {n}");
                    assert_eq!(dense.model(), indexed.model());
                    assert_eq!(
                        (
                            dense.stats.conflicts,
                            dense.stats.decisions,
                            dense.stats.xor_row_ops,
                            dense.stats.xor_passes,
                            dense.stats.xor_reason_lits
                        ),
                        (
                            indexed.stats.conflicts,
                            indexed.stats.decisions,
                            indexed.stats.xor_row_ops,
                            indexed.stats.xor_passes,
                            indexed.stats.xor_reason_lits
                        )
                    );
                    let words = bs_words(indexed.n_vars);
                    for (i, support) in indexed.matrix_support.iter().enumerate() {
                        let exact: Vec<_> = indexed.matrix[i * words..(i + 1) * words]
                            .iter()
                            .enumerate()
                            .filter_map(|(w, &m)| (m != 0).then_some(w))
                            .collect();
                        assert_eq!(*support, exact);
                    }
                    if a != SolveResult::Sat {
                        break;
                    }
                    let block: Vec<_> = dense
                        .model()
                        .iter()
                        .enumerate()
                        .map(|(v, &t)| if t { -((v + 1) as Lit) } else { (v + 1) as Lit })
                        .collect();
                    dense.reset_search();
                    indexed.reset_search();
                    assert_eq!(dense.add_clause(block.clone()), indexed.add_clause(block));
                }
                // Widen the already-used matrix across another word boundary.
                dense.reset_search();
                indexed.reset_search();
                dense.add_vars(65);
                indexed.add_vars(65);
                assert_eq!(
                    dense.add_xor(&[n, n + 1, n + 65], true),
                    indexed.add_xor(&[n, n + 1, n + 65], true)
                );
                assert_eq!(dense.solve(), indexed.solve());
                assert_eq!(dense.model(), indexed.model());
            }
        }
    }

    #[test]
    fn incremental_matrix_matches_full_elimination() {
        let n_vars = 12u32;
        let mut state = 0xD1B5_4A32_D192_ED03u64;
        let mut next = || {
            state ^= state >> 12;
            state ^= state << 25;
            state ^= state >> 27;
            state.wrapping_mul(0x2545_F491_4F6C_DD1D)
        };

        /// Oracle: full Gauss-Jordan from scratch, returning every
        /// variable the system forces under `fixed`, with its value.
        fn oracle(
            rows: &[(Vec<u32>, bool)],
            fixed: &[Option<bool>],
            n_vars: u32,
        ) -> Option<Vec<(u32, bool)>> {
            // Dense F2 elimination over the unassigned columns.
            let mut m: Vec<(Vec<bool>, bool)> = rows
                .iter()
                .map(|(vars, rhs)| {
                    let mut row = vec![false; n_vars as usize];
                    let mut r = *rhs;
                    for &v in vars {
                        let idx = (v - 1) as usize;
                        match fixed[idx] {
                            Some(true) => r = !r,
                            Some(false) => {}
                            None => row[idx] ^= true,
                        }
                    }
                    (row, r)
                })
                .collect();
            // Row-reduce.
            let mut pivot_row = 0usize;
            for col in 0..n_vars as usize {
                let Some(sel) = (pivot_row..m.len()).find(|&r| m[r].0[col]) else {
                    continue;
                };
                m.swap(pivot_row, sel);
                for r in 0..m.len() {
                    if r != pivot_row && m[r].0[col] {
                        let (src, rhs) = (m[pivot_row].0.clone(), m[pivot_row].1);
                        for c in 0..n_vars as usize {
                            m[r].0[c] ^= src[c];
                        }
                        m[r].1 ^= rhs;
                    }
                }
                pivot_row += 1;
            }
            let mut implied = Vec::new();
            for (row, rhs) in &m {
                let set: Vec<usize> = (0..n_vars as usize).filter(|&c| row[c]).collect();
                match set.len() {
                    0 => {
                        if *rhs {
                            return None; // inconsistent
                        }
                    }
                    1 => implied.push((set[0] as u32 + 1, *rhs)),
                    _ => {}
                }
            }
            implied.sort();
            Some(implied)
        }

        for trial in 0..300 {
            let n_rows = 2 + (next() % 6) as usize;
            let rows: Vec<(Vec<u32>, bool)> = (0..n_rows)
                .map(|_| {
                    let mut vars: Vec<u32> = (1..=n_vars).filter(|_| next() % 3 != 0).collect();
                    if vars.is_empty() {
                        vars.push(1);
                    }
                    (vars, next() % 2 == 0)
                })
                .collect();

            // A random partial assignment, installed as unit clauses so
            // the solver reaches it by propagation at level 0.
            let mut fixed: Vec<Option<bool>> = vec![None; n_vars as usize];
            let mut units: Vec<Lit> = Vec::new();
            for v in 1..=n_vars {
                if next() % 3 == 0 {
                    let val = next() % 2 == 0;
                    fixed[(v - 1) as usize] = Some(val);
                    units.push(if val { v as Lit } else { -(v as Lit) });
                }
            }

            let want = oracle(&rows, &fixed, n_vars);

            let mut s = Solver::new(n_vars);
            let mut trivial_unsat = false;
            for (vars, rhs) in &rows {
                if !s.add_xor(vars, *rhs) {
                    trivial_unsat = true;
                }
            }
            for u in &units {
                if !s.add_clause(vec![*u]) {
                    trivial_unsat = true;
                }
            }
            // Drive propagation to fixpoint at level 0 without deciding.
            let conflicted = trivial_unsat || s.propagate_to_fixpoint_for_test();

            match want {
                None => assert!(
                    conflicted,
                    "trial {trial}: elimination says inconsistent, solver did not notice"
                ),
                Some(implied) => {
                    assert!(
                        !conflicted,
                        "trial {trial}: solver reported a conflict where none exists"
                    );
                    for (v, val) in implied {
                        assert_eq!(
                            s.value_of_for_test(v),
                            Some(val),
                            "trial {trial}: variable {v} should have been forced to {val}"
                        );
                    }
                }
            }
        }
    }

    /// **Differential test against brute force.**  Random dense parity
    /// systems, decided exhaustively and by the solver; every verdict
    /// must agree, and every SAT model must satisfy every row.
    #[test]
    fn xor_engine_agrees_with_brute_force() {
        let n_vars = 9u32;
        let mut state = 0x2545_F491_4F6C_DD1Du64; // xorshift64*
        let mut next = || {
            state ^= state >> 12;
            state ^= state << 25;
            state ^= state >> 27;
            state.wrapping_mul(0x2545_F491_4F6C_DD1D)
        };

        for trial in 0..200 {
            let n_rows = 3 + (next() % 6) as usize;
            let mut rows: Vec<(Vec<u32>, bool)> = Vec::new();
            for _ in 0..n_rows {
                let mut vars: Vec<u32> = Vec::new();
                for v in 1..=n_vars {
                    if next() % 2 == 0 {
                        vars.push(v);
                    }
                }
                if vars.is_empty() {
                    vars.push(1 + (next() % n_vars as u64) as u32);
                }
                rows.push((vars, next() % 2 == 0));
            }

            // Ground truth by exhaustive search.
            let mut brute_sat = false;
            for a in 0..(1u32 << n_vars) {
                if rows.iter().all(|(vars, rhs)| {
                    let parity = vars.iter().filter(|v| (a >> (**v - 1)) & 1 == 1).count() % 2 == 1;
                    parity == *rhs
                }) {
                    brute_sat = true;
                    break;
                }
            }

            let mut s = Solver::new(n_vars);
            let mut trivially_unsat = false;
            for (vars, rhs) in &rows {
                if !s.add_xor(vars, *rhs) {
                    trivially_unsat = true;
                }
            }
            let res = s.solve();

            if brute_sat {
                assert_eq!(
                    res,
                    SolveResult::Sat,
                    "trial {trial}: solver missed a model"
                );
                let m = s.model();
                assert!(s.check_xors(&m), "trial {trial}: model violates a row");
            } else {
                assert_eq!(
                    res,
                    SolveResult::Unsat,
                    "trial {trial}: solver invented a model"
                );
                let _ = trivially_unsat;
            }
        }
    }

    #[test]
    fn deferred_xor_still_checks_a_complete_assignment() {
        for cadence in [1, 2, 8] {
            let mut sat = Solver::new(4);
            sat.set_xor_decision_cadence(cadence);
            assert!(sat.add_xor(&[1, 2, 3, 4], true));
            assert_eq!(sat.solve(), SolveResult::Sat);
            let model = sat.model();
            assert!(sat.check_xors(&model));
            assert_eq!(model.iter().filter(|&&value| value).count() % 2, 1);

            let mut unsat = Solver::new(4);
            unsat.set_xor_decision_cadence(cadence);
            assert!(unsat.add_xor(&[1, 2, 3, 4], true));
            // These eight clauses admit only even-parity assignments.
            for assignment in 0u32..16 {
                if assignment.count_ones() % 2 == 1 {
                    let clause = (0..4)
                        .map(|bit| {
                            let variable = (bit + 1) as Lit;
                            if assignment & (1 << bit) != 0 {
                                -variable
                            } else {
                                variable
                            }
                        })
                        .collect();
                    assert!(unsat.add_clause(clause));
                }
            }
            assert_eq!(unsat.solve(), SolveResult::Unsat);
        }
    }

    #[test]
    fn deferred_xor_mixed_cnf_agrees_with_exhaustive_search() {
        let mut state = 0x9e37_79b9_7f4a_7c15u64;
        let mut next = || {
            state ^= state >> 12;
            state ^= state << 25;
            state ^= state >> 27;
            state.wrapping_mul(0x2545_F491_4F6C_DD1D)
        };
        for trial in 0..120 {
            let clauses: Vec<Vec<Lit>> = (0..(3 + next() % 8))
                .map(|_| {
                    (0..3)
                        .map(|_| {
                            let var = (1 + next() % 6) as Lit;
                            if next() & 1 == 0 {
                                var
                            } else {
                                -var
                            }
                        })
                        .collect()
                })
                .collect();
            let xors: Vec<(Vec<u32>, bool)> = (0..(2 + next() % 5))
                .map(|_| {
                    let mut vars: Vec<u32> = (1..=6).filter(|_| next() & 1 == 0).collect();
                    if vars.is_empty() {
                        vars.push((1 + next() % 6) as u32);
                    }
                    (vars, next() & 1 == 0)
                })
                .collect();
            let brute_sat = (0u32..64).any(|bits| {
                clauses.iter().all(|clause| {
                    clause.iter().any(|&lit| {
                        let bit = (bits >> var_of(lit)) & 1 != 0;
                        if lit > 0 {
                            bit
                        } else {
                            !bit
                        }
                    })
                }) && xors.iter().all(|(vars, rhs)| {
                    vars.iter().filter(|&&v| (bits >> (v - 1)) & 1 != 0).count() % 2
                        == usize::from(*rhs)
                })
            });
            for cadence in [1, 2, 4, 32] {
                let mut solver = Solver::new(6);
                solver.set_xor_decision_cadence(cadence);
                for clause in &clauses {
                    solver.add_clause(clause.clone());
                }
                for (vars, rhs) in &xors {
                    solver.add_xor(vars, *rhs);
                }
                let answer = solver.solve();
                assert_eq!(
                    answer == SolveResult::Sat,
                    brute_sat,
                    "mixed CNF/XOR trial {trial}, cadence {cadence}: {answer:?}; clauses={clauses:?}; xors={xors:?}"
                );
                if answer == SolveResult::Sat {
                    let model = solver.model();
                    assert!(solver.check_xors(&model));
                    assert!(clauses.iter().all(|clause| clause.iter().any(|&lit| {
                        if lit > 0 {
                            model[(lit - 1) as usize]
                        } else {
                            !model[(-lit - 1) as usize]
                        }
                    })));
                }
            }
        }
    }

    #[test]
    fn expired_deadline_stops_conflict_free_search() {
        let mut solver = Solver::new(4);
        solver.deadline = Some(std::time::Instant::now());
        assert_eq!(solver.solve(), SolveResult::Unknown);
    }

    /// The extended-DIMACS reader must apply CryptoMiniSat's parity
    /// convention: bare literals mean `= 1`, one negation flips to `= 0`.
    #[test]
    fn parse_dimacs_xor_reads_parity_convention() {
        // x₁ ⊕ x₂ ⊕ x₃ = 1 (no negations), x₁ ⊕ x₂ = 0 (one negation),
        // plus the unit clause x₃.  Together these force x₃ = 1 and
        // x₁ = x₂.
        let src = "p cnf 3 3\nx 1 2 3 0\nx -1 2 0\n3 0\n";
        let mut s = parse_dimacs_xor(src).expect("parse");
        assert_eq!(s.n_xors(), 2);
        assert_eq!(s.solve(), SolveResult::Sat);
        let m = s.model();
        assert!(s.check_xors(&m));
        assert!(m[2], "the unit clause forces x₃ true");
        assert!(m[0] ^ m[1] ^ m[2], "first row must have odd parity");
        assert!(!(m[0] ^ m[1]), "second row must have even parity");

        // Flipping the unit clause to ¬x₃ makes the same system UNSAT.
        let src_bad = "p cnf 3 3\nx 1 2 3 0\nx -1 2 0\n-3 0\n";
        assert_eq!(
            parse_dimacs_xor(src_bad).expect("parse").solve(),
            SolveResult::Unsat
        );
    }

    #[test]
    fn extended_dimacs_export_round_trips_xors_and_root_unsat() {
        let mut original = Solver::new(4);
        assert!(original.add_clause(vec![1, -4]));
        assert!(original.add_xor(&[1, 2, 3], true));
        assert!(original.add_xor(&[2, 4], false));
        let encoded = to_dimacs_xor(&original);
        let mut reparsed = parse_dimacs_xor(&encoded).expect("parse exported XOR DIMACS");
        assert_eq!(reparsed.n_xors(), 2);
        assert_eq!(reparsed.solve(), SolveResult::Sat);
        let model = reparsed.model();
        assert!(reparsed.check_xors(&model));

        let mut root_unsat = Solver::new(1);
        assert!(!root_unsat.add_clause(Vec::new()));
        let encoded_unsat = to_dimacs_xor(&root_unsat);
        assert!(encoded_unsat.lines().any(|line| line.trim() == "0"));
        assert_eq!(
            parse_dimacs_xor(&encoded_unsat)
                .expect("parse exported root conflict")
                .solve(),
            SolveResult::Unsat
        );
    }

    #[test]
    fn targeted_saved_phase_changes_first_decision_without_changing_satisfiability() {
        for value in [false, true] {
            let mut solver = Solver::new(2);
            assert!(solver.add_clause(vec![1, 2]));
            solver.set_branch_priority(&[1]);
            solver.set_saved_phase_for_vars(&[1], value);
            assert_eq!(solver.solve(), SolveResult::Sat);
            assert_eq!(solver.model()[0], value);
            assert!(solver.check_original_assignment(&solver.model()));
        }
    }

    #[test]
    fn lazy_clause_callback_installs_guarded_theory_consequences_on_current_trail() {
        let mut solver = Solver::new(3);
        solver.set_branch_priority(&[1, 2]);
        let mut seen = std::collections::HashSet::new();
        let mut theory = |assignment: &[Option<bool>]| {
            let left = assignment[0].unwrap();
            let right = assignment[1].unwrap();
            if !seen.insert((left, right)) {
                return None;
            }
            let mut clause = vec![if left { -1 } else { 1 }, if right { -2 } else { 2 }];
            clause.push(if left ^ right { 3 } else { -3 });
            Some(vec![clause])
        };
        assert_eq!(
            solver.solve_with_lazy_clauses(&[1, 2], &mut theory),
            SolveResult::Sat
        );
        let model = solver.model();
        assert_eq!(model[2], model[0] ^ model[1]);
        assert!(!seen.is_empty());
    }

    #[test]
    fn lazy_clause_conflict_backjumps_and_preserves_theory_answer() {
        let mut solver = Solver::new(3);
        solver.set_branch_priority(&[1, 2]);
        assert!(solver.add_clause(vec![-3]));
        let mut seen = std::collections::HashSet::new();
        let mut theory = |assignment: &[Option<bool>]| {
            let left = assignment[0].unwrap();
            let right = assignment[1].unwrap();
            if !seen.insert((left, right)) {
                return None;
            }
            let mut clause = vec![if left { -1 } else { 1 }, if right { -2 } else { 2 }];
            clause.push(if left ^ right { 3 } else { -3 });
            Some(vec![clause])
        };
        assert_eq!(
            solver.solve_with_lazy_clauses(&[1, 2], &mut theory),
            SolveResult::Sat
        );
        let model = solver.model();
        assert!(!model[2]);
        assert_eq!(model[2], model[0] ^ model[1]);
        assert!(!seen.is_empty());
    }

    /// A literal past the variables is refused even once
    /// [`Solver::add_vars`] has grown the literal tables past `n_vars`,
    /// where its spare slot would read as a variable nothing watches.
    /// The per-variable tables before them panicked on the index.
    #[test]
    #[should_panic(expected = "names no variable of this solver")]
    fn add_clause_refuses_a_literal_past_the_variables_after_add_vars() {
        let mut solver = Solver::new(1000);
        solver.add_vars(1);
        solver.add_clause(vec![1, 1500]);
    }

    /// 0 is refused wherever it sorts, but a tautology is still dropped
    /// before any literal is looked at, as it always was.
    #[test]
    fn add_clause_drops_tautologies_before_checking_literals() {
        let mut solver = Solver::new(3);
        assert!(solver.add_clause(vec![1, -1, 7]));
        assert_eq!(solver.n_clauses(), 0);
    }

    /// With overflow checks `var_of(0)` already panics while the clause
    /// is sorted; without them the clause check refuses it.  Either way
    /// it never reaches a table.
    #[test]
    #[should_panic]
    fn add_clause_refuses_literal_zero() {
        let mut solver = Solver::new(3);
        solver.add_clause(vec![1, 0]);
    }

    /// A trigger variable past the variables panics on the index, as it
    /// did before the tables had spare slots, rather than reading as
    /// never assigned and silently never consulting the theory.
    #[test]
    #[should_panic(expected = "index out of bounds")]
    fn lazy_trigger_past_the_variables_panics_after_add_vars() {
        let mut solver = Solver::new(10);
        solver.add_vars(1);
        assert!(solver.add_clause(vec![1, 2]));
        let mut theory = |_: &[Option<bool>]| -> Option<Vec<Vec<Lit>>> { Some(vec![vec![-1]]) };
        solver.solve_with_lazy_clauses(&[15], &mut theory);
    }

    /// A theory clause naming a variable past the solver's is refused
    /// like one given to [`Solver::add_clause`].
    #[test]
    #[should_panic(expected = "names no variable of this solver")]
    fn lazy_theory_clause_past_the_variables_panics() {
        let mut solver = Solver::new(10);
        solver.add_vars(1);
        assert!(solver.add_clause(vec![1, 2]));
        let mut theory = |_: &[Option<bool>]| -> Option<Vec<Vec<Lit>>> { Some(vec![vec![-1, 50]]) };
        solver.solve_with_lazy_clauses(&[1], &mut theory);
    }

    /// **Clause forgetting must not change any answer.**  Under a
    /// deliberately tiny budget the solver reduces its learnt database
    /// constantly; every verdict and every model must still match a
    /// run that never forgets anything.
    #[test]
    fn aggressive_clause_reduction_preserves_answers() {
        let n_vars = 9u32;
        let mut state = 0x9E37_79B9_7F4A_7C15u64;
        let mut next = || {
            state ^= state >> 12;
            state ^= state << 25;
            state ^= state >> 27;
            state.wrapping_mul(0x2545_F491_4F6C_DD1D)
        };

        for trial in 0..60 {
            // A mixed CNF + parity instance, the shape this solver is
            // actually used on.
            let mut clauses: Vec<Vec<Lit>> = Vec::new();
            for _ in 0..(20 + next() % 20) {
                let mut c = Vec::new();
                for _ in 0..3 {
                    let v = 1 + (next() % n_vars as u64) as i32;
                    let sign = if next() % 2 == 0 { 1 } else { -1 };
                    c.push(sign * v);
                }
                clauses.push(c);
            }
            let mut xors: Vec<(Vec<u32>, bool)> = Vec::new();
            for _ in 0..3 {
                let vars: Vec<u32> = (1..=n_vars).filter(|_| next() % 2 == 0).collect();
                if !vars.is_empty() {
                    xors.push((vars, next() % 2 == 0));
                }
            }

            let build = |budget: usize| {
                let mut s = Solver::new(n_vars);
                for c in &clauses {
                    s.add_clause(c.clone());
                }
                for (vars, rhs) in &xors {
                    s.add_xor(vars, *rhs);
                }
                s.max_learnts = budget;
                s
            };

            let mut relaxed = build(1_000_000);
            let mut aggressive = build(2);
            let (ra, rb) = (relaxed.solve(), aggressive.solve());
            assert_eq!(ra, rb, "trial {trial}: forgetting changed the verdict");
            if ra == SolveResult::Sat {
                let m = aggressive.model();
                assert!(
                    check_model(&clauses, &m) && aggressive.check_xors(&m),
                    "trial {trial}: model from the forgetting run is invalid"
                );
            }
        }
    }

    /// A small known-SAT instance.
    #[test]
    fn simple_sat() {
        let mut s = Solver::new(3);
        assert!(s.add_clause(vec![1, 2]));
        assert!(s.add_clause(vec![-1, 3]));
        assert!(s.add_clause(vec![-2, -3]));
        assert!(s.add_clause(vec![1, -3]));
        assert_eq!(s.solve(), SolveResult::Sat);
        let m = s.model();
        // Verify against the original clauses.
        let orig = vec![vec![1, 2], vec![-1, 3], vec![-2, -3], vec![1, -3]];
        assert!(check_model(&orig, &m));
    }

    /// Trivially UNSAT: x ∧ ¬x.  Note: `add_clause` may return false
    /// for the second unit clause because enqueuing `-1` conflicts
    /// with the already-propagated `1`; both that path and `solve()`
    /// must reach UNSAT.
    #[test]
    fn trivial_unsat() {
        let mut s = Solver::new(1);
        assert!(s.add_clause(vec![1]));
        // The contradictory unit may be detected immediately at add
        // time (returns false) or surface from solve(); either is
        // valid UNSAT detection.
        let added = s.add_clause(vec![-1]);
        if added {
            assert_eq!(s.solve(), SolveResult::Unsat);
        } else {
            // add_clause already detected UNSAT; solve() must agree.
            assert_eq!(s.solve(), SolveResult::Unsat);
        }
    }

    /// The pigeonhole principle PHP(3, 2): 3 pigeons in 2 holes is
    /// UNSAT. Variable `x_{i,j}` = pigeon `i` is in hole `j`. Indexed
    /// 1..=6 as: (i-1)*2 + j.
    #[test]
    fn pigeonhole_3_into_2_is_unsat() {
        let x = |i: u32, j: u32| ((i - 1) * 2 + j) as i32;
        let mut s = Solver::new(6);
        // Each pigeon in some hole.
        for i in 1..=3 {
            s.add_clause(vec![x(i, 1), x(i, 2)]);
        }
        // No two pigeons in the same hole.
        for j in 1..=2 {
            for i1 in 1..=3 {
                for i2 in (i1 + 1)..=3 {
                    s.add_clause(vec![-x(i1, j), -x(i2, j)]);
                }
            }
        }
        assert_eq!(s.solve(), SolveResult::Unsat);
    }

    /// Pigeonhole 5-into-4 is also UNSAT; non-trivial for CDCL.
    #[test]
    fn pigeonhole_5_into_4_is_unsat() {
        let n_pigeons = 5u32;
        let n_holes = 4u32;
        let x = |i: u32, j: u32| ((i - 1) * n_holes + j) as i32;
        let mut s = Solver::new(n_pigeons * n_holes);
        for i in 1..=n_pigeons {
            let mut c = Vec::with_capacity(n_holes as usize);
            for j in 1..=n_holes {
                c.push(x(i, j));
            }
            s.add_clause(c);
        }
        for j in 1..=n_holes {
            for i1 in 1..=n_pigeons {
                for i2 in (i1 + 1)..=n_pigeons {
                    s.add_clause(vec![-x(i1, j), -x(i2, j)]);
                }
            }
        }
        assert_eq!(s.solve(), SolveResult::Unsat);
    }

    /// Round-trip a CNF through DIMACS.
    #[test]
    fn dimacs_roundtrip() {
        let mut s = Solver::new(4);
        s.add_clause(vec![1, -2, 3]);
        s.add_clause(vec![-1, 2]);
        s.add_clause(vec![-3, 4]);
        let dimacs = to_dimacs(&s);
        assert!(dimacs.starts_with("p cnf 4 3"));
        let s2 = parse_dimacs(&dimacs).expect("parse failed");
        assert_eq!(s2.n_vars(), 4);
        assert_eq!(s2.n_clauses(), 3);
    }

    #[test]
    fn external_assignment_checks_original_cnf_and_xor_rows() {
        let mut solver = Solver::new(3);
        solver.add_clause(vec![1]);
        solver.add_clause(vec![3]);
        solver.add_xor(&[1, 2], true);
        assert!(solver.check_original_assignment(&[true, false, true]));
        assert!(!solver.check_original_assignment(&[true, true, true]));
        assert!(!solver.check_original_assignment(&[false, false, true]));
        assert!(!solver.check_original_assignment(&[true, false]));
    }

    /// Luby sequence check.
    #[test]
    fn luby_sequence_starts_correctly() {
        let seq: Vec<u64> = (1..=15).map(luby).collect();
        assert_eq!(seq, vec![1, 1, 2, 1, 1, 2, 4, 1, 1, 2, 1, 1, 2, 4, 8]);
    }

    /// Random k-SAT instance at the satisfiability threshold (clause-
    /// to-variable ratio ≈ 4.26 for 3-SAT). Should mostly be SAT.
    #[test]
    fn random_3sat_around_threshold() {
        let n = 20u32;
        let m = (4.0 * n as f64) as usize;
        let mut state = 0xc0ffee_u64;
        let mut next = || {
            state = state
                .wrapping_mul(6364136223846793005)
                .wrapping_add(1442695040888963407);
            state >> 33
        };
        let mut s = Solver::new(n);
        let mut orig_clauses = Vec::new();
        for _ in 0..m {
            let mut clause = Vec::with_capacity(3);
            let mut vars_in_clause = HashSet::new();
            while clause.len() < 3 {
                let v = ((next() as u32) % n) + 1;
                if vars_in_clause.insert(v) {
                    let sign = (next() & 1) as u32;
                    clause.push(if sign == 0 { v as i32 } else { -(v as i32) });
                }
            }
            orig_clauses.push(clause.clone());
            s.add_clause(clause);
        }
        let result = s.solve();
        if result == SolveResult::Sat {
            let m = s.model();
            assert!(check_model(&orig_clauses, &m));
        }
        // Either SAT or UNSAT is acceptable; what we're checking is
        // that the solver terminates.
        assert_ne!(result, SolveResult::Unknown);
    }

    /// Fold a solve's verdict, every work counter (the `ns_*` timers
    /// excepted), the clause count and the model into one digest.
    fn trace_digest(h: u64, res: SolveResult, s: &Solver) -> u64 {
        let st = &s.stats;
        let verdict = match res {
            SolveResult::Sat => 1,
            SolveResult::Unsat => 2,
            SolveResult::Unknown => 3,
        };
        let mut words = vec![
            verdict,
            st.decisions,
            st.conflicts,
            st.restarts,
            st.propagations,
            st.xor_passes,
            st.xor_propagations,
            st.xor_conflicts,
            st.xor_repivots,
            st.learnt_clauses,
            st.xor_row_ops,
            st.xor_row_scans,
            st.xor_reason_lits,
            st.clause_visits,
            st.clause_lit_visits,
            st.analyze_lit_visits,
            st.learnt_lits_raw,
            st.learnt_lits_kept,
            st.conflict_level_sum,
            st.max_level,
            s.conflicts(),
            s.n_clauses() as u64,
            s.n_original_clauses() as u64,
        ];
        if res == SolveResult::Sat {
            words.extend(s.model().iter().map(|&b| b as u64));
        }
        words
            .into_iter()
            .fold(h, |h, w| (h ^ w).wrapping_mul(0x0000_0100_0000_01B3))
    }

    /// **The search trace is pinned.**  The solver's data layout is
    /// tuned for speed, and no layout change may alter a single step of
    /// the search: every decision, propagation, learnt literal and
    /// counter must come out the same.  These digests were recorded
    /// from the solver before its layout was tuned (a vector per clause,
    /// `Option<bool>` per variable, a vector per parity row) and cover
    /// what the perfbench fingerprints may not: restarts with clause
    /// forgetting under a tiny budget, parity rows rebuilt at restarts,
    /// `add_vars` after clauses exist, branching priority, incremental
    /// model enumeration through `reset_search`, lazy theory clauses,
    /// and a conflict budget running out.
    #[test]
    fn search_trace_is_pinned() {
        let mut state = 0x6A09_E667_F3BC_C908u64;
        let mut next = move || {
            state ^= state >> 12;
            state ^= state << 25;
            state ^= state >> 27;
            state.wrapping_mul(0x2545_F491_4F6C_DD1D)
        };
        fn random_clause(n: u32, next: &mut dyn FnMut() -> u64) -> Vec<Lit> {
            let mut c: Vec<Lit> = Vec::with_capacity(3);
            while c.len() < 3 {
                let v = 1 + (next() % n as u64) as i32;
                if c.iter().all(|&l| l.abs() != v) {
                    c.push(if next().is_multiple_of(2) { v } else { -v });
                }
            }
            c
        }
        /// A random 3-clause that `planted` satisfies.
        fn planted_clause(planted: &[bool], next: &mut dyn FnMut() -> u64) -> Vec<Lit> {
            loop {
                let c = random_clause(planted.len() as u32, next);
                if c.iter()
                    .any(|&l| planted[(l.abs() - 1) as usize] == (l > 0))
                {
                    return c;
                }
            }
        }
        let mut digests = Vec::new();

        // Random 3-SAT at the threshold, big enough to restart several
        // times; half under a tiny learnt budget so `reduce_db` runs at
        // most restarts.
        for inst in 0..4u32 {
            let n = 110;
            let mut s = Solver::new(n);
            for _ in 0..469 {
                s.add_clause(random_clause(n, &mut next));
            }
            if inst % 2 == 1 {
                s.max_learnts = 60;
            }
            let res = s.solve();
            digests.push(trace_digest(0, res, &s));
        }

        // Planted parity + CNF, widened by `add_vars` after the fact,
        // with a branching priority, then enumerated model by model.
        for _ in 0..3 {
            let n = 90u32;
            let mut planted: Vec<bool> = (0..n).map(|_| next() % 2 == 0).collect();
            let mut s = Solver::new(n);
            for _ in 0..30 {
                let vars: Vec<u32> = (1..=n).filter(|_| next() % 8 == 0).collect();
                let rhs = vars.iter().filter(|&&v| planted[(v - 1) as usize]).count() % 2 == 1;
                s.add_xor(&vars, rhs);
            }
            for _ in 0..300 {
                s.add_clause(planted_clause(&planted, &mut next));
            }
            for v in s.add_vars(8) {
                // v = a AND b as three clauses, and v ⊕ c as a row, all
                // satisfied by the planted assignment extended to v.
                let pick = |x: u64| 1 + (x % n as u64) as u32;
                let (a, b, c) = (pick(next()), pick(next()), pick(next()));
                let value = planted[(a - 1) as usize] && planted[(b - 1) as usize];
                planted.push(value);
                let (v, a, b) = (v as Lit, a as Lit, b as Lit);
                s.add_clause(vec![-v, a]);
                s.add_clause(vec![-v, b]);
                s.add_clause(vec![v, -a, -b]);
                s.add_xor(&[v as u32, c], value ^ planted[(c - 1) as usize]);
            }
            s.set_branch_priority(&(1..=30).collect::<Vec<u32>>());
            let mut h = 0;
            for _ in 0..5 {
                let res = s.solve();
                h = trace_digest(h, res, &s);
                if res != SolveResult::Sat {
                    break;
                }
                let m = s.model();
                let block: Vec<Lit> = (1..=30)
                    .map(|v: Lit| if m[(v - 1) as usize] { -v } else { v })
                    .collect();
                s.reset_search();
                if !s.add_clause(block) {
                    break;
                }
            }
            digests.push(h);
        }

        // Lazy theory clauses: an odd pattern on the trigger variables
        // is refuted by a clause whose side literal the planted
        // assignment satisfies; depending on the trail it arrives unit,
        // satisfied or already false, so both install paths run.
        for _ in 0..3 {
            let n = 60u32;
            let planted: Vec<bool> = (0..n).map(|_| next() % 2 == 0).collect();
            let mut s = Solver::new(n);
            for _ in 0..230 {
                s.add_clause(planted_clause(&planted, &mut next));
            }
            let side_var = 5 + (next() % 50) as usize;
            let side = if planted[side_var] {
                side_var as Lit + 1
            } else {
                -(side_var as Lit + 1)
            };
            let mut seen = HashSet::new();
            let mut theory = |a: &[Option<bool>]| {
                let bits: Vec<bool> = (0..4).map(|i| a[i].unwrap()).collect();
                if bits.iter().filter(|&&b| b).count() % 2 == 0 || !seen.insert(bits.clone()) {
                    return None;
                }
                let mut clause: Vec<Lit> = (1..=4)
                    .map(|v: Lit| if bits[(v - 1) as usize] { -v } else { v })
                    .collect();
                clause.push(side);
                Some(vec![clause])
            };
            let res = s.solve_with_lazy_clauses(&[1, 2, 3, 4], &mut theory);
            digests.push(trace_digest(0, res, &s));
        }

        // A conflict budget that runs out: the counters at the cut.
        {
            let n = 150;
            let mut s = Solver::new(n);
            for _ in 0..639 {
                s.add_clause(random_clause(n, &mut next));
            }
            s.conflict_budget = 700;
            let res = s.solve();
            digests.push(trace_digest(0, res, &s));
        }

        let want: [u64; 11] = [
            0xb2e0_4683_836a_bf61,
            0x67b3_5419_5935_88e6,
            0x3cc2_9eed_b852_d8cf,
            0xe09e_bb2c_f03b_80ee,
            0x8c81_db2b_bfca_bb47,
            0xa4b5_88b1_8057_a75c,
            0xadab_f077_7d3f_d049,
            0x1988_b235_e614_2f45,
            0x1c6e_5944_639b_6e22,
            0xd078_af6e_2f95_b4e1,
            0x0623_2f40_9d26_5579,
        ];
        assert_eq!(digests, want, "search trace moved: {digests:#018x?}");
    }

    #[test]
    fn arena_reclamation_relocates_reasons_and_preserves_incremental_exports() {
        fn fixture() -> Solver {
            let mut s = Solver::new(6);
            s.add_clause(vec![-1, 2, 5]);
            s.add_clause(vec![-1, 2, -5]);
            s.add_clause(vec![-2, 3]);
            s.add_clause(vec![1]);
            s.add_xor(&[3, 4], false);
            // Implied by the original root unit, deliberately large enough
            // to exercise both physical compaction and capacity shrinking.
            s.push_clause(&vec![1; 20_000]);
            let live = s.push_clause(&[2]);
            s.detached.resize(s.clause_at.len(), false);
            s.detached[s.n_orig_clauses] = true;
            s.enqueue(2, Reason::Propagated(live)).unwrap();
            s.reason[5] = Reason::Propagated(s.clause_at[s.n_orig_clauses]);
            assert!(s.propagate().is_none());
            s
        }
        let mut compact = fixture();
        let mut retained = fixture();
        let before = compact.arena.len();
        let capacity = compact.arena.capacity();
        let observed = Arc::new(std::sync::Mutex::new(Vec::new()));
        let sink = observed.clone();
        compact
            .set_event_observer(move |event| {
                sink.lock().unwrap().push(event.clone());
                Ok(())
            })
            .unwrap();
        let initial_ids = compact.clause_at.clone();
        for (i, cref) in compact.clause_at.iter().enumerate() {
            assert_eq!(compact.event_clause_id(*cref), initial_ids[i]);
        }
        compact.reclaim_clause_arena();
        compact.rebuild_clause_watches();
        assert!(compact.arena.len() < before / 4);
        assert!(compact.arena.capacity() < capacity);
        assert_eq!(compact.clause_at.len(), retained.clause_at.len());
        for (i, cref) in compact.clause_at.iter().enumerate() {
            assert_eq!(compact.event_clause_id(*cref), initial_ids[i]);
        }
        // The next observed name is the old end, not a newly reused offset.
        assert_eq!(compact.event_next_clause_id, before as u32);
        assert!(compact.clause_at.windows(2).all(|w| w[0] < w[1]));
        assert!(matches!(compact.reason[5], Reason::Decision));
        match compact.reason[1] {
            Reason::Propagated(c) => assert_eq!(clause_in(&compact.arena, c), &[2]),
            _ => panic!("live reason lost"),
        }
        for s in [&mut compact, &mut retained] {
            s.add_clause(vec![5, 6]);
        }
        fn exported_truth(s: &Solver) -> Vec<bool> {
            (0..64)
                .map(|bits| {
                    s.clause_at.iter().take(s.n_orig_clauses).all(|&c| {
                        clause_in(&s.arena, c)
                            .iter()
                            .any(|&l| ((bits >> var_of(l)) & 1 == 1) == (l > 0))
                    })
                })
                .collect()
        }
        assert!(observed.lock().unwrap().iter().any(|event| matches!(
            event, SolverEvent::Clause { clause_id, existing: false, .. }
                if *clause_id == before as u32
        )));
        assert_eq!(exported_truth(&compact), exported_truth(&retained));
        assert_eq!(compact.solve(), retained.solve());
        assert_eq!(compact.model(), retained.model());
        let mut replay = parse_dimacs(&to_dimacs(&compact)).unwrap();
        assert_eq!(replay.solve(), SolveResult::Sat);
        let mut replay_xor = parse_dimacs_xor(&to_dimacs_xor(&compact)).unwrap();
        assert_eq!(replay_xor.solve(), SolveResult::Sat);
        assert_eq!(compact.stats.arena_reclamations, 1);
        // A second pass is harmless, including tombstones now in originals.
        let after = compact.arena.clone();
        compact.reset_search();
        compact.reclaim_clause_arena();
        assert_eq!(compact.arena, after);
    }

    /// **The search trace is pinned across bitset word boundaries.**
    /// The flat parity matrix, the bit-read XOR reasons and the
    /// literal-indexed tables that `add_vars` re-centres are all laid out
    /// by 64-bit word, and the instances above never put a variable
    /// count next to a word boundary or widen one across it.  Here the
    /// count sits on each side of 64 and 128, parity rows exist before
    /// `add_vars` carries it past the next boundary, and every solve is
    /// enumerated through `reset_search`.  Recorded from the untuned
    /// solver, like the digests above.
    #[test]
    fn search_trace_is_pinned_across_word_boundaries() {
        let mut state = 0x243F_6A88_85A3_08D3u64;
        let mut next = move || {
            state ^= state >> 12;
            state ^= state << 25;
            state ^= state >> 27;
            state.wrapping_mul(0x2545_F491_4F6C_DD1D)
        };
        let mut digests = Vec::new();
        for (inst, n) in [63u32, 64, 65, 127, 128, 129].into_iter().enumerate() {
            let mut planted: Vec<bool> = (0..n).map(|_| next().is_multiple_of(2)).collect();
            let mut s = Solver::new(n);
            let parity = |vars: &[u32], planted: &[bool]| {
                vars.iter().filter(|&&v| planted[(v - 1) as usize]).count() % 2 == 1
            };
            for _ in 0..n / 4 {
                let vars: Vec<u32> = (1..=n).filter(|_| next().is_multiple_of(8)).collect();
                s.add_xor(&vars, parity(&vars, &planted));
            }
            // Past the next word boundary: each new variable is the parity
            // of two old ones, and the planted 3-clauses below range over
            // old and new variables alike.
            let extra = 64 - n % 64 + 3;
            for v in s.add_vars(extra) {
                let pick = |x: u64| 1 + (x % n as u64) as u32;
                let (a, b) = (pick(next()), pick(next()));
                planted.push(planted[(a - 1) as usize] ^ planted[(b - 1) as usize]);
                s.add_xor(&[v, a, b], false);
            }
            let total = n + extra;
            for _ in 0..3 * total / 2 {
                loop {
                    let c: Vec<Lit> = (0..3)
                        .map(|_| {
                            let v = 1 + (next() % total as u64) as Lit;
                            if next().is_multiple_of(2) {
                                v
                            } else {
                                -v
                            }
                        })
                        .collect();
                    if c.iter()
                        .any(|&l| planted[(l.abs() - 1) as usize] == (l > 0))
                    {
                        s.add_clause(c);
                        break;
                    }
                }
            }
            // A ceiling on the test's cost; none of these solves reaches it
            // (the largest takes under 3,000 conflicts).
            s.conflict_budget = 20_000;
            if inst % 2 == 1 {
                s.max_learnts = 40;
            } else {
                s.set_branch_priority(&(1..=n / 2).collect::<Vec<u32>>());
            }
            let mut h = 0;
            for _ in 0..4 {
                let res = s.solve();
                h = trace_digest(h, res, &s);
                if res != SolveResult::Sat {
                    break;
                }
                let m = s.model();
                let block: Vec<Lit> = (1..=24)
                    .map(|v: Lit| if m[(v - 1) as usize] { -v } else { v })
                    .collect();
                s.reset_search();
                if !s.add_clause(block) {
                    break;
                }
            }
            digests.push(h);
        }

        let want: [u64; 6] = [
            0x2f44_afb1_4835_6b36,
            0x789b_fbc1_a19c_dd9e,
            0x63c9_5cf5_cfc3_44c9,
            0xcad3_2ba2_aced_18ca,
            0x51b7_bb50_5809_12f2,
            0x0318_2ef1_4e1c_41f9,
        ];
        assert_eq!(digests, want, "search trace moved: {digests:#018x?}");
    }

    /// **Adding variables one at a time stays linear.**  The literal
    /// tables are re-centred only when `add_vars` outgrows their base,
    /// which at least doubles each time, so a caller that adds every
    /// auxiliary separately (`examples/koblitz_s5_sat_instance.rs` does)
    /// moves them a logarithmic number of times rather than once per
    /// call.  Counted rather than timed: a move is a fresh allocation
    /// of `values` and of `watches`.  Root facts, watch lists and a
    /// parity row all have to survive every move, and the grown solver
    /// must still answer correctly.
    #[test]
    fn add_vars_one_at_a_time_recentres_logarithmically() {
        let mut s = Solver::new(1000);
        assert!(s.add_clause(vec![1]));
        assert!(s.add_xor(&[2, 3], true));
        let (mut value_moves, mut watch_moves) = (0, 0);
        let (mut forced, mut chain) = (Vec::new(), vec![2]);
        for i in 0..30_000 {
            let (values, watches) = (s.values.as_ptr(), s.watches.as_ptr());
            let v = *s.add_vars(1).start() as Lit;
            value_moves += (s.values.as_ptr() != values) as u32;
            watch_moves += (s.watches.as_ptr() != watches) as u32;
            let prev = *chain.last().unwrap();
            if i % 2 == 0 {
                // `x1` is true at the root, so this is the unit `±v`,
                // assigned at once and carried by every later move.
                let lit = if i % 4 == 0 { v } else { -v };
                assert!(s.add_clause(vec![lit, -1]));
                forced.push(lit);
            } else {
                // Left free and made equivalent to the previous free
                // variable: two watched binary clauses per link.
                assert!(s.add_clause(vec![-v, prev]));
                assert!(s.add_clause(vec![v, -prev]));
                chain.push(v);
            }
        }
        // From a base of 1000, doubling reaches the 31000 variables in
        // five moves; a table centred on `n_vars` moved 30000 times.
        assert!(
            value_moves <= 5 && watch_moves <= 5,
            "{value_moves} and {watch_moves} moves"
        );
        assert!(s.lit_base >= s.n_vars && s.lit_base <= 2 * s.n_vars);

        // Pin the far end of the chain: propagation walks the watch lists
        // back to `x2`, and the parity row then fixes `x3`.
        assert!(s.add_clause(vec![-*chain.last().unwrap()]));
        assert_eq!(s.solve(), SolveResult::Sat);
        let m = s.model();
        assert_eq!(m.len(), 31_000);
        let holds = |l: Lit| m[var_of(l) as usize] == (l > 0);
        assert!(holds(1) && holds(3));
        assert!(forced.iter().all(|&l| holds(l)));
        assert!(chain.iter().all(|&v| holds(-v)));

        // From no variables at all, where there is no base to double.
        let mut z = Solver::new(0);
        for _ in 0..3 {
            z.add_vars(1);
        }
        assert!(z.add_clause(vec![-1, 3]) && z.add_clause(vec![1]));
        assert_eq!(z.solve(), SolveResult::Sat);
        assert!(z.model()[0] && z.model()[2]);
    }
}

/// CDCL SAT solver.

/// Partial native admission increment. Not sufficient for owned binary SAT:
/// observers, XOR, conflict analysis and incremental theories fail closed.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NativeAdmissionFailure {
    Work,
    Bytes,
    Deadline,
    Allocation,
    Overflow,
    UncoveredPath,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NativeOperation {
    Entry,
    Loop,
    WatchList,
    Watcher,
    Literal,
    WatchGrowth,
    Assignment,
    TrailGrowth,
    LevelGrowth,
    DetachedGrowth,
    Heap,
    Model,
    XorSetup,
    XorGrowth,
    XorPivot,
    XorScan,
    XorWord,
    XorReason,
    EventPayload,
    Analyze,
    AnalyzeGrowth,
    ClauseGrowth,
    Backjump,
    Reduction,
    Restart,
}

#[derive(Clone, Copy, Debug)]
pub struct NativeCharge {
    pub operation: NativeOperation,
    pub work: u64,
    pub requested_replacement_bytes: u64,
}

type NativeAdmission =
    Box<dyn FnMut(NativeCharge) -> Result<(), NativeAdmissionFailure> + Send + Sync>;

fn native_pay(
    hook: &mut Option<NativeAdmission>,
    failure: &mut Option<NativeAdmissionFailure>,
    deadline: Option<std::time::Instant>,
    operation: NativeOperation,
    work: u64,
    bytes: u64,
) -> bool {
    if failure.is_some() {
        return false;
    }
    if hook.is_none() {
        return true;
    }
    if deadline.is_some_and(|d| std::time::Instant::now() >= d) {
        *failure = Some(NativeAdmissionFailure::Deadline);
        return false;
    }
    if let Err(e) = hook.as_mut().unwrap()(NativeCharge {
        operation,
        work,
        requested_replacement_bytes: bytes,
    }) {
        *failure = Some(e);
        return false;
    }
    if deadline.is_some_and(|d| std::time::Instant::now() >= d) {
        *failure = Some(NativeAdmissionFailure::Deadline);
        return false;
    }
    true
}

fn native_reserve<T>(
    v: &mut Vec<T>,
    needed: usize,
    hook: &mut Option<NativeAdmission>,
    failure: &mut Option<NativeAdmissionFailure>,
    deadline: Option<std::time::Instant>,
    operation: NativeOperation,
) -> bool {
    if failure.is_some() {
        return false;
    }
    if hook.is_none() || needed <= v.capacity() {
        return true;
    }
    let Some(target) = v
        .capacity()
        .checked_mul(2)
        .and_then(|n| n.max(needed).checked_add(0))
    else {
        *failure = Some(NativeAdmissionFailure::Overflow);
        return false;
    };
    let Some(bytes) = target
        .checked_mul(std::mem::size_of::<T>())
        .and_then(|n| u64::try_from(n).ok())
    else {
        *failure = Some(NativeAdmissionFailure::Overflow);
        return false;
    };
    if !native_pay(hook, failure, deadline, operation, v.len() as u64, bytes) {
        return false;
    }
    if v.try_reserve_exact(target - v.len()).is_err() {
        *failure = Some(NativeAdmissionFailure::Allocation);
        return false;
    }
    if deadline.is_some_and(|d| std::time::Instant::now() >= d) {
        *failure = Some(NativeAdmissionFailure::Deadline);
        return false;
    }
    true
}

#[cfg(test)]
mod native_admission_increment_tests {
    use super::*;
    use std::sync::{Arc, Mutex};
    #[test]
    fn real_nonroot_cnf_search_preserves_legacy_answer_and_work() {
        fn fixture() -> Solver {
            let mut s = Solver::new(4);
            s.add_clause(vec![-1, 2]);
            s.add_clause(vec![-2, 3]);
            s
        }
        let mut legacy = fixture();
        let mut metered = fixture();
        let charges = Arc::new(Mutex::new(Vec::new()));
        let sink = Arc::clone(&charges);
        metered
            .set_search_admission(move |c| {
                sink.lock().unwrap().push(c);
                Ok(())
            })
            .unwrap();
        assert_eq!(legacy.solve(), SolveResult::Sat);
        assert_eq!(metered.solve(), SolveResult::Sat);
        assert!(metered.stats.decisions > 0);
        assert!(metered.stats.propagations > 0);
        let model = metered.admitted_model().unwrap();
        assert!(metered.check_original_assignment(&model));
        assert_eq!(model, legacy.model());
        assert_eq!(metered.word_ops(), legacy.word_ops());
        let calls = charges.lock().unwrap();
        assert!(calls.iter().any(|c| c.operation == NativeOperation::Heap));
        assert!(calls
            .iter()
            .any(|c| c.operation == NativeOperation::Watcher));
    }
    #[test]
    fn late_native_work_and_growth_refusal_are_sticky_unknown() {
        let mut s = Solver::new(3);
        let mut assignments = 0;
        s.set_search_admission(move |c| {
            if c.operation == NativeOperation::Assignment {
                assignments += 1;
                if assignments == 2 {
                    return Err(NativeAdmissionFailure::Work);
                }
            }
            Ok(())
        })
        .unwrap();
        assert_eq!(s.solve(), SolveResult::Unknown);
        assert!(s.trail.len() == 1);
        assert_eq!(
            s.search_admission_failure(),
            Some(NativeAdmissionFailure::Work)
        );
        let trail = s.trail.clone();
        assert_eq!(s.solve(), SolveResult::Unknown);
        assert_eq!(s.trail, trail);
        let mut allocation = Solver::new(2);
        allocation
            .set_search_admission(|c| {
                if c.operation == NativeOperation::LevelGrowth {
                    Err(NativeAdmissionFailure::Bytes)
                } else {
                    Ok(())
                }
            })
            .unwrap();
        assert_eq!(allocation.solve(), SolveResult::Unknown);
        assert!(allocation.trail_lim.is_empty());
        assert!(allocation.trail.is_empty());
        assert_eq!(
            allocation.search_admission_failure(),
            Some(NativeAdmissionFailure::Bytes)
        );
    }
    #[test]
    fn original_expired_deadline_precedes_root_propagation() {
        let mut s = Solver::new(2);
        s.add_clause(vec![1]);
        s.add_clause(vec![-1, 2]);
        s.set_search_admission(|_| Ok(())).unwrap();
        s.deadline = Some(std::time::Instant::now());
        let before = (s.qhead, s.trail.clone(), s.stats.propagations);
        assert_eq!(s.propagate_root(), RootPropagationResult::Unknown);
        assert_eq!((s.qhead, s.trail.clone(), s.stats.propagations), before);
        assert_eq!(s.solve(), SolveResult::Unknown);
    }
    #[test]
    fn uncovered_observer_xor_and_analysis_do_not_run_or_replace_observer() {
        let mut observed = Solver::new(2);
        let events = Arc::new(Mutex::new(Vec::new()));
        let sink = Arc::clone(&events);
        observed
            .set_event_observer(move |e| {
                sink.lock().unwrap().push(e.clone());
                Ok(())
            })
            .unwrap();
        let before = events.lock().unwrap().clone();
        observed.set_search_admission(|_| Ok(())).unwrap();
        assert_eq!(observed.solve(), SolveResult::Unknown);
        assert_eq!(*events.lock().unwrap(), before);
        assert!(observed.set_event_observer(|_| Ok(())).is_err());
        let mut xor = Solver::new(2);
        xor.add_xor(&[1, 2], true);
        xor.set_search_admission(|_| Ok(())).unwrap();
        assert_eq!(xor.solve(), SolveResult::Unknown);
        assert_eq!(xor.stats.xor_passes, 0);
        let mut conflict = Solver::new(2);
        for c in [vec![1, 2], vec![-1, 2], vec![1, -2], vec![-1, -2]] {
            conflict.add_clause(c);
        }
        conflict.set_search_admission(|_| Ok(())).unwrap();
        assert_eq!(conflict.solve(), SolveResult::Unknown);
        assert_eq!(
            conflict.search_admission_failure(),
            Some(NativeAdmissionFailure::UncoveredPath)
        );
        assert_eq!(conflict.stats.learnt_clauses, 0);
    }
    #[test]
    fn native_root_unsat_remains_distinct_from_refusal() {
        let mut s = Solver::new(1);
        s.add_clause(vec![1]);
        s.add_clause(vec![-1]);
        s.set_search_admission(|_| Ok(())).unwrap();
        assert_eq!(s.solve(), SolveResult::Unsat);
        assert_eq!(s.search_admission_failure(), None);
        let mut legacy = Solver::new(1);
        legacy.add_clause(vec![1]);
        assert_eq!(legacy.solve(), SolveResult::Sat);
    }
}

#[cfg(test)]
mod native_xor_admission_increment_tests {
    use super::*;
    #[test]
    fn actual_xor_rebuild_word_refusal_preserves_owned_matrix_and_sticky_failure() {
        let mut s = Solver::new(3);
        s.add_xor(&[1, 2], true);
        s.add_xor(&[2, 3], false);
        let mut word_calls = 0;
        s.set_search_admission(move |c| {
            if c.operation == NativeOperation::XorWord {
                word_calls += 1;
                if word_calls == 2 {
                    return Err(NativeAdmissionFailure::Work);
                }
            }
            Ok(())
        })
        .unwrap();
        assert!(matches!(s.propagate_xors(), XorStep::Refused));
        assert_eq!(
            s.search_admission_failure(),
            Some(NativeAdmissionFailure::Work)
        );
        assert_eq!(s.matrix, vec![0b011u64]);
        assert_eq!(s.matrix_rhs, vec![true]);
        assert!(s.pivot.is_empty());
        assert_eq!(s.solve(), SolveResult::Unknown);
    }
    #[test]
    fn actual_xor_growth_refusal_precedes_clear_and_copy() {
        let mut s = Solver::new(2);
        s.add_xor(&[1, 2], true);
        s.set_search_admission(|c| {
            if c.operation == NativeOperation::XorGrowth {
                Err(NativeAdmissionFailure::Bytes)
            } else {
                Ok(())
            }
        })
        .unwrap();
        assert!(matches!(s.propagate_xors(), XorStep::Refused));
        assert!(s.matrix.is_empty() && s.matrix_rhs.is_empty() && s.pivot.is_empty());
        assert_eq!(
            s.search_admission_failure(),
            Some(NativeAdmissionFailure::Bytes)
        );
    }
}

#[cfg(test)]
mod native_event_admission_increment_tests {
    use super::*;
    use std::sync::{Arc, Mutex};
    #[test]
    fn existing_observer_is_retained_and_late_reason_copy_refusal_does_not_publish() {
        let mut s = Solver::new(2);
        let events = Arc::new(Mutex::new(Vec::new()));
        let sink = Arc::clone(&events);
        s.set_event_observer(move |e| {
            sink.lock().unwrap().push(e.clone());
            Ok(())
        })
        .unwrap();
        let original = events.lock().unwrap().clone();
        s.set_search_admission(|c| {
            if c.operation == NativeOperation::EventPayload {
                Err(NativeAdmissionFailure::Bytes)
            } else {
                Ok(())
            }
        })
        .unwrap();
        s.assign(1, Reason::Decision);
        assert_eq!(s.trail, vec![1]);
        assert_eq!(*events.lock().unwrap(), original);
        assert_eq!(
            s.search_admission_failure(),
            Some(NativeAdmissionFailure::Bytes)
        );
        assert_eq!(s.solve(), SolveResult::Unknown);
    }
}

#[cfg(test)]
mod native_analysis_admission_increment_tests {
    use super::*;
    fn installed() -> Solver {
        let mut s = Solver::new(2);
        s.add_clause(vec![-1, 2]);
        s.add_clause(vec![-1, -2]);
        s
    }
    fn conflict(s: &mut Solver) -> Conflict {
        assert!(native_reserve(
            &mut s.trail_lim,
            1,
            &mut s.native_admission,
            &mut s.native_failure,
            s.deadline,
            NativeOperation::LevelGrowth
        ));
        s.trail_lim.push(0);
        s.assign(1, Reason::Decision);
        s.propagate().expect("actual watched propagation conflict")
    }
    #[test]
    fn actual_native_analysis_and_backjump_are_charged_before_use() {
        let mut s = installed();
        s.set_search_admission(|_| Ok(())).unwrap();
        let c = conflict(&mut s);
        let (learnt, level) = s.analyze(c);
        assert_eq!(learnt, vec![-1]);
        assert_eq!(level, 0);
        assert_eq!(s.search_admission_failure(), None);
        s.backjump(level);
        assert!(s.trail.is_empty());
        let cref = s.push_clause(&learnt);
        assert_eq!(clause_in(&s.arena, cref), &[-1]);
    }
    #[test]
    fn actual_analysis_growth_refusal_retains_conflicting_native_state() {
        let mut s = installed();
        s.set_search_admission(|c| {
            if c.operation == NativeOperation::AnalyzeGrowth {
                Err(NativeAdmissionFailure::Bytes)
            } else {
                Ok(())
            }
        })
        .unwrap();
        let c = conflict(&mut s);
        let before = s.trail.clone();
        let (learnt, _) = s.analyze(c);
        assert!(learnt.is_empty());
        assert_eq!(s.trail, before);
        assert_eq!(
            s.search_admission_failure(),
            Some(NativeAdmissionFailure::Bytes)
        );
        assert_eq!(s.solve(), SolveResult::Unknown);
    }
}

#[cfg(test)]
mod native_batch_admission_increment_tests {
    use super::*;
    #[test]
    fn charged_stable_clause_sort_matches_legacy_ties_and_retains_scratch_on_refusal() {
        let mut s = Solver::new(4);
        s.add_clause(vec![1, 2]);
        s.add_clause(vec![1, 2, 3]);
        s.add_clause(vec![-1, 2]);
        let mut expected = vec![0, 1, 2];
        expected.sort_by_key(|&i| std::cmp::Reverse(clause_in(&s.arena, s.clause_at[i]).len()));
        s.set_search_admission(|_| Ok(())).unwrap();
        let mut actual = vec![0, 1, 2];
        assert!(s.native_clause_sort(&mut actual));
        assert_eq!(actual, expected);
        let mut t = Solver::new(3);
        t.add_clause(vec![1, 2]);
        t.add_clause(vec![1, 2, 3]);
        let mut steps = 0;
        t.set_search_admission(move |c| {
            if c.operation == NativeOperation::Reduction {
                steps += 1;
                if steps == 4 {
                    return Err(NativeAdmissionFailure::Work);
                }
            }
            Ok(())
        })
        .unwrap();
        let mut partial = vec![0, 1];
        assert!(!t.native_clause_sort(&mut partial));
        assert!(!t.native_sort_scratch.is_empty());
        assert_eq!(t.solve(), SolveResult::Unknown);
    }
}

#[cfg(test)]
mod native_deadline_retention_increment_tests {
    use super::*;
    #[test]
    fn model_copy_refusal_retains_actual_partial_assignment_buffer() {
        let mut s = Solver::new(130);
        let mut copies = 0;
        s.set_search_admission(move |c| {
            if c.operation == NativeOperation::Model {
                copies += 1;
                if copies == 4 {
                    return Err(NativeAdmissionFailure::Work);
                }
            }
            Ok(())
        })
        .unwrap();
        assert_eq!(s.solve(), SolveResult::Sat);
        assert!(s.admitted_model().is_none());
        assert!(s
            .native_pending_model
            .as_ref()
            .is_some_and(|v| v.len() == 64));
        assert_eq!(s.solve(), SolveResult::Unknown);
    }
}

#[cfg(test)]
mod native_analysis_boundary_retention_tests {
    use super::*;
    fn fixture(stop: usize) -> (Solver, Conflict) {
        let mut s = Solver::new(3);
        s.add_clause(vec![-1, -2, 3]);
        s.add_clause(vec![-1, -2, -3]);
        let mut zero_steps = 0;
        s.set_search_admission(move |c| {
            if c.operation == NativeOperation::Analyze && c.work == 0 {
                zero_steps += 1;
                if zero_steps == stop {
                    return Err(NativeAdmissionFailure::Work);
                }
            }
            Ok(())
        })
        .unwrap();
        s.trail_lim.push(0);
        s.assign(1, Reason::Decision);
        assert!(s.propagate().is_none());
        s.trail_lim.push(s.trail.len());
        s.assign(2, Reason::Decision);
        let conflict = s.propagate().expect("real second-level watched conflict");
        (s, conflict)
    }
    #[test]
    fn actual_analysis_partial_clause_survives_search_boundary() {
        // Find the actual output-copy refusal among finitely many zero-work
        // deadline checkpoints; no synthetic pending clause is installed.
        let mut witnessed = false;
        for stop in 1..=64 {
            let (mut direct, c) = fixture(stop);
            let output = direct.analyze(c);
            if direct
                .native_pending_clause
                .as_ref()
                .is_some_and(|v| !v.is_empty())
            {
                assert!(output.0.is_empty());
                let expected = direct.native_pending_clause.clone();
                let (mut boundary, c) = fixture(stop);
                assert!(boundary.analyze_for_search(c).is_none());
                assert_eq!(boundary.native_pending_clause, expected);
                assert_eq!(
                    boundary.search_admission_failure(),
                    Some(NativeAdmissionFailure::Work)
                );
                assert_eq!(boundary.solve(), SolveResult::Unknown);
                assert_eq!(boundary.native_pending_clause, expected);
                witnessed = true;
                break;
            }
        }
        assert!(
            witnessed,
            "actual analysis must reach retained nonempty output before refusal"
        );
    }
}

#[cfg(test)]
mod native_observer_boundary_increment_tests {
    use super::*;
    #[test]
    fn observer_backjump_refusal_keeps_actual_trail_and_levels() {
        let mut s = Solver::new(3);
        s.set_event_observer(|event| {
            if matches!(event, SolverEvent::Backjump { .. }) {
                Err("stop at backjump".into())
            } else {
                Ok(())
            }
        })
        .unwrap();
        s.set_search_admission(|_| Ok(())).unwrap();
        s.trail_lim.push(0);
        s.assign(1, Reason::Decision);
        let before = (
            s.trail.clone(),
            s.trail_lim.clone(),
            s.values.clone(),
            s.assigned_w.clone(),
        );
        s.backjump(0);
        assert_eq!(
            (
                s.trail.clone(),
                s.trail_lim.clone(),
                s.values.clone(),
                s.assigned_w.clone()
            ),
            before
        );
        assert_eq!(s.event_failure.as_deref(), Some("stop at backjump"));
        assert_eq!(s.solve(), SolveResult::Unknown);
        assert_eq!(s.trail, before.0);
    }
    #[test]
    fn detached_fill_charges_reused_capacity_and_retains_prefix() {
        let mut s = Solver::new(1);
        s.detached.reserve(192);
        let mut fills = 0;
        s.set_search_admission(move |c| {
            if c.operation == NativeOperation::DetachedGrowth {
                fills += 1;
                if fills == 2 {
                    return Err(NativeAdmissionFailure::Work);
                }
            }
            Ok(())
        })
        .unwrap();
        assert!(!s.native_fill_detached(150));
        assert_eq!(s.detached, vec![false; 64]);
        assert_eq!(
            s.search_admission_failure(),
            Some(NativeAdmissionFailure::Work)
        );
        assert!(!s.native_fill_detached(150));
        assert_eq!(s.detached.len(), 64);
    }
    #[test]
    fn heap_refusal_precedes_next_actual_pop() {
        let mut s = Solver::new(3);
        s.assign(1, Reason::Decision);
        s.assign(2, Reason::Decision);
        s.assign(3, Reason::Decision);
        let mut pops = 0;
        s.set_search_admission(move |c| {
            if c.operation == NativeOperation::Heap && c.work == 0 {
                pops += 1;
                if pops == 2 {
                    return Err(NativeAdmissionFailure::Work);
                }
            }
            Ok(())
        })
        .unwrap();
        let before = s.order.heap.len();
        assert_eq!(s.pick_branching_variable(), None);
        assert_eq!(s.order.heap.len(), before - 1);
        assert_eq!(
            s.search_admission_failure(),
            Some(NativeAdmissionFailure::Work)
        );
    }
}

#[cfg(test)]
mod native_pending_watch_increment_tests {
    use super::*;
    #[test]
    fn watcher_refusal_retains_actual_vector_and_two_cursors() {
        let mut s = Solver::new(4);
        for v in 2..=4 {
            s.add_clause(vec![-1, v]);
        }
        s.assign(1, Reason::Decision);
        let mut scans = 0;
        s.set_search_admission(move |c| {
            if c.operation == NativeOperation::Watcher {
                scans += 1;
                if scans == 2 {
                    return Err(NativeAdmissionFailure::Work);
                }
            }
            Ok(())
        })
        .unwrap();
        assert!(s.propagate_clauses().is_none());
        let (slot, ws, read, written) = s.native_pending_watch.as_ref().unwrap();
        assert_eq!(*slot, s.watch_slot(-1));
        assert_eq!(ws.len(), 3);
        assert_eq!((*read, *written), (1, 1));
        assert!(s.watches[*slot].is_empty());
        assert_eq!(s.trail, vec![1, 2]);
        assert_eq!(s.solve(), SolveResult::Unknown);
        assert_eq!(s.native_pending_watch.as_ref().unwrap().1.len(), 3);
    }
    #[test]
    fn xor_observer_refusal_retains_reason_before_assignment() {
        let mut s = Solver::new(2);
        s.add_xor(&[1, 2], true);
        s.add_clause(vec![1]);
        s.set_event_observer(|e| {
            if matches!(e, SolverEvent::XorImplication { .. }) {
                Err("stop XOR implication".into())
            } else {
                Ok(())
            }
        })
        .unwrap();
        s.set_search_admission(|_| Ok(())).unwrap();
        let before = s.trail.clone();
        assert!(matches!(s.propagate_xors(), XorStep::Refused));
        assert_eq!(s.trail, before);
        assert!(s.var_value(1).is_none());
        assert!(!s.xor_reason[1].is_empty());
        assert_eq!(s.event_failure.as_deref(), Some("stop XOR implication"));
    }
}

#[cfg(test)]
mod native_bulk_boundary_increment_tests {
    use super::*;
    #[test]
    fn pivot_fill_refusal_keeps_actual_matrix_and_initialized_prefix() {
        let mut s = Solver::new(2);
        for _ in 0..130 {
            s.add_xor(&[1, 2], true);
        }
        assert_eq!(s.xors.len(), 130);
        let mut fills = 0;
        s.set_search_admission(move |c| {
            if c.operation == NativeOperation::XorPivot {
                fills += 1;
                if fills == 2 {
                    return Err(NativeAdmissionFailure::Work);
                }
            }
            Ok(())
        })
        .unwrap();
        s.rebuild_matrix();
        assert_eq!(s.matrix.len(), 130);
        assert_eq!(s.matrix_rhs.len(), 130);
        assert_eq!(s.pivot, vec![None; 64]);
        assert_eq!(
            s.search_admission_failure(),
            Some(NativeAdmissionFailure::Work)
        );
        s.rebuild_matrix();
        assert_eq!(s.pivot.len(), 64);
    }
    #[test]
    fn xor_row_observer_refusal_keeps_only_first_actual_row_operation() {
        let mut s = Solver::new(3);
        s.add_xor(&[1, 2], true);
        s.add_xor(&[1, 3], false);
        s.add_xor(&[1, 2, 3], true);
        s.set_event_observer(|e| {
            if matches!(e, SolverEvent::XorRowXor { .. }) {
                Err("stop first XOR row".into())
            } else {
                Ok(())
            }
        })
        .unwrap();
        s.set_search_admission(|_| Ok(())).unwrap();
        assert!(matches!(s.propagate_xors(), XorStep::Refused));
        assert_eq!(s.matrix, vec![0b011, 0b110, 0b111]);
        assert_eq!(s.matrix_rhs, vec![true, true, true]);
        assert_eq!(s.native_partial_xor, Some((0, 1, 1, true)));
        assert_eq!(s.event_failure.as_deref(), Some("stop first XOR row"));
        assert_eq!(s.stats.xor_row_ops, 1);
    }
}

#[cfg(test)]
mod native_minimize_deletion_increment_tests {
    use super::*;
    #[test]
    fn decision_only_minimization_refusal_retains_both_actual_buffers() {
        let mut s = Solver::new(3);
        s.redundant_stack = vec![-3];
        let mut visits = 0;
        s.set_search_admission(move |c| {
            if c.operation == NativeOperation::Analyze && c.work == 4 {
                visits += 1;
                if visits == 2 {
                    return Err(NativeAdmissionFailure::Work);
                }
            }
            Ok(())
        })
        .unwrap();
        assert!(s.minimize_for_search(vec![1, 2, 3], 0).is_none());
        assert_eq!(s.learnt_buf, vec![1, 2, 3]);
        assert_eq!(s.redundant_stack, vec![-3]);
        assert_eq!(
            s.search_admission_failure(),
            Some(NativeAdmissionFailure::Work)
        );
        assert_eq!(s.solve(), SolveResult::Unknown);
        assert_eq!(s.learnt_buf, vec![1, 2, 3]);
    }
    #[test]
    fn decision_only_minimization_retains_legacy_output_when_admitted() {
        let mut legacy = Solver::new(3);
        let mut metered = Solver::new(3);
        metered.set_search_admission(|_| Ok(())).unwrap();
        assert_eq!(
            legacy.minimize_for_search(vec![1, -2, 3], 0),
            Some(vec![1, -2, 3])
        );
        assert_eq!(
            metered.minimize_for_search(vec![1, -2, 3], 0),
            Some(vec![1, -2, 3])
        );
        assert_eq!(legacy.word_ops(), metered.word_ops());
    }
    #[test]
    fn unobserved_deletion_refusal_precedes_second_actual_flag_mutation() {
        let mut s = Solver::new(4);
        for c in [
            vec![1, 2, 3],
            vec![-1, 2, 4],
            vec![1, -3, 4],
            vec![2, 3, -4],
        ] {
            s.push_clause(&c);
        }
        s.n_orig_clauses = 0;
        let mut deletions = 0;
        s.set_search_admission(move |c| {
            if c.operation == NativeOperation::Reduction && c.work == 2 {
                deletions += 1;
                if deletions == 2 {
                    return Err(NativeAdmissionFailure::Work);
                }
            }
            Ok(())
        })
        .unwrap();
        assert!(s.event_observer.is_none());
        s.reduce_db();
        assert_eq!(s.detached, vec![true, false, false, false]);
        let (locked, candidates) = s.native_pending_reduction.as_ref().unwrap();
        assert_eq!(locked, &vec![false; 4]);
        assert_eq!(candidates, &vec![0, 1, 2, 3]);
        let inventory = s.storage_inventory();
        let components = &inventory["components_capacity_bytes"];
        assert_eq!(
            components["native_pending_reduction_locked"],
            locked.capacity() as u64 * std::mem::size_of::<bool>() as u64
        );
        assert_eq!(
            components["native_pending_reduction_candidates"],
            candidates.capacity() as u64 * std::mem::size_of::<usize>() as u64
        );
        assert_eq!(
            components["native_sort_scratch"],
            s.native_sort_scratch.capacity() as u64 * std::mem::size_of::<usize>() as u64
        );
        assert!(
            inventory["owned_capacity_bytes"].as_u64().unwrap()
                >= (locked.capacity() * std::mem::size_of::<bool>()
                    + candidates.capacity() * std::mem::size_of::<usize>()
                    + s.native_sort_scratch.capacity() * std::mem::size_of::<usize>())
                    as u64
        );
        assert_eq!(
            s.search_admission_failure(),
            Some(NativeAdmissionFailure::Work)
        );
        assert_eq!(s.solve(), SolveResult::Unknown);
        assert_eq!(s.detached, vec![true, false, false, false]);
    }
}
