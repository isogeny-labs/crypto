from pathlib import Path
import json,hashlib,datetime,subprocess
s=Path('research/relation_fusion_20261117');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
paths=[str(p) for p in Path('crates/certified-relations/src').rglob('*.rs')]+[str(s/'src/bin/packed-qualify.rs')]
pins=json.loads((s/'PROFILE_PINS_169.json').read_text());matrix=json.loads(Path('/workspace/packed-constructor-196/matrix.json').read_text())
for row in matrix['cases']:
 source=next(x for x in pins['files'] if x['path'].endswith(f"p{row['prime']}-n{row['n']}-frontier/original.json"))
 assert row['input_sha256']==source['sha256']
assert len(matrix['cases'])==36
for l in Path('/workspace/kernel-items-192.jsonl').read_text().splitlines():
 x=json.loads(l);old=subprocess.check_output(['git','show','d5f25f53dc:'+x['path']],text=True).splitlines(keepends=True);now=Path(x['path']).read_text()
 for i in x['items']:
  if 'cfg (test)' in i['key']:
   test=''.join(old[i['start'][0]-1:i['end'][0]])
   assert test in now,(x['path'],i['key'])
logs=[str(p) for p in s.glob('development-01/packed-*') if p.suffix in ['.stdout','.stderr']]
v={'schema':'packed-constructor-qualification/v1','producer_release_tests':{'passed':68,'failed':0,'ignored':0},'separate_checker_release_tests':{'passed':14,'failed':0,'ignored':0},'fixed_cases':36,'complete_proof_byte_and_metadata_equality':True,'independent_full_replays':72,'mutation_rejections':126,'all_six_inputs_match_published_169_hashes':True,'legacy_test_modules_byte_preserved':True,'actual_root_packed_backend_qualified':False,'timing_claim':False,'source_sha256':{p:sha(p) for p in sorted(paths)},'logs':{p:sha(p) for p in logs},'matrix_sha256':sha('/workspace/packed-constructor-196/matrix.json')}
(s/'PACKED_QUALIFICATION_197.json').write_text(json.dumps(v,indent=2)+'\n')
with Path('docs/session-logs/2026-11-17.md').open('a') as f:f.write(f'''\n## {datetime.datetime.now(datetime.timezone.utc).isoformat()} — Packed correctness195/196/197\n\n### What was done (commands, files, features)\nPacked release suite195passes68including3new arithmetic/range tests; unchanged separate checker197passes14. Full fixed36case qualification196passes with exact old/new complete proof bytes and metadata,72complete independent proof replays and126 mutation rejections. Allsix input hashes match published169. Alloriginal legacy test modules are byte-preserved after extraction. PACKED_QUALIFICATION_197.json pins sources/logs. [pcc:unverified]\n\n### Decisions made (and why)\nAdvance the now implemented packed constructor to actual-root integration through explicit additional forms; keep both original forms and every native proof/basis/receipt check. Actualroot matrix must cover both old and new backends, no weaker control. Qualification196is not timing; original15x remains active.\n\n### Open threads (unfinished, pick up next time)\nActual-root packed backend qualification and saved-artifact separate audit/archive. Then build worker including candidate, publish finite prospective matched full-boundary measurement before collecting times.\n\n### Errors (what went wrong, how it was handled)\nInitial193compiler typo retained. No new matrix/test failures or exclusions. Full ordinary root7561runtime gate stillincomplete185; no assertions disabled or global recovery claim.\n''')
