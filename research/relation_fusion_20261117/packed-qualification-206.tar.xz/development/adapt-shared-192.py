from pathlib import Path
b=Path('crates/certified-relations/src/kernels')
for name in ['cheap','projection','quotient','compact','arithmetic']:
 p=b/f'{name}.rs';s=p.read_text()
 # Only expressions known to be monomials; depths/coefficient vectors stay Vec.
 s=s.replace('vec![0; self.n]', 'Mono::zero(self.n)')
 s=s.replace('vec![0; am.len()]', 'Mono::zero(am.len())')
 s=s.replace('vec![0; n]', 'Mono::zero(n)')
 s=s.replace('let mut depths = Mono::zero(n);','let mut depths = vec![0; n];')
 replacements={
 'result[indices[0]] = x;':'result.set_exp(indices[0], x);',
 'result[indices[1]] = y;':'result.set_exp(indices[1], y);',
 'm[y] = k;':'m.set_exp(y, k);', 'x[y] = 0;':'x.set_exp(y, 0);',
 'exponent[y] = 0;':'exponent.set_exp(y, 0);','ym[y] = 1;':'ym.set_exp(y, 1);',
 'm.swap(a, b);':'m.swap_exp(a, b);',
 'm[axis] = am[axis] - bm[axis];':'m.set_exp(axis, am[axis] - bm[axis]);',
 'm[i] = 1;':'m.set_exp(i, 1);','shift_by[i] -= 1;':'shift_by.set_exp(i, shift_by[i] - 1);',
 'shift_by[t] -= d;':'shift_by.set_exp(t, shift_by[t] - d);','m[y] = 0;':'m.set_exp(y, 0);',
 'm[t] = i;':'m.set_exp(t, i);',
 'child[i] = child[i].checked_add(1).expect("bounded frontier exponent");':'child.set_exp(i, child[i].checked_add(1).expect("bounded frontier exponent"));',
 'fn mono_degree(m: &[usize])':'fn mono_degree(m: &Mono)',
 }
 for a,v in replacements.items():s=s.replace(a,v)
 p.write_text(s)
p=b/'arithmetic.rs';s=p.read_text();a=s.index('pub fn degree(');z=s.index('fn lead(',a)
s=s[:a]+'''pub fn degree(f: &Poly) -> usize {
    f.keys().map(Mono::total_degree).max().unwrap_or(0)
}
fn cmp(a: &Mono, b: &Mono) -> Ordering { a.grevlex_cmp(b) }
'''+s[z:]
s=s.replace('m.iter().sum::<usize>(), m','m.total_degree(), m')
s=s.replace('b.1.iter().rev().cmp(a.1.iter().rev())','b.1.reverse_lex_cmp(a.1)')
a=s.index('fn plus(');z=s.index('fn axpy<',a)
s=s[:a]+'''fn plus(a: &Mono, b: &Mono) -> Mono { a.add_exp(b) }
fn divides(a: &Mono, b: &Mono) -> bool { a.divides_exp(b) }
fn difference(a: &Mono, b: &Mono) -> Mono { a.sub_exp(b) }
'''+s[z:];p.write_text(s)
p=b/'projection.rs';s=p.read_text()
s=s.replace('pub(super) fn product(a: &Poly, b: &Poly, p: u64) -> Poly {','''pub(super) fn product(a: &Poly, b: &Poly, p: u64) -> Poly {
    if Mono::PACKED {
        let mut out = Poly::new();
        for (m, c) in a { for (e, d) in b { axpy_owned(&mut out, plus(m,e), *d, *c, p); } }
        return out;
    }''')
s=s.replace('pub(super) fn times(row: &Row, f: &Poly, p: u64) -> Row {','''pub(super) fn times(row: &Row, f: &Poly, p: u64) -> Row {
    if Mono::PACKED {
        let mut out = Row {poly: Poly::new(), proof: Proof::new()};
        for (m,c) in f {
            for (e,d) in &row.poly {axpy_owned(&mut out.poly,plus(m,e),*d,*c,p);}
            for ((i,e),d) in &row.proof {axpy_owned(&mut out.proof,(*i,plus(m,e)),*d,*c,p);}
        }
        return out;
    }''')
p.write_text(s)
