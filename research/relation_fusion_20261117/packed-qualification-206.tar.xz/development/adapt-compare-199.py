from pathlib import Path
base=Path('research/relation_fusion_20261117/src/bin')
s=(base/'root-dag-compare.rs').read_text()
pos=s.index('fn main()')
s=s[:pos]+'''// Declared immutable roster. 12 controls; 6 candidates. AA duplicates every control.
#[derive(Clone)]
struct Arm {name:String,kind:&'static str,kernel:&'static str,worker:usize}
fn controls()->Vec<Arm> {
    let mut out=Vec::new();
    for (prefix,worker,forms) in [
        ("frozen85",0,vec![("sparse","compact-sparse")]),
        ("frozen96",1,vec![("dag","compact-dag")]),
        ("current",2,vec![("sparse","compact-sparse"),("dag","compact-dag")]),
    ] {
        for (form,kind) in forms {for (k,kernel) in [("103","frontier"),("231","packed-products"),("487","packed-batch")] {
            out.push(Arm{name:format!("{prefix}-{form}-{k}"),kind,kernel,worker});
        }}
    }
    out
}
fn roster(stage:&str)->Vec<Arm>{
    let mut out=Vec::new();
    if stage=="AA" {
        for arm in controls(){let mut copy=arm.clone();copy.name+="-copy";out.push(arm);out.push(copy);}
    } else {
        out=controls();
        for (form,kind) in [("sparse","packed-constructor-sparse"),("dag","packed-constructor-dag")] {
            for (k,kernel) in [("103","frontier"),("231","packed-products"),("487","packed-batch")] {
                out.push(Arm{name:format!("packed-{form}-{k}"),kind,kernel,worker:2});
            }
        }
    }
    out
}
'''+s[pos:]
a=s.index('    if args.len() != 5');b=s.index('    let global =',a)
s=s[:a]+'''    if args.len()!=6{return Err("usage:packed-compare NEW_OUT FROZEN85 FROZEN96 CURRENT_WORKER CORPUS66".into());}
    let out=Path::new(&args[1]);fs::create_dir(out)?;
    let drivers=[Path::new(&args[2]),Path::new(&args[3]),Path::new(&args[4])];
    let hashes=drivers.iter().map(|p|hash(p)).collect::<Result<Vec<_>>>()?;
    let corpus=Path::new(&args[5]);
    save(&out.join("workers-before.json"),&serde_json::to_vec_pretty(&hashes)?)?;
'''+s[b:]
a=s.index('                    let modes:');b=s.index('                        let checker =',a)
s=s[:a]+'''                    let modes=roster(stage);
                    for index in 0..modes.len() {
                        let mode=&modes[(index+round)%modes.len()];
                        let arm=mode.name.as_str();let kind=mode.kind;let kernel=mode.kernel;
                        let driver=drivers[mode.worker];let driver_hash=&hashes[mode.worker];
'''+s[b:]
a=s.index('                                .arg(if kind ==');b=s.index('                                .args([kind',a)
s=s[:a]+'''                                .arg(driver)
'''+s[b:]
s=s.replace('if kind=="compact-sparse"{&control_hash}else{&driver_hash}','driver_hash')
s=s.replace('if kind == "compact-dag" {','if kind.ends_with("-dag") {')
a=s.index('    let control_after =');b=s.index('    let all =',a)
s=s[:a]+'''    let after=drivers.iter().map(|p|hash(p)).collect::<Result<Vec<_>>>()?;
    save(&out.join("workers-after.json"),&serde_json::to_vec_pretty(&after)?)?;
    if after!=hashes || outcomes.len()!=1260{return Err("worker pin/roster".into());}
'''+s[b:]
s=s.replace('fusion-root-dag-compare/v1','fusion-packed-constructor-compare/v1').replace('"planned":210','"planned":1260')
(base/'packed-compare.rs').write_text(s)
