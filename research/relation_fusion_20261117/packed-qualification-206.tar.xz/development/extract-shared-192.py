from pathlib import Path
import json
base=Path('crates/certified-relations/src'); (base/'kernels').mkdir(exist_ok=True)
for line in Path('/workspace/kernel-items-192.jsonl').read_text().splitlines():
 x=json.loads(line); path=Path(x['path']); text=path.read_text(); lines=text.splitlines(keepends=True)
 tests=[i for i in x['items'] if 'cfg (test)' in i['key']]
 prod=[]; legacy=[]; testlines=set()
 for i in tests:
  a,b=i['start'][0]-1,i['end'][0]; legacy.extend(lines[a:b]); legacy.append('\n');testlines.update(range(a,b))
 for n,l in enumerate(lines):
  if n not in testlines and not l.startswith('//!') and not (path.name=='quotient.rs' and l=='pub mod compact;\n'):
   prod.append(l)
 name='compact' if path.parent.name=='quotient' else path.stem
 (base/'kernels'/f'{name}.rs').write_text(''.join(prod))
 docs=''.join(l for l in lines if l.startswith('//!'))
 inc='../kernels/compact.rs' if name=='compact' else f'kernels/{name}.rs'
 wrapper=docs+('pub mod compact;\n' if name=='quotient' else '')+f'include!("{inc}");\n\n'+''.join(legacy)
 path.write_text(wrapper)
p=base/'lib.rs'; text=p.read_text()
a=text.index('pub fn degree('); b=text.index('/// A separate textbook Buchberger path',a)
core=text[a:b];text=text[:a]+'include!("kernels/arithmetic.rs");\n'+text[b:]
a=text.index('pub fn check_reference('); b=text.index('pub fn check_reference_legacy(',a)
core+='\n'+text[a:b];text=text[:a]+'include!("kernels/check.rs");\n\n'+text[b:]
# Keep the independently includable checking portion separate.
a=core.index('pub fn check_reference(')
(base/'kernels/arithmetic.rs').write_text(core[:a]);(base/'kernels/check.rs').write_text(core[a:])
text=text.replace('pub mod cheap;','mod monomial;\nuse monomial::MonomialOps;\npub mod packed_constructor;\npub mod cheap;')
p.write_text(text)
