#set page(paper: "a4", margin: 1.5cm)
#set text(size: 9pt)
#show raw: set text(size: 8pt)
#set table(stroke: 0.4pt + luma(180), inset: 3.5pt)
#show table: set text(size: 7.5pt)

= cpu profile: compact-frontier-p53-n6

- status: *ok*
- command: #raw("/workspace/relation-native-qualifiers/fusion-85/fused-native compact-sparse packed frontier /workspace/fusion-profile-proof-86")
- binary: #raw("/workspace/relation-native-qualifiers/fusion-85/fused-native") sha256 #raw("6b689556a5c764a7…")
- commit: #raw("912568f709ac") (2 dirty tracked files)
- host: AMD EPYC 9V74 80-Core Processor, 1 logical CPUs, kernel 6.18.57, PMU absent, perf\_event\_paranoid 2
- valgrind: valgrind-3.24.0
- isolation: none; wall 0.499 s (profiled run: not a timing measurement)
- started: 2026-11-17T06:35:40Z

== Hotspots (callgrind, self Ir)

Total: 23376889 Ir (deterministic, simulated; not cycles).

#table(columns: 5,
  [*\#*],  [*self %*],  [*Ir*],  [*function*],  [*object*],
  [1],  [13.94],  [3259265],  [#raw("certified_relations::axpy_in_place::<alloc::vec::Vec<usize>>")],  [fused-native],
  [2],  [6.73],  [1573450],  [#raw("free")],  [libc.so.6],
  [3],  [4.92],  [1149192],  [#raw("<alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<usize>, core::slice::iter::Iter<usize>>, certified_relations::plus::{closure#0}>>>::from_iter")],  [fused-native],
  [4],  [4.31],  [1007768],  [#raw("malloc")],  [libc.so.6],
  [5],  [3.46],  [809265],  [#raw("0x00000000000a0fe0")],  [libc.so.6],
  [6],  [3.41],  [796307],  [#raw("<relation_replay_checker::packed::Arithmetic<9007199254740881>>::identity")],  [fused-native],
  [7],  [3.3],  [770578],  [#raw("certified_relations::normal_form")],  [fused-native],
  [8],  [2.85],  [665803],  [#raw("<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::insert")],  [fused-native],
  [9],  [2.62],  [611870],  [#raw("certified_relations::lead")],  [fused-native],
  [10],  [2.55],  [595296],  [#raw("<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Owned, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::LeafOrInternal>>::bulk_push::<alloc::collections::btree::dedup_sorted_iter::DedupSortedIter<alloc::vec::Vec<usize>, u64, alloc::vec::into_iter::IntoIter<(alloc::vec::Vec<usize>, u64)>>, alloc::alloc::Global>")],  [fused-native],
  [11],  [2.51],  [585846],  [#raw("<core::iter::adapters::map::Map<alloc::collections::btree::map::Keys<alloc::vec::Vec<usize>, u64>, certified_relations::degree::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::cmp::Ord>::max>")],  [fused-native],
  [12],  [2.32],  [541544],  [#raw("<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::remove::<alloc::vec::Vec<usize>>")],  [fused-native],
  [13],  [2.22],  [517846],  [#raw("__umodti3")],  [fused-native],
  [14],  [2.13],  [496795],  [#raw("<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<(alloc::vec::Vec<usize>, u64), <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)>>::extend_trusted<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>")],  [fused-native],
  [15],  [2.06],  [480924],  [#raw("0x00000000000a02e0")],  [libc.so.6],
  [16],  [1.67],  [389361],  [#raw("core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(alloc::vec::Vec<usize>, u64), <[(alloc::vec::Vec<usize>, u64)]>::sort_by<<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64> as core::iter::traits::collect::FromIterator<(alloc::vec::Vec<usize>, u64)>>::from_iter<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}>")],  [fused-native],
  [17],  [1.66],  [388580],  [#raw("certified_relations::axpy_in_place::<(usize, alloc::vec::Vec<usize>)>")],  [fused-native],
  [18],  [1.39],  [325177],  [#raw("<serde_json::de::Deserializer<serde_json::read::SliceRead>>::parse_integer")],  [fused-native],
  [19],  [1.39],  [324364],  [#raw("0x0000000000162880")],  [libc.so.6],
  [20],  [1.31],  [307100],  [#raw("<alloc::collections::btree::map::IntoIter<alloc::vec::Vec<usize>, u64>>::dying_next")],  [fused-native],
  [21],  [1.28],  [298477],  [#raw("certified_relations::quotient::rewrite")],  [fused-native],
  [22],  [1],  [233929],  [#raw("certified_relations::verify")],  [fused-native],
  [23],  [0.95],  [223221],  [#raw("<alloc::collections::btree::node::Handle<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Dying, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::Leaf>, alloc::collections::btree::node::marker::Edge>>::deallocating_next::<alloc::alloc::Global>")],  [fused-native],
  [24],  [0.94],  [219618],  [#raw("__rustc::__rdl_alloc")],  [fused-native],
  [25],  [0.93],  [216825],  [#raw("<serde_json::de::SeqAccess<_> as serde_core::de::SeqAccess>::next_element_seed::has_next_element::<serde_json::read::SliceRead>")],  [fused-native],
)

== Files

- #raw("annotate-inclusive.txt")
- #raw("annotate.txt")
- #raw("callgrind.out")
- #raw("command.stderr")
- #raw("command.stdout")
- #raw("hotspots.json")
- #raw("hotspots.svg")
- #raw("manifest.json")

Raw profiler output (perf.data, \*.ncu-rep, \*.nsys-rep, callgrind.out) is large: push it with #raw("crypto store push") (AGENTS.md section 13) rather than committing it.

== Graphs

#figure(image("hotspots.svg", width: 100%))

