//! Full-width, native-XOR SAT circuits for chained binary Semaev S3.
//!
//! A chain of `m-1` S3 equations is a necessary x-coordinate condition for
//! an `m`-point decomposition. Intermediate sums can be the identity, which
//! has no x-coordinate, so each possible intermediate-identity pattern is a
//! separate finite SAT instance. The caller must check every model against
//! the original equations and lift its summands in the curve group. A capped
//! pattern is inconclusive, not a refutation.

use num_bigint::BigUint;

/// Bounded opt-in provenance of the original unsimplified construction.
#[path = "binary_semaev_chain_provenance.rs"]
pub mod provenance;

use crate::binary_ecc::{
    trace_zero::{
        TraceZeroAffineMode, TraceZeroError, TraceZeroKummerMode, TraceZeroKummerSystem,
        TraceZeroVariety,
    },
    BinaryPoint,
};
use crate::binary_ecc::{F2mElement, IrreduciblePoly};
use crate::cryptanalysis::binary_semaev::binary_semaev_s3;
use crate::cryptanalysis::sat::{Lit, Solver};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ChainBuildError {
    Unsupported,
    VariableCap { required: u64, maximum: u32 },
    DomainClauseCap { required: usize, maximum: usize },
}

/// Polynomial multiplication circuit used inside each S3 equation.
/// Karatsuba is opt-in so existing sweep receipts retain their source meaning.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ChainProductKernel {
    Schoolbook,
    Karatsuba,
    ShallowKaratsuba,
}

/// Worst-case SAT variable count for the schoolbook circuit, before a
/// finite-coordinate domain. The bound is exact for the all-affine pattern.
/// Defined through m = 15, the widest supported summand count.
pub fn chain_s3_max_variables(n: u32, m: usize) -> Option<u64> {
    // m=15 uses only 13 intermediate-identity bits. Keep this explicit
    // bound below the u32 mask width; build() checks its allocation cap
    // against the returned full circuit bound before constructing gates.
    if !(2..=15).contains(&m) || !(2..=131).contains(&n) {
        return None;
    }
    let n = u64::from(n);
    let m = m as u64;
    // Summands, m-2 internal outputs and target; one sum block and three
    // reduced products per S3. Squaring is a linear map in characteristic 2.
    Some(n * (2 * m - 1) + 4 * n * (m - 1) + 3 * n * n * (m - 1))
}

/// Exact number of missing-prefix clauses for `m` identical finite x-domains.
/// This is computed without constructing a solver or enumerating the domain's
/// complement, and is a memory preflight rather than a runtime estimate.
pub fn finite_domain_clause_count(codes: &[BigUint], n: u32, m: usize) -> Option<usize> {
    if n == 0 || m == 0 || codes.iter().any(|code| code.bits() > u64::from(n)) {
        return None;
    }
    fn count(codes: &[BigUint], bit: usize) -> Option<usize> {
        if codes.is_empty() {
            return Some(1);
        }
        if bit == 0 {
            return Some(0);
        }
        let position = bit - 1;
        let split = codes.partition_point(|code| !code.bit(position as u64));
        count(&codes[..split], position)?.checked_add(count(&codes[split..], position)?)
    }
    let mut sorted = codes.to_vec();
    sorted.sort_unstable();
    sorted.dedup();
    count(&sorted, n as usize)?.checked_mul(m)
}

/// Exact additions for a signed-Frobenius x-domain represented by distinct
/// orbit representatives. Each summand chooses one representative and one
/// phase in `0..n`; sign does not alter x. The root point and every phase
/// transform are tied to the original summand bits, so this is an exact
/// finite-domain constraint rather than a post-solve filter.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct FrobeniusOrbitDomainSize {
    pub variables: u64,
    pub clauses: usize,
    pub xor_rows: usize,
}

/// Exact representative-to-root encoding. SharedBits is explicit because its
/// cost depends on the actual representative set, rather than only its size.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum FrobeniusOrbitRootEncoding {
    #[default]
    PerRepresentative,
    SharedBits,
}

/// SAT wires allocated for one exact Frobenius-orbit x-domain. Selectors
/// follow the sorted representative order used by the domain builder.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct FrobeniusOrbitChoiceWires {
    pub selectors: Vec<u32>,
    pub phase: Vec<u32>,
}

pub fn frobenius_orbit_domain_size(
    n: u32,
    m: usize,
    representatives: usize,
) -> Option<FrobeniusOrbitDomainSize> {
    if !(2..=131).contains(&n) || m == 0 || representatives < 2 {
        return None;
    }
    let bits = (u32::BITS - (n - 1).leading_zeros()) as usize;
    let n = n as usize;
    let vars_per = representatives
        .checked_mul(2)?
        .checked_sub(1)?
        .checked_add(n)?
        .checked_add(bits)?
        .checked_add(2usize.checked_mul(n)?.checked_mul(bits)?)?;
    let clauses_per = representatives
        .checked_mul(n)?
        .checked_add(3usize.checked_mul(representatives)?.checked_sub(3)?)?
        .checked_add((1usize << bits).checked_sub(n)?)?
        .checked_add(4usize.checked_mul(n)?.checked_mul(bits)?)?;
    Some(FrobeniusOrbitDomainSize {
        variables: u64::try_from(vars_per.checked_mul(m)?).ok()?,
        clauses: clauses_per.checked_mul(m)?,
        xor_rows: bits.checked_add(1)?.checked_mul(n)?.checked_mul(m)?,
    })
}

/// Data-dependent exact size of an orbit domain with common root bits
/// represented by units instead of one implication per representative.
pub fn frobenius_orbit_domain_size_with_encoding(
    n: u32,
    m: usize,
    representatives: &[BigUint],
    encoding: FrobeniusOrbitRootEncoding,
) -> Option<FrobeniusOrbitDomainSize> {
    let mut size = frobenius_orbit_domain_size(n, m, representatives.len())?;
    if representatives.iter().any(|x| x.bits() > u64::from(n)) {
        return None;
    }
    let mut sorted = representatives.to_vec();
    sorted.sort_unstable();
    sorted.dedup();
    if sorted.len() != representatives.len() {
        return None;
    }
    if encoding == FrobeniusOrbitRootEncoding::SharedBits {
        let common = shared_root_bits(n, &sorted).iter().flatten().count();
        let removed = common
            .checked_mul(sorted.len().checked_sub(1)?)?
            .checked_mul(m)?;
        size.clauses = size.clauses.checked_sub(removed)?;
    }
    Some(size)
}

fn shared_root_bits(n: u32, representatives: &[BigUint]) -> Vec<Option<bool>> {
    (0..u64::from(n))
        .map(|bit| {
            let first = representatives[0].bit(bit);
            representatives
                .iter()
                .all(|x| x.bit(bit) == first)
                .then_some(first)
        })
        .collect()
}

fn reduced_monomial(degree: usize, irr: &IrreduciblePoly) -> Vec<usize> {
    let n = irr.degree as usize;
    let mut bits = vec![false; 2 * n - 1];
    bits[degree] = true;
    for high in (n..=degree).rev() {
        if bits[high] {
            bits[high] = false;
            for &low in &irr.low_terms {
                bits[high - n + low as usize] ^= true;
            }
        }
    }
    (0..n).filter(|&bit| bits[bit]).collect()
}

pub(crate) struct Circuit {
    n: usize,
    product_kernel: ChainProductKernel,
    pub(crate) next: u32,
    reductions: Vec<Vec<usize>>,
    pub(crate) square_inputs: Vec<Vec<usize>>,
    ands: Vec<(u32, u32, u32)>,
    pub(crate) xors: Vec<(Vec<u32>, bool)>,
    pub(crate) units: Vec<(u32, bool)>,
    impossible: bool,
    fold_constants: bool,
    known: Vec<Option<bool>>,
}

impl Circuit {
    pub(crate) fn new(irr: &IrreduciblePoly) -> Self {
        Self::new_with_kernel(irr, ChainProductKernel::Schoolbook)
    }

    fn new_with_kernel(irr: &IrreduciblePoly, product_kernel: ChainProductKernel) -> Self {
        let n = irr.degree as usize;
        let reductions: Vec<_> = (0..2 * n - 1)
            .map(|degree| reduced_monomial(degree, irr))
            .collect();
        let mut square_inputs = vec![Vec::new(); n];
        for bit in 0..n {
            for &output in &reductions[2 * bit] {
                square_inputs[output].push(bit);
            }
        }
        Self {
            n,
            product_kernel,
            next: 1,
            reductions,
            square_inputs,
            ands: Vec::new(),
            xors: Vec::new(),
            units: Vec::new(),
            impossible: false,
            fold_constants: false,
            known: Vec::new(),
        }
    }

    fn enable_constant_folding(&mut self) {
        debug_assert_eq!(self.next, 1);
        self.fold_constants = true;
        self.known = vec![None];
    }
    fn pin(&mut self, wire: u32, value: bool) {
        self.units.push((wire, value));
        if self.fold_constants {
            if self.known[wire as usize].is_some_and(|old| old != value) {
                self.impossible = true;
            }
            self.known[wire as usize] = Some(value);
        }
    }
    fn xor(&mut self, row: Vec<u32>, rhs: bool) {
        if self.fold_constants {
            let mut unknown = std::collections::BTreeSet::new();
            let mut constant = rhs;
            for &wire in &row {
                if let Some(value) = self.known[wire as usize] {
                    constant ^= value;
                } else if !unknown.remove(&wire) {
                    unknown.insert(wire);
                }
            }
            if unknown.is_empty() {
                if constant {
                    self.impossible = true;
                }
            } else if unknown.len() == 1 {
                self.pin(*unknown.first().expect("one unknown"), constant);
            }
        }
        self.xors.push((row, rhs));
    }

    fn wire(&mut self) -> u32 {
        let wire = self.next;
        self.next += 1;
        if self.fold_constants {
            self.known.push(None);
        }
        wire
    }

    pub(crate) fn block(&mut self) -> Vec<u32> {
        (0..self.n).map(|_| self.wire()).collect()
    }

    pub(crate) fn equal(&mut self, left: &[u32], right: &[u32]) {
        for (&a, &b) in left.iter().zip(right) {
            self.xor(vec![a, b], false);
        }
    }

    pub(crate) fn product(&mut self, left: &[u32], right: &[u32]) -> Vec<u32> {
        if self.product_kernel == ChainProductKernel::Karatsuba {
            return self.product_karatsuba(left, right);
        }
        if self.product_kernel == ChainProductKernel::ShallowKaratsuba {
            return self.product_shallow_karatsuba(left, right);
        }
        let mut rows = vec![Vec::new(); self.n];
        for (i, &a) in left.iter().enumerate() {
            for (j, &b) in right.iter().enumerate() {
                let gate = if self.fold_constants {
                    match (self.known[a as usize], self.known[b as usize]) {
                        (Some(false), _) | (_, Some(false)) => continue,
                        (Some(true), _) => b,
                        (_, Some(true)) => a,
                        _ => {
                            let gate = self.wire();
                            self.ands.push((gate, a, b));
                            gate
                        }
                    }
                } else {
                    let gate = self.wire();
                    self.ands.push((gate, a, b));
                    gate
                };
                for &output in &self.reductions[i + j] {
                    rows[output].push(gate);
                }
            }
        }
        let output = self.block();
        for (bit, mut row) in rows.into_iter().enumerate() {
            row.push(output[bit]);
            self.xor(row, false);
        }
        output
    }

    fn xor_terms(&mut self, mut terms: Vec<u32>) -> u32 {
        terms.retain(|&wire| wire != 0);
        terms.sort_unstable();
        let mut odd = Vec::with_capacity(terms.len());
        let mut index = 0;
        while index < terms.len() {
            let wire = terms[index];
            let mut end = index + 1;
            while end < terms.len() && terms[end] == wire {
                end += 1;
            }
            if (end - index) & 1 == 1 {
                odd.push(wire);
            }
            index = end;
        }
        match odd.len() {
            0 => 0,
            1 => odd[0],
            _ => {
                let output = self.wire();
                odd.push(output);
                self.xors.push((odd, false));
                output
            }
        }
    }

    // Zero is a private constant-zero sentinel, never a SAT variable.
    fn polynomial_karatsuba(&mut self, left: &[u32], right: &[u32]) -> Vec<u32> {
        debug_assert_eq!(left.len(), right.len());
        debug_assert!(left.len().is_power_of_two());
        if left.len() == 1 {
            if left[0] == 0 || right[0] == 0 {
                return vec![0];
            }
            let output = self.wire();
            self.ands.push((output, left[0], right[0]));
            return vec![output];
        }
        let half = left.len() / 2;
        let low = self.polynomial_karatsuba(&left[..half], &right[..half]);
        let high = self.polynomial_karatsuba(&left[half..], &right[half..]);
        let left_sum: Vec<u32> = (0..half)
            .map(|i| self.xor_terms(vec![left[i], left[i + half]]))
            .collect();
        let right_sum: Vec<u32> = (0..half)
            .map(|i| self.xor_terms(vec![right[i], right[i + half]]))
            .collect();
        let mixed = self.polynomial_karatsuba(&left_sum, &right_sum);
        let mut rows = vec![Vec::new(); 4 * half - 1];
        for (i, &wire) in low.iter().enumerate() {
            rows[i].push(wire);
            rows[i + half].push(wire);
        }
        for (i, &wire) in high.iter().enumerate() {
            rows[i + half].push(wire);
            rows[i + 2 * half].push(wire);
        }
        for (i, &wire) in mixed.iter().enumerate() {
            rows[i + half].push(wire);
        }
        rows.into_iter().map(|row| self.xor_terms(row)).collect()
    }

    fn product_karatsuba(&mut self, left: &[u32], right: &[u32]) -> Vec<u32> {
        let padded = self.n.next_power_of_two();
        let mut a = vec![0; padded];
        let mut b = vec![0; padded];
        a[..self.n].copy_from_slice(left);
        b[..self.n].copy_from_slice(right);
        let polynomial = self.polynomial_karatsuba(&a, &b);
        let mut rows = vec![Vec::new(); self.n];
        for (degree, &wire) in polynomial.iter().enumerate() {
            // Padded coefficients above the true 2n-2 degree cancel by the
            // Karatsuba identities; they do not contribute to field output.
            if wire == 0 || degree >= self.reductions.len() {
                continue;
            }
            for &output in &self.reductions[degree] {
                rows[output].push(wire);
            }
        }
        let output = self.block();
        for (bit, mut row) in rows.into_iter().enumerate() {
            row.push(output[bit]);
            self.xors.push((row, false));
        }
        output
    }

    fn product_shallow_karatsuba(&mut self, left: &[u32], right: &[u32]) -> Vec<u32> {
        // A=A0+x^h A1, B=B0+x^h B1, with h=ceil(n/2).  Form only
        // L=A0 B0, H=A1 B1, and M=(A0+A1)(B0+B1).  Each AND gate is
        // routed directly to the reduced output; no coefficient wires for
        // L, H, or M are introduced into the SAT instance.
        let half = self.n.div_ceil(2);
        let high = self.n - half;
        let mut rows = vec![Vec::new(); self.n];
        let mut left_mix = Vec::with_capacity(half);
        let mut right_mix = Vec::with_capacity(half);
        for i in 0..half {
            left_mix.push(self.xor_terms(vec![left[i], left.get(i + half).copied().unwrap_or(0)]));
            right_mix
                .push(self.xor_terms(vec![right[i], right.get(i + half).copied().unwrap_or(0)]));
        }
        for i in 0..half {
            for j in 0..half {
                let gate = self.wire();
                self.ands.push((gate, left[i], right[j]));
                for &degree in &[i + j, i + j + half] {
                    for &bit in &self.reductions[degree] {
                        rows[bit].push(gate);
                    }
                }
            }
        }
        for i in 0..high {
            for j in 0..high {
                let gate = self.wire();
                self.ands.push((gate, left[i + half], right[j + half]));
                for &degree in &[i + j + half, i + j + 2 * half] {
                    for &bit in &self.reductions[degree] {
                        rows[bit].push(gate);
                    }
                }
            }
        }
        for i in 0..half {
            for j in 0..half {
                let gate = self.wire();
                self.ands.push((gate, left_mix[i], right_mix[j]));
                for &bit in &self.reductions[i + j + half] {
                    rows[bit].push(gate);
                }
            }
        }
        let output = self.block();
        for (bit, mut row) in rows.into_iter().enumerate() {
            row.push(output[bit]);
            self.xors.push((row, false));
        }
        output
    }

    fn s3(&mut self, x: &[u32], y: &[u32], z: &[u32], b: &F2mElement) {
        let sum = self.block();
        for bit in 0..self.n {
            self.xor(vec![sum[bit], x[bit], y[bit]], false);
        }
        let xy = self.product(x, y);
        let sum_z = self.product(&sum, z);
        let xyz = self.product(&xy, z);
        let b_bits = b.to_biguint();
        for output in 0..self.n {
            let mut row = vec![xyz[output]];
            for &input in &self.square_inputs[output] {
                row.extend([xy[input], sum_z[input]]);
            }
            self.xor(row, b_bits.bit(output as u64));
        }
    }

    pub(crate) fn finish(self) -> Solver {
        let mut solver = Solver::new(self.next - 1);
        for (gate, left, right) in self.ands {
            let (gate, left, right) = (gate as Lit, left as Lit, right as Lit);
            solver.add_clause(vec![-gate, left]);
            solver.add_clause(vec![-gate, right]);
            solver.add_clause(vec![gate, -left, -right]);
        }
        for (row, rhs) in self.xors {
            solver.add_xor(&row, rhs);
        }
        for (wire, value) in self.units {
            solver.add_clause(vec![if value { wire as Lit } else { -(wire as Lit) }]);
        }
        if self.impossible {
            solver.add_clause(vec![]);
        }
        solver
    }
}

/// An x-coordinate circuit for one intermediate-identity pattern. Summand
/// blocks occupy SAT variables `1..=m*n`, followed by internal and target
/// blocks. The product gates and all S3 rows use native XOR constraints.
pub struct ChainedS3Encoding {
    pub solver: Solver,
    pub n_and_gates: usize,
    pub n_s3_nodes: usize,
    n: u32,
    m: usize,
    identity_mask: u32,
    blocks: Vec<Vec<u32>>,
    target_x: Option<F2mElement>,
    b: F2mElement,
    irr: IrreduciblePoly,
    domain_installed: bool,
    orbit_choice_wires: Vec<FrobeniusOrbitChoiceWires>,
    first_pair_exchangeable: bool,
    first_pair_ordered: bool,
    all_summands_exchangeable: bool,
    all_summands_ordered: bool,
    adjacent_domains_equal: Vec<bool>,
    adjacent_ordered: Vec<bool>,
    full_trace_zero: Option<(TraceZeroVariety, Vec<Vec<u32>>)>,
    intermediate_trace_enforced: bool,
    kummer_trace_zero: Option<(TraceZeroVariety, Vec<Vec<u32>>)>,
    subspace_kummer: Option<(TraceZeroKummerSystem, Vec<Vec<u32>>)>,
    terminal_pairs: Option<Vec<BigUint>>,
}

impl ChainedS3Encoding {
    pub fn build(
        m: usize,
        irr: &IrreduciblePoly,
        b: &F2mElement,
        target_x: Option<&F2mElement>,
        identity_mask: u32,
        max_variables: u32,
    ) -> Result<Self, ChainBuildError> {
        Self::build_internal(
            m,
            irr,
            b,
            target_x,
            identity_mask,
            max_variables,
            None,
            false,
            ChainProductKernel::Schoolbook,
        )
    }

    /// Build the original S3 equations with an explicitly chosen multiplication
    /// circuit. Constant folding remains disabled for these retained kernel arms.
    pub fn build_with_kernel(
        m: usize,
        irr: &IrreduciblePoly,
        b: &F2mElement,
        target_x: Option<&F2mElement>,
        identity_mask: u32,
        max_variables: u32,
        kernel: ChainProductKernel,
    ) -> Result<Self, ChainBuildError> {
        Self::build_internal(
            m,
            irr,
            b,
            target_x,
            identity_mask,
            max_variables,
            None,
            false,
            kernel,
        )
    }

    /// Constant field multiplication is linear. Specialize only the
    /// already fixed target while preserving the original build default.
    pub fn build_with_target_constants(
        m: usize,
        irr: &IrreduciblePoly,
        b: &F2mElement,
        target_x: Option<&F2mElement>,
        identity_mask: u32,
        max_variables: u32,
    ) -> Result<Self, ChainBuildError> {
        Self::build_internal(
            m,
            irr,
            b,
            target_x,
            identity_mask,
            max_variables,
            None,
            true,
            ChainProductKernel::Schoolbook,
        )
    }

    /// Compile constants shared by every allowed summand code, then attach
    /// the exact same complete finite domain. No code or sign is discarded.
    /// Allocation retains the old conservative preflight bound.
    pub fn build_for_domain(
        m: usize,
        irr: &IrreduciblePoly,
        b: &F2mElement,
        target_x: Option<&F2mElement>,
        identity_mask: u32,
        max_variables: u32,
        codes: &[BigUint],
        max_domain_clauses: usize,
    ) -> Result<Self, ChainBuildError> {
        if codes.is_empty() || codes.iter().any(|x| x.bits() > irr.degree as u64) {
            return Err(ChainBuildError::Unsupported);
        }
        let required =
            finite_domain_clause_count(codes, irr.degree, m).ok_or(ChainBuildError::Unsupported)?;
        if required > max_domain_clauses {
            return Err(ChainBuildError::DomainClauseCap {
                required,
                maximum: max_domain_clauses,
            });
        }
        let common = shared_root_bits(irr.degree, codes);
        let mut enc = Self::build_internal(
            m,
            irr,
            b,
            target_x,
            identity_mask,
            max_variables,
            Some(&common),
            true,
            ChainProductKernel::Schoolbook,
        )?;
        enc.constrain_summands(codes, max_domain_clauses)?;
        Ok(enc)
    }

    /// Algebraic full-kernel domain, without enumerating its finite points.
    /// Shared zero bits specialize field products; linear basis rows and
    /// the compact inverse model constrain exactly x in V intersect x(T_n).
    pub fn build_for_trace_zero_subspace(
        m: usize,
        variety: &TraceZeroVariety,
        basis: &[F2mElement],
        target: &BinaryPoint,
        identity_mask: u32,
        max_variables: u32,
        max_terms: usize,
    ) -> Result<Self, TraceZeroError> {
        if !variety.contains(target) {
            return Err(TraceZeroError::NotTraceZero);
        }
        let curve = variety.curve();
        let model =
            variety.kummer_system_over_subspace(basis, TraceZeroKummerMode::Compact, max_terms)?;
        let base = chain_s3_max_variables(curve.m, m).ok_or(TraceZeroError::UnsupportedCurve)?;
        let extra = (model.variables as u64 + model.auxiliary_variables() as u64) * m as u64;
        let required = base + extra;
        if required > max_variables as u64 || required > i32::MAX as u64 {
            return Err(TraceZeroError::VariableCap {
                required,
                maximum: max_variables,
            });
        }
        let common: Vec<_> = (0..curve.m)
            .map(|bit| {
                basis
                    .iter()
                    .all(|b| !b.to_biguint().bit(bit as u64))
                    .then_some(false)
            })
            .collect();
        let tx = match target {
            BinaryPoint::Infinity => None,
            BinaryPoint::Affine { x, .. } => Some(x),
        };
        let mut enc = Self::build_internal(
            m,
            &curve.irreducible,
            &curve.b,
            tx,
            identity_mask,
            max_variables,
            Some(&common),
            true,
            ChainProductKernel::Schoolbook,
        )
        .map_err(|e| match e {
            ChainBuildError::VariableCap { required, maximum } => {
                TraceZeroError::VariableCap { required, maximum }
            }
            _ => TraceZeroError::UnsupportedCurve,
        })?;
        let mut mappings = Vec::new();
        for i in 0..m {
            let wires: Vec<u32> = enc.solver.add_vars(model.variables).collect();
            for bit in 0..curve.m as usize {
                let mut row = vec![enc.blocks[i][bit]];
                row.extend(
                    basis
                        .iter()
                        .enumerate()
                        .filter_map(|(j, b)| b.to_biguint().bit(bit as u64).then_some(wires[j])),
                );
                enc.solver.add_xor(&row, false);
            }
            model.append_to_solver(&mut enc.solver, &wires, max_variables)?;
            mappings.push(wires);
        }
        let mut primary = Vec::new();
        for wires in &mappings {
            primary.extend_from_slice(&wires[..basis.len()]);
        }
        for wires in &mappings {
            primary.extend_from_slice(&wires[basis.len()..]);
        }
        enc.solver.set_branch_priority(&primary);
        enc.subspace_kummer = Some((model, mappings));
        Ok(enc)
    }

    fn build_internal(
        m: usize,
        irr: &IrreduciblePoly,
        b: &F2mElement,
        target_x: Option<&F2mElement>,
        identity_mask: u32,
        max_variables: u32,
        common: Option<&[Option<bool>]>,
        fold_constants: bool,
        kernel: ChainProductKernel,
    ) -> Result<Self, ChainBuildError> {
        let n = irr.degree;
        let Some(required) = chain_s3_max_variables(n, m) else {
            return Err(ChainBuildError::Unsupported);
        };
        if max_variables == 0 {
            return Err(ChainBuildError::VariableCap {
                required: if kernel == ChainProductKernel::Schoolbook {
                    required
                } else {
                    1
                },
                maximum: max_variables,
            });
        }
        if kernel == ChainProductKernel::Schoolbook && required > u64::from(max_variables) {
            return Err(ChainBuildError::VariableCap {
                required,
                maximum: max_variables,
            });
        }
        if b.m_value() != n
            || target_x.is_some_and(|x| x.m_value() != n)
            || identity_mask >= (1u32 << (m - 2))
            || !irr.low_terms.contains(&0)
            || irr.low_terms.iter().any(|&term| term >= n)
            || {
                let mut terms = irr.low_terms.clone();
                terms.sort_unstable();
                terms.dedup();
                terms.len() != irr.low_terms.len()
            }
        {
            return Err(ChainBuildError::Unsupported);
        }
        let mut circuit = Circuit::new_with_kernel(irr, kernel);
        if fold_constants {
            circuit.enable_constant_folding();
        }
        let blocks: Vec<Vec<u32>> = (0..2 * m - 1).map(|_| circuit.block()).collect();
        let target = &blocks[2 * m - 2];
        let target_bits = target_x.map(F2mElement::to_biguint);
        for (bit, &wire) in target.iter().enumerate() {
            circuit.pin(
                wire,
                target_bits.as_ref().is_some_and(|x| x.bit(bit as u64)),
            );
        }
        if let Some(common) = common {
            for block in &blocks[..m] {
                for (bit, value) in common.iter().enumerate() {
                    if let Some(value) = value {
                        circuit.pin(block[bit], *value);
                    }
                }
            }
        }

        let mut n_s3_nodes = 0;
        let mut previous = &blocks[0];
        for step in 1..m {
            let output = if step == m - 1 {
                target
            } else {
                &blocks[m + step - 1]
            };
            let previous_infinity = step > 1 && (identity_mask & (1 << (step - 2))) != 0;
            let output_infinity = if step == m - 1 {
                target_x.is_none()
            } else {
                (identity_mask & (1 << (step - 1))) != 0
            };
            if step < m - 1 && output_infinity {
                for &wire in output {
                    circuit.units.push((wire, false));
                }
            }
            match (previous_infinity, output_infinity) {
                (true, true) => circuit.impossible = true, // O + affine != O
                (true, false) => circuit.equal(&blocks[step], output),
                (false, true) => circuit.equal(previous, &blocks[step]),
                (false, false) => {
                    circuit.s3(previous, &blocks[step], output, b);
                    n_s3_nodes += 1;
                }
            }
            previous = output;
        }
        let actual_variables = u64::from(circuit.next - 1);
        if actual_variables > u64::from(max_variables) || actual_variables > i32::MAX as u64 {
            return Err(ChainBuildError::VariableCap {
                required: actual_variables,
                maximum: max_variables,
            });
        }
        let n_and_gates = circuit.ands.len();
        let mut solver = circuit.finish();
        solver.set_branch_priority(&(1..=(m as u32 * n)).collect::<Vec<_>>());
        Ok(Self {
            solver,
            n_and_gates,
            n_s3_nodes,
            n,
            m,
            identity_mask,
            blocks,
            target_x: target_x.cloned(),
            b: b.clone(),
            irr: irr.clone(),
            domain_installed: false,
            orbit_choice_wires: Vec::new(),
            first_pair_exchangeable: false,
            first_pair_ordered: false,
            all_summands_exchangeable: false,
            all_summands_ordered: false,
            adjacent_domains_equal: vec![false; m - 1],
            adjacent_ordered: vec![false; m - 1],
            full_trace_zero: None,
            intermediate_trace_enforced: false,
            kummer_trace_zero: None,
            subspace_kummer: None,
            terminal_pairs: None,
        })
    }

    /// Necessary invariant for chains of full-kernel rational points:
    /// every finite partial sum has field trace zero in its abscissa.
    /// This does not constrain a partial sum to the original factor base.
    pub fn constrain_trace_zero_intermediates(
        &mut self,
        variety: &TraceZeroVariety,
    ) -> Result<usize, TraceZeroError> {
        let curve = variety.curve();
        if self.intermediate_trace_enforced
            || curve.m != self.n
            || curve.irreducible.degree != self.irr.degree
            || curve.irreducible.low_terms != self.irr.low_terms
            || curve.b != self.b
        {
            return Err(TraceZeroError::UnsupportedCurve);
        }
        let support: Vec<_> = (0..self.n)
            .filter(|&i| F2mElement::from_bit_positions(&[i], self.n).trace(&self.irr) != 0)
            .collect();
        let mut count = 0;
        for step in 1..self.m - 1 {
            if self.identity_mask & (1 << (step - 1)) != 0 {
                continue;
            }
            let block = &self.blocks[self.m + step - 1];
            let row: Vec<_> = support.iter().map(|&i| block[i as usize]).collect();
            self.solver.add_xor(&row, false);
            count += 1;
        }
        self.intermediate_trace_enforced = true;
        Ok(count)
    }

    /// Full rational x-image membership with a unique inverse witness;
    /// no free ordinate sign. This is the classical x-only halving test.
    pub fn constrain_kummer_trace_zero_summands(
        &mut self,
        variety: &TraceZeroVariety,
        max_variables: u32,
        max_terms: usize,
    ) -> Result<usize, TraceZeroError> {
        let curve = variety.curve();
        if self.kummer_trace_zero.is_some()
            || curve.m != self.n
            || curve.irreducible.degree != self.irr.degree
            || curve.irreducible.low_terms != self.irr.low_terms
            || curve.b != self.b
        {
            return Err(TraceZeroError::UnsupportedCurve);
        }
        let system = variety.kummer_system(TraceZeroKummerMode::Raw, max_terms)?;
        let required = self.solver.n_vars() as u64
            + (self.n as u64 + system.auxiliary_variables() as u64) * self.m as u64;
        if required > max_variables as u64 || required > i32::MAX as u64 {
            return Err(TraceZeroError::VariableCap {
                required,
                maximum: max_variables,
            });
        }
        let mut inverses = Vec::new();
        for i in 0..self.m {
            let v: Vec<u32> = self.solver.add_vars(self.n).collect();
            let mut wires = self.blocks[i].clone();
            wires.extend(&v);
            system.append_to_solver(&mut self.solver, &wires, max_variables)?;
            inverses.push(v);
        }
        let mut primary: Vec<_> = self.blocks[..self.m].iter().flatten().copied().collect();
        primary.extend(inverses.iter().flatten().copied());
        self.solver.set_branch_priority(&primary);
        self.kummer_trace_zero = Some((variety.clone(), inverses));
        Ok(self.m * system.equations.len())
    }

    /// Install the full E_0 trace-zero rational-point equations on every
    /// summand. Unlike an aggregate x-trace XOR, this supplies ordinate
    /// variables, the original curve, and both 4E membership conditions.
    /// All allocation is preflighted before mutating the circuit.
    pub fn constrain_full_trace_zero_summands(
        &mut self,
        variety: &TraceZeroVariety,
        max_variables: u32,
        max_terms: usize,
    ) -> Result<usize, TraceZeroError> {
        let curve = variety.curve();
        if self.full_trace_zero.is_some()
            || curve.m != self.n
            || curve.irreducible.degree != self.irr.degree
            || curve.irreducible.low_terms != self.irr.low_terms
            || curve.b != self.b
        {
            return Err(TraceZeroError::UnsupportedCurve);
        }
        let system = variety.affine_system(TraceZeroAffineMode::Raw, max_terms)?;
        let per = self.n as u64 + system.auxiliary_variables() as u64;
        let required = self.solver.n_vars() as u64 + per * self.m as u64;
        if required > max_variables as u64 || required > i32::MAX as u64 {
            return Err(TraceZeroError::VariableCap {
                required,
                maximum: max_variables,
            });
        }
        let mut ordinates = Vec::with_capacity(self.m);
        for i in 0..self.m {
            let y: Vec<u32> = self.solver.add_vars(self.n).collect();
            let mut wires = self.blocks[i].clone();
            wires.extend(&y);
            system.append_to_solver(&mut self.solver, &wires, max_variables)?;
            ordinates.push(y);
        }
        let mut primary = self.blocks[..self.m]
            .iter()
            .flatten()
            .copied()
            .collect::<Vec<_>>();
        primary.extend(ordinates.iter().flatten().copied());
        self.solver.set_branch_priority(&primary);
        self.full_trace_zero = Some((variety.clone(), ordinates));
        Ok(self.m * (self.n as usize + 2))
    }

    /// Decode the full rational summand points when membership was installed.
    pub fn decode_full_trace_zero_summands(&self) -> Option<Vec<BinaryPoint>> {
        let (_, ys) = self.full_trace_zero.as_ref()?;
        let model = self.solver.model();
        Some(
            (0..self.m)
                .map(|i| BinaryPoint::Affine {
                    x: self.decode_block(&self.blocks[i], &model),
                    y: self.decode_block(&ys[i], &model),
                })
                .collect(),
        )
    }

    /// Correctness-control interface: pin full known points, validating
    /// their original group membership before adding coordinate units.
    pub fn pin_full_trace_zero_summands(
        &mut self,
        points: &[BinaryPoint],
    ) -> Result<(), TraceZeroError> {
        let Some((variety, ordinates)) = self.full_trace_zero.as_ref() else {
            return Err(TraceZeroError::UnsupportedCurve);
        };
        if points.len() != self.m
            || points
                .iter()
                .any(|p| matches!(p, BinaryPoint::Infinity) || !variety.contains(p))
        {
            return Err(TraceZeroError::InvalidPoint);
        }
        for (i, point) in points.iter().enumerate() {
            let BinaryPoint::Affine { x, y } = point else {
                unreachable!()
            };
            for (block, value) in [(&self.blocks[i], x), (&ordinates[i], y)] {
                let value = value.to_biguint();
                for (j, &wire) in block.iter().enumerate() {
                    self.solver.add_clause(vec![if value.bit(j as u64) {
                        wire as i32
                    } else {
                        -(wire as i32)
                    }]);
                }
            }
        }
        Ok(())
    }

    /// Add the exact finite set of rational factor-base x-coordinates to
    /// every summand. No constraint is placed on affine intermediate sums.
    pub fn constrain_summands(
        &mut self,
        codes: &[BigUint],
        max_domain_clauses: usize,
    ) -> Result<usize, ChainBuildError> {
        if self.domain_installed {
            return Err(ChainBuildError::Unsupported);
        }
        let required = finite_domain_clause_count(codes, self.n, self.m)
            .ok_or(ChainBuildError::Unsupported)?;
        if required > max_domain_clauses {
            return Err(ChainBuildError::DomainClauseCap {
                required,
                maximum: max_domain_clauses,
            });
        }
        let mut codes = codes.to_vec();
        codes.sort_unstable();
        codes.dedup();
        for block in &self.blocks[..self.m] {
            add_coordinate_domain(&mut self.solver, block, &codes, self.n as usize);
        }
        self.domain_installed = true;
        self.first_pair_exchangeable = true;
        self.adjacent_domains_equal.fill(true);
        self.all_summands_exchangeable = true;
        Ok(required)
    }

    /// Install the exact union of all binary-Frobenius phases of the given
    /// representative x-coordinates. One-hot representative selection and
    /// a bounded binary phase are linked to each summand by native XOR rows.
    /// All caps are checked before the solver is mutated.
    pub fn constrain_frobenius_orbit_summands(
        &mut self,
        representatives: &[BigUint],
        max_variables: u32,
        max_domain_clauses: usize,
    ) -> Result<FrobeniusOrbitDomainSize, ChainBuildError> {
        self.constrain_frobenius_orbit_summands_with_encoding(
            representatives,
            FrobeniusOrbitRootEncoding::PerRepresentative,
            max_variables,
            max_domain_clauses,
        )
    }

    /// Opt-in exact orbit domain with one unit for each root bit common to
    /// every representative. The unchanged exactly-one selector makes this
    /// equivalent to the per-representative implications.
    pub fn constrain_frobenius_orbit_summands_with_encoding(
        &mut self,
        representatives: &[BigUint],
        encoding: FrobeniusOrbitRootEncoding,
        max_variables: u32,
        max_domain_clauses: usize,
    ) -> Result<FrobeniusOrbitDomainSize, ChainBuildError> {
        if self.domain_installed || representatives.iter().any(|x| x.bits() > u64::from(self.n)) {
            return Err(ChainBuildError::Unsupported);
        }
        let mut sorted = representatives.to_vec();
        sorted.sort_unstable();
        sorted.dedup();
        if sorted.len() != representatives.len() {
            return Err(ChainBuildError::Unsupported);
        }
        let required = frobenius_orbit_domain_size_with_encoding(self.n, self.m, &sorted, encoding)
            .ok_or(ChainBuildError::Unsupported)?;
        let total = u64::from(self.solver.n_vars())
            .checked_add(required.variables)
            .ok_or(ChainBuildError::Unsupported)?;
        if total > u64::from(max_variables) || total > i32::MAX as u64 {
            return Err(ChainBuildError::VariableCap {
                required: total,
                maximum: max_variables,
            });
        }
        if required.clauses > max_domain_clauses {
            return Err(ChainBuildError::DomainClauseCap {
                required: required.clauses,
                maximum: max_domain_clauses,
            });
        }
        let shared = (encoding == FrobeniusOrbitRootEncoding::SharedBits)
            .then(|| shared_root_bits(self.n, &sorted));
        for block in &self.blocks[..self.m] {
            self.orbit_choice_wires.push(add_frobenius_orbit_domain(
                &mut self.solver,
                block,
                &sorted,
                &self.irr,
                shared.as_deref(),
            ));
        }
        self.domain_installed = true;
        self.first_pair_exchangeable = true;
        self.adjacent_domains_equal.fill(true);
        self.all_summands_exchangeable = true;
        Ok(required)
    }

    /// Give each summand its own exact signed-Frobenius x-domain. This is the
    /// circuit prerequisite for small-base summands plus one or two residual
    /// domains; a caller must still lift and verify any partial point equation.
    /// Caps and every domain are checked before mutating the solver.
    pub fn constrain_frobenius_orbit_domains(
        &mut self,
        representatives_by_summand: &[Vec<BigUint>],
        max_variables: u32,
        max_domain_clauses: usize,
    ) -> Result<FrobeniusOrbitDomainSize, ChainBuildError> {
        if self.domain_installed || representatives_by_summand.len() != self.m {
            return Err(ChainBuildError::Unsupported);
        }
        let mut sorted_domains = Vec::with_capacity(self.m);
        let mut required = FrobeniusOrbitDomainSize {
            variables: 0,
            clauses: 0,
            xor_rows: 0,
        };
        for representatives in representatives_by_summand {
            if representatives.iter().any(|x| x.bits() > u64::from(self.n)) {
                return Err(ChainBuildError::Unsupported);
            }
            let mut sorted = representatives.clone();
            sorted.sort_unstable();
            sorted.dedup();
            if sorted.len() != representatives.len() {
                return Err(ChainBuildError::Unsupported);
            }
            let size = frobenius_orbit_domain_size(self.n, 1, sorted.len())
                .ok_or(ChainBuildError::Unsupported)?;
            required.variables = required
                .variables
                .checked_add(size.variables)
                .ok_or(ChainBuildError::Unsupported)?;
            required.clauses = required
                .clauses
                .checked_add(size.clauses)
                .ok_or(ChainBuildError::Unsupported)?;
            required.xor_rows = required
                .xor_rows
                .checked_add(size.xor_rows)
                .ok_or(ChainBuildError::Unsupported)?;
            sorted_domains.push(sorted);
        }
        let total = u64::from(self.solver.n_vars())
            .checked_add(required.variables)
            .ok_or(ChainBuildError::Unsupported)?;
        if total > u64::from(max_variables) || total > i32::MAX as u64 {
            return Err(ChainBuildError::VariableCap {
                required: total,
                maximum: max_variables,
            });
        }
        if required.clauses > max_domain_clauses {
            return Err(ChainBuildError::DomainClauseCap {
                required: required.clauses,
                maximum: max_domain_clauses,
            });
        }
        self.first_pair_exchangeable = sorted_domains[0] == sorted_domains[1];
        self.adjacent_domains_equal = sorted_domains
            .windows(2)
            .map(|pair| pair[0] == pair[1])
            .collect();
        self.all_summands_exchangeable = sorted_domains.windows(2).all(|w| w[0] == w[1]);
        for (block, representatives) in self.blocks[..self.m].iter().zip(&sorted_domains) {
            self.orbit_choice_wires.push(add_frobenius_orbit_domain(
                &mut self.solver,
                block,
                representatives,
                &self.irr,
                None,
            ));
        }
        self.domain_installed = true;
        Ok(required)
    }

    /// Return exact selector/phase wires after an orbit-domain installation.
    /// Coordinate-only domains have no such wires.
    pub fn orbit_choice_wires(&self) -> Option<&[FrobeniusOrbitChoiceWires]> {
        (!self.orbit_choice_wires.is_empty()).then_some(&self.orbit_choice_wires)
    }

    /// Keep one representative of the first summand-pair swap. The first
    /// S3 node is symmetric in these two x-coordinates, and every later
    /// node depends only on its output. This is optional so ordered and
    /// unrestricted searches remain separate sweep arms.
    pub fn order_first_pair(&mut self, max_variables: u32) -> Result<(), ChainBuildError> {
        if self.first_pair_ordered || self.all_summands_ordered || !self.first_pair_exchangeable {
            return Err(ChainBuildError::Unsupported);
        }
        let extra = self.n - 1;
        let required = u64::from(self.solver.n_vars()) + u64::from(extra);
        if required > u64::from(max_variables) || required > i32::MAX as u64 {
            return Err(ChainBuildError::VariableCap {
                required,
                maximum: max_variables,
            });
        }
        add_lex_leq(&mut self.solver, &self.blocks[0], &self.blocks[1]);
        self.first_pair_ordered = true;
        self.adjacent_ordered[0] = true;
        Ok(())
    }

    /// Restrict the affine intermediate `y_step` (the x-coordinate of the
    /// partial sum after summand `step + 1`, `1 <= step <= m - 2`) to a
    /// finite set of codes, by the same trie as a summand domain. The caller
    /// must pass a set that contains every value the intermediate can take
    /// in a decomposition (for example all x-coordinates of sums of
    /// `step + 1` base points, or of `R` minus sums of `m - step - 1`), so
    /// that no decomposition is lost. Refused for an identity step, whose
    /// block is fixed to zero, and before the summand domain is installed.
    pub fn constrain_intermediate(
        &mut self,
        step: usize,
        codes: &[BigUint],
        max_domain_clauses: usize,
    ) -> Result<usize, ChainBuildError> {
        if !self.domain_installed
            || step == 0
            || step + 2 > self.m
            || (self.identity_mask & (1 << (step - 1))) != 0
        {
            return Err(ChainBuildError::Unsupported);
        }
        let required =
            finite_domain_clause_count(codes, self.n, 1).ok_or(ChainBuildError::Unsupported)?;
        if required > max_domain_clauses {
            return Err(ChainBuildError::DomainClauseCap {
                required,
                maximum: max_domain_clauses,
            });
        }
        let mut codes = codes.to_vec();
        codes.sort_unstable();
        codes.dedup();
        let block = self.blocks[self.m + step - 1].clone();
        add_coordinate_domain(&mut self.solver, &block, &codes, self.n as usize);
        Ok(required)
    }

    /// Exact allowed (x(P3),x(P1+P2)) pairs for a finite m3 intermediate.
    /// The caller supplies pairs from actual T-P3 group points, not an
    /// independently combined pair of coordinate lists. Infinity is handled
    /// by its separate identity mask, never encoded as affine x=0.
    pub fn constrain_terminal_pair_domain(
        &mut self,
        codes: &[BigUint],
        max_domain_clauses: usize,
    ) -> Result<usize, ChainBuildError> {
        if self.m != 3
            || self.identity_mask != 0
            || !self.domain_installed
            || self.terminal_pairs.is_some()
        {
            return Err(ChainBuildError::Unsupported);
        }
        let mut codes = codes.to_vec();
        codes.sort_unstable();
        codes.dedup();
        let required = finite_domain_clause_count(&codes, 2 * self.n, 1)
            .ok_or(ChainBuildError::Unsupported)?;
        if required > max_domain_clauses {
            return Err(ChainBuildError::DomainClauseCap {
                required,
                maximum: max_domain_clauses,
            });
        }
        let wires: Vec<_> = self.blocks[2]
            .iter()
            .chain(&self.blocks[3])
            .copied()
            .collect();
        add_coordinate_domain(&mut self.solver, &wires, &codes, 2 * self.n as usize);
        self.terminal_pairs = Some(codes);
        Ok(required)
    }

    /// Keep one representative of every summand permutation:
    /// `x_1 <= x_2 <= ... <= x_m` as unsigned codes. A decomposition
    /// `R = P_1 + ... + P_m` has a chain witness in every summand order, its
    /// partial sums landing in some identity pattern, so a caller that
    /// searches every pattern loses no decomposition; it only stops searching
    /// the `m!` reorderings of each one. Requires one shared summand domain.
    /// Optional, like [`Self::order_first_pair`], so the arms stay separate.
    pub fn order_all_summands(&mut self, max_variables: u32) -> Result<(), ChainBuildError> {
        if self.first_pair_ordered
            || self.all_summands_ordered
            || self.adjacent_ordered.iter().any(|x| *x)
            || !self.all_summands_exchangeable
        {
            return Err(ChainBuildError::Unsupported);
        }
        let extra = u64::from(self.n - 1) * (self.m as u64 - 1);
        let required = u64::from(self.solver.n_vars()) + extra;
        if required > u64::from(max_variables) || required > i32::MAX as u64 {
            return Err(ChainBuildError::VariableCap {
                required,
                maximum: max_variables,
            });
        }
        for i in 0..self.m - 1 {
            add_lex_leq(&mut self.solver, &self.blocks[i], &self.blocks[i + 1]);
        }
        self.all_summands_ordered = true;
        self.adjacent_ordered.fill(true);
        Ok(())
    }

    /// Canonically order every still-unordered adjacent pair with identical
    /// exact x-domains. The caller must also establish that each pair has the
    /// same allowed *full-point* set and position semantics. This is a complete
    /// symmetry arm only when all intermediate-identity patterns are searched:
    /// reordering exchangeable points preserves the group sum, but may change
    /// which chain prefix is the identity. Preflight the full auxiliary-variable
    /// addition before mutation. An earlier `order_first_pair` call is retained.
    pub fn order_equal_adjacent_summands(
        &mut self,
        max_variables: u32,
    ) -> Result<usize, ChainBuildError> {
        let edges: Vec<_> = (0..self.m - 1)
            .filter(|&edge| self.adjacent_domains_equal[edge] && !self.adjacent_ordered[edge])
            .collect();
        if edges.is_empty() {
            return Err(ChainBuildError::Unsupported);
        }
        let extra = (self.n as u64 - 1) * edges.len() as u64;
        let required = u64::from(self.solver.n_vars()) + extra;
        if required > u64::from(max_variables) || required > i32::MAX as u64 {
            return Err(ChainBuildError::VariableCap {
                required,
                maximum: max_variables,
            });
        }
        for edge in &edges {
            add_lex_leq(
                &mut self.solver,
                &self.blocks[*edge],
                &self.blocks[*edge + 1],
            );
            self.adjacent_ordered[*edge] = true;
        }
        Ok(edges.len())
    }

    fn decode_block(&self, block: &[u32], model: &[bool]) -> F2mElement {
        let set: Vec<u32> = block
            .iter()
            .enumerate()
            .filter_map(|(bit, &wire)| model[wire as usize - 1].then_some(bit as u32))
            .collect();
        F2mElement::from_bit_positions(&set, self.n)
    }

    pub fn decode_summands(&self) -> Vec<F2mElement> {
        let model = self.solver.model();
        self.blocks[..self.m]
            .iter()
            .map(|block| self.decode_block(block, &model))
            .collect()
    }

    /// Decode the summand x-coordinates from a complete external SAT model.
    pub fn decode_summands_assignment(&self, model: &[bool]) -> Option<Vec<F2mElement>> {
        (model.len() == self.solver.n_vars() as usize).then(|| {
            self.blocks[..self.m]
                .iter()
                .map(|block| self.decode_block(block, model))
                .collect()
        })
    }

    /// Require an external model to satisfy every original CNF and XOR row,
    /// then re-evaluate the chain over the original binary field.
    pub fn verify_external_assignment(&self, model: &[bool]) -> bool {
        self.solver.check_original_assignment(model) && self.verify_field_assignment(model)
    }

    /// Fix one named x-coordinate block: summands `0..m`, intermediate
    /// outputs `m..2m-2`, and the final target at `2m-2`. The target is
    /// fixed by `build`, so this only checks that its value agrees.
    pub fn pin_x_block(
        &mut self,
        block_index: usize,
        value: &F2mElement,
    ) -> Result<(), ChainBuildError> {
        if value.m_value() != self.n || block_index >= self.blocks.len() {
            return Err(ChainBuildError::Unsupported);
        }
        if block_index == self.blocks.len() - 1 {
            return if self.target_x.as_ref() == Some(value) {
                Ok(())
            } else {
                Err(ChainBuildError::Unsupported)
            };
        }
        let bits = value.to_biguint();
        for (bit, &wire) in self.blocks[block_index].iter().enumerate() {
            self.solver.add_clause(vec![if bits.bit(bit as u64) {
                wire as Lit
            } else {
                -(wire as Lit)
            }]);
        }
        Ok(())
    }

    /// Decode every x block of a SAT model in the same named order.
    pub fn decode_x_blocks(&self) -> Vec<F2mElement> {
        let model = self.solver.model();
        self.blocks
            .iter()
            .map(|block| self.decode_block(block, &model))
            .collect()
    }

    /// Re-evaluate every active S3 over the original field and each
    /// intermediate-identity equality. Call this after a SAT result.
    pub fn verify_model(&self) -> bool {
        let model = self.solver.model();
        self.verify_field_assignment(&model)
    }

    fn verify_field_assignment(&self, model: &[bool]) -> bool {
        if model.len() != self.solver.n_vars() as usize {
            return false;
        }
        if let Some((variety, ordinates)) = &self.full_trace_zero {
            for i in 0..self.m {
                let point = BinaryPoint::Affine {
                    x: self.decode_block(&self.blocks[i], model),
                    y: self.decode_block(&ordinates[i], model),
                };
                if !variety.contains(&point) {
                    return false;
                }
            }
        }
        if let Some((variety, inverses)) = &self.kummer_trace_zero {
            for i in 0..self.m {
                let x = self.decode_block(&self.blocks[i], model);
                let v = self.decode_block(&inverses[i], model);
                if x.mul(&v, &self.irr) != F2mElement::one(self.n) || !variety.kummer_contains_x(&x)
                {
                    return false;
                }
            }
        }
        if let Some((system, mappings)) = &self.subspace_kummer {
            for (i, wires) in mappings.iter().enumerate() {
                let bits: Vec<_> = wires.iter().map(|&w| model[w as usize - 1]).collect();
                if system.decode_x(&bits).ok().as_ref()
                    != Some(&self.decode_block(&self.blocks[i], model))
                {
                    return false;
                }
            }
        }
        let values: Vec<_> = self
            .blocks
            .iter()
            .map(|block| self.decode_block(block, model))
            .collect();
        if let Some(codes) = &self.terminal_pairs {
            let code = values[2].to_biguint() | (values[3].to_biguint() << self.n as usize);
            if codes.binary_search(&code).is_err() {
                return false;
            }
        }
        if self.intermediate_trace_enforced {
            for step in 1..self.m - 1 {
                if self.identity_mask & (1 << (step - 1)) == 0
                    && values[self.m + step - 1].trace(&self.irr) != 0
                {
                    return false;
                }
            }
        }
        if self.target_x.as_ref() != Some(&values[2 * self.m - 2])
            && !(self.target_x.is_none() && values[2 * self.m - 2].is_zero())
        {
            return false;
        }
        let mut previous = &values[0];
        for step in 1..self.m {
            let output = if step == self.m - 1 {
                &values[2 * self.m - 2]
            } else {
                &values[self.m + step - 1]
            };
            let previous_infinity = step > 1 && (self.identity_mask & (1 << (step - 2))) != 0;
            let output_infinity = if step == self.m - 1 {
                self.target_x.is_none()
            } else {
                (self.identity_mask & (1 << (step - 1))) != 0
            };
            let valid = match (previous_infinity, output_infinity) {
                (true, true) => false,
                (true, false) => output == &values[step],
                (false, true) => previous == &values[step],
                (false, false) => {
                    binary_semaev_s3(previous, &values[step], output, &self.b, &self.irr).is_zero()
                }
            };
            if !valid || (step < self.m - 1 && output_infinity && !output.is_zero()) {
                return false;
            }
            previous = output;
        }
        true
    }
}

fn add_frobenius_orbit_domain(
    solver: &mut Solver,
    block: &[u32],
    representatives: &[BigUint],
    irr: &IrreduciblePoly,
    shared: Option<&[Option<bool>]>,
) -> FrobeniusOrbitChoiceWires {
    fn take(next: &mut u32, count: usize) -> Vec<u32> {
        let start = *next;
        *next += count as u32;
        (start..*next).collect()
    }

    let n = block.len();
    let r = representatives.len();
    let bits = (u32::BITS - ((n as u32) - 1).leading_zeros()) as usize;
    let size = frobenius_orbit_domain_size(n as u32, 1, r).expect("preflighted domain");
    let allocated = solver.add_vars(size.variables as u32);
    let mut next = *allocated.start();
    let selectors = take(&mut next, r);
    let prefix = take(&mut next, r - 1);
    let root = take(&mut next, n);
    let phase = take(&mut next, bits);
    let shared_units: Vec<Lit> = shared
        .into_iter()
        .flat_map(|bits| root.iter().zip(bits))
        .filter_map(|(&wire, value)| {
            value.map(|value| if value { wire as Lit } else { -(wire as Lit) })
        })
        .collect();

    // Sequential exactly-one selection. No quadratic pairwise clauses.
    solver.add_clause(selectors.iter().map(|&v| v as Lit).collect());
    solver.add_clause(vec![-(selectors[0] as Lit), prefix[0] as Lit]);
    for i in 1..r - 1 {
        solver.add_clause(vec![-(selectors[i] as Lit), prefix[i] as Lit]);
        solver.add_clause(vec![-(prefix[i - 1] as Lit), prefix[i] as Lit]);
        solver.add_clause(vec![-(selectors[i] as Lit), -(prefix[i - 1] as Lit)]);
    }
    solver.add_clause(vec![-(selectors[r - 1] as Lit), -(prefix[r - 2] as Lit)]);
    for (&selector, rep) in selectors.iter().zip(representatives) {
        for (bit, &wire) in root.iter().enumerate() {
            if shared.is_some_and(|bits| bits[bit].is_some()) {
                continue;
            }
            solver.add_clause(vec![
                -(selector as Lit),
                if rep.bit(bit as u64) {
                    wire as Lit
                } else {
                    -(wire as Lit)
                },
            ]);
        }
    }

    // Bits encode an exponent in 0..n-1; every other 7-bit value at N83
    // is explicitly forbidden. Compose powers 1,2,4,... of Frobenius.
    for value in n..(1usize << bits) {
        solver.add_clause(
            phase
                .iter()
                .enumerate()
                .map(|(bit, &wire)| {
                    if (value >> bit) & 1 == 1 {
                        -(wire as Lit)
                    } else {
                        wire as Lit
                    }
                })
                .collect(),
        );
    }
    let mut current = root;
    for (power, &choose) in phase.iter().enumerate() {
        let shifted = take(&mut next, n);
        let output = take(&mut next, n);
        let mut rows = vec![Vec::new(); n];
        for (input, &wire) in current.iter().enumerate() {
            let basis = F2mElement::from_bit_positions(&[input as u32], n as u32);
            let image = basis.square_k_times(1u32 << power, irr).to_biguint();
            for (bit, row) in rows.iter_mut().enumerate() {
                if image.bit(bit as u64) {
                    row.push(wire);
                }
            }
        }
        for bit in 0..n {
            rows[bit].push(shifted[bit]);
            solver.add_xor(&rows[bit], false);
            let (input, transformed, result) =
                (current[bit] as Lit, shifted[bit] as Lit, output[bit] as Lit);
            let choose = choose as Lit;
            solver.add_clause(vec![choose, -input, result]);
            solver.add_clause(vec![choose, input, -result]);
            solver.add_clause(vec![-choose, -transformed, result]);
            solver.add_clause(vec![-choose, transformed, -result]);
        }
        current = output;
    }
    for (&output, &summand) in current.iter().zip(block) {
        solver.add_xor(&[output, summand], false);
    }
    // Keep these units last so installed-clause counts match preflight even
    // when the SAT solver eagerly simplifies against assigned root wires.
    for unit in shared_units {
        solver.add_clause(vec![unit]);
    }
    debug_assert_eq!(next - 1, *allocated.end());
    FrobeniusOrbitChoiceWires { selectors, phase }
}

/// Enforce unsigned `a <= b`, with the highest field bit most significant.
/// Equality forces each next prefix wire true; no other assignment is lost.
fn add_lex_leq(solver: &mut Solver, a: &[u32], b: &[u32]) {
    debug_assert_eq!(a.len(), b.len());
    let top = a.len() - 1;
    let aux: Vec<Lit> = solver
        .add_vars(top as u32)
        .map(|wire| wire as Lit)
        .collect();
    solver.add_clause(vec![-(a[top] as Lit), b[top] as Lit]);
    for bit in (0..top).rev() {
        let above = if bit + 1 < top {
            Some(aux[bit + 1])
        } else {
            None
        };
        for (left, right) in [
            (a[bit + 1] as Lit, b[bit + 1] as Lit),
            (-(a[bit + 1] as Lit), -(b[bit + 1] as Lit)),
        ] {
            let mut clause = vec![left, right, aux[bit]];
            if let Some(prefix) = above {
                clause.push(-prefix);
            }
            solver.add_clause(clause);
        }
        solver.add_clause(vec![-aux[bit], -(a[bit] as Lit), b[bit] as Lit]);
    }
}

pub(crate) fn add_coordinate_domain(
    solver: &mut Solver,
    block: &[u32],
    codes: &[BigUint],
    bit: usize,
) {
    fn visit(
        solver: &mut Solver,
        block: &[u32],
        codes: &[BigUint],
        bit: usize,
        prefix: &mut Vec<Lit>,
    ) {
        if codes.is_empty() {
            solver.add_clause(prefix.clone());
            return;
        }
        if bit == 0 {
            return;
        }
        let position = bit - 1;
        let split = codes.partition_point(|code| !code.bit(position as u64));
        let wire = block[position] as Lit;
        prefix.push(wire);
        visit(solver, block, &codes[..split], position, prefix);
        *prefix.last_mut().expect("pushed") = -wire;
        visit(solver, block, &codes[split..], position, prefix);
        prefix.pop();
    }
    visit(solver, block, codes, bit, &mut Vec::new());
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::binary_ecc::BinaryPoint;
    use crate::cryptanalysis::koblitz_index_calculus::KoblitzCurve;
    use crate::cryptanalysis::sat::{RootPropagationResult, SolveResult, SolverProgress};
    use std::sync::Arc;
    use std::time::Instant;

    #[test]
    fn first_pair_lex_constraint_keeps_exactly_one_swap_orientation() {
        for width in 1..=4usize {
            let mut solver = Solver::new((2 * width) as u32);
            let a: Vec<u32> = (1..=width as u32).collect();
            let b: Vec<u32> = ((width + 1) as u32..=(2 * width) as u32).collect();
            add_lex_leq(&mut solver, &a, &b);
            let mut seen = std::collections::HashSet::new();
            while solver.solve() == SolveResult::Sat {
                let model = solver.model();
                let code = |first: usize| {
                    (0..width).fold(0u32, |word, bit| {
                        word | (u32::from(model[first + bit]) << bit)
                    })
                };
                let pair = (code(0), code(width));
                assert!(pair.0 <= pair.1);
                assert!(seen.insert(pair));
                solver.reset_search();
                solver.add_clause(
                    (0..2 * width)
                        .map(|bit| {
                            if model[bit] {
                                -((bit + 1) as Lit)
                            } else {
                                (bit + 1) as Lit
                            }
                        })
                        .collect(),
                );
            }
            let choices = 1usize << width;
            assert_eq!(seen.len(), choices * (choices + 1) / 2);
        }
    }

    #[test]
    fn first_pair_order_cap_is_checked_before_mutation() {
        let irr = IrreduciblePoly {
            degree: 7,
            low_terms: vec![0, 1],
        };
        let mut encoding =
            ChainedS3Encoding::build(5, &irr, &F2mElement::one(7), None, 0, 2_000).unwrap();
        encoding
            .constrain_summands(&[BigUint::from(1u8), BigUint::from(2u8)], 1_000)
            .unwrap();
        let variables = encoding.solver.n_vars();
        let clauses = encoding.solver.n_clauses();
        assert!(matches!(
            encoding.order_first_pair(variables + 5),
            Err(ChainBuildError::VariableCap { required, .. }) if required == u64::from(variables + 6)
        ));
        assert_eq!(encoding.solver.n_vars(), variables);
        assert_eq!(encoding.solver.n_clauses(), clauses);
        encoding.order_first_pair(variables + 6).unwrap();
        assert_eq!(encoding.solver.n_vars(), variables + 6);
        // Root assignments from the finite domain may remove clauses.
        assert!((clauses + 1..=clauses + 19).contains(&encoding.solver.n_clauses()));
        assert!(matches!(
            encoding.order_first_pair(variables + 12),
            Err(ChainBuildError::Unsupported)
        ));
    }

    #[test]
    fn product_gates_match_field_multiplication_and_reject_a_wrong_output() {
        for n in [7u32, 9] {
            let irr = match n {
                7 => IrreduciblePoly {
                    degree: 7,
                    low_terms: vec![0, 1],
                },
                _ => IrreduciblePoly {
                    degree: 9,
                    low_terms: vec![0, 4],
                },
            };
            for (a, b) in [(3u32, 7u32), (65, 31), (127, 255)] {
                let left = F2mElement::from_biguint(&BigUint::from(a), n);
                let right = F2mElement::from_biguint(&BigUint::from(b), n);
                let expected = left.mul(&right, &irr).to_biguint();
                for kernel in [
                    ChainProductKernel::Schoolbook,
                    ChainProductKernel::Karatsuba,
                    ChainProductKernel::ShallowKaratsuba,
                ] {
                    let mut circuit = Circuit::new_with_kernel(&irr, kernel);
                    let x = circuit.block();
                    let y = circuit.block();
                    let z = circuit.product(&x, &y);
                    for (bit, &wire) in x.iter().enumerate() {
                        circuit
                            .units
                            .push((wire, left.to_biguint().bit(bit as u64)));
                    }
                    for (bit, &wire) in y.iter().enumerate() {
                        circuit
                            .units
                            .push((wire, right.to_biguint().bit(bit as u64)));
                    }
                    let mut solver = circuit.finish();
                    assert_eq!(solver.solve(), SolveResult::Sat);
                    let model = solver.model();
                    let actual =
                        BigUint::from(z.iter().enumerate().fold(0u32, |bits, (bit, &wire)| {
                            bits | (u32::from(model[wire as usize - 1]) << bit)
                        }));
                    assert_eq!(actual, expected);
                    solver.reset_search();
                    solver.add_clause(vec![if expected.bit(0) {
                        -(z[0] as Lit)
                    } else {
                        z[0] as Lit
                    }]);
                    assert_eq!(solver.solve(), SolveResult::Unsat);
                }
            }
        }
    }

    #[test]
    fn product_gates_preserve_bits_above_one_word_in_the_pinned_field() {
        let n = 83u32;
        let irr = IrreduciblePoly {
            degree: n,
            low_terms: vec![0, 1, 2, 45],
        };
        let left_bits =
            (BigUint::from(1u8) << 82) | (BigUint::from(1u8) << 64) | BigUint::from(9u8);
        let right_bits =
            (BigUint::from(1u8) << 81) | (BigUint::from(1u8) << 65) | BigUint::from(3u8);
        let left = F2mElement::from_biguint(&left_bits, n);
        let right = F2mElement::from_biguint(&right_bits, n);
        let expected = left.mul(&right, &irr).to_biguint();
        for kernel in [
            ChainProductKernel::Karatsuba,
            ChainProductKernel::ShallowKaratsuba,
        ] {
            let mut circuit = Circuit::new_with_kernel(&irr, kernel);
            let x = circuit.block();
            let y = circuit.block();
            let z = circuit.product(&x, &y);
            assert!(circuit.ands.len() < (n as usize) * (n as usize));
            for (bit, &wire) in x.iter().enumerate() {
                circuit.units.push((wire, left_bits.bit(bit as u64)));
            }
            for (bit, &wire) in y.iter().enumerate() {
                circuit.units.push((wire, right_bits.bit(bit as u64)));
            }
            let mut solver = circuit.finish();
            assert_eq!(solver.solve(), SolveResult::Sat);
            let model = solver.model();
            for (bit, &wire) in z.iter().enumerate() {
                assert_eq!(model[wire as usize - 1], expected.bit(bit as u64));
            }
        }
    }

    #[test]
    fn karatsuba_n83_s3_circuit_has_fewer_and_gates() {
        let irr = IrreduciblePoly {
            degree: 83,
            low_terms: vec![0, 1, 2, 45],
        };
        let mut counts = Vec::new();
        for kernel in [
            ChainProductKernel::Schoolbook,
            ChainProductKernel::Karatsuba,
            ChainProductKernel::ShallowKaratsuba,
        ] {
            let mut circuit = Circuit::new_with_kernel(&irr, kernel);
            let x = circuit.block();
            let y = circuit.block();
            let z = circuit.block();
            circuit.s3(&x, &y, &z, &F2mElement::one(83));
            counts.push((circuit.ands.len(), circuit.next - 1, circuit.xors.len()));
        }
        println!(
            "N83 single S3 schoolbook={:?} karatsuba={:?} shallow={:?}",
            counts[0], counts[1], counts[2]
        );
        assert_eq!(counts[0].0, 3 * 83 * 83);
        assert!(counts[1].0 < counts[0].0);
        assert_eq!(counts[2].0, 3 * (2 * 42 * 42 + 41 * 41));
    }

    #[test]
    fn karatsuba_n83_five_sum_build_preserves_explicit_kernel_choice() {
        let irr = IrreduciblePoly {
            degree: 83,
            low_terms: vec![0, 1, 2, 45],
        };
        let b = F2mElement::one(83);
        let target = F2mElement::one(83);
        let schoolbook = ChainedS3Encoding::build(5, &irr, &b, Some(&target), 0, 200_000)
            .expect("schoolbook capacity");
        let karatsuba = ChainedS3Encoding::build_with_kernel(
            5,
            &irr,
            &b,
            Some(&target),
            0,
            200_000,
            ChainProductKernel::Karatsuba,
        )
        .expect("Karatsuba capacity");
        let shallow = ChainedS3Encoding::build_with_kernel(
            5,
            &irr,
            &b,
            Some(&target),
            0,
            200_000,
            ChainProductKernel::ShallowKaratsuba,
        )
        .expect("shallow Karatsuba capacity");
        println!(
            "N83 m5 schoolbook vars={} clauses={} ands={}; karatsuba vars={} clauses={} ands={}; shallow vars={} clauses={} ands={}",
            schoolbook.solver.n_vars(),
            schoolbook.solver.n_clauses(),
            schoolbook.n_and_gates,
            karatsuba.solver.n_vars(),
            karatsuba.solver.n_clauses(),
            karatsuba.n_and_gates,
            shallow.solver.n_vars(),
            shallow.solver.n_clauses(),
            shallow.n_and_gates,
        );
        assert_eq!(schoolbook.n_and_gates, 4 * 3 * 83 * 83);
        assert!(karatsuba.n_and_gates < schoolbook.n_and_gates);
        assert!(karatsuba.solver.n_clauses() < schoolbook.solver.n_clauses());
        assert_eq!(shallow.n_and_gates, 12 * (2 * 42 * 42 + 41 * 41));
        assert!(shallow.solver.n_vars() < schoolbook.solver.n_vars());
        assert!(shallow.solver.n_clauses() < schoolbook.solver.n_clauses());
        let below = karatsuba.solver.n_vars() - 1;
        assert!(matches!(
            ChainedS3Encoding::build_with_kernel(
                5,
                &irr,
                &b,
                Some(&target),
                0,
                below,
                ChainProductKernel::Karatsuba,
            ),
            Err(ChainBuildError::VariableCap { required, maximum })
                if required == u64::from(below + 1) && maximum == below
        ));
    }

    #[test]
    fn s3_circuit_agrees_with_original_field_polynomial_on_roots_and_nonroots() {
        let n = 7u32;
        let irr = IrreduciblePoly {
            degree: n,
            low_terms: vec![0, 1],
        };
        let b = F2mElement::one(n);
        let mut cases = Vec::new();
        let (mut roots, mut nonroots) = (0, 0);
        for x in 0..8u32 {
            for y in 0..8u32 {
                for z in 0..128u32 {
                    let values =
                        [x, y, z].map(|word| F2mElement::from_biguint(&BigUint::from(word), n));
                    let is_root =
                        binary_semaev_s3(&values[0], &values[1], &values[2], &b, &irr).is_zero();
                    if (is_root && roots < 4) || (!is_root && nonroots < 4) {
                        cases.push((values, is_root));
                        if is_root {
                            roots += 1;
                        } else {
                            nonroots += 1;
                        }
                    }
                    if roots == 4 && nonroots == 4 {
                        break;
                    }
                }
                if roots == 4 && nonroots == 4 {
                    break;
                }
            }
            if roots == 4 && nonroots == 4 {
                break;
            }
        }
        assert_eq!((roots, nonroots), (4, 4));
        for (values, is_root) in cases {
            for kernel in [
                ChainProductKernel::Schoolbook,
                ChainProductKernel::Karatsuba,
            ] {
                let mut circuit = Circuit::new_with_kernel(&irr, kernel);
                let blocks = [circuit.block(), circuit.block(), circuit.block()];
                circuit.s3(&blocks[0], &blocks[1], &blocks[2], &b);
                for (block, value) in blocks.iter().zip(values.iter()) {
                    let bits = value.to_biguint();
                    for (bit, &wire) in block.iter().enumerate() {
                        circuit.units.push((wire, bits.bit(bit as u64)));
                    }
                }
                let mut solver = circuit.finish();
                assert_eq!(solver.solve() == SolveResult::Sat, is_root);
            }
        }
    }

    #[test]
    fn source_bound_covers_degree_83_without_constructing_a_model() {
        assert_eq!(chain_s3_max_variables(83, 4), Some(63_578));
        assert_eq!(chain_s3_max_variables(83, 5), Some(84_743));
        assert_eq!(chain_s3_max_variables(83, 6), Some(105_908));
        assert_eq!(chain_s3_max_variables(83, 9), Some(169_403));
        assert_eq!(chain_s3_max_variables(83, 10), Some(190_568));
        assert_eq!(chain_s3_max_variables(83, 7), Some(127_073));
        assert_eq!(chain_s3_max_variables(83, 15), Some(296_393));
        assert_eq!(chain_s3_max_variables(83, 16), None);
        assert_eq!(chain_s3_max_variables(1, 4), None);
        assert_eq!(chain_s3_max_variables(132, 4), None);
        assert_eq!(chain_s3_max_variables(131, 3), Some(104_669));
    }

    #[test]
    fn fifteen_summands_preflight_cap_and_pinned_identity_pattern() {
        let kc = KoblitzCurve::new(0, 7).unwrap();
        let required = chain_s3_max_variables(7, 15).unwrap();
        assert!(matches!(
            ChainedS3Encoding::build(
                15,
                &kc.curve.irreducible,
                &kc.curve.b,
                None,
                0,
                required as u32 - 1
            ),
            Err(ChainBuildError::VariableCap { .. })
        ));
        let p = kc.generator().clone();
        let x = match &p {
            BinaryPoint::Affine { x, .. } => x.clone(),
            _ => unreachable!(),
        };
        // P,-P,P,-P,...,P: each even prefix is infinity. This exercises
        // the highest intermediate-identity bit and the final affine link.
        let mask = (0..13)
            .filter(|i| i % 2 == 0)
            .fold(0u32, |mask, i| mask | (1 << i));
        let mut enc = ChainedS3Encoding::build(
            15,
            &kc.curve.irreducible,
            &kc.curve.b,
            Some(&x),
            mask,
            required as u32,
        )
        .unwrap();
        for i in 0..15 {
            enc.pin_x_block(i, &x).unwrap();
        }
        let zero = F2mElement::zero(7);
        for i in 0..13 {
            enc.pin_x_block(15 + i, if i % 2 == 0 { &zero } else { &x })
                .unwrap();
        }
        assert_eq!(enc.solver.solve(), SolveResult::Sat);
        assert!(enc.verify_model());
        assert_eq!(enc.decode_summands(), vec![x; 15]);
    }

    #[test]
    fn named_complete_witness_pins_all_four_summand_chain_blocks() {
        let kc = KoblitzCurve::new(0, 7).unwrap();
        let generator = kc.generator();
        let xs: Vec<_> = (1..=4u32)
            .map(
                |multiple| match kc.mul(generator, &BigUint::from(multiple)) {
                    BinaryPoint::Affine { x, .. } => x,
                    BinaryPoint::Infinity => panic!("complete witness must be affine"),
                },
            )
            .collect();
        let expected = vec![
            xs[0].clone(),
            xs[0].clone(),
            xs[0].clone(),
            xs[0].clone(),
            xs[1].clone(),
            xs[2].clone(),
            xs[3].clone(),
        ];
        let mut enc = ChainedS3Encoding::build(
            4,
            &kc.curve.irreducible,
            &kc.curve.b,
            Some(&xs[3]),
            0,
            2_000,
        )
        .unwrap();
        let clauses_before_target = enc.solver.n_clauses();
        enc.pin_x_block(6, &xs[3]).unwrap();
        assert_eq!(enc.solver.n_clauses(), clauses_before_target);
        assert_eq!(
            enc.pin_x_block(6, &xs[2]),
            Err(ChainBuildError::Unsupported)
        );
        assert_eq!(
            enc.pin_x_block(7, &xs[3]),
            Err(ChainBuildError::Unsupported)
        );
        for (block, value) in expected.iter().enumerate() {
            enc.pin_x_block(block, value).unwrap();
        }
        assert_eq!(enc.solver.propagate_root(), RootPropagationResult::Fixpoint);
        assert_eq!(enc.solver.solve(), SolveResult::Sat);
        assert!(enc.verify_model());
        assert_eq!(enc.decode_x_blocks(), expected);
    }

    #[test]
    fn orbit_choice_observer_preserves_small_chain_group_lift_and_records_overhead() {
        fn affine_x(point: &BinaryPoint) -> F2mElement {
            match point {
                BinaryPoint::Affine { x, .. } => x.clone(),
                BinaryPoint::Infinity => panic!("small control point is infinity"),
            }
        }

        let kc = KoblitzCurve::new(0, 7).unwrap();
        let generator = kc.generator();
        let p = kc.mul(generator, &BigUint::from(1u32));
        let q = kc.mul(generator, &BigUint::from(2u32));
        let three = kc.mul(generator, &BigUint::from(3u32));
        let target = kc.mul(generator, &BigUint::from(5u32));
        let (xp, xq, x3, xt) = (
            affine_x(&p),
            affine_x(&q),
            affine_x(&three),
            affine_x(&target),
        );
        assert_ne!(xp, xq);
        let expected = vec![
            xp.clone(),
            xp.clone(),
            xp.clone(),
            xq.clone(),
            xq.clone(),
            x3,
            xt.clone(),
        ];
        let representatives = vec![xp.to_biguint(), xq.to_biguint()];
        let mut sorted_representatives = representatives.clone();
        sorted_representatives.sort_unstable();

        let make = || {
            let mut enc = ChainedS3Encoding::build(
                4,
                &kc.curve.irreducible,
                &kc.curve.b,
                Some(&xt),
                0,
                2_000,
            )
            .unwrap();
            enc.constrain_frobenius_orbit_summands(&representatives, 2_000, 10_000)
                .unwrap();
            for (block, x) in expected.iter().enumerate() {
                enc.pin_x_block(block, x).unwrap();
            }
            let handles = enc.orbit_choice_wires().unwrap().to_vec();
            assert_eq!(handles.len(), 4);
            for (slot, x) in expected[..4].iter().enumerate() {
                let index = sorted_representatives
                    .binary_search(&x.to_biguint())
                    .unwrap();
                assert_eq!(handles[slot].selectors.len(), 2);
                assert_eq!(handles[slot].phase.len(), 3);
                assert!(enc
                    .solver
                    .add_clause(vec![handles[slot].selectors[index] as Lit]));
                for &wire in &handles[slot].phase {
                    assert!(enc.solver.add_clause(vec![-(wire as Lit)]));
                }
            }
            enc
        };

        let run = |mut enc: ChainedS3Encoding, observed: bool, contradiction: bool| {
            if contradiction {
                let wrong = if xp.to_biguint().bit(0) { -1 } else { 1 };
                enc.solver.add_clause(vec![wrong]);
            }
            let progress = observed.then(|| Arc::new(SolverProgress::default()));
            if let Some(progress) = &progress {
                enc.solver.set_progress_observer(Arc::clone(progress));
            }
            let result = enc.solver.solve();
            let model = if result == SolveResult::Sat {
                assert!(!contradiction);
                assert!(enc.verify_model());
                assert_eq!(enc.decode_x_blocks(), expected);
                let mut lifted_sum = BinaryPoint::Infinity;
                for x in enc.decode_summands() {
                    let lifted = if x == xp {
                        &p
                    } else if x == xq {
                        &q
                    } else {
                        panic!("decoded x was not in the checked lift table")
                    };
                    lifted_sum = kc.add(&lifted_sum, lifted);
                }
                assert_eq!(lifted_sum, target);
                Some(enc.solver.model())
            } else {
                assert_eq!(result, SolveResult::Unsat);
                None
            };
            if let Some(progress) = progress {
                let snapshot = progress.snapshot();
                assert_eq!(snapshot.xor_passes, enc.solver.stats.xor_passes);
                assert_eq!(snapshot.xor_nanoseconds, enc.solver.stats.ns_propagate_xors);
                assert_eq!(snapshot.xor_row_scans, enc.solver.stats.xor_row_scans);
                assert_eq!(snapshot.xor_repivots, enc.solver.stats.xor_repivots);
                assert_eq!(snapshot.xor_row_ops, enc.solver.stats.xor_row_ops);
            }
            (result, model)
        };

        for contradiction in [false, true] {
            assert_eq!(
                run(make(), false, contradiction),
                run(make(), true, contradiction)
            );
        }

        // One-thread, release-mode descriptive overhead control. Preparation
        // is outside each timed interval; both arms verify every answer.
        for repetition in 0..20 {
            let order = if repetition % 2 == 0 { [0, 1] } else { [1, 0] };
            let mut elapsed = [0u128; 2];
            for arm in order {
                let cases: Vec<_> = (0..100).map(|_| make()).collect();
                let start = Instant::now();
                for enc in cases {
                    assert_eq!(run(enc, arm == 1, false).0, SolveResult::Sat);
                }
                elapsed[arm] = start.elapsed().as_nanos();
            }
            println!(
                "{{\"schema\":\"n83.selector-small-observer-overhead/v1\",\"repetition\":{repetition},\"order\":\"{}\",\"direct_ns\":{},\"observed_ns\":{}}}",
                if repetition % 2 == 0 { "AB" } else { "BA" },
                elapsed[0],
                elapsed[1],
            );
        }
    }

    #[test]
    fn intermediate_and_final_identity_patterns_preserve_real_group_sums() {
        let kc = KoblitzCurve::new(0, 7).unwrap();
        let point = kc.generator();
        let BinaryPoint::Affine { x: point_x, .. } = point else {
            panic!("generator is affine");
        };
        let three = kc.mul(point, &BigUint::from(3u32));
        let BinaryPoint::Affine { x: three_x, .. } = three else {
            panic!("three times generator is affine");
        };
        // P + (-P) + P + P + P = 3P. The first internal sum is O.
        let mut affine = ChainedS3Encoding::build(
            5,
            &kc.curve.irreducible,
            &kc.curve.b,
            Some(&three_x),
            0b001,
            2_000,
        )
        .unwrap();
        affine
            .constrain_summands(&[point_x.to_biguint()], 1_000)
            .unwrap();
        assert_eq!(affine.solver.solve(), SolveResult::Sat);
        assert!(affine.verify_model());
        assert!(affine.decode_summands().iter().all(|x| x == point_x));
        let external = affine.solver.model();
        assert!(affine.verify_external_assignment(&external));
        assert_eq!(
            affine.decode_summands_assignment(&external),
            Some(affine.decode_summands())
        );
        let mut tampered = external.clone();
        tampered[0] = !tampered[0];
        assert!(!affine.verify_external_assignment(&tampered));
        assert!(!affine.verify_external_assignment(&external[..external.len() - 1]));

        // Three P,-P pairs sum to O. Internal sums after 2 and 4 points
        // are O, while the intermediate sums after 3 and 5 are affine.
        let mut identity =
            ChainedS3Encoding::build(6, &kc.curve.irreducible, &kc.curve.b, None, 0b0101, 2_000)
                .unwrap();
        identity
            .constrain_summands(&[point_x.to_biguint()], 1_000)
            .unwrap();
        assert_eq!(identity.solver.solve(), SolveResult::Sat);
        assert!(identity.verify_model());
        assert!(identity.decode_summands().iter().all(|x| x == point_x));
    }

    #[test]
    fn finite_domain_clause_preflight_is_exact_and_rejects_before_installation() {
        let codes = [BigUint::from(0u32), BigUint::from(1u32)];
        assert_eq!(finite_domain_clause_count(&codes, 3, 5), Some(10));
        let kc = KoblitzCurve::new(0, 7).unwrap();
        let mut enc =
            ChainedS3Encoding::build(5, &kc.curve.irreducible, &kc.curve.b, None, 0, 2_000)
                .unwrap();
        let before = enc.solver.n_clauses();
        let required = finite_domain_clause_count(&codes, 7, 5).unwrap();
        assert_eq!(
            enc.constrain_summands(&codes, required - 1),
            Err(ChainBuildError::DomainClauseCap {
                required,
                maximum: required - 1,
            })
        );
        assert_eq!(enc.solver.n_clauses(), before);
        assert_eq!(enc.constrain_summands(&codes, required), Ok(required));
        assert_eq!(enc.solver.n_clauses(), before + required);
    }

    #[test]
    fn frobenius_orbit_domain_accepts_exactly_the_small_field_closure() {
        let irr = IrreduciblePoly {
            degree: 3,
            low_terms: vec![0, 1],
        };
        for pair in [[1u8, 2], [1, 3], [1, 6]] {
            let representatives = pair.map(BigUint::from);
            let mut closure = std::collections::BTreeSet::new();
            for representative in &representatives {
                let mut value = F2mElement::from_biguint(representative, 3);
                for _ in 0..3 {
                    closure.insert(value.to_biguint());
                    value = value.square(&irr);
                }
            }
            for encoding in [
                FrobeniusOrbitRootEncoding::PerRepresentative,
                FrobeniusOrbitRootEncoding::SharedBits,
            ] {
                let shared = (encoding == FrobeniusOrbitRootEncoding::SharedBits)
                    .then(|| shared_root_bits(3, &representatives));
                let size =
                    frobenius_orbit_domain_size_with_encoding(3, 1, &representatives, encoding)
                        .unwrap();
                for x in 0..8u8 {
                    let mut solver = Solver::new(3);
                    let before = (solver.n_vars(), solver.n_clauses(), solver.n_xors());
                    add_frobenius_orbit_domain(
                        &mut solver,
                        &[1, 2, 3],
                        &representatives,
                        &irr,
                        shared.as_deref(),
                    );
                    assert_eq!(solver.n_vars() as u64 - before.0 as u64, size.variables);
                    assert_eq!(solver.n_clauses() - before.1, size.clauses);
                    assert_eq!(solver.n_xors() - before.2, size.xor_rows);
                    for bit in 0..3 {
                        solver.add_clause(vec![if x & (1 << bit) != 0 {
                            (bit + 1) as Lit
                        } else {
                            -((bit + 1) as Lit)
                        }]);
                    }
                    assert_eq!(
                        solver.solve() == SolveResult::Sat,
                        closure.contains(&BigUint::from(x)),
                        "pair={pair:?} encoding={encoding:?} x={x}"
                    );
                }
            }
        }
        assert_eq!(
            shared_root_bits(3, &[1u8.into(), 3u8.into()]),
            vec![Some(true), None, Some(false)]
        );
        assert_eq!(
            shared_root_bits(3, &[1u8.into(), 6u8.into()]),
            vec![None, None, None]
        );
        assert!(frobenius_orbit_domain_size_with_encoding(
            3,
            1,
            &[1u8.into(), 1u8.into()],
            FrobeniusOrbitRootEncoding::SharedBits
        )
        .is_none());
        assert!(frobenius_orbit_domain_size_with_encoding(
            3,
            1,
            &[1u8.into(), 8u8.into()],
            FrobeniusOrbitRootEncoding::SharedBits
        )
        .is_none());
    }

    #[test]
    fn orbit_choice_wires_pin_the_selected_root_and_phase() {
        let irr = IrreduciblePoly {
            degree: 3,
            low_terms: vec![0, 1],
        };
        let representatives = [BigUint::from(1u8), BigUint::from(3u8)];
        let shared = shared_root_bits(3, &representatives);
        let expected = F2mElement::from_biguint(&representatives[1], 3)
            .square(&irr)
            .to_biguint();
        for x in 0..8u8 {
            let mut solver = Solver::new(3);
            let wires = add_frobenius_orbit_domain(
                &mut solver,
                &[1, 2, 3],
                &representatives,
                &irr,
                Some(&shared),
            );
            assert_eq!(wires.selectors.len(), 2);
            assert_eq!(wires.phase.len(), 2);
            solver.add_clause(vec![wires.selectors[1] as Lit]);
            solver.add_clause(vec![wires.phase[0] as Lit]);
            solver.add_clause(vec![-(wires.phase[1] as Lit)]);
            for bit in 0..3u8 {
                let wire = bit as Lit + 1;
                solver.add_clause(vec![if x & (1 << bit) != 0 { wire } else { -wire }]);
            }
            assert_eq!(
                solver.solve() == SolveResult::Sat,
                expected == BigUint::from(x)
            );
        }
    }

    #[test]
    fn frobenius_orbit_preflight_caps_before_mutation_and_counts_n83() {
        assert_eq!(
            frobenius_orbit_domain_size(83, 4, 2_001),
            Some(FrobeniusOrbitDomainSize {
                variables: 21_012,
                clauses: 697_808,
                xor_rows: 2_656,
            })
        );
        assert_eq!(
            frobenius_orbit_domain_size(83, 5, 2_001),
            Some(FrobeniusOrbitDomainSize {
                variables: 26_265,
                clauses: 872_260,
                xor_rows: 3_320,
            })
        );
        let kc = KoblitzCurve::new(0, 7).unwrap();
        let mut enc =
            ChainedS3Encoding::build(5, &kc.curve.irreducible, &kc.curve.b, None, 0, 2_000)
                .unwrap();
        let reps = [BigUint::from(1u8), BigUint::from(2u8)];
        let size = frobenius_orbit_domain_size(7, 5, reps.len()).unwrap();
        let before = (
            enc.solver.n_vars(),
            enc.solver.n_clauses(),
            enc.solver.n_xors(),
        );
        assert_eq!(
            enc.constrain_frobenius_orbit_summands(&reps, before.0, size.clauses),
            Err(ChainBuildError::VariableCap {
                required: before.0 as u64 + size.variables,
                maximum: before.0,
            })
        );
        assert_eq!(
            enc.constrain_frobenius_orbit_summands(
                &reps,
                before.0 + size.variables as u32,
                size.clauses - 1,
            ),
            Err(ChainBuildError::DomainClauseCap {
                required: size.clauses,
                maximum: size.clauses - 1,
            })
        );
        assert_eq!(
            (
                enc.solver.n_vars(),
                enc.solver.n_clauses(),
                enc.solver.n_xors(),
            ),
            before
        );
        assert_eq!(
            enc.constrain_frobenius_orbit_summands(
                &reps,
                before.0 + size.variables as u32,
                size.clauses,
            ),
            Ok(size)
        );
        assert_eq!(enc.solver.n_vars() as u64 - before.0 as u64, size.variables);
        assert_eq!(enc.solver.n_clauses() - before.1, size.clauses);
        assert_eq!(enc.solver.n_xors() - before.2, size.xor_rows);
    }

    #[test]
    fn heterogeneous_orbit_domains_preflight_and_guard_pair_symmetry() {
        let kc = KoblitzCurve::new(0, 7).unwrap();
        let BinaryPoint::Affine { x, .. } = kc.generator() else {
            panic!("generator is affine");
        };
        let point_x = x.to_biguint();
        let alternatives: Vec<_> = (0u8..128)
            .map(BigUint::from)
            .filter(|candidate| candidate != &point_x)
            .take(3)
            .collect();
        let domains = vec![
            vec![point_x.clone(), alternatives[0].clone()],
            vec![
                point_x.clone(),
                alternatives[1].clone(),
                alternatives[2].clone(),
            ],
        ];
        let small = frobenius_orbit_domain_size(7, 1, 2).unwrap();
        let large = frobenius_orbit_domain_size(7, 1, 3).unwrap();
        let size = FrobeniusOrbitDomainSize {
            variables: small.variables + large.variables,
            clauses: small.clauses + large.clauses,
            xor_rows: small.xor_rows + large.xor_rows,
        };
        let mut enc =
            ChainedS3Encoding::build(2, &kc.curve.irreducible, &kc.curve.b, None, 0, 2_000)
                .unwrap();
        let before = (
            enc.solver.n_vars(),
            enc.solver.n_clauses(),
            enc.solver.n_xors(),
        );
        assert_eq!(
            enc.constrain_frobenius_orbit_domains(&domains, before.0, size.clauses),
            Err(ChainBuildError::VariableCap {
                required: u64::from(before.0) + size.variables,
                maximum: before.0,
            })
        );
        assert_eq!(
            enc.constrain_frobenius_orbit_domains(
                &domains,
                before.0 + size.variables as u32,
                size.clauses - 1,
            ),
            Err(ChainBuildError::DomainClauseCap {
                required: size.clauses,
                maximum: size.clauses - 1,
            })
        );
        assert_eq!(
            (
                enc.solver.n_vars(),
                enc.solver.n_clauses(),
                enc.solver.n_xors()
            ),
            before
        );
        assert_eq!(
            enc.constrain_frobenius_orbit_domains(
                &domains,
                before.0 + size.variables as u32,
                size.clauses,
            ),
            Ok(size)
        );
        assert_eq!(
            enc.solver.n_vars() as u64 - u64::from(before.0),
            size.variables
        );
        assert_eq!(enc.solver.n_clauses() - before.1, size.clauses);
        assert_eq!(enc.solver.n_xors() - before.2, size.xor_rows);
        assert_eq!(
            enc.order_first_pair(2_000),
            Err(ChainBuildError::Unsupported)
        );
        assert_eq!(enc.solver.solve(), SolveResult::Sat);
        assert!(enc.verify_model());
        let found = enc.decode_summands();
        assert_eq!(found[0], found[1]);

        let mut equal =
            ChainedS3Encoding::build(2, &kc.curve.irreducible, &kc.curve.b, None, 0, 2_000)
                .unwrap();
        let equal_domains = vec![
            domains[0].clone(),
            domains[0].iter().rev().cloned().collect(),
        ];
        let equal_size = frobenius_orbit_domain_size(7, 2, 2).unwrap();
        equal
            .constrain_frobenius_orbit_domains(&equal_domains, 2_000, equal_size.clauses)
            .unwrap();
        equal.order_first_pair(2_000).unwrap();
        assert_eq!(equal.solver.solve(), SolveResult::Sat);
        assert!(equal.verify_model());
    }
    #[test]
    fn equal_domain_run_ordering_preserves_first_pair_and_preflights_all_edges() {
        let kc = KoblitzCurve::new(0, 7).unwrap();
        let small = vec![BigUint::from(1u8), BigUint::from(2u8)];
        let residual = vec![BigUint::from(3u8), BigUint::from(4u8), BigUint::from(5u8)];
        let domains = vec![
            small.clone(),
            small.iter().rev().cloned().collect(),
            small.clone(),
            small,
            residual.clone(),
            residual.iter().rev().cloned().collect(),
        ];
        let mut enc =
            ChainedS3Encoding::build(6, &kc.curve.irreducible, &kc.curve.b, None, 0, 2_000)
                .unwrap();
        enc.constrain_frobenius_orbit_domains(&domains, 2_000, 1_000_000)
            .unwrap();
        assert_eq!(enc.adjacent_domains_equal, [true, true, true, false, true]);
        enc.order_first_pair(2_000).unwrap();
        let before = (
            enc.solver.n_vars(),
            enc.solver.n_clauses(),
            enc.solver.n_xors(),
        );
        let required = u64::from(before.0) + 3 * 6;
        assert_eq!(
            enc.order_equal_adjacent_summands((required - 1) as u32),
            Err(ChainBuildError::VariableCap {
                required,
                maximum: (required - 1) as u32,
            })
        );
        assert_eq!(
            (
                enc.solver.n_vars(),
                enc.solver.n_clauses(),
                enc.solver.n_xors()
            ),
            before
        );
        assert_eq!(enc.order_equal_adjacent_summands(required as u32), Ok(3));
        assert_eq!(u64::from(enc.solver.n_vars()), required);
        assert_eq!(enc.adjacent_ordered, [true, true, true, false, true]);
        assert_eq!(
            enc.order_equal_adjacent_summands(2_000),
            Err(ChainBuildError::Unsupported)
        );
        assert_eq!(
            enc.order_first_pair(2_000),
            Err(ChainBuildError::Unsupported)
        );
    }
}

impl Circuit {
    fn new_checked(
        irr: &IrreduciblePoly,
        check: &mut impl FnMut() -> Result<(), ChainBuildError>,
    ) -> Result<Self, ChainBuildError> {
        let n = irr.degree as usize;
        let reductions: Vec<_> = (0..2 * n - 1)
            .map(|degree| {
                check()?;
                Ok(reduced_monomial(degree, irr))
            })
            .collect::<Result<_, ChainBuildError>>()?;
        let mut square_inputs = vec![Vec::new(); n];
        for bit in 0..n {
            check()?;
            for &output in &reductions[2 * bit] {
                square_inputs[output].push(bit);
            }
        }
        Ok(Self {
            n,
            product_kernel: ChainProductKernel::Schoolbook,
            fold_constants: false,
            known: Vec::new(),
            next: 1,
            reductions,
            square_inputs,
            ands: Vec::new(),
            xors: Vec::new(),
            units: Vec::new(),
            impossible: false,
        })
    }

    fn product_checked(
        &mut self,
        left: &[u32],
        right: &[u32],
        check: &mut impl FnMut() -> Result<(), ChainBuildError>,
    ) -> Result<Vec<u32>, ChainBuildError> {
        let mut rows = vec![Vec::new(); self.n];
        for (i, &a) in left.iter().enumerate() {
            check()?;
            for (j, &b) in right.iter().enumerate() {
                let gate = self.wire();
                self.ands.push((gate, a, b));
                for &output in &self.reductions[i + j] {
                    rows[output].push(gate);
                }
            }
        }
        let output = self.block();
        for (bit, mut row) in rows.into_iter().enumerate() {
            row.push(output[bit]);
            self.xors.push((row, false));
        }
        Ok(output)
    }

    fn s3_checked(
        &mut self,
        x: &[u32],
        y: &[u32],
        z: &[u32],
        b: &F2mElement,
        check: &mut impl FnMut() -> Result<(), ChainBuildError>,
    ) -> Result<(), ChainBuildError> {
        let sum = self.block();
        for bit in 0..self.n {
            self.xors.push((vec![sum[bit], x[bit], y[bit]], false));
        }
        let xy = self.product_checked(x, y, check)?;
        let sum_z = self.product_checked(&sum, z, check)?;
        let xyz = self.product_checked(&xy, z, check)?;
        let b_bits = b.to_biguint();
        for output in 0..self.n {
            check()?;
            let mut row = vec![xyz[output]];
            for &input in &self.square_inputs[output] {
                row.extend([xy[input], sum_z[input]]);
            }
            self.xors.push((row, b_bits.bit(output as u64)));
        }
        Ok(())
    }
}

fn prepare_circuit_checked(
    m: usize,
    irr: &IrreduciblePoly,
    b: &F2mElement,
    target_x: Option<&F2mElement>,
    identity_mask: u32,
    max_variables: u32,
    check: &mut impl FnMut() -> Result<(), ChainBuildError>,
) -> Result<(Circuit, Vec<Vec<u32>>, usize), ChainBuildError> {
    let n = irr.degree;
    let Some(required) = chain_s3_max_variables(n, m) else {
        return Err(ChainBuildError::Unsupported);
    };
    if max_variables == 0 || required > u64::from(max_variables) {
        return Err(ChainBuildError::VariableCap {
            required,
            maximum: max_variables,
        });
    }
    if b.m_value() != n
        || target_x.is_some_and(|x| x.m_value() != n)
        || identity_mask >= (1u32 << (m - 2))
        || !irr.low_terms.contains(&0)
        || irr.low_terms.iter().any(|&term| term >= n)
        || {
            let mut terms = irr.low_terms.clone();
            terms.sort_unstable();
            terms.dedup();
            terms.len() != irr.low_terms.len()
        }
    {
        return Err(ChainBuildError::Unsupported);
    }
    let mut circuit = Circuit::new_checked(irr, check)?;
    let blocks: Vec<Vec<u32>> = (0..2 * m - 1).map(|_| circuit.block()).collect();
    let target = &blocks[2 * m - 2];
    let target_bits = target_x.map(F2mElement::to_biguint);
    for (bit, &wire) in target.iter().enumerate() {
        circuit.units.push((
            wire,
            target_bits.as_ref().is_some_and(|x| x.bit(bit as u64)),
        ));
    }

    let mut n_s3_nodes = 0;
    let mut previous = &blocks[0];
    for step in 1..m {
        check()?;
        let output = if step == m - 1 {
            target
        } else {
            &blocks[m + step - 1]
        };
        let previous_infinity = step > 1 && (identity_mask & (1 << (step - 2))) != 0;
        let output_infinity = if step == m - 1 {
            target_x.is_none()
        } else {
            (identity_mask & (1 << (step - 1))) != 0
        };
        if step < m - 1 && output_infinity {
            for &wire in output {
                circuit.units.push((wire, false));
            }
        }
        match (previous_infinity, output_infinity) {
            (true, true) => circuit.impossible = true, // O + affine != O
            (true, false) => circuit.equal(&blocks[step], output),
            (false, true) => circuit.equal(previous, &blocks[step]),
            (false, false) => {
                circuit.s3_checked(previous, &blocks[step], output, b, check)?;
                n_s3_nodes += 1;
            }
        }
        previous = output;
    }
    Ok((circuit, blocks, n_s3_nodes))
}

fn visit_coordinate_domain_checked(
    emit: &mut impl FnMut(Vec<Lit>),
    check: &mut impl FnMut() -> Result<(), ChainBuildError>,
    block: &[u32],
    codes: &[BigUint],
    bit: usize,
) -> Result<(), ChainBuildError> {
    fn visit(
        emit: &mut impl FnMut(Vec<Lit>),
        check: &mut impl FnMut() -> Result<(), ChainBuildError>,
        block: &[u32],
        codes: &[BigUint],
        bit: usize,
        prefix: &mut Vec<Lit>,
    ) -> Result<(), ChainBuildError> {
        check()?;
        if codes.is_empty() {
            emit(prefix.clone());
            return Ok(());
        }
        if bit == 0 {
            return Ok(());
        }
        let position = bit - 1;
        let split = codes.partition_point(|code| !code.bit(position as u64));
        let wire = block[position] as Lit;
        prefix.push(wire);
        visit(emit, check, block, &codes[..split], position, prefix)?;
        *prefix.last_mut().expect("pushed") = -wire;
        visit(emit, check, block, &codes[split..], position, prefix)?;
        prefix.pop();
        Ok(())
    }
    visit(emit, check, block, codes, bit, &mut Vec::new())
}
