use super::program::{equality, Expr};
use super::*;
use crate::ecc::curve::CurveParams;
use crate::ecc::point::Point;
use num_bigint::BigUint;
use num_traits::Zero;
use std::collections::BTreeSet;

/// Small prime used for exhaustive model checks. `p = 1 mod 12` keeps square
/// roots of -1 and primitive cube roots of unity available. Override with
/// `EFD_TEST_P` to re-run the same suite at another such prime (for example 97).
#[inline]
fn prime() -> u64 {
    static PRIME: std::sync::OnceLock<u64> = std::sync::OnceLock::new();
    *PRIME.get_or_init(|| {
        std::env::var("EFD_TEST_P")
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or(109)
    })
}

/// Two upstream `.op3` files compute `-(r1+l3)` where the pinned record says
/// `r2 = -r1+l3`. They are kept byte for byte; verification uses the
/// record-derived fallback for these two, and everything else is compared
/// against the upstream program strictly.
const KNOWN_PROGRAM_DEFECTS: &[(&str, &str)] = &[
    (
        "jintersect/standard/doubling/dbl-2001-ls",
        "op3 computes -(r1+l3); record says -r1+l3",
    ),
        "jintersect/extended/doubling/dbl-2001-ls",
];

type Point2 = Vec<FieldElement>;

fn modulus() -> BigUint {
    static MODULUS: std::sync::OnceLock<BigUint> = std::sync::OnceLock::new();
    MODULUS.get_or_init(|| BigUint::from(prime())).clone()
fn fe(v: u64) -> FieldElement {
    FieldElement::new(BigUint::from(v % prime()), modulus())
fn fe_i(v: i64) -> FieldElement {
    let p = prime() as i64;
    fe((((v % p) + p) % p) as u64)
fn one() -> FieldElement {
    fe(1)
fn zero() -> FieldElement {
    fe(0)

fn coordinates(model: &Model) -> Vec<String> {
    model
        .source
        .text
        .lines()
        .filter_map(|l| l.strip_prefix("coordinate "))
        .map(str::to_owned)
        .collect()

fn relations(model: &Model) -> Vec<(Expr, Expr)> {
        .filter_map(|l| l.strip_prefix("satisfying "))
        .map(|s| equality(s).unwrap())

/// Square root via exhaustive search; only used on the small test field.
fn small_sqrt(v: &FieldElement) -> Option<FieldElement> {
    if v.is_zero() {
        return Some(zero());
    }
    (0..prime()).map(fe).find(|x| x.mul(x) == *v)

fn model_points(model: &Model, params: &Bindings) -> Vec<Point2> {
    let coords = coordinates(model);
    let rels = relations(model);
    let mut out = Vec::new();
    if coords.len() == 2 {
        for a in 0..prime() {
            for b in 0..prime() {
                let point = vec![fe(a), fe(b)];
                if satisfies(&coords, &rels, params, &point) {
                    out.push(point);
                }
            }
        }
    } else {
        // Jacobi intersections: s^2+c^2=1 and a s^2+d^2=1.
        let a = params["a"].clone();
        for s in (0..prime()).map(fe) {
            for c in (0..prime()).map(fe) {
                if s.mul(&s).add(&c.mul(&c)) != one() {
                    continue;
                let d2 = one().sub(&a.mul(&s.mul(&s)));
                if let Some(d) = small_sqrt(&d2) {
                    out.push(vec![s.clone(), c.clone(), d.clone()]);
                    if !d.is_zero() {
                        out.push(vec![s.clone(), c.clone(), zero().sub(&d)]);
                    }
    out

fn satisfies(coords: &[String], rels: &[(Expr, Expr)], params: &Bindings, point: &Point2) -> bool {
    let mut v = params.clone();
    for (name, value) in coords.iter().zip(point) {
        v.insert(name.clone(), value.clone());
    rels.iter()
        .all(|(a, b)| a.eval(&modulus(), &v).unwrap() == b.eval(&modulus(), &v).unwrap())

fn oracle(model: &Model, operation: &str, params: &Bindings, args: &[&Point2]) -> Result<Point2> {
    let mut values = params.clone();
    for (i, point) in args.iter().enumerate() {
        for (name, value) in coords.iter().zip(point.iter()) {
            values.insert(format!("{name}{}", i + 1), value.clone());
    let prefix = format!("{operation} ");
    let mut out = Bindings::new();
    for line in model.source.text.lines() {
        let Some(body) = line.strip_prefix(&prefix) else {
            continue;
        };
        let (name, expression) = body.split_once('=').unwrap();
        out.insert(
            name.trim().into(),
            Expr::parse(expression)?.eval(&modulus(), &values)?,
        );
    Ok(coords.iter().map(|c| out[c].clone()).collect())

fn jquartic_params() -> Bindings {
    for c in 1..prime() {
        let rhs = one().sub(&fe(c).mul(&fe(c)));
        if let Some(a) = small_sqrt(&rhs) {
            return Bindings::from([("a".into(), a), ("c".into(), fe(c))]);
    unreachable!("no Jacobi-quartic parameter pair")

fn cube_root_of_unity() -> Option<FieldElement> {
    (2..prime())
        .map(fe)
        .find(|w| w.mul(w).add(w).add(&one()).is_zero())

fn params_for(rep: &Representation) -> Bindings {
    let model = rep.id.split('/').next().unwrap();
    let mut v = Bindings::new();
    match model {
        "shortw" => {
            let a = if rep.id.ends_with("-0") || rep.id == "shortw/w12-0" {
                fe(0)
            } else if rep.id.ends_with("-1") {
                fe_i(-1)
            } else if rep.id.ends_with("-3") {
                fe_i(-3)
            } else {
                fe(2)
            };
            let b = if rep.id == "shortw/w12-0" {
                fe(3)
            v.insert("a".into(), a);
            v.insert("b".into(), b);
        "montgom" => {
            v.insert("a".into(), fe(2));
            v.insert("b".into(), fe(3));
        "edwards" => {
            v.insert("c".into(), fe(1));
            if rep.id.ends_with("/yz") || rep.id.ends_with("/yzsquared") {
                v.insert("r".into(), fe(6));
                v.insert("d".into(), fe(36));
                v.insert("d".into(), fe(3));
        "twisted" => {
            v.insert(
                "a".into(),
                if rep.id.ends_with("-1") {
                    fe_i(-1)
                } else {
                    fe(1)
                },
            );
            v.insert("d".into(), fe(3));
        "twistedhessian" => {
            v.insert("a".into(), fe(1));
        "hessian" => {
            // xmadd charts require a point with X=1; solving
            // y^3 - 3 d y + 2 = 0 at x=1 gives d = (y^3+2)/(3y).
            let y = fe(3);
            let num = y.mul(&y).mul(&y).add(&fe(2));
            let den = fe(3).mul(&y);
            v.insert("d".into(), num.mul(&den.inv().unwrap()));
        "jquartic" => {
            if rep.id.contains("/2") {
                v.extend(jquartic_params());
                v.insert("a".into(), fe(2));
        "jintersect" => {
        "2dik" | "3dik" => {
        other => unreachable!("unknown model {other}"),
    v

/// Formula-level cache parameters that cannot be derived from a definition.
fn special_parameters(formula: &Formula, values: &mut Bindings) {
    if formula.assumptions.iter().any(|s| s.contains('w')) {
        if let Some(w) = cube_root_of_unity() {
            values.entry("w".into()).or_insert(w);

fn encode(
    rep: &Representation,
    params: &Bindings,
    point: &Point2,
    z: &FieldElement,
) -> Result<Bindings> {
    if rep.id.starts_with("jintersect/") {
        rep.encode_jintersection(&modulus(), params, &point[0], &point[1], &point[2], z)
        rep.encode_affine(&modulus(), params, &point[0], &point[1], z)

fn projection(rep: &Representation, point: &Point2) -> Projection {
        return Projection::Triple {
            s: point[0].clone(),
            c: point[1].clone(),
            d: point[2].clone(),
    if rep.id == "edwards/yz" {
        return Projection::Y(point[1].clone());
    if rep.id == "edwards/yzsquared" {
        return Projection::Y2(point[1].mul(&point[1]));
    if rep.id == "shortw/xz" || rep.id == "montgom/xz" {
        return Projection::X(point[0].clone());
    Projection::Full {
        x: point[0].clone(),
        y: point[1].clone(),

fn div(a: &FieldElement, b: &FieldElement) -> FieldElement {
    a.mul(&b.inv_vartime().unwrap())

fn source_digest(s: &Source) {
    let h = crate::hash::sha256::sha256(s.text.as_bytes());
    let hex: String = h.iter().map(|b| format!("{b:02x}")).collect();
    assert_eq!(s.sha256, hex, "{}", s.url);

#[test]
fn complete_pinned_catalogue_and_source_hashes() {
    let c = catalogue();
    assert_eq!(c.schema, "efd-prime-catalogue/v1");
    assert_eq!(c.characteristic, "p");
    assert_eq!(c.formulas.len(), 471);
    assert_eq!(c.representations.len(), 33);
    assert_eq!(c.models.len(), 10);
    let mut ids = BTreeSet::new();
    for model in &c.models {
        source_digest(&model.source);
    for rep in &c.representations {
        source_digest(&rep.source);
    let mut incomplete = 0;
    let mut fallbacks = 0;
    for f in &c.formulas {
        assert!(ids.insert(&f.id));
        source_digest(&f.record);
        source_digest(&f.program);
        match f.compile() {
            Ok(_) => {}
            Err(EfdError::Unsupported(message)) if f.program.text.contains("error:") => {
                incomplete += 1;
                assert!(message.contains("upstream program incomplete"), "{message}");
            Err(e) => panic!("{}: {e}", f.id),
        // Every record states its computation, so every formula is executable
        // through the record-derived fallback when the upstream code is not.
        if f.compile().is_err() {
            assert_eq!(
                f.compile_record().unwrap().source(),
                ProgramSource::RecordFallback
            fallbacks += 1;
    // Six `add-1986-cc*` programs were never emitted by the EFD generator.
    assert_eq!(incomplete, 6);
    assert_eq!(fallbacks, 6);
    for (id, _) in KNOWN_PROGRAM_DEFECTS {
        let f = c.formula(id).unwrap();
        assert!(f.compile().is_ok());
        assert_eq!(
            f.compile_record().unwrap().source(),
            ProgramSource::RecordFallback

fn all_33_formats_roundtrip_scaled_finite_points() {
    let params = |rep: &Representation| params_for(rep);
    for rep in &catalogue().representations {
        let params = params(rep);
        let point: Point2 = if rep.id.starts_with("jintersect/") {
            vec![fe(3), fe(5), fe(7)]
        } else {
            vec![fe(3), fe(5)]
        for z in [1u64, 2, 7] {
            let encoded = encode(rep, &params, &point, &fe(z)).unwrap();
                rep.project(&params, &rep.bind_point(&encoded, 3), 3)
                    .unwrap(),
                projection(rep, &point),
                "{} z={z}",
                rep.id

/// Compare every optimized straight-line program with the independent,
/// unoptimized affine group law in the model record. Exercise both unit and
/// nonunit projective scales. Singular charts and vanishing denominators are
/// skipped; every formula must have at least 8 successful comparisons.
fn all_471_formulas_match_affine_model_laws() {
    let mut coverage = Vec::new();
        let model = catalogue().representation_model(&rep.id).unwrap();
        let params = params_for(rep);
        let points = model_points(model, &params);
        assert!(points.len() > 8, "{}: {} points", rep.id, points.len());
        for formula in catalogue()
            .formulas
            .iter()
            .filter(|f| f.representation == rep.id)
        {
            let known_defect = KNOWN_PROGRAM_DEFECTS
                .iter()
                .find(|(id, _)| *id == formula.id);
            let program = match formula.compile() {
                Ok(program) if known_defect.is_none() => program,
                Ok(_) => {
                    assert!(
                        formula.program.text.contains("-t7"),
                        "{}: expected defect evidence",
                        formula.id
                    );
                    formula.compile_record().unwrap()
                Err(EfdError::Unsupported(_)) => {
                    assert!(formula.program.text.contains("error:"));
                Err(e) => panic!("{}: {e}", formula.id),
            let source = match program.source() {
                ProgramSource::Upstream => "upstream",
                ProgramSource::RecordFallback => "record-fallback",
            let mut passed = 0;
            let mut attempted = 0;
            let limit = (points.len() * points.len() * 2).min(600);
            let unit = |name: &str| {
                formula
                    .assumptions
                    .iter()
                    .any(|s| s.replace(' ', "") == format!("{name}=1"))
            let has_unit_x2 = unit("X2") || unit("S2");
            let has_unit_x1 = unit("X1") || unit("S1");
            let inverted = rep.id.ends_with("/inverted");
            for k in 0..limit {
                attempted += 1;
                let mut p_index = k % points.len();
                let mut q_index = (k / points.len() + k + 3) % points.len();
                if !inverted {
                    if has_unit_x2 {
                        if let Some(i) = points.iter().position(|p| p[0] == one()) {
                            q_index = i;
                        }
                    if has_unit_x1 {
                            p_index = i;
                let p = &points[p_index];
                let q = &points[q_index];
                let attempt = (|| -> Result<()> {
                    let mut inputs = params.clone();
                    special_parameters(formula, &mut inputs);
                    let mut encoded_points: Vec<(u32, Point2)> = vec![(1, p.clone())];
                    let expected: Vec<(u32, Point2)> = match formula.operation.as_str() {
                        "addition" => {
                            encoded_points.push((2, q.clone()));
                            vec![(3, oracle(model, "addition", &params, &[p, q])?)]
                        "doubling" => vec![(3, oracle(model, "doubling", &params, &[p])?)],
                        "tripling" => {
                            let doubled = oracle(model, "doubling", &params, &[p])?;
                            vec![(3, oracle(model, "addition", &params, &[p, &doubled])?)]
                        "scaling" => vec![(3, p.clone())],
                        "diffadd" | "ladder" => {
                            let negated = oracle(model, "negation", &params, &[p])?;
                            let difference = oracle(model, "addition", &params, &[q, &negated])?;
                            encoded_points =
                                vec![(1, difference.clone()), (2, p.clone()), (3, q.clone())];
                            let sum = oracle(model, "addition", &params, &[p, q])?;
                            if formula.operation == "diffadd" {
                                vec![(5, sum)]
                            } else {
                                vec![(4, oracle(model, "doubling", &params, &[p])?), (5, sum)]
                            }
                        other => panic!("uncovered operation {other}"),
                    };
                    for (index, point) in &encoded_points {
                        let index = *index;
                        let z_forced = formula
                            .assumptions
                            .iter()
                            .any(|s| s.replace(' ', "") == format!("Z{index}=1"));
                        let x_forced = (index == 1 && has_unit_x1) || (index == 2 && has_unit_x2);
                        let scale = if x_forced && inverted {
                            point[0].clone()
                        } else if x_forced || z_forced || k % 2 == 0 {
                            one()
                        } else {
                            fe(u64::from(index) + 2)
                        };
                        let encoded = encode(rep, &params, point, &scale)?;
                        inputs.extend(rep.bind_point(&encoded, index));
                    let output = program.evaluate(&modulus(), &inputs)?;
                    for (index, point) in expected {
                        assert_eq!(
                            rep.project(&params, &output, index)?,
                            projection(rep, &point),
                            "{} k={k}",
                            formula.id
                        );
                    Ok(())
                })();
                match attempt {
                    Ok(()) => passed += 1,
                    Err(
                        EfdError::ZeroDenominator
                        | EfdError::OutsideChart
                        | EfdError::Assumption(_),
                    ) => {}
                    Err(e) => panic!("{} k={k}: {e}", formula.id),
                if passed == 32 {
                    break;
            assert!(
                passed >= 8,
                "{}: only {passed} comparable cases (attempted {attempted})",
                formula.id
            coverage.push(serde_json::json!({"formula":formula.id,"prime":prime(),
                "program":source,
                "passed":passed,"attempted":attempted,
                "excluded_singular_or_conditional":attempted-passed}));
    if let Some(path) = std::env::var_os("EFD_COVERAGE_OUT") {
        std::fs::write(path, serde_json::to_vec_pretty(&coverage).unwrap()).unwrap();

fn small_curve(a: u64) -> CurveParams {
    CurveParams {
        name: "efd-test",
        p: modulus(),
        a: BigUint::from(a),
        b: BigUint::from(3u32),
        gx: BigUint::from(0u32),
        gy: BigUint::from(0u32),
        n: BigUint::from(0u32),
        h: 1,

fn shortw_points(curve: &CurveParams) -> Vec<Point> {
    let model = catalogue().model("shortw").unwrap();
    let params = Bindings::from([
        ("a".into(), FieldElement::new(curve.a.clone(), modulus())),
        ("b".into(), FieldElement::new(curve.b.clone(), modulus())),
    ]);
    model_points(model, &params)
        .into_iter()
        .map(|p| Point::Affine {
            x: p[0].clone(),
            y: p[1].clone(),
        })

fn applies(formula: &Formula, curve: &CurveParams) -> bool {
    let rep = &formula.representation;
    if !rep.starts_with("shortw/")
        || rep == "shortw/xz"
        || !matches!(formula.operation.as_str(), "addition" | "doubling")
    {
        return false;
    let p = &curve.p;
    let a = FieldElement::new(curve.a.clone(), p.clone());
    if rep.ends_with("-0") && !a.is_zero() {
    if rep.ends_with("-1") && a != FieldElement::new(p - BigUint::from(1u32), p.clone()) {
    if rep.ends_with("-3") && a != FieldElement::new(p - BigUint::from(3u32), p.clone()) {
    if rep.ends_with("w12-0") && !curve.b.is_zero() {
    true

fn checked_weierstrass_formulas_match_existing_independent_arithmetic() {
    for a in [0u64, prime() - 3] {
        let curve = small_curve(a);
        let a_fe = curve.a_fe();
        let points = shortw_points(&curve);
        assert!(points.len() > 8);
        for formula in catalogue().formulas.iter().filter(|f| applies(f, &curve)) {
            let mut actual_formula = 0;
            for i in 0..points.len() {
                let p = &points[i];
                let q = &points[(i + 5) % points.len()];
                let result = match weierstrass_operation(
                    &curve,
                    &formula.id,
                    p,
                    if formula.operation == "addition" {
                        Some(q)
                    } else {
                        None
                    },
                ) {
                    Ok(result) => result,
                    // xmadd charts require the fixed point X2=1.
                    Err(EfdError::Assumption(_)) => continue,
                    Err(e) => panic!("{}: {e}", formula.id),
                };
                let expected = if formula.operation == "addition" {
                    p.add(q, &a_fe)
                    p.double(&a_fe)
                assert_eq!(result.point, expected, "{} a={a}", formula.id);
                actual_formula += usize::from(result.path == ExecutionPath::Formula);
                actual_formula >= 4,
                "{}: did not exercise formula",

fn large_prime_planted_points_match_existing_arithmetic() {
    // Existing public generators and their small multiples; no imported target.
    for curve in [CurveParams::secp256k1(), CurveParams::p256()] {
        let a = curve.a_fe();
        let p = curve.generator();
        let q = p.double(&a);
        let r = p.add(&q, &a);
            let addition = formula.operation == "addition";
            let result = match weierstrass_operation(
                &curve,
                &formula.id,
                &p,
                if addition { Some(&r) } else { None },
            ) {
                Ok(result) => result,
                Err(EfdError::Assumption(_)) => continue,
                result.path,
                ExecutionPath::Formula,
                "{} p={}",
                formula.id,
                curve.p
                result.point,
                if addition {
                    p.add(&r, &a)
                    p.double(&a)

/// Every published shape and chart must be present, encodable from model
/// parameters alone, and checked against its own `satisfying` equations.
fn all_ten_curve_equations_and_thirty_three_charts_are_covered() {
    let models: BTreeSet<&str> = c.models.iter().map(|m| m.id.as_str()).collect();
    assert_eq!(
        models,
        [
            "2dik",
            "3dik",
            "edwards",
            "hessian",
            "jintersect",
            "jquartic",
            "montgom",
            "shortw",
            "twisted",
            "twistedhessian",
        ]
    );
    let mut seen = BTreeSet::new();
        assert!(seen.insert(rep.id.clone()), "duplicate {}", rep.id);
        let model = c
            .representation_model(&rep.id)
            .unwrap_or_else(|| panic!("{} has no model", rep.id));
        assert!(!rep.variables.is_empty(), "{}", rep.id);
        // Supply model parameters only: `r` and `c` are chart parameters that
        // the representation fixes by `d = r^2` and `a^2+c^2 = 1`.
        let mut params = params_for(rep);
        params.remove("r");
        params.remove("c");
        let point = if rep.id.starts_with("jintersect/") {
        for z in [1u64, 5] {
            model.coordinates().len(),
            if rep.id.starts_with("jintersect/") {
                3
                2
    // Each curve equation is executable and holds on its own enumerated points.
        let rep = c
            .representations
            .find(|r| r.id.split('/').next() == Some(model.id.as_str()))
            .unwrap();
        assert!(
            !relations(model).is_empty(),
            "{}: no satisfying equations",
            model.id
        assert!(points.len() > 8, "{}: {} points", model.id, points.len());
        // The equations must actually constrain the chart.
            points.len() < prime() as usize * prime() as usize,
            "{}: unconstrained",
        for point in &points {
                model.on_model(&modulus(), &params, point).unwrap(),
                "{}",
                model.id
        assert!(model.on_model(&modulus(), &params, &points[0]).unwrap());
        assert_eq!(model.coordinates().len(), points[0].len());
    // Unknown charts fail closed; no projection falls through a default.
    let bogus = Representation {
        id: "bogus/chart".into(),
        page_url: String::new(),
        variables: vec!["X".into(), "Y".into(), "Z".into()],
        relations: vec![],
        assumptions: vec![],
        source: Source {
            url: String::new(),
            sha256: String::new(),
            text: String::new(),
        },
    };
    assert!(matches!(
        bogus.encode_affine(&modulus(), &Bindings::new(), &fe(3), &fe(5), &fe(1)),
        Err(EfdError::Unsupported(_))
    ));
    let values = Bindings::from([
        ("X3".into(), fe(1)),
        ("Y3".into(), fe(1)),
        ("Z3".into(), fe(1)),
        bogus.project(&Bindings::new(), &values, 3),

/// Every model exposes both directions of its Weierstrass bridge, so model
/// conversion is possible (through the hub) for all ten shapes.
fn every_model_has_both_weierstrass_maps() {
    let mut identity = BTreeSet::new();
            !model.to_weierstrass().is_empty(),
            "{}: no toweierstrass",
            !model.from_weierstrass().is_empty(),
            "{}: no fromweierstrass",
        if model.is_identity_weierstrass() {
            identity.insert(model.id.as_str());
    // These four shapes are already Weierstrass models with the same
    // coordinates; the other six need a rational map.
        identity,
        ["2dik", "3dik", "montgom", "shortw"].into_iter().collect()

/// Chart family used by the Lean round-trip proofs. Mirrors the dispatch in
/// `formats.rs`; the Lean manifest lists the same id -> family pairs.
fn chart_family(id: &str) -> u8 {
    match id {
        "shortw/jacobian" | "shortw/jacobian-0" | "shortw/jacobian-3" | "shortw/modified"
        | "3dik/standard" => 2,
        "shortw/projective"
        | "shortw/projective-1"
        | "shortw/projective-3"
        | "edwards/projective"
        | "twisted/projective"
        | "twisted/extended"
        | "twisted/extended-1"
        | "twistedhessian/projective"
        | "hessian/standard"
        | "hessian/extended" => 1,
        "shortw/w12-0" | "jquartic/xyz" | "jquartic/2xyz" | "jquartic/xxyzz"
        | "jquartic/xxyzzr" | "jquartic/2xxyzz" | "jquartic/2xxyzzr" | "jquartic/extended"
        | "2dik/standard" => 3,
        "shortw/xyzz" | "shortw/xyzz-3" => 4,
        "shortw/xz" | "montgom/xz" => 5,
        "edwards/inverted" | "twisted/inverted" => 6,
        "edwards/yz" => 7,
        "edwards/yzsquared" => 8,
        id if id.starts_with("jintersect/") => 9,
        other => panic!("unclassified chart {other}"),

/// Encode constants implied by each Lean proof family.
/// `(x_z_power, y_z_power, inverted)`; families with quotient coordinates are
/// handled separately in the test below.
fn family_constants(family: u8) -> (u32, u32, bool) {
    match family {
        0 => (0, 0, false),
        1 => (1, 1, false),
        2 => (2, 3, false),
        3 => (1, 2, false),
        4 => (2, 3, false),
        6 => (0, 0, true),
        other => panic!("family {other} has quotient/triple coordinates"),

/// Tie the Lean family table to the actual encode constants: for every chart,
/// the raw X/Y written by `formats.rs` must be `x*z^a`, `y*z^b` (or `z/x`,
/// `z/y`) with the exponents that the corresponding Lean theorem proves.
fn chart_family_constants_match_encode() {
    let x = fe(3);
    let y = fe(7);
    let z = fe(5);
    let z2 = z.mul(&z);
    let z3 = z2.mul(&z);
        let family = chart_family(&rep.id);
            vec![fe(3), fe(7)]
        let encoded = encode(rep, &params, &point, &z).unwrap();
        match family {
            1 | 2 | 3 | 4 => {
                let (a, b, _) = family_constants(family);
                let expected_x = if a == 1 { x.mul(&z) } else { x.mul(&z2) };
                let expected_y = match b {
                    1 => y.mul(&z),
                    2 => y.mul(&z2),
                    3 => y.mul(&z3),
                    _ => unreachable!(),
                assert_eq!(encoded["X"], expected_x, "{}", rep.id);
                assert_eq!(encoded["Y"], expected_y, "{}", rep.id);
            5 => assert_eq!(encoded["X"], x.mul(&z), "{}", rep.id),
            6 => {
                assert_eq!(encoded["X"], div(&z, &x), "{}", rep.id);
                assert_eq!(encoded["Y"], div(&z, &y), "{}", rep.id);
            7 => {
                let r = params["r"].clone();
                assert_eq!(encoded["Y"], r.mul(&y).mul(&z), "{}", rep.id);
            8 => {
                assert_eq!(encoded["Y"], r.mul(&y.mul(&y)).mul(&z), "{}", rep.id);
            9 => {
                assert_eq!(encoded["S"], point[0].mul(&z), "{}", rep.id);
                assert_eq!(encoded["C"], point[1].mul(&z), "{}", rep.id);
                assert_eq!(encoded["D"], point[2].mul(&z), "{}", rep.id);
            other => panic!("family {other}"),

/// The Lean development must cover exactly the catalogue charts, with each
/// chart mapped to a family that has a machine-checked round-trip theorem.
fn lean_chart_manifest_matches_catalogue() {
    let lean = include_str!("../../../research/efd_coordinate_charts_20261108/Charts.lean");
    for theorem in [
        "affine_roundtrip",
        "projective_roundtrip",
        "jacobian_roundtrip",
        "xyz_roundtrip",
        "xyzz_roundtrip",
        "x_only_roundtrip",
        "inverted_roundtrip",
        "yz_roundtrip",
        "yzsquared_roundtrip",
        "jintersect_roundtrip",
    ] {
        assert!(lean.contains(&format!("theorem {theorem}")), "{theorem}");
    let start = lean.find("def charts").expect("Lean chart manifest");
    let end = lean[start..].find(']').expect("manifest terminator") + start;
    let body = &lean[start..end];
    let mut entries = Vec::new();
    let mut rest = body;
    while let Some(open) = rest.find("(\"") {
        let after = &rest[open + 2..];
        let close = after.find('"').expect("chart id");
        let id = after[..close].to_owned();
        let tail = &after[close + 1..];
        let comma = tail.find(',').expect("family separator");
        let family_tail = &tail[comma + 1..];
        let paren = family_tail.find(')').expect("family terminator");
        let family: u8 = family_tail[..paren].trim().parse().expect("family code");
        entries.push((id, family));
        rest = &family_tail[paren + 1..];
    assert_eq!(entries.len(), 33, "Lean manifest size");
    let lean_ids: BTreeSet<&str> = entries.iter().map(|(id, _)| id.as_str()).collect();
    let catalogue_ids: BTreeSet<&str> = catalogue()
        .representations
        .iter()
        .map(|r| r.id.as_str())
        .collect();
    assert_eq!(lean_ids, catalogue_ids);
    for (id, family) in entries {
        assert_eq!(family, chart_family(&id), "{id}");

/// The legacy extended Jacobi-quartic section is converted from the old EFD
/// Magma programs and verified against the same pinned affine law.
fn legacy_extended_quartic_formulas_match_affine_law() {
    let c = legacy::catalogue();
    assert_eq!(c.formulas.len(), 15);
        c.source_page_sha256.as_deref(),
        Some(legacy::SOURCE_PAGE_SHA256)
    let model = c.model("jquartic").unwrap();
    let rep = c.representation("jquartic/extended").unwrap();
    // Same x=X/Z, y=Y/Z^2 family as the Lean `xyz_roundtrip` theorem.
    assert_eq!(chart_family(&rep.id), 3);
    let params = Bindings::from([("a".into(), fe(2))]);
    let points = model_points(model, &params);
    assert!(points.len() > 8, "{} points", points.len());
    let mut checked = 0;
    for formula in &c.formulas {
        let program = formula
            .compile_in(c)
            .unwrap_or_else(|e| panic!("{}: {e}", formula.id));
        let mut passed = 0;
        for k in 0..points.len() * points.len() {
            if passed == 16 {
                break;
            let p = &points[k % points.len()];
            let q = &points[(k / points.len() + k + 3) % points.len()];
            let attempt = (|| -> Result<()> {
                let mut inputs = params.clone();
                let mut encoded_points: Vec<(u32, &Point2)> = vec![(1, p)];
                let expected: Vec<(u32, Point2)> = match formula.operation.as_str() {
                    "addition" => {
                        encoded_points.push((2, q));
                        vec![(3, oracle(model, "addition", &params, &[p, q])?)]
                    "doubling" => vec![(3, oracle(model, "doubling", &params, &[p])?)],
                    "tripling" => {
                        let doubled = oracle(model, "doubling", &params, &[p])?;
                        vec![(3, oracle(model, "addition", &params, &[p, &doubled])?)]
                    "scaling" => vec![(2, p.clone())],
                    other => panic!("uncovered operation {other}"),
                for (index, point) in encoded_points {
                    let encoded =
                        rep.encode_affine(&modulus(), &params, &point[0], &point[1], &one())?;
                    inputs.extend(rep.bind_point(&encoded, index));
                let output = program.evaluate(&modulus(), &inputs)?;
                for (index, point) in expected {
                    assert_eq!(
                        rep.project(&params, &output, index)?,
                        projection(rep, &point),
                        "{} k={k}",
                Ok(())
            })();
            match attempt {
                Ok(()) => passed += 1,
                Err(
                    EfdError::ZeroDenominator | EfdError::OutsideChart | EfdError::Assumption(_),
                ) => {}
        assert!(passed >= 8, "{}: only {passed}", formula.id);
        checked += 1;
    assert_eq!(checked, 15);

fn rejects_assumption_field_and_chart_mismatches() {
    let rep = c.representation("shortw/jacobian").unwrap();
    let params = params_for(rep);
    let mut inputs = params.clone();
    inputs.extend(
        rep.bind_point(
            &rep.encode_affine(&modulus(), &params, &fe(1), &fe(2), &fe(2))
                .unwrap(),
            1,
        ),
            &rep.encode_affine(&modulus(), &params, &fe(3), &fe(4), &fe(2))
            2,
    let mixed = c.formula("shortw/jacobian/addition/madd-2007-bl").unwrap();
        mixed.evaluate(&modulus(), &inputs),
        Err(EfdError::Assumption(_))
    inputs.insert("Z2".into(), one());
    let derived = mixed.evaluate(&modulus(), &inputs).unwrap();
    assert!(derived.contains_key("X3"));

    let other = BigUint::from(107u32);
        rep.encode_affine(&other, &params, &fe(1), &fe(2), &fe(1)),
        Err(EfdError::FieldMismatch)
        rep.encode_affine(&modulus(), &params, &fe(1), &fe(2), &zero()),
        Err(EfdError::OutsideChart)
    assert!(Expr::parse("a; panic!()").is_err());
    assert!(Expr::parse("a ^ 100000000").is_err());
        Expr::parse("2d").unwrap(),
        Expr::Variable(ref v) if v == "2d"
        Expr::parse("1/0")
            .unwrap()
            .eval(&modulus(), &Bindings::new()),
        Err(EfdError::ZeroDenominator)

fn preserves_declared_operation_counts() {
    let f = catalogue()
        .formula("shortw/jacobian/doubling/dbl-2007-bl")
        .unwrap();
        f.compile().unwrap().operation_counts(),
        OperationCounts {
            multiplications: 6,
            squarings: 8,
            inversions: 0,
            additions: 10
        .formula("montgom/xz/doubling/dbl-1987-m-3")
            multiplications: 3,
            squarings: 2,
            additions: 4































            1..=4 => {

    for (id, family) in &entries {
        assert_eq!(*family, chart_family(id), "{id}");




