//! # The factor bases, oracles and matrices that ship with the framework.
//!
//! Each of these wraps a component the repository already measures, so
//! a framework run reproduces a ledger row rather than approximating
//! one.  They are also the worked examples: a new plug-in looks like
//! these, and `docs/ic/FRAMEWORK.md` walks through writing one.
//!
//! ## Factor bases
//!
//! | name | regime | what it is |
//! |:--|:--|:--|
//! | `prime-abscissa` | prime | the smallest abscissae carrying a point, one column each |
//! | `known-log` | prime | `±[s_i]G`, one column each, every logarithm known so there is no linear algebra; `scalars=progression` (default) is `s_i = i`, `scalars=random` seeded uniform scalars |
//! | `binary-subspace` | binary, Koblitz | points whose abscissa lies in an `F_2`-subspace |
//! | `koblitz-orbit` | Koblitz | the same, each signed Frobenius orbit folded onto one column |
//! | `compact-orbit-scan` | Koblitz | deterministic raw-abscissa scan, subgroup projection and signed Frobenius closure |
//! | `cyclotomic` | Koblitz, `2n+1` prime | the γ-weight-`w` abscissae `Σ_{k∈S} γ^k` (lead A2), projected and folded like `compact-orbit-scan` |
//! | `onb-weight` | Koblitz, `2n+1` prime | ONB Hamming-weight-`w` abscissae, projected and folded like `cyclotomic` (low-HW D\* hypothesis) |
//! | `glv-orbit` | prime | the closure of the smallest abscissae under the curve's automorphism group, each orbit folded onto one column (`j = 0`: 6 points a column, `j = 1728`: 4, generic: 2) |
//! | `gls-line` | GLS over `F_{p²}` | the `ψ`-stable line `x ∈ u·s·F_p`, each `⟨−1, ψ⟩`-orbit folded onto one column (4 points a column) |
//!
//! The column map is the interesting part.  `koblitz-orbit` gives a
//! whole orbit of `2n` points one unknown, which cuts the relations
//! needed by `2n`; setting its `no_fold` parameter gives the control
//! that shows what the fold buys.  That pair is the one place this
//! ledger records an *advance* in the `AGENTS.md` §3 sense rather than
//! engineering, and it is a two-word change in a sweep file.
//!
//! ## Decomposition oracles
//!
//! | name | summands | how |
//! |:--|:--|:--|
//! | `subtract` | 2 | test `R − P ∈ F` for every signed base point; no table; `batch=1` (default) one field inversion a block of candidates on a prime curve, `batch=0` one a candidate |
//! | `mitm` | 2 or 3 | a pair table probed once per target, or once per `R − P`; `batch=1` (default) builds the table and the `R − P` rows with one field inversion a block on a prime curve, `batch=0` one an addition |
//! | `mitm-prime-batch` | 2 | the same folded prime pair table, built with one batched inversion per abscissa row and x-only sums |
//! | `mitm-prime-blocked` | 2 | the same table and sums again, inserted in cache-sized pieces (many small maps, each block grouped by map) |
//! | `mitm-frobenius` | 2 or 3 | the same on a Frobenius-folded table (Koblitz) |
//! | `mitm-frobenius-counted` | 2 or 3 | the same table and probe, with native table setup counters |
//! | `mitm-frobenius-lazy-counted` | 2 or 3 | the same entries and probe; a hit names its summands' orbit members then, not every base point at build |
//! | `mitm-frobenius-layout-counted` | 2 or 3 | the same entries and probe on a base laid out by orbit (`compact-orbit-scan`): members named by index, and half the same-orbit pairs added |
//! | `rootfind-subtract` | 2 or 3 | prime curves: `prime_fast`'s direct-subtraction root finding, every `x(R ∓ F_i)` of a target from one Montgomery batched inversion, then a lookup (`m = 2`) or a probe of the negation-folded pair table (`m = 3`) |
//! | `mitm-coset` | 2 or 3 | `mitm` over the pairs whose classes in `E/⟨G⟩` cancel (m = 2; binary curves with cofactor > 1); same first witnesses, fewer table additions; labels charged |
//! | `rootfind-floor` | 2 or 3 | same search and charged additions as `rootfind-subtract`, with x-only Montgomery candidates and a word-blocked Bloom filter in front of the exact abscissa map (lever 1 of the 100× plan) |
//! | `rootfind-kmitm` | 3 to 12 | meet-in-the-middle: left=`min(9,m−1)` table (probe-favoring; `split=balanced` for half), Bloom + batch-inv folded probes on primes — `right=1` for `m≤10`; enables `m=10..12` |
//! | `chained-x` | 2, 3 or 4 | Koblitz subspace bases: the chained `x`-frame descent (`groebner_decompose`), `m − 1` Semaev `S₃` links solved by boolean F4 with splitting |
//!
//! The pair table is where memory buys time, and `mitm`'s
//! `negation_folded` parameter halves the additions that build it.

use crate::cryptanalysis::pq_groebner_f2::mask_low64;
use std::collections::{BTreeMap, BTreeSet, HashMap, HashSet};
use std::time::{Duration, Instant};

use num_traits::ToPrimitive;
use rand::SeedableRng;

use super::large_prime::{LargePrimeCollector, LargePrimeConfig};
use super::stages::{
    BooleanSystem, DecompositionOracle, FactorBaseBuilder, InstanceCtx, Params, SolverCost,
    SolverTotals, SolverVerdict, SystemShape, SystemSolver,
};
use crate::cryptanalysis::gls_fp2::{gls_line_base, Fp2Curve, Fp2Point, GlsInstance};
use crate::cryptanalysis::glv_invariant_base::{glv_orbit_base, AutomorphismGroup};
use crate::cryptanalysis::ic_boundary::{
    binary_subspace_factor_base, decompose_mitm, decompose_mitm_frobenius, koblitz_factor_base,
    prime_factor_base, prime_factor_base_strided, BinaryGroup, BinaryInstance, ColumnFold,
    CountedGroup, FactorBase, FrobeniusPairTable, GroupOps, KSumTable, OracleCounters, PairTable,
    PrimeCurve, PrimeInstance, PrimePoint, Relation, TargetWalk, TauOrbitCheck, WSumTable,
    WalkOpts, WalkTable,
};
use crate::cryptanalysis::koblitz_factor_base_search::subspace_is_trace_zero;
use crate::cryptanalysis::koblitz_fast::{with_cached_point_lifts, FastPoint};
use crate::cryptanalysis::koblitz_fast_arith::FastBinaryCurve;
use crate::cryptanalysis::koblitz_groebner::{f4_word_ops_thread, FieldStructure, SolverEngine};
use crate::cryptanalysis::koblitz_index_calculus::build_frobenius_factor_base_from_divisor;
use crate::cryptanalysis::koblitz_symmetrised::{
    build_symmetrised_factor_base, build_symmetrised_system, frobenius_view_of_symmetrised,
    symmetrised_groebner_decompose, SymmetrisedFactorBase,
};
use crate::cryptanalysis::pq_descent_symbolic::{max_n_prime, SymbolicDescent};
use crate::cryptanalysis::prime_fast::{Fp64, MAX_BITS as PRIME_FAST_MAX_BITS};

// ── Factor bases ───────────────────────────────────────────────────

/// The smallest abscissae of a prime-field curve that carry a point,
/// one column each.
pub struct PrimeAbscissaBase<'i> {
    pub instance: &'i PrimeInstance,
}

impl FactorBaseBuilder<PrimeCurve> for PrimeAbscissaBase<'_> {
    fn name(&self) -> &str {
        "prime-abscissa"
    }

    fn describe(&self, params: &Params) -> String {
        if let Some(below) = params.get("below") {
            return format!("every abscissa in [1, {below}) carrying a point, one column each");
        }
        if params.get("size") == Some("auto") {
            return format!(
                "the round({} * r^(1/3)) smallest abscissae carrying a point, one column each",
                params.get("scale").unwrap_or("0.5")
            );
        }
        match params.get("stride") {
            None | Some("1") => format!(
                "the {} smallest abscissae carrying a point, one column each",
                params.get("size").unwrap_or("?")
            ),
            Some(stride) => format!(
                "{} abscissae carrying a point, scanned at stride {stride} modulo p, one column each",
                params.get("size").unwrap_or("?")
            ),
        }
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            (
                "size",
                "abscissae in the base; the family optimum is about #E^(1/3); `auto` takes \
                 round(scale * r^(1/3)), at least 4",
            ),
            (
                "scale",
                "with size=auto: the constant c of B = c * r^(1/3); default 0.5 (the pair-table \
                 oracle's B(B+1) build against its r * N/(2B^2) trials with N ~ 0.6 B)",
            ),
            (
                "stride",
                "fixed nonzero abscissa stride modulo p; default 1",
            ),
            (
                "below",
                "instead of size: every abscissa in [1, below) carrying a point (Semaev's naive \
                 small-abscissa base; with below = 2^T it is the point set of pkm-semaev's bits=T)",
            ),
        ]
    }

    fn build(
        &self,
        _ctx: &InstanceCtx<PrimeCurve>,
        params: &Params,
        _ops: &mut GroupOps,
    ) -> Result<FactorBase<PrimePoint>, String> {
        if let Some(below) = params.get("below") {
            if params.get("size").is_some() || params.get("stride").is_some() {
                return Err("prime-abscissa: below= replaces size= and stride=".into());
            }
            let below: u64 = below
                .parse()
                .map_err(|_| "below must be an unsigned integer".to_string())?;
            let curve = &self.instance.curve;
            if below < 2 || below > curve.p {
                return Err(format!("below must lie in 2..=p = {}", curve.p));
            }
            // The scan below takes abscissae 1, 2, ... in order, so "every
            // carrier below B" is that scan stopped after this many. The
            // count repeats the scan's Legendre symbols, uncharged: the
            // baseline is, if anything, under-charged by them.
            let size = (1..below)
                .filter(|&x| curve.legendre(curve.rhs(x)) >= 0)
                .count();
            if size == 0 {
                return Err(format!("no abscissa in [1, {below}) carries a point"));
            }
            return Ok(prime_factor_base(self.instance, size));
        }
        let size = if params.get("size") == Some("auto") {
            let scale: f64 = params.get("scale").map_or(Ok(0.5), |v| {
                v.parse::<f64>()
                    .ok()
                    .filter(|c| c.is_finite() && *c > 0.0)
                    .ok_or_else(|| "scale must be a positive number".to_string())
            })?;
            ((scale * (self.instance.r as f64).cbrt()).round() as usize).max(4)
        } else {
            if params.get("scale").is_some() {
                return Err("prime-abscissa: scale= needs size=auto".into());
            }
            params.u64("size")? as usize
        };
        if size == 0 {
            return Err("factor base size must be positive".into());
        }
        let stride = params.get("stride").map_or(Ok(1u64), |s| {
            s.parse::<u64>()
                .map_err(|_| "stride must be an unsigned integer".to_string())
        })?;
        if stride == 0 || stride >= self.instance.curve.p {
            return Err("stride must lie in 1..p".into());
        }
        if stride == 1 {
            Ok(prime_factor_base(self.instance, size))
        } else {
            Ok(prime_factor_base_strided(self.instance, size, stride))
        }
    }
}

/// Scan rational points, project by the cofactor, and retain distinct signed
/// subgroup points. This is a different base from `prime-abscissa`: the
/// abscissae after projection need not be small.
pub struct PrimeProjectedAbscissaBase<'i> {
    pub instance: &'i PrimeInstance,
}

#[cfg(test)]
mod projected_prime_tests {
    use super::*;
    use crate::cryptanalysis::ic_boundary::Calibration;
    use crate::cryptanalysis::ic_framework::stages::Targets;
    use crate::cryptanalysis::ic_framework::{run_pipeline, PipelineSpec};
    #[allow(unused_imports)]
    use crate::cryptanalysis::pq_groebner_f2::{
        bit, low_bits, mask_from64, mask_low64, masks_low64, Mask, MASK_BITS,
    };

    fn fixture() -> PrimeInstance {
        let curve = PrimeCurve {
            p: 113,
            a: 19,
            b: 2,
        };
        let mut ops = GroupOps::default();
        for x in 1..113 {
            if let Some(y) = curve.sqrt(curve.rhs(x)) {
                let g = curve.mul(&mut ops, PrimePoint::affine(x, y), 16);
                if !g.infinity && curve.mul(&mut ops, g, 7).infinity {
                    return PrimeInstance {
                        name: "projected-control".into(),
                        curve,
                        group_order: 112,
                        r: 7,
                        cofactor: 16,
                        generator: (g.x, g.y),

                        representation: None,
                    };
                }
            }
        }
        panic!("control generator missing")
    }
    #[test]
    fn projected_base_checks_membership_and_counts_projection() {
        let inst = fixture();
        let ctx = InstanceCtx {
            group: &inst.curve,
            generator: inst.generator_point(),
            target: inst.generator_point(),
            r: 7,
            cofactor: 16,
            group_order: 112,
            name: inst.name.clone(),
            field_degree: None,
        };
        let (_, params) =
            Params::parse_spec("prime-projected-abscissa:size=2,scan_cap=64").unwrap();
        let mut ops = GroupOps::default();
        let fb = PrimeProjectedAbscissaBase { instance: &inst }
            .build(&ctx, &params, &mut ops)
            .unwrap();
        assert_eq!(fb.columns, 2);
        assert_eq!(fb.points.len(), 4);
        assert!(ops.scalar_mults >= 4);
        assert!(fb.cost.get("projected_base_membership_checks_uncharged") >= 2);
        for p in &fb.points {
            assert!(inst.curve.is_on_curve(*p));
            assert!(!p.infinity);
            assert!(inst.curve.mul(&mut ops, *p, 7).infinity);
        }
        let (_, bad) = Params::parse_spec("prime-projected-abscissa:size=4,scan_cap=64").unwrap();
        assert!(PrimeProjectedAbscissaBase { instance: &inst }
            .build(&ctx, &bad, &mut ops)
            .is_err());
    }
    #[test]
    fn projected_relations_recover_every_nonzero_control_log() {
        let inst = fixture();
        for k in 1..7 {
            let mut scratch = GroupOps::default();
            let q = inst.curve.mul(&mut scratch, inst.generator_point(), k);
            let ctx = InstanceCtx {
                group: &inst.curve,
                generator: inst.generator_point(),
                target: q,
                r: 7,
                cofactor: 16,
                group_order: 112,
                name: inst.name.clone(),
                field_degree: None,
            };
            let (_, params) =
                Params::parse_spec("prime-projected-abscissa:size=2,scan_cap=64").unwrap();
            let spec = PipelineSpec {
                factor_base: "prime-projected-abscissa".into(),
                factor_base_params: params,
                oracle: "mitm".into(),
                oracle_params: Params::default(),
                targets: Targets::Random,
                linalg: "incremental-gauss-full-rank-checked".into(),
                max_trials: 1000,
                seed: 21,
                ..Default::default()
            };
            let rep = run_pipeline(
                &ctx,
                &spec,
                &PrimeProjectedAbscissaBase { instance: &inst },
                &mut MitmOracle::new(2),
                u64::MAX,
                &Calibration {
                    ns_per_add: 1.0,
                    ns_per_double: 1.0,
                    ..Default::default()
                },
                None,
            )
            .unwrap();
            assert_eq!(rep.recovered, Some(k));
            assert!(
                inst.curve
                    .mul(&mut scratch, inst.generator_point(), rep.recovered.unwrap())
                    == q
            );
        }
    }
}

impl FactorBaseBuilder<PrimeCurve> for PrimeProjectedAbscissaBase<'_> {
    fn name(&self) -> &str {
        "prime-projected-abscissa"
    }

    fn describe(&self, params: &Params) -> String {
        format!("{} distinct signed subgroup columns from cofactor-projected raw abscissae; scan cap {}",
            params.get("size").unwrap_or("?"), params.get("scan_cap").unwrap_or("?"))
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            (
                "size",
                "distinct negation pairs in the selected prime subgroup",
            ),
            ("scan_cap", "maximum raw abscissae scanned; required"),
        ]
    }

    fn build(
        &self,
        ctx: &InstanceCtx<PrimeCurve>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<FactorBase<PrimePoint>, String> {
        let inst = self.instance;
        if ctx.r != inst.r || ctx.cofactor != inst.cofactor || ctx.group_order != inst.group_order {
            return Err("projected base context does not match its instance".into());
        }
        let size = params.u64("size")?;
        let cap = params.u64("scan_cap")?;
        if inst.r < 5 || size == 0 || size > (inst.r - 1) / 2 || cap == 0 || cap >= inst.curve.p {
            return Err("projected base needs 0<size<=(r-1)/2 and 0<scan_cap<p".into());
        }
        let start = Instant::now();
        let curve = &inst.curve;
        let mut seen = BTreeSet::new();
        let mut points = Vec::new();
        let mut columns = Vec::new();
        let mut coefficients = Vec::new();
        let mut scanned = 0;
        let mut sqrts = 0;
        let mut projected = 0;
        let mut checked = 0;
        let mut duplicates = 0;
        for x in 1..=cap {
            scanned += 1;
            let rhs = curve.rhs(x);
            if curve.legendre(rhs) < 0 {
                continue;
            }
            sqrts += 1;
            let Some(y) = curve.sqrt(rhs) else {
                continue;
            };
            let point = curve.mul(ops, PrimePoint::affine(x, y), inst.cofactor);
            projected += 1;
            if point.infinity {
                continue;
            }
            checked += 1;
            if !curve.mul(ops, point, inst.r).infinity {
                return Err(
                    "cofactor projection produced a point outside the selected subgroup".into(),
                );
            }
            if !seen.insert(point.x) {
                duplicates += 1;
                continue;
            }
            let point = if point.y <= curve.p - point.y {
                point
            } else {
                curve.neg(point)
            };
            let col = seen.len() - 1;
            points.extend([point, curve.neg(point)]);
            columns.extend([col, col]);
            coefficients.extend([1, inst.r - 1]);
            if seen.len() as u64 == size {
                break;
            }
        }
        if seen.len() as u64 != size {
            return Err(format!(
                "projected base scan exhausted: {} of {size} columns after {scanned} abscissae",
                seen.len()
            ));
        }
        let mut fb = FactorBase::from_column_map(
            self.describe(params),
            points,
            columns,
            coefficients,
            size as usize,
            |p| curve.key(p),
            |p| curve.key(&curve.neg(*p)),
            |p| p.x,
        )?;
        fb.cost.wall_ns = start.elapsed().as_nanos() as u64;
        fb.cost.count("abscissae_scanned", scanned);
        fb.cost.count("legendre_symbols", scanned);
        fb.cost.count("sqrt_solves", sqrts);
        fb.cost.count("cofactor_projected_points", projected);
        fb.cost
            .count("projected_base_membership_checks_uncharged", checked);
        fb.cost
            .count("projected_base_dedup_probes_uncharged", checked);
        fb.cost.count("projected_base_duplicate_points", duplicates);
        fb.cost
            .count("projected_base_column_map_entries_uncharged", 2 * size);
        Ok(fb)
    }
}

/// **The known-log base:** `F_G(B) = { ±[i]G : 1 ≤ i ≤ B }`, one column
/// per `i`, the column's unknown being `log_G([i]G) = i`.
///
/// Every logarithm is free, so one verified relation
/// `[a]G + [b]Q = Σ ±[iⱼ]G` gives `k` directly and the pipeline skips
/// linear algebra (`FactorBase::known_logs`).  Construction is `B`
/// incremental additions, charged to the base's `PhaseCost`.  The points
/// all lie in `⟨G⟩`, so on a cofactor-`h` curve no class condition applies.
///
/// This is a generic precomputation table (Bernstein–Lange shape): with a
/// membership-testing oracle it is an arbitrary set of `B` points and it
/// cannot beat `√r`.  It is measured against the abscissa base to show how
/// much of that base's cost is its algebra.  No security statement.
pub struct KnownLogBase;

impl FactorBaseBuilder<PrimeCurve> for KnownLogBase {
    fn name(&self) -> &str {
        "known-log"
    }

    fn describe(&self, params: &Params) -> String {
        match params.get("scalars") {
            Some("random") => format!(
                "±[s_i]G for {} seeded uniform scalars s_i, one column each, every logarithm known",
                params.get("size").unwrap_or("?")
            ),
            _ => format!(
                "±[i]G for 1 ≤ i ≤ {}, one column each, every logarithm known",
                params.get("size").unwrap_or("?")
            ),
        }
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            (
                "size",
                "columns B (need 2·B < r); the family optimum is about #E^(1/3)",
            ),
            (
                "scalars",
                "progression (default): s_i = i, built by B−1 additions; random: s_i uniform in [1, r−1], one charged scalar multiplication each",
            ),
            (
                "seed",
                "random only: seed of the scalar stream (default 20261019); the base is fixed per (G, size, seed)",
            ),
        ]
    }

    fn build(
        &self,
        ctx: &InstanceCtx<PrimeCurve>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<FactorBase<PrimePoint>, String> {
        let size = params.u64("size")?;
        if size == 0 {
            return Err("factor base size must be positive".into());
        }
        if size.checked_mul(2).is_none_or(|t| t >= ctx.r) {
            return Err(format!(
                "known-log size {size} needs 2·size < r = {}, so that ±[i]G are distinct",
                ctx.r
            ));
        }
        let random = match params.get("scalars") {
            None | Some("progression") => false,
            Some("random") => true,
            Some(other) => {
                return Err(format!(
                    "known-log scalars is progression or random, not {other}"
                ))
            }
        };
        let start = Instant::now();
        let g = ctx.group;
        let mut points = Vec::with_capacity(2 * size as usize);
        let mut col_of = Vec::with_capacity(2 * size as usize);
        let mut coef_of = Vec::with_capacity(2 * size as usize);
        let mut logs = Vec::with_capacity(size as usize);
        let mut multiple = ctx.generator;
        let mut rng = rand::rngs::StdRng::seed_from_u64(params.u64_or("seed", 20261019)?);
        let mut used = HashSet::new();
        for i in 1..=size {
            let s = if random {
                // Distinct classes {s, r − s}, so ±[s]G never repeats a point.
                loop {
                    let s = rand::Rng::gen_range(&mut rng, 1..ctx.r);
                    if !used.contains(&s) && !used.contains(&(ctx.r - s)) {
                        used.insert(s);
                        break s;
                    }
                }
            } else {
                i
            };
            multiple = if random {
                g.mul(ops, ctx.generator, s)
            } else if i > 1 {
                g.add(ops, multiple, ctx.generator)
            } else {
                multiple
            };
            logs.push(s);
            points.push(multiple);
            col_of.push((i - 1) as usize);
            coef_of.push(1);
            points.push(g.neg(multiple));
            col_of.push((i - 1) as usize);
            coef_of.push(ctx.r - 1);
        }
        let mut fb = FactorBase::from_column_map(
            if random {
                format!("±[s_i]G, {size} seeded uniform scalars")
            } else {
                format!("±[i]G, 1 ≤ i ≤ {size}")
            },
            points,
            col_of,
            coef_of,
            size as usize,
            |p| g.key(p),
            |p| g.key(&g.neg(*p)),
            |p| p.x,
        )?;
        fb.known_logs = Some(logs);
        fb.cost.wall_ns = start.elapsed().as_nanos() as u64;
        if random {
            fb.cost.count("known_log_scalar_mults", size);
        } else {
            fb.cost.count("known_log_additions", size.saturating_sub(1));
        }
        Ok(fb)
    }
}

/// Points of a binary curve whose abscissa lies in an `F_2`-subspace
/// of the field, one column per abscissa.
pub struct BinarySubspaceBase<'i> {
    pub instance: &'i BinaryInstance,
}

impl<'a> FactorBaseBuilder<BinaryGroup<'a>> for BinarySubspaceBase<'_> {
    fn name(&self) -> &str {
        "binary-subspace"
    }

    fn describe(&self, params: &Params) -> String {
        if params.get("basis").is_some() {
            return format!(
                "points whose abscissa lies in the explicitly recorded {}-dimensional subspace",
                params.get("dimension").unwrap_or("?")
            );
        }
        format!(
            "points whose abscissa lies in the {}-dimensional subspace spanned by {{1, z, …}}",
            params.get("dimension").unwrap_or("?")
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            (
                "dimension",
                "F_2-dimension of the abscissa subspace; about 2^dimension abscissae",
            ),
            (
                "basis",
                "optional explicit full-rank polynomial-basis words separated by semicolons",
            ),
            (
                "select",
                "optional subspace selection: `prefix` (default, <1, z, ...>), `strict4e` (sieve-built subspace with every abscissa in 4E; Koblitz a=0, odd n, h=4 only) or `gated-rank` (best of `candidates` draws by the rank-aware key); excludes `basis`",
            ),
            ("seed", "seed of `select` (default 1); deterministic per seed"),
            ("candidates", "`select=gated-rank` only: sieve draws (default 16)"),
            ("m", "`select=gated-rank` only: summands of the ceiling (default 3)"),
        ]
    }

    fn build(
        &self,
        _ctx: &InstanceCtx<BinaryGroup<'a>>,
        params: &Params,
        _ops: &mut GroupOps,
    ) -> Result<FactorBase<FastPoint>, String> {
        let dim = params.u64("dimension")?;
        if !(1..=30).contains(&dim) {
            return Err(format!("subspace dimension {dim} outside 1..=30"));
        }
        // Validate before narrowing: e.g. 2^32 + 3 must not become dimension 3.
        let dim = dim as u32;
        let select = params.get("select").unwrap_or("prefix");
        if select != "prefix" && params.get("basis").is_some() {
            return Err("`select` and an explicit `basis` are mutually exclusive".into());
        }
        if matches!(select, "strict4e" | "gated-rank") {
            use crate::cryptanalysis::ic_framework::subspace_select as ss;
            if let Some(why) = ss::strict4e_refusal(self.instance) {
                return Err(format!("select={select} refused: {why}"));
            }
            if dim >= self.instance.n {
                return Err(format!("subspace dimension {dim} must be below n"));
            }
            let seed = params.u64_or("seed", 1)?;
            let start = Instant::now();
            let map = ss::X4Map::build(self.instance);
            let sel = if select == "strict4e" {
                ss::strict4e_sieve(&map, dim, seed)?
            } else {
                let k = params.u64_or("candidates", 16)? as u32;
                let m = params.u64_or("m", 3)? as u32;
                ss::gated_rank_select(self.instance, &map, dim, seed, k, m)?.0
            };
            let mut fb = binary_subspace_factor_base(self.instance, &sel.basis);
            // Unpriced native work of the selection (AGENTS.md section 5a).
            fb.cost.count(
                "strict4e_membership_tests_uncharged",
                1u64 << self.instance.n,
            );
            fb.cost
                .count("strict4e_sieve_lookups_uncharged", sel.lookups);
            fb.cost.count("strict4e_x4_in_span", sel.x4_in_span);
            fb.cost.count("strict4e_span_nonzero", sel.span_nonzero);
            fb.cost
                .count("strict4e_fallback_steps", u64::from(sel.fallback_steps));
            fb.cost.wall_ns += start.elapsed().as_nanos() as u64;
            return Ok(fb);
        }
        if select != "prefix" {
            return Err(format!(
                "unknown select `{select}`; try prefix, strict4e or gated-rank"
            ));
        }
        let basis: Vec<u64> = if let Some(text) = params.get("basis") {
            let basis: Vec<u64> = text
                .split(';')
                .map(|word| {
                    if let Some(word) = word.strip_prefix("0x") {
                        u64::from_str_radix(word, 16)
                    } else {
                        word.parse()
                    }
                })
                .collect::<Result<_, _>>()
                .map_err(|e| format!("invalid explicit subspace basis: {e}"))?;
            if basis.len() != dim as usize
                || basis.iter().any(|x| *x == 0 || *x >> self.instance.n != 0)
            {
                return Err("explicit basis dimension or field word is invalid".into());
            }
            let mut pivots = [0u64; 64];
            for &word in &basis {
                let mut word = word;
                while word != 0 {
                    let k = 63 - word.leading_zeros() as usize;
                    if pivots[k] == 0 {
                        pivots[k] = word;
                        break;
                    }
                    word ^= pivots[k];
                }
                if word == 0 {
                    return Err("explicit subspace basis is linearly dependent".into());
                }
            }
            basis
        } else {
            (0..dim).map(|k| 1u64 << k).collect()
        };
        Ok(binary_subspace_factor_base(self.instance, &basis))
    }
}

/// `dim` independent elements of `ker Tr`, from `1, z, z², …`: each monomial
/// of trace 0 as it is, each of trace 1 plus the first monomial of trace 1.
/// A point `(x, y)` of `y² + xy = x³ + ax² + b` lies in `2E(F_{2^n})` iff
/// `Tr(x) = Tr(a)`, so with `Tr(a) = 0` every point above the span is in
/// `2E` (`research/isogeny_conductor_gap_round5_20261012/`, E7b; the
/// trace-zero bases of `koblitz_factor_base_search` use the same fact).
pub fn trace_kernel_basis(inst: &BinaryInstance, dim: u32) -> Result<Vec<u64>, String> {
    if inst.artin_schreier.trace(inst.a) != 0 {
        return Err("trace_kernel needs Tr(a) = 0: with Tr(a) = 1 the points of 2E lie over an affine hyperplane".into());
    }
    trace_coset_basis(inst, dim).map(|(basis, _)| basis)
}

/// The coset of `ker Tr` holding the abscissae of `2E`, as `(basis,
/// offset)`: `dim` independent elements of `ker Tr` (see
/// [`trace_kernel_basis`]) and `offset = 0` when `Tr(a) = 0`, or a
/// monomial of trace 1 when `Tr(a) = 1`.  Every point above
/// `offset + span(basis)` then has `Tr(x) = Tr(a)`, so lies in `2E`.
pub fn trace_coset_basis(inst: &BinaryInstance, dim: u32) -> Result<(Vec<u64>, u64), String> {
    let tr = |v: u64| inst.artin_schreier.trace(v);
    let t0 = (0..inst.n)
        .map(|k| 1u64 << k)
        .find(|&e| tr(e) == 1)
        .ok_or("no monomial of trace 1")?;
    let basis: Vec<u64> = (0..inst.n)
        .map(|k| 1u64 << k)
        .filter(|&e| e != t0)
        .map(|e| if tr(e) == 1 { e ^ t0 } else { e })
        .take(dim as usize)
        .collect();
    if basis.len() < dim as usize {
        return Err(format!("ker Tr has dimension {} < {dim}", inst.n - 1));
    }
    Ok((basis, if tr(inst.a) == 0 { 0 } else { t0 }))
}

/// **The Frobenius closure of a prefix subspace** (lead L5, the ordered
/// τ-slot relation space): every point whose abscissa lies in
/// `σ^t(V)` for some `t`, `V = ⟨1, z, …, z^{d−1}⟩`, each signed Frobenius
/// orbit folded onto one column with weights `±λ^t`.  `V` itself is not
/// Frobenius-stable, so the closure has about `n·|F_V|` points on about
/// `|F_V|/2` columns.  The base records `V`'s basis as its
/// `subspace_basis`, so the algebraic oracle can descend with summand
/// `i` over `σ^{j_i}(V)` (`descent-algebraic:slots=all`) and the lifted
/// abscissae are abscissae of base points; the pair-table oracles run on
/// it like on any closed base.
pub struct KoblitzClosureBase<'i> {
    pub instance: &'i BinaryInstance,
}

impl<'a> FactorBaseBuilder<BinaryGroup<'a>> for KoblitzClosureBase<'_> {
    fn name(&self) -> &str {
        "koblitz-closure"
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "the signed Frobenius closure of the {}-dimensional prefix subspace, one column per orbit",
            params.get("dimension").unwrap_or("?")
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[(
            "dimension",
            "F_2-dimension of the seed subspace V = <1, z, ...>; the base is the union of the Frobenius images of V's points",
        )]
    }

    fn build(
        &self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        params: &Params,
        _ops: &mut GroupOps,
    ) -> Result<FactorBase<FastPoint>, String> {
        let inst = self.instance;
        let kc = inst
            .koblitz
            .as_ref()
            .ok_or("koblitz-closure requires a Koblitz curve")?;
        let dim = params.u64("dimension")? as u32;
        if dim == 0 || dim > 24 {
            return Err(format!("subspace dimension {dim} outside 1..=24"));
        }
        let n = inst.n as usize;
        let lambda = kc
            .lambda
            .to_u64()
            .ok_or("Frobenius eigenvalue does not fit in u64")?;
        let r = ctx.r;
        let basis: Vec<u64> = (0..dim).map(|k| 1u64 << k).collect();
        let g = ctx.group;
        let mut points = Vec::new();
        let mut col_of = Vec::new();
        let mut coef_of = Vec::new();
        let mut seen: HashSet<u64> = HashSet::new();
        let mut columns = 0usize;
        let (mut solves, mut frob) = (0u64, 0u64);
        for idx in 1..(1u64 << dim) {
            let mut x = 0u64;
            for (j, &e) in basis.iter().enumerate() {
                if (idx >> j) & 1 == 1 {
                    x ^= e;
                }
            }
            solves += 1;
            for seed in inst.points_with_x(x) {
                if seen.contains(&seed.pack()) {
                    continue;
                }
                // One column for the signed orbit of `seed`.
                let column = columns;
                let mut member = seed;
                let mut coefficient = 1u64;
                let mut fresh = false;
                for _ in 0..n {
                    if seen.insert(member.pack()) {
                        fresh = true;
                        points.push(member);
                        col_of.push(column);
                        coef_of.push(coefficient);
                        let neg = g.neg(member);
                        seen.insert(neg.pack());
                        points.push(neg);
                        col_of.push(column);
                        coef_of.push((r - coefficient) % r);
                    }
                    member = inst.fast.frobenius_k(member, 1);
                    frob += 1;
                    coefficient = ((coefficient as u128 * lambda as u128) % r as u128) as u64;
                }
                if fresh {
                    columns += 1;
                }
            }
        }
        if columns == 0 {
            return Err("the closure base is empty".into());
        }
        let mut fb = FactorBase::from_column_map(
            format!("Frobenius closure of the prefix subspace of dimension {dim}"),
            points,
            col_of,
            coef_of,
            columns,
            |p| p.pack(),
            |p| inst.fast.neg(*p).pack(),
            |p| p.x,
        )?;
        fb.subspace_basis = Some(basis);
        fb.dimension = Some(dim);
        fb.cost.count("abscissae_scanned", solves);
        fb.cost.count("as_solves", solves);
        fb.cost.count("frobenius_maps", frob);
        Ok(fb)
    }
}

/// A Koblitz base with each signed Frobenius orbit folded onto one
/// column: `2n` points, one unknown.
pub struct KoblitzOrbitBase<'i> {
    pub instance: &'i BinaryInstance,
}

/// A signed-Frobenius-orbit base whose abscissa subspace is contained in
/// `ker Tr_{F_{2^n}/F_2}`.  This is an executable factor-base policy rather
/// than merely a score attached to a search candidate: a divisor that is not
/// trace-zero is rejected before relation collection starts.
pub struct KoblitzTraceZeroBase<'i> {
    pub instance: &'i BinaryInstance,
}

impl<'a> FactorBaseBuilder<BinaryGroup<'a>> for KoblitzTraceZeroBase<'_> {
    fn name(&self) -> &str {
        "koblitz-trace-zero"
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "the trace-zero Frobenius-invariant abscissa subspace selected by divisor {}, each signed orbit folded onto one column",
            params.get("divisor").unwrap_or("?")
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            (
                "divisor",
                "`;`-separated factors of x^n - 1; the resulting invariant subspace must lie in the absolute-trace kernel",
            ),
            (
                "projected",
                "1 to fold by the signed Frobenius orbits of the cofactor projections [h]P instead of \
                 of the raw points: orbits whose projections coincide or are Frobenius translates \
                 share one column (on a base closed under +T, P and P + T do), which is the column \
                 count the relation matrix actually has to determine",
            ),
        ]
    }

    fn build(
        &self,
        _ctx: &InstanceCtx<BinaryGroup<'a>>,
        params: &Params,
        _ops: &mut GroupOps,
    ) -> Result<FactorBase<FastPoint>, String> {
        let kc = self
            .instance
            .koblitz
            .as_ref()
            .ok_or("koblitz-trace-zero requires a Koblitz curve")?;
        let idx = divisor_indices(params)?;
        let frob = build_frobenius_factor_base_from_divisor(kc, &idx)
            .ok_or_else(|| format!("no invariant subspace for divisor {idx:?}"))?;
        if !subspace_is_trace_zero(kc, &frob) {
            return Err(format!(
                "divisor {idx:?} is not trace-zero: at least one abscissa has absolute trace one"
            ));
        }
        let fold = if params.flag("projected") {
            ColumnFold::ProjectedSignedFrobeniusOrbit
        } else {
            ColumnFold::SignedFrobeniusOrbit
        };
        koblitz_factor_base(
            self.instance,
            &frob,
            fold,
            format!(
                "trace-zero invariant subspace, divisor {idx:?}, dimension {}{}",
                frob.ell,
                if params.flag("projected") {
                    ", columns merged by cofactor projection"
                } else {
                    ""
                }
            ),
        )
        .ok_or_else(|| "the trace-zero subspace produced no usable factor base".into())
    }
}

impl<'a> FactorBaseBuilder<BinaryGroup<'a>> for KoblitzOrbitBase<'_> {
    fn name(&self) -> &str {
        "koblitz-orbit"
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "the Frobenius-invariant subspace spanned by divisor factors {}, {}",
            params.get("divisor").unwrap_or("?"),
            if params.flag("no_fold") {
                "one column per abscissa (the unfolded control)"
            } else {
                "each signed Frobenius orbit folded onto one column"
            }
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            (
                "halftrace_tables",
                "0 (default) preserves legacy halftrace squarings; 1 builds a lazy byte-table cache in the charged factor-base phase, preserving ordered points",
            ),
            (
                "divisor",
                "`;`-separated indices into the factorisation of the Frobenius characteristic \
                 polynomial, e.g. `divisor=1;2` (a `,` would end the parameter on the command \
                 line); the invariant subspace they span becomes the abscissa set. This is \
                 the knob that chooses the base, so sweeping it sweeps factor bases",
            ),
            (
                "no_fold",
                "1 to give every abscissa its own column: the control that shows what the fold buys",
            ),
            (
                "projected",
                "1 to fold by the signed Frobenius orbits of the cofactor projections [h]P instead of \
                 of the raw points: orbits whose projections coincide or are Frobenius translates \
                 share one column (on a base closed under +T, P and P + T do), which is the column \
                 count the relation matrix actually has to determine",
            ),
        ]
    }

    fn build(
        &self,
        _ctx: &InstanceCtx<BinaryGroup<'a>>,
        params: &Params,
        _ops: &mut GroupOps,
    ) -> Result<FactorBase<FastPoint>, String> {
        let kc = self
            .instance
            .koblitz
            .as_ref()
            .ok_or("this instance is not a Koblitz curve, so it has no Frobenius to fold by")?;
        let idx = divisor_indices(params)?;
        let cached = match params.u64_or("halftrace_tables", 0)? {
            0 => false,
            1 => true,
            _ => return Err("halftrace_tables must be 0 or 1".into()),
        };
        let frob = with_cached_point_lifts(cached, || {
            build_frobenius_factor_base_from_divisor(kc, &idx)
        })
        .ok_or_else(|| format!("no invariant subspace for divisor {idx:?} on this curve"))?;
        let fold = if params.flag("no_fold") {
            ColumnFold::Abscissa
        } else if params.flag("projected") {
            ColumnFold::ProjectedSignedFrobeniusOrbit
        } else {
            ColumnFold::SignedFrobeniusOrbit
        };
        koblitz_factor_base(
            self.instance,
            &frob,
            fold,
            format!(
                "invariant subspace, divisor {idx:?}, dimension {}",
                frob.ell
            ),
        )
        .ok_or_else(|| "the invariant subspace produced no usable factor base".into())
    }
}

/// `generator_orbit` of `compact-orbit-scan`: absent or 0 is the archived
/// scan, 1 seeds column 0 with the generator's orbit.
fn generator_orbit(params: &Params) -> Result<bool, String> {
    match params.get("generator_orbit") {
        None => Ok(false),
        Some(_) => match params.u64("generator_orbit")? {
            0 => Ok(false),
            1 => Ok(true),
            v => Err(format!("generator_orbit must be 0 or 1, not {v}")),
        },
    }
}

/// `generator_multiples` of `compact-orbit-scan` (Koblitz small-row lever,
/// 2026-11-18): with `generator_orbit=1`, columns `0..k` are the signed
/// Frobenius orbits of `[1]G, …, [k]G`, every one of known logarithm. Absent
/// or 1 is the plain generator-orbit base (one known column).
fn generator_multiples(params: &Params) -> Result<u64, String> {
    match params.get("generator_multiples") {
        None => Ok(1),
        Some(_) => match params.u64("generator_multiples")? {
            0 => Err("generator_multiples must be at least 1".into()),
            k => {
                if !generator_orbit(params)? {
                    return Err("generator_multiples needs generator_orbit=1".into());
                }
                if k > params.u64("columns")? {
                    return Err("generator_multiples cannot exceed columns".into());
                }
                Ok(k)
            }
        },
    }
}

/// `multiple_doublings` of `compact-orbit-scan`: absent is the progression
/// `[j]G`; `d >= 1` makes the known seeds `[2^(d*(j-1))]G` (d doublings
/// each), whose pair sums do not cluster along the generator stride.
fn multiple_doublings(params: &Params) -> Result<Option<u32>, String> {
    match params.get("multiple_doublings") {
        None => Ok(None),
        Some(_) => {
            let d = params.u64("multiple_doublings")?;
            let k = generator_multiples(params)?;
            if d == 0 || k < 2 || d * (k - 1) >= 63 {
                return Err(
                    "multiple_doublings needs d >= 1, generator_multiples >= 2 and d*(k-1) < 63"
                        .into(),
                );
            }
            Ok(Some(d as u32))
        }
    }
}

/// `lean_layout` of `compact-orbit-scan` (n29 generator-orbit lever,
/// 2026-11-18): absent or 0 is the incumbent build, bit for bit.  With 1
/// (needs `generator_orbit=1` and `generator_multiples = columns`, so every
/// column is a known seed's orbit and nothing is scanned) the base keeps
/// the same points, columns, coefficients and negation map, but skips the
/// work no orbit-layout consumer reads: the hash index of
/// `FactorBase::from_column_map` (its inserts, probes and negative-key
/// negations), the on-curve check of every Frobenius image (the seed is
/// still checked; an image of an on-curve point under the Frobenius is on
/// the curve), and, with a single column, the orbit's minimum key (it only
/// detects a repeated column).  The base is then usable only by
/// `mitm-frobenius-layout-counted`, which names its points by index.
fn lean_layout(params: &Params) -> Result<bool, String> {
    match params.get("lean_layout") {
        None => Ok(false),
        Some(_) => match params.u64("lean_layout")? {
            0 => Ok(false),
            1 => {
                if !generator_orbit(params)? {
                    return Err("lean_layout needs generator_orbit=1".into());
                }
                if generator_multiples(params)? != params.u64("columns")? {
                    return Err(
                        "lean_layout needs every column known-log (generator_multiples = columns)"
                            .into(),
                    );
                }
                Ok(true)
            }
            v => Err(format!("lean_layout must be 0 or 1, not {v}")),
        },
    }
}

/// `lazy_neg` of `compact-orbit-scan` (Koblitz K1 set-up lever,
/// 2026-11-18): absent or 0 is the incumbent build, bit for bit.  With 1
/// (needs `lean_layout=1`, so the base is read only by the orbit-layout
/// pair table) the builder does not form the negative `−σ^t(S)` of each
/// orbit member: the slot keeps its index, column and coefficient but
/// holds the identity ([`FactorBase::negations_deferred`]).  The sibling
/// table build never reads a negative (it forms `P − X` from `X`), and a
/// probe hit that names one forms it from its partner and counts that
/// negation in the relation phase.
fn lazy_neg(params: &Params) -> Result<bool, String> {
    match params.get("lazy_neg") {
        None => Ok(false),
        Some(_) => match params.u64("lazy_neg")? {
            0 => Ok(false),
            1 => {
                if !lean_layout(params)? {
                    return Err("lazy_neg needs lean_layout=1".into());
                }
                Ok(true)
            }
            v => Err(format!("lazy_neg must be 0 or 1, not {v}")),
        },
    }
}

/// `orbit_key_reuse` of `compact-orbit-scan` (Koblitz K1 speed-up,
/// 2026-11-18): absent or 0 is the incumbent build, bit for bit.  With 1
/// (needs `generator_orbit=1`) a known seed's orbit key, which only detects
/// a column that repeats an earlier one, is the least abscissa of the orbit
/// members the builder forms anyway (each `σ(P) = (x², y²)` is one counted
/// Frobenius map), not `n − 1` field squarings of the seed's abscissa that
/// recompute exactly those abscissae.  The same keys, the same refusal of a
/// repeated column, the same points; the squarings are gone.
fn orbit_key_reuse(params: &Params) -> Result<bool, String> {
    match params.get("orbit_key_reuse") {
        None => Ok(false),
        Some(_) => match params.u64("orbit_key_reuse")? {
            0 => Ok(false),
            1 => {
                if !generator_orbit(params)? {
                    return Err("orbit_key_reuse needs generator_orbit=1".into());
                }
                Ok(true)
            }
            v => Err(format!("orbit_key_reuse must be 0 or 1, not {v}")),
        },
    }
}

/// The log of the `j`-th known seed (1-based) over `G`.
fn generator_multiple_log(j: u64, doublings: Option<u32>) -> u128 {
    match doublings {
        None => j as u128,
        Some(d) => 1u128 << (d as u64 * (j - 1)),
    }
}

/// The archived compact-orbit producer's public, deterministic raw-x scan.
/// All group work is charged to `ops`; native field and container work is
/// retained on the base as priced counters or explicit lower-bound gaps.
pub struct CompactOrbitScanBase<'i> {
    pub instance: &'i BinaryInstance,
}

impl<'a> FactorBaseBuilder<BinaryGroup<'a>> for CompactOrbitScanBase<'_> {
    fn name(&self) -> &str {
        "compact-orbit-scan"
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "the first {} distinct projected signed Frobenius orbits from raw x <= {}",
            params.get("columns").unwrap_or("?"),
            params.get("raw_x_cap").unwrap_or("?")
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            ("columns", "number of distinct signed Frobenius orbits"),
            (
                "raw_x_cap",
                "inclusive maximum raw abscissa; exhaustion is an error",
            ),
            (
                "norm",
                "Z[tau]-multiplier closure (lead A1): also take alpha(P) for every alpha = a + b*tau of norm a^2 - ab + 2b^2 <= norm, with weight (a + b*lambda) on P's column; 0 or absent for the plain {+-tau^k} orbits",
            ),
            (
                "generator_orbit",
                "1: column 0 is the signed Frobenius orbit of the generator G itself, whose logarithm is known (no lift, cofactor projection, order or eigenvalue check: the instance's lambda is used as the signed-Frobenius rho uses it), so the relation search needs one row fewer; the other columns come from the raw-x scan. 0 or absent: every column from the scan",
            ),
            (
                "multiple_doublings",
                "d (needs generator_multiples >= 2): the known seeds are [2^(d*(j-1))]G, d doublings each, instead of the progression [j]G; absent: the progression",
            ),
            (
                "generator_multiples",
                "k (needs generator_orbit=1, k <= columns; absent or 1: only G): columns 0..k are the signed Frobenius orbits of [1]G, ..., [k]G, built by one doubling and k-2 additions, every logarithm known (h*j), so the relation search needs k rows fewer; at k = columns the base is all known-log and one relation pins the target. A multiple whose orbit repeats an earlier column is an error",
            ),            (
                "lean_layout",
                "1 (needs generator_orbit=1 and generator_multiples = columns): the same points, columns, coefficients and negation map without the work no orbit-layout consumer reads (the base's hash index, the on-curve check of each Frobenius image, the single column's orbit key); usable only by mitm-frobenius-layout-counted. 0 or absent: the incumbent build",
            ),
            (
                "orbit_key_reuse",
                "1 (needs generator_orbit=1): each known seed's orbit key (it only refuses a repeated column) is the least abscissa of the orbit members already formed by the counted Frobenius maps, not n-1 more squarings of the seed's abscissa; same keys, refusals and points. 0 or absent: the incumbent build",
            ),
            (
                "lazy_neg",
                "1 (needs lean_layout=1; Koblitz K1 set-up lever, 2026-11-18): the negatives -sigma^t(S) are not formed; their slots keep index, column and coefficient but hold the identity, the sibling pair table never reads them, and a probe hit that names one forms it from its partner and counts the negation (point_negations_uncharged, relation phase). 0 or absent: the incumbent build",
            ),
        ]
    }

    fn known_column_logs(
        &self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        params: &Params,
    ) -> Result<Vec<(usize, u64)>, String> {
        // x = h·log_G(seed) with seed = G (see collect_and_solve_relations).
        Ok(if generator_orbit(params)? {
            let h = (ctx.cofactor % ctx.r) as u128;
            let doublings = multiple_doublings(params)?;
            (1..=generator_multiples(params)?)
                .map(|j| {
                    let s = generator_multiple_log(j, doublings) % ctx.r as u128;
                    ((j - 1) as usize, ((h * s) % ctx.r as u128) as u64)
                })
                .collect()
        } else {
            Vec::new()
        })
    }

    fn build(
        &self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<FactorBase<FastPoint>, String> {
        let inst = self.instance;
        let kc = inst
            .koblitz
            .as_ref()
            .ok_or("compact-orbit-scan requires a Koblitz curve")?;
        if ctx.r != inst.r || ctx.cofactor != inst.cofactor || ctx.field_degree != Some(inst.n) {
            return Err("compact-orbit-scan context does not match its binary instance".into());
        }
        let columns =
            usize::try_from(params.u64("columns")?).map_err(|_| "columns does not fit in usize")?;
        let raw_x_cap = params.u64("raw_x_cap")?;
        let norm_cap = match params.get("norm") {
            None => 0i64,
            Some(_) => params.u64("norm")? as i64,
        };
        // Multipliers a + b*tau of norm a^2 - ab + 2b^2 <= norm_cap, one per
        // associate class up to sign and Frobenius (the orbit loop below
        // supplies +-tau^k alpha(P); duplicates are dropped by key).
        let mut multipliers: Vec<(i64, i64)> = Vec::new();
        if norm_cap > 0 {
            let bound = (norm_cap as f64).sqrt() as i64 + 2;
            for a in -bound..=bound {
                for b in -bound..=bound {
                    if (a, b) == (0, 0) || a * a - a * b + 2 * b * b > norm_cap {
                        continue;
                    }
                    multipliers.push((a, b));
                }
            }
        }
        let mut multiplier_points = 0u64;
        let from_generator = generator_orbit(params)?;
        let multiples = generator_multiples(params)?;
        let doublings = multiple_doublings(params)?;
        let lean = lean_layout(params)?;
        let key_reuse = orbit_key_reuse(params)?;
        let defer_neg = lazy_neg(params)?;
        // `[2^i]G` as the doubling path forms it (kept, not recomputed).
        let mut ladder: Vec<FastPoint> = Vec::new();
        if from_generator && !multipliers.is_empty() {
            return Err("generator_orbit=1 does not combine with norm > 0".into());
        }
        if columns == 0 || raw_x_cap == 0 || inst.n == 0 || inst.n >= 64 || inst.n.is_multiple_of(2)
        {
            return Err(
                "compact-orbit-scan requires positive columns and cap and odd degree < 64".into(),
            );
        }
        // The archived source selects the half-trace root first. The
        // framework's linear Artin-Schreier solver can choose its other
        // valid root, changing representatives, point order and base hash.
        let source_curve = FastBinaryCurve::new(&inst.irreducible, inst.a)
            .ok_or("compact-orbit source curve is outside its field limit")?;
        let orbit_size = (inst.n as usize)
            .checked_mul(2)
            .ok_or("orbit size overflows usize")?;
        let capacity = columns
            .checked_mul(orbit_size)
            .ok_or("factor base size overflows usize")?;
        let lambda = kc
            .lambda
            .to_u64()
            .ok_or("Frobenius eigenvalue does not fit in u64")?;
        let g = ctx.group;
        let mut seen = HashSet::new();
        let mut points = Vec::with_capacity(capacity);
        let mut col_of = Vec::with_capacity(capacity);
        let mut coef_of = Vec::with_capacity(capacity);
        let mut scanned = 0u64;
        let mut lifts = 0u64;
        let mut projected = 0u64;
        let mut key_squares = 0u64;
        let mut frobenius_maps = 0u64;
        let mut equation_checks = 0u64;
        let max_x = raw_x_cap.min((1u64 << inst.n) - 1);
        if from_generator {
            // Column 0: the generator's own orbit. G is the instance's point
            // of order r, so there is nothing to lift, project or order-check.
            // Its coefficients use the instance's lambda unchecked, as the
            // signed-Frobenius rho does; a wrong lambda would fail the final
            // [d]G = Q verification that every arm pays, not return a wrong d.
            // With `generator_multiples = k`, columns 1..k repeat this for
            // [j]G (one doubling, then one addition each), log h*j.
            let mut seed = ctx.generator;
            if doublings.is_some() {
                ladder.push(seed);
            }
            for j in 1..=multiples {
                if let (Some(d), true) = (doublings, j > 1) {
                    for _ in 0..d {
                        seed = g.double(ops, seed);
                        ladder.push(seed);
                    }
                } else if j == 2 {
                    seed = g.double(ops, seed);
                } else if j > 2 {
                    seed = g.add(ops, seed, ctx.generator);
                }
                let column = (j - 1) as usize;
                if g.is_identity(&seed) || seed.x <= 1 {
                    return Err(format!(
                        "generator_orbit=1 needs [{j}]G with x > 1 (generator_multiples)"
                    ));
                }
                equation_checks += 1;
                if !inst.fast.is_on_curve(seed) {
                    return Err("the generator is off curve".into());
                }
                if lean && multiples == 1 {
                    // One column: there is no earlier orbit to repeat.
                    seen.insert(seed.x);
                } else if key_reuse {
                    // Keyed below, from the orbit members once formed.
                } else {
                    let mut x = seed.x;
                    let mut key = x;
                    for _ in 1..inst.n {
                        x = inst.gf.sqr(x);
                        key = key.min(x);
                        key_squares += 1;
                    }
                    if !seen.insert(key) {
                        return Err(format!(
                            "the orbit of [{j}]G repeats an earlier column; use fewer generator_multiples"
                        ));
                    }
                }
                let mut member = seed;
                let mut coefficient = 1u64;
                for _ in 0..inst.n {
                    if !lean {
                        equation_checks += 1;
                        if !inst.fast.is_on_curve(member) {
                            return Err("a Frobenius image of the generator is off curve".into());
                        }
                    }
                    points.push(member);
                    col_of.push(column);
                    coef_of.push(coefficient);
                    // `lazy_neg`: the slot of `−member`, not formed.
                    points.push(if defer_neg {
                        FastPoint::INFINITY
                    } else {
                        g.neg(member)
                    });
                    col_of.push(column);
                    coef_of.push((ctx.r - coefficient) % ctx.r);
                    member = inst.fast.frobenius_k(member, 1);
                    frobenius_maps += 1;
                    coefficient = ((coefficient as u128 * lambda as u128) % ctx.r as u128) as u64;
                }
                if member != seed || coefficient != 1 {
                    return Err("the generator's Frobenius orbit is not closed".into());
                }
                if key_reuse && !(lean && multiples == 1) {
                    // The least abscissa over σ^t(seed), t < n: the key the
                    // squarings would give, read off the formed members.
                    let first = points.len() - 2 * inst.n as usize;
                    let key = points[first..]
                        .iter()
                        .step_by(2)
                        .map(|p| p.x)
                        .min()
                        .expect("an orbit has n >= 1 members");
                    if !seen.insert(key) {
                        return Err(format!(
                            "the orbit of [{j}]G repeats an earlier column; use fewer generator_multiples"
                        ));
                    }
                }
            }
        }
        for raw_x in 1..=max_x {
            if seen.len() == columns {
                break;
            }
            scanned += 1;
            for source_point in source_curve.points_with_x(inst.b, raw_x) {
                let (x, y) = source_point.ok_or("raw-x lift unexpectedly returned infinity")?;
                let point = FastPoint::affine(x, y);
                lifts += 1;
                let seed = g.mul(ops, point, ctx.cofactor);
                if g.is_identity(&seed) || seed.x <= 1 {
                    continue;
                }
                projected += 1;
                equation_checks += 1;
                if !inst.fast.is_on_curve(seed) {
                    return Err(format!("projected point from raw x {raw_x} is off curve"));
                }
                let mut x = seed.x;
                let mut key = x;
                for _ in 1..inst.n {
                    x = inst.gf.sqr(x);
                    key = key.min(x);
                    key_squares += 1;
                }
                if !seen.insert(key) {
                    continue;
                }
                if !g.is_identity(&g.mul(ops, seed, ctx.r)) {
                    return Err(format!(
                        "projected point from raw x {raw_x} has wrong order"
                    ));
                }
                if g.mul(ops, seed, lambda) != inst.fast.frobenius_k(seed, 1) {
                    return Err(format!(
                        "Frobenius eigenvalue check failed for raw x {raw_x}"
                    ));
                }
                frobenius_maps += 1;
                let column = seen.len() - 1;
                let mut member = seed;
                let mut coefficient = 1u64;
                for _ in 0..inst.n {
                    equation_checks += 1;
                    if !inst.fast.is_on_curve(member) {
                        return Err(format!("Frobenius image from raw x {raw_x} is off curve"));
                    }
                    points.push(member);
                    col_of.push(column);
                    coef_of.push(coefficient);
                    points.push(g.neg(member));
                    col_of.push(column);
                    coef_of.push((ctx.r - coefficient) % ctx.r);
                    member = inst.fast.frobenius_k(member, 1);
                    frobenius_maps += 1;
                    coefficient = ((coefficient as u128 * lambda as u128) % ctx.r as u128) as u64;
                }
                if member != seed || coefficient != 1 {
                    return Err(format!("Frobenius orbit from raw x {raw_x} is not closed"));
                }
                // Lead A1: the orbits of alpha(P) = [a]P + [b]tau(P) for the
                // small-norm multipliers, weight (a + b*lambda)*lambda^t.
                if !multipliers.is_empty() {
                    let tau_seed = inst.fast.frobenius_k(seed, 1);
                    let r128 = ctx.r as u128;
                    let to_scalar = |v: i64| -> u64 { v.rem_euclid(ctx.r as i64) as u64 };
                    let mut local_seen: HashSet<u64> = HashSet::new();
                    for &(a, b) in &multipliers {
                        let sa = to_scalar(a);
                        let sb = to_scalar(b);
                        let pa = if sa == 0 {
                            g.identity()
                        } else {
                            g.mul(ops, seed, sa)
                        };
                        let pb = if sb == 0 {
                            g.identity()
                        } else {
                            g.mul(ops, tau_seed, sb)
                        };
                        let image = g.add(ops, pa, pb);
                        if g.is_identity(&image) {
                            continue;
                        }
                        // Skip images already in the base (an associate of a
                        // Frobenius power, or a repeat), by orbit key.
                        let mut xk = image.x;
                        let mut key = xk;
                        for _ in 1..inst.n {
                            xk = inst.gf.sqr(xk);
                            key = key.min(xk);
                        }
                        if !local_seen.insert(key) || seen.contains(&key) {
                            continue;
                        }
                        let weight =
                            ((sa as u128 + (sb as u128 * lambda as u128) % r128) % r128) as u64;
                        let mut member = image;
                        let mut coefficient = weight;
                        for _ in 0..inst.n {
                            points.push(member);
                            col_of.push(column);
                            coef_of.push(coefficient);
                            points.push(g.neg(member));
                            col_of.push(column);
                            coef_of.push((ctx.r - coefficient) % ctx.r);
                            member = inst.fast.frobenius_k(member, 1);
                            frobenius_maps += 1;
                            coefficient = ((coefficient as u128 * lambda as u128) % r128) as u64;
                            multiplier_points += 2;
                        }
                        if member != image {
                            return Err(format!(
                                "multiplier orbit from raw x {raw_x} is not closed"
                            ));
                        }
                    }
                }
                if seen.len() == columns {
                    break;
                }
            }
            if seen.len() == columns {
                break;
            }
        }
        if seen.len() != columns {
            return Err(format!(
                "raw-x cap {raw_x_cap} exhausted after {scanned} abscissae with {} of {columns} orbits",
                seen.len()
            ));
        }
        let description = if from_generator && multiples > 1 {
            format!(
                    "the signed Frobenius orbits of [1]G..[{multiples}]G and the first {} projected orbits, raw x <= {raw_x_cap}",
                    columns as u64 - multiples
                )
        } else if from_generator {
            format!(
                    "the generator's signed Frobenius orbit and the first {} projected orbits, raw x <= {raw_x_cap}",
                    columns - 1
                )
        } else {
            format!("first {columns} projected signed Frobenius orbits, raw x <= {raw_x_cap}")
        };
        let mut fb = if lean {
            // Pushed as (σ^t(S), −σ^t(S)) pairs above: the layout is the
            // negation map, and no index is derived.
            FactorBase::from_signed_layout(description, points, col_of, coef_of, columns)?
        } else {
            FactorBase::from_column_map(
                description,
                points,
                col_of,
                coef_of,
                columns,
                |p| p.pack(),
                |p| inst.fast.neg(*p).pack(),
                |p| p.x,
            )?
        };
        // Each orbit was pushed seed-first as (σ^t(S), −σ^t(S)) for
        // t = 0..n; multiplier orbits share a column but follow the same
        // order, so the layout holds for them too.
        fb.frobenius_orbit_layout = Some(inst.n);
        fb.generator_ladder = ladder;
        fb.negations_deferred = defer_neg;
        // `from_column_map`'s inserts, lookups and negations are in this
        // builder's `hash_probes_uncharged` and `point_negations_uncharged`
        // below; only its abscissa sort is new.
        fb.cost.work_native.remove("index_inserts");
        fb.cost.work_native.remove("index_point_negations");
        fb.cost.count("abscissae_scanned_uncharged", scanned);
        fb.cost.count("inversions", scanned);
        fb.cost.count("legacy_as_solves_uncharged", scanned);
        fb.cost.count("point_lifts_uncharged", lifts);
        fb.cost.count(
            "lift_field_squares_uncharged",
            scanned * inst.n as u64 + lifts / 2 * (inst.n as u64 - 1),
        );
        fb.cost
            .count("lift_field_multiplies_uncharged", scanned + lifts / 2);
        fb.cost.count("cofactor_projected_points", projected);
        fb.cost
            .count("curve_equation_checks_uncharged", equation_checks);
        fb.cost
            .count("min_key_field_squares_uncharged", key_squares);
        fb.cost.count("frobenius_maps", frobenius_maps);
        // Only with multipliers: a plain scan's counters (and the frozen
        // evidence built from them) stay exactly what they were.
        if !multipliers.is_empty() {
            fb.cost.count("multiplier_points", multiplier_points);
        }
        if multiples > 1 {
            fb.cost.count("generator_multiple_columns", multiples);
        }
        // `lean_layout` derives no index: no insert, probe or negative-key
        // negation (the orbit loop's own negations stay).
        let indexed = if lean { 0 } else { fb.points.len() as u64 };
        fb.cost
            .count("hash_probes_uncharged", projected + indexed * 3);
        // `lazy_neg` (lean, so no scan and no index) forms none.
        let orbit_negations = if defer_neg {
            0
        } else {
            columns as u64 * inst.n as u64
        };
        fb.cost.count(
            "point_negations_uncharged",
            lifts / 2 + orbit_negations + indexed,
        );
        fb.cost.count("factor_point_inserts_uncharged", indexed);
        fb.cost.count(
            "factor_base_vec_bytes_floor_uncharged",
            (fb.points.len() * std::mem::size_of::<FastPoint>()
                + fb.col_of.len() * std::mem::size_of::<usize>()
                + fb.coef_of.len() * std::mem::size_of::<u64>()
                + fb.neg_index.len() * std::mem::size_of::<usize>()) as u64,
        );
        Ok(fb)
    }
}

/// **The cyclotomic-sparse base** (lead A2): abscissae `x = Σ_{k∈S} γ^k`
/// with `|S| = w`, `γ` a primitive `(2n+1)`-th root of unity — the second
/// Frobenius-stable family at prime `n`, with a polynomial membership
/// description (`cyclotomic_factor_base`).  Each abscissa's rational
/// points are projected into the subgroup by the cofactor and the
/// projected signed Frobenius orbits are folded onto one column each
/// with weights `±λ^t`, exactly as `compact-orbit-scan` does for raw
/// abscissae.  Needs `2n + 1` prime with `ord_{2n+1}(2) = n`
/// (`n ∈ {11, 23, 35, 39, …}` in the single-word range).
pub struct CyclotomicBase<'i> {
    pub instance: &'i BinaryInstance,
}

impl<'a> FactorBaseBuilder<BinaryGroup<'a>> for CyclotomicBase<'_> {
    fn name(&self) -> &str {
        "cyclotomic"
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "projected signed Frobenius orbits of the gamma-weight-{} abscissae (gamma a primitive (2n+1)-th root of unity)",
            params.get("w").unwrap_or("?")
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            (
                "w",
                "gamma-weight of the abscissae: x = sum of w distinct powers of gamma; the set has C(2n+1, w) elements",
            ),
            (
                "columns",
                "optional cap on the number of distinct projected signed orbits, in canonical abscissa order; 0 or absent takes them all",
            ),
        ]
    }

    fn build(
        &self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<FactorBase<FastPoint>, String> {
        use crate::cryptanalysis::cyclotomic_factor_base::CyclotomicField;
        let inst = self.instance;
        let kc = inst
            .koblitz
            .as_ref()
            .ok_or("cyclotomic requires a Koblitz curve")?;
        if ctx.r != inst.r || ctx.cofactor != inst.cofactor || ctx.field_degree != Some(inst.n) {
            return Err("cyclotomic context does not match its binary instance".into());
        }
        let w = usize::try_from(params.u64("w")?).map_err(|_| "w does not fit in usize")?;
        let column_cap = match params.get("columns") {
            None => 0usize,
            Some(_) => usize::try_from(params.u64("columns")?)
                .map_err(|_| "columns does not fit in usize")?,
        };
        if inst.n == 0 || inst.n >= 64 || inst.n.is_multiple_of(2) {
            return Err("cyclotomic requires an odd degree < 64".into());
        }
        let field = CyclotomicField::new(&inst.irreducible, inst.n)?;
        let abscissae = field.gamma_weight_set(w)?;
        let lambda = kc
            .lambda
            .to_u64()
            .ok_or("Frobenius eigenvalue does not fit in u64")?;
        let g = ctx.group;
        let mut seen = HashSet::new();
        let mut points = Vec::new();
        let mut col_of = Vec::new();
        let mut coef_of = Vec::new();
        let (mut lifts, mut projected, mut frobenius_maps) = (0u64, 0u64, 0u64);
        'outer: for x in &abscissae {
            let raw_x = x.raw_bits().first().copied().unwrap_or(0);
            for point in inst.points_with_x(raw_x) {
                lifts += 1;
                let seed = g.mul(ops, point, ctx.cofactor);
                if g.is_identity(&seed) {
                    continue;
                }
                projected += 1;
                let mut xk = seed.x;
                let mut key = xk;
                for _ in 1..inst.n {
                    xk = inst.gf.sqr(xk);
                    key = key.min(xk);
                }
                if !seen.insert(key) {
                    continue;
                }
                if !g.is_identity(&g.mul(ops, seed, ctx.r)) {
                    return Err(format!("projected point from x {raw_x} has wrong order"));
                }
                let column = seen.len() - 1;
                let mut member = seed;
                let mut coefficient = 1u64;
                for _ in 0..inst.n {
                    if !inst.fast.is_on_curve(member) {
                        return Err(format!("Frobenius image from x {raw_x} is off curve"));
                    }
                    points.push(member);
                    col_of.push(column);
                    coef_of.push(coefficient);
                    points.push(g.neg(member));
                    col_of.push(column);
                    coef_of.push((ctx.r - coefficient) % ctx.r);
                    member = inst.fast.frobenius_k(member, 1);
                    frobenius_maps += 1;
                    coefficient = ((coefficient as u128 * lambda as u128) % ctx.r as u128) as u64;
                }
                if member != seed || coefficient != 1 {
                    return Err(format!("Frobenius orbit from x {raw_x} is not closed"));
                }
                if column_cap > 0 && seen.len() == column_cap {
                    break 'outer;
                }
            }
        }
        let columns = seen.len();
        if columns == 0 {
            return Err(format!(
                "no gamma-weight-{w} abscissa carries a subgroup point on {}",
                inst.name
            ));
        }
        let mut fb = FactorBase::from_column_map(
            format!(
                "{columns} projected signed Frobenius orbits of the {} gamma-weight-{w} abscissae",
                abscissae.len()
            ),
            points,
            col_of,
            coef_of,
            columns,
            |p| p.pack(),
            |p| inst.fast.neg(*p).pack(),
            |p| p.x,
        )?;
        fb.cost
            .count("abscissae_enumerated_uncharged", abscissae.len() as u64);
        fb.cost.count("point_lifts_uncharged", lifts);
        fb.cost.count("cofactor_projected_points", projected);
        fb.cost.count("frobenius_maps", frobenius_maps);
        Ok(fb)
    }
}

/// Projected signed Frobenius orbits of the ONB Hamming-weight-`w`
/// abscissae. Same fold as [`CyclotomicBase`]; the generator set is the
/// normal basis rather than powers of γ. Spec: `onb-weight:w=W[,columns=N]`.
pub struct OnbWeightBase<'i> {
    pub instance: &'i BinaryInstance,
}

impl<'a> FactorBaseBuilder<BinaryGroup<'a>> for OnbWeightBase<'_> {
    fn name(&self) -> &str {
        "onb-weight"
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "projected signed Frobenius orbits of the ONB Hamming-weight-{} abscissae",
            params.get("w").unwrap_or("?")
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            (
                "w",
                "ONB Hamming weight of the abscissae; the set has C(n, w) elements before curve filtering",
            ),
            (
                "columns",
                "optional cap on the number of distinct projected signed orbits, in canonical abscissa order; 0 or absent takes them all",
            ),
        ]
    }

    fn build(
        &self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<FactorBase<FastPoint>, String> {
        use crate::cryptanalysis::cyclotomic_factor_base::CyclotomicField;
        let inst = self.instance;
        let kc = inst
            .koblitz
            .as_ref()
            .ok_or("onb-weight requires a Koblitz curve")?;
        if ctx.r != inst.r || ctx.cofactor != inst.cofactor || ctx.field_degree != Some(inst.n) {
            return Err("onb-weight context does not match its binary instance".into());
        }
        let w = usize::try_from(params.u64("w")?).map_err(|_| "w does not fit in usize")?;
        let column_cap = match params.get("columns") {
            None => 0usize,
            Some(_) => usize::try_from(params.u64("columns")?)
                .map_err(|_| "columns does not fit in usize")?,
        };
        if inst.n == 0 || inst.n >= 64 || inst.n.is_multiple_of(2) {
            return Err("onb-weight requires an odd degree < 64".into());
        }
        let field = CyclotomicField::new(&inst.irreducible, inst.n)?;
        let abscissae = field.onb_weight_set(w)?;
        let lambda = kc
            .lambda
            .to_u64()
            .ok_or("Frobenius eigenvalue does not fit in u64")?;
        let g = ctx.group;
        let mut seen = HashSet::new();
        let mut points = Vec::new();
        let mut col_of = Vec::new();
        let mut coef_of = Vec::new();
        let (mut lifts, mut projected, mut frobenius_maps) = (0u64, 0u64, 0u64);
        'outer: for x in &abscissae {
            let raw_x = x.raw_bits().first().copied().unwrap_or(0);
            for point in inst.points_with_x(raw_x) {
                lifts += 1;
                let seed = g.mul(ops, point, ctx.cofactor);
                if g.is_identity(&seed) {
                    continue;
                }
                projected += 1;
                let mut xk = seed.x;
                let mut key = xk;
                for _ in 1..inst.n {
                    xk = inst.gf.sqr(xk);
                    key = key.min(xk);
                }
                if !seen.insert(key) {
                    continue;
                }
                if !g.is_identity(&g.mul(ops, seed, ctx.r)) {
                    return Err(format!("projected point from x {raw_x} has wrong order"));
                }
                let column = seen.len() - 1;
                let mut member = seed;
                let mut coefficient = 1u64;
                for _ in 0..inst.n {
                    if !inst.fast.is_on_curve(member) {
                        return Err(format!("Frobenius image from x {raw_x} is off curve"));
                    }
                    points.push(member);
                    col_of.push(column);
                    coef_of.push(coefficient);
                    points.push(g.neg(member));
                    col_of.push(column);
                    coef_of.push((ctx.r - coefficient) % ctx.r);
                    member = inst.fast.frobenius_k(member, 1);
                    frobenius_maps += 1;
                    coefficient = ((coefficient as u128 * lambda as u128) % ctx.r as u128) as u64;
                }
                if member != seed || coefficient != 1 {
                    return Err(format!("Frobenius orbit from x {raw_x} is not closed"));
                }
                if column_cap > 0 && seen.len() == column_cap {
                    break 'outer;
                }
            }
        }
        let columns = seen.len();
        if columns == 0 {
            return Err(format!(
                "no ONB weight-{w} abscissa carries a subgroup point on {}",
                inst.name
            ));
        }
        let mut fb = FactorBase::from_column_map(
            format!(
                "{columns} projected signed Frobenius orbits of the {} ONB weight-{w} abscissae",
                abscissae.len()
            ),
            points,
            col_of,
            coef_of,
            columns,
            |p| p.pack(),
            |p| inst.fast.neg(*p).pack(),
            |p| p.x,
        )?;
        fb.cost
            .count("abscissae_enumerated_uncharged", abscissae.len() as u64);
        fb.cost.count("point_lifts_uncharged", lifts);
        fb.cost.count("cofactor_projected_points", projected);
        fb.cost.count("frobenius_maps", frobenius_maps);
        Ok(fb)
    }
}

/// The prime-field analogue of `koblitz-orbit`: the `size` smallest
/// abscissae, closed under the curve's automorphism group and folded
/// one orbit to a column.  `group` picks the group (`auto` takes what
/// the curve has); `no_fold` keeps the closed point set and folds by
/// negation only, which is the control that shows what the fold buys
/// on the same points.  See `glv_invariant_base`.
pub struct GlvOrbitBase<'i> {
    pub instance: &'i PrimeInstance,
}

impl FactorBaseBuilder<PrimeCurve> for GlvOrbitBase<'_> {
    fn name(&self) -> &str {
        "glv-orbit"
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "the closure of the {} smallest abscissae under the {} automorphism group, {}",
            params.get("size").unwrap_or("?"),
            params.get("group").unwrap_or("auto"),
            if params.flag("no_fold") {
                "folded by negation only (the control)"
            } else {
                "each orbit folded onto one column"
            }
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            (
                "size",
                "seed abscissae; the base is their closure under the group (3× as many on j = 0, 2× on j = 1728)",
            ),
            (
                "group",
                "auto (what the curve has), negation, j0 or j1728",
            ),
            (
                "no_fold",
                "1 to fold the same points by negation only: the control that shows what the fold buys",
            ),
        ]
    }

    fn build(
        &self,
        _ctx: &InstanceCtx<PrimeCurve>,
        params: &Params,
        _ops: &mut GroupOps,
    ) -> Result<FactorBase<PrimePoint>, String> {
        let size = params.u64("size")? as usize;
        if size == 0 {
            return Err("factor base size must be positive".into());
        }
        let group = AutomorphismGroup::parse(params.get("group").unwrap_or("auto"))?;
        let (fb, _) = glv_orbit_base(self.instance, size, group, !params.flag("no_fold"))?;
        Ok(fb)
    }
}

/// **Lead A1 on a prime-field CM curve**: the `Z[φ]` multiplier closure
/// over the curve's small CM endomorphism (`D = −7, −8`: degree 2;
/// `D = −11`: degree 3; or the free automorphism of a `j = 0` / `1728` curve), the prime-field twin of
/// `compact-orbit-scan:norm=N`.  Every seed `P` contributes, for each
/// `α = a + bφ` of norm `a² + t·ab + d·b² ≤ norm` (`φ² − tφ + d = 0`),
/// the point `α(P) = [a]P + [b]φ(P)` on `P`'s column with weight
/// `a + bλ`, so `K` seeds behave like `K·M` independent points for the
/// pair table while the rank stage needs `K + 1` relations.  `norm = 0`
/// takes the seeds alone (the control).  The endomorphism comes from
/// `glv_invariant_base::velu_degree{2,3}_endomorphisms`; its evaluation
/// is charged as one inversion-equivalent group addition per image.
pub struct CmMultiplierBase<'i> {
    pub instance: &'i PrimeInstance,
}

impl FactorBaseBuilder<PrimeCurve> for CmMultiplierBase<'_> {
    fn name(&self) -> &str {
        "cm-multiplier"
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "{} {} seeds, each with its Z[phi] multiples of norm <= {}, {} columns",
            params.get("size").unwrap_or("?"),
            params.get("seed_source").unwrap_or("smallest-abscissa"),
            params.get("norm").unwrap_or("0"),
            params.get("column_mode").unwrap_or("weighted")
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            ("size", "seed abscissae (columns)"),
            (
                "norm",
                "include alpha(P) for every alpha = a + b*phi of norm <= this; 0 or absent: seeds only",
            ),
            ("endo", "index of the curve's CM endomorphism; default 0"),
            (
                "mult",
                "also include [m]P for m = 2..=mult with weight m, built as an arithmetic progression; `sqrt` targets about sqrt(r) signed vertices; default 1",
            ),
            (
                "column_mode",
                "weighted (default): one known-weight column per seed; independent: one column per identical signed point pair",
            ),
            (
                "seed_source",
                "smallest (default) or isogeny (PKM auxiliary-curve tower)",
            ),
            ("aux_t", "isogeny seed source: tower height"),
            ("aux_seed", "isogeny seed source: public tower/search seed, default 0"),
            (
                "aux",
                "isogeny seed source: ordinary (default), supersingular, ss-j1728, ss-j1728-twist, ss-j0 or ss-j0-twist",
            ),
        ]
    }

    fn build(
        &self,
        ctx: &InstanceCtx<PrimeCurve>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<FactorBase<PrimePoint>, String> {
        use crate::cryptanalysis::glv_invariant_base::{
            smallest_abscissa_points, velu_degree2_endomorphisms, velu_degree3_endomorphisms,
            Endomorphism,
        };
        let inst = self.instance;
        let g = ctx.group;
        let r = ctx.r;
        let size = params.u64("size")? as usize;
        if size == 0 {
            return Err("size must be positive".into());
        }
        let independent_columns = match params.get("column_mode").unwrap_or("weighted") {
            "weighted" => false,
            "independent" => true,
            other => {
                return Err(format!(
                    "column_mode is weighted or independent, not `{other}`"
                ))
            }
        };
        let norm_cap = match params.get("norm") {
            None => 0i64,
            Some(_) => params.u64("norm")? as i64,
        };
        let which = match params.get("endo") {
            None => 0usize,
            Some(_) => params.u64("endo")? as usize,
        };
        let mut endos: Vec<Box<dyn Endomorphism<PrimeCurve>>> = Vec::new();
        // The curve's own automorphism (`j = 0`: zeta_3, `j = 1728`: i) is
        // free to evaluate; it comes first, after the leading negation.
        if let Ok(gens) = crate::cryptanalysis::glv_invariant_base::automorphism_generators(
            inst,
            AutomorphismGroup::Auto,
        ) {
            endos.extend(gens.into_iter().skip(1));
        }
        for e in velu_degree2_endomorphisms(inst) {
            endos.push(Box::new(e));
        }
        for e in velu_degree3_endomorphisms(inst) {
            endos.push(Box::new(e));
        }
        let mult_u64 = match params.get("mult") {
            None => 1,
            Some("sqrt") => {
                let signed_target = r.isqrt().max(2);
                let denominator = (size as u64).saturating_mul(2).max(1);
                signed_target
                    .saturating_add(denominator - 1)
                    .checked_div(denominator)
                    .unwrap_or(1)
                    .max(1)
            }
            Some(_) => params.u64("mult")?.max(1),
        };
        let mult = i64::try_from(mult_u64).map_err(|_| "mult exceeds i64")?;
        if norm_cap > 0 && endos.is_empty() {
            return Err(
                "cm-multiplier needs a curve with a rational degree-2 or degree-3 CM endomorphism (--family d7, d8 or d11)".into(),
            );
        }
        let endo = endos.get(which);
        let (lambda, degree, trace) = match endo {
            Some(e) => {
                let l = e.eigenvalue();
                let d = e.degree() as i64;
                let lm = l as i128;
                let rm = r as i128;
                let t = (-8i64..=8)
                    .find(|&t| (lm * lm - t as i128 * lm + d as i128).rem_euclid(rm) == 0)
                    .ok_or("eigenvalue does not satisfy a small characteristic polynomial")?;
                (l, d, t)
            }
            None => (0, 0, 0),
        };
        let mut multipliers: Vec<(i64, i64)> = Vec::new();
        if norm_cap > 0 {
            let bound = ((4 * norm_cap) as f64).sqrt() as i64 + 2;
            for a in -bound..=bound {
                for b in -bound..=bound {
                    if (a, b) != (0, 0) && a * a + trace * a * b + degree * b * b <= norm_cap {
                        multipliers.push((a, b));
                    }
                }
            }
        }
        for m in 2..=mult {
            if !multipliers.contains(&(m, 0)) {
                multipliers.push((m, 0));
            }
        }
        let to_scalar = |v: i64| -> u64 { v.rem_euclid(r as i64) as u64 };
        let mut points: Vec<PrimePoint> = Vec::new();
        let mut col_of: Vec<usize> = Vec::new();
        let mut coef_of: Vec<u64> = Vec::new();
        let mut seen: HashSet<u64> = HashSet::new();
        let mut seed_count = 0usize;
        let mut columns = 0usize;
        let mut endo_applies = 0u64;
        let mut progression_adds = 0u64;
        let push_pair = |points: &mut Vec<PrimePoint>,
                         col_of: &mut Vec<usize>,
                         coef_of: &mut Vec<u64>,
                         q: PrimePoint,
                         column: usize,
                         weight: u64| {
            points.push(q);
            col_of.push(column);
            coef_of.push(weight);
            let nq = g.neg(q);
            if nq != q {
                points.push(nq);
                col_of.push(column);
                coef_of.push((r - weight) % r);
            }
        };
        // Seeds come either from the ordinary smallest-abscissa control or
        // from PKM's auxiliary-curve isogeny tower. The latter's group work
        // is charged through `ops`; its native/work counters are merged below.
        let mut source_cost = None;
        let candidates = match params.get("seed_source").unwrap_or("smallest") {
            "smallest" => smallest_abscissa_points(inst, 2 * size + 16),
            "isogeny" => {
                let mut aux_params = Params::default();
                aux_params.set("t", params.u64("aux_t")?.to_string());
                aux_params.set("seed", params.u64_or("aux_seed", 0)?.to_string());
                aux_params.set("aux", params.get("aux").unwrap_or("ordinary"));
                let source = crate::cryptanalysis::ic_framework::prime_tower::PrimeIsogenyBase {
                    instance: inst,
                }
                .build(ctx, &aux_params, ops)?;
                source_cost = Some(source.cost.clone());
                source.points
            }
            other => return Err(format!("seed_source is smallest or isogeny, not `{other}`")),
        };
        let mut last_x = u64::MAX;
        for cand in &candidates {
            if cand.x == last_x {
                continue;
            }
            last_x = cand.x;
            let seed = if ctx.cofactor == 1 {
                *cand
            } else {
                g.mul(ops, *cand, ctx.cofactor)
            };
            let nseed = g.neg(seed);
            if g.is_identity(&seed) || seen.contains(&g.key(&seed)) || seen.contains(&g.key(&nseed))
            {
                continue;
            }
            seen.insert(g.key(&seed));
            seen.insert(g.key(&nseed));
            let seed_column = columns;
            columns += 1;
            seed_count += 1;
            push_pair(&mut points, &mut col_of, &mut coef_of, seed, seed_column, 1);
            if !multipliers.is_empty() {
                let phi_seed = match endo {
                    Some(e) if multipliers.iter().any(|&(_, mb)| mb != 0) => {
                        endo_applies += 1;
                        if e.degree() > 1 {
                            ops.adds += 1; // an inversion-equivalent evaluation of phi
                        }
                        e.apply(g, seed)
                    }
                    _ => g.identity(),
                };
                // Build integer multiples once as P, 2P, ..., mP. Both
                // column modes execute this before assigning image columns,
                // so their construction transcript is identical.
                let mut integer_multiples = Vec::with_capacity(mult_u64 as usize + 1);
                integer_multiples.push(g.identity());
                integer_multiples.push(seed);
                for m in 2..=mult_u64 {
                    let next = g.add(ops, integer_multiples[(m - 1) as usize], seed);
                    progression_adds += 1;
                    integer_multiples.push(next);
                }
                for &(ma, mb) in &multipliers {
                    let sa = to_scalar(ma);
                    let sb = to_scalar(mb);
                    let pa = if mb == 0 && ma >= 0 && (ma as u64) <= mult_u64 {
                        integer_multiples[ma as usize]
                    } else if sa == 0 {
                        g.identity()
                    } else {
                        g.mul(ops, seed, sa)
                    };
                    let pb = if sb == 0 {
                        g.identity()
                    } else {
                        g.mul(ops, phi_seed, sb)
                    };
                    let image = g.add(ops, pa, pb);
                    if g.is_identity(&image) {
                        continue;
                    }
                    let nimg = g.neg(image);
                    if seen.contains(&g.key(&image)) || seen.contains(&g.key(&nimg)) {
                        continue;
                    }
                    seen.insert(g.key(&image));
                    seen.insert(g.key(&nimg));
                    let weight = ((sa as u128 + (sb as u128 * lambda as u128) % r as u128)
                        % r as u128) as u64;
                    let (column, coefficient) = if independent_columns {
                        let column = columns;
                        columns += 1;
                        (column, 1)
                    } else {
                        (seed_column, weight)
                    };
                    push_pair(
                        &mut points,
                        &mut col_of,
                        &mut coef_of,
                        image,
                        column,
                        coefficient,
                    );
                }
            }
            if seed_count == size {
                break;
            }
        }
        if seed_count < size {
            return Err(format!("only {seed_count} of {size} seeds found"));
        }
        let curve = &inst.curve;
        let mut fb = FactorBase::from_column_map(
            format!(
                "{seed_count} seeds with Z[phi] multiples of norm <= {norm_cap}, {} columns ({} points)",
                columns,
                points.len()
            ),
            points,
            col_of,
            coef_of,
            columns,
            |p| curve.key(p),
            |p| curve.key(&curve.neg(*p)),
            |p| p.x,
        )?;
        if let Some(cost) = source_cost {
            for (name, value) in cost.native {
                fb.cost.count(&name, value);
            }
            fb.cost.work_all(&cost.work_native);
        }
        fb.cost.count("endomorphism_applies", endo_applies);
        fb.cost.count("multiplier_seeds", seed_count as u64);
        fb.cost
            .count("multiplier_progression_adds", progression_adds);
        fb.cost.count(
            "multiplier_independent_columns",
            u64::from(independent_columns),
        );
        Ok(fb)
    }
}

/// **Integer-multiple closure on any binary curve** (lead A1 without an
/// endomorphism): each seed `P` (a point with one of the smallest
/// abscissae, projected into the order-`r` subgroup) contributes
/// `[m]P` for `m = 1..=mult` on its own column with weight `m`, built by
/// repeated addition (one group addition per multiple).  `K` seeds then
/// behave like `K * mult` independent points for the pair table while
/// the rank stage needs only `K + 1` relations.  Nothing here uses
/// structure, so it applies to a random curve; as `K -> 1` it becomes a
/// baby-step/giant-step table (the honest limit of the idea).
pub struct BinaryMultiplierBase<'i> {
    pub instance: &'i BinaryInstance,
}

impl<'a> FactorBaseBuilder<BinaryGroup<'a>> for BinaryMultiplierBase<'_> {
    fn name(&self) -> &str {
        "binary-multiplier"
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "{} smallest-abscissa seeds, each with its multiples [1..{}]P on its column",
            params.get("size").unwrap_or("?"),
            params.get("mult").unwrap_or("1")
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            ("size", "seed abscissae (columns)"),
            (
                "mult",
                "include [m]P for m = 2..=mult with weight m; 1 or absent: seeds only",
            ),
        ]
    }

    fn build(
        &self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<FactorBase<FastPoint>, String> {
        let inst = self.instance;
        let g = ctx.group;
        let size = params.u64("size")? as usize;
        if size == 0 {
            return Err("size must be positive".into());
        }
        let mult = match params.get("mult") {
            None => 1u64,
            Some(_) => params.u64("mult")?.max(1),
        };
        let mut points: Vec<FastPoint> = Vec::new();
        let mut col_of: Vec<usize> = Vec::new();
        let mut coef_of: Vec<u64> = Vec::new();
        let mut seen: HashSet<u64> = HashSet::new();
        let mut columns = 0usize;
        let mut x = 1u64;
        let cap = (1u64 << inst.n.min(40)).min(1 << 24);
        while columns < size {
            if x >= cap {
                return Err(format!("only {columns} of {size} seeds in {cap} abscissae"));
            }
            let candidates = inst.points_with_x(x);
            x += 1;
            let Some(&cand) = candidates.first() else {
                continue;
            };
            let seed = if ctx.cofactor == 1 {
                cand
            } else {
                g.mul(ops, cand, ctx.cofactor)
            };
            if g.is_identity(&seed) {
                continue;
            }
            let column = columns;
            let mut member = seed;
            let mut added = 0usize;
            for m in 1..=mult {
                if m > 1 {
                    member = g.add(ops, member, seed);
                }
                if g.is_identity(&member) {
                    break;
                }
                let nm = g.neg(member);
                if seen.contains(&g.key(&member)) || seen.contains(&g.key(&nm)) {
                    continue;
                }
                seen.insert(g.key(&member));
                seen.insert(g.key(&nm));
                let weight = m % ctx.r;
                points.push(member);
                col_of.push(column);
                coef_of.push(weight);
                added += 1;
                if nm != member {
                    points.push(nm);
                    col_of.push(column);
                    coef_of.push((ctx.r - weight) % ctx.r);
                }
            }
            if added > 0 {
                columns += 1;
            } else {
                // Roll back nothing: no point of this seed was kept.
                continue;
            }
        }
        FactorBase::from_column_map(
            format!(
                "{columns} seeds with multiples [1..{mult}]P ({} points)",
                points.len()
            ),
            points,
            col_of,
            coef_of,
            columns,
            |p| p.pack(),
            |p| inst.fast.neg(*p).pack(),
            |p| p.x,
        )
    }
}

/// The `ψ`-stable line of a GLS twist over `F_{p²}`, folded by
/// `⟨−1, ψ⟩`; `no_fold` folds the same points by negation only.  See
/// `gls_fp2`.
pub struct GlsLineBase<'i> {
    pub instance: &'i GlsInstance,
}

impl FactorBaseBuilder<Fp2Curve> for GlsLineBase<'_> {
    fn name(&self) -> &str {
        "gls-line"
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "the ψ-stable line x ∈ u·s·F_p, {}",
            if params.flag("no_fold") {
                "folded by negation only (the control)"
            } else {
                "each ⟨−1, ψ⟩-orbit folded onto one column"
            }
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[(
            "no_fold",
            "1 to fold the same points by negation only: the control that shows what the fold buys",
        )]
    }

    fn build(
        &self,
        _ctx: &InstanceCtx<Fp2Curve>,
        params: &Params,
        _ops: &mut GroupOps,
    ) -> Result<FactorBase<Fp2Point>, String> {
        let (fb, _) = gls_line_base(self.instance, !params.flag("no_fold"))?;
        Ok(fb)
    }
}

// ── Decomposition oracles ──────────────────────────────────────────

/// `counters` with the marker that says the oracle's set-up counts all
/// its table work (`ecbench::work::known_uncounted`).
pub(crate) fn table_counted(mut counters: BTreeMap<String, u64>) -> BTreeMap<String, u64> {
    counters.insert("counted:table_insert_attempts".to_string(), 1);
    counters
}

/// The `batch` parameter of `subtract` and `mitm`: absent or `1` (the
/// default) takes [`CountedGroup::add_each_batched`], one field inversion a
/// block on a prime curve; `0` keeps the one-inversion-an-addition loop,
/// for an A/A comparison.  The two give the same points, relations and
/// charged additions; only the field tally differs.
fn batch_param(params: &Params, oracle: &str) -> Result<bool, String> {
    match params.get("batch") {
        None | Some("1") => Ok(true),
        Some("0") => Ok(false),
        Some(v) => Err(format!("{oracle}: batch is 0 or 1, not `{v}`")),
    }
}

/// Test `R − P ∈ F` for every signed base point: no table, `|F|` group
/// operations a target, and the honest baseline every table oracle is
/// an improvement on.
///
/// The candidates `R − P_i` come from [`CountedGroup::add_each_batched`]
/// (`batch=1`, the default): on a prime curve one inversion a block of
/// candidates instead of one a candidate, each finished only when it is
/// tested, so the candidates, their order, the relations and the charged
/// additions are the serial loop's (`batch=0`).
pub struct SubtractOracle {
    batch: bool,
}

/// The default `subtract` (`batch=1`), constructible by its bare name as
/// when the oracle was a unit struct.
#[allow(non_upper_case_globals)]
pub const SubtractOracle: SubtractOracle = SubtractOracle { batch: true };

impl SubtractOracle {
    /// `subtract` with the batched (`true`) or serial (`false`) candidates.
    pub fn with_batch(batch: bool) -> Self {
        Self { batch }
    }
}

impl Default for SubtractOracle {
    fn default() -> Self {
        Self::with_batch(true)
    }
}

impl<G: CountedGroup> DecompositionOracle<G> for SubtractOracle {
    fn name(&self) -> &str {
        "subtract"
    }

    fn summands(&self) -> u32 {
        2
    }

    fn describe(&self, _params: &Params) -> String {
        "for each signed base point P, test whether R − P is in the base".into()
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[(
            "batch",
            "1 (default): the candidates R − P with one field inversion a block (prime curves); \
             0: one inversion a candidate; same relations and additions",
        )]
    }

    fn prepare(
        &mut self,
        _ctx: &InstanceCtx<G>,
        _fb: &FactorBase<G::Elt>,
        params: &Params,
        _ops: &mut GroupOps,
    ) -> Result<(), String> {
        self.batch = batch_param(params, "subtract")?;
        Ok(())
    }

    fn setup_work_native(&self) -> BTreeMap<String, u64> {
        // No table: nothing is inserted.
        table_counted(BTreeMap::new())
    }

    fn decompose(
        &mut self,
        ctx: &InstanceCtx<G>,
        fb: &FactorBase<G::Elt>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: G::Elt,
    ) -> Option<Vec<usize>> {
        if self.batch {
            let g = ctx.group;
            let mut hit = None;
            g.add_each_batched(ops, point, &fb.points, true, &mut |_, i, rest| {
                counters.lookups += 1;
                match fb.index_of_key(g.key(&rest)) {
                    Some(j) => {
                        hit = Some(vec![i, j]);
                        true
                    }
                    None => false,
                }
            });
            return hit;
        }
        for (i, p) in fb.points.iter().enumerate() {
            let rest = ctx.group.add(ops, point, ctx.group.neg(*p));
            counters.lookups += 1;
            let key = ctx.group.key(&rest);
            if let Some(j) = fb.index_of_key(key) {
                return Some(vec![i, j]);
            }
        }
        None
    }
}

/// Meet in the middle over a pair table: memory for time, the lever
/// that makes a two-summand search `O(1)` a target instead of `O(|F|)`.
///
/// With `batch=1` (the default) the table's sums and the `m = 3` rows
/// `R − P_i` come from [`CountedGroup::add_each_batched`] (on a prime curve
/// one inversion a block, not one an addition): the same table, probes,
/// relations and charged additions as `batch=0`, the serial path, in
/// either layout.
pub struct MitmOracle {
    m: u32,
    lines: bool,
    batch: bool,
    table: Option<PairTable>,
}

impl MitmOracle {
    pub fn new(m: u32) -> Self {
        Self {
            m,
            lines: false,
            batch: true,
            table: None,
        }
    }
}

impl<G: CountedGroup> DecompositionOracle<G> for MitmOracle {
    fn name(&self) -> &str {
        "mitm"
    }

    fn summands(&self) -> u32 {
        self.m
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "a table of pair sums probed once per target (m = 2) or once per R − P (m = 3), {}",
            if params.flag("negation_folded") {
                "built with the negation fold"
            } else {
                "built in full"
            }
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            (
                "negation_folded",
                "1 to build only one of each ±pair, halving the table's additions",
            ),
            (
                "layout",
                "map (default) or lines (cache-line pair index and relation guard)",
            ),
            (
                "batch",
                "1 (default): table sums and m = 3 rows with one field inversion a block \
                 (prime curves); 0: one inversion an addition; same relations and additions",
            ),
        ]
    }

    fn prepare(
        &mut self,
        ctx: &InstanceCtx<G>,
        fb: &FactorBase<G::Elt>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<(), String> {
        self.batch = batch_param(params, "mitm")?;
        self.lines = match params.get("layout") {
            None | Some("map") => false,
            Some("lines") => true,
            Some(other) => return Err(format!("unknown layout `{other}`; use map or lines")),
        };
        if self.lines && !params.flag("negation_folded") {
            return Err("layout=lines requires negation_folded=1".into());
        }
        let table = if self.lines {
            if self.batch {
                PairTable::build_negation_folded_lines_batched(ctx.group, fb)
            } else {
                PairTable::build_negation_folded_lines(ctx.group, fb)
            }
        } else if params.flag("negation_folded") {
            if self.batch {
                PairTable::build_negation_folded_batched(ctx.group, fb)
            } else {
                PairTable::build_negation_folded(ctx.group, fb)
            }
        } else if self.batch {
            PairTable::build_batched(ctx.group, fb)
        } else {
            PairTable::build(ctx.group, fb)
        };
        // The table's construction is part of the pipeline's cost.
        ops.merge(table.build_ops);
        self.table = Some(table);
        Ok(())
    }

    fn setup_work_native(&self) -> BTreeMap<String, u64> {
        table_counted(
            self.table
                .as_ref()
                .map(PairTable::work_counters)
                .unwrap_or_default(),
        )
    }

    fn decompose(
        &mut self,
        ctx: &InstanceCtx<G>,
        fb: &FactorBase<G::Elt>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: G::Elt,
    ) -> Option<Vec<usize>> {
        let table = self.table.as_ref()?;
        if self.batch && self.m == 3 {
            // `decompose_mitm`'s `m = 3` loop, its rows `R − P_i` batched.
            let g = ctx.group;
            let mut hit = None;
            g.add_each_batched(ops, point, &fb.points, true, &mut |ops, i, s| {
                if g.is_identity(&s) {
                    return false;
                }
                match table.probe(g, fb, ops, &mut counters.lookups, s) {
                    Some((j, k)) => {
                        hit = Some(vec![i, j, k]);
                        true
                    }
                    None => false,
                }
            });
            return hit;
        }
        decompose_mitm(ctx.group, fb, table, self.m, ops, counters, point)
    }

    fn touch(&self, ctx: &InstanceCtx<G>, point: &G::Elt) {
        if let Some(table) = &self.table {
            table.prefetch(ctx.group, point);
        }
    }

    fn line_guard(&self) -> bool {
        self.lines
    }
}

/// How the coset filter labelled the base, for the report.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct CosetFilter {
    /// `off` (`m ≠ 2` or cofactor 1), `trace` (cofactor 2: the
    /// `Tr(x) = Tr(a)` test, field squarings only) or `scalar` (one
    /// `[r]P` per `±` pair of base points, charged as group operations).
    pub mode: &'static str,
    /// Points of the base that lie in the subgroup `⟨G⟩`.
    pub in_subgroup: u64,
    /// Distinct classes seen among the base points.
    pub classes: u64,
    /// Field squarings the trace test performed (counted, uncharged).
    pub label_squarings: u64,
}

/// The coset classes of a base, as the per-point keys `(key(T_i),
/// key(−T_i))` with `T_i = [r]P_i ∈ E[h]` (or the parity class when the
/// group reads it for free and the cofactor is 2).
///
/// A target `R = [a]G + [b]Q` lies in the subgroup `⟨G⟩` of index `h`, and
/// `P_i + P_j = R` forces the classes of `P_i` and `P_j` in `E/⟨G⟩` to
/// cancel, so a pair whose classes do not cancel is a table entry no
/// subgroup target can reach (`±R` share a class).  `None` when the filter
/// does nothing (cofactor 1).  The scalar labels run on `ops` and so are
/// charged; the trace test costs field squarings only, reported in
/// `report.label_squarings`.
pub fn coset_classes<G: CountedGroup>(
    ctx: &InstanceCtx<G>,
    fb: &FactorBase<G::Elt>,
    ops: &mut GroupOps,
    report: &mut CosetFilter,
) -> Option<Vec<(u64, u64)>> {
    let g = ctx.group;
    if ctx.cofactor <= 1 {
        report.mode = "off";
        return None;
    }
    let parity: Option<Vec<u8>> = if ctx.cofactor == 2 {
        fb.points.iter().map(|p| g.coset_parity(p)).collect()
    } else {
        None
    };
    let classes: Vec<(u64, u64)> = match parity {
        Some(par) => {
            report.mode = "trace";
            report.label_squarings = par.len() as u64 * g.coset_parity_squarings();
            // With two classes each is its own negative.
            par.iter().map(|&c| (u64::from(c), u64::from(c))).collect()
        }
        None => {
            report.mode = "scalar";
            // One `[r]P` per ± pair: `[r](−P) = −[r]P`.
            let mut out: Vec<Option<(u64, u64)>> = vec![None; fb.points.len()];
            for i in 0..fb.points.len() {
                if out[i].is_some() {
                    continue;
                }
                let t = g.mul(ops, fb.points[i], ctx.r);
                let (k, nk) = (g.key(&t), g.key(&g.neg(t)));
                out[i] = Some((k, nk));
                let j = fb.neg_index[i];
                if j < out.len() && out[j].is_none() {
                    out[j] = Some((nk, k));
                }
            }
            out.into_iter()
                .map(|c| c.expect("every point labelled"))
                .collect()
        }
    };
    let identity_key = if report.mode == "trace" {
        0
    } else {
        g.key(&g.identity())
    };
    report.in_subgroup = classes.iter().filter(|(k, _)| *k == identity_key).count() as u64;
    let mut seen: Vec<u64> = classes.iter().map(|(k, _)| *k).collect();
    seen.sort_unstable();
    seen.dedup();
    report.classes = seen.len() as u64;
    Some(classes)
}

/// **`mitm-coset`: `mitm` over the coset-filtered pair table.**
///
/// On a curve with cofactor `h` only pairs whose classes in `E/⟨G⟩` cancel
/// can sum to a subgroup target, so the table is built over those pairs
/// alone, visiting them in the full build's order: every key a subgroup
/// target can hit keeps the first witness `mitm` stores, and the probe,
/// its lookups and its verifying addition are `mitm`'s (`m = 2` only; at
/// `m = 3` the probed `R − P` leaves the subgroup, so the table is built
/// in full and nothing is labelled).  Cofactor 2 reads each point's class
/// from `Tr(x) = Tr(a)` (field squarings, counted as
/// `mitm_coset_label_field_squarings_uncharged`); larger cofactors charge
/// one `[r]P` per `±` pair of base points to the oracle-setup phase.  On a
/// base inside one coset (subgroup orbits, Koblitz divisors without
/// `x + 1`) the filter keeps every pair and the labelling is a pure cost.
pub struct CosetMitmOracle {
    m: u32,
    table: Option<PairTable>,
    pub coset: CosetFilter,
}

impl CosetMitmOracle {
    pub fn new(m: u32) -> Self {
        Self {
            m,
            table: None,
            coset: CosetFilter::default(),
        }
    }
}

impl<G: CountedGroup> DecompositionOracle<G> for CosetMitmOracle {
    fn name(&self) -> &str {
        "mitm-coset"
    }

    fn summands(&self) -> u32 {
        self.m
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "`mitm` over a pair table restricted to the pairs whose classes in E/⟨G⟩ cancel (m = 2; same entries and first witnesses as mitm for every subgroup target), {}",
            if params.flag("negation_folded") {
                "built with the negation fold"
            } else {
                "built in full"
            }
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            ("m", "summands, 2 or 3 (the filter is a no-op at 3)"),
            (
                "negation_folded",
                "1 to build only one of each ±pair, halving the table's additions",
            ),
        ]
    }

    fn prepare(
        &mut self,
        ctx: &InstanceCtx<G>,
        fb: &FactorBase<G::Elt>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<(), String> {
        let mut label_ops = GroupOps::default();
        self.coset = CosetFilter {
            mode: "off",
            ..Default::default()
        };
        let classes = if self.m == 2 {
            coset_classes(ctx, fb, &mut label_ops, &mut self.coset)
        } else {
            None
        };
        let keep = classes
            .as_ref()
            .map(|c| move |i: usize, j: usize| c[i].0 == c[j].1);
        let keep_ref: Option<&dyn Fn(usize, usize) -> bool> =
            keep.as_ref().map(|k| k as &dyn Fn(usize, usize) -> bool);
        let table = if params.flag("negation_folded") {
            PairTable::build_negation_folded_filtered(ctx.group, fb, keep_ref)
        } else {
            PairTable::build_filtered(ctx.group, fb, keep_ref)
        };
        // The labelling's group operations and the table's construction
        // are both part of the pipeline's cost.
        ops.merge(label_ops);
        ops.merge(table.build_ops);
        self.table = Some(table);
        Ok(())
    }

    fn setup_native(&self) -> BTreeMap<String, u64> {
        let mut out = BTreeMap::new();
        if self.coset.mode != "off" && !self.coset.mode.is_empty() {
            out.insert("mitm_coset_in_subgroup".into(), self.coset.in_subgroup);
            out.insert("mitm_coset_classes".into(), self.coset.classes);
            out.insert(
                "mitm_coset_scalar_labels".into(),
                u64::from(self.coset.mode == "scalar"),
            );
            if self.coset.label_squarings > 0 {
                out.insert(
                    "mitm_coset_label_field_squarings_uncharged".into(),
                    self.coset.label_squarings,
                );
            }
        }
        out
    }

    fn setup_work_native(&self) -> BTreeMap<String, u64> {
        table_counted(
            self.table
                .as_ref()
                .map(PairTable::work_counters)
                .unwrap_or_default(),
        )
    }

    fn decompose(
        &mut self,
        ctx: &InstanceCtx<G>,
        fb: &FactorBase<G::Elt>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: G::Elt,
    ) -> Option<Vec<usize>> {
        let table = self.table.as_ref()?;
        decompose_mitm(ctx.group, fb, table, self.m, ops, counters, point)
    }

    fn touch(&self, ctx: &InstanceCtx<G>, point: &G::Elt) {
        if let Some(table) = &self.table {
            table.prefetch(ctx.group, point);
        }
    }
}

/// One probe per target into a table of every signed `k`-sum of the base
/// ([`KSumTable`]): the `mitm` lever pushed from pairs to triples or
/// quadruples, trading a smaller base for a larger table.
pub struct KSumOracle {
    k: u32,
    table: Option<KSumTable>,
    /// `free=1`: the build's key collisions are verified and handed to
    /// the relation loop as target-free rows, once, with the first trial.
    free: bool,
    free_pending: bool,
    free_checked: u64,
    free_emitted: u64,
    /// `walk_sib=m`: the `StrideRenewSib { m }` target walk (sibling pairs
    /// around a block centre, the minus side probed by abscissa through
    /// [`KSumTable::probe_x`]); 0 (the default) is the incumbent walk.
    walk_sib: u32,
}

impl KSumOracle {
    pub fn new(k: u32) -> Self {
        Self {
            k,
            table: None,
            free: false,
            free_pending: false,
            free_checked: 0,
            free_emitted: 0,
            walk_sib: 0,
        }
    }
}

impl<G: CountedGroup> DecompositionOracle<G> for KSumOracle {
    fn name(&self) -> &str {
        "ksum"
    }

    fn summands(&self) -> u32 {
        self.k
    }

    fn describe(&self, _params: &Params) -> String {
        format!(
            "a table of every signed {}-sum of the base, built with the negation fold and probed once per target",
            self.k
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            ("m", "summands, 3 to 9 (the packed index is 12 bits for m <= 5, 64/m bits above: bases of up to 1023, 511, 255, 127 points for m = 6..9)"),
            ("free", "1: verify the table's key collisions and use them as target-free relations (default 0)"),
            ("prune", "1: skip the adds of partial sums that cannot be completed to m summands; same table, fewer build adds (default 0)"),
            ("split", "1: form the last two summands of every sum from a precomputed pair-sum table (two adds per abscissa pair) instead of building the (m-1)-summand partial sums; same table, fewer build adds; not with sib=1 (default 0)"),
            ("sib", "1 (prime curves; not with split=1): the last level forms both signs x(S + P), x(S - P) of a base pair from ONE inversion; same table, keys and witnesses. Charged as ONE group addition plus one unit of the native counter sibling_second_points (sqr + 2 add), the walk's convention, so the band prices the second point at w (default 0)"),
            ("prefix", "1: also key the partial sums of fewer than m summands the build forms anyway (base points, lower-level partials, pair sums), under keys no m-sum took; no added group operation, one counted insert attempt each (default 0)"),
            ("walk_sib", "0..=64 (needs targets=stride-renew or stride-renew-joint; default 0): the same target progression formed in blocks of 2m+1 around a centre C = A + [m+1]S, C + [i]S full and x(C - [i]S) from ONE inversion; the abscissa probed by one counted lookup and, on a hit, formed by one more addition; a pair is charged one group addition plus one sibling_second_points (priced at w); the multiples [2]S..[m+1]S (m operations) each time the stride is drawn or renewed, one addition a centre"),
        ]
    }

    fn prepare(
        &mut self,
        ctx: &InstanceCtx<G>,
        fb: &FactorBase<G::Elt>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<(), String> {
        self.free = params.flag("free");
        self.free_pending = self.free;
        self.walk_sib = walk_sib(params)?;
        let table = KSumTable::build_negation_folded_prefix(
            ctx.group,
            fb,
            self.k,
            self.free,
            params.flag("prune"),
            params.flag("split"),
            params.flag("sib"),
            params.flag("prefix"),
        )?;
        // The table's construction is part of the pipeline's cost.
        ops.merge(table.build_ops);
        self.table = Some(table);
        Ok(())
    }

    fn setup_work_native(&self) -> BTreeMap<String, u64> {
        table_counted(
            self.table
                .as_ref()
                .map(KSumTable::work_counters)
                .unwrap_or_default(),
        )
    }

    fn decompose(
        &mut self,
        ctx: &InstanceCtx<G>,
        fb: &FactorBase<G::Elt>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: G::Elt,
    ) -> Option<Vec<usize>> {
        let table = self.table.as_ref()?;
        table.probe(ctx.group, fb, ops, &mut counters.lookups, point)
    }

    fn walk_siblings(&self) -> u32 {
        self.walk_sib
    }

    fn probe_x(
        &mut self,
        _ctx: &InstanceCtx<G>,
        _fb: &FactorBase<G::Elt>,
        counters: &mut OracleCounters,
        x: u64,
    ) -> Option<bool> {
        if self.walk_sib == 0 {
            return None;
        }
        let table = self.table.as_ref()?;
        Some(table.probe_x(&mut counters.lookups, x))
    }

    #[allow(clippy::too_many_arguments)]
    fn decompose_relations(
        &mut self,
        ctx: &InstanceCtx<G>,
        fb: &FactorBase<G::Elt>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: G::Elt,
        _a: u64,
        _b: u64,
    ) -> Vec<Relation> {
        let mut out = Vec::new();
        if self.free_pending {
            self.free_pending = false;
            if let Some(table) = self.table.as_ref() {
                let (rows, checked) = table.free_rows(ctx.group, fb, ctx.r, ops);
                self.free_checked = checked;
                self.free_emitted = rows.len() as u64;
                out.extend(rows.into_iter().map(|columns| Relation::Row {
                    columns,
                    a: 0,
                    b: 0,
                }));
            }
        }
        if let Some(summands) = self.decompose(ctx, fb, ops, counters, point) {
            out.push(Relation::Summands(summands));
        }
        out
    }

    fn relation_counters(&self) -> BTreeMap<String, u64> {
        let mut m = BTreeMap::new();
        if self.free {
            m.insert("free_collisions_checked".to_string(), self.free_checked);
            m.insert("free_rows_emitted".to_string(), self.free_emitted);
        }
        if let Some(table) = self.table.as_ref().filter(|t| t.prefix) {
            m.insert("ksum_prefix_entries".to_string(), table.prefix_entries);
        }
        m
    }
}

#[cfg(test)]
mod ksum_split_tests {
    use super::*;
    use crate::cryptanalysis::ic_boundary::{roster_prime_instance, Calibration};
    use crate::cryptanalysis::ic_framework::stages::Targets;
    use crate::cryptanalysis::ic_framework::{run_pipeline, PipelineSpec};

    /// `split=1` leaves every output of a run unchanged (recovered log,
    /// relations, trials, rank, every relation-phase operation and
    /// counter, the table's insert count) and lowers only the
    /// oracle-setup additions; off (absent or `split=0`) it is the
    /// unsplit build exactly.
    #[test]
    fn split_runs_are_identical_but_for_fewer_setup_adds() {
        let inst = roster_prime_instance(20).unwrap();
        let g = inst.generator_point();
        let mut ops = GroupOps::default();
        let planted = 300_011 % inst.r;
        let q = CountedGroup::mul(&inst.curve, &mut ops, g, planted);
        let ctx = InstanceCtx {
            group: &inst.curve,
            generator: g,
            target: q,
            r: inst.r,
            cofactor: inst.cofactor,
            group_order: inst.group_order,
            name: inst.name.clone(),
            field_degree: None,
        };
        let base = PrimeAbscissaBase { instance: &inst };
        for (k, size, targets) in [
            (4u32, "12", Targets::Walk),
            (5, "10", Targets::Walk),
            (5, "10", Targets::StrideRenew),
        ] {
            let run = |extra: &str| {
                let mut spec = PipelineSpec {
                    factor_base: "prime-abscissa".into(),
                    oracle: "ksum".into(),
                    targets,
                    max_trials: 50_000_000,
                    seed: 11,
                    ..Default::default()
                };
                spec.factor_base_params.set("size", size);
                spec.oracle_params.set("prune", "1");
                if !extra.is_empty() {
                    spec.oracle_params.set("split", extra);
                }
                let mut oracle = KSumOracle::new(k);
                run_pipeline(
                    &ctx,
                    &spec,
                    &base,
                    &mut oracle,
                    planted,
                    &Calibration::default(),
                    None,
                )
                .expect("the configuration should run")
            };
            let (plain, off, on) = (run(""), run("0"), run("1"));
            for r in [&plain, &off, &on] {
                assert!(r.verified, "k = {k}");
                assert_eq!(r.recovered, Some(planted));
            }
            let d = |r: &crate::cryptanalysis::ic_framework::RunReport| {
                (
                    r.decomposition.targets_tried,
                    r.decomposition.relations_found,
                    r.decomposition.cost.group_ops,
                    r.decomposition.cost.native.clone(),
                    r.decomposition.cost.work_native.clone(),
                    r.decomposition.setup.native.clone(),
                    r.decomposition.setup.work_native.clone(),
                    r.linear_algebra.rank,
                )
            };
            assert_eq!(d(&plain), d(&on), "k = {k}");
            assert_eq!(d(&plain), d(&off), "k = {k}");
            assert_eq!(
                plain.decomposition.setup.group_ops,
                off.decomposition.setup.group_ops
            );
            let (su, ss) = (
                plain.decomposition.setup.group_ops,
                on.decomposition.setup.group_ops,
            );
            assert!(
                ss.adds < su.adds,
                "k = {k}: {} against {}",
                ss.adds,
                su.adds
            );
            assert_eq!((ss.doubles, ss.scalar_mults), (su.doubles, su.scalar_mults));
            assert!(on.total_gae < plain.total_gae);
        }
    }

    fn ksum_run(
        k: u32,
        size: &str,
        targets: Targets,
        prefix: &str,
        seed: u64,
    ) -> (crate::cryptanalysis::ic_framework::RunReport, u64) {
        let inst = roster_prime_instance(20).unwrap();
        let g = inst.generator_point();
        let mut ops = GroupOps::default();
        let planted = (300_011 + 7919 * seed) % inst.r;
        let q = CountedGroup::mul(&inst.curve, &mut ops, g, planted);
        let ctx = InstanceCtx {
            group: &inst.curve,
            generator: g,
            target: q,
            r: inst.r,
            cofactor: inst.cofactor,
            group_order: inst.group_order,
            name: inst.name.clone(),
            field_degree: None,
        };
        let base = PrimeAbscissaBase { instance: &inst };
        let mut spec = PipelineSpec {
            factor_base: "prime-abscissa".into(),
            oracle: "ksum".into(),
            targets,
            max_trials: 50_000_000,
            seed,
            ..Default::default()
        };
        spec.factor_base_params.set("size", size);
        spec.oracle_params.set("prune", "1");
        spec.oracle_params.set("split", "1");
        if !prefix.is_empty() {
            spec.oracle_params.set("prefix", prefix);
        }
        let mut oracle = KSumOracle::new(k);
        let report = run_pipeline(
            &ctx,
            &spec,
            &base,
            &mut oracle,
            planted,
            &Calibration::default(),
            None,
        )
        .expect("the configuration should run");
        (report, planted)
    }

    /// `prefix=0` (or absent) is the build without it, run for run;
    /// `prefix=1` adds no set-up group operation, keys more sums and
    /// still recovers the planted log, with relations of fewer summands
    /// accepted by the elimination.
    #[test]
    fn prefix_off_is_identical_and_on_adds_no_setup_operation() {
        for (k, size) in [(4u32, "12"), (5, "10")] {
            for seed in [11u64, 12, 13] {
                let (plain, planted) = ksum_run(k, size, Targets::StrideRenew, "", seed);
                let (off, _) = ksum_run(k, size, Targets::StrideRenew, "0", seed);
                let (on, _) = ksum_run(k, size, Targets::StrideRenew, "1", seed);
                for r in [&plain, &off, &on] {
                    assert!(r.verified, "k = {k}");
                    assert_eq!(r.recovered, Some(planted));
                }
                assert_eq!(plain.total_gae, off.total_gae);
                assert_eq!(
                    plain.decomposition.targets_tried,
                    off.decomposition.targets_tried
                );
                assert_eq!(
                    plain.decomposition.cost.native,
                    off.decomposition.cost.native
                );
                assert_eq!(
                    plain.decomposition.setup.native,
                    off.decomposition.setup.native
                );
                assert_eq!(
                    plain.decomposition.setup.work_native,
                    off.decomposition.setup.work_native
                );
                assert!(!plain
                    .decomposition
                    .cost
                    .native
                    .contains_key("ksum_prefix_entries"));
                assert_eq!(
                    plain.decomposition.setup.group_ops, on.decomposition.setup.group_ops,
                    "k = {k}: prefix adds no group operation"
                );
                let ins = |r: &crate::cryptanalysis::ic_framework::RunReport| {
                    r.decomposition.setup.work_native["table_insert_attempts"]
                };
                let extra = on.decomposition.cost.native["ksum_prefix_entries"];
                assert!(extra > 0);
                assert!(ins(&on) >= ins(&plain) + extra, "k = {k}");
            }
        }
    }

    /// `stride-renew-joint` presents exactly the targets of `stride-renew`
    /// (same trials, relations, rank, answer and every relation-phase
    /// counter) and spends fewer counted additions plus doublings on the
    /// set-up's three `[a]G + [b]Q`, with three scalar multiplications
    /// recorded instead of six.
    #[test]
    fn stride_renew_joint_is_stride_renew_with_a_cheaper_setup() {
        for (k, size) in [(4u32, "12"), (5, "10")] {
            for seed in [11u64, 12, 13] {
                for prefix in ["", "1"] {
                    let (sep, planted) = ksum_run(k, size, Targets::StrideRenew, prefix, seed);
                    let (joint, _) = ksum_run(k, size, Targets::StrideRenewJoint, prefix, seed);
                    for r in [&sep, &joint] {
                        assert!(r.verified);
                        assert_eq!(r.recovered, Some(planted));
                    }
                    assert_eq!(
                        sep.decomposition.targets_tried,
                        joint.decomposition.targets_tried
                    );
                    assert_eq!(
                        sep.decomposition.relations_found,
                        joint.decomposition.relations_found
                    );
                    assert_eq!(
                        sep.decomposition.cost.native,
                        joint.decomposition.cost.native
                    );
                    assert_eq!(
                        sep.decomposition.cost.work_native,
                        joint.decomposition.cost.work_native
                    );
                    assert_eq!(sep.linear_algebra.rank, joint.linear_algebra.rank);
                    assert_eq!(
                        sep.decomposition.setup.group_ops,
                        joint.decomposition.setup.group_ops
                    );
                    assert_eq!(
                        sep.decomposition.setup.native,
                        joint.decomposition.setup.native
                    );
                    let (a, b) = (
                        sep.decomposition.cost.group_ops,
                        joint.decomposition.cost.group_ops,
                    );
                    assert_eq!(a.scalar_mults, 2 * b.scalar_mults, "k = {k} seed = {seed}");
                    assert!(b.scalar_mults >= 3, "k = {k} seed = {seed}");
                    assert!(b.gae() < a.gae(), "k = {k} seed = {seed}");
                    assert!(joint.total_gae < sep.total_gae);
                }
            }
        }
    }

    /// `ksum_run` with extra oracle parameters, on the prime roster curve
    /// (`binary = false`) or a binary Koblitz curve with a
    /// `binary-multiplier` base (`binary = true`).
    fn ksum_run_with(
        binary: bool,
        k: u32,
        size: &str,
        targets: Targets,
        extra: &[(&str, &str)],
        seed: u64,
    ) -> (crate::cryptanalysis::ic_framework::RunReport, u64) {
        let mut spec = PipelineSpec {
            factor_base: if binary {
                "binary-multiplier".into()
            } else {
                "prime-abscissa".into()
            },
            oracle: "ksum".into(),
            targets,
            max_trials: 50_000_000,
            seed,
            ..Default::default()
        };
        spec.factor_base_params.set("size", size);
        if binary {
            spec.factor_base_params.set("mult", "1");
        }
        spec.oracle_params.set("prune", "1");
        spec.oracle_params.set("split", "1");
        for (key, value) in extra {
            spec.oracle_params.set(key, *value);
        }
        let mut oracle = KSumOracle::new(k);
        if binary {
            let inst = crate::cryptanalysis::ic_boundary::koblitz_instance_best(19)
                .expect("roster Koblitz instance");
            let group = BinaryGroup(&inst.fast);
            let mut ops = GroupOps::default();
            let planted = (300_011 + 7919 * seed) % inst.r;
            let q = group.mul(&mut ops, inst.generator, planted);
            let ctx = InstanceCtx {
                group: &group,
                generator: inst.generator,
                target: q,
                r: inst.r,
                cofactor: inst.cofactor,
                group_order: inst.group_order,
                name: inst.name.clone(),
                field_degree: Some(inst.n),
            };
            let base = BinaryMultiplierBase { instance: &inst };
            let report = run_pipeline(
                &ctx,
                &spec,
                &base,
                &mut oracle,
                planted,
                &Calibration::default(),
                None,
            )
            .expect("the configuration should run");
            (report, planted)
        } else {
            let inst = roster_prime_instance(20).unwrap();
            let g = inst.generator_point();
            let mut ops = GroupOps::default();
            let planted = (300_011 + 7919 * seed) % inst.r;
            let q = CountedGroup::mul(&inst.curve, &mut ops, g, planted);
            let ctx = InstanceCtx {
                group: &inst.curve,
                generator: g,
                target: q,
                r: inst.r,
                cofactor: inst.cofactor,
                group_order: inst.group_order,
                name: inst.name.clone(),
                field_degree: None,
            };
            let base = PrimeAbscissaBase { instance: &inst };
            let report = run_pipeline(
                &ctx,
                &spec,
                &base,
                &mut oracle,
                planted,
                &Calibration::default(),
                None,
            )
            .expect("the configuration should run");
            (report, planted)
        }
    }

    /// `walk_sib=m` on `stride-renew` and `stride-renew-joint`: absent and
    /// `walk_sib=0` are the incumbent run for run; on, the targets,
    /// relations, rank, answer, scalar multiplications and oracle set-up
    /// are the incumbent's, and the relation phase's additions plus
    /// doublings are exactly the incumbent's minus one addition a stride
    /// step plus, counted, one addition a sibling pair (two for a pair
    /// formed in full), one a block centre, one a lifted abscissa hit and
    /// the `m` operations of the multiples each time the stride is drawn
    /// or renewed; one `sibling_second_points` a pair.  Prime and binary.
    #[test]
    fn walk_sib_on_stride_renew_keeps_the_targets_and_counts_the_pairs() {
        let cases: [(bool, u32, &str); 3] = [(false, 4, "12"), (false, 5, "10"), (true, 4, "7")];
        for (binary, k, size) in cases {
            for seed in [11u64, 12] {
                for targets in [Targets::StrideRenew, Targets::StrideRenewJoint] {
                    for prefix in ["0", "1"] {
                        let base = [("prefix", prefix)];
                        let (plain, planted) = ksum_run_with(binary, k, size, targets, &base, seed);
                        let (off, _) = ksum_run_with(
                            binary,
                            k,
                            size,
                            targets,
                            &[("prefix", prefix), ("walk_sib", "0")],
                            seed,
                        );
                        let label = format!(
                            "binary={binary} k={k} seed={seed} {targets:?} prefix={prefix}"
                        );
                        assert!(plain.verified, "{label}");
                        assert_eq!(plain.recovered, Some(planted), "{label}");
                        assert_eq!(plain.total_gae, off.total_gae, "{label}");
                        assert_eq!(
                            plain.decomposition.cost.native,
                            off.decomposition.cost.native
                        );
                        assert_eq!(
                            plain.decomposition.cost.work_native,
                            off.decomposition.cost.work_native
                        );
                        assert_eq!(
                            plain.decomposition.cost.group_ops.gae(),
                            off.decomposition.cost.group_ops.gae()
                        );
                        assert!(!plain
                            .decomposition
                            .cost
                            .native
                            .contains_key("walk_sibling_m"));
                        for m in [1u64, 3, 8] {
                            let ms = m.to_string();
                            let (on, _) = ksum_run_with(
                                binary,
                                k,
                                size,
                                targets,
                                &[("prefix", prefix), ("walk_sib", ms.as_str())],
                                seed,
                            );
                            let label = format!("{label} m={m}");
                            assert!(on.verified, "{label}");
                            assert_eq!(on.recovered, Some(planted), "{label}");
                            let (p, o) = (&plain.decomposition, &on.decomposition);
                            assert_eq!(p.targets_tried, o.targets_tried, "{label}");
                            assert_eq!(p.relations_found, o.relations_found, "{label}");
                            assert_eq!(
                                plain.linear_algebra.rank, on.linear_algebra.rank,
                                "{label}"
                            );
                            assert_eq!(p.setup.group_ops, o.setup.group_ops, "{label}");
                            assert_eq!(p.setup.native, o.setup.native, "{label}");
                            let (pn, on_) = (&p.cost.native, &o.cost.native);
                            for c in [
                                "stride_steps",
                                "stride_restarts",
                                "stride_renewals",
                                "direct_relations_skipped",
                            ] {
                                assert_eq!(pn.get(c), on_.get(c), "{label}: {c}");
                            }
                            let get = |name: &str| on_.get(name).copied().unwrap_or(0);
                            assert_eq!(get("walk_sibling_m"), m);
                            let (a, b) = (&p.cost.group_ops, &o.cost.group_ops);
                            assert_eq!(a.scalar_mults, b.scalar_mults, "{label}");
                            let model = (a.adds + a.doubles) - pn["stride_steps"]
                                + get("walk_sibling_pairs")
                                + 2 * get("walk_sibling_full_pairs")
                                + get("walk_sibling_centres")
                                + get("walk_sibling_lifts")
                                + get("walk_sibling_multiple_ops");
                            assert_eq!(b.adds + b.doubles, model, "{label}: count model");
                            // Once a stride that starts a block: the first,
                            // and every renewal but a last one the run ends on.
                            let mult = get("walk_sibling_multiple_ops");
                            assert_eq!(mult % m, 0, "{label}");
                            assert!(
                                mult / m >= pn["stride_renewals"]
                                    && mult / m <= pn["stride_renewals"] + 1,
                                "{label}: multiples once a stride"
                            );
                            assert_eq!(
                                o.cost.work_native.get("sibling_second_points"),
                                Some(&get("walk_sibling_pairs")),
                                "{label}"
                            );
                            assert!(get("walk_x_only_probes") >= get("walk_sibling_pairs"));
                            assert!(
                                on_["target_guard_probes"] < pn["target_guard_probes"],
                                "{label}"
                            );
                            if m >= 3 {
                                assert!(b.gae() < a.gae(), "{label}: cheaper at w = 0");
                            }
                        }
                    }
                }
            }
        }
    }
}

/// One probe per target into a coefficient-box table over the base's
/// `C` abscissae ([`WSumTable`], proposal P3): every `Σ e_c·P_c` with
/// `|e_c| ≤ coef`, so a relation has only `C` unknown columns.
pub struct WSumOracle<E> {
    table: Option<WSumTable<E>>,
    /// `free=1`: the build's key collisions are verified and handed to
    /// the relation loop as target-free rows, once, with the first trial.
    free: bool,
    free_pending: bool,
    free_checked: u64,
    free_emitted: u64,
}

impl<E> WSumOracle<E> {
    pub fn new() -> Self {
        Self {
            table: None,
            free: false,
            free_pending: false,
            free_checked: 0,
            free_emitted: 0,
        }
    }
}

impl<E> Default for WSumOracle<E> {
    fn default() -> Self {
        Self::new()
    }
}

impl<G: CountedGroup> DecompositionOracle<G> for WSumOracle<G::Elt> {
    fn name(&self) -> &str {
        "wsum"
    }

    fn summands(&self) -> u32 {
        // Distinct columns a relation touches: one per seed.
        self.table.as_ref().map_or(1, |t| t.c as u32)
    }

    fn describe(&self, _params: &Params) -> String {
        "a table of every Σ e_c·P_c over the base's abscissae with |e_c| ≤ coef, \
         one entry per negation orbit, probed once per target"
            .into()
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            ("coef", "coefficient bound B, 1 to 255 (C ≤ 8 seeds, ((2B+1)^C − 1)/2 ≤ 2^26)"),
            ("free", "1: verify the table's key collisions and use them as target-free relations (default 0)"),
        ]
    }

    fn prepare(
        &mut self,
        ctx: &InstanceCtx<G>,
        fb: &FactorBase<G::Elt>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<(), String> {
        let b = params.u64("coef").map_err(|e| format!("wsum: {e}"))?;
        self.free = params.flag("free");
        self.free_pending = self.free;
        let table = WSumTable::build(ctx.group, fb, b, self.free)?;
        // The table's construction (multiples included) is part of the
        // pipeline's cost.
        ops.merge(table.build_ops);
        self.table = Some(table);
        Ok(())
    }

    fn setup_work_native(&self) -> BTreeMap<String, u64> {
        table_counted(
            self.table
                .as_ref()
                .map(WSumTable::work_counters)
                .unwrap_or_default(),
        )
    }

    fn decompose(
        &mut self,
        ctx: &InstanceCtx<G>,
        fb: &FactorBase<G::Elt>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: G::Elt,
    ) -> Option<Vec<usize>> {
        let table = self.table.as_ref()?;
        table.probe(ctx.group, fb, ops, &mut counters.lookups, point)
    }

    #[allow(clippy::too_many_arguments)]
    fn decompose_relations(
        &mut self,
        ctx: &InstanceCtx<G>,
        fb: &FactorBase<G::Elt>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: G::Elt,
        _a: u64,
        _b: u64,
    ) -> Vec<Relation> {
        let mut out = Vec::new();
        if self.free_pending {
            self.free_pending = false;
            if let Some(table) = self.table.as_ref() {
                let (rows, checked) = table.free_rows(ctx.group, fb, ctx.r, ops);
                self.free_checked = checked;
                self.free_emitted = rows.len() as u64;
                out.extend(rows.into_iter().map(|columns| Relation::Row {
                    columns,
                    a: 0,
                    b: 0,
                }));
            }
        }
        if let Some(summands) = self.decompose(ctx, fb, ops, counters, point) {
            out.push(Relation::Summands(summands));
        }
        out
    }

    fn relation_counters(&self) -> BTreeMap<String, u64> {
        let mut m = BTreeMap::new();
        if self.free {
            m.insert("free_collisions_checked".to_string(), self.free_checked);
            m.insert("free_rows_emitted".to_string(), self.free_emitted);
        }
        m
    }
}

/// One probe per target into a random-jump walk table over the base's two
/// seeds ([`WalkTable`], proposal P2): `E_t = E_{t−1} + J_{h_t}` for
/// `T = round(x·√r)` steps, so a relation has only two unknown columns and
/// the table's own key collisions are target-free rows over them.
///
/// Parameters: `x` (table size in units of `√r`, in `(0, 4]`), `jumps`
/// (default 16, 2 to 64), `grow` (1: extend the walk, charged, until the
/// first verified free row, capped at `2·T` entries; default 0), `seed`
/// (default 0, mixed with the seeds' keys).  A base of one abscissa is
/// accepted with `g=1` (`F = 1`): jumps `[α_j]P1 + [γ_j]G`, a collision is
/// the one-column affine row `du·s1 = −dz`, and `grow` stops at rank 1.
/// With `tw=1` (needs `g=1`, `grow=2` and a one-seed base) the target is
/// inside the walk ([`TargetWalk`]): jumps `[α]P1 + [γ]G + [β]Q`, every
/// collision is the row `du·s1 + db·log Q = −dz`, the walk stops at the
/// first two independent rows, and they are handed to the loop with the
/// first trial (probes run only if the cap `3T` was reached below rank 2);
/// `cj=1` (needs `tw=1` or `tw=2`) builds the jumps by chained additions.
/// With `tw=2` (needs `g=1`, `grow=2` and a TWO-seed base) the target walk
/// carries both seeds: jumps `[α]P1 + [α']P2 + [γ]G + [β]Q`, every collision
/// is the row `du1·s1 + du2·s2 + db·log Q = −dz` (rows whose seed part is
/// zero modulo `r` are dropped), the walk stops at rank 3, cap `3T`.
/// `lazy=1` (needs `g=1`; for the walk table, `tw=1` and `tw=2`) skips the
/// per-collision recomputation: a row is kept on its exact key match.  The
/// pipeline's own `[d]G = Q` check still runs and is charged; a target walk
/// also runs that check once itself when its rows reach full rank, and on a
/// failure recomputes (charged) and drops the bad rows and keeps walking.
/// The verified free rows are
/// handed to the relation loop once, with the first trial, as
/// `Relation::Row { a: 0, b: 0 }`.  A probe hit `±E_t` is a
/// `Relation::Row` with the trial's own `(a, b)` and the columns
/// `(±u_t, ±v_t)`: the (large) coefficients are never expanded into
/// repeated summands, so [`DecompositionOracle::decompose`] has no
/// `Summands` form to return and answers `None`.
pub struct WWalkOracle<E> {
    table: Option<WalkTable<E>>,
    /// The `tw=1` walk (then `table` is `None`).
    tw_table: Option<TargetWalk<E>>,
    free_pending: bool,
    free_checked: u64,
    free_emitted: u64,
    probe_hits: u64,
    /// `lcheck=1` (with `tw=1|2`): both `[d]G = Q` checks read the target
    /// walk's stored `[2^i]G` ladder.
    lcheck: bool,
}

impl<E> WWalkOracle<E> {
    pub fn new() -> Self {
        Self {
            table: None,
            tw_table: None,
            free_pending: false,
            free_checked: 0,
            free_emitted: 0,
            probe_hits: 0,
            lcheck: false,
        }
    }

    /// The table of the last `prepare`, for reports and tests.
    pub fn table(&self) -> Option<&WalkTable<E>> {
        self.table.as_ref()
    }

    /// The `tw=1` walk of the last `prepare`, for reports and tests.
    pub fn target_walk(&self) -> Option<&TargetWalk<E>> {
        self.tw_table.as_ref()
    }

    /// With `lcheck=1`: the target walk's `[2^i]G` chain
    /// ([`TargetWalk::g_ladder`], already paid for in `prepare`), for the
    /// pipeline's recovery check
    /// ([`collect_and_solve_relations_touching_ladder`]); `None` otherwise.
    ///
    /// [`collect_and_solve_relations_touching_ladder`]: crate::cryptanalysis::ic_boundary::collect_and_solve_relations_touching_ladder
    pub fn recovery_ladder(&self) -> Option<Vec<E>>
    where
        E: Copy + PartialEq,
    {
        self.tw_table
            .as_ref()
            .filter(|_| self.lcheck)
            .map(TargetWalk::g_ladder)
    }
}

impl<E> Default for WWalkOracle<E> {
    fn default() -> Self {
        Self::new()
    }
}

impl<G: CountedGroup> DecompositionOracle<G> for WWalkOracle<G::Elt> {
    fn name(&self) -> &str {
        "wwalk"
    }

    fn summands(&self) -> u32 {
        // Distinct columns a relation touches: one per seed.
        2
    }

    fn describe(&self, _params: &Params) -> String {
        "a table of x·√r steps of a random-jump walk E_t = E_(t-1) + J_h over the base's two \
         abscissae, one entry per negation orbit, probed once per target; its key collisions \
         are target-free rows over the two seed columns"
            .into()
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            ("x", "table size in units of √r, T = round(x·√r), x in (0, 4] (required)"),
            ("jumps", "jump count, 2 to 64 (default 16); J_j = [α_j]P1 + [β_j]P2, α_j, β_j uniform in [1, round(1.2·√T)]"),
            ("grow", "1: after T entries keep extending the walk (charged) until the first verified free row, at most 2T entries; 2 (needs g=1): until two independent verified rows pin both seed logs, at most 3T (default 0)"),
            ("g", "1: every jump also carries [γ_j]G, γ_j uniform in [1, r), and entries track z mod r; a collision is the affine row du·s1 + dv·s2 = −dz (default 0)"),
            ("seed", "seed of the jump and step stream, mixed with the two seeds' keys (default 0)"),
            ("tw", "1 (needs g=1, grow=2 and a one-seed base): the target inside the walk, jumps [α]P1 + [γ]G + [β]Q, every collision a row du·s1 + db·log Q = −dz, stop at the first two independent rows, cap 3T; 2 (needs g=1, grow=2 and a two-seed base in distinct columns): jumps [α]P1 + [α']P2 + [γ]G + [β]Q, every collision a row du1·s1 + du2·s2 + db·log Q = −dz (rows with du1 = du2 = 0 mod r dropped), stop at rank 3, cap 3T (default 0)"),
            ("cj", "1 (needs tw=1 or tw=2): build the jumps by chained additions from two base combinations [γ]G + [β]Q (the seed parts from the doubled multiples) instead of independent scalar multiplications (default 0)"),
            ("lazy", "1 (needs g=1): skip the per-collision recomputation and keep each row on its exact key match (sign bit stored beside the entry); the walk, its stream and its collisions are identical, only verify_ops disappears.  The pipeline's [d]G = Q check still runs, charged.  With tw=1|2 the build also runs that check itself once when the rows reach full rank (charged as tw_lazy_check_*); on a failure it recomputes all collisions (charged), drops the rows that fail and resumes the walk.  With the walk table a wrong row is rejected by the pipeline's check (the run ends unverified; no in-run recovery) (default 0)"),
            ("lcheck", "1 (needs tw=1 or tw=2): the [d]G = Q checks (the build's lazy final check, charged as tw_lazy_check_*, and the pipeline's recovery check, charged to the verification phase's group ops, where the pipeline reads the oracle's recovery ladder) compute [d]G from the [2^i]G ladder (i < bits(r)) that the target walk's set-up already doubled and paid for, one addition per set bit of d (the first free) instead of a double-and-add; the ladder is retained at no group operation; walk, stream, collisions, rows and entries are unchanged, only the check counts move (default 0)"),
            ("sib", "1 to 16 (needs tw=1 or tw=2 and pool=M; default off): sibling points.  Every parent P draws its own random m-subset of a pool of M jump points (a product set J = A_i + K_j: a = 4 seed parts, or 8 from M = 256, and M/a chained parts K_j = K_(j-1) + K_(j-2), built as cj=1 chains them; set-up about a·popcount + M/a + M additions), and for each chosen J forms the two x-only children x(P ± J) from ONE inversion 1/(x_J − x_P); all 2m children are keyed (negation folded) with coefficient vectors c_P ± c_J and a key collision among any stored points is a row as in the target walk (lazy applies); the walk continues from P + J_h with h the first of the subset; the two known-copy minus children are not formed; stored points are capped at 3T.  Table size T is planned from `jumps` (and `x`) exactly as a non-sib tw walk — not hard-coded to 16 — so `jumps=` amortises the walk table while `pool` keeps the sibling alphabet.  Charging: the m pairs of one parent share ONE Montgomery-batched inversion of the denominators (walk identity unchanged; was one inv per pair) plus the same λ/sqr field work; each pair is charged as ONE group addition plus one unit of the native counter sibling_second_points (sqr + 2 add, the difference), so its bitop/v1 price equals its field work, and the band prices the second point at w; the continuing child's y (mul + 2 add) is the counter sibling_lift_products, once a parent; a pair whose minus child is skipped is the addition alone (one mul and two adds above what it performs); field_ops are counted as performed, never through the addition; a collision's x-only point gets its sign resolved at that time (one more addition, charged)"),
            ("pool", "sib to 512 (needs sib): the sibling jump alphabet size M; table planning still uses `jumps` (default off)"),
            ("aut", "3 (needs tw=1 or tw=2; j = 0 prime curves over p ≡ 1 mod 3 with 3 | r − 1): orbit-canonical keys under the order-3 automorphism ζ₃(x, y) = (ωx, y) = [κ](x, y) and negation (A = 6): each stored or probed point is keyed by min(x, ωx, ω²x), two field multiplications, listed as the unpriced counter aut_canonicalisations_uncharged exactly as rho.cubic lists its canonicalisations_uncharged (the §5a band charges it at w; bitop/v1 prices it as 2 field multiplications and 2 word compares); the rotation is stored with the entry, and a collision at rotation difference d is the row of E_t = ±[κ^d]E_s (the kept coefficients scaled by κ^d mod r), with lazy, cv=0, sib and the verified recomputation unchanged; the [κ]G = ζ₃(G) check is charged to the set-up (default off)"),
            ("cv", "0 (needs tw=1 or tw=2; not with lazy=1): do not recompute the two entries of a key collision; the key is the exact abscissa, the key's sign bit stored in bit 127 of the entry's u word gives E_t = ±E_s, and the final [d]G = Q check (charged) fails the solve on a wrong row, with no in-run recovery (default 1)"),
        ]
    }

    fn prepare(
        &mut self,
        ctx: &InstanceCtx<G>,
        fb: &FactorBase<G::Elt>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<(), String> {
        let x: f64 = params
            .get("x")
            .ok_or_else(|| "wwalk: missing parameter `x`".to_string())?
            .parse()
            .map_err(|_| format!("wwalk: parameter `x` is not a number: `{}`", params.0["x"]))?;
        let jumps = params
            .u64_or("jumps", 16)
            .map_err(|e| format!("wwalk: {e}"))?;
        let jumps = usize::try_from(jumps).map_err(|_| "wwalk: jumps too large".to_string())?;
        let seed = params
            .u64_or("seed", 0)
            .map_err(|e| format!("wwalk: {e}"))?;
        let grow = match params.get("grow") {
            None => 0u8,
            Some("true" | "yes") => 1,
            Some(v) => v
                .parse::<u8>()
                .ok()
                .filter(|g| *g <= 2)
                .ok_or_else(|| format!("wwalk: grow is 0, 1 or 2, not `{v}`"))?,
        };
        let opts = WalkOpts {
            g_jumps: params.flag("g"),
            grow,
        };
        let tw = match params.get("tw") {
            None | Some("0" | "false" | "no") => 0usize,
            Some("1" | "true" | "yes") => 1,
            Some("2") => 2,
            Some(v) => return Err(format!("wwalk: tw is 0, 1 or 2, not `{v}`")),
        };
        let (cj, lazy) = (params.flag("cj"), params.flag("lazy"));
        if cj && tw == 0 {
            return Err("wwalk: cj=1 needs tw=1 or tw=2".into());
        }
        let lcheck = params.flag("lcheck");
        if lcheck && tw == 0 {
            return Err("wwalk: lcheck=1 needs tw=1 or tw=2".into());
        }
        self.lcheck = lcheck;
        if lazy && !opts.g_jumps {
            return Err("wwalk: lazy=1 needs g=1".into());
        }
        let cv = wwalk_cv(params)?;
        if !cv && tw == 0 {
            return Err("wwalk: cv=0 needs tw=1 or tw=2".into());
        }
        if !cv && lazy {
            return Err("wwalk: cv=0 and lazy=1 are alternatives; choose one".into());
        }
        let sib = match (params.get("sib"), params.get("pool")) {
            (None, None) => None,
            (Some(_), None) => return Err("wwalk: sib=m needs pool=M".into()),
            (None, Some(_)) => return Err("wwalk: pool=M needs sib=m".into()),
            (Some(_), Some(_)) => {
                if tw == 0 {
                    return Err("wwalk: sib needs tw=1 or tw=2".into());
                }
                let m = params.u64_or("sib", 0).map_err(|e| format!("wwalk: {e}"))?;
                let pool = params
                    .u64_or("pool", 0)
                    .map_err(|e| format!("wwalk: {e}"))?;
                Some((
                    usize::try_from(m).map_err(|_| "wwalk: sib too large".to_string())?,
                    usize::try_from(pool).map_err(|_| "wwalk: pool too large".to_string())?,
                ))
            }
        };
        let aut = match params.get("aut") {
            None | Some("0" | "1" | "off" | "no" | "false") => false,
            Some("3") => true,
            Some(v) => return Err(format!("wwalk: aut is 3 (or off), not `{v}`")),
        };
        if aut && tw == 0 {
            return Err("wwalk: aut=3 needs tw=1 or tw=2".into());
        }
        if tw > 0 {
            if !opts.g_jumps || grow != 2 {
                return Err(format!("wwalk: tw={tw} needs g=1 and grow=2"));
            }
            if aut && sib.is_some() && !cv {
                return Err("wwalk: sib with cv=0 is not supported".into());
            }
            let walk = if aut {
                TargetWalk::build_lcheck(
                    ctx.group,
                    ctx.generator,
                    ctx.target,
                    fb,
                    ctx.r,
                    ctx.cofactor,
                    x,
                    jumps,
                    cj,
                    seed,
                    lazy,
                    tw,
                    cv,
                    sib,
                    true,
                    lcheck,
                )?
            } else if sib.is_some() {
                if !cv {
                    return Err("wwalk: sib with cv=0 is not supported".into());
                }
                // `build_ext_sib` (chained jumps) with `lcheck`.
                TargetWalk::build_lcheck(
                    ctx.group,
                    ctx.generator,
                    ctx.target,
                    fb,
                    ctx.r,
                    ctx.cofactor,
                    x,
                    jumps,
                    true,
                    seed,
                    lazy,
                    tw,
                    cv,
                    sib,
                    false,
                    lcheck,
                )?
            } else {
                // `build_ext_cv` with `lcheck`.
                TargetWalk::build_lcheck(
                    ctx.group,
                    ctx.generator,
                    ctx.target,
                    fb,
                    ctx.r,
                    ctx.cofactor,
                    x,
                    jumps,
                    cj,
                    seed,
                    lazy,
                    tw,
                    cv,
                    None,
                    false,
                    lcheck,
                )?
            };
            self.free_pending = true;
            self.free_checked = walk.collisions.len() as u64;
            self.free_emitted = walk.rows.len() as u64;
            self.probe_hits = 0;
            ops.merge(walk.build_ops);
            self.table = None;
            self.tw_table = Some(walk);
            return Ok(());
        }
        self.tw_table = None;
        let table = WalkTable::build_lazy(
            ctx.group,
            Some(ctx.generator),
            fb,
            ctx.r,
            x,
            jumps,
            opts,
            seed,
            lazy,
        )?;
        self.free_pending = true;
        self.free_checked = table.collisions.len() as u64;
        self.free_emitted = table.rows.len() as u64;
        self.probe_hits = 0;
        // The walk, the jump set-up and the row verification are part of
        // the pipeline's cost.
        ops.merge(table.build_ops);
        self.table = Some(table);
        Ok(())
    }

    fn setup_work_native(&self) -> BTreeMap<String, u64> {
        if let Some(walk) = &self.tw_table {
            return table_counted(walk.work_counters());
        }
        table_counted(
            self.table
                .as_ref()
                .map(WalkTable::work_counters)
                .unwrap_or_default(),
        )
    }

    fn decompose(
        &mut self,
        _ctx: &InstanceCtx<G>,
        _fb: &FactorBase<G::Elt>,
        _ops: &mut GroupOps,
        _counters: &mut OracleCounters,
        _point: G::Elt,
    ) -> Option<Vec<usize>> {
        None
    }

    #[allow(clippy::too_many_arguments)]
    fn decompose_relations(
        &mut self,
        ctx: &InstanceCtx<G>,
        fb: &FactorBase<G::Elt>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: G::Elt,
        a: u64,
        b: u64,
    ) -> Vec<Relation> {
        let mut out = Vec::new();
        if let Some(walk) = self.tw_table.as_ref() {
            if self.free_pending {
                self.free_pending = false;
                out.extend(walk.rows.iter().map(|row| Relation::Row {
                    columns: row.columns.clone(),
                    a: row.a,
                    b: row.b,
                }));
            }
            // Full rank (two independent rows with one seed, three with
            // two) pins log Q: no probe is needed.
            if walk.rank < walk.need() {
                if let Some((sign, u, z, be)) =
                    walk.probe(ctx.group, ops, &mut counters.lookups, point)
                {
                    self.probe_hits += 1;
                    let row = walk.hit_row(fb, ctx.r, a, b, sign, u, z, be);
                    out.push(Relation::Row {
                        columns: row.columns,
                        a: row.a,
                        b: row.b,
                    });
                }
            }
            return out;
        }
        let Some(table) = self.table.as_ref() else {
            return out;
        };
        if self.free_pending {
            self.free_pending = false;
            // `Σ coef·x = h·(a + b·d)` with `b = 0`: a collision's affine
            // row `du·s1 + dv·s2 = −dz` carries `a = −dz` (zero without
            // `g=1`).
            out.extend(
                table
                    .rows
                    .iter()
                    .zip(&table.row_consts)
                    .map(|(columns, &konst)| Relation::Row {
                        columns: columns.clone(),
                        a: konst,
                        b: 0,
                    }),
            );
        }
        if let Some((sign, u, v, z)) = table.probe_z(ctx.group, ops, &mut counters.lookups, point) {
            let columns = table.hit_columns(fb, ctx.r, sign, u, v);
            self.probe_hits += 1;
            let a = WalkTable::<G::Elt>::hit_const(ctx.r, a, sign, z);
            out.push(Relation::Row { columns, a, b });
        }
        out
    }

    fn relation_counters(&self) -> BTreeMap<String, u64> {
        let mut m = BTreeMap::new();
        m.insert("free_collisions_checked".to_string(), self.free_checked);
        m.insert("free_rows_emitted".to_string(), self.free_emitted);
        m.insert("probe_hits".to_string(), self.probe_hits);
        if let Some(walk) = &self.tw_table {
            m.extend(walk.breakdown_counters());
        }
        if let Some(table) = &self.table {
            if table.lazy {
                m.insert("wwalk_lazy".to_string(), 1);
                m.insert(
                    "wwalk_lazy_certified_rows".to_string(),
                    table.lazy_certified,
                );
            }
        }
        m
    }

    fn recovery_ladder(&self) -> Option<Vec<G::Elt>> {
        WWalkOracle::recovery_ladder(self)
    }
}

/// `wwalk`'s `cv` parameter: absent or `1` recomputes every key collision
/// (the committed walk), `0` does not.
pub fn wwalk_cv(params: &Params) -> Result<bool, String> {
    match params.get("cv") {
        None | Some("1") => Ok(true),
        Some("0") => Ok(false),
        Some(v) => Err(format!("wwalk: cv is 0 or 1, not `{v}`")),
    }
}

/// The two-summand prime MITM search with the same probe and table keys as
/// `mitm`, but a batched-inversion, x-only table construction.  The
/// `blocked` form (`mitm-prime-blocked`) builds the same table in
/// cache-sized pieces ([`PairTable::build_negation_folded_prime_blocked`]).
pub struct PrimeBatchMitmOracle {
    blocked: bool,
    lines: bool,
    table: Option<PairTable>,
}

impl PrimeBatchMitmOracle {
    pub fn new() -> Self {
        Self {
            blocked: false,
            lines: false,
            table: None,
        }
    }

    pub fn blocked() -> Self {
        Self {
            blocked: true,
            lines: false,
            table: None,
        }
    }

    fn name_str(&self) -> &'static str {
        if self.blocked {
            "mitm-prime-blocked"
        } else {
            "mitm-prime-batch"
        }
    }
}

impl Default for PrimeBatchMitmOracle {
    fn default() -> Self {
        Self::new()
    }
}

impl DecompositionOracle<PrimeCurve> for PrimeBatchMitmOracle {
    fn name(&self) -> &str {
        self.name_str()
    }

    fn summands(&self) -> u32 {
        2
    }

    fn describe(&self, _params: &Params) -> String {
        if self.blocked {
            "negation-folded pair table built with batched prime-field inversions, \
             inserted in cache-sized pieces; identical MITM probe"
                .into()
        } else {
            "negation-folded pair table built with batched prime-field inversions; identical MITM probe"
                .into()
        }
    }

    fn parameters(&self) -> &[(&str, &str)] {
        if self.blocked {
            &[
                ("m", "must be 2"),
                (
                    "filter",
                    "0 (default) or 1: a membership filter of about a byte per entry in front of \
                     the packed table, so a missing key costs one bit read (packed layout only)",
                ),
            ]
        } else {
            &[
                ("m", "must be 2"),
                (
                    "layout",
                    "map (default) or lines (cache-line pair index and relation guard)",
                ),
            ]
        }
    }

    fn prepare(
        &mut self,
        ctx: &InstanceCtx<PrimeCurve>,
        fb: &FactorBase<PrimePoint>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<(), String> {
        let allowed = |key: &String| {
            key == "m" || (self.blocked && key == "filter") || (!self.blocked && key == "layout")
        };
        if params.u64_or("m", 2)? != 2 || !params.0.keys().all(allowed) {
            return Err(if self.blocked {
                format!("{} accepts only m=2 and filter=0|1", self.name_str())
            } else {
                format!("{} accepts only m=2", self.name_str())
            });
        }
        let filtered = match params.u64_or("filter", 0)? {
            0 => false,
            1 => true,
            other => {
                return Err(format!(
                    "{}: filter must be 0 or 1, not {other}",
                    self.name_str()
                ))
            }
        };
        self.lines = match params.get("layout") {
            None | Some("map") => false,
            Some("lines") if !self.blocked => true,
            Some("lines") => return Err("mitm-prime-blocked does not accept layout=lines".into()),
            Some(other) => return Err(format!("unknown layout `{other}`; use map or lines")),
        };
        let table = if self.blocked {
            PairTable::build_negation_folded_prime_blocked_with(ctx.group, fb, filtered)?
        } else if self.lines {
            PairTable::build_negation_folded_prime_batch_lines(ctx.group, fb)?
        } else {
            PairTable::build_negation_folded_prime_batch(ctx.group, fb)?
        };
        ops.merge(table.build_ops);
        self.table = Some(table);
        Ok(())
    }

    fn setup_work_native(&self) -> BTreeMap<String, u64> {
        table_counted(
            self.table
                .as_ref()
                .map(PairTable::work_counters)
                .unwrap_or_default(),
        )
    }

    fn decompose(
        &mut self,
        ctx: &InstanceCtx<PrimeCurve>,
        fb: &FactorBase<PrimePoint>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: PrimePoint,
    ) -> Option<Vec<usize>> {
        decompose_mitm(ctx.group, fb, self.table.as_ref()?, 2, ops, counters, point)
    }

    fn touch(&self, ctx: &InstanceCtx<PrimeCurve>, point: &PrimePoint) {
        if let Some(table) = &self.table {
            table.prefetch(ctx.group, point);
        }
    }

    fn line_guard(&self) -> bool {
        self.lines
    }
}

/// **Single-large-prime residual sweep** (lead `ICP-residual-partial-relations`).
///
/// For a target `R = [a]G + [b]Q` it forms every residual `Z_i = R − P_i`
/// over the base's `2|F_x|` signed points, one group addition each (charged
/// exactly as `subtract` charges its candidates), and stores `Z_i` under its
/// abscissa together with `(a, b, i)`.  Two stored residuals with equal
/// abscissa are equal up to sign, `R − P_i = t (R' − P_i')`, which is the
/// base-only relation
///
/// ```text
///   (a − t a') + (b − t b') d = log P_i − t log P_i' .
/// ```
///
/// No pair table is built and no residual is required to land in the base:
/// the unknown point `Z` is the "large prime" and a collision is its
/// pairing.  A residual that is the identity is `R = P_i`, a one-column row.
///
/// What it costs is the point of the lead: the number of stored residuals
/// needed for `|F_x|` collisions is about `sqrt(2 r |F_x|)`, so the relation
/// phase is a birthday search whose price falls as the base shrinks, and
/// the table it needs grows with the same square root (reported as
/// `residuals_stored`).  It is a different search from the pair table's,
/// not a faster one.
pub struct ResidualSweepOracle {
    /// Residuals kept at most; later ones are still looked up.
    cap: usize,
    /// Identify `Z` with `−Z` (the signed-class fold).  Off: only equal points collide.
    fold: bool,
    /// Distinguished-point filter: only residuals whose hashed abscissa has this
    /// many trailing zero bits are stored or probed.
    dp_bits: u32,
    /// Also probe the negation-folded pair table once a target (hybrid).
    pairs: bool,
    table: Option<PairTable>,
    negs: Vec<PrimePoint>,
    /// key -> (a, b, index, y bit)
    store: HashMap<u64, (u64, u64, u32, bool)>,
    stored: u64,
    sweeps: u64,
    collisions: u64,
    identity_hits: u64,
    cap_misses: u64,
    dp_skipped: u64,
    pair_hits: u64,
}

fn sweep_mix(x: u64) -> u64 {
    let mut z = x.wrapping_add(0x9E37_79B9_7F4A_7C15);
    z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
    z ^ (z >> 31)
}

impl ResidualSweepOracle {
    pub fn new() -> Self {
        Self {
            cap: 1 << 24,
            fold: true,
            dp_bits: 0,
            pairs: false,
            table: None,
            negs: Vec::new(),
            store: HashMap::new(),
            stored: 0,
            sweeps: 0,
            collisions: 0,
            identity_hits: 0,
            cap_misses: 0,
            dp_skipped: 0,
            pair_hits: 0,
        }
    }
}

impl Default for ResidualSweepOracle {
    fn default() -> Self {
        Self::new()
    }
}

impl DecompositionOracle<PrimeCurve> for ResidualSweepOracle {
    fn name(&self) -> &str {
        "residual-sweep"
    }

    fn summands(&self) -> u32 {
        2
    }

    fn describe(&self, _params: &Params) -> String {
        "every residual R − P_i of a target stored by abscissa; a collision of two residuals is a \
         base-only relation (single large prime, no pair table unless pairs=1)"
            .into()
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            ("m", "must be 2"),
            ("cap", "most residuals kept (default 16777216)"),
            ("fold", "1 (default): Z and −Z collide; 0: only equal points collide"),
            (
                "dp",
                "k (default 0): store and probe only residuals whose hashed abscissa has k trailing zero bits",
            ),
            (
                "pairs",
                "1: also probe the negation-folded pair table once a target (hybrid); default 0",
            ),
        ]
    }

    fn prepare(
        &mut self,
        ctx: &InstanceCtx<PrimeCurve>,
        fb: &FactorBase<PrimePoint>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<(), String> {
        const KEYS: [&str; 5] = ["m", "cap", "fold", "dp", "pairs"];
        if params.u64_or("m", 2)? != 2 || params.0.keys().any(|key| !KEYS.contains(&key.as_str())) {
            return Err("residual-sweep accepts only m=2, cap, fold, dp and pairs".into());
        }
        self.cap = params.u64_or("cap", 1 << 24)? as usize;
        self.fold = params.u64_or("fold", 1)? != 0;
        self.dp_bits = params.u64_or("dp", 0)? as u32;
        if self.dp_bits > 40 {
            return Err("residual-sweep dp must be at most 40".into());
        }
        self.pairs = params.u64_or("pairs", 0)? != 0;
        self.negs = fb.points.iter().map(|p| ctx.group.neg(*p)).collect();
        self.store.clear();
        self.table = None;
        if self.pairs {
            let table = PairTable::build_negation_folded_prime_batch(ctx.group, fb)?;
            ops.merge(table.build_ops);
            self.table = Some(table);
        }
        Ok(())
    }

    fn setup_work_native(&self) -> BTreeMap<String, u64> {
        table_counted(
            self.table
                .as_ref()
                .map(PairTable::work_counters)
                .unwrap_or_default(),
        )
    }

    fn decompose(
        &mut self,
        _ctx: &InstanceCtx<PrimeCurve>,
        _fb: &FactorBase<PrimePoint>,
        _ops: &mut GroupOps,
        _counters: &mut OracleCounters,
        _point: PrimePoint,
    ) -> Option<Vec<usize>> {
        None
    }

    fn decompose_relations(
        &mut self,
        ctx: &InstanceCtx<PrimeCurve>,
        fb: &FactorBase<PrimePoint>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: PrimePoint,
        a: u64,
        b: u64,
    ) -> Vec<Relation> {
        let r = ctx.r;
        let g = ctx.group;
        let mut out = Vec::new();
        self.sweeps += 1;
        if let Some(table) = self.table.as_ref() {
            if let Some(summands) = decompose_mitm(g, fb, table, 2, ops, counters, point) {
                self.pair_hits += 1;
                out.push(Relation::Summands(summands));
            }
        }
        let dp_mask = (1u64 << self.dp_bits) - 1;
        for (i, neg) in self.negs.iter().enumerate() {
            let z = g.add(ops, point, *neg);
            if g.is_identity(&z) {
                self.identity_hits += 1;
                out.push(Relation::Row {
                    columns: vec![(fb.col_of[i], fb.coef_of[i] % r)],
                    a,
                    b,
                });
                continue;
            }
            if self.dp_bits > 0 && sweep_mix(z.x) & dp_mask != 0 {
                self.dp_skipped += 1;
                continue;
            }
            counters.lookups += 1;
            let ybit = z.y > g.neg(z).y;
            let key = if self.fold {
                z.x
            } else {
                (z.x << 1) | u64::from(ybit)
            };
            match self.store.get(&key) {
                Some(&(a2, b2, i2, ybit2)) => {
                    let i2 = i2 as usize;
                    let t_plus = !self.fold || ybit == ybit2;
                    self.collisions += 1;
                    let (ra, rb, second) = if t_plus {
                        (
                            (a + r - a2) % r,
                            (b + r - b2) % r,
                            (r - fb.coef_of[i2] % r) % r,
                        )
                    } else {
                        ((a + a2) % r, (b + b2) % r, fb.coef_of[i2] % r)
                    };
                    out.push(Relation::Row {
                        columns: vec![(fb.col_of[i], fb.coef_of[i] % r), (fb.col_of[i2], second)],
                        a: ra,
                        b: rb,
                    });
                }
                None => {
                    if self.store.len() < self.cap {
                        self.store.insert(key, (a, b, i as u32, ybit));
                        self.stored += 1;
                    } else {
                        self.cap_misses += 1;
                    }
                }
            }
        }
        out
    }

    fn relation_counters(&self) -> BTreeMap<String, u64> {
        BTreeMap::from([
            ("residuals_stored".to_string(), self.stored),
            ("sweeps".to_string(), self.sweeps),
            ("collisions".to_string(), self.collisions),
            ("identity_hits".to_string(), self.identity_hits),
            ("cap_misses".to_string(), self.cap_misses),
            ("dp_skipped".to_string(), self.dp_skipped),
            ("pair_hits".to_string(), self.pair_hits),
        ])
    }
}

/// One abscissa of the base as the root-finding sweep sees it: both
/// coordinates of its positive representative in Montgomery form, and the
/// indices of `P` and `−P` in the run's base.
#[derive(Clone, Copy, Debug)]
pub(crate) struct SweepRep {
    pub(crate) x: u64,
    pub(crate) y: u64,
    pub(crate) plus: usize,
    pub(crate) minus: usize,
}

/// Direct-subtraction root finding on a prime curve: the decomposition
/// oracle of `prime_fast::collect_relations`
/// (`RESEARCH_SEMAEV_ROOTFIND_VS_GROEBNER.md` §2), inside `ic.pipeline`.
///
/// The Semaev `S₃` root in the third variable is literally `x(R ∓ F_i)`,
/// so a two-summand sweep over the base needs no summation polynomial,
/// no Gröbner basis and no square root: the `x_R − x_i` of every
/// abscissa are inverted together by Montgomery's trick (one field
/// inversion a target), `λ` for `R − F_i` and `R + F_i` share that
/// inverse, and each resulting point is looked up in the base (`m = 2`)
/// or probed against the negation-folded pair table (`m = 3`).
///
/// It is the `subtract` oracle's search — the same `2·|F_x|` candidate
/// points a target, found in the same order — on `prime_fast`'s
/// arithmetic.  It is charged exactly as `subtract` is: one group addition
/// per candidate point, so the two arms read the same `S` and differ in
/// the constant the unit does not see (one batched inversion against
/// `2·|F_x|`), which the record keeps as `inversions` (counted, priced
/// only where the curve has a pinned ratio) and as wall time.  Every hit
/// is re-added in the group on the ledger before it is returned.
pub struct RootfindSubtractOracle<'i> {
    m: u32,
    instance: &'i PrimeInstance,
    field: Option<Fp64>,
    reps: Vec<SweepRep>,
    table: Option<PairTable>,
    diffs: Vec<u64>,
    degenerate: Vec<bool>,
    scratch: Vec<u64>,
    /// Hits whose summands did not re-add to the target in the group.
    /// Must stay zero.
    pub mismatches: u64,
    /// `bitop/v1`-only work of the sweep (`relation_work_native`): the
    /// batched inversion's `3k` products and the two conversions into
    /// Montgomery form a target, and the `k` differences `x_R − x_i`.
    /// The candidate points' own products are inside the group addition
    /// each is charged as.
    sweep_field_muls: u64,
    sweep_field_adds: u64,
    /// `m = 3` with the pair table built elsewhere (`rootfind-subtract-gpu`,
    /// `probe_build=pairs`): `prepare` builds no table, and the builder
    /// charges the build and supplies its work counters here.
    defer_table: bool,
    deferred_table_work: BTreeMap<String, u64>,
    /// `sweep=1/N`: the abscissae a trial examines, `ceil(k/N)` of the `k`
    /// (`0` = all, the default).  Window `t` starts at `t · window mod k`, so
    /// successive trials rotate through the base and every abscissa is swept
    /// equally often.
    window: usize,
    /// Trials examined so far in this run (the rotation's position).
    trial: u64,
}

impl<'i> RootfindSubtractOracle<'i> {
    pub fn new(m: u32, instance: &'i PrimeInstance) -> Self {
        Self {
            m,
            instance,
            field: None,
            reps: Vec::new(),
            table: None,
            diffs: Vec::new(),
            degenerate: Vec::new(),
            scratch: Vec::new(),
            mismatches: 0,
            sweep_field_muls: 0,
            sweep_field_adds: 0,
            defer_table: false,
            deferred_table_work: BTreeMap::new(),
            window: 0,
            trial: 0,
        }
    }

    /// Build no pair table in `prepare` (`m = 3`); the caller builds it,
    /// charges it, and passes its [`PairTable::work_counters`] to
    /// [`Self::set_deferred_table_work`].
    pub(crate) fn defer_pair_table(&mut self) {
        self.defer_table = true;
    }

    pub(crate) fn set_deferred_table_work(&mut self, work: BTreeMap<String, u64>) {
        self.deferred_table_work = work;
    }
}

impl DecompositionOracle<PrimeCurve> for RootfindSubtractOracle<'_> {
    fn name(&self) -> &str {
        "rootfind-subtract"
    }

    fn summands(&self) -> u32 {
        self.m
    }

    fn describe(&self, _params: &Params) -> String {
        match self.m {
            2 => "every x(R ∓ F_i) from one Montgomery batched inversion, each looked up in the \
                  base (prime_fast's direct-subtraction root finding)"
                .into(),
            _ => "every R ∓ F_i from one Montgomery batched inversion, each probed against the \
                  negation-folded pair table (prime_fast's direct-subtraction root finding)"
                .into(),
        }
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            (
                "m",
                "summands, 2 or 3; 3 builds the negation-folded pair table",
            ),
            (
                "sweep",
                "1 (default: every abscissa until the first hit) or 1/N: each trial examines a \
                 rotating window of ceil(k/N) of the k abscissae, then the next target is taken",
            ),
        ]
    }

    fn prepare(
        &mut self,
        ctx: &InstanceCtx<PrimeCurve>,
        fb: &FactorBase<PrimePoint>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<(), String> {
        if !(2..=3).contains(&self.m) {
            return Err(format!(
                "rootfind-subtract takes m = 2 or 3, got {}",
                self.m
            ));
        }
        for key in params.0.keys() {
            if key != "m" && key != "sweep" {
                return Err(format!(
                    "rootfind-subtract reads only `m` and `sweep`; `{key}` would change the method's \
                     identity without changing the search"
                ));
            }
        }
        // `sweep=1/N` (or `1`): the fraction of the base's abscissae a trial
        // examines before the next target is taken.
        let sweep_den: usize = match params.0.get("sweep").map(|s| s.as_str()) {
            None | Some("1") => 1,
            Some(s) => s
                .strip_prefix("1/")
                .and_then(|d| d.parse::<usize>().ok())
                .filter(|&d| d >= 1)
                .ok_or_else(|| format!("rootfind-subtract: sweep must be 1 or 1/N, got `{s}`"))?,
        };
        let p = self.instance.curve.p;
        if p != ctx.group.p {
            return Err("rootfind-subtract was built for another curve".into());
        }
        if p < 5 || p & 1 == 0 || p >= (1u64 << PRIME_FAST_MAX_BITS) {
            return Err(format!(
                "rootfind-subtract needs an odd prime 3 < p < 2^{PRIME_FAST_MAX_BITS}"
            ));
        }
        let f = Fp64::new(p);
        let mut reps = Vec::with_capacity(fb.abscissa_list.len());
        for x in &fb.abscissa_list {
            let idx = fb
                .x_index
                .get(x)
                .ok_or("every listed abscissa is indexed")?;
            let plus = *idx.first().ok_or("an abscissa with no point")?;
            let minus = idx.get(1).copied().unwrap_or(plus);
            let pt = fb.points[plus];
            if pt.infinity || pt.x != *x {
                return Err("the base's abscissa index does not match its points".into());
            }
            reps.push(SweepRep {
                x: f.to_mont(pt.x),
                y: f.to_mont(pt.y),
                plus,
                minus,
            });
        }
        self.diffs = vec![0; reps.len()];
        self.degenerate = vec![false; reps.len()];
        self.window = if sweep_den <= 1 {
            0
        } else {
            reps.len().div_ceil(sweep_den)
        };
        self.trial = 0;
        self.reps = reps;
        self.field = Some(f);
        if self.m == 3 && !self.defer_table {
            // Same batched builder as `rootfind-floor:m=3` (PLAN lever 5):
            // keep decompose parity (same keys/witnesses) while cutting
            // prepare wall at large |Fₓ|.
            let table = PairTable::build_negation_folded_prime_batch(ctx.group, fb)?;
            ops.merge(table.build_ops);
            self.table = Some(table);
        }
        Ok(())
    }

    fn setup_work_native(&self) -> BTreeMap<String, u64> {
        let mut out = self
            .table
            .as_ref()
            .map(PairTable::work_counters)
            .unwrap_or_else(|| self.deferred_table_work.clone());
        // The sweep's `x_index` read per abscissa, and its two
        // conversions into Montgomery form.
        let k = self.reps.len() as u64;
        if k > 0 {
            crate::cryptanalysis::ic_boundary::bump_counter(&mut out, "lookups", k);
            out.insert("montgomery_conversions".to_string(), 2 * k);
        }
        table_counted(out)
    }

    fn relation_work_native(&self) -> BTreeMap<String, u64> {
        let mut out = BTreeMap::new();
        if self.sweep_field_muls > 0 {
            out.insert("sweep_field_muls".to_string(), self.sweep_field_muls);
        }
        if self.sweep_field_adds > 0 {
            out.insert("sweep_field_adds".to_string(), self.sweep_field_adds);
        }
        out
    }

    fn decompose(
        &mut self,
        ctx: &InstanceCtx<PrimeCurve>,
        fb: &FactorBase<PrimePoint>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: PrimePoint,
    ) -> Option<Vec<usize>> {
        let f = self.field?;
        if point.infinity {
            return None;
        }
        let g = ctx.group;
        let xr = f.to_mont(point.x);
        let yr = f.to_mont(point.y);
        ops.field_ops.muls += 2;
        // One inversion for the whole sweep: `(x_R − x_i)⁻¹` for every
        // abscissa.  An abscissa equal to `x_R` means `R = ±F_i`; that
        // row is taken on the ledger below, exactly as `subtract` takes
        // it, so the two oracles examine the same candidates in the same
        // order whatever the target.
        // The abscissae this trial examines: all `k` in base order, or (with
        // `sweep=1/N`) the next window of `n = ceil(k/N)` of them, rotating.
        let k = self.reps.len();
        let (n, offset) = if self.window == 0 || self.window >= k {
            (k, 0)
        } else {
            let o = ((self.trial % k as u64) * self.window as u64 % k as u64) as usize;
            self.trial += 1;
            (self.window, o)
        };
        let at = |j: usize| if offset == 0 { j } else { (offset + j) % k };
        for j in 0..n {
            let d = f.sub(xr, self.reps[at(j)].x);
            self.degenerate[j] = d == 0;
            self.diffs[j] = if d == 0 { f.one } else { d };
        }
        f.batch_inv(&mut self.diffs[..n], &mut self.scratch);
        counters.inversions += 1;
        ops.field_ops.invs += 1;
        ops.field_ops.muls += 3 * n as u64;
        self.sweep_field_muls += 2 + 3 * n as u64;
        self.sweep_field_adds += n as u64;
        for j in 0..n {
            let rep = self.reps[at(j)];
            let i = j;
            if self.degenerate[i] {
                for summand in [rep.plus, rep.minus] {
                    let t = g.add(ops, point, g.neg(fb.points[summand]));
                    if let Some(found) = self.lookup(ctx, fb, ops, counters, point, summand, t) {
                        return Some(found);
                    }
                }
                continue;
            }
            let inv = self.diffs[i];
            // `T = R − ε·F_i`: ε = +1 adds `−F_i = (x_i, −y_i)`, so
            // `λ = (−y_i − y_R)/(x_i − x_R) = (y_R + y_i)/(x_R − x_i)`;
            // ε = −1 adds `F_i`, `λ = (y_R − y_i)/(x_R − x_i)`.  Each `T`
            // is one group addition's result and is charged as one; its
            // field work (two multiplications, one squaring, two
            // conversions out of Montgomery form counted as
            // multiplications) is tallied beside the ledger's.
            let lam_minus = f.mul(f.add(yr, rep.y), inv);
            let lam_plus = f.mul(f.sub(yr, rep.y), inv);
            for (summand, lam) in [(rep.plus, lam_minus), (rep.minus, lam_plus)] {
                let x3 = f.sub(f.sub(f.sqr(lam), xr), rep.x);
                let y3 = f.sub(f.mul(lam, f.sub(xr, x3)), yr);
                ops.adds += 1;
                ops.field_ops.muls += 4;
                ops.field_ops.sqrs += 1;
                let t = PrimePoint::affine(f.from_mont(x3), f.from_mont(y3));
                if let Some(found) = self.lookup(ctx, fb, ops, counters, point, summand, t) {
                    return Some(found);
                }
            }
        }
        None
    }
}

impl RootfindSubtractOracle<'_> {
    /// The prepared sweep: the field and one representative per abscissa,
    /// in the order `decompose` walks them (`rootfind-subtract-gpu`).
    pub(crate) fn sweep(&self) -> Option<(Fp64, &[SweepRep])> {
        Some((self.field?, &self.reps))
    }

    /// The pair table's abscissae (`m = 3`), for the device probe set.
    pub(crate) fn pair_abscissae(&self) -> Option<Vec<u64>> {
        self.table.as_ref()?.map_abscissae()
    }

    /// What `decompose` charges for a target before its first candidate:
    /// the two conversions into Montgomery form and the batched inversion
    /// over the `k` abscissae.
    pub(crate) fn charge_sweep_setup(&mut self, ops: &mut GroupOps, counters: &mut OracleCounters) {
        let k = self.reps.len() as u64;
        ops.field_ops.muls += 2;
        counters.inversions += 1;
        ops.field_ops.invs += 1;
        ops.field_ops.muls += 3 * k;
        self.sweep_field_muls += 2 + 3 * k;
        self.sweep_field_adds += k;
    }

    /// What `decompose` charges per non-degenerate candidate point, before
    /// its lookup.
    pub(crate) fn charge_candidate(ops: &mut GroupOps) {
        ops.adds += 1;
        ops.field_ops.muls += 4;
        ops.field_ops.sqrs += 1;
    }

    /// Is `t = R − F_summand` a base point (`m = 2`), or a pair sum
    /// (`m = 3`)?  A hit is re-added in the group before it is returned.
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn lookup(
        &mut self,
        ctx: &InstanceCtx<PrimeCurve>,
        fb: &FactorBase<PrimePoint>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: PrimePoint,
        summand: usize,
        t: PrimePoint,
    ) -> Option<Vec<usize>> {
        let g = ctx.group;
        if g.is_identity(&t) {
            counters.lookups += 1;
            return None;
        }
        match self.m {
            2 => {
                counters.lookups += 1;
                let j = fb.index_of_key(g.key(&t))?;
                // Fail closed: `F_summand + T` must be `R` in the group,
                // on the ledger.
                if g.add(ops, fb.points[summand], fb.points[j]) == point {
                    return Some(vec![summand, j]);
                }
                self.mismatches += 1;
                counters.frobfold_mismatches += 1;
                None
            }
            _ => {
                let table = self.table.as_ref()?;
                let (j, k) = table.probe(g, fb, ops, &mut counters.lookups, t)?;
                Some(vec![summand, j, k])
            }
        }
    }
}

/// Meet in the middle on a table folded by the signed Frobenius: the
/// same probe over a table `2n` times smaller.
///
/// With `large_primes=1` or `2` (and `m=3`) the oracle runs the same
/// probe loop through the large-prime collector
/// ([`LargePrimeCollector`]), which keeps partial relations whose
/// residual lies in a bounded domain `D` of `lp_domain_factor · |F|`
/// signed points and returns the complete relations they merge into;
/// see `ic_framework::large_prime`.
pub struct FrobeniusMitmOracle<'i> {
    m: u32,
    instance: &'i BinaryInstance,
    table: Option<FrobeniusPairTable>,
    large: Option<LargePrimeCollector<'i>>,
    count_setup: bool,
    lazy_members: bool,
    layout_members: bool,
    /// `tau_verify=1` (layout table only): the recovery check reads the
    /// base's stored orbit of `G` through the τ-adic NAF of `d`.
    tau_check: Option<TauOrbitCheck<FastPoint>>,
    /// `walk_sib=m` (layout table, m = 2): the `StrideGeneratorSib { m }`
    /// giant-step walk with x-only probes; 0 is the incumbent walk.
    walk_sib: u32,
    /// `ladder_verify=1`: the base's stored doubling chain `[2^i]G`,
    /// read by the recovery check (`ladder_mul`) instead of re-doubling.
    ladder: Option<Vec<FastPoint>>,
}

/// `orbit_ids` of the layout oracle (Koblitz K1 set-up lever, 2026-11-18):
/// `Some(μ)`, the curve's Frobenius trace, when the sibling build should
/// skip the same-orbit pairs a `Z[τ]` identity names as repeats
/// ([`FrobeniusPairTable::build_layout_plan`]); absent or 0 is the
/// incumbent build, bit for bit.
fn orbit_ids(params: &Params, inst: &BinaryInstance) -> Result<Option<i64>, String> {
    if !layout_flag(params, "orbit_ids")? {
        return Ok(None);
    }
    if !layout_flag(params, "sib")? {
        return Err("orbit_ids needs sib=1".into());
    }
    if inst.n < 7 {
        return Err("orbit_ids needs n >= 7".into());
    }
    let kc = inst
        .koblitz
        .as_ref()
        .ok_or("orbit_ids needs a Koblitz curve")?;
    if kc.trace != 1 && kc.trace != -1 {
        return Err("orbit_ids needs a Frobenius trace of +-1".into());
    }
    Ok(Some(kc.trace))
}

/// `walk_sib` of the layout oracle: absent or 0 is the incumbent walk.
fn walk_sib(params: &Params) -> Result<u32, String> {
    match params.get("walk_sib") {
        None => Ok(0),
        Some(_) => match params.u64("walk_sib")? {
            v @ 0..=64 => Ok(v as u32),
            v => Err(format!("walk_sib must be 0..=64, not {v}")),
        },
    }
}

/// A 0/1 flag of the layout oracle; absent is 0.
fn layout_flag(params: &Params, name: &str) -> Result<bool, String> {
    match params.get(name) {
        None => Ok(false),
        Some(_) => match params.u64(name)? {
            0 => Ok(false),
            1 => Ok(true),
            v => Err(format!("{name} must be 0 or 1, not {v}")),
        },
    }
}

impl<'i> FrobeniusMitmOracle<'i> {
    pub fn new(m: u32, instance: &'i BinaryInstance) -> Self {
        Self {
            m,
            instance,
            table: None,
            large: None,
            count_setup: false,
            lazy_members: false,
            layout_members: false,
            tau_check: None,
            walk_sib: 0,
            ladder: None,
        }
    }

    pub fn new_counted(m: u32, instance: &'i BinaryInstance) -> Self {
        Self {
            m,
            instance,
            table: None,
            large: None,
            count_setup: true,
            lazy_members: false,
            layout_members: false,
            tau_check: None,
            walk_sib: 0,
            ladder: None,
        }
    }

    /// [`new_counted`](Self::new_counted) over a table that names the
    /// orbit members of a hit when it happens
    /// ([`FrobeniusPairTable::build_lazy`]) instead of for every base
    /// point at build.  The same entries and relations; less set-up work.
    pub fn new_lazy_counted(m: u32, instance: &'i BinaryInstance) -> Self {
        Self {
            lazy_members: true,
            ..Self::new_counted(m, instance)
        }
    }

    /// [`new_counted`](Self::new_counted) over the table of a base laid
    /// out by orbit ([`FrobeniusPairTable::build_layout`]): the same
    /// entries and relations, no Frobenius map or member lookup at build
    /// or at a hit, and the same-orbit pairs added once per rotation
    /// class.  Refuses a base without the layout.
    pub fn new_layout_counted(m: u32, instance: &'i BinaryInstance) -> Self {
        Self {
            layout_members: true,
            ..Self::new_counted(m, instance)
        }
    }

    /// The large-prime collector of this run, when `large_primes` is set.
    pub fn large_prime_collector(&self) -> Option<&LargePrimeCollector<'i>> {
        self.large.as_ref()
    }

    /// The first error the collector's exact eliminator returned, if any.
    pub fn large_prime_error(&self) -> Option<&str> {
        self.large.as_ref().and_then(|lp| lp.last_error())
    }
}

impl<'a> DecompositionOracle<BinaryGroup<'a>> for FrobeniusMitmOracle<'_> {
    fn name(&self) -> &str {
        if self.layout_members {
            "mitm-frobenius-layout-counted"
        } else if self.lazy_members {
            "mitm-frobenius-lazy-counted"
        } else if self.count_setup {
            "mitm-frobenius-counted"
        } else {
            "mitm-frobenius"
        }
    }

    fn summands(&self) -> u32 {
        self.m
    }

    fn describe(&self, params: &Params) -> String {
        match LargePrimeConfig::from_params(params) {
            Ok(Some(config)) => format!(
                "a pair table folded by the signed Frobenius, one entry per orbit, plus a large-prime collector with up to {} residuals in a domain of {} × |F| signed points",
                config.large_primes, config.domain_factor
            ),
            _ => "a pair table folded by the signed Frobenius, one entry per orbit".into(),
        }
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            ("m", "summands, 2 or 3"),
            (
                "sib",
                "1 (layout table only): form each signed pair P + X, P - X from one inversion (x-only siblings; charged one addition plus one sibling_second_points) and skip P + (-P); the same entries and probes. 0 or absent: the incumbent build",
            ),
            (
                "tau_verify",
                "1 (layout table only; column 0 must be the generator's orbit, generator_orbit=1): the recovery check forms [d]G as the tau-adic NAF of d summed over the stored signed orbit of G (one addition per non-zero digit, tau^n = 1), with its recoding steps reported as tau_naf_recode_steps_uncharged. 0 or absent: double-and-add",
            ),
            (
                "walk_sib",
                "m >= 1 (layout table, m=2, targets=stride-generator; Koblitz K1 speed-up, 2026-11-18): the same targets Q + [k]G in the same order, formed in blocks of 2m+1 around a centre C (one addition of [2m+1]G a block): C + [i]G and the abscissa of C - [i]G from ONE inversion each (charged one addition plus one sibling_second_points), the abscissa probed by one canonicalisation and one lookup and, on a hit, its point formed by one more addition and probed in full; set-up [2]G..[m+1]G and [2m+1]G, m+1 operations. 0 or absent: the incumbent walk",
            ),
            (
                "ladder_verify",
                "1 (needs a base with a stored doubling chain, compact-orbit-scan with multiple_doublings): the recovery check forms [d]G from the chain [2^i]G the base formed and charged on its way to its seeds (ladder_mul: popcount(d)-1 additions, doublings only above the chain), not by re-doubling G. 0 or absent: double-and-add",
            ),
            (
                "orbit_ids",
                "1 (needs sib=1, n >= 7; Koblitz K1 set-up lever, 2026-11-18): in each orbit, skip the same-orbit pairs whose key the build inserts anyway, by identities of Z[tau] valid for every point (mu the trace): P + P (2 = mu*tau*(1 - mu*tau), the key of P - mu*sigma(P)), the plus half of rotation 2 (1 + tau^2 = -(1 - mu*tau)) and the sign-mu half of rotation 3 (1 + mu*tau^3 = -(1 + mu*tau)); a pair formed without one half is charged one addition and no sibling_second_points, each skip also saves its canonicalisation and insert; the same table keys and probes (the key of 2P is stored as (P, -mu*sigma(P))). 0 or absent: the incumbent build",
            ),
            (
                "large_primes",
                "0 (default), 1 or 2 residual points outside the base a partial relation may carry; needs m=3",
            ),
            (
                "lp_domain_factor",
                "size of the large-prime domain D as a multiple of |F| in signed points (default 10); D is the next projected signed Frobenius orbits of the raw-x scan after the base's",
            ),
            (
                "lp_raw_x_cap",
                "inclusive raw-abscissa cap of the scan that materialises D (default 2^40)",
            ),
        ]
    }

    fn prepare(
        &mut self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        fb: &FactorBase<FastPoint>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<(), String> {
        if let Some(config) = LargePrimeConfig::from_params(params)? {
            if self.m != 3 {
                return Err("large_primes needs the three-summand probe loop (m=3)".into());
            }
            if self.lazy_members || self.layout_members {
                return Err(
                    "large_primes is not implemented for the lazy- or layout-member table".into(),
                );
            }
            // The collector builds the classic table itself (its direct
            // path is the plain probe) and the large table beside it.
            self.large = Some(LargePrimeCollector::new(
                self.instance,
                ctx,
                fb,
                config,
                ops,
            )?);
            self.table = None;
            return Ok(());
        }
        if self.layout_members && fb.frobenius_orbit_layout != Some(self.instance.n) {
            return Err(
                "mitm-frobenius-layout-counted needs a base laid out by orbit (compact-orbit-scan)"
                    .into(),
            );
        }
        let sib = layout_flag(params, "sib")?;
        let tau_verify = layout_flag(params, "tau_verify")?;
        if (sib || tau_verify) && !self.layout_members {
            return Err("sib and tau_verify need mitm-frobenius-layout-counted".into());
        }
        if fb.index_elided() && !self.layout_members {
            return Err("a base without its index needs mitm-frobenius-layout-counted".into());
        }
        // A base without its negatives (`lazy_neg`) is read only by the
        // two-summand layout probe, which forms a negative when it needs it.
        if fb.negations_deferred && (!self.layout_members || self.m != 2 || tau_verify) {
            return Err(
                "a base without its negatives (lazy_neg) needs mitm-frobenius-layout-counted with m=2 and no tau_verify".into(),
            );
        }
        let ids = orbit_ids(params, self.instance)?;
        if ids.is_some() && !self.layout_members {
            return Err("orbit_ids needs mitm-frobenius-layout-counted".into());
        }
        self.walk_sib = walk_sib(params)?;
        if self.walk_sib > 0 && (!self.layout_members || self.m != 2) {
            return Err("walk_sib needs mitm-frobenius-layout-counted with m=2".into());
        }
        self.ladder = None;
        if layout_flag(params, "ladder_verify")? {
            if !self.layout_members {
                return Err("ladder_verify needs mitm-frobenius-layout-counted".into());
            }
            if tau_verify {
                return Err(
                    "ladder_verify and tau_verify are two recovery checks; pick one".into(),
                );
            }
            if fb.generator_ladder.len() < 2 || fb.generator_ladder[0] != ctx.generator {
                return Err(
                    "ladder_verify needs a base that stored its doubling chain from G (compact-orbit-scan multiple_doublings)"
                        .into(),
                );
            }
            self.ladder = Some(fb.generator_ladder.clone());
        }
        self.tau_check = None;
        if tau_verify {
            let n = self.instance.n as usize;
            let kc = self
                .instance
                .koblitz
                .as_ref()
                .ok_or("tau_verify needs a Koblitz curve")?;
            // Column 0 must be G's own orbit, laid out as
            // (τ^t(G), −τ^t(G)) for t < n (`generator_orbit=1`).
            if fb.points.len() < 2 * n || fb.points[0] != ctx.generator {
                return Err(
                    "tau_verify needs column 0 to be the generator's orbit (generator_orbit=1)"
                        .into(),
                );
            }
            self.tau_check = Some(TauOrbitCheck {
                orbit: (0..n).map(|t| fb.points[2 * t]).collect(),
                neg: (0..n).map(|t| fb.points[2 * t + 1]).collect(),
                mu: kc.trace,
            });
        }
        let table = if self.layout_members {
            FrobeniusPairTable::build_layout_plan(self.instance, fb, sib, ids)
        } else if self.lazy_members {
            FrobeniusPairTable::build_lazy(self.instance, fb)
        } else {
            FrobeniusPairTable::build(self.instance, fb)
        }
        .ok_or("this instance has no Koblitz structure to fold by")?;
        ops.merge(table.build_ops);
        self.table = Some(table);
        Ok(())
    }

    fn setup_work_native(&self) -> BTreeMap<String, u64> {
        // The large-prime collector builds its own tables, which this
        // does not count: its records keep `table_insert_attempts` listed.
        if self.large.is_some() {
            return BTreeMap::new();
        }
        let Some(table) = &self.table else {
            return BTreeMap::new();
        };
        let mut out = table.work_counters();
        if !self.count_setup {
            // The uncounted variant's `setup_native` leaves the build's
            // canonicalisations, Frobenius maps and orbit lookups out.
            for (name, v) in table.build_counters() {
                *out.entry(name).or_insert(0) += v;
            }
        }
        table_counted(out)
    }

    fn setup_native(&self) -> BTreeMap<String, u64> {
        let mut counts = BTreeMap::new();
        if let Some(lp) = &self.large {
            counts.extend(lp.setup_counters());
        }
        if self.count_setup {
            if let Some(table) = &self.table {
                counts.insert("canonicalisations".into(), table.build_canonicalisations);
                counts.insert("frobenius_maps".into(), table.build_frobenius_maps);
                counts.insert("lookups".into(), table.build_lookups);
                counts.insert("pair_table_entries".into(), table.entries);
                counts.insert("pair_table_representatives".into(), table.representatives);
                // Zero-free: absent off the `orbit_ids` / `lazy_neg` levers.
                if table.identity_skips > 0 {
                    counts.insert("orbit_identity_skips".into(), table.identity_skips);
                }
                if table.build_point_negations > 0 {
                    counts.insert(
                        "point_negations_uncharged".into(),
                        table.build_point_negations,
                    );
                }
            }
        }
        counts
    }

    fn recovery_tau_orbit(&self) -> Option<TauOrbitCheck<FastPoint>> {
        self.tau_check.clone()
    }

    fn recovery_ladder(&self) -> Option<Vec<FastPoint>> {
        self.ladder.clone()
    }

    fn walk_siblings(&self) -> u32 {
        self.walk_sib
    }

    fn probe_x(
        &mut self,
        _ctx: &InstanceCtx<BinaryGroup<'a>>,
        _fb: &FactorBase<FastPoint>,
        counters: &mut OracleCounters,
        x: u64,
    ) -> Option<bool> {
        if self.walk_sib == 0 || self.large.is_some() {
            return None;
        }
        let table = self.table.as_ref()?;
        Some(table.probe_x(counters, x))
    }

    fn decompose(
        &mut self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        fb: &FactorBase<FastPoint>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: FastPoint,
    ) -> Option<Vec<usize>> {
        let table = self.table.as_ref()?;
        decompose_mitm_frobenius(ctx.group, fb, table, self.m, ops, counters, point)
    }

    fn decompose_relations(
        &mut self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        fb: &FactorBase<FastPoint>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: FastPoint,
        a: u64,
        b: u64,
    ) -> Vec<Relation> {
        match self.large.as_mut() {
            Some(lp) => lp.decompose(ctx, fb, ops, counters, point, a, b),
            None => match self.decompose(ctx, fb, ops, counters, point) {
                Some(summands) => vec![Relation::Summands(summands)],
                None => Vec::new(),
            },
        }
    }

    fn relation_counters(&self) -> BTreeMap<String, u64> {
        self.large
            .as_ref()
            .map(|lp| lp.relation_counters())
            .unwrap_or_default()
    }
}

// ── The bridge to the solver plug point ────────────────────────────

/// Holds a [`SystemSolver`] and the record of what it cost, so an
/// algebraic oracle can be written without repeating the bookkeeping.
///
/// This is what makes the solver plug point reachable from a whole
/// pipeline: swap `buchberger-f2` for `sat-cdcl` and the change
/// propagates through the relation phase to the recovered key, with
/// every stage still counted.
pub struct SolverHarness {
    pub solver: Box<dyn SystemSolver>,
    pub params: Params,
    pub budget: Option<Duration>,
    last_shape: Option<SystemShape>,
    last_cost: Option<SolverCost>,
    /// Targets whose solver hit its budget.  Counted, never silently
    /// folded into "did not decompose": an oracle that did that would
    /// quietly lower its own hit rate and make the relation phase it
    /// feeds unmeasurable.
    pub budget_exceeded: u64,
}

impl SolverHarness {
    pub fn new(solver: Box<dyn SystemSolver>, params: Params, budget: Option<Duration>) -> Self {
        Self {
            solver,
            params,
            budget,
            last_shape: None,
            last_cost: None,
            budget_exceeded: 0,
        }
    }

    /// Solve one descended system, recording what it cost.
    pub fn solve(&mut self, system: &BooleanSystem) -> SolverVerdict {
        let shape = system.shape();
        self.last_shape = Some(shape.clone());
        if !self.solver.accepts(&shape) {
            self.last_cost = None;
            self.budget_exceeded += 1;
            return SolverVerdict::BudgetExceeded;
        }
        let (verdict, cost) = self.solver.solve(system, &self.params, self.budget);
        self.last_cost = Some(cost);
        if matches!(verdict, SolverVerdict::BudgetExceeded) {
            self.budget_exceeded += 1;
        }
        verdict
    }

    pub fn shape(&self) -> Option<&SystemShape> {
        self.last_shape.as_ref()
    }

    pub fn cost(&self) -> Option<&SolverCost> {
        self.last_cost.as_ref()
    }
}

// ── The algebraic oracle ───────────────────────────────────────────

/// Descend the Semaev polynomial over the base's abscissa subspace and
/// hand the boolean system to the chosen [`SystemSolver`].
///
/// This is the oracle that makes the solver plug point reach the `S`
/// column: swap `buchberger-f2` for `sat-cdcl` and the change
/// propagates through the relation phase to the recovered logarithm,
/// with every stage still counted.  It requires a factor base whose
/// abscissae form an `F_2`-subspace — `binary-subspace` and
/// `koblitz-orbit` both record theirs in `FactorBase::subspace_basis`.
///
/// ## What it charges
///
/// The descent and the solver are engine work, not group operations,
/// and are reported through [`DecompositionOracle::solver_totals`] in
/// the solver's own unit; the runner prices them into `S`.  Lifting a
/// solution back to signed base points costs real group additions,
/// which are charged to `ops` like any other oracle's.
///
/// ## The cap
///
/// The descent is symbolic — the summation polynomial expanded in
/// `F_{2^n}[v]/(v² − v)` term by term — so it builds no table and is
/// capped only by the monomial mask: `m·n' ≤ 64` boolean variables,
/// `n' ≤ 32` at two summands and `n' ≤ 21` at three.  What limits a
/// row above that is the engine, which says so through `accepts`.
pub struct DescentAlgebraicOracle<'i> {
    summands: u32,
    instance: &'i BinaryInstance,
    v_basis: Vec<u64>,
    /// Ordered τ-slots (lead L5): `None` is the plain descent (every
    /// summand over `V`); `Some(n)` tries, per target, the systems with
    /// summand 2 over `σ^{j}(V)` for `j = 0, …, n−1` (and summand 3 over
    /// `V`), stopping at the first that lifts.
    slot_rotations: Option<u32>,
    harness: SolverHarness,
    totals: SolverTotals,
    /// The target-independent descents
    /// ([`DescentTemplate`](crate::cryptanalysis::pq_descent_symbolic::DescentTemplate)),
    /// one a rotation: `templates[0]` is the plain descent (every summand
    /// over `V`, which is also τ-slot 0), built in `prepare` and charged
    /// to `oracle_setup`; with slots, `templates[j]` (summand 2 over
    /// `σ^{j}(V)`) is built the first time a target reaches rotation `j`,
    /// from slot `j − 1`'s shifted basis by one squaring an element, and
    /// charged once, to that target's solver block.  Per target only the
    /// substitution of `x_R` and the split into coordinates remain.
    templates: Vec<Option<crate::cryptanalysis::pq_descent_symbolic::DescentTemplate>>,
    /// What building `templates[0]` in `prepare` cost, for `oracle_setup`.
    setup_work: crate::cryptanalysis::pq_descent_symbolic::DescentWork,
    /// Systems the solver decided satisfiable none of whose solutions
    /// lifted to base points summing to the target.  Expected, not a
    /// defect: a summation polynomial vanishes over the algebraic
    /// closure, so a solution may name abscissae whose points live on
    /// the quadratic twist (`y ∈ F_{2^{2n}}`, never in the base), and
    /// the pair table never sees those.  Reported as
    /// `unliftable_systems` beside `lift_failures` so the hit rate can
    /// be read against what the solver actually found.
    pub unliftable: u64,
}

impl<'i> DescentAlgebraicOracle<'i> {
    pub fn new(
        summands: u32,
        instance: &'i BinaryInstance,
        solver: Box<dyn SystemSolver>,
        solver_params: Params,
        budget: Option<Duration>,
    ) -> Self {
        let totals = SolverTotals {
            solver: solver.name().to_string(),
            ..Default::default()
        };
        Self {
            summands,
            instance,
            v_basis: Vec::new(),
            slot_rotations: None,
            harness: SolverHarness::new(solver, solver_params, budget),
            totals,
            templates: Vec::new(),
            setup_work: Default::default(),
            unliftable: 0,
        }
    }

    /// The template of rotation `j` (summand 2 over `σ^{j}(V)`; `j = 0` is
    /// the plain descent), built on first use and kept for the run.  Its
    /// construction is counted on the descent counter of the calling
    /// thread, so it lands in whatever block reads that counter next:
    /// `oracle_setup` for `j = 0` in `prepare`, the solver block of the
    /// first target to reach rotation `j` otherwise.  Rotations are tried
    /// in order, so slot `j − 1`'s shifted basis is there to square once.
    fn template(&mut self, j: u32) -> &crate::cryptanalysis::pq_descent_symbolic::DescentTemplate {
        let j = j as usize;
        if self.templates.len() <= j {
            self.templates.resize(j + 1, None);
        }
        if self.templates[j].is_none() {
            let inst = self.instance;
            let gf = &inst.gf;
            let shifted: Vec<u64> = if j == 0 {
                self.v_basis.clone()
            } else {
                let prev = self.templates[j - 1]
                    .as_ref()
                    .expect("rotations are built in order");
                // One squaring of each element of slot `j − 1`'s basis
                // (put through the descent's counter so it reaches the
                // same block) and the copies of the bases.
                charge_slot_bases(self.v_basis.len() as u64, 1, self.summands);
                prev.summand_bases[1].iter().map(|&e| gf.sqr(e)).collect()
            };
            let mut bases = vec![self.v_basis.clone(), shifted];
            if self.summands == 3 {
                bases.push(self.v_basis.clone());
            }
            self.templates[j] = Some(
                crate::cryptanalysis::pq_descent_symbolic::descent_template_with_bases(
                    gf, inst.b, &bases,
                )
                .expect("prepare checked the dimension"),
            );
        }
        self.templates[j].as_ref().expect("built above")
    }

    /// The descended system of rotation `j` at the target abscissa `x_r`:
    /// the template specialised.  Its `lift` maps a solution back to
    /// abscissae.  `prepare` must have run.
    fn descend_rotation(&mut self, x_r: u64, j: u32) -> SymbolicDescent {
        let inst = self.instance;
        let gf = &inst.gf;
        let _ = self.template(j);
        self.templates[j as usize]
            .as_ref()
            .expect("built above")
            .specialise(gf, x_r)
    }

    pub fn solver_name(&self) -> &str {
        self.harness.solver.name()
    }
}

fn system_of(sys: &SymbolicDescent) -> BooleanSystem {
    BooleanSystem {
        equations: sys.equations.clone(),
        n_vars: sys.n_vars,
    }
}

/// The descent's slot bases, as primitives: `n'·j` squarings and the
/// `(m + 1)·n'` words of the basis copies.
fn charge_slot_bases(n_prime: u64, j: u32, summands: u32) {
    crate::cryptanalysis::pq_descent_symbolic::add_descent_work(
        crate::cryptanalysis::pq_descent_symbolic::DescentWork {
            field_sqrs: n_prime * u64::from(j),
            word_ops: n_prime * (1 + u64::from(summands)),
            ..Default::default()
        },
    );
}

/// The work an algebraic oracle does on one descended system outside the
/// descent and the solver, in `bitop/v1` primitives added to `extra`
/// (the oracle's solver block, so that the relation phase is complete
/// when the solver's count is): the descent's own counters
/// ([`take_descent_work`](crate::cryptanalysis::pq_descent_symbolic::take_descent_work)),
/// the copy of the equations into the [`BooleanSystem`] (a word a term)
/// and `shape_calls` shape computations ([`BooleanSystem::shape_word_ops`]).
pub(crate) fn charge_system_build(
    extra: &mut BTreeMap<String, u64>,
    system: &BooleanSystem,
    shape: &SystemShape,
    shape_calls: u64,
) {
    crate::cryptanalysis::pq_descent_symbolic::take_descent_work().charge(extra);
    let terms: u64 = system.equations.iter().map(|p| p.terms.len() as u64).sum();
    crate::cryptanalysis::ic_boundary::bump_counter(
        extra,
        "bitop_word_ops",
        terms + shape_calls * system.shape_word_ops(shape),
    );
}

/// The hash probes of one `lift_abscissae` call on `xs`: one per
/// abscissa looked up, stopping at the first the base does not hold.
/// (The additions it performs are charged to `ops` already.)
pub(crate) fn lift_probes(fb: &FactorBase<FastPoint>, xs: &[u64], lifted: bool) -> u64 {
    if lifted {
        return xs.len() as u64;
    }
    let mut probes = 0u64;
    for x in xs {
        probes += 1;
        if !fb.x_index.contains_key(x) {
            break;
        }
    }
    probes
}

/// Charge one lift of a solution to `extra`: the descent counter's share
/// ([`SymbolicDescent::lift`]'s bit tests and field adds) and the probes
/// of [`lift_probes`].
pub(crate) fn charge_lift(
    extra: &mut BTreeMap<String, u64>,
    fb: &FactorBase<FastPoint>,
    xs: &[u64],
    lifted: bool,
) {
    crate::cryptanalysis::pq_descent_symbolic::take_descent_work().charge(extra);
    crate::cryptanalysis::ic_boundary::bump_counter(
        extra,
        "bitop_hash_probes",
        lift_probes(fb, xs, lifted),
    );
}

impl<'a> DecompositionOracle<BinaryGroup<'a>> for DescentAlgebraicOracle<'_> {
    fn setup_work_native(&self) -> BTreeMap<String, u64> {
        // No table.  The target-independent descent (the template of
        // `S_{m+1}` in `X`) is built once in `prepare` and charged here;
        // each target's specialisation is charged to the solver block in
        // the relation phase.
        let w = &self.setup_work;
        let mut out = BTreeMap::new();
        crate::cryptanalysis::bitop_tally::Tally {
            word_ops: w.word_ops,
            hash_probes: w.hash_probes,
            field_adds: w.field_adds,
            field_muls: w.field_muls,
            field_sqrs: w.field_sqrs,
            field_invs: 0,
        }
        .add_work_native(&mut out);
        table_counted(out)
    }

    fn name(&self) -> &str {
        "descent-algebraic"
    }

    fn summands(&self) -> u32 {
        self.summands
    }

    fn describe(&self, _params: &Params) -> String {
        format!(
            "Weil-descend S_{} over the base's abscissa subspace and solve with {}",
            self.summands + 1,
            self.harness.solver.name()
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            ("m", "summands, 2 (descends S3) or 3 (descends S4)"),
            (
                "slots",
                "ordered tau-slots (Koblitz): `all` tries summand 2 over every Frobenius image of V per target; absent for the plain descent",
            ),
        ]
    }

    fn prepare(
        &mut self,
        _ctx: &InstanceCtx<BinaryGroup<'a>>,
        fb: &FactorBase<FastPoint>,
        params: &Params,
        _ops: &mut GroupOps,
    ) -> Result<(), String> {
        self.slot_rotations = match params.get("slots") {
            None | Some("0") | Some("none") => None,
            Some("all") => {
                if self.instance.koblitz.is_none() {
                    return Err(
                        "slots need a Koblitz curve (the Frobenius must be an endomorphism)".into(),
                    );
                }
                Some(self.instance.n)
            }
            Some(other) => return Err(format!("unknown slots value `{other}`; use all")),
        };
        if !(2..=3).contains(&self.summands) {
            return Err(format!(
                "descent-algebraic takes m = 2 or 3, got {}",
                self.summands
            ));
        }
        let basis = fb.subspace_basis.as_ref().ok_or(
            "descent-algebraic needs a factor base whose abscissae form an F_2-subspace; \
             use binary-subspace or koblitz-orbit",
        )?;
        let cap = max_n_prime(self.summands);
        if basis.len() as u32 > cap {
            return Err(format!(
                "the descent's monomial mask holds n' ≤ {cap} at m = {}; this base has n' = {}",
                self.summands,
                basis.len()
            ));
        }
        self.v_basis = basis.clone();
        // The target-independent template, built once and charged to
        // `oracle_setup`.
        self.templates.clear();
        let _ = crate::cryptanalysis::pq_descent_symbolic::take_descent_work();
        let _ = self.template(0);
        self.setup_work = crate::cryptanalysis::pq_descent_symbolic::take_descent_work();
        // Every system on one base has the same shape, so descend one
        // abscissa now and let the engine decline the shape here, once,
        // with a reason a sweep can report — rather than target by
        // target, which would run the whole relation phase for nothing.
        let probe = system_of(&self.descend_rotation(self.instance.generator.x, 0));
        let shape = probe.shape();
        charge_system_build(&mut self.totals.extra, &probe, &shape, 1);
        if !self.harness.solver.accepts(&shape) {
            return Err(format!(
                "solver `{}` declines a system of {} unknowns and {} equations; \
                 use a smaller base or another engine",
                self.harness.solver.name(),
                shape.n_vars,
                shape.n_equations
            ));
        }
        Ok(())
    }

    fn decompose(
        &mut self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        fb: &FactorBase<FastPoint>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: FastPoint,
    ) -> Option<Vec<usize>> {
        if self.v_basis.is_empty() {
            return None;
        }
        // Descend, solve, and lift every solution until one sums to R;
        // with slots, one system per rotation of the second summand.
        let rotations = self.slot_rotations.unwrap_or(1);
        for j in 0..rotations {
            // Work left on this thread's descent counter by anything else
            // is not this target's.
            let _ = crate::cryptanalysis::pq_descent_symbolic::take_descent_work();
            let sys = self.descend_rotation(point.x, j);
            let system = system_of(&sys);
            let shape = system.shape();
            let verdict = self.harness.solve(&system);
            let exceeded = matches!(verdict, SolverVerdict::BudgetExceeded);
            let found = matches!(&verdict, SolverVerdict::Solved(s) if !s.is_empty());
            self.totals
                .absorb_outcome(&shape, self.harness.cost(), exceeded, found);
            // The descent, the copy, and two shape computations (here and
            // in the harness).
            charge_system_build(&mut self.totals.extra, &system, &shape, 2);
            crate::cryptanalysis::ic_boundary::bump_counter(
                &mut self.totals.extra,
                "slot_systems",
                1,
            );
            let SolverVerdict::Solved(solutions) = verdict else {
                continue;
            };
            for v in solutions {
                let xs = sys.lift(mask_low64(v));
                let lifted = crate::cryptanalysis::ic_boundary::lift_abscissae(
                    ctx.group, fb, ops, &xs, point,
                );
                charge_lift(&mut self.totals.extra, fb, &xs, lifted.is_some());
                if let Some(indices) = lifted {
                    crate::cryptanalysis::ic_boundary::bump_counter(
                        &mut self.totals.extra,
                        "slot_hits",
                        1,
                    );
                    *self
                        .totals
                        .extra
                        .entry(format!("slot_hit_rotation_{j}"))
                        .or_insert(0) += 1;
                    return Some(indices);
                }
                counters.lift_failures += 1;
            }
            self.unliftable += 1;
            counters.unliftable_systems += 1;
        }
        None
    }

    fn last_system(&self) -> Option<SystemShape> {
        self.totals.shape.clone()
    }

    fn solver_totals(&self) -> Option<SolverTotals> {
        Some(self.totals.clone())
    }
}

// ── The symmetrised Koblitz base and oracle ────────────────────────

/// Parse a `divisor` parameter: indices into
/// [`crate::cryptanalysis::koblitz_index_calculus::all_factors_of_x_n_minus_1`],
/// separated by `;` (a `,` would split the plug-in spec itself; a `,` is
/// still accepted here for a [`Params`] built in code, but
/// [`Params::parse_spec`] never lets one through from a command line).
fn divisor_indices(params: &Params) -> Result<Vec<usize>, String> {
    let raw = params
        .get("divisor")
        .ok_or("missing parameter `divisor`; try 0;1 (index 0 is x + 1)")?;
    let idx: Result<Vec<usize>, String> = raw
        .split([',', ';'])
        .filter(|s| !s.is_empty())
        .map(|s| {
            s.trim()
                .parse::<usize>()
                .map_err(|_| format!("divisor index `{s}` is not a number"))
        })
        .collect();
    let idx = idx?;
    if idx.is_empty() {
        return Err("parameter `divisor` selected no factors".into());
    }
    Ok(idx)
}

/// `F_u = { P : u(P) ∈ V }` for the frame `u = 1/(x + 1)` and a
/// Frobenius-invariant subspace `V ∋ 1`, each signed Frobenius orbit
/// folded onto one column.
///
/// This is the base of `research/notes/index-calculus/RESEARCH_EXOTIC_COORDINATES.md`
/// §8: the rational 2-torsion point `T = (0, 1)` acts on the `x`-line
/// as `x ↦ 1/x`, the frame turns that into `u ↦ u + 1`, and a subspace
/// containing `1` is closed under it for free.  `T` itself (`u = 1`) is
/// a base point.  The abscissae of `F_u` are *not* an `F_2`-subspace,
/// so the `descent-algebraic` oracle cannot run on this base; the
/// `symmetrised` oracle is the one that can, and `mitm-frobenius` runs
/// on it like on any other.  The same `divisor` handed to
/// `koblitz-orbit` gives the `x`-frame base `F_x` for the same `V`,
/// which is the matched control.
pub struct KoblitzSymmetrisedBase<'i> {
    pub instance: &'i BinaryInstance,
}

impl<'a> FactorBaseBuilder<BinaryGroup<'a>> for KoblitzSymmetrisedBase<'_> {
    fn name(&self) -> &str {
        "koblitz-symmetrised"
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "F_u = {{P : 1/(x + 1) ∈ V}} for the Frobenius-invariant V ∋ 1 of divisor {}, {}",
            params.get("divisor").unwrap_or("?"),
            if params.flag("no_fold") {
                "one column per abscissa (the unfolded control)"
            } else {
                "each signed Frobenius orbit folded onto one column"
            }
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            (
                "divisor",
                "`;`-separated indices into the factorisation of xⁿ − 1, e.g. `divisor=0;1` (a `,` \
                 would end the parameter on the command line); index 0 is x + 1, which must be \
                 included so that 1 ∈ V; the same indices on koblitz-orbit give the x-frame base \
                 for the same V",
            ),
            (
                "no_fold",
                "1 to give every abscissa its own column: the control that shows what the fold buys",
            ),
            (
                "projected",
                "1 to fold by the signed Frobenius orbits of the cofactor projections [h]P instead of \
                 of the raw points: orbits whose projections coincide or are Frobenius translates \
                 share one column (on a base closed under +T, P and P + T do), which is the column \
                 count the relation matrix actually has to determine",
            ),
        ]
    }

    fn build(
        &self,
        _ctx: &InstanceCtx<BinaryGroup<'a>>,
        params: &Params,
        _ops: &mut GroupOps,
    ) -> Result<FactorBase<FastPoint>, String> {
        let kc = self
            .instance
            .koblitz
            .as_ref()
            .ok_or("this instance is not a Koblitz curve, so it has no 1/(x + 1) frame")?;
        let idx = divisor_indices(params)?;
        // The subspace, its lifts and its orbit view are charged to the
        // base's phase in `bitop/v1` alone (`tally_*`, `ecbench::work`):
        // `koblitz_factor_base` then counts its own indexes.
        let tally_before = crate::cryptanalysis::bitop_tally::snapshot();
        let fb_u = build_symmetrised_factor_base(kc, &idx).ok_or_else(|| {
            format!(
                "no symmetrised base for divisor {idx:?}: the subspace must contain 1 \
                 (include index 0, the factor x + 1) and be a proper invariant subspace"
            )
        })?;
        let view = frobenius_view_of_symmetrised(kc, &fb_u)
            .ok_or("the u-frame base has no Frobenius-orbit view; this is a bug")?;
        let tally = crate::cryptanalysis::bitop_tally::snapshot().since(tally_before);
        let fold = if params.flag("no_fold") {
            ColumnFold::Abscissa
        } else if params.flag("projected") {
            ColumnFold::ProjectedSignedFrobeniusOrbit
        } else {
            ColumnFold::SignedFrobeniusOrbit
        };
        let mut fb = koblitz_factor_base(
            self.instance,
            &view,
            fold,
            format!(
                "u-frame invariant subspace, divisor {idx:?}, dimension {}, {} points including T",
                fb_u.ell,
                fb_u.points.len()
            ),
        )
        .ok_or_else(|| "the u-frame subspace produced no usable factor base".to_string())?;
        tally.add_work_native(&mut fb.cost.work_native);
        // `koblitz_factor_base` also counts this base's Artin–Schreier
        // lifts and orbit walks from its size, as the native `as_solves`
        // and `frobenius_maps`.  The tally above already holds that work,
        // so those natives stay in the record (replay compares `native`)
        // but are marked so that `bitop/v1` does not price them twice.
        crate::cryptanalysis::bitop_tally::mark_tallied(
            &mut fb.cost.work_native,
            &["as_solves", "frobenius_maps"],
        );
        // The base is the subspace V of the u-frame, so a frozen copy
        // carries its dimension and basis (single words, as the
        // x-frame bases do) rather than only a description.
        fb.dimension = Some(fb_u.ell as u32);
        fb.subspace_basis = Some(
            fb_u.v_basis
                .iter()
                .map(|v| u64::try_from(v.to_biguint()).unwrap_or(0))
                .collect(),
        );
        Ok(fb)
    }
}

/// Decompose over `F_u` by solving the symmetrised summation polynomial
/// in the invariants `w = u² + u`, `s = Σu` with the repository's
/// boolean matrix-F4 and splitting (`koblitz_symmetrised`).
///
/// The system has `m(ℓ − 1) + 1` unknowns of boolean degree 2 at
/// `m = 2` and 4 at `m = 3`, against `m·ℓ` unknowns of degree 2 and 6
/// for the direct `x`-frame descent on the same `V`.  A root lifts to
/// points summing to `R` or to `R + T`; both are relations over `F_u`,
/// and the second carries `T` as an extra summand.
///
/// ## What it charges
///
/// The solve is engine work, reported through `solver_totals` in the
/// same unit and by the same rule as the `inherited-f4` adapter (word
/// XORs counted, priced by the runner); lifting a root back to signed
/// base points goes through the framework's own `lift_abscissae`, so
/// its group additions are charged to `ops` exactly as the
/// `descent-algebraic` oracle's are.
///
/// In `bitop/v1` the record is complete: every solve carries the whole
/// call (the system's build, the engine's matrices, the lifts) as
/// `bitop_*` keys with `bitop_complete = 1`, and `prepare` — the rebuild
/// of `F_u`, the point-for-point membership check, the field tables and
/// the generator's system — is charged to the `oracle_setup` phase as
/// `tally_*` counters with the `counted:table_insert_attempts` marker
/// (it builds no table).  `peak_bytes` stays 0: the engine reports no
/// memory, and memory is reported, never priced.
///
/// ## Parameters
///
/// `m` (2 or 3), `divisor` (the base's; copied from the factor base
/// when omitted on the command line), `engine`
/// (`inherited-f4` default, `matrix-f4`, `matrix-f5`), `max_degree`
/// (Macaulay cap, default 3: the cap is absolute, so the degree-4
/// `m = 3` system still builds its own degree at the root) and
/// `node_budget` (algebraic reduction calls before a solve gives up,
/// default 4096; splitting decisions are counted separately).
pub struct SymmetrisedOracle<'i> {
    summands: u32,
    instance: &'i BinaryInstance,
    fb_u: Option<SymmetrisedFactorBase>,
    st: Option<FieldStructure>,
    engine: SolverEngine,
    node_budget: usize,
    shape: Option<SystemShape>,
    totals: SolverTotals,
    /// What `prepare` tallied, for the `oracle_setup` phase.
    setup_tally: crate::cryptanalysis::bitop_tally::Tally,
    /// Solves whose root lifted in the `u`-frame but whose abscissae
    /// did not re-lift through the framework's sign resolution; must
    /// stay zero, and is reported so that it can be seen to.
    pub unliftable: u64,
    /// Targets with `u(R) ∈ {0, ∞}` or an oversize layout, which the
    /// system cannot be built for.
    pub unbuildable: u64,
}

impl<'i> SymmetrisedOracle<'i> {
    pub fn new(summands: u32, instance: &'i BinaryInstance) -> Self {
        Self {
            summands,
            instance,
            fb_u: None,
            st: None,
            engine: SolverEngine::InheritedF4 { max_degree: 3 },
            node_budget: 4096,
            shape: None,
            totals: SolverTotals::default(),
            setup_tally: Default::default(),
            unliftable: 0,
            unbuildable: 0,
        }
    }
}

impl<'a> DecompositionOracle<BinaryGroup<'a>> for SymmetrisedOracle<'_> {
    fn name(&self) -> &str {
        "symmetrised"
    }

    fn summands(&self) -> u32 {
        self.summands
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "solve the symmetrised S_{} in w = u² + u, s = Σu over F_u with {} (Macaulay cap {}, {} reduction calls)",
            self.summands + 1,
            params.get("engine").unwrap_or("inherited-f4"),
            params.get("max_degree").unwrap_or("3"),
            params.get("node_budget").unwrap_or("4096"),
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            ("m", "summands, 2 (symmetrised S3) or 3 (symmetrised S4)"),
            (
                "divisor",
                "the koblitz-symmetrised base's divisor; copied from the base when omitted",
            ),
            ("engine", "inherited-f4 (default), matrix-f4 or matrix-f5"),
            (
                "max_degree",
                "highest Macaulay degree built before splitting (default 3)",
            ),
            (
                "node_budget",
                "algebraic reduction calls before a solve gives up (default 4096)",
            ),
        ]
    }

    fn prepare(
        &mut self,
        _ctx: &InstanceCtx<BinaryGroup<'a>>,
        fb: &FactorBase<FastPoint>,
        params: &Params,
        _ops: &mut GroupOps,
    ) -> Result<(), String> {
        if !(2..=3).contains(&self.summands) {
            return Err(format!(
                "symmetrised takes m = 2 or 3, got {}",
                self.summands
            ));
        }
        let kc = self
            .instance
            .koblitz
            .as_ref()
            .ok_or("symmetrised needs a Koblitz instance")?;
        let idx = divisor_indices(params)?;
        // Everything below is set-up work `bitop/v1` prices from
        // `setup_work_native`; nothing of it is in `native`, so committed
        // records replay unchanged.
        let tally_before = crate::cryptanalysis::bitop_tally::snapshot();
        let fb_u = build_symmetrised_factor_base(kc, &idx)
            .ok_or_else(|| format!("no symmetrised base for divisor {idx:?}"))?;
        // The base the runner built must be this F_u, point for point:
        // a mismatched divisor would make every relation a lie.
        crate::cryptanalysis::bitop_tally::word_ops(1);
        if fb_u.points.len() != fb.points.len() {
            return Err(format!(
                "symmetrised needs the koblitz-symmetrised base with the same divisor: \
                 F_u has {} points, the base has {}",
                fb_u.points.len(),
                fb.points.len()
            ));
        }
        for p in &fb_u.points {
            // The packed lift (two words) and one probe of the base's index.
            crate::cryptanalysis::bitop_tally::word_ops(2);
            crate::cryptanalysis::bitop_tally::hash_probes(1);
            let key = self.instance.fast.lift(p).pack();
            if fb.index_of_key(key).is_none() {
                return Err(
                    "symmetrised needs the koblitz-symmetrised base with the same divisor: \
                     a point of F_u is not in the base"
                        .into(),
                );
            }
        }
        let max_degree = params.u64_or("max_degree", 3)? as u32;
        self.engine = match params.get("engine").unwrap_or("inherited-f4") {
            "inherited-f4" => SolverEngine::InheritedF4 { max_degree },
            "matrix-f4" => SolverEngine::MatrixF4 { max_degree },
            "matrix-f5" => SolverEngine::MatrixF5 { max_degree },
            other => {
                return Err(format!(
                    "unknown engine `{other}`; try inherited-f4, matrix-f4 or matrix-f5"
                ))
            }
        };
        self.node_budget = params.u64_or("node_budget", 4096)? as usize;
        // The structure constants: one product of basis monomials per
        // entry of the `n × n` table, and a word to store it.
        crate::cryptanalysis::bitop_tally::field_ops(0, u64::from(kc.n) * u64::from(kc.n), 0, 0);
        crate::cryptanalysis::bitop_tally::word_ops(u64::from(kc.n) * u64::from(kc.n));
        let st = FieldStructure::new(kc.n, &kc.curve.irreducible);
        // Every system on one base has the same shape; build one for the
        // generator so the report's degree columns come from a real
        // system, and so an oversize layout is refused here, once.
        let g = self.instance.fast.lower(self.instance.generator);
        let sys = build_symmetrised_system(kc, &fb_u, &g, self.summands as usize, &st).ok_or_else(
            || {
                format!(
                    "the symmetrised system for dimension {} at m = {} exceeds the Boolean-variable \
                     layout or the generator has u ∈ {{0, ∞}}",
                    fb_u.ell, self.summands
                )
            },
        )?;
        let system = BooleanSystem {
            equations: sys.equations,
            n_vars: sys.n_vars,
        };
        let shape = system.shape();
        crate::cryptanalysis::bitop_tally::word_ops(system.shape_word_ops(&shape));
        self.shape = Some(shape);
        self.setup_tally = crate::cryptanalysis::bitop_tally::snapshot().since(tally_before);
        self.totals = SolverTotals {
            solver: format!(
                "symmetrised {} (cap {}, budget {})",
                match self.engine {
                    SolverEngine::InheritedF4 { .. } => "inherited-f4",
                    SolverEngine::MatrixF4 { .. } => "matrix-f4",
                    SolverEngine::MatrixF5 { .. } => "matrix-f5",
                    _ => "engine",
                },
                max_degree,
                self.node_budget
            ),
            ..Default::default()
        };
        self.fb_u = Some(fb_u);
        self.st = Some(st);
        Ok(())
    }

    fn setup_work_native(&self) -> BTreeMap<String, u64> {
        // No table: nothing is inserted.  The set-up's own work is the
        // tally `prepare` took.
        let mut out = BTreeMap::new();
        self.setup_tally.add_work_native(&mut out);
        table_counted(out)
    }

    fn decompose(
        &mut self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        fb: &FactorBase<FastPoint>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: FastPoint,
    ) -> Option<Vec<usize>> {
        let (Some(fb_u), Some(st), Some(shape)) = (&self.fb_u, &self.st, &self.shape) else {
            return None;
        };
        let kc = self.instance.koblitz.as_ref()?;
        let target = self.instance.fast.lower(point);
        let before = f4_word_ops_thread();
        let tally_before = crate::cryptanalysis::bitop_tally::snapshot();
        let started = Instant::now();
        let outcome = symmetrised_groebner_decompose(
            kc,
            fb_u,
            st,
            &target,
            self.summands as usize,
            self.engine,
            self.node_budget,
        );
        let word_xors = f4_word_ops_thread().wrapping_sub(before);
        let wall_ns = started.elapsed().as_nanos() as u64;
        let Some(out) = outcome else {
            self.unbuildable += 1;
            return None;
        };
        let mut extra = BTreeMap::new();
        extra.insert("splits".to_string(), out.effort);
        extra.insert("oversize".to_string(), out.oversize as u64);
        extra.insert("used_t".to_string(), u64::from(out.used_t));
        // The whole call in `bitop/v1` primitives: the engine's word XORs
        // and everything else `bitop_tally` saw on this thread (the
        // system's build, the solver's matrices, scans and lifts).
        crate::cryptanalysis::bitop_tally::snapshot()
            .since(tally_before)
            .put_complete(&mut extra, word_xors);
        let cost = SolverCost {
            ops: word_xors,
            // The same unit string as the `inherited-f4` adapter, so the
            // runner prices both arms by the same rule.
            op_unit: "word XORs (elimination, specialisation and linear elimination only)".into(),
            wall_ns,
            // The engine reports no memory figure; reported, never priced.
            peak_bytes: 0,
            degree_reached: Some(out.built_degree),
            solving_degree: None,
            timed_out: !out.complete,
            extra,
            ..Default::default()
        };
        self.totals
            .absorb_outcome(shape, Some(&cost), !out.complete, out.relation.is_some());
        let indices = out.relation?;
        // Re-lift through the framework so the sign resolution is charged
        // exactly as it is for the x-frame oracle.  `T` (x = 0) is a base
        // point like any other, so a relation through `R + T` lifts too.
        let xs: Vec<u64> = indices
            .iter()
            .map(|&i| self.instance.fast.lift(&fb_u.points[i]).x)
            .collect();
        match crate::cryptanalysis::ic_boundary::lift_abscissae(ctx.group, fb, ops, &xs, point) {
            Some(found) => Some(found),
            None => {
                counters.lift_failures += 1;
                self.unliftable += 1;
                None
            }
        }
    }

    fn last_system(&self) -> Option<SystemShape> {
        self.shape.clone()
    }

    fn solver_totals(&self) -> Option<SolverTotals> {
        Some(self.totals.clone())
    }
}

// ── The chained x-frame descent as an oracle ────────────────────────

/// Why one call of [`ChainedXOracle`] ended, with what it consumed:
/// the per-target record the discrepancy protocol of round 6 (R6.1)
/// asks every driver to keep.
#[derive(Clone, Debug, serde::Serialize)]
pub struct ChainedXCall {
    /// `found`, `refuted` (the solve completed without a liftable root),
    /// `budget` (the node budget ran out), `unbuildable` (no system for
    /// this target) or `lift_failure` (a root whose abscissae did not
    /// re-lift through the framework's sign resolution).
    pub outcome: &'static str,
    /// Algebraic reductions consumed: the unit `node_budget` caps.
    pub reductions: u64,
    pub splits: u64,
    pub word_xors: u64,
    pub wall_ns: u64,
}

/// Decompose over an `F_2`-subspace base by the library's chained
/// `x`-frame descent ([`groebner_decompose`]): `m − 1` Semaev `S₃`
/// links with `(m − 2)·n` free intermediate abscissae, solved by the
/// repository's boolean F4 with splitting.
///
/// This is the system round 4 (lead 16.1) found feasible wherever the
/// symmetrised oracle is, which `ic` could not run before: the
/// `descent-algebraic` oracle is the direct `S_{m+1}` descent only.
/// `m = 2, 3, 4`; the layout has `m·ℓ + (m − 2)·n` unknowns and is
/// refused above the engine's 64.
///
/// ## What it charges
///
/// Engine work in word XORs, through `solver_totals`, in the same unit
/// string and by the same rule as the `inherited-f4` adapter and the
/// `symmetrised` oracle; the sign resolution goes through the
/// framework's `lift_abscissae`, so its group additions are charged to
/// `ops`.
///
/// ## Parameters
///
/// `m` (2, 3 or 4), `engine` (`inherited-f4` default, `matrix-f4`,
/// `matrix-f5`), `max_degree` (Macaulay cap, default 3), `node_budget`
/// (algebraic reduction calls before a solve gives up, default 4096) and
/// `trace` (`1` keeps a [`ChainedXCall`] per call in `calls`).
pub struct ChainedXOracle<'i> {
    summands: u32,
    instance: &'i BinaryInstance,
    view: Option<crate::cryptanalysis::koblitz_index_calculus::FrobeniusFactorBase>,
    index_of: std::collections::HashMap<(num_bigint::BigUint, num_bigint::BigUint), usize>,
    st: Option<FieldStructure>,
    engine: SolverEngine,
    node_budget: usize,
    shape: Option<SystemShape>,
    totals: SolverTotals,
    trace: bool,
    /// One record per call when `trace=1`.
    pub calls: Vec<ChainedXCall>,
    /// Roots that lifted in the descent but not through the framework.
    pub unliftable: u64,
    /// Targets the system could not be built for.
    pub unbuildable: u64,
}

impl<'i> ChainedXOracle<'i> {
    pub fn new(summands: u32, instance: &'i BinaryInstance) -> Self {
        Self {
            summands,
            instance,
            view: None,
            index_of: Default::default(),
            st: None,
            engine: SolverEngine::InheritedF4 { max_degree: 3 },
            node_budget: 4096,
            shape: None,
            totals: SolverTotals::default(),
            trace: false,
            calls: Vec::new(),
            unliftable: 0,
            unbuildable: 0,
        }
    }

    /// Unknowns of the chained layout for subspace dimension `ell`.
    pub fn layout_vars(m: usize, ell: usize, n: usize) -> usize {
        m * ell + m.saturating_sub(2) * n
    }

    fn record(&mut self, call: ChainedXCall) {
        if self.trace {
            self.calls.push(call);
        }
    }
}

impl<'a> DecompositionOracle<BinaryGroup<'a>> for ChainedXOracle<'_> {
    fn name(&self) -> &str {
        "chained-x"
    }

    fn summands(&self) -> u32 {
        self.summands
    }

    fn describe(&self, params: &Params) -> String {
        format!(
            "chained x-frame descent: {} S3 links over the base's subspace, {} (Macaulay cap {}, {} reduction calls)",
            self.summands.saturating_sub(1),
            params.get("engine").unwrap_or("inherited-f4"),
            params.get("max_degree").unwrap_or("3"),
            params.get("node_budget").unwrap_or("4096"),
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            ("m", "summands, 2, 3 or 4 (m − 1 chained S3 links)"),
            ("engine", "inherited-f4 (default), matrix-f4 or matrix-f5"),
            (
                "max_degree",
                "highest Macaulay degree built before splitting (default 3)",
            ),
            (
                "node_budget",
                "algebraic reduction calls before a solve gives up (default 4096)",
            ),
            (
                "trace",
                "1 keeps a per-call record (outcome, reductions, XORs)",
            ),
        ]
    }

    fn prepare(
        &mut self,
        _ctx: &InstanceCtx<BinaryGroup<'a>>,
        fb: &FactorBase<FastPoint>,
        params: &Params,
        _ops: &mut GroupOps,
    ) -> Result<(), String> {
        if !(2..=4).contains(&self.summands) {
            return Err(format!(
                "chained-x takes m = 2, 3 or 4, got {}",
                self.summands
            ));
        }
        let kc =
            self.instance.koblitz.as_ref().ok_or(
                "chained-x needs a Koblitz instance (the library's chained descent is b = 1)",
            )?;
        let words = fb.subspace_basis.as_ref().ok_or(
            "chained-x needs a factor base whose abscissae form an F_2-subspace; \
             use binary-subspace or koblitz-orbit",
        )?;
        let n = kc.n;
        let basis: Vec<crate::binary_ecc::F2mElement> = words
            .iter()
            .map(|&w| crate::binary_ecc::F2mElement::from_biguint(&num_bigint::BigUint::from(w), n))
            .collect();
        let vars = Self::layout_vars(self.summands as usize, basis.len(), n as usize);
        if vars > crate::cryptanalysis::koblitz_groebner::MAX_VARS {
            return Err(format!(
                "the chained layout at m = {} needs {vars} unknowns (dimension {}, n = {n}); \
                 the engine holds {}",
                self.summands,
                basis.len(),
                crate::cryptanalysis::koblitz_groebner::MAX_VARS
            ));
        }
        let view =
            crate::cryptanalysis::koblitz_symmetrised::plain_subspace_factor_base(kc, &basis)
                .ok_or("the base's subspace basis is not linearly independent")?;
        // The descent names points of its own view.  Every base point must
        // be one of them; a view point the base leaves out (`binary-subspace`
        // drops the abscissa 0) is removed from the lift's index, so a root
        // through it is never returned as a relation.
        let mut index_of = view.index_map();
        let mut in_base = 0usize;
        for p in &view.points {
            if fb.index_of_key(self.instance.fast.lift(p).pack()).is_some() {
                in_base += 1;
            } else {
                index_of.remove(&crate::cryptanalysis::koblitz_index_calculus::point_key(p));
            }
        }
        if in_base != fb.points.len() {
            return Err(format!(
                "chained-x: {} of the base's {} points lie over the base's subspace; \
                 the base is not the subspace base its basis names",
                in_base,
                fb.points.len()
            ));
        }
        let max_degree = params.u64_or("max_degree", 3)? as u32;
        self.engine = match params.get("engine").unwrap_or("inherited-f4") {
            "inherited-f4" => SolverEngine::InheritedF4 { max_degree },
            "matrix-f4" => SolverEngine::MatrixF4 { max_degree },
            "matrix-f5" => SolverEngine::MatrixF5 { max_degree },
            other => {
                return Err(format!(
                    "unknown engine `{other}`; try inherited-f4, matrix-f4 or matrix-f5"
                ))
            }
        };
        self.node_budget = params.u64_or("node_budget", 4096)? as usize;
        self.trace = params.u64_or("trace", 0)? == 1;
        let st = FieldStructure::new(n, &kc.curve.irreducible);
        let g = self.instance.fast.lower(self.instance.generator);
        let crate::binary_ecc::BinaryPoint::Affine { x: x_g, .. } = &g else {
            return Err("the generator is the point at infinity".into());
        };
        let sys = crate::cryptanalysis::koblitz_groebner::build_decomposition_system(
            &basis,
            x_g,
            &kc.curve.b,
            self.summands as usize,
            &st,
        )
        .ok_or("the chained system could not be built for the generator")?;
        self.shape = Some(
            BooleanSystem {
                equations: sys.equations,
                n_vars: sys.n_vars,
            }
            .shape(),
        );
        self.totals = SolverTotals {
            solver: format!(
                "chained-x {} (cap {}, budget {})",
                match self.engine {
                    SolverEngine::InheritedF4 { .. } => "inherited-f4",
                    SolverEngine::MatrixF4 { .. } => "matrix-f4",
                    SolverEngine::MatrixF5 { .. } => "matrix-f5",
                    _ => "engine",
                },
                max_degree,
                self.node_budget
            ),
            ..Default::default()
        };
        self.index_of = index_of;
        self.view = Some(view);
        self.st = Some(st);
        self.calls.clear();
        Ok(())
    }

    fn decompose(
        &mut self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        fb: &FactorBase<FastPoint>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: FastPoint,
    ) -> Option<Vec<usize>> {
        let kc = self.instance.koblitz.as_ref()?;
        let (Some(view), Some(st), Some(shape)) = (&self.view, &self.st, &self.shape) else {
            return None;
        };
        let target = self.instance.fast.lower(point);
        let before = f4_word_ops_thread();
        let started = Instant::now();
        let (relation, stats) = crate::cryptanalysis::koblitz_index_calculus::groebner_decompose(
            kc,
            view,
            &self.index_of,
            st,
            &target,
            self.summands as usize,
            self.engine,
            self.node_budget,
        );
        let word_xors = f4_word_ops_thread().wrapping_sub(before);
        let wall_ns = started.elapsed().as_nanos() as u64;
        let mut call = ChainedXCall {
            outcome: "refuted",
            reductions: stats.reductions as u64,
            splits: stats.splits as u64,
            word_xors,
            wall_ns,
        };
        if stats.unsupported {
            self.unbuildable += 1;
            call.outcome = "unbuildable";
            self.record(call);
            return None;
        }
        let shape = shape.clone();
        let exhausted = stats.exhausted;
        let mut extra = BTreeMap::new();
        extra.insert("splits".to_string(), stats.splits as u64);
        extra.insert("reductions".to_string(), stats.reductions as u64);
        extra.insert("oversize".to_string(), stats.oversize as u64);
        let cost = SolverCost {
            ops: word_xors,
            op_unit: "word XORs (elimination, specialisation and linear elimination only)".into(),
            wall_ns,
            peak_bytes: 0,
            degree_reached: Some(stats.max_degree_built),
            solving_degree: None,
            timed_out: exhausted,
            extra,
            ..Default::default()
        };
        self.totals
            .absorb_outcome(&shape, Some(&cost), exhausted, relation.is_some());
        let Some(indices) = relation else {
            call.outcome = if exhausted { "budget" } else { "refuted" };
            self.record(call);
            return None;
        };
        let xs: Vec<u64> = indices
            .iter()
            .map(|&i| self.instance.fast.lift(&view.points[i]).x)
            .collect();
        match crate::cryptanalysis::ic_boundary::lift_abscissae(ctx.group, fb, ops, &xs, point) {
            Some(found) => {
                call.outcome = "found";
                self.record(call);
                Some(found)
            }
            None => {
                counters.lift_failures += 1;
                self.unliftable += 1;
                call.outcome = "lift_failure";
                self.record(call);
                None
            }
        }
    }

    fn last_system(&self) -> Option<SystemShape> {
        self.shape.clone()
    }

    fn solver_totals(&self) -> Option<SolverTotals> {
        Some(self.totals.clone())
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn trace_coset_basis_roundtrip_retains_affine_metadata() {
        use crate::cryptanalysis::ic_boundary::{
            binary_affine_subspace_factor_base, koblitz_instance,
        };
        let ko = koblitz_instance(1, 17).expect("a = 1 over F_2^17");
        let (basis, offset) = trace_coset_basis(&ko, 6).unwrap();
        let tr = |v: u64| ko.artin_schreier.trace(v);
        assert_eq!(tr(offset), 1);
        assert!(basis.iter().all(|&v| tr(v) == 0));
        let fb = binary_affine_subspace_factor_base(&ko, &basis, offset);
        assert!(fb.subspace_basis.is_none());
        assert_eq!(fb.affine_subspace, Some((basis.clone(), offset)));
        assert!(!fb.points.is_empty());
        let g = BinaryGroup(&ko.fast);
        let mut ops = GroupOps::default();
        let half = ko.r * ko.cofactor / 2;
        assert!(fb.points.iter().all(|&p| g.mul(&mut ops, p, half).infinity));
        let (b0, o0) = trace_coset_basis(&koblitz_instance(0, 13).unwrap(), 6).unwrap();
        assert_eq!(o0, 0);
        assert_eq!(
            b0,
            trace_kernel_basis(&koblitz_instance(0, 13).unwrap(), 6).unwrap()
        );
    }

    use super::*;
    use crate::cryptanalysis::ic_boundary::koblitz_instance;
    #[allow(unused_imports)]
    use crate::cryptanalysis::pq_groebner_f2::{
        bit, low_bits, mask_from64, mask_low64, masks_low64, Mask, MASK_BITS,
    };

    /// **With `Tr(a) = 1` the trace coset is affine and still in `2E`**:
    /// the a = 1 Koblitz curve's base sits over `t₀ + ker Tr`, records
    /// itself as affine (so linear-subspace consumers refuse it), and
    /// every point has order dividing `#E / 2`.
    #[test]
    fn the_trace_coset_base_on_an_a1_curve_is_affine_and_in_two_e_dup() {
        use crate::cryptanalysis::ic_boundary::binary_affine_subspace_factor_base;
        let ko = koblitz_instance(1, 17).expect("a = 1 over F_2^17");
        let (basis, offset) = trace_coset_basis(&ko, 6).unwrap();
        let tr = |v: u64| ko.artin_schreier.trace(v);
        assert_eq!(tr(offset), 1);
        assert!(basis.iter().all(|&v| tr(v) == 0));
        assert!(trace_kernel_basis(&ko, 6).is_err(), "Tr(a) = 1 is refused");
        let fb = binary_affine_subspace_factor_base(&ko, &basis, offset);
        assert!(fb.subspace_basis.is_none());
        assert_eq!(fb.affine_subspace, Some((basis.clone(), offset)));
        assert!(!fb.points.is_empty());
        let g = BinaryGroup(&ko.fast);
        let mut ops = GroupOps::default();
        let half = ko.r * ko.cofactor / 2;
        assert!(fb.points.iter().all(|&p| g.mul(&mut ops, p, half).infinity));
        let (b0, o0) = trace_coset_basis(&koblitz_instance(0, 13).unwrap(), 6).unwrap();
        assert_eq!(o0, 0);
        assert_eq!(
            b0,
            trace_kernel_basis(&koblitz_instance(0, 13).unwrap(), 6).unwrap()
        );
    }

    /// **The oracle's templates give exactly the systems the per-target
    /// descent built**: for the plain descent and every τ-slot rotation,
    /// at two and three summands, on a small Koblitz curve and several
    /// targets, the specialised template equals `descend` /
    /// `descend_with_bases` over the `j`-fold squared basis, equation for
    /// equation, so the solver sees the same systems and the lifts the
    /// same abscissae.  The template is built once: a second target
    /// charges no slot-basis squarings.
    #[test]
    fn the_descent_templates_give_the_per_target_systems() {
        use super::super::solvers::solver_by_name;
        use crate::cryptanalysis::pq_descent_symbolic::{
            descend, descend_with_bases, take_descent_work,
        };
        let inst = koblitz_instance(0, 13).expect("a = 0 over F_2^13");
        let gf = &inst.gf;
        let basis = trace_kernel_basis(&inst, 3).unwrap();
        let targets = [inst.generator.x, 0x1, 0x2b5 & gf.mask, 0x1f0f & gf.mask, 0];
        for summands in [2u32, 3] {
            for slots in [None, Some(inst.n)] {
                let mut oracle = DescentAlgebraicOracle::new(
                    summands,
                    &inst,
                    solver_by_name("exhaustive").unwrap(),
                    Params::default(),
                    None,
                );
                oracle.v_basis = basis.clone();
                oracle.slot_rotations = slots;
                for (t, &x_r) in targets.iter().enumerate() {
                    for j in 0..slots.unwrap_or(1) {
                        let _ = take_descent_work();
                        let new = oracle.descend_rotation(x_r, j);
                        let squarings = take_descent_work().field_sqrs;
                        let old = if slots.is_none() {
                            descend(gf, inst.b, x_r, &basis, summands).unwrap()
                        } else {
                            let shifted: Vec<u64> = basis
                                .iter()
                                .map(|&e| (0..j).fold(e, |acc, _| gf.sqr(acc)))
                                .collect();
                            let mut bases = vec![basis.clone(), shifted];
                            if summands == 3 {
                                bases.push(basis.clone());
                            }
                            descend_with_bases(gf, inst.b, x_r, &bases).unwrap()
                        };
                        assert_eq!(
                            new.equations, old.equations,
                            "m = {summands}, slots {slots:?}, x_R = {x_r:#x}, j = {j}"
                        );
                        assert_eq!(new.summand_bases, old.summand_bases);
                        assert_eq!(new.field_monomials, old.field_monomials);
                        let v = (0x5a5a_5a5a_u64) & ((1u64 << new.n_vars) - 1);
                        assert_eq!(new.lift(v), old.lift(v));
                        if t > 0 {
                            // Only the powers of `x_R` are squared now.
                            assert!(squarings <= 2, "the template was rebuilt");
                        }
                    }
                }
            }
        }
    }

    /// The command-line form of a multi-factor divisor, end to end from
    /// the plug-in string to the indices both Koblitz bases read.
    #[test]
    fn divisor_indices_parse_the_semicolon_form_from_a_plugin_string() {
        for spec in [
            "koblitz-orbit:divisor=1;2",
            "koblitz-symmetrised:divisor=1;2",
        ] {
            let (_, params) = Params::parse_spec(spec).unwrap();
            assert_eq!(divisor_indices(&params).unwrap(), vec![1, 2], "{spec}");
        }
        let (_, params) = Params::parse_spec("koblitz-orbit:divisor=0,no_fold=1").unwrap();
        assert_eq!(divisor_indices(&params).unwrap(), vec![0]);
    }

    /// The comma form never reaches `divisor_indices` from a command
    /// line: the spec parser refuses it first, and says why.
    #[test]
    fn the_comma_form_is_refused_before_the_plugin_sees_it() {
        let err = Params::parse_spec("koblitz-orbit:divisor=1,2").unwrap_err();
        assert!(err.contains("`divisor=1;2`"), "{err}");
    }

    #[test]
    fn divisor_indices_reject_a_missing_empty_or_non_numeric_value() {
        let mut p = Params::default();
        assert!(divisor_indices(&p)
            .unwrap_err()
            .contains("missing parameter `divisor`"));
        p.set("divisor", ";");
        assert!(divisor_indices(&p)
            .unwrap_err()
            .contains("selected no factors"));
        p.set("divisor", "1;x");
        assert!(divisor_indices(&p)
            .unwrap_err()
            .contains("`x` is not a number"));
    }

    fn koblitz_ctx<'a>(
        inst: &BinaryInstance,
        g: &'a BinaryGroup<'a>,
    ) -> InstanceCtx<'a, BinaryGroup<'a>> {
        InstanceCtx {
            group: g,
            generator: inst.generator,
            target: inst.generator,
            r: inst.r,
            cofactor: inst.cofactor,
            group_order: inst.group_order,
            name: inst.name.clone(),
            field_degree: Some(inst.n),
        }
    }

    /// `mitm-frobenius` and `mitm-frobenius-counted` share the same hot
    /// kernel (`decompose_mitm_frobenius`); the counted flag only changes
    /// which setup counters are published.  Drift here would make the
    /// measurement path a different algorithm.
    #[test]
    fn mitm_frobenius_counted_matches_uncounted_decompositions() {
        let inst = koblitz_instance(0, 19).expect("K0 n19");
        let g = BinaryGroup(&inst.fast);
        let ctx = koblitz_ctx(&inst, &g);
        let fb = CompactOrbitScanBase { instance: &inst }
            .build(
                &ctx,
                &Params::parse_spec("compact-orbit-scan:columns=4,raw_x_cap=1000000")
                    .unwrap()
                    .1,
                &mut GroupOps::default(),
            )
            .expect("base");
        let params = Params::parse_spec("mitm-frobenius:m=2").unwrap().1;
        let mut plain = FrobeniusMitmOracle::new(2, &inst);
        let mut counted = FrobeniusMitmOracle::new_counted(2, &inst);
        plain
            .prepare(&ctx, &fb, &params, &mut GroupOps::default())
            .unwrap();
        counted
            .prepare(&ctx, &fb, &params, &mut GroupOps::default())
            .unwrap();
        assert_eq!(plain.name(), "mitm-frobenius");
        assert_eq!(counted.name(), "mitm-frobenius-counted");
        // Same table shape; counted publishes build counters, uncounted does not.
        let setup_plain = plain.setup_native();
        let setup_counted = counted.setup_native();
        assert!(
            setup_counted.get("canonicalisations").copied().unwrap_or(0) > 0,
            "counted path must publish table setup"
        );
        assert!(
            setup_plain.get("canonicalisations").copied().unwrap_or(0) == 0,
            "uncounted path must not republish table setup as native setup"
        );
        let mut hits = 0u32;
        for k in 1..200u64 {
            let mut ops_a = GroupOps::default();
            let mut ops_b = GroupOps::default();
            let mut ca = OracleCounters::default();
            let mut cb = OracleCounters::default();
            let point = g.mul(&mut GroupOps::default(), inst.generator, k);
            let a = plain.decompose(&ctx, &fb, &mut ops_a, &mut ca, point);
            let b = counted.decompose(&ctx, &fb, &mut ops_b, &mut cb, point);
            assert_eq!(a, b, "k={k}: counted/uncounted decomposition drift");
            // Probe charges must match: measurement tax is setup-only.
            assert_eq!(ops_a.adds, ops_b.adds, "k={k}: probe add drift");
            assert_eq!(ops_a.doubles, ops_b.doubles, "k={k}: probe double drift");
            if a.is_some() {
                hits += 1;
            }
        }
        assert!(
            hits > 0,
            "planted probes should hit the table at least once"
        );
    }

    #[test]
    fn cached_halftrace_factor_base_preserves_order_columns_and_coefficients() {
        let inst = koblitz_instance(1, 9).unwrap();
        let group = BinaryGroup(&inst.fast);
        let ctx = koblitz_ctx(&inst, &group);
        let builder = KoblitzOrbitBase { instance: &inst };
        let (_, baseline) = Params::parse_spec("koblitz-orbit:divisor=2").unwrap();
        let (_, candidate) =
            Params::parse_spec("koblitz-orbit:divisor=2,halftrace_tables=1").unwrap();
        let mut ops = GroupOps::default();
        let old = builder.build(&ctx, &baseline, &mut ops).unwrap();
        let new = builder.build(&ctx, &candidate, &mut ops).unwrap();
        assert_eq!(new.points, old.points);
        assert_eq!(new.col_of, old.col_of);
        assert_eq!(new.coef_of, old.coef_of);
        assert_eq!(new.columns, old.columns);
        let (_, invalid) =
            Params::parse_spec("koblitz-orbit:divisor=2,halftrace_tables=2").unwrap();
        assert!(builder.build(&ctx, &invalid, &mut ops).is_err());
    }

    /// Every relation the chained oracle returns re-sums to its target,
    /// every completed refusal agrees with exhaustive enumeration over
    /// the base, and the per-call trace accounts for every call.
    #[test]
    fn chained_x_relations_resum_and_refutations_match_enumeration() {
        let inst = koblitz_instance(1, 11).expect("registered n11 Koblitz instance");
        let g = BinaryGroup(&inst.fast);
        let ctx = koblitz_ctx(&inst, &g);
        let (_, base_params) = Params::parse_spec("binary-subspace:dimension=5").unwrap();
        let mut ops = GroupOps::default();
        let fb = BinarySubspaceBase { instance: &inst }
            .build(&ctx, &base_params, &mut ops)
            .unwrap();
        let fc = &inst.fast;
        for m in [2u32, 3] {
            let (_, params) =
                Params::parse_spec(&format!("chained-x:m={m},node_budget=4096,trace=1")).unwrap();
            let mut oracle = ChainedXOracle::new(m, &inst);
            oracle.prepare(&ctx, &fb, &params, &mut ops).unwrap();
            let mut counters = OracleCounters::default();
            let (mut found, mut refuted) = (0, 0);
            let mut target = inst.generator;
            for _ in 0..24 {
                target = fc.add(target, fc.add(inst.generator, target));
                let decomposes = match m {
                    2 => fb
                        .points
                        .iter()
                        .any(|&p| fb.index_of_key(fc.add(target, fc.neg(p)).pack()).is_some()),
                    _ => fb.points.iter().any(|&p| {
                        fb.points.iter().any(|&q| {
                            let rest = fc.add(fc.add(target, fc.neg(p)), fc.neg(q));
                            fb.index_of_key(rest.pack()).is_some()
                        })
                    }),
                };
                match oracle.decompose(&ctx, &fb, &mut ops, &mut counters, target) {
                    Some(idx) => {
                        assert_eq!(idx.len(), m as usize);
                        let sum = idx
                            .iter()
                            .fold(FastPoint::INFINITY, |s, &i| fc.add(s, fb.points[i]));
                        assert_eq!(sum, target, "m = {m}: relation does not re-sum");
                        found += 1;
                    }
                    None => {
                        let last = oracle.calls.last().unwrap();
                        if last.outcome == "refuted" {
                            assert!(!decomposes, "m = {m}: refuted a decomposable target");
                            refuted += 1;
                        }
                    }
                }
            }
            assert_eq!(oracle.calls.len(), 24);
            assert!(found > 0, "m = {m}: no relation in 24 targets");
            assert!(found + refuted > 12, "m = {m}: mostly budget-limited");
            let totals = oracle.solver_totals().unwrap();
            assert_eq!(totals.calls, 24);
            assert!(totals.ops > 0);
        }
    }

    /// The layout guard and the arity guard refuse in `prepare`, once.
    #[test]
    fn chained_x_refuses_bad_arity_and_oversize_layouts() {
        let inst = koblitz_instance(1, 11).expect("registered n11 Koblitz instance");
        let g = BinaryGroup(&inst.fast);
        let ctx = koblitz_ctx(&inst, &g);
        let mut ops = GroupOps::default();
        let (_, base_params) = Params::parse_spec("binary-subspace:dimension=5").unwrap();
        let fb = BinarySubspaceBase { instance: &inst }
            .build(&ctx, &base_params, &mut ops)
            .unwrap();
        let params = Params::default();
        let err = ChainedXOracle::new(5, &inst)
            .prepare(&ctx, &fb, &params, &mut ops)
            .unwrap_err();
        assert!(err.contains("m = 2, 3 or 4"), "{err}");
        assert_eq!(ChainedXOracle::layout_vars(4, 9, 17), 70);
        // n = 17, dimension 8, m = 4: 4·8 + 2·17 = 66 > 64.
        let inst13 = koblitz_instance(1, 17).expect("registered n17 Koblitz instance");
        let g13 = BinaryGroup(&inst13.fast);
        let ctx13 = koblitz_ctx(&inst13, &g13);
        let (_, big) = Params::parse_spec("binary-subspace:dimension=8").unwrap();
        let fb_big = BinarySubspaceBase { instance: &inst13 }
            .build(&ctx13, &big, &mut ops)
            .unwrap();
        let err = ChainedXOracle::new(4, &inst13)
            .prepare(&ctx13, &fb_big, &params, &mut ops)
            .unwrap_err();
        assert!(err.contains("66 unknowns"), "{err}");
    }

    /// Every point of a `cm-multiplier` base is `[coefficient]` times its
    /// column's seed (the first point of the column, weight 1), on `j = 0`
    /// (free automorphism) and `D = -7` (degree-2 Velu endomorphism), so every
    /// relation row over the base is a true logarithm identity.
    #[test]
    fn cm_multiplier_columns_are_scalar_multiples_of_their_seed() {
        use crate::cryptanalysis::glv_invariant_base::{generate_cm_instance, CmFamily};
        for (family, seed) in [(CmFamily::J0, 7u64), (CmFamily::D7, 31)] {
            let inst = generate_cm_instance(family, 24, seed, 8).unwrap();
            let curve = inst.curve.clone();
            let ctx = InstanceCtx {
                group: &curve,
                generator: inst.generator_point(),
                target: inst.generator_point(),
                r: inst.r,
                cofactor: inst.cofactor,
                group_order: inst.group_order,
                name: inst.name.clone(),
                field_degree: None,
            };
            let mut ops = GroupOps::default();
            let (_, params) = Params::parse_spec("cm-multiplier:size=5,norm=32").unwrap();
            let fb = CmMultiplierBase { instance: &inst }
                .build(&ctx, &params, &mut ops)
                .unwrap();
            assert_eq!(fb.columns, 5);
            assert!(
                fb.points.len() > 5 * 2 * 3,
                "multiples add points ({family:?})"
            );
            let mut seeds: Vec<Option<PrimePoint>> = vec![None; fb.columns];
            for (i, p) in fb.points.iter().enumerate() {
                if fb.coef_of[i] == 1 && seeds[fb.col_of[i]].is_none() {
                    seeds[fb.col_of[i]] = Some(*p);
                }
            }
            let mut check = GroupOps::default();
            for (i, p) in fb.points.iter().enumerate() {
                let seed = seeds[fb.col_of[i]].expect("every column has a weight-1 seed");
                assert_eq!(
                    curve.mul(&mut check, seed, fb.coef_of[i]),
                    *p,
                    "{family:?} point {i}"
                );
            }
        }
    }

    /// The relation-solving ablation changes only the column map. Point
    /// construction, duplicate filtering, order, indexes and group-operation
    /// ledger stay identical, so a matrix-width comparison cannot hide a
    /// larger table or cheaper precomputation in one arm.
    #[test]
    fn cm_multiplier_column_modes_share_exact_vertices_and_build_ops() {
        use crate::cryptanalysis::glv_invariant_base::{generate_cm_instance, CmFamily};

        let inst = generate_cm_instance(CmFamily::J0, 24, 71, 8).unwrap();
        let curve = inst.curve.clone();
        let ctx = InstanceCtx {
            group: &curve,
            generator: inst.generator_point(),
            target: inst.generator_point(),
            r: inst.r,
            cofactor: inst.cofactor,
            group_order: inst.group_order,
            name: inst.name.clone(),
            field_degree: None,
        };
        let build = |mode: &str| {
            let (_, params) = Params::parse_spec(&format!(
                "cm-multiplier:size=4,norm=0,mult=8,column_mode={mode}"
            ))
            .unwrap();
            let mut ops = GroupOps::default();
            let fb = CmMultiplierBase { instance: &inst }
                .build(&ctx, &params, &mut ops)
                .unwrap();
            (fb, ops)
        };
        let (weighted, weighted_ops) = build("weighted");
        let (independent, independent_ops) = build("independent");

        assert_eq!(weighted.points, independent.points);
        assert_eq!(weighted.neg_index, independent.neg_index);
        assert_eq!(weighted.abscissa_list, independent.abscissa_list);
        assert_eq!(weighted_ops, independent_ops);
        assert_eq!(weighted.columns, 4);
        assert_eq!(independent.columns, independent.points.len() / 2);
        assert_eq!(
            weighted.cost.get("multiplier_progression_adds"),
            independent.cost.get("multiplier_progression_adds")
        );
        assert_eq!(weighted.cost.get("multiplier_independent_columns"), 0);
        assert_eq!(independent.cost.get("multiplier_independent_columns"), 1);
        for i in 0..independent.points.len() {
            let coefficient = independent.coef_of[i];
            assert!(coefficient == 1 || coefficient == inst.r - 1);
        }
    }

    /// A PKM auxiliary tower can select the seed points, but it receives no
    /// free setup: its search/build counters remain in the composed base. The
    /// weighted and independent arms still materialise exactly the same table.
    #[test]
    fn cm_multiplier_isogeny_seed_source_is_charged_and_exactly_controlled() {
        use crate::cryptanalysis::ic_boundary::prime_instance_for;

        let mut accepted = None;
        for curve_seed in 1..=32 {
            let inst = prime_instance_for(18, curve_seed);
            let curve = inst.curve.clone();
            let ctx = InstanceCtx {
                group: &curve,
                generator: inst.generator_point(),
                target: inst.generator_point(),
                r: inst.r,
                cofactor: inst.cofactor,
                group_order: inst.group_order,
                name: inst.name.clone(),
                field_degree: None,
            };
            let build = |mode: &str| {
                let (_, params) = Params::parse_spec(&format!(
                    "cm-multiplier:size=2,norm=0,mult=4,column_mode={mode},seed_source=isogeny,aux_t=3,aux_seed=9,aux=ordinary"
                ))
                .unwrap();
                let mut ops = GroupOps::default();
                CmMultiplierBase { instance: &inst }
                    .build(&ctx, &params, &mut ops)
                    .map(|fb| (fb, ops))
            };
            if let (Ok(weighted), Ok(independent)) = (build("weighted"), build("independent")) {
                accepted = Some((weighted, independent));
                break;
            }
        }
        let ((weighted, weighted_ops), (independent, independent_ops)) =
            accepted.expect("one deterministic 18-bit fixture admits two projected tower seeds");
        assert_eq!(weighted.points, independent.points);
        assert_eq!(weighted_ops, independent_ops);
        assert_eq!(weighted.cost.get("multiplier_seeds"), 2);
        assert!(weighted.cost.get("aux_curves_tried") > 0);
        assert!(weighted.cost.get("aux_tower_build_gae") > 0);
        assert_eq!(
            weighted.cost.get("aux_curves_tried"),
            independent.cost.get("aux_curves_tried")
        );
        assert_eq!(weighted.columns, 2);
        assert_eq!(independent.columns, independent.points.len() / 2);
    }

    /// Every point of a `binary-multiplier` base is `[coefficient]` times
    /// its column's seed (the weight-1 point), so each relation row over the
    /// base is a true logarithm identity on a curve with no endomorphism use.
    #[test]
    fn binary_multiplier_columns_are_scalar_multiples_of_their_seed() {
        let inst = koblitz_instance(1, 9).expect("registered n9 Koblitz instance");
        let group = BinaryGroup(&inst.fast);
        let ctx = InstanceCtx {
            group: &group,
            generator: inst.generator,
            target: inst.generator,
            r: inst.r,
            cofactor: inst.cofactor,
            group_order: inst.group_order,
            name: inst.name.clone(),
            field_degree: Some(inst.n),
        };
        let mut ops = GroupOps::default();
        let (_, params) = Params::parse_spec("binary-multiplier:size=3,mult=6").unwrap();
        let fb = BinaryMultiplierBase { instance: &inst }
            .build(&ctx, &params, &mut ops)
            .unwrap();
        assert_eq!(fb.columns, 3);
        assert!(fb.points.len() > 3 * 2, "multiples add points");
        let mut seeds: Vec<Option<FastPoint>> = vec![None; fb.columns];
        for (i, p) in fb.points.iter().enumerate() {
            if fb.coef_of[i] == 1 && seeds[fb.col_of[i]].is_none() {
                seeds[fb.col_of[i]] = Some(*p);
            }
        }
        let mut check = GroupOps::default();
        for (i, p) in fb.points.iter().enumerate() {
            let seed = seeds[fb.col_of[i]].expect("weight-1 seed per column");
            assert_eq!(group.mul(&mut check, seed, fb.coef_of[i]), *p, "point {i}");
        }
    }

    #[test]
    fn trace_zero_factor_base_is_an_executable_policy() {
        let inst = koblitz_instance(1, 9).expect("registered n9 Koblitz instance");
        let group = BinaryGroup(&inst.fast);
        let ctx = InstanceCtx {
            group: &group,
            generator: inst.generator,
            target: inst.generator,
            r: inst.r,
            cofactor: inst.cofactor,
            group_order: inst.group_order,
            name: inst.name.clone(),
            field_degree: Some(inst.n),
        };
        let mut ops = GroupOps::default();
        let (_, trace_zero) = Params::parse_spec("koblitz-trace-zero:divisor=1").unwrap();
        let base = KoblitzTraceZeroBase { instance: &inst }
            .build(&ctx, &trace_zero, &mut ops)
            .expect("a divisor omitting x + 1 is trace-zero");
        assert!(base.columns > 0);

        let (_, trace_one) = Params::parse_spec("koblitz-trace-zero:divisor=0").unwrap();
        let error =
            match (KoblitzTraceZeroBase { instance: &inst }).build(&ctx, &trace_one, &mut ops) {
                Err(error) => error,
                Ok(_) => panic!("a divisor containing x + 1 must be rejected"),
            };
        assert!(error.contains("not trace-zero"), "{error}");
    }

    /// Freeze the entire producer support, not merely its size or first
    /// representative. This is the preregistered gate before fresh Q.
    #[test]
    fn compact_orbit_scan_matches_archived_n37_source42() {
        let inst = koblitz_instance(0, 37).expect("registered n37 Koblitz instance");
        let g = BinaryGroup(&inst.fast);
        let ctx = InstanceCtx {
            group: &g,
            generator: inst.generator,
            target: inst.generator,
            r: inst.r,
            cofactor: inst.cofactor,
            group_order: inst.group_order,
            name: inst.name.clone(),
            field_degree: Some(inst.n),
        };
        let (_, params) =
            Params::parse_spec("compact-orbit-scan:columns=42,raw_x_cap=1000000").unwrap();
        let mut ops = GroupOps::default();
        let fb = CompactOrbitScanBase { instance: &inst }
            .build(&ctx, &params, &mut ops)
            .unwrap();
        let source = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/research/notes/ecc2k130/n37_four_policy_support_20261003/SOURCE42.jsonl"
        ))
        .unwrap();
        let frozen: serde_json::Value =
            serde_json::from_str(source.lines().next().unwrap()).unwrap();
        let coordinates: Vec<[u64; 2]> =
            serde_json::from_value(frozen["factor_base_point_coordinates"].clone()).unwrap();
        let labels: Vec<[u64; 2]> =
            serde_json::from_value(frozen["factor_base_point_labels"].clone()).unwrap();
        let representatives: Vec<[u64; 2]> =
            serde_json::from_value(frozen["factor_base_representatives"].clone()).unwrap();
        assert_eq!(fb.columns, 42);
        assert_eq!(fb.points.len(), 3108);
        assert_eq!(coordinates.len(), fb.points.len());
        assert_eq!(labels.len(), fb.points.len());
        assert_eq!(representatives.len(), fb.columns);
        for (i, p) in fb.points.iter().enumerate() {
            assert_eq!([p.x, p.y], coordinates[i], "point {i}");
            assert_eq!([fb.col_of[i] as u64, fb.coef_of[i]], labels[i], "label {i}");
        }
        for (column, rep) in representatives.iter().enumerate() {
            let p = fb.points[column * 2 * inst.n as usize];
            assert_eq!([p.x, p.y], *rep, "representative {column}");
        }
        let mut base_hash = blake3::Hasher::new();
        base_hash.update(b"compact-orbit-constructed-base-v1");
        for (i, p) in fb.points.iter().enumerate() {
            for word in [p.x, p.y, fb.col_of[i] as u64, fb.coef_of[i]] {
                base_hash.update(&word.to_le_bytes());
            }
        }
        assert_eq!(
            base_hash.finalize().to_hex().as_str(),
            frozen["base_hash"].as_str().unwrap()
        );
        assert_eq!(
            frozen["base_hash"].as_str().unwrap(),
            "8423b135df3515b0e284126d9eeb95f71e3901ae12908b3cad8eb03d1f31d4bc"
        );
        assert!(ops.scalar_mults > 0 && fb.cost.get("inversions") > 0);
        assert!(fb.cost.get("min_key_field_squares_uncharged") > 0);
    }
}

#[cfg(test)]
mod explicit_subspace_tests {
    use super::*;
    #[test]
    fn explicit_basis_preserves_the_legacy_points_and_rejects_bad_bases() {
        let inst = crate::cryptanalysis::ic_boundary::koblitz_instance(1, 7).unwrap();
        let g = BinaryGroup(&inst.fast);
        let ctx = InstanceCtx {
            group: &g,
            generator: inst.generator,
            target: inst.generator,
            r: inst.r,
            cofactor: inst.cofactor,
            group_order: inst.group_order,
            name: inst.name.clone(),
            field_degree: Some(inst.n),
        };
        let builder = BinarySubspaceBase { instance: &inst };
        let (_, plain) = Params::parse_spec("binary-subspace:dimension=3").unwrap();
        let (_, explicit) =
            Params::parse_spec("binary-subspace:dimension=3,basis=0x1;0x2;0x4").unwrap();
        let a = builder
            .build(&ctx, &plain, &mut GroupOps::default())
            .unwrap();
        let b = builder
            .build(&ctx, &explicit, &mut GroupOps::default())
            .unwrap();
        assert_eq!(a.points, b.points);
        assert_eq!(a.col_of, b.col_of);
        assert_eq!(a.coef_of, b.coef_of);
        assert_eq!(a.subspace_basis, b.subspace_basis);
        for recipe in [
            "binary-subspace:dimension=3,basis=1;2;3",
            "binary-subspace:dimension=3,basis=1;2",
            "binary-subspace:dimension=3,basis=1;2;128",
            "binary-subspace:dimension=3,basis=1;2;0",
            "binary-subspace:dimension=3,basis=1;2;2",
            "binary-subspace:dimension=3,basis=1;2;",
            "binary-subspace:dimension=3,basis=1;2;0xg",
            "binary-subspace:dimension=3,basis=1;2;4,select=strict4e",
            "binary-subspace:dimension=3,basis=1;2;4,select=gated-rank",
            "binary-subspace:dimension=4294967299,basis=1;2;4",
            "binary-subspace:dimension=4294967299",
            "binary-subspace:dimension=0,basis=1",
            "binary-subspace:dimension=31,basis=1",
            "binary-subspace:dimension=18446744073709551615,basis=1",
        ] {
            let (_, bad) = Params::parse_spec(recipe).unwrap();
            assert!(
                builder.build(&ctx, &bad, &mut GroupOps::default()).is_err(),
                "accepted invalid recipe: {recipe}"
            );
        }
    }
}

/// Why `wsum` with `targets=stride-generator` meets dependent rows that
/// `targets=walk` does not: the hits of the progression `R_k = Q + [k]G`
/// are not independent box entries.  Whenever a short seed relation
/// `w·S = [m]G` holds (`w` a difference of two box points, `m` a small
/// integer, here found by the test and not assumed), `R_k = T_e` gives
/// `R_{k+m} = T_{e+w}`: the hit repeats `m` steps later, on the line
/// `e + t·w`, with `b = 1` in every row.  Rows `(e, −1 | k)` on one line
/// are rank 2.  A walk row carries a random `b`, which breaks the line.
/// The dependence is arithmetic, not a row-handling defect.
#[cfg(test)]
mod wsum_stride_dependence_tests {
    use super::*;
    use crate::cryptanalysis::ic_boundary::{
        Calibration, CountedGroup, PrimeCurve, PrimeInstance, PrimePoint, WSumTable,
    };
    use crate::cryptanalysis::ic_framework::stages::Targets;
    use crate::cryptanalysis::ic_framework::{run_pipeline, PipelineSpec};

    /// The `train-k32` curve of the round-28 session: `r = 536884639`,
    /// cofactor 8, `log2 r = 29`.
    fn instance() -> PrimeInstance {
        PrimeInstance {
            name: "train-k32".into(),
            curve: PrimeCurve {
                p: 4294967197,
                a: 1173263412,
                b: 337904346,
            },
            group_order: 4295077112,
            r: 536884639,
            cofactor: 8,
            generator: (1431665017, 592057774),

            representation: None,
        }
    }

    fn ctx<'a>(inst: &'a PrimeInstance, q: PrimePoint) -> InstanceCtx<'a, PrimeCurve> {
        InstanceCtx {
            group: &inst.curve,
            generator: inst.generator_point(),
            target: q,
            r: inst.r,
            cofactor: inst.cofactor,
            group_order: inst.group_order,
            name: inst.name.clone(),
            field_degree: None,
        }
    }

    fn base_params() -> Params {
        Params::parse_spec("prime-projected-abscissa:size=2,scan_cap=32")
            .unwrap()
            .1
    }

    fn dependent_runs(inst: &PrimeInstance, targets: Targets, runs: u64) -> (u64, u64) {
        let (mut dependent, mut found) = (0, 0);
        for s in 0..runs {
            let mut ops = GroupOps::default();
            let q = inst
                .curve
                .mul(&mut ops, inst.generator_point(), 12345 + 7919 * s);
            let spec = PipelineSpec {
                factor_base: "prime-projected-abscissa".into(),
                factor_base_params: base_params(),
                oracle: "wsum".into(),
                oracle_params: Params::parse_spec("wsum:coef=120,free=1").unwrap().1,
                targets,
                linalg: "incremental-gauss".into(),
                max_trials: 5_000_000,
                seed: s,
                ..Default::default()
            };
            let rep = run_pipeline(
                &ctx(inst, q),
                &spec,
                &PrimeProjectedAbscissaBase { instance: inst },
                &mut WSumOracle::<PrimePoint>::new(),
                u64::MAX,
                &Calibration {
                    ns_per_add: 1.0,
                    ns_per_double: 1.0,
                    ..Default::default()
                },
                None,
            )
            .unwrap();
            dependent += u64::from(rep.linear_algebra.dependent > 0);
            found += rep.decomposition.relations_found;
        }
        (dependent, found)
    }

    #[test]
    fn stride_generator_hits_repeat_along_a_short_seed_relation() {
        let inst = instance();
        let g = &inst.curve;
        let gen = inst.generator_point();
        let mut ops = GroupOps::default();
        let mut build_ctx_ops = GroupOps::default();
        let fb = PrimeProjectedAbscissaBase { instance: &inst }
            .build(&ctx(&inst, gen), &base_params(), &mut build_ctx_ops)
            .unwrap();
        let table = WSumTable::build(g, &fb, 120, true).unwrap();

        // Hits of Q + [k]G: (k, e) with e·S = R_k, four hits per target.
        let mut runs: Vec<Vec<(u64, Vec<i64>)>> = Vec::new();
        for s in 0..12u64 {
            let q = g.mul(&mut ops, gen, 12345 + 7919 * s);
            let (mut hits, mut point, mut lookups) = (Vec::new(), q, 0u64);
            for k in 0..400_000u64 {
                if k > 0 {
                    point = g.add(&mut ops, point, gen);
                }
                if g.is_identity(&point) {
                    continue;
                }
                if let Some(summands) = table.probe(g, &fb, &mut ops, &mut lookups, point) {
                    // Recover e from the signed summands: +1 per seed
                    // index, −1 per negated one (seeds sit at even index).
                    let mut e = vec![0i64; table.c];
                    for i in summands {
                        e[fb.col_of[i]] += if i % 2 == 0 { 1 } else { -1 };
                    }
                    hits.push((k, e));
                    if hits.len() == 4 {
                        break;
                    }
                }
            }
            runs.push(hits);
        }

        // Every pair of hits obeys (e' − e)·S = [k' − k]G, by group
        // arithmetic, with no logarithm known.
        let seeds = |e: &[i64], ops: &mut GroupOps| {
            let mut acc = g.identity();
            for (c, &ec) in e.iter().enumerate() {
                let p = fb.points[fb.col_of.iter().position(|&x| x == c).unwrap()];
                let t = g.mul(ops, p, ec.unsigned_abs());
                acc = g.add(ops, acc, if ec < 0 { g.neg(t) } else { t });
            }
            acc
        };
        let mut progressions = 0;
        for hits in &runs {
            for i in 0..hits.len() {
                for j in i + 1..hits.len() {
                    let (ki, ei) = &hits[i];
                    let (kj, ej) = &hits[j];
                    let w: Vec<i64> = ei.iter().zip(ej).map(|(a, b)| b - a).collect();
                    let lhs = seeds(&w, &mut ops);
                    let rhs = g.mul(&mut ops, gen, kj - ki);
                    assert_eq!(lhs, rhs, "(e'−e)·S = [Δk]G must hold");
                }
            }
            // A progression: three hits k, k+m, k+2m on the line e + t·w.
            for i in 0..hits.len().saturating_sub(2) {
                let ((k0, e0), (k1, e1), (k2, e2)) = (&hits[i], &hits[i + 1], &hits[i + 2]);
                if k1 - k0 == k2 - k1 {
                    let w0: Vec<i64> = e0.iter().zip(e1).map(|(a, b)| b - a).collect();
                    let w1: Vec<i64> = e1.iter().zip(e2).map(|(a, b)| b - a).collect();
                    assert_eq!(w0, w1, "equal Δk, equal Δe: the hits are collinear");
                    // The relation both rows reveal: w·S = [m]G, m small.
                    eprintln!("progression m={} w={:?} e0={:?}", k1 - k0, w0, e0);
                    progressions += 1;
                }
            }
        }
        for (s, hits) in runs.iter().enumerate() {
            let rows: Vec<String> = hits
                .iter()
                .map(|(k, e)| format!("(e1,e2,a,b)=({},{},{},1)", e[0], e[1], k))
                .collect();
            eprintln!("target {s}: {}", rows.join(" "));
        }
        assert!(
            progressions > 0,
            "the curve's seeds have a short relation w·S = [m]G, so some target has a progression"
        );
    }

    #[test]
    fn stride_generator_runs_are_dependent_and_walk_runs_are_not() {
        let inst = instance();
        let (walk_dep, walk_found) = dependent_runs(&inst, Targets::Walk, 8);
        let (stride_dep, stride_found) = dependent_runs(&inst, Targets::StrideGenerator, 8);
        eprintln!("walk: dependent runs {walk_dep}/8, relations {walk_found}");
        eprintln!("stride-generator: dependent runs {stride_dep}/8, relations {stride_found}");
        assert_eq!(walk_dep, 0, "random (a, b) rows are independent");
        assert_eq!(walk_found, 8 * 3);
        assert!(stride_dep >= 1, "progression rows are collinear");
        assert!(stride_found > walk_found);
    }
}

/// `wwalk` end to end on the `train-k32` curve: the planted logarithm is
/// recovered with walk targets and with stride-generator targets, the
/// free rows hold, and the fraction of bases with a verified free row is
/// reported against the proposal's `1 − exp(−x²)`.
#[cfg(test)]
mod wwalk_pipeline_tests {
    use super::*;
    use crate::cryptanalysis::ic_boundary::{Calibration, PrimeCurve, PrimeInstance, PrimePoint};
    use crate::cryptanalysis::ic_framework::stages::Targets;
    use crate::cryptanalysis::ic_framework::{run_pipeline, PipelineSpec};

    fn instance() -> PrimeInstance {
        PrimeInstance {
            name: "train-k32".into(),
            curve: PrimeCurve {
                p: 4294967197,
                a: 1173263412,
                b: 337904346,
            },
            group_order: 4295077112,
            r: 536884639,
            cofactor: 8,
            generator: (1431665017, 592057774),

            representation: None,
        }
    }

    fn ctx<'a>(inst: &'a PrimeInstance, q: PrimePoint) -> InstanceCtx<'a, PrimeCurve> {
        InstanceCtx {
            group: &inst.curve,
            generator: inst.generator_point(),
            target: q,
            r: inst.r,
            cofactor: inst.cofactor,
            group_order: inst.group_order,
            name: inst.name.clone(),
            field_degree: None,
        }
    }

    fn base_params(scan: u64) -> Params {
        Params::parse_spec(&format!("prime-projected-abscissa:size=2,scan_cap={scan}"))
            .unwrap()
            .1
    }

    /// One run: (verified, free rows emitted, probe hits, steps grown).
    /// The oracle's own seed is `s`, so every run walks another path over
    /// the same two seeds.
    fn run(inst: &PrimeInstance, targets: Targets, spec: &str, s: u64) -> (bool, u64, u64, u64) {
        let planted = 12345 + 7919 * s;
        let mut ops = GroupOps::default();
        let q = inst.curve.mul(&mut ops, inst.generator_point(), planted);
        let (name, oracle_params) = Params::parse_spec(&format!("{spec},seed={s}")).unwrap();
        let ps = PipelineSpec {
            factor_base: "prime-projected-abscissa".into(),
            factor_base_params: base_params(32),
            oracle: name,
            oracle_params,
            targets,
            linalg: "incremental-gauss".into(),
            max_trials: 5_000_000,
            seed: s,
            ..Default::default()
        };
        let mut oracle = WWalkOracle::<PrimePoint>::new();
        let rep = run_pipeline(
            &ctx(inst, q),
            &ps,
            &PrimeProjectedAbscissaBase { instance: inst },
            &mut oracle,
            planted,
            &Calibration {
                ns_per_add: 1.0,
                ns_per_double: 1.0,
                ..Default::default()
            },
            None,
        )
        .unwrap();
        let ctr = DecompositionOracle::<PrimeCurve>::relation_counters(&oracle);
        (
            rep.verified && rep.recovered == Some(planted),
            ctr["free_rows_emitted"],
            ctr["probe_hits"],
            oracle.table().unwrap().grown_steps,
        )
    }

    #[test]
    fn wwalk_recovers_the_planted_log_with_walk_and_stride_targets() {
        let inst = instance();
        for (targets, label) in [
            (Targets::Walk, "walk"),
            (Targets::StrideGenerator, "stride-generator"),
        ] {
            for spec in ["wwalk:x=1.2", "wwalk:x=0.6", "wwalk:x=0.6,grow=1"] {
                let (mut ok, mut rows, mut hits, mut grown, mut no_row) = (0, 0, 0, 0, 0);
                let n = 16;
                for s in 0..n {
                    let (verified, free, probe_hits, g) = run(&inst, targets, spec, s);
                    assert!(verified, "{label} {spec} s={s}: planted log not recovered");
                    ok += 1;
                    rows += free;
                    hits += probe_hits;
                    grown += u64::from(g > 0);
                    no_row += u64::from(free == 0);
                    // With a free row two hits pin the log; without, three.
                    assert!(
                        probe_hits >= if free > 0 { 2 } else { 3 },
                        "{label} {spec} s={s}: {probe_hits} hits with {free} free rows"
                    );
                }
                eprintln!(
                    "{label} {spec}: recovered {ok}/{n}, runs without a free row {no_row}, \
                     free rows {rows}, mean hits {:.2}, runs that grew {grown}",
                    hits as f64 / n as f64
                );
                assert_eq!(ok, n);
                if spec.contains("grow") {
                    assert!(grown > 0, "{label}: growth never exercised");
                } else if spec.contains("0.6") {
                    assert!(no_row > 0, "{label}: the no-free-row path never exercised");
                }
            }
        }
    }

    /// One run in full: the report beside the oracle's counters.
    struct Full {
        verified: bool,
        free_rows: u64,
        hits: u64,
        rows_used: u64,
        steps: u64,
        t: u64,
        rank2: bool,
        gae: f64,
        setup_gae: f64,
        s: f64,
    }

    fn run_full(inst: &PrimeInstance, targets: Targets, spec: &str, s: u64) -> Full {
        let planted = 12345 + 7919 * s;
        let mut ops = GroupOps::default();
        let q = inst.curve.mul(&mut ops, inst.generator_point(), planted);
        let (name, oracle_params) = Params::parse_spec(&format!("{spec},seed={s}")).unwrap();
        let ps = PipelineSpec {
            factor_base: "prime-projected-abscissa".into(),
            factor_base_params: base_params(32),
            oracle: name,
            oracle_params,
            targets,
            linalg: "incremental-gauss".into(),
            max_trials: 5_000_000,
            seed: s,
            ..Default::default()
        };
        let mut oracle = WWalkOracle::<PrimePoint>::new();
        let rep = run_pipeline(
            &ctx(inst, q),
            &ps,
            &PrimeProjectedAbscissaBase { instance: inst },
            &mut oracle,
            planted,
            &Calibration {
                ns_per_add: 1.0,
                ns_per_double: 1.0,
                ..Default::default()
            },
            None,
        )
        .unwrap();
        let ctr = DecompositionOracle::<PrimeCurve>::relation_counters(&oracle);
        let table = oracle.table().unwrap();
        Full {
            verified: rep.verified && rep.recovered == Some(planted),
            free_rows: ctr["free_rows_emitted"],
            hits: ctr["probe_hits"],
            rows_used: rep.linear_algebra.rows,
            steps: table.steps,
            t: table.t,
            rank2: table.seed_rank(inst.r) == 2,
            gae: rep.total_gae,
            setup_gae: rep.decomposition.setup.gae,
            s: rep.s,
        }
    }

    /// `g=1,grow=2`: both seed logs are pinned by the free rows, so one
    /// probe hit solves the target, with walk and stride-generator targets.
    /// A row `Relation::Row { a != 0, b: 0 }` is read by the loop as
    /// `Σ coef·x = h·a`, which this recovery (cofactor 8) confirms.
    #[test]
    fn wwalk_g_grow2_recovers_with_one_probe_hit() {
        let inst = instance();
        for (targets, label) in [
            (Targets::Walk, "walk"),
            (Targets::StrideGenerator, "stride-generator"),
        ] {
            let (mut rank2, mut hits1, n) = (0, 0, 16);
            for s in 0..n {
                let f = run_full(&inst, targets, "wwalk:x=1.0,g=1,grow=2", s);
                assert!(f.verified, "{label} s={s}: planted log not recovered");
                if f.rank2 {
                    rank2 += 1;
                    assert_eq!(f.hits, 1, "{label} s={s}: rank-2 rows, {} hits", f.hits);
                    assert!(f.free_rows >= 2);
                    hits1 += 1;
                } else {
                    // Capped at 3T below rank 2: more hits needed.
                    assert_eq!(f.steps, 3 * f.t);
                    assert!(f.hits >= 2, "{label} s={s}: {} hits", f.hits);
                }
            }
            eprintln!("{label} wwalk:x=1.0,g=1,grow=2: rank-2 tables {rank2}/{n}, solved by one hit {hits1}");
            assert!(rank2 >= n / 2);
        }
    }

    /// The trend before an ecbench round: `g=0,grow=1` against
    /// `g=1,grow=2`, 16 runs each at x in {0.8, 1.0, 1.2}.
    #[test]
    fn wwalk_g_trend_report() {
        let inst = instance();
        let sqrt_r = (inst.r as f64).sqrt();
        let n = 16u64;
        eprintln!("spec | mean rows used | mean hits | mean steps/sqrt(r) | mean GAE | mean build GAE | S=GAE/sqrt(r)");
        for x in ["0.8", "1.0", "1.2"] {
            for spec in [
                format!("wwalk:x={x},grow=1"),
                format!("wwalk:x={x},g=1,grow=2"),
            ] {
                let (mut rows, mut hits, mut steps, mut gae, mut setup, mut s_sum) =
                    (0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
                for s in 0..n {
                    let f = run_full(&inst, Targets::Walk, &spec, s);
                    assert!(f.verified, "{spec} s={s}");
                    rows += f.rows_used as f64;
                    hits += f.hits as f64;
                    steps += f.steps as f64 / sqrt_r;
                    gae += f.gae;
                    setup += f.setup_gae;
                    s_sum += f.s;
                }
                let n = n as f64;
                eprintln!(
                    "{spec} | {:.2} | {:.2} | {:.3} | {:.0} | {:.0} | {:.3}",
                    rows / n,
                    hits / n,
                    steps / n,
                    gae / n,
                    setup / n,
                    s_sum / n
                );
            }
        }
    }

    #[test]
    fn wwalk_free_row_fraction_against_the_proposal() {
        use crate::cryptanalysis::ic_boundary::WalkTable;
        let inst = instance();
        let g = &inst.curve;
        let mut cap_ops = GroupOps::default();
        let fb = PrimeProjectedAbscissaBase { instance: &inst }
            .build(
                &ctx(&inst, inst.generator_point()),
                &base_params(32),
                &mut cap_ops,
            )
            .unwrap();
        for x in [0.6f64, 1.2] {
            let (mut bases, mut with_row, mut rows) = (0u64, 0u64, 0u64);
            for s in 0..300u64 {
                // The same two seeds, another walk (jumps and steps) each time.
                let t = WalkTable::build(g, &fb, inst.r, x, 16, false, s).unwrap();
                bases += 1;
                with_row += u64::from(!t.rows.is_empty());
                rows += t.rows.len() as u64;
                // Every row holds as a group equation: recompute the
                // collision from scratch is done inside `build`; here, the
                // count must agree with the verified collisions.
                assert_eq!(t.rows.len() as u64 + t.zero_rows, t.verified_collisions);
            }
            let pred = 1.0 - (-x * x).exp();
            // The grown walk from the same x0: how far it goes to a row.
            let (mut g_rows, mut g_steps) = (0u64, 0u64);
            for s in 0..300u64 {
                let t = WalkTable::build(g, &fb, inst.r, x, 16, true, s).unwrap();
                g_rows += u64::from(!t.rows.is_empty());
                g_steps += t.steps;
            }
            eprintln!(
                "x0={x} grow: fraction with a row {:.3} (cap 2x0), mean steps/T0 {:.3}",
                g_rows as f64 / 300.0,
                g_steps as f64 / 300.0 / (x * (inst.r as f64).sqrt()).round()
            );
            eprintln!(
                "x={x}: walks {bases} over one seed pair, fraction with a verified free row {:.3} (prediction 1-exp(-x^2) = {pred:.3}), mean rows {:.3} (x^2 = {:.3})",
                with_row as f64 / bases as f64,
                rows as f64 / bases as f64,
                x * x
            );
        }
    }

    /// `tw=1` (target in the walk, one-seed base) end to end on
    /// `train-k32`, plain and chained jumps (`cj=1`): the planted log is
    /// recovered with stride-generator targets; a walk that reached rank 2
    /// solves on the first trial with no probe; the ledger breakdown sums to
    /// the oracle set-up; the chained jumps cost fewer set-up additions; and
    /// the option refusals hold.
    #[test]
    fn wwalk_target_in_walk_recovers_on_the_first_trial() {
        let inst = instance();
        let one = Params::parse_spec("prime-projected-abscissa:size=1,scan_cap=32")
            .unwrap()
            .1;
        let run_tw = |spec: &str, s: u64| {
            let planted = 12345 + 7919 * s;
            let mut ops = GroupOps::default();
            let q = inst.curve.mul(&mut ops, inst.generator_point(), planted);
            let (name, oracle_params) = Params::parse_spec(&format!("{spec},seed={s}")).unwrap();
            let ps = PipelineSpec {
                factor_base: "prime-projected-abscissa".into(),
                factor_base_params: one.clone(),
                oracle: name,
                oracle_params,
                targets: Targets::StrideGenerator,
                linalg: "incremental-gauss".into(),
                max_trials: 5_000_000,
                seed: s,
                ..Default::default()
            };
            let mut oracle = WWalkOracle::<PrimePoint>::new();
            let rep = run_pipeline(
                &ctx(&inst, q),
                &ps,
                &PrimeProjectedAbscissaBase { instance: &inst },
                &mut oracle,
                planted,
                &Calibration {
                    ns_per_add: 1.0,
                    ns_per_double: 1.0,
                    ..Default::default()
                },
                None,
            )
            .unwrap();
            let ctr = DecompositionOracle::<PrimeCurve>::relation_counters(&oracle);
            assert!(oracle.table().is_none(), "tw=1 builds no WalkTable");
            let walk = oracle.target_walk().expect("tw=1 builds a TargetWalk");
            let mut sum = walk.setup_ops;
            sum.merge(walk.walk_ops);
            sum.merge(walk.verify_ops);
            assert_eq!(
                sum.gae(),
                rep.decomposition.setup.gae,
                "{spec} s={s}: ledgers"
            );
            assert_eq!(ctr["tw_walk_adds"], walk.steps);
            (
                rep.verified && rep.recovered == Some(planted),
                ctr["tw_rank"],
                ctr["probe_hits"],
                rep.decomposition.targets_tried,
                walk.setup_ops.adds,
                walk.steps as f64 / (inst.r as f64).sqrt(),
            )
        };
        let n = 12u64;
        let mut setup_adds = [0u64; 2];
        for (i, spec) in [
            "wwalk:x=1.5,g=1,grow=2,tw=1",
            "wwalk:x=1.5,g=1,grow=2,tw=1,cj=1",
        ]
        .into_iter()
        .enumerate()
        {
            let mut steps = 0.0;
            for s in 0..n {
                let (ok, rank, hits, trials, adds, st) = run_tw(spec, s);
                assert!(ok, "{spec} s={s}: planted log not recovered");
                if rank == 2 {
                    assert_eq!(hits, 0, "{spec} s={s}: rank 2 needs no probe");
                    assert_eq!(trials, 1, "{spec} s={s}: rank 2 solves on trial 1");
                }
                setup_adds[i] += adds;
                steps += st;
            }
            eprintln!(
                "{spec}: recovered {n}/{n}, mean walk steps {:.3} sqrt(r), mean set-up adds {:.1}",
                steps / n as f64,
                setup_adds[i] as f64 / n as f64
            );
        }
        assert!(
            setup_adds[1] * 2 < setup_adds[0],
            "chained jumps should at least halve the set-up additions: {setup_adds:?}"
        );
        // Refusals: tw without g or grow=2, cj without tw, tw on two seeds.
        let mut ops = GroupOps::default();
        let q = inst.curve.mul(&mut ops, inst.generator_point(), 777);
        let fb1 = PrimeProjectedAbscissaBase { instance: &inst }
            .build(&ctx(&inst, q), &one, &mut ops)
            .unwrap();
        let fb2 = PrimeProjectedAbscissaBase { instance: &inst }
            .build(&ctx(&inst, q), &base_params(32), &mut ops)
            .unwrap();
        for (fb, spec, needle) in [
            (&fb1, "wwalk:x=1.5,grow=2,tw=1", "tw=1 needs g=1 and grow=2"),
            (
                &fb1,
                "wwalk:x=1.5,g=1,grow=1,tw=1",
                "tw=1 needs g=1 and grow=2",
            ),
            (&fb1, "wwalk:x=1.5,g=1,grow=2,cj=1", "cj=1 needs tw=1"),
            (&fb2, "wwalk:x=1.5,g=1,grow=2,tw=1", "exactly 1 abscissa"),
        ] {
            let (_, params) = Params::parse_spec(spec).unwrap();
            let mut oracle = WWalkOracle::<PrimePoint>::new();
            let err = DecompositionOracle::<PrimeCurve>::prepare(
                &mut oracle,
                &ctx(&inst, q),
                fb,
                &params,
                &mut ops,
            )
            .unwrap_err();
            assert!(err.contains(needle), "{spec}: {err}");
        }
    }

    /// What one pipeline run of a `wwalk` spec leaves, for the pairings
    /// below.
    struct Pair {
        verified: bool,
        gae: f64,
        verify_gae: f64,
        ctr: BTreeMap<String, u64>,
        trials: u64,
        steps: u64,
    }

    fn run_pair(spec: &str, size: u64, targets: Targets, s: u64) -> Pair {
        let inst = instance();
        let planted = 12345 + 7919 * s;
        let mut ops = GroupOps::default();
        let q = inst.curve.mul(&mut ops, inst.generator_point(), planted);
        let base = Params::parse_spec(&format!("prime-projected-abscissa:size={size},scan_cap=32"))
            .unwrap()
            .1;
        let (name, oracle_params) = Params::parse_spec(&format!("{spec},seed={s}")).unwrap();
        let ps = PipelineSpec {
            factor_base: "prime-projected-abscissa".into(),
            factor_base_params: base,
            oracle: name,
            oracle_params,
            targets,
            linalg: "incremental-gauss".into(),
            max_trials: 5_000_000,
            seed: s,
            ..Default::default()
        };
        let mut oracle = WWalkOracle::<PrimePoint>::new();
        let rep = run_pipeline(
            &ctx(&inst, q),
            &ps,
            &PrimeProjectedAbscissaBase { instance: &inst },
            &mut oracle,
            planted,
            &Calibration {
                ns_per_add: 1.0,
                ns_per_double: 1.0,
                ..Default::default()
            },
            None,
        )
        .unwrap();
        let ctr = DecompositionOracle::<PrimeCurve>::relation_counters(&oracle);
        let steps = oracle
            .target_walk()
            .map(|w| w.steps)
            .or_else(|| oracle.table().map(|t| t.steps))
            .unwrap();
        Pair {
            verified: rep.verified && rep.recovered == Some(planted),
            gae: rep.total_gae,
            verify_gae: rep.verify.gae,
            ctr,
            trials: rep.decomposition.targets_tried,
            steps,
        }
    }

    /// `sib=m,pool=M` through the parameter parser and the pipeline: the
    /// planted log is recovered and the pipeline's own `[d]G = Q` check
    /// passes with one and two seeds, verified and lazy; the second-point
    /// counter and its marker are emitted; the option refusals hold.
    #[test]
    fn wwalk_sibling_points_recover_end_to_end() {
        for (spec, size) in [
            ("wwalk:x=1.5,g=1,grow=2,tw=2,cj=1,sib=4,pool=32", 2u64),
            ("wwalk:x=1.5,g=1,grow=2,tw=2,cj=1,sib=8,pool=64", 2),
            ("wwalk:x=1.5,g=1,grow=2,tw=1,cj=1,sib=4,pool=32", 1),
        ] {
            let mut full = 0u64;
            for s in 0..12u64 {
                for lazy in ["", ",lazy=1"] {
                    let a = run_pair(&format!("{spec}{lazy}"), size, Targets::StrideGenerator, s);
                    assert!(a.verified, "{spec}{lazy} s={s}: planted log not recovered");
                    assert!(a.ctr["tw_sib_pairs"] + a.ctr["tw_sib_degenerate"] > 0);
                    assert!(a.ctr["tw_sib_second_points"] <= a.ctr["tw_sib_pairs"]);
                    if lazy.is_empty() {
                        full += 1;
                    } else {
                        assert_eq!(a.ctr["tw_lazy_failures"], 0);
                    }
                }
            }
            assert_eq!(full, 12);
        }
        for bad in [
            "wwalk:x=1.5,g=1,grow=2,tw=1,cj=1,sib=4",
            "wwalk:x=1.5,g=1,grow=2,tw=1,cj=1,pool=32",
            "wwalk:x=1.5,g=1,grow=2,tw=1,cj=1,sib=4,pool=3",
            "wwalk:x=1.5,g=1,grow=2,sib=4,pool=32",
        ] {
            let inst = instance();
            let mut ops = GroupOps::default();
            let q = inst.curve.mul(&mut ops, inst.generator_point(), 77);
            let (_, p) = Params::parse_spec(bad).unwrap();
            let fb = PrimeProjectedAbscissaBase { instance: &inst };
            let base = Params::parse_spec("prime-projected-abscissa:size=1,scan_cap=32")
                .unwrap()
                .1;
            let _ = (&fb, &base);
            let mut oracle = WWalkOracle::<PrimePoint>::new();
            let ps = PipelineSpec {
                factor_base: "prime-projected-abscissa".into(),
                factor_base_params: base,
                oracle: "wwalk".into(),
                oracle_params: p,
                targets: Targets::StrideGenerator,
                linalg: "incremental-gauss".into(),
                max_trials: 1000,
                seed: 1,
                ..Default::default()
            };
            let res = run_pipeline(
                &ctx(&inst, q),
                &ps,
                &PrimeProjectedAbscissaBase { instance: &inst },
                &mut oracle,
                77,
                &Calibration {
                    ns_per_add: 1.0,
                    ns_per_double: 1.0,
                    ..Default::default()
                },
                None,
            );
            assert!(res.is_err(), "{bad} should be refused");
        }
    }

    /// Prime-order curves above the old `r < 2^31` limit: `sib`, `lazy=1`
    /// and `cv=0` on the two-seed walk recover and verify the planted log at
    /// r ≈ 2^34 and r ≈ 2^38 (the `u128` coefficient word, `TW_COEF_BITS`),
    /// and the plain `WalkTable` keeps its 32-bit refusal there.
    #[test]
    fn wwalk_target_walk_runs_above_two_to_the_31() {
        use crate::cryptanalysis::ecbench::workload::{CurveSpec, Instance};
        for bits in [35u32, 39] {
            let spec = CurveSpec::PrimeOrbitShape {
                shape: "generic_a_minus_3".into(),
                bits,
                seed: 7,
            };
            let Instance::Prime(inst) = spec.build().unwrap() else {
                panic!("a prime instance");
            };
            assert!(inst.r >= 1 << 31, "r={} is not above 2^31", inst.r);
            let base = Params::parse_spec("prime-projected-abscissa:size=2,scan_cap=32")
                .unwrap()
                .1;
            let pre = "wwalk:x=2.0,g=1,grow=2,tw=2,cj=1";
            for (arm, s) in [
                (format!("{pre},lazy=1,sib=8,pool=256"), 1u64),
                (format!("{pre},sib=8,pool=64"), 2),
                (format!("{pre},lazy=1"), 3),
                (format!("{pre},cv=0"), 4),
            ] {
                let planted = (inst.r / 3 + 7919 * s) % inst.r;
                let mut ops = GroupOps::default();
                let q = inst.curve.mul(&mut ops, inst.generator_point(), planted);
                let (name, oracle_params) = Params::parse_spec(&format!("{arm},seed={s}")).unwrap();
                let ps = PipelineSpec {
                    factor_base: "prime-projected-abscissa".into(),
                    factor_base_params: base.clone(),
                    oracle: name,
                    oracle_params,
                    targets: Targets::StrideGenerator,
                    linalg: "incremental-gauss".into(),
                    max_trials: 5_000_000,
                    seed: s,
                    ..Default::default()
                };
                let mut oracle = WWalkOracle::<PrimePoint>::new();
                let rep = run_pipeline(
                    &ctx(&inst, q),
                    &ps,
                    &PrimeProjectedAbscissaBase { instance: &inst },
                    &mut oracle,
                    planted,
                    &Calibration {
                        ns_per_add: 1.0,
                        ns_per_double: 1.0,
                        ..Default::default()
                    },
                    None,
                )
                .unwrap_or_else(|e| panic!("{arm} at {bits} bits: {e}"));
                assert!(
                    rep.verified && rep.recovered == Some(planted),
                    "{arm} at {bits} bits: planted log not recovered"
                );
                if arm.contains("sib") {
                    let ctr = DecompositionOracle::<PrimeCurve>::relation_counters(&oracle);
                    assert!(ctr["tw_sib_pairs"] > 0);
                }
            }
        }
        // The plain walk table still packs coefficients in 32 bits.
        let r = 1u64 << 39;
        let opts = crate::cryptanalysis::ic_boundary::WalkOpts {
            g_jumps: true,
            grow: 2,
        };
        assert!(crate::cryptanalysis::ic_boundary::wwalk_plan_check(r, 2.0, 16, opts).is_err());
        assert!(crate::cryptanalysis::ic_boundary::wwalk_plan_check_bits(
            r,
            2.0,
            16,
            opts,
            crate::cryptanalysis::ic_boundary::TW_COEF_BITS
        )
        .is_ok());
    }

    /// `aut=3` on `j = 0`, `b = 7` prime-order curves: orbit-canonical keys
    /// under `ζ₃` recover and verify the planted log with lazy, verified,
    /// `cv=0`, sibling and one-seed walks; rotated collisions occur and are
    /// solved; every canonicalisation charges two field multiplications;
    /// curves without the structure and `tw=0` are refused.
    #[test]
    fn wwalk_aut3_recovers_on_j0_curves_and_refuses_elsewhere() {
        use crate::cryptanalysis::ecbench::workload::{CurveSpec, Instance};
        let build = |shape: &str, bits: u32, seed: u64| {
            let Instance::Prime(inst) = (CurveSpec::PrimeOrbitShape {
                shape: shape.into(),
                bits,
                seed,
            })
            .build()
            .unwrap() else {
                panic!("a prime instance");
            };
            inst
        };
        let run = |inst: &PrimeInstance, arm: &str, size: u64, s: u64| {
            let planted = (inst.r / 5 + 7919 * s) % inst.r;
            let mut ops = GroupOps::default();
            let q = inst.curve.mul(&mut ops, inst.generator_point(), planted);
            let base =
                Params::parse_spec(&format!("prime-projected-abscissa:size={size},scan_cap=32"))
                    .unwrap()
                    .1;
            let (name, oracle_params) = Params::parse_spec(&format!("{arm},seed={s}")).unwrap();
            let ps = PipelineSpec {
                factor_base: "prime-projected-abscissa".into(),
                factor_base_params: base,
                oracle: name,
                oracle_params,
                targets: Targets::StrideGenerator,
                linalg: "incremental-gauss".into(),
                max_trials: 5_000_000,
                seed: s,
                ..Default::default()
            };
            let mut oracle = WWalkOracle::<PrimePoint>::new();
            let rep = run_pipeline(
                &ctx(inst, q),
                &ps,
                &PrimeProjectedAbscissaBase { instance: inst },
                &mut oracle,
                planted,
                &Calibration {
                    ns_per_add: 1.0,
                    ns_per_double: 1.0,
                    ..Default::default()
                },
                None,
            );
            (rep, oracle, planted)
        };
        let pre2 = "wwalk:x=2.0,g=1,grow=2,tw=2,cj=1";
        let mut rotated = 0u64;
        for (bits, cseed) in [(28u32, 3u64), (34, 5)] {
            let inst = build("j0_b7", bits, cseed);
            for (arm, size) in [
                (format!("{pre2},lazy=1,aut=3"), 2u64),
                (format!("{pre2},aut=3"), 2),
                (format!("{pre2},cv=0,aut=3"), 2),
                (format!("{pre2},lazy=1,sib=8,pool=256,aut=3"), 2),
                (
                    "wwalk:x=2.0,g=1,grow=2,tw=1,cj=1,lazy=1,aut=3".to_string(),
                    1,
                ),
            ] {
                for s in 0..4u64 {
                    let (rep, oracle, planted) = run(&inst, &arm, size, s);
                    let rep = rep.unwrap_or_else(|e| panic!("{arm} at {bits} bits: {e}"));
                    assert!(
                        rep.verified && rep.recovered == Some(planted),
                        "{arm} at {bits} bits s={s}: planted log not recovered"
                    );
                    let ctr = DecompositionOracle::<PrimeCurve>::relation_counters(&oracle);
                    assert!(
                        ctr["aut_canonicalisations_uncharged"] > 0,
                        "{arm}: no canonicalisation"
                    );
                    rotated += ctr["tw_aut_rotated_collisions"];
                    let walk = oracle.target_walk().unwrap();
                    assert!(walk.walk_ops.field_ops.muls >= 2 * walk.aut_canonicalisations);
                }
            }
        }
        // About two thirds of the collisions join different rotations.
        assert!(rotated > 0, "no rotated collision was ever solved");
        // Refusals: a curve without ζ₃, and the plain walk table.
        let a3 = build("generic_a_minus_3", 28, 3);
        let (rep, _, _) = run(&a3, &format!("{pre2},lazy=1,aut=3"), 2, 0);
        assert!(rep.is_err(), "aut=3 on an a = -3 curve should be refused");
        let j0 = build("j0_b7", 28, 3);
        let (rep, _, _) = run(&j0, "wwalk:x=2.0,g=1,grow=2,aut=3", 2, 0);
        assert!(rep.is_err(), "aut=3 without tw should be refused");
    }

    /// `tw=2` (size-2 `prime-projected-abscissa` base) and `lazy=1`, end to
    /// end on `train-k32` (cofactor 8): the planted log is recovered and
    /// verified; a rank-3 walk solves on the first trial without a probe; a
    /// lazy arm has the walk, probe and collision counters of its verified
    /// twin and no verify ledger, its total is lower, and the pipeline's own
    /// charged check still runs (`verify` phase).  The option refusals hold.
    #[test]
    fn wwalk_two_seed_target_walk_and_lazy_recover_with_identical_walks() {
        let n = 12u64;
        // (spec, base size, lazy twin)
        for (spec, size) in [
            ("wwalk:x=1.5,g=1,grow=2,tw=2", 2u64),
            ("wwalk:x=1.5,g=1,grow=2,tw=2,cj=1", 2),
            ("wwalk:x=1.5,g=1,grow=2,tw=1,cj=1", 1),
        ] {
            let need = if size == 2 { 3 } else { 2 };
            let (mut eager_gae, mut lazy_gae, mut rank_full) = (0.0, 0.0, 0u64);
            for s in 0..n {
                let a = run_pair(spec, size, Targets::StrideGenerator, s);
                let b = run_pair(&format!("{spec},lazy=1"), size, Targets::StrideGenerator, s);
                assert!(a.verified, "{spec} s={s}: planted log not recovered");
                assert!(b.verified, "{spec},lazy s={s}: planted log not recovered");
                assert!(b.verify_gae > 0.0, "the pipeline's final check is charged");
                assert_eq!(b.ctr["tw_lazy_failures"], 0);
                for key in [
                    "tw_steps",
                    "tw_collisions",
                    "tw_rows",
                    "tw_rank",
                    "tw_walk_adds",
                    "tw_setup_adds",
                    "tw_setup_doubles",
                    "probe_hits",
                    "free_rows_emitted",
                ] {
                    assert_eq!(a.ctr[key], b.ctr[key], "{spec} s={s}: {key}");
                }
                assert_eq!(a.steps, b.steps);
                assert_eq!(b.ctr["tw_verify_adds"], 0);
                assert_eq!(b.ctr["tw_lazy_certified_rows"], b.ctr["tw_collisions"]);
                assert_eq!(a.trials, b.trials);
                if size == 2 {
                    assert_eq!(a.ctr["tw_seeds"], 2);
                }
                if a.ctr["tw_rank"] == need {
                    rank_full += 1;
                    assert_eq!(
                        a.ctr["probe_hits"], 0,
                        "{spec} s={s}: full rank needs no probe"
                    );
                    assert_eq!(a.trials, 1);
                }
                eager_gae += a.gae;
                lazy_gae += b.gae;
            }
            eprintln!(
                "{spec}: {n}/{n} recovered, full rank in {rank_full}, total GAE eager {eager_gae:.0} lazy {lazy_gae:.0}"
            );
            assert!(rank_full > 0);
            assert!(lazy_gae < eager_gae, "{spec}: lazy is not cheaper");
        }
        // The C = 2 walk table, stride-generator targets: `lazy=1` leaves the
        // walk, rows and probes alone and removes `verify_ops`.
        let (mut eager_gae, mut lazy_gae) = (0.0, 0.0);
        for s in 0..n {
            let spec = "wwalk:x=1.0,g=1,grow=2";
            let a = run_pair(spec, 2, Targets::StrideGenerator, s);
            let b = run_pair(&format!("{spec},lazy=1"), 2, Targets::StrideGenerator, s);
            assert!(a.verified && b.verified, "inc s={s}");
            assert_eq!(a.steps, b.steps);
            assert_eq!(a.ctr["probe_hits"], b.ctr["probe_hits"]);
            assert_eq!(a.ctr["free_rows_emitted"], b.ctr["free_rows_emitted"]);
            assert_eq!(
                a.ctr["free_collisions_checked"],
                b.ctr["free_collisions_checked"]
            );
            assert_eq!(a.trials, b.trials);
            assert_eq!(
                b.ctr["wwalk_lazy_certified_rows"],
                b.ctr["free_collisions_checked"]
            );
            assert!(b.verify_gae > 0.0);
            assert!(b.gae <= a.gae, "inc+lazy costs more at s={s}");
            eager_gae += a.gae;
            lazy_gae += b.gae;
        }
        eprintln!("inc: total GAE eager {eager_gae:.0} lazy {lazy_gae:.0}");
        assert!(lazy_gae < eager_gae);
        // Refusals.
        let inst = instance();
        let mut ops = GroupOps::default();
        let q = inst.curve.mul(&mut ops, inst.generator_point(), 777);
        let one = Params::parse_spec("prime-projected-abscissa:size=1,scan_cap=32")
            .unwrap()
            .1;
        let fb1 = PrimeProjectedAbscissaBase { instance: &inst }
            .build(&ctx(&inst, q), &one, &mut ops)
            .unwrap();
        let fb2 = PrimeProjectedAbscissaBase { instance: &inst }
            .build(&ctx(&inst, q), &base_params(32), &mut ops)
            .unwrap();
        for (fb, spec, needle) in [
            (&fb2, "wwalk:x=1.5,g=1,grow=2,tw=2,lazy=1", ""),
            (&fb1, "wwalk:x=1.5,g=1,grow=2,tw=2", "exactly 2 abscissae"),
            (&fb2, "wwalk:x=1.5,g=1,grow=2,tw=3", "tw is 0, 1 or 2"),
            (&fb2, "wwalk:x=1.5,grow=2,tw=2", "tw=2 needs g=1 and grow=2"),
            (
                &fb2,
                "wwalk:x=1.5,g=1,grow=1,tw=2",
                "tw=2 needs g=1 and grow=2",
            ),
            (&fb2, "wwalk:x=1.5,lazy=1", "lazy=1 needs g=1"),
            (
                &fb2,
                "wwalk:x=1.5,g=1,grow=2,cj=1",
                "cj=1 needs tw=1 or tw=2",
            ),
        ] {
            let (_, params) = Params::parse_spec(spec).unwrap();
            let mut oracle = WWalkOracle::<PrimePoint>::new();
            let res = DecompositionOracle::<PrimeCurve>::prepare(
                &mut oracle,
                &ctx(&inst, q),
                fb,
                &params,
                &mut ops,
            );
            if needle.is_empty() {
                assert!(res.is_ok(), "{spec}: {res:?}");
            } else {
                let err = res.unwrap_err();
                assert!(err.contains(needle), "{spec}: {err}");
            }
        }
    }
}

/// **`layout=lines` is a memory layout, not a different oracle.**  The
/// opt-in cache-line pair index and prefetched relation guard (#3116)
/// must leave every observable of the default (`map`) layout unchanged:
/// the decomposition of every target, the counted group operations and
/// native counters of the table build and of every probe, the relation
/// stream the pipeline collects, and the solved logarithm.  Checked on
/// several small prime-field curves and seeds, for both oracles that
/// accept the option: `mitm:negation_folded=1` and `mitm-prime-batch:m=2`.
#[cfg(test)]
mod layout_lines_equality_tests {
    use super::*;
    use crate::cryptanalysis::ic_boundary::{
        find_prime_order_curve, prime_factor_base, prime_instance_for, Calibration, CountedGroup,
        PrimeCurve, PrimeInstance, PrimePoint, Relation,
    };
    use crate::cryptanalysis::ic_framework::stages::Targets;
    use crate::cryptanalysis::ic_framework::{run_pipeline, PipelineSpec, RunReport};
    use rand::{rngs::StdRng, Rng, SeedableRng};

    /// The two oracle specs that accept `layout`, as the CLI spells them.
    const SPECS: [&str; 2] = ["mitm:negation_folded=1", "mitm-prime-batch:m=2"];

    /// Small prime-field curves: four roster curves and two curves drawn
    /// by `find_prime_order_curve` off the roster, with a base size each.
    fn curves() -> Vec<(PrimeInstance, usize)> {
        vec![
            (prime_instance_for(14, 1), 16),
            (prime_instance_for(16, 1), 24),
            (prime_instance_for(18, 1), 32),
            (prime_instance_for(20, 59297), 48),
            (find_prime_order_curve(15, 20261106), 20),
            (find_prime_order_curve(17, 3116), 28),
        ]
    }

    fn oracle_for(name: &str) -> Box<dyn DecompositionOracle<PrimeCurve>> {
        match name {
            "mitm" => Box::new(MitmOracle::new(2)),
            "mitm-prime-batch" => Box::new(PrimeBatchMitmOracle::new()),
            other => panic!("no oracle {other}"),
        }
    }

    /// `(name, default params, lines params)` for one spec string.
    fn arms(spec: &str) -> (String, Params, Params) {
        let (name, map) = Params::parse_spec(spec).unwrap();
        let (_, lines) = Params::parse_spec(&format!("{spec},layout=lines")).unwrap();
        assert_eq!(lines.get("layout"), Some("lines"));
        assert_eq!(map.get("layout"), None);
        (name, map, lines)
    }

    fn ctx(inst: &PrimeInstance, target: PrimePoint) -> InstanceCtx<'_, PrimeCurve> {
        InstanceCtx {
            group: &inst.curve,
            generator: inst.generator_point(),
            target,
            r: inst.r,
            cofactor: inst.cofactor,
            group_order: inst.group_order,
            name: inst.name.clone(),
            field_degree: None,
        }
    }

    /// The explicit `layout=map` spelling is the default, and the lines
    /// layout is the only arm that turns the line guard on.
    #[test]
    fn layout_map_is_the_default_and_lines_selects_the_line_guard() {
        let (inst, size) = curves().remove(1);
        let fb = prime_factor_base(&inst, size);
        let c = ctx(&inst, inst.generator_point());
        for spec in SPECS {
            let (name, map, lines) = arms(spec);
            let (_, explicit) = Params::parse_spec(&format!("{spec},layout=map")).unwrap();
            for (params, guard) in [(&map, false), (&explicit, false), (&lines, true)] {
                let mut oracle = oracle_for(&name);
                oracle
                    .prepare(&c, &fb, params, &mut GroupOps::default())
                    .unwrap();
                assert_eq!(oracle.line_guard(), guard, "{spec} {params:?}");
            }
        }
    }

    /// Table build and every probe: same decompositions (as summand
    /// indices and as the relations the pipeline is handed), same group
    /// operations, same native counters, target by target.
    #[test]
    fn layout_lines_gives_identical_decompositions_and_counted_operations() {
        for (inst, size) in curves() {
            let fb = prime_factor_base(&inst, size);
            let g = inst.generator_point();
            let c = ctx(&inst, g);
            for spec in SPECS {
                let (name, map_params, line_params) = arms(spec);
                let mut map = oracle_for(&name);
                let mut lines = oracle_for(&name);
                let mut map_build = GroupOps::default();
                let mut line_build = GroupOps::default();
                map.prepare(&c, &fb, &map_params, &mut map_build).unwrap();
                lines
                    .prepare(&c, &fb, &line_params, &mut line_build)
                    .unwrap();
                let label = format!("{} {spec}", inst.name);
                assert!(!map.line_guard() && lines.line_guard(), "{label}");
                assert_eq!(map_build, line_build, "{label}: build ops");
                assert!(map_build.adds > 0, "{label}: the build counted nothing");
                assert_eq!(
                    map.setup_work_native(),
                    lines.setup_work_native(),
                    "{label}: build work"
                );
                assert_eq!(map.summands(), lines.summands(), "{label}");
                for seed in [1u64, 7, 20261106] {
                    let mut rng = StdRng::seed_from_u64(seed ^ inst.r);
                    let mut map_ops = GroupOps::default();
                    let mut line_ops = GroupOps::default();
                    let mut map_ctr = OracleCounters::default();
                    let mut line_ctr = OracleCounters::default();
                    let mut hits = 0u64;
                    let mut setup = GroupOps::default();
                    for trial in 0..3000u64 {
                        let (a, b) = (rng.gen_range(0..inst.r), rng.gen_range(0..inst.r));
                        let point = inst.curve.mul(&mut setup, g, a);
                        let point = inst.curve.add(
                            &mut setup,
                            point,
                            inst.curve.mul(&mut GroupOps::default(), g, b),
                        );
                        lines.touch(&c, &point);
                        let m = map.decompose(&c, &fb, &mut map_ops, &mut map_ctr, point);
                        let l = lines.decompose(&c, &fb, &mut line_ops, &mut line_ctr, point);
                        assert_eq!(m, l, "{label} seed {seed} trial {trial}");
                        if let Some(w) = &m {
                            hits += 1;
                            let sum = w.iter().fold(None::<PrimePoint>, |acc, &i| {
                                Some(match acc {
                                    None => fb.points[i],
                                    Some(s) => {
                                        inst.curve.add(&mut GroupOps::default(), s, fb.points[i])
                                    }
                                })
                            });
                            assert_eq!(sum, Some(point), "{label}: a wrong decomposition");
                        }
                        let mr: Vec<Relation> = map.decompose_relations(
                            &c,
                            &fb,
                            &mut map_ops,
                            &mut map_ctr,
                            point,
                            a,
                            b,
                        );
                        let lr: Vec<Relation> = lines.decompose_relations(
                            &c,
                            &fb,
                            &mut line_ops,
                            &mut line_ctr,
                            point,
                            a,
                            b,
                        );
                        assert_eq!(mr, lr, "{label} seed {seed} trial {trial}: relations");
                    }
                    assert!(hits > 0, "{label} seed {seed}: no target decomposed");
                    assert_eq!(map_ops, line_ops, "{label} seed {seed}: probe ops");
                    assert_eq!(
                        format!("{map_ctr:?}"),
                        format!("{line_ctr:?}"),
                        "{label} seed {seed}: probe counters"
                    );
                    assert!(map_ctr.lookups > 0, "{label}: no lookup counted");
                }
                assert_eq!(
                    map.relation_counters(),
                    lines.relation_counters(),
                    "{label}: relation counters"
                );
            }
        }
    }

    fn assert_same_run(map: &RunReport, lines: &RunReport, label: &str) {
        assert_eq!(map.recovered, lines.recovered, "{label}: recovered");
        assert_eq!(map.verified, lines.verified, "{label}: verified");
        assert_eq!(map.exhausted, lines.exhausted, "{label}: exhausted");
        let (fm, fl) = (&map.factor_base, &lines.factor_base);
        assert_eq!(fm.columns, fl.columns, "{label}");
        assert_eq!(fm.signed_points, fl.signed_points, "{label}");
        assert_eq!(fm.cost.group_ops, fl.cost.group_ops, "{label}: base ops");
        assert_eq!(fm.cost.native, fl.cost.native, "{label}: base native");
        let (dm, dl) = (&map.decomposition, &lines.decomposition);
        assert_eq!(dm.targets_tried, dl.targets_tried, "{label}: targets");
        assert_eq!(dm.relations_found, dl.relations_found, "{label}: relations");
        assert_eq!(dm.setup.group_ops, dl.setup.group_ops, "{label}: setup ops");
        assert_eq!(dm.setup.native, dl.setup.native, "{label}: setup native");
        assert_eq!(dm.setup.work_native, dl.setup.work_native, "{label}");
        assert_eq!(dm.setup.gae, dl.setup.gae, "{label}: setup gae");
        assert_eq!(
            dm.cost.group_ops, dl.cost.group_ops,
            "{label}: relation ops"
        );
        assert_eq!(dm.cost.native, dl.cost.native, "{label}: relation native");
        assert_eq!(dm.cost.work_native, dl.cost.work_native, "{label}");
        assert_eq!(dm.cost.gae, dl.cost.gae, "{label}: relation gae");
        let (lm, ll) = (&map.linear_algebra, &lines.linear_algebra);
        assert_eq!(
            (lm.rows, lm.rank, lm.dependent, lm.work),
            (ll.rows, ll.rank, ll.dependent, ll.work),
            "{label}: linear algebra"
        );
        assert_eq!(lm.cost.native, ll.cost.native, "{label}");
        assert_eq!(map.verify.group_ops, lines.verify.group_ops, "{label}");
        assert_eq!(map.total_gae, lines.total_gae, "{label}: total gae");
        assert_eq!(map.s, lines.s, "{label}: S");
    }

    /// End to end: the same relation counts, the same counted cost in
    /// every phase, and the same solved logarithm, with walk, random and
    /// batched-lane targets (the lane source is the one that prefetches).
    #[test]
    fn layout_lines_solves_the_same_logarithm_at_the_same_counted_cost() {
        let calib = Calibration::default();
        let mut solved = 0;
        for (inst, size) in curves() {
            let g = inst.generator_point();
            for planted_seed in [11u64, 30_011, 20_261_106] {
                let planted = planted_seed % inst.r;
                let q = inst.curve.mul(&mut GroupOps::default(), g, planted);
                let c = ctx(&inst, q);
                for spec in SPECS {
                    let (name, map_params, line_params) = arms(spec);
                    for targets in [Targets::Walk, Targets::Random, Targets::WalkPrimeBatch16] {
                        for seed in [7u64, 3116] {
                            let run = |params: &Params| {
                                let mut spec = PipelineSpec {
                                    factor_base: "prime-abscissa".into(),
                                    oracle: name.clone(),
                                    oracle_params: params.clone(),
                                    targets,
                                    max_trials: 2_000_000,
                                    seed,
                                    ..Default::default()
                                };
                                spec.factor_base_params.set("size", size.to_string());
                                let mut oracle = oracle_for(&name);
                                run_pipeline(
                                    &c,
                                    &spec,
                                    &PrimeAbscissaBase { instance: &inst },
                                    oracle.as_mut(),
                                    planted,
                                    &calib,
                                    None,
                                )
                                .unwrap()
                            };
                            let map = run(&map_params);
                            let lines = run(&line_params);
                            let label = format!(
                                "{} {spec} {} seed {seed} planted {planted}",
                                inst.name,
                                targets.name()
                            );
                            assert_same_run(&map, &lines, &label);
                            if map.verified {
                                assert_eq!(map.recovered, Some(planted), "{label}");
                                solved += 1;
                            }
                        }
                    }
                }
            }
        }
        // Six curves × three logs × two specs × three sources × two seeds.
        assert_eq!(solved, 216, "every configuration should solve");
    }
}

#[cfg(test)]
mod free_rows_probe {
    //! Feasibility probe (not a result): how many target-free relations the
    //! Frobenius-folded pair table's build-time key collisions give on the
    //! frozen orbit panel, and their rank over the column unknowns mod r.
    use super::*;
    use crate::cryptanalysis::ic_boundary::koblitz_instance;
    use crate::cryptanalysis::koblitz_fast::FrobeniusCanon;
    use num_traits::ToPrimitive;
    use std::collections::HashMap;

    fn mulmod(a: u64, b: u64, r: u64) -> u64 {
        ((a as u128 * b as u128) % r as u128) as u64
    }
    fn powmod(mut a: u64, mut e: u64, r: u64) -> u64 {
        let mut acc = 1u64;
        while e > 0 {
            if e & 1 == 1 {
                acc = mulmod(acc, a, r);
            }
            a = mulmod(a, a, r);
            e >>= 1;
        }
        acc
    }
    fn rank(rows: &[Vec<u64>], cols: usize, r: u64) -> usize {
        let mut piv: Vec<Option<Vec<u64>>> = vec![None; cols];
        let mut rk = 0;
        for row in rows {
            let mut v = row.clone();
            for c in 0..cols {
                if v[c] == 0 {
                    continue;
                }
                match &piv[c] {
                    Some(p) => {
                        let f = v[c];
                        for k in c..cols {
                            v[k] = (v[k] + r - mulmod(f, p[k], r)) % r;
                        }
                    }
                    None => {
                        let inv = powmod(v[c], r - 2, r);
                        for k in c..cols {
                            v[k] = mulmod(v[k], inv, r);
                        }
                        piv[c] = Some(v);
                        rk += 1;
                        break;
                    }
                }
            }
            if rk == cols {
                break;
            }
        }
        rk
    }

    #[test]
    #[ignore]
    fn frobenius_table_free_rows_probe() {
        let panel: &[(u8, u32, usize)] = &[
            (0, 13, 1),
            (1, 17, 1),
            (0, 19, 2),
            (0, 23, 3),
            (1, 29, 1),
            (0, 31, 2),
            (0, 37, 8),
            (0, 41, 90),
        ];
        for &(a, n, c) in panel {
            let inst = koblitz_instance(a, n).expect("instance");
            let g = BinaryGroup(&inst.fast);
            let ctx = InstanceCtx {
                group: &g,
                generator: inst.generator,
                target: inst.generator,
                r: inst.r,
                cofactor: inst.cofactor,
                group_order: inst.group_order,
                name: inst.name.clone(),
                field_degree: Some(inst.n),
            };
            let (_, params) = Params::parse_spec(&format!(
                "compact-orbit-scan:columns={c},raw_x_cap=100000000"
            ))
            .unwrap();
            let mut ops = GroupOps::default();
            let fb = CompactOrbitScanBase { instance: &inst }
                .build(&ctx, &params, &mut ops)
                .unwrap();
            let r = inst.r;
            let lambda = (&inst.koblitz.as_ref().unwrap().lambda % r)
                .to_u64()
                .unwrap();
            let canon = FrobeniusCanon::new(&inst.gf, inst.n).unwrap();
            let f = fb.points.len();
            let cols = fb.columns;
            // Orbit representatives exactly as FrobeniusPairTable::build_inner.
            let mut orbit_of = vec![0u32; f];
            let mut reps: Vec<usize> = Vec::new();
            let mut idx: HashMap<u64, u32> = HashMap::new();
            for i in 0..f {
                let key = canon.canon(fb.points[i].x);
                let next = reps.len() as u32;
                let id = *idx.entry(key).or_insert(next);
                if id == next {
                    reps.push(i);
                }
                orbit_of[i] = id;
            }
            let mut map: HashMap<u64, (usize, usize, u32, FastPoint)> = HashMap::new();
            let (mut attempts, mut collisions, mut mismatches) = (0u64, 0u64, 0u64);
            let mut rows: Vec<Vec<u64>> = Vec::new();
            let mut ops2 = GroupOps::default();
            for (orbit, &rep) in reps.iter().enumerate() {
                for j in 0..f {
                    if (orbit_of[j] as usize) < orbit {
                        continue;
                    }
                    let u = g.add(&mut ops2, fb.points[rep], fb.points[j]);
                    if u.infinity {
                        continue;
                    }
                    attempts += 1;
                    let (key, t_u) = canon.canon_with_shift(u.x);
                    match map.get(&key) {
                        None => {
                            map.insert(key, (rep, j, t_u, u));
                        }
                        Some(&(i0, j0, t0, u0)) => {
                            collisions += 1;
                            let t = (t0 + n - t_u) % n;
                            let v = inst.fast.frobenius_k(u0, t);
                            let s_neg = if v == u {
                                false
                            } else if v == g.neg(u) {
                                true
                            } else {
                                mismatches += 1;
                                continue;
                            };
                            let mut row = vec![0u64; cols];
                            for &k in &[rep, j] {
                                let col = fb.col_of[k];
                                row[col] = (row[col] + fb.coef_of[k] % r) % r;
                            }
                            let lt = powmod(lambda, t as u64, r);
                            for &k in &[i0, j0] {
                                let col = fb.col_of[k];
                                let mut term = mulmod(lt, fb.coef_of[k] % r, r);
                                if !s_neg {
                                    term = (r - term) % r;
                                }
                                row[col] = (row[col] + term) % r;
                            }
                            if row.iter().any(|&x| x != 0) {
                                rows.push(row);
                            }
                        }
                    }
                }
            }
            let rk = rank(&rows, cols, r);
            println!(
                "n{n} a{a} c{cols} |F| {f} reps {} entries {} attempts {attempts} collisions {collisions} nonzero rows {} rank {rk} (need {}) mismatches {mismatches} r 2^{:.1}",
                reps.len(),
                map.len(),
                rows.len(),
                cols.saturating_sub(1),
                (r as f64).log2()
            );
        }
    }
}

// ── k-sum folded by the signed Frobenius (Koblitz) ───────────────────

/// Most `k`-sum completions [`FrobeniusKSumTable::build`] agrees to try:
/// a guard against a base whose folded table would not fit in memory.
pub const FROB_KSUM_MAX_ATTEMPTS: u64 = 1 << 28;

use crate::cryptanalysis::ic_boundary::{fast_map, FastMap};

/// **A table of every signed `k`-sum of a Frobenius-closed base, folded by
/// the signed Frobenius `⟨σ, −1⟩`** (Koblitz curves, `k = 3` to `5`).
///
/// `σ` is a group automorphism, so `σ^t(Σ ε_i P_i) = Σ ε_i σ^t(P_i)`, and
/// the `2n` images of a sum share one canonical name of its abscissa
/// ([`FrobeniusCanon`]).  The table keeps one sum per such orbit: the
/// first summand is the representative of the least orbit the sum meets
/// (the rotation and sign that bring a summand there are absorbed by the
/// fold), the others are base points at strictly later positions of the
/// orbit-sorted base, no two on one abscissa.  About `1/(2n)` of the
/// unfolded table of the same signed points.
///
/// A probe canonicalises the target's abscissa once; the entry's shift and
/// the target's give the rotation `t`; the summands `σ^t(P_i)` are read
/// from an orbit-member index built once (`n − 1` Frobenius maps and
/// lookups a base point, charged at build); `k − 1` additions confirm
/// `±R`.  A relation is a [`Relation::Summands`] over base points, which
/// the base's column map turns into `±λ^t` coefficients on orbit columns.
#[derive(Clone, Copy, Debug, Default)]
pub struct FrobeniusKSumOpts {
    pub layout: bool,
    pub prune: bool,
    pub sib: bool,
    pub keep_collisions: bool,
    pub max_entries: Option<u64>,
}

pub struct FrobeniusKSumTable {
    /// Canonical key → (packed summand indices, the entry's shift).
    map: FastMap<(u64, u8)>,
    canon: crate::cryptanalysis::koblitz_fast::FrobeniusCanon,
    /// `member_of[i·n + t]`: the base index of `σ^t(P_i)` (empty when `layout` is set).
    member_of: Vec<u32>,
    layout: bool,
    prune: bool,
    sib: bool,
    keep_collisions: bool,
    max_entries: Option<u64>,
    /// Colliding `(packed1, shift1, packed2, shift2)` pairs when `keep_collisions` is set.
    pub collisions: Vec<(u64, u8, u64, u8)>,
    pub sib_second_points: u64,
    n: u32,
    bits: u32,
    pub k: u32,
    pub entries: u64,
    pub representatives: u64,
    pub build_ops: GroupOps,
    pub build_wall_ns: u64,
    /// Canonicalisations of the build: one a base point (the orbit
    /// pass, when not `layout`) and one a completed sum.
    pub build_canonicalisations: u64,
    pub build_frobenius_maps: u64,
    pub build_lookups: u64,
    /// Completed sums offered to the map, kept or not.
    pub insert_attempts: u64,
}

impl FrobeniusKSumTable {
    pub fn build(
        inst: &BinaryInstance,
        fb: &FactorBase<FastPoint>,
        k: u32,
    ) -> Result<Self, String> {
        Self::build_with_opts(inst, fb, k, FrobeniusKSumOpts::default())
    }

    pub fn build_with_opts(
        inst: &BinaryInstance,
        fb: &FactorBase<FastPoint>,
        k: u32,
        opts: FrobeniusKSumOpts,
    ) -> Result<Self, String> {
        use crate::cryptanalysis::ic_boundary::ksum_index_bits;
        if !(3..=5).contains(&k) {
            return Err(format!("ksum-frobenius needs m = 3, 4 or 5, not {k}"));
        }
        let bits = ksum_index_bits(k);
        let f = fb.points.len();
        if f >= 1 << bits {
            return Err(format!(
                "ksum-frobenius packs base indices in {bits} bits; the base has {f} points (fewer than {} are allowed)",
                1u64 << bits
            ));
        }
        if inst.koblitz.is_none() {
            return Err("ksum-frobenius needs a Koblitz curve".into());
        }
        if let Some(cap) = opts.max_entries {
            if cap == 0 || cap > FROB_KSUM_MAX_ATTEMPTS {
                return Err(format!(
                    "ksum-frobenius max_entries must be in 1..={FROB_KSUM_MAX_ATTEMPTS}, got {cap}"
                ));
            }
        }
        let start = Instant::now();
        let n = inst.n as usize;
        let g = BinaryGroup(&inst.fast);
        let canon = crate::cryptanalysis::koblitz_fast::FrobeniusCanon::new(&inst.gf, inst.n)
            .ok_or("no normal basis found for the Frobenius canonical form")?;

        let (member_of, order, rep_of_orbit, block_start, canons, frob, lookups) = if opts.layout {
            if fb.frobenius_orbit_layout != Some(inst.n)
                || n.is_multiple_of(2)
                || !f.is_multiple_of(2 * n)
            {
                return Err(
                    "ksum-frobenius layout=1 needs an odd-degree base laid out by orbit (compact-orbit-scan)"
                        .into(),
                );
            }
            let orbits = f / (2 * n);
            let order: Vec<usize> = (0..f).collect();
            let rep_of_orbit: Vec<usize> = (0..orbits).map(|o| 2 * o * n).collect();
            let block_start: Vec<usize> = rep_of_orbit.clone();
            (
                Vec::new(),
                order,
                rep_of_orbit,
                block_start,
                0u64,
                0u64,
                0u64,
            )
        } else {
            // The orbit-member index: σ^t(P_i) for every base point.
            let mut member_of = vec![0u32; f * n];
            let (mut frob, mut lookups) = (0u64, 0u64);
            for i in 0..f {
                let mut p = fb.points[i];
                member_of[i * n] = i as u32;
                for t in 1..n {
                    p = inst.fast.frobenius_k(p, 1);
                    frob += 1;
                    lookups += 1;
                    let idx = *fb
                        .point_index
                        .get(&p.pack())
                        .ok_or("ksum-frobenius needs a base closed under the Frobenius")?;
                    member_of[i * n + t] = idx as u32;
                }
            }
            // Orbits by the canonical name of the abscissa (±P share it), the
            // representative the first point of each in index order.
            let mut orbit_of = vec![0u32; f];
            let mut rep_of_orbit: Vec<usize> = Vec::new();
            let mut canons = 0u64;
            {
                let mut orbit_index: FastMap<u32> = fast_map(f / n + 1);
                for i in 0..f {
                    canons += 1;
                    let key = canon.canon(fb.points[i].x);
                    let next = rep_of_orbit.len() as u32;
                    let id = *orbit_index.entry(key).or_insert(next);
                    if id == next {
                        rep_of_orbit.push(i);
                    }
                    orbit_of[i] = id;
                }
            }
            let mut order: Vec<usize> = (0..f).collect();
            order.sort_by_key(|&i| (orbit_of[i], i));
            let mut block_start = vec![0usize; rep_of_orbit.len()];
            for (pos, &i) in order.iter().enumerate().rev() {
                block_start[orbit_of[i] as usize] = pos;
            }
            (
                member_of,
                order,
                rep_of_orbit,
                block_start,
                canons,
                frob,
                lookups,
            )
        };

        // Completions tried: Σ_o C(f − start_o − 1, k − 1).
        let choose = |a: u64, b: u64| -> u64 {
            (0..b).fold(1u64, |c, i| c.saturating_mul(a.saturating_sub(i)) / (i + 1))
        };
        let full_estimate = block_start
            .iter()
            .map(|&s| choose((f - s - 1) as u64, u64::from(k - 1)))
            .fold(0u64, |a, b| a.saturating_add(b));
        let estimate = match opts.max_entries {
            Some(cap) => full_estimate.min(cap.saturating_mul(2)),
            None => full_estimate,
        };
        if estimate > FROB_KSUM_MAX_ATTEMPTS {
            return Err(format!(
                "a Frobenius-folded {k}-sum table over {f} points would try about {estimate} sums, above the limit {FROB_KSUM_MAX_ATTEMPTS}"
            ));
        }
        let map_cap = match opts.max_entries {
            Some(cap) => cap.min(1 << 24) as usize + 4,
            None => (estimate / 2).min(1 << 24) as usize + 1,
        };
        let mut t = Self {
            map: fast_map(map_cap),
            canon,
            member_of,
            layout: opts.layout,
            prune: opts.prune,
            sib: opts.sib,
            keep_collisions: opts.keep_collisions,
            max_entries: opts.max_entries,
            collisions: Vec::new(),
            sib_second_points: 0,
            n: inst.n,
            bits,
            k,
            entries: 0,
            representatives: rep_of_orbit.len() as u64,
            build_ops: GroupOps::default(),
            build_wall_ns: 0,
            build_canonicalisations: canons,
            build_frobenius_maps: frob,
            build_lookups: lookups,
            insert_attempts: 0,
        };
        let paired_order = (opts.prune || opts.sib || opts.max_entries.is_some())
            && order.len().is_multiple_of(2)
            && block_start.iter().all(|s| s.is_multiple_of(2))
            && (0..order.len() / 2).all(|p| {
                let (j0, j1) = (order[2 * p], order[2 * p + 1]);
                fb.neg_index[j0] == j1 && fb.points[j0].x == fb.points[j1].x
            });
        let mut idx = [u32::MAX; 5];
        if paired_order {
            let mut acc = Vec::new();
            let mut dens = Vec::new();
            for (o, &rep) in rep_of_orbit.iter().enumerate() {
                if t.reached_cap() {
                    break;
                }
                idx[0] = rep as u32;
                let o_pair_base = block_start[o] / 2;
                let o_pair_end = if opts.layout { o_pair_base + n } else { 0 };
                t.extend_paired(
                    &g,
                    fb,
                    &order,
                    1,
                    o_pair_base + 1,
                    o_pair_base,
                    o_pair_end,
                    None,
                    0,
                    fb.points[rep],
                    &mut idx,
                    &mut dens,
                    &mut acc,
                );
            }
        } else {
            for (o, &rep) in rep_of_orbit.iter().enumerate() {
                if t.reached_cap() {
                    break;
                }
                idx[0] = rep as u32;
                t.extend(
                    &g,
                    fb,
                    &order,
                    1,
                    block_start[o] + 1,
                    fb.points[rep],
                    &mut idx,
                );
            }
        }
        t.entries = t.map.len() as u64;
        t.build_wall_ns = start.elapsed().as_nanos() as u64;
        Ok(t)
    }

    #[inline]
    fn reached_cap(&self) -> bool {
        self.max_entries
            .is_some_and(|cap| self.map.len() as u64 >= cap)
    }

    #[inline]
    fn member_at(&self, idx: usize, t: usize) -> usize {
        let n = self.n as usize;
        if self.layout {
            let (block, within) = (idx / (2 * n), idx % (2 * n));
            block * 2 * n + 2 * ((within / 2 + t) % n) + within % 2
        } else {
            self.member_of[idx * n + t] as usize
        }
    }

    #[inline]
    fn insert_x(&mut self, x: u64, idx: &[u32; 5]) {
        self.build_canonicalisations += 1;
        self.insert_attempts += 1;
        let (key, shift) = self.canon.canon_with_shift(x);
        let bits = self.bits;
        let packed = idx[..self.k as usize]
            .iter()
            .rev()
            .fold(0u64, |w, &i| (w << bits) | u64::from(i));
        let shift_u8 = shift as u8;
        match self.map.entry(key) {
            std::collections::hash_map::Entry::Vacant(v) => {
                v.insert((packed, shift_u8));
            }
            std::collections::hash_map::Entry::Occupied(o) => {
                if self.keep_collisions {
                    let &(p1, s1) = o.get();
                    self.collisions.push((p1, s1, packed, shift_u8));
                }
            }
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn extend(
        &mut self,
        g: &BinaryGroup,
        fb: &FactorBase<FastPoint>,
        order: &[usize],
        depth: usize,
        from: usize,
        partial: FastPoint,
        idx: &mut [u32; 5],
    ) {
        let last = depth + 1 == self.k as usize;
        for pos in from..order.len() {
            if self.reached_cap() {
                break;
            }
            let j = order[pos];
            // Distinct abscissae: never a point beside its negative.
            let neg = fb.neg_index[j] as u32;
            if idx[..depth].contains(&neg) {
                continue;
            }
            let s = g.add(&mut self.build_ops, partial, fb.points[j]);
            if g.is_identity(&s) {
                continue;
            }
            idx[depth] = j as u32;
            if last {
                self.insert_x(s.x, idx);
            } else {
                self.extend(g, fb, order, depth + 1, pos + 1, s, idx);
            }
        }
        idx[depth] = u32::MAX;
    }

    #[allow(clippy::too_many_arguments)]
    fn extend_paired(
        &mut self,
        g: &BinaryGroup,
        fb: &FactorBase<FastPoint>,
        order: &[usize],
        depth: usize,
        from_pair: usize,
        o_pair_base: usize,
        o_pair_end: usize,
        first_rot: Option<usize>,
        prev_rot: usize,
        partial: FastPoint,
        idx: &mut [u32; 5],
        dens: &mut Vec<u64>,
        acc: &mut Vec<u64>,
    ) {
        let num_pairs = order.len() / 2;
        let last = depth + 1 == self.k as usize;
        let end_pair = if self.prune {
            num_pairs.saturating_sub(self.k as usize - 1 - depth)
        } else {
            num_pairs
        };
        if from_pair >= end_pair || self.reached_cap() {
            return;
        }
        // Allowed pair intervals `[lo, hi)` at this depth: under `layout`,
        // summands in the starting orbit `o` (`o_pair_base .. o_pair_end`)
        // obey the cyclic minimum-gap necklace bound so duplicate Frobenius
        // rotations of the same tuple are skipped without losing any orbit.
        let n = self.n as usize;
        let mut ranges: [(usize, usize); 2] = [(0, 0); 2];
        let mut n_ranges = 0usize;
        if self.layout && from_pair < o_pair_end {
            let (in_lo, in_hi_excl) = match first_rot {
                None => (from_pair, (o_pair_base + n / 2 + 1).min(o_pair_end)),
                Some(r1) => {
                    let min_rot = prev_rot + r1;
                    let max_rot = n.saturating_sub(r1);
                    if min_rot <= max_rot {
                        (
                            from_pair.max(o_pair_base + min_rot),
                            (o_pair_base + max_rot + 1).min(o_pair_end),
                        )
                    } else {
                        (0, 0)
                    }
                }
            };
            let in_hi = in_hi_excl.min(end_pair);
            if in_lo < in_hi {
                ranges[n_ranges] = (in_lo, in_hi);
                n_ranges += 1;
            }
            let out_lo = o_pair_end.max(from_pair);
            if out_lo < end_pair {
                ranges[n_ranges] = (out_lo, end_pair);
                n_ranges += 1;
            }
        } else {
            ranges[0] = (from_pair, end_pair);
            n_ranges = 1;
        }

        if last && self.sib {
            let f = &g.0.field;
            let curve_a = g.0.a;
            for &(r_lo, r_hi) in &ranges[..n_ranges] {
                let mut cur = r_lo;
                while cur < r_hi && !self.reached_cap() {
                    let chunk_limit = match self.max_entries {
                        Some(cap) => {
                            let rem = cap.saturating_sub(self.map.len() as u64);
                            ((rem as usize).div_ceil(2)).clamp(1, 256)
                        }
                        None => 256,
                    };
                    let hi = (cur + chunk_limit).min(r_hi);
                    dens.clear();
                    dens.reserve(hi - cur);
                    for p in cur..hi {
                        let xq = fb.points[order[2 * p]].x;
                        dens.push(if partial.x == xq { 0 } else { partial.x ^ xq });
                    }
                    f.batch_inv(dens, acc);
                    for (offset, &inv) in dens.iter().enumerate() {
                        let p = cur + offset;
                        let (j0, j1) = (order[2 * p], order[2 * p + 1]);
                        if inv != 0 {
                            let pt = fb.points[j0];
                            let dx = partial.x ^ pt.x;
                            let lp = f.mul(partial.y ^ pt.y, inv);
                            let lp2 = f.sqr(lp);
                            let xp = lp2 ^ lp ^ dx ^ curve_a;
                            let lm = lp ^ f.mul(pt.x, inv);
                            let lm2 = f.sqr(lm);
                            let xm = lm2 ^ lm ^ dx ^ curve_a;
                            self.build_ops.adds += 1;
                            self.sib_second_points += 1;
                            crate::cryptanalysis::group_op_count::count_adds(1);
                            idx[depth] = j0 as u32;
                            self.insert_x(xp, idx);
                            idx[depth] = j1 as u32;
                            self.insert_x(xm, idx);
                        } else {
                            for j in [j0, j1] {
                                let s = g.add(&mut self.build_ops, partial, fb.points[j]);
                                if !g.is_identity(&s) {
                                    idx[depth] = j as u32;
                                    self.insert_x(s.x, idx);
                                }
                            }
                        }
                    }
                    cur = hi;
                }
            }
            idx[depth] = u32::MAX;
            return;
        }
        for &(r_lo, r_hi) in &ranges[..n_ranges] {
            for p in r_lo..r_hi {
                if self.reached_cap() {
                    break;
                }
                let (next_first, next_prev) = if self.layout && p < o_pair_end {
                    let rot = p - o_pair_base;
                    (Some(first_rot.unwrap_or(rot)), rot)
                } else {
                    (first_rot, prev_rot)
                };
                for j in [order[2 * p], order[2 * p + 1]] {
                    if self.reached_cap() {
                        break;
                    }
                    let s = g.add(&mut self.build_ops, partial, fb.points[j]);
                    if g.is_identity(&s) {
                        continue;
                    }
                    idx[depth] = j as u32;
                    if last {
                        self.insert_x(s.x, idx);
                    } else {
                        self.extend_paired(
                            g,
                            fb,
                            order,
                            depth + 1,
                            p + 1,
                            o_pair_base,
                            o_pair_end,
                            next_first,
                            next_prev,
                            s,
                            idx,
                            dens,
                            acc,
                        );
                    }
                }
            }
        }
        idx[depth] = u32::MAX;
    }

    /// Verify recorded Frobenius-orbit key collisions in the group and return
    /// target-free relation rows `(col, coef mod r)` plus `(checked, modr_muls, modr_adds)`.
    pub fn free_rows(
        &self,
        g: &BinaryGroup,
        fb: &FactorBase<FastPoint>,
        r: u64,
        ops: &mut GroupOps,
    ) -> (Vec<Vec<(usize, u64)>>, u64, u64, u64) {
        let mask = (1u64 << self.bits) - 1;
        let unpack = |packed: u64, t: usize| -> Vec<usize> {
            (0..self.k)
                .map(|d| {
                    let i = ((packed >> (d * self.bits)) & mask) as usize;
                    self.member_at(i, t)
                })
                .collect()
        };
        let sum = |ops: &mut GroupOps, idx: &[usize]| {
            let mut s = fb.points[idx[0]];
            for &i in &idx[1..] {
                s = g.add(ops, s, fb.points[i]);
            }
            s
        };
        let max_rows = fb.columns.saturating_add(4);
        let max_checks = max_rows.saturating_mul(2).max(8);
        let mut rows = Vec::new();
        let mut checked = 0u64;
        let mut modr_muls = 0u64;
        let mut modr_adds = 0u64;
        let n = self.n;
        for &(p1, t1, p2, t2) in &self.collisions {
            if rows.len() >= max_rows || checked >= max_checks as u64 {
                break;
            }
            let t = ((u32::from(t1) + n - u32::from(t2)) % n) as usize;
            let i1 = unpack(p1, t);
            let i2 = unpack(p2, 0);
            // Form the column-coefficient vectors of both tuples modulo r
            // first: any single-column identity, permutation, or Z[τ] identity
            // (such as −τ − τ² = τ + τ³ = 2) has v1 == ±v2 on every column and
            // would cancel to the zero row, so skip it before group additions.
            let mut v1: BTreeMap<usize, u64> = BTreeMap::new();
            let mut v2: BTreeMap<usize, u64> = BTreeMap::new();
            for &i in &i1 {
                let e = v1.entry(fb.col_of[i]).or_insert(0);
                *e = (*e + fb.coef_of[i] % r) % r;
                modr_adds += 1;
            }
            for &i in &i2 {
                let e = v2.entry(fb.col_of[i]).or_insert(0);
                *e = (*e + fb.coef_of[i] % r) % r;
                modr_adds += 1;
            }
            v1.retain(|_, c| *c != 0);
            v2.retain(|_, c| *c != 0);
            let same = v1 == v2;
            let opp = !same
                && v1.len() == v2.len()
                && v1
                    .iter()
                    .all(|(col, &c1)| v2.get(col).is_some_and(|&c2| (c1 + c2) % r == 0));
            if same || opp {
                continue;
            }
            checked += 1;
            let (s1, s2) = (sum(ops, &i1), sum(ops, &i2));
            let sign: u64 = if s1 == s2 {
                r - 1
            } else if s1 == g.neg(s2) {
                1
            } else {
                continue;
            };
            let mut acc = v1;
            for (col, c2) in v2 {
                let e = acc.entry(col).or_insert(0);
                *e = ((*e as u128 + c2 as u128 * sign as u128) % r as u128) as u64;
                modr_muls += 1;
                modr_adds += 1;
            }
            let row: Vec<(usize, u64)> = acc.into_iter().filter(|&(_, c)| c != 0).collect();
            if !row.is_empty() {
                rows.push(row);
            }
        }
        (rows, checked, modr_muls, modr_adds)
    }

    /// The build's work that only `bitop/v1` prices.
    pub fn work_counters(&self) -> BTreeMap<String, u64> {
        let mut out = BTreeMap::new();
        let canon = self.canon.build_work();
        for (name, v) in [
            ("table_insert_attempts", self.insert_attempts),
            ("canon_build_word_ops", canon.word_ops),
            ("canon_build_field_sqrs", canon.field_sqrs),
        ] {
            if v > 0 {
                out.insert(name.to_string(), v);
            }
        }
        if self.sib {
            out.insert("counted:sibling_second_points".to_string(), 1);
            out.insert("sibling_second_points".to_string(), self.sib_second_points);
        }
        out
    }

    /// Signed indices of `k` base points summing to `target`, if some
    /// `⟨σ, −1⟩`-image of a stored sum is `±target`: one canonicalisation,
    /// one probe, `k − 1` additions.
    pub fn probe(
        &self,
        g: &BinaryGroup,
        fb: &FactorBase<FastPoint>,
        ops: &mut GroupOps,
        ctr: &mut OracleCounters,
        target: FastPoint,
    ) -> Option<Vec<usize>> {
        if g.is_identity(&target) {
            return None;
        }
        ctr.canonicalisations += 1;
        let (key, t_r) = self.canon.canon_with_shift(target.x);
        ctr.lookups += 1;
        let &(packed, t_u) = self.map.get(&key)?;
        let n = self.n;
        // x_R = σ^t(x_U), t = t_u − t_r (as FrobeniusPairTable::probe).
        let t = ((u32::from(t_u) + n - t_r) % n) as usize;
        let mask = (1u64 << self.bits) - 1;
        let summands: Vec<usize> = (0..self.k)
            .map(|d| {
                let i = ((packed >> (d * self.bits)) & mask) as usize;
                self.member_at(i, t)
            })
            .collect();
        let mut s = fb.points[summands[0]];
        for &i in &summands[1..] {
            s = g.add(ops, s, fb.points[i]);
        }
        if s == target {
            Some(summands)
        } else if s == g.neg(target) {
            Some(summands.iter().map(|&i| fb.neg_index[i]).collect())
        } else {
            ctr.frobfold_mismatches += 1;
            None
        }
    }
}

/// `ksum-frobenius:m=3|4|5[,layout=1][,prune=1][,sib=1][,free=1][,max_entries=E][,scale=X]`:
/// one probe a target into a [`FrobeniusKSumTable`] over a Frobenius-closed
/// Koblitz base (`koblitz-standard-subspace`, `koblitz-closure`, `compact-orbit-scan`).
/// Every group operation, Frobenius map, lookup and canonicalisation of
/// the build and of every probe is counted.
pub struct FrobeniusKSumOracle<'i> {
    k: u32,
    instance: &'i BinaryInstance,
    table: Option<FrobeniusKSumTable>,
    free: bool,
    free_pending: bool,
    free_checked: u64,
    free_emitted: u64,
    free_modr_muls: u64,
    free_modr_adds: u64,
}

impl<'i> FrobeniusKSumOracle<'i> {
    pub fn new(k: u32, instance: &'i BinaryInstance) -> Self {
        Self {
            k,
            instance,
            table: None,
            free: false,
            free_pending: false,
            free_checked: 0,
            free_emitted: 0,
            free_modr_muls: 0,
            free_modr_adds: 0,
        }
    }

    pub fn table(&self) -> Option<&FrobeniusKSumTable> {
        self.table.as_ref()
    }
}

impl<'a> DecompositionOracle<BinaryGroup<'a>> for FrobeniusKSumOracle<'_> {
    fn name(&self) -> &str {
        "ksum-frobenius"
    }

    fn summands(&self) -> u32 {
        self.k
    }

    fn describe(&self, _params: &Params) -> String {
        format!(
            "a table of signed {}-sums of a Frobenius-closed base, one entry per signed Frobenius orbit, probed once per target",
            self.k
        )
    }

    fn parameters(&self) -> &[(&str, &str)] {
        &[
            (
                "m",
                "summands, 3 to 5 (base of fewer than 4096 signed points, closed under the Frobenius)",
            ),
            (
                "layout",
                "1: index Frobenius orbit members directly on compact-orbit-scan bases, avoiding orbit-index Frobenius maps and lookups (default 0)",
            ),
            (
                "prune",
                "1: skip partial sums that cannot be completed to m summands (default 0)",
            ),
            (
                "sib",
                "1: form both leaf signs x(S ± P) from one shared inverse with batched Montgomery inversions, charged as 1 group add + 1 sibling_second_points (default 0)",
            ),
            (
                "free",
                "1: group-check colliding table keys and emit target-free orbit relations (default 0)",
            ),
            (
                "max_entries",
                "optional bound E on stored orbit entries before stopping the table build",
            ),
            (
                "scale",
                "optional analytical bound E = max(1, round(X * sqrt(r / n))) on stored orbit entries (mutually exclusive with max_entries)",
            ),
        ]
    }

    fn prepare(
        &mut self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        fb: &FactorBase<FastPoint>,
        params: &Params,
        ops: &mut GroupOps,
    ) -> Result<(), String> {
        self.free = params.flag("free");
        self.free_pending = self.free;
        self.free_checked = 0;
        self.free_emitted = 0;
        self.free_modr_muls = 0;
        self.free_modr_adds = 0;
        let max_entries = match (params.get("max_entries"), params.get("scale")) {
            (Some(_), Some(_)) => {
                return Err(
                    "ksum-frobenius accepts at most one of max_entries and scale".to_string(),
                );
            }
            (Some(_), None) => Some(params.u64("max_entries")?),
            (None, Some(raw)) => {
                let scale: f64 = raw
                    .parse()
                    .map_err(|_| format!("ksum-frobenius: scale `{raw}` is not a number"))?;
                if !scale.is_finite() || scale <= 0.0 {
                    return Err(format!(
                        "ksum-frobenius scale={scale} must be finite and > 0"
                    ));
                }
                let r = ctx.r as f64;
                let n = self.instance.n.max(1) as f64;
                let e = (scale * (r / n).sqrt()).round().max(1.0) as u64;
                Some(e)
            }
            (None, None) => None,
        };
        let opts = FrobeniusKSumOpts {
            layout: params.flag("layout"),
            prune: params.flag("prune"),
            sib: params.flag("sib"),
            keep_collisions: self.free,
            max_entries,
        };
        let table = FrobeniusKSumTable::build_with_opts(self.instance, fb, self.k, opts)?;
        ops.merge(table.build_ops);
        self.table = Some(table);
        Ok(())
    }

    fn setup_work_native(&self) -> BTreeMap<String, u64> {
        table_counted(
            self.table
                .as_ref()
                .map(FrobeniusKSumTable::work_counters)
                .unwrap_or_default(),
        )
    }

    fn setup_native(&self) -> BTreeMap<String, u64> {
        let mut counts = BTreeMap::new();
        if let Some(table) = &self.table {
            counts.insert("canonicalisations".into(), table.build_canonicalisations);
            counts.insert("frobenius_maps".into(), table.build_frobenius_maps);
            counts.insert("lookups".into(), table.build_lookups);
            counts.insert("ksum_table_entries".into(), table.entries);
            counts.insert("ksum_table_representatives".into(), table.representatives);
        }
        counts
    }

    fn decompose(
        &mut self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        fb: &FactorBase<FastPoint>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: FastPoint,
    ) -> Option<Vec<usize>> {
        let table = self.table.as_ref()?;
        table.probe(ctx.group, fb, ops, counters, point)
    }

    #[allow(clippy::too_many_arguments)]
    fn decompose_relations(
        &mut self,
        ctx: &InstanceCtx<BinaryGroup<'a>>,
        fb: &FactorBase<FastPoint>,
        ops: &mut GroupOps,
        counters: &mut OracleCounters,
        point: FastPoint,
        _a: u64,
        _b: u64,
    ) -> Vec<Relation> {
        let mut out = Vec::new();
        if self.free_pending {
            self.free_pending = false;
            if let Some(table) = self.table.as_ref() {
                let (rows, checked, modr_muls, modr_adds) =
                    table.free_rows(ctx.group, fb, ctx.r, ops);
                self.free_checked = checked;
                self.free_emitted = rows.len() as u64;
                self.free_modr_muls = modr_muls;
                self.free_modr_adds = modr_adds;
                out.extend(rows.into_iter().map(|columns| Relation::Row {
                    columns,
                    a: 0,
                    b: 0,
                }));
            }
        }
        if let Some(summands) = self.decompose(ctx, fb, ops, counters, point) {
            out.push(Relation::Summands(summands));
        }
        out
    }

    fn relation_counters(&self) -> BTreeMap<String, u64> {
        let mut m = BTreeMap::new();
        if self.free {
            m.insert("free_collisions_checked".to_string(), self.free_checked);
            m.insert("free_rows_emitted".to_string(), self.free_emitted);
        }
        m
    }

    fn relation_work_native(&self) -> BTreeMap<String, u64> {
        let mut m = BTreeMap::new();
        if self.free_modr_muls > 0 {
            m.insert("combination_modr_muls".to_string(), self.free_modr_muls);
        }
        if self.free_modr_adds > 0 {
            m.insert("combination_modr_adds".to_string(), self.free_modr_adds);
        }
        m
    }
}

#[cfg(test)]
mod ksum_frobenius_tests {
    use super::*;
    use crate::cryptanalysis::ic_boundary::{koblitz_instance, Calibration};
    use crate::cryptanalysis::ic_framework::{run_pipeline, PipelineSpec};

    fn ctx<'a>(
        inst: &BinaryInstance,
        g: &'a BinaryGroup<'a>,
        q: FastPoint,
    ) -> InstanceCtx<'a, BinaryGroup<'a>> {
        InstanceCtx {
            group: g,
            generator: inst.generator,
            target: q,
            r: inst.r,
            cofactor: inst.cofactor,
            group_order: inst.group_order,
            name: inst.name.clone(),
            field_degree: Some(inst.n),
        }
    }

    /// Every probe hit re-sums to its target, the fold leaves no
    /// mismatches, and the folded table finds every decomposition the
    /// unfolded `KSumTable` over the same signed points finds.
    #[test]
    fn folded_ksum_agrees_with_the_unfolded_table() {
        let inst = koblitz_instance(1, 17).expect("K1 n17");
        let g = BinaryGroup(&inst.fast);
        let c = ctx(&inst, &g, inst.generator);
        let (_, params) = Params::parse_spec("koblitz-closure:dimension=2").unwrap();
        let mut ops = GroupOps::default();
        let fb = KoblitzClosureBase { instance: &inst }
            .build(&c, &params, &mut ops)
            .unwrap();
        for k in [3u32, 4] {
            let folded = FrobeniusKSumTable::build(&inst, &fb, k).unwrap();
            let full = KSumTable::build_negation_folded(&g, &fb, k).unwrap();
            assert!(
                folded.entries * inst.n as u64 <= full.entries,
                "k={k}: {} folded entries against {} unfolded",
                folded.entries,
                full.entries
            );
            let mut ctr = OracleCounters::default();
            let mut lk = 0u64;
            let (mut both, mut only_full, mut only_fold) = (0, 0, 0);
            for e in 1..inst.r.min(4000) {
                let q = g.mul(&mut ops, inst.generator, e);
                let a = full.probe(&g, &fb, &mut ops, &mut lk, q);
                let b = folded.probe(&g, &fb, &mut ops, &mut ctr, q);
                if let Some(w) = &b {
                    assert_eq!(w.len(), k as usize);
                    let mut s = fb.points[w[0]];
                    for &i in &w[1..] {
                        s = g.add(&mut ops, s, fb.points[i]);
                    }
                    assert_eq!(s, q, "k={k} e={e}");
                }
                match (a.is_some(), b.is_some()) {
                    (true, true) => both += 1,
                    (true, false) => only_full += 1,
                    (false, true) => only_fold += 1,
                    _ => {}
                }
            }
            assert_eq!(ctr.frobfold_mismatches, 0);
            assert!(both > 0, "k={k}: no hits");
            assert_eq!(only_full, 0, "k={k}: the fold lost decompositions");
            // The unfolded table keeps one sum per key and sees nothing
            // the fold misses; the fold can see more (distinct-abscissa
            // sums both cover), so only the one direction is asserted.
            std::hint::black_box(only_fold);
        }
    }

    /// End to end: the pipeline recovers planted logs on a small Koblitz
    /// curve with the folded oracle over a Frobenius-closed base (two
    /// projected signed Frobenius orbits).
    #[test]
    fn ksum_frobenius_recovers_planted_logs() {
        let inst = koblitz_instance(1, 17).expect("K1 n17");
        let g = BinaryGroup(&inst.fast);
        for k in [3u32, 4] {
            for s in 0..3u64 {
                let planted = (1234 + 977 * s) % inst.r;
                let mut ops = GroupOps::default();
                let q = g.mul(&mut ops, inst.generator, planted);
                let c = ctx(&inst, &g, q);
                let (fb_name, fb_params) =
                    Params::parse_spec("compact-orbit-scan:columns=2,raw_x_cap=1000000").unwrap();
                let (name, oracle_params) =
                    Params::parse_spec(&format!("ksum-frobenius:m={k}")).unwrap();
                let ps = PipelineSpec {
                    factor_base: fb_name,
                    factor_base_params: fb_params,
                    oracle: name,
                    oracle_params,
                    linalg: "incremental-gauss".into(),
                    max_trials: 5_000_000,
                    seed: s,
                    ..Default::default()
                };
                let mut oracle = FrobeniusKSumOracle::new(k, &inst);
                let rep = run_pipeline(
                    &c,
                    &ps,
                    &CompactOrbitScanBase { instance: &inst },
                    &mut oracle,
                    planted,
                    &Calibration {
                        ns_per_add: 1.0,
                        ns_per_double: 1.0,
                        ..Default::default()
                    },
                    None,
                )
                .unwrap();
                assert!(
                    rep.verified && rep.recovered == Some(planted),
                    "k={k} s={s}: planted log not recovered"
                );
                let native = DecompositionOracle::<BinaryGroup>::setup_native(&oracle);
                assert!(native["canonicalisations"] > 0 && native["frobenius_maps"] > 0);
            }
        }
    }

    #[test]
    fn binary_sibling_pair_matches_group_law_and_bitop_gate_bound() {
        use crate::cryptanalysis::bitops::{Field, Prim, Widths};
        for n in [13u32, 17, 23, 41] {
            let w = Widths {
                field: Field::Binary { n },
                r_bits: n - 1,
            };
            let g = |p| w.gates(p).unwrap();
            let charged = g(Prim::GroupAdd) + g(Prim::FieldSqr) + 2 * g(Prim::FieldAdd);
            // BinaryGroup::sibling_pair performs: dx (1 add), inv (1 inv),
            // dy+ (1 add), lp (1 mul), lp2 (1 sqr), xp = lp2 ^ lp ^ dx ^ a (3 adds),
            // lm = lp ^ (x_J * inv) (1 mul + 1 add), lm2 (1 sqr), xm (3 adds) = 10 adds <= 11 adds.
            let performed = g(Prim::FieldInv)
                + 2 * g(Prim::FieldMul)
                + 2 * g(Prim::FieldSqr)
                + 10 * g(Prim::FieldAdd);
            assert!(
                charged >= performed,
                "n={n}: charged {charged} < performed {performed}"
            );
        }
        let inst = koblitz_instance(0, 13).expect("K0 n13");
        let g = BinaryGroup(&inst.fast);
        let mut ops = GroupOps::default();
        for e1 in 1..25u64 {
            let p = g.mul(&mut ops, inst.generator, e1);
            for e2 in (e1 + 1)..40u64 {
                let j = g.mul(&mut ops, inst.generator, e2);
                if p.x == j.x {
                    assert!(g.sibling_pair(&mut ops, p, j, true).is_none());
                    continue;
                }
                let sp = g.sibling_pair(&mut ops, p, j, true).expect("distinct x");
                let want_plus = g.add(&mut ops, p, j);
                let want_minus = g.add(&mut ops, p, g.neg(j));
                assert_eq!(sp.key_plus, g.key(&want_plus) >> 1);
                assert_eq!(sp.key_minus, g.key(&want_minus) >> 1);
                assert_eq!(
                    g.sibling_lift(&mut ops, p, sp.key_plus, sp.lambda_plus),
                    Some(want_plus)
                );
                assert_eq!(
                    g.sibling_lift(&mut ops, p, sp.key_minus, sp.lambda_minus),
                    Some(want_minus)
                );
            }
        }
    }

    #[test]
    fn ksum_frobenius_layout_prune_sib_free_and_cap_recover_exact_logs() {
        let inst = koblitz_instance(1, 17).expect("K1 n17");
        let g = BinaryGroup(&inst.fast);
        let c0 = ctx(&inst, &g, inst.generator);
        let (_, fb_params) =
            Params::parse_spec("compact-orbit-scan:columns=2,raw_x_cap=1000000,generator_orbit=1")
                .unwrap();
        let mut ops = GroupOps::default();
        let fb = CompactOrbitScanBase { instance: &inst }
            .build(&c0, &fb_params, &mut ops)
            .unwrap();

        let plain = FrobeniusKSumTable::build(&inst, &fb, 3).unwrap();
        let opt = FrobeniusKSumTable::build_with_opts(
            &inst,
            &fb,
            3,
            FrobeniusKSumOpts {
                layout: true,
                prune: true,
                sib: true,
                keep_collisions: true,
                max_entries: None,
            },
        )
        .unwrap();
        assert_eq!(opt.entries, plain.entries);
        assert!(opt.insert_attempts < plain.insert_attempts);
        assert_eq!(opt.build_frobenius_maps, 0);
        assert_eq!(opt.build_lookups, 0);
        assert!(opt.build_ops.adds * 2 < plain.build_ops.adds);
        assert!(opt.sib_second_points > 0);
        let (rows, checked, _, _) = opt.free_rows(&g, &fb, inst.r, &mut ops);
        assert!(checked > 0 && !rows.is_empty());

        for s in 0..4u64 {
            let planted = (5431 + 7919 * s) % inst.r;
            let q = g.mul(&mut ops, inst.generator, planted);
            let c = ctx(&inst, &g, q);
            let (fb_name, fb_p) = Params::parse_spec(
                "compact-orbit-scan:columns=2,raw_x_cap=1000000,generator_orbit=1",
            )
            .unwrap();
            let (name, oracle_params) = Params::parse_spec(
                "ksum-frobenius:m=3,layout=1,prune=1,sib=1,free=1,max_entries=600",
            )
            .unwrap();
            let ps = PipelineSpec {
                factor_base: fb_name,
                factor_base_params: fb_p,
                oracle: name,
                oracle_params,
                linalg: "incremental-gauss".into(),
                targets: crate::cryptanalysis::ic_framework::stages::Targets::StrideGenerator,
                max_trials: 1_000_000,
                seed: s,
                ..Default::default()
            };
            let mut oracle = FrobeniusKSumOracle::new(3, &inst);
            let rep = run_pipeline(
                &c,
                &ps,
                &CompactOrbitScanBase { instance: &inst },
                &mut oracle,
                planted,
                &Calibration {
                    ns_per_add: 1.0,
                    ns_per_double: 1.0,
                    ..Default::default()
                },
                None,
            )
            .unwrap();
            assert!(
                rep.verified && rep.recovered == Some(planted),
                "s={s}: planted log {planted} not recovered"
            );
        }

        let (_, scale_params) =
            Params::parse_spec("ksum-frobenius:m=4,layout=1,prune=1,sib=1,free=1,scale=1.35")
                .unwrap();
        let mut scale_oracle = FrobeniusKSumOracle::new(4, &inst);
        scale_oracle
            .prepare(&c0, &fb, &scale_params, &mut ops)
            .unwrap();
        let expected_cap = (1.35 * ((inst.r as f64) / (inst.n as f64)).sqrt()).round() as u64;
        assert_eq!(scale_oracle.table().unwrap().entries, expected_cap);

        let (_, both_params) =
            Params::parse_spec("ksum-frobenius:m=3,max_entries=100,scale=1.0").unwrap();
        assert!(FrobeniusKSumOracle::new(3, &inst)
            .prepare(&c0, &fb, &both_params, &mut ops)
            .is_err());
    }
}

#[cfg(test)]
mod coset_mitm_tests {
    use super::*;
    use crate::cryptanalysis::ic_boundary::{
        koblitz_instance, random_binary_instance, Calibration,
    };
    use crate::cryptanalysis::ic_framework::{run_pipeline, PipelineSpec};

    fn ctx<'a>(inst: &BinaryInstance, g: &'a BinaryGroup<'a>) -> InstanceCtx<'a, BinaryGroup<'a>> {
        InstanceCtx {
            group: g,
            generator: inst.generator,
            target: inst.generator,
            r: inst.r,
            cofactor: inst.cofactor,
            group_order: inst.group_order,
            name: inst.name.clone(),
            field_degree: Some(inst.n),
        }
    }

    fn ctx_q<'a>(
        inst: &BinaryInstance,
        g: &'a BinaryGroup<'a>,
        q: FastPoint,
    ) -> InstanceCtx<'a, BinaryGroup<'a>> {
            target: q,
            ..ctx(inst, g)

    /// A char2 instance with the wanted cofactor.
    fn char2(n: u32, max_h: u64, h: u64) -> BinaryInstance {
        for seed in 1..200u64 {
            if let Some(inst) = random_binary_instance(n, seed, max_h) {
                if inst.cofactor == h {
                    return inst;
                }
            }
        panic!("no cofactor-{h} instance at n = {n}");

    /// The decompositions of `samples` subgroup targets by `mitm` and by
    /// `mitm-coset` on one base: identical witnesses, identical lookups
    /// and verifying additions, a table that is no larger and builds with
    /// no more additions.  Returns `(plain, coset)` table-build adds and
    /// the number of hits.
    fn compare(
        fb: &FactorBase<FastPoint>,
        spec: &str,
        samples: u64,
    ) -> (u64, u64, usize, CosetFilter) {
        let g = BinaryGroup(&inst.fast);
        let c = ctx(inst, &g);
        let (_, params) = Params::parse_spec(spec).unwrap();
        let (mut plain, mut coset) = (MitmOracle::new(2), CosetMitmOracle::new(2));
        let (mut ops_p, mut ops_c) = (GroupOps::default(), GroupOps::default());
        plain.prepare(&c, fb, &params, &mut ops_p).unwrap();
        coset.prepare(&c, fb, &params, &mut ops_c).unwrap();
        let (tp, tc) = (plain.table.as_ref().unwrap(), coset.table.as_ref().unwrap());
        assert!(tc.entries <= tp.entries);
        assert!(tc.build_ops.adds <= tp.build_ops.adds);
        let (adds_p, adds_c) = (tp.build_ops.adds, tc.build_ops.adds);
        let (mut cp, mut cc) = (OracleCounters::default(), OracleCounters::default());
        let (mut dp, mut dc) = (GroupOps::default(), GroupOps::default());
        let mut hits = 0;
        let step = (inst.r / samples).max(1);
        let mut k = 1;
        while k < inst.r {
            let target = g.mul(&mut GroupOps::default(), inst.generator, k);
            let a = DecompositionOracle::<BinaryGroup>::decompose(
                &mut plain, &c, fb, &mut dp, &mut cp, target,
            );
            let b = DecompositionOracle::<BinaryGroup>::decompose(
                &mut coset, &c, fb, &mut dc, &mut cc, target,
            assert_eq!(a, b, "{spec}: k = {k}");
            hits += usize::from(a.is_some());
            k += step;
        assert!(
            cc.lookups <= cp.lookups,
            "lookups {} > {}",
            cc.lookups,
            cp.lookups
        );
        assert_eq!(dc, dp, "the probes' verifying additions differ");
        (adds_p, adds_c, hits, coset.coset.clone())

    /// char2, cofactor 2 (the free trace label) and cofactor 4 or 8 (the
    /// charged `[r]P` labels), folded and unfolded: same witnesses as
    /// `mitm`, lookups no larger, table additions strictly fewer on a
    /// base that straddles the classes.
    #[test]
    fn mitm_coset_agrees_with_mitm_on_char2() {
        for (n, max_h, h, dim) in [(15u32, 2u64, 2u64, 6usize), (15, 4, 4, 6), (15, 8, 8, 6)] {
            let inst = char2(n, max_h, h);
            let basis: Vec<u64> = (0..dim as u32).map(|i| 1u64 << i).collect();
            let fb = binary_subspace_factor_base(&inst, &basis);
            for spec in ["mitm:m=2", "mitm:m=2,negation_folded=1"] {
                let (plain, coset, hits, report) = compare(&inst, &fb, spec, 500);
                assert!(hits > 0, "h = {h} {spec}: no target decomposed");
                assert_eq!(report.mode, if h == 2 { "trace" } else { "scalar" });
                assert!(report.classes >= 2, "h = {h}: {report:?}");
                assert!(
                    coset < plain,
                    "h = {h} {spec}: {coset} vs {plain} additions"
                );

    /// Koblitz K_1 / F_2^17, cofactor 2: a divisor base containing x + 1
    /// (index 0) straddles both classes and is filtered; the (x + 1)-free
    /// divisor puts the whole base in one class, so the filter keeps
    /// every pair and builds exactly the plain table.
    fn mitm_coset_agrees_with_mitm_on_koblitz_and_is_inert_without_x_plus_1() {
        let inst = koblitz_instance(1, 17).expect("K1 n17");
        assert_eq!(inst.cofactor, 2);
        let c = ctx(&inst, &g);
        let build = |divisor: &str| {
            let (_, p) = Params::parse_spec(&format!("koblitz-orbit:divisor={divisor}")).unwrap();
            KoblitzOrbitBase { instance: &inst }
                .build(&c, &p, &mut GroupOps::default())
                .unwrap()
        };
        let mixed = build("0;1");
        let (plain, coset, hits, report) = compare(&inst, &mixed, "mitm:m=2", 400);
        assert!(hits > 0);
        assert_eq!((report.mode, report.classes), ("trace", 2));
        assert!(coset < plain, "mixed base: {coset} vs {plain}");
        let free = build("1");
        let (plain, coset, hits, report) = compare(&inst, &free, "mitm:m=2", 400);
        assert_eq!(report.classes, 1, "{report:?}");
        assert_eq!(coset, plain, "a one-class base must keep every pair");

    /// The flag-free oracle at `m = 3` labels nothing and builds the
    /// plain table; `mitm`'s own table is unchanged by this work.
    fn mitm_coset_is_inert_at_three_summands() {
        let inst = char2(15, 2, 2);
        let fb = binary_subspace_factor_base(&inst, &[1, 2, 4, 8, 16]);
        let (mut a, mut b) = (MitmOracle::new(3), CosetMitmOracle::new(3));
        let (mut oa, mut ob) = (GroupOps::default(), GroupOps::default());
        let none = Params::default();
        a.prepare(&c, &fb, &none, &mut oa).unwrap();
        b.prepare(&c, &fb, &none, &mut ob).unwrap();
        assert_eq!(b.coset.mode, "off");
        assert_eq!(oa, ob);
        assert!(DecompositionOracle::<BinaryGroup>::setup_native(&b).is_empty());

    /// Trace labels are free of group operations and counted: the oracle
    /// reports its field squarings as an uncharged counter, and the
    /// scalar labels are charged to the setup ledger.
    fn labelling_is_counted_trace_uncharged_scalar_charged() {
        let basis = [1u64, 2, 4, 8, 16, 32];
        for (h, scalar) in [(2u64, false), (4, true)] {
            let inst = char2(15, h, h);
            let g = BinaryGroup(&inst.fast);
            let c = ctx(&inst, &g);
            let mut o = CosetMitmOracle::new(2);
            let mut ops = GroupOps::default();
            o.prepare(&c, &fb, &Params::default(), &mut ops).unwrap();
            let native = DecompositionOracle::<BinaryGroup>::setup_native(&o);
            let table = o.table.as_ref().unwrap();
            if scalar {
                assert_eq!(native["mitm_coset_scalar_labels"], 1);
                assert!(!native.contains_key("mitm_coset_label_field_squarings_uncharged"));
                assert!(ops.scalar_mults > 0 && ops.adds > table.build_ops.adds);
            } else {
                assert_eq!(
                    native["mitm_coset_label_field_squarings_uncharged"],
                    fb.points.len() as u64 * 2 * u64::from(inst.n - 1)
                assert_eq!(ops, table.build_ops);

    /// End to end through the pipeline, same seed: identical relation
    /// counts and targets, both verified, set-up additions fewer.
    fn mitm_coset_pipeline_matches_mitm_relations() {
        let inst = char2(17, 2, 2);
        let planted = 12_345 % inst.r;
        let q = g.mul(&mut GroupOps::default(), inst.generator, planted);
        let c = ctx_q(&inst, &g, q);
        let calib = Calibration {
            ns_per_add: 1.0,
            ns_per_double: 1.0,
            ..Default::default()
        let mut reps = Vec::new();
        for oracle in ["mitm", "mitm-coset"] {
            let (fb_name, fb_params) = Params::parse_spec("binary-subspace:dimension=7").unwrap();
            let (name, oracle_params) = Params::parse_spec(&format!("{oracle}:m=2")).unwrap();
            let ps = PipelineSpec {
                factor_base: fb_name,
                factor_base_params: fb_params,
                oracle: name,
                oracle_params,
                linalg: "incremental-gauss".into(),
                max_trials: 5_000_000,
                seed: 3,
                ..Default::default()
            };
            let mut plain = MitmOracle::new(2);
            let mut coset = CosetMitmOracle::new(2);
            let o: &mut dyn DecompositionOracle<BinaryGroup> = if oracle == "mitm" {
                &mut plain
                &mut coset
            let rep = run_pipeline(
                &c,
                &ps,
                &BinarySubspaceBase { instance: &inst },
                o,
                planted,
                &calib,
                None,
            )
            .unwrap();
            assert!(rep.verified && rep.recovered == Some(planted), "{oracle}");
            reps.push(rep);
        let (a, b) = (&reps[0], &reps[1]);
        assert_eq!(
            a.decomposition.relations_found,
            b.decomposition.relations_found
        assert_eq!(a.decomposition.targets_tried, b.decomposition.targets_tried);
            a.decomposition.cost.group_ops,
            b.decomposition.cost.group_ops
        assert!(b.decomposition.setup.group_ops.adds < a.decomposition.setup.group_ops.adds);
        assert!(b.total_gae < a.total_gae);
}

/// `subtract` and `mitm` with `batch=1` (the default, one field inversion a
/// block) against `batch=0` (one an addition): the same relations in the
/// same order, the same charged additions and lookups, fewer inversions.
mod batch_inversion_tests {
    use crate::cryptanalysis::ic_boundary::roster_prime_instance;
    use rand::Rng;

    fn run<O: DecompositionOracle<PrimeCurve>>(
        mut oracle: O,
        params: &Params,
        batch: &str,
    ) -> (Vec<Option<Vec<usize>>>, GroupOps, u64, usize) {
        let inst = roster_prime_instance(16).unwrap();
        let g = inst.generator_point();
        let mut setup = GroupOps::default();
        let q = inst.curve.mul(&mut setup, g, 30_011 % inst.r);
        let ctx = InstanceCtx {
            group: &inst.curve,
            generator: g,
            field_degree: None,
        let mut fb_params = Params::default();
        fb_params.set("size", "40");
        let fb = PrimeAbscissaBase { instance: &inst }
            .build(&ctx, &fb_params, &mut setup)
        let mut params = params.clone();
        params.set("batch", batch);
        let mut ops = GroupOps::default();
        oracle.prepare(&ctx, &fb, &params, &mut ops).unwrap();
        let mut counters = OracleCounters::default();
        let mut rng = rand::rngs::StdRng::seed_from_u64(0xBA7C);
        let mut out = Vec::new();
        for _ in 0..3_000 {
            let (a, b) = (rng.gen_range(0..inst.r), rng.gen_range(0..inst.r));
            let mut t = GroupOps::default();
            let ga = inst.curve.mul(&mut t, g, a);
            let qb = inst.curve.mul(&mut t, q, b);
            let target = inst.curve.add(&mut t, ga, qb);
            out.push(oracle.decompose(&ctx, &fb, &mut ops, &mut counters, target));
        let hits = out.iter().filter(|r| r.is_some()).count();
        (out, ops, counters.lookups, hits)

    fn assert_same(
        name: &str,
        serial: &(Vec<Option<Vec<usize>>>, GroupOps, u64, usize),
        batched: &(Vec<Option<Vec<usize>>>, GroupOps, u64, usize),
    ) {
        assert!(serial.3 > 0, "{name}: the panel must find relations");
        assert_eq!(serial.0, batched.0, "{name}: relations differ");
            serial.1.adds, batched.1.adds,
            "{name}: charged additions differ"
        assert_eq!(serial.1.doubles, batched.1.doubles);
        assert_eq!(serial.2, batched.2, "{name}: lookups differ");
            batched.1.field_ops.invs < serial.1.field_ops.invs,
            "{name}: batching must cut inversions ({} vs {})",
            batched.1.field_ops.invs,
            serial.1.field_ops.invs

    fn batched_subtract_and_mitm_find_the_serial_relations() {
        let s0 = run(SubtractOracle::with_batch(false), &none, "0");
        let s1 = run(SubtractOracle::default(), &none, "1");
        assert_same("subtract", &s0, &s1);
        let mut folded = Params::default();
        folded.set("negation_folded", "1");
        for (m, params) in [(2, &none), (2, &folded), (3, &none), (3, &folded)] {
            let m0 = run(MitmOracle::new(m), params, "0");
            let m1 = run(MitmOracle::new(m), params, "1");
            assert_same(&format!("mitm m={m} {:?}", params.0), &m0, &m1);

mod wwalk_binary_tests {
    use crate::cryptanalysis::ic_boundary::Calibration;
    use crate::cryptanalysis::ic_framework::stages::Targets;
    use crate::cryptanalysis::koblitz_fast::FastPoint;

    /// Table B curve B15 (`research/ic_tableb_binary_ksum_20261115/specs/B15-r1.json`).
    fn b15() -> BinaryInstance {
        crate::cryptanalysis::ecbench_large_prime::binary_explicit_instance(
            15, 32771, 1, 21067, 32638, 16319, 31539, 28502,
        )
        .unwrap()

    /// One run; returns (verified, total GAE).
    fn run(inst: &BinaryInstance, oracle: &str, s: u64) -> (bool, f64) {
        let planted = (1234 + 7919 * s) % inst.r;
        let q = g.mul(&mut ops, inst.generator, planted);
            group: &g,
            name: "B15".into(),
        let (name, oracle_params) = Params::parse_spec(&format!("{oracle},seed={s}")).unwrap();
        let (_, fbp) = Params::parse_spec("binary-multiplier:size=2,mult=1").unwrap();
        let ps = PipelineSpec {
            factor_base: "binary-multiplier".into(),
            factor_base_params: fbp,
            oracle: name,
            oracle_params,
            targets: Targets::Walk,
            linalg: "incremental-gauss".into(),
            max_trials: 5_000_000,
            seed: s,
        let mut o = WWalkOracle::<FastPoint>::new();
        let rep = run_pipeline(
            &ctx,
            &ps,
            &BinaryMultiplierBase { instance: inst },
            &mut o,
            planted,
            &Calibration {
                ns_per_add: 1.0,
                ns_per_double: 1.0,
            },
            None,
        .unwrap();
        // [d]G = Q, checked here independently of the pipeline.
        let d = rep.recovered.expect("a recovered log");
        let mut o2 = GroupOps::default();
        assert!(g.mul(&mut o2, inst.generator, d) == q, "[d]G != Q");
        (rep.verified && d == planted, rep.total_gae)

    fn wwalk_solves_b15_plain_and_target_walk() {
        let inst = b15();
        for spec in [
            "wwalk:x=2.0,g=1,grow=2",
            "wwalk:x=2.0,g=1,grow=2,tw=2,cj=1,lazy=1",
        ] {
            for s in 0..4 {
                let (ok, ops) = run(&inst, spec, s);
                assert!(ok, "{spec} s={s}: planted log not recovered");
                assert!(ops > 0.0);
