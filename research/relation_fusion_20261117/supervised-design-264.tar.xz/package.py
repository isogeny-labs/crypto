from pathlib import Path
import shutil,hashlib,json,tarfile
repo=Path('/workspace/relation-supervisor-live');s=repo/'research/relation_fusion_20261117';pkg=Path('/workspace/supervised-design-package-264');pkg.mkdir()
def copy(src,dst):
 p=pkg/dst;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,p)
for name,k in [('neutral',254),('hypothetical20',256)]:
 shutil.copytree(f'/workspace/supervised-synthetic-{name}-{k}',pkg/f'synthetic-{name}')
for name,k in [('neutral',255),('hypothetical20',257)]:
 copy(f'/workspace/supervised-synthetic-{name}-analysis-{k}/analysis.json',Path('analysis')/f'{name}.json')
qualification=json.loads((s/'SUPERVISED_SYNTHETIC_QUALIFICATION_260.json').read_text())
for row in qualification['canaries']:
 mode=row['kind'];step=258 if mode=='clock' else 259
 for file in row['changed_files']:
  copy(Path(f'/workspace/supervised-synthetic-{mode}-canary-{step}')/file['path'],Path('canary-deltas')/mode/file['path'])
for k in [245,248,249,250,252,253,254,255,256,257,258,259,261]:
 for p in (s/'development-01').glob(f'*-{k}.*'):copy(p,Path('logs')/p.name)
for p in [Path('/workspace/supervisor-ledger-check-247.stdout'),Path('/workspace/supervisor-ledger-check-247.stderr')]:copy(p,Path('logs')/p.name)
shutil.copytree('/workspace/supervised-design-context-250',pkg/'context-250')
for k in [250,253]:
 for p in Path(f'/workspace/relation-native-qualifiers/supervisor-design-{k}').iterdir():copy(p,Path('bin')/f'design-{k}'/p.name)
for n in ['src/supervised_roster.rs','src/bin/supervised-compare.rs','src/bin/supervised-analyze.rs','src/bin/supervised-fixture.rs','Cargo.toml','Cargo.lock','SUPERVISED_COMPARE_DRAFT_248.md','SUPERVISED_DESIGN_TESTS_249.json','SUPERVISED_ROSTER_250.json','SUPERVISED_DESIGN_CONTEXT_250.json','SUPERVISED_SYNTHETIC_SOURCE_253.json','SUPERVISED_SYNTHETIC_QUALIFICATION_260.json','SUPERVISED_SYNTHETIC_REPORT_262.md','supervised-synthetic-report-262.typ','supervised-synthetic-report-262.pdf','visual-262/synthetic-qualification.svg']:
 copy(s/n,Path('study')/n)
copy(__file__,Path('package.py'))
index=[{'path':str(p.relative_to(pkg)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(pkg.rglob('*')) if p.is_file()]
(pkg/'index.json').write_text(json.dumps({'schema':'supervised-draft-analysis-archive/v1','explicitly_synthetic':True,'performance_observations_collected':0,'files':index},indent=2)+'\n')
archive=s/'supervised-design-264.tar.xz'
with tarfile.open(archive,'x:xz',preset=6,dereference=True) as tar:
 for p in sorted(pkg.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(pkg)),recursive=False)
digest=hashlib.sha256(archive.read_bytes()).hexdigest();(s/(archive.name+'.sha256')).write_text(f'{digest}  {archive.name}\n')
r={'schema':'supervised-design-archive-receipt/v1','archive':archive.name,'sha256':digest,'bytes':archive.stat().st_size,'indexed_files':len(index),'uncompressed_bytes':sum(v['bytes'] for v in index),'explicitly_synthetic':True,'performance_observations_collected':0,'qualified_analyzer_proof_replays':5040,'earlier_context':'context-250','final_source_context':'study/SUPERVISED_SYNTHETIC_SOURCE_253.json','canary_storage':'Only changed files are stored; all other canary files are byte-equal to synthetic-neutral. Use frozen fixture --mutate to reproduce complete copies.','signed_execution_verdict':False,'15x_admitted':False}
(s/'SUPERVISED_DESIGN_ARCHIVE_264.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
