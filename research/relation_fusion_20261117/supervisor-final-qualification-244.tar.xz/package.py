from pathlib import Path
import hashlib,json,shutil,tarfile
repo=Path('/workspace/relation-supervisor-live');s=repo/'research/relation_fusion_20261117';pkg=Path('/workspace/supervisor-final-package-244');pkg.mkdir(exist_ok=True)
def copy(src,dst):
 p=pkg/dst;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():
  assert p.read_bytes()==Path(src).read_bytes(),str(p)
 else:shutil.copy2(src,p)
for k in [234,240]:shutil.copytree(f'/workspace/native-supervised-qualification-{k}',pkg/f'raw-{k}',dirs_exist_ok=True)
shutil.copytree('/workspace/native-supervisor-20261123-238',pkg/'OS-238',dirs_exist_ok=True)
for p in (s/'development-01').glob('*'):
 if any(k in p.name for k in ['-234.','-235.','-236.','-237.','-238.','-239.','-240.','-241.']):copy(p,Path('logs')/p.name)
for sub in ['supervisor-237','supervisor-239']:
 for p in Path('/workspace/relation-native-qualifiers',sub).iterdir():copy(p,Path('bin')/sub/p.name)
for n in ['Cargo.toml','Cargo.lock','src/bin/supervised-qualify.rs','src/bin/supervised-audit.rs','src/packed_roster.rs','NATIVE_SUPERVISOR_PINS_239.json','NATIVE_SUPERVISOR_QUALIFICATION_238.json','NATIVE_SUPERVISOR_PLAN_230.md','SUPERVISOR_REFINEMENT_238.md','SUPERVISOR_PUBLICATION_234.json','SUPERVISOR_PUBLICATION_240.json','SUPERVISOR_FUNCTIONAL_OUTCOME_234.json','SUPERVISOR_FINAL_OUTCOME_240.json','SUPERVISOR_FUNCTIONAL_AUDIT_237.json','SUPERVISOR_AUDIT_SOURCE_237.json','SUPERVISOR_FINAL_AUDIT_241.json','PACKED_PINS_200.json','PARENT_TRACE_ANALYSIS_223.json','SUPERVISOR_REPORT_242.md','native-supervisor-report-242.typ','native-supervisor-report-242.pdf']:
 copy(s/n,Path('study')/n)
for p in (s/'native-supervisor').rglob('*'):
 if p.is_file() and 'target' not in p.relative_to(s/'native-supervisor').parts:copy(p,Path('study/native-supervisor')/p.relative_to(s/'native-supervisor'))
for p in (s/'visual-242').iterdir():copy(p,Path('study/visual-242')/p.name)
# Own frozen workers and fixed input bytes for complete packet context.
for k in [85,96,200]:copy(f'/workspace/relation-native-qualifiers/fusion-{k}/fused-native',Path('bin')/f'worker-{k}')
for p in [2147483647,9007199254740881]:
 for n in [3,4,6]:copy(f'/workspace/fusion-qualification-66/p{p}-n{n}-frontier/original.json',Path('inputs')/f'p{p}-n{n}.json')
copy(__file__,Path('package.py'))
idx=[{'path':str(p.relative_to(pkg)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(pkg.rglob('*')) if p.is_file()]
(pkg/'index.json').write_text(json.dumps({'schema':'supervisor-final-qualification-archive/v1','files':idx},indent=2)+'\n')
archive=s/'supervisor-final-qualification-244.tar.xz'
with tarfile.open(archive,'x:xz',preset=6) as tar:
 for p in sorted(pkg.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(pkg)),recursive=False)
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
(s/(archive.name+'.sha256')).write_text(f'{digest}  {archive.name}\n')
receipt={'schema':'supervisor-final-qualification-archive-receipt/v1','archive':archive.name,'archive_sha256':digest,'bytes':archive.stat().st_size,'indexed_files':len(idx),'uncompressed_bytes':sum(v['bytes'] for v in idx),'source_commit':'2647188b4a7f3d4ac5a3e6f72dcfed8fb60ce265','final_proof_cases':216,'final_launcher_pairs':108,'OS_tests':5,'timing_claim':False,'signed_execution_verdict':False,'earlier_context_archive':'supervisor-qualification-233.tar.xz'}
(s/'SUPERVISOR_ARCHIVE_244.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
