1. Freeze a fresh primal_controls variant fixing the inherited controls symbol collision. Reuse all five frozen positive inputs; run compile, small independent oracles, then complete conditional positive root replay. No primal root sets have yet been recovered.
2. Add high-coordinate positive controls and general integer-cubic extraction.
3. Restore global original-root exceptional/auxiliary/order closure and broader curve/extension scope.
4. Match genuine F4/F5/F6 all-roots baselines and review primary-source novelty.
