"""Fail-closed, cold-process all-root benchmark and release gate.

No unavailable, failed, truncated, or timed-out baseline is an infinite win.
Run the measurement command inside isolated_bench.py reserve, then evaluate
with that tool's completed evidence file. See performance/GATE.md.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import resource
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from statistics import median


BASELINES = ("F4", "F5", "F6")
PIPELINE = ["input", "field", "domain", "solve", "extract", "verify", "serialize"]
DEFAULTS = {"repetitions": 5, "min_hard_instances": 20,
            "min_baseline_seconds": 1.0, "min_geomean_speedup": 2.0,
            "max_instance_slowdown": 1.10, "max_aa_spread": 0.10,
            "timeout_seconds": 120.0, "memory_limit_mib": 4096}


def configuration_groups(manifest):
    """Separate executable configurations from the algorithm they truthfully run."""
    groups = {"candidate": ["candidate"]}
    for family in BASELINES:
        names = [name for name, registration in manifest["backends"].items()
                 if registration.get("algorithm", name) == family]
        groups[family] = names or [family]
    return groups


def configuration_names(manifest):
    return [name for names in configuration_groups(manifest).values() for name in names]


def digest_bytes(value):
    return hashlib.sha256(value).hexdigest()


def _integer(value):
    if type(value) is int:
        return value
    if isinstance(value, str):
        return int(value, 16 if value.lower().startswith("0x") else 10)
    raise ValueError("root coordinates must be exact integers or hexadecimal strings")


def normalized_roots(report, *, backend=None, instance=None):
    """Validate the all-root protocol and return an order-independent exact set."""
    if report.get("schema_version") != 1:
        raise ValueError("unsupported root report schema")
    if report.get("complete") is not True or report.get("verified") is not True:
        raise ValueError("all roots must be returned and exactly verified")
    if report.get("pipeline") != PIPELINE:
        raise ValueError("end-to-end pipeline is incomplete or out of order")
    if backend and report.get("algorithm") != backend:
        raise ValueError("algorithm identity does not match the registered backend")
    if instance:
        if report.get("instance_id") != instance["id"]:
            raise ValueError("instance identity mismatch")
        if report.get("input_sha256") != instance["sha256"]:
            raise ValueError("input digest mismatch")
    variables = report.get("variables")
    if (not isinstance(variables, list) or not variables or
            any(not isinstance(v, str) or not v for v in variables) or
            len(set(variables)) != len(variables)):
        raise ValueError("invalid ordered variable list")
    if not isinstance(report.get("field"), dict):
        raise ValueError("exact field representation is required")
    roots = report.get("roots")
    if not isinstance(roots, list):
        raise ValueError("explicit root tuples are required")
    normalized = []
    for root in roots:
        if not isinstance(root, (list, tuple)) or len(root) != len(variables):
            raise ValueError("root arity mismatch")
        values = tuple(_integer(value) for value in root)
        if any(value < 0 for value in values):
            raise ValueError("negative canonical field encoding")
        normalized.append(values)
    unique = frozenset(normalized)
    if len(unique) != len(normalized):
        raise ValueError("duplicate roots cannot inflate the root count")
    if type(report.get("root_count")) is not int or report["root_count"] != len(unique):
        raise ValueError("exact root count disagrees with the returned root set")
    return unique


def structural_hardness(problem):
    """Reject uncoupled/linear fixtures; hardness additionally needs measured cost."""
    variables = problem.get("variables", [])
    n = len(variables)
    equations = problem.get("equations", [problem.get("f", [])])
    from rootfinder.fields import make_field
    from rootfinder.solver import element
    field = make_field(problem.get("field", {}))
    graph = [set() for _ in range(n)]
    nonlinear = False
    for equation in equations:
        merged = {}
        for term in equation:
            powers = term.get("powers", [])
            if len(powers) != n or any(type(p) is not int or p < 0 for p in powers):
                raise ValueError("invalid sparse equation powers")
            coefficient = element(term.get("coefficient", 0), field)
            # x**q == x as a function on GF(q). This inexpensive reduction
            # prevents formally different terms cancelling on the entire
            # field from pretending to be a difficult nonlinear constraint.
            key = tuple(0 if power == 0 else 1 + (power - 1) % (field.order - 1)
                        for power in powers)
            merged[key] = field.add(merged.get(key, 0), coefficient)
        for powers, coefficient in merged.items():
            if not coefficient:
                continue
            support = [i for i, power in enumerate(powers) if power]
            nonlinear |= sum(powers) >= 2 and len(support) >= 2
            for i in support:
                graph[i].update(j for j in support if i != j)
    seen, pending = set(), [0] if n else []
    while pending:
        current = pending.pop()
        if current not in seen:
            seen.add(current)
            pending.extend(graph[current] - seen)
    return {"coupled_nonlinear": n >= 2 and nonlinear and len(seen) == n,
            "variables": n}


def verify_report_roots(report, problem):
    """Independently verify reported tuples against original finite-field equations.

    This supervisory check is outside the timed solver process. Each solver is
    additionally required to perform its own verification inside its interval.
    Completeness is compared across independent all-root algorithms, rather
    than inferred from this membership check alone.
    """
    from rootfinder.fields import make_field
    from rootfinder.polynomial import evaluate_poly, gcd_poly, divmod_poly, trim
    from rootfinder.solver import element

    roots = normalized_roots(report)
    if report["field"] != problem.get("field", {}):
        raise ValueError("reported field differs from original input representation")
    if report["variables"] != problem["variables"]:
        raise ValueError("reported variable order differs from original input")
    field = make_field(problem.get("field", {}))
    equations = problem.get("equations", [problem.get("f", [])])
    constraint = problem["L"]

    def poly(values, x):
        return evaluate_poly(tuple(element(v, field) for v in values), x, field)

    reduced_numerator = reduced_denominator = None
    if "coefficients" in constraint:
        numerator = trim(tuple(element(v, field) for v in constraint["coefficients"]), field)
        denominator = trim(tuple(element(v, field) for v in constraint.get("denominator", [1])), field)
        if not denominator:
            raise ValueError("zero denominator does not define a rational function")
        common = gcd_poly(numerator, denominator, field)
        reduced_numerator = divmod_poly(numerator, common, field)[0]
        reduced_denominator = divmod_poly(denominator, common, field)[0]

    def allowed(x):
        if "coefficients" in constraint:
            denominator = evaluate_poly(reduced_denominator, x, field)
            return denominator != 0 and evaluate_poly(reduced_numerator, x, field) == 0
        if "linearized" in constraint:
            value = element(constraint["linearized"].get("constant", 0), field)
            for term in constraint["linearized"]["terms"]:
                value = field.add(value, field.mul(element(term["coefficient"], field),
                    field.pow(x, field.characteristic ** term["power"])))
            return value == 0
        if "composition" in constraint:
            for mapping in constraint["composition"]:
                denominator = poly(mapping.get("denominator", [1]), x)
                if denominator == 0:
                    return False
                x = field.mul(poly(mapping["coefficients"], x), field.inv(denominator))
            return x == 0
        raise ValueError("unknown domain representation")

    for root in roots:
        for x in root:
            field.validate(x)
            if not allowed(x):
                raise ValueError("returned root violates the original domain constraint")
        for equation in equations:
            value = 0
            for term in equation:
                coefficient = element(term["coefficient"], field)
                for x, exponent in zip(root, term["powers"]):
                    coefficient = field.mul(coefficient, field.pow(x, exponent))
                value = field.add(value, coefficient)
            if value != 0:
                raise ValueError("returned root violates an original coupled equation")
    return roots


def read_manifest(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    manifest = json.loads(data)
    if manifest.get("schema_version") != 1:
        raise ValueError("manifest schema_version must be 1")
    policy = {**DEFAULTS, **manifest.get("policy", {})}
    if set(policy) != set(DEFAULTS):
        raise ValueError("unknown benchmark policy option")
    if any(isinstance(value, bool) or not isinstance(value, (int, float)) or
           not math.isfinite(value) for value in policy.values()):
        raise ValueError("all benchmark policy values must be finite numbers")
    # These are release floors. Stronger targets and smaller resource budgets
    # are configurable; a caller cannot make a toy benchmark a release gate.
    for key, floor in (("repetitions", 3), ("min_hard_instances", 20),
                       ("min_baseline_seconds", 1), ("min_geomean_speedup", 2)):
        if not isinstance(policy[key], (int, float)) or isinstance(policy[key], bool) or policy[key] < floor:
            raise ValueError(f"{key} must be at least {floor}")
    for key in ("repetitions", "min_hard_instances", "memory_limit_mib"):
        if type(policy[key]) is not int:
            raise ValueError(f"{key} must be an integer")
    if not 0 < policy["max_instance_slowdown"] <= 1.10:
        raise ValueError("max_instance_slowdown must be positive and no greater than 1.10")
    if not 0 < policy["max_aa_spread"] <= .10:
        raise ValueError("max_aa_spread must be positive and no greater than 0.10")
    if policy["timeout_seconds"] <= 0 or policy["memory_limit_mib"] <= 0:
        raise ValueError("resource limits must be positive")
    backends = manifest.get("backends", {})
    workdir = (path.parent / manifest.get("workdir", ".")).resolve()
    if "harness_sha256" in manifest and manifest["harness_sha256"] != digest_bytes(Path(__file__).read_bytes()):
        raise ValueError("preregistered measurement harness digest mismatch")
    if "candidate" not in backends:
        raise ValueError("a registered candidate backend is required")
    for name, backend in backends.items():
        algorithm = backend.get("algorithm", name)
        if algorithm not in ("candidate", *BASELINES) or (algorithm == "candidate" and name != "candidate"):
            raise ValueError(f"{name}: register a truthful candidate/F4/F5/F6 algorithm identity")
        command = backend.get("command")
        if command is not None and (not isinstance(command, list) or not command or
                                    any(not isinstance(arg, str) for arg in command)):
            raise ValueError(f"{name}: command must be an argument array")
        if command is not None and not backend.get("identity"):
            raise ValueError(f"{name}: source/algorithm identity must be recorded")
        for artifact, expected in backend.get("artifact_sha256", {}).items():
            local_artifact = (workdir / artifact).resolve()
            if not local_artifact.is_file() or digest_bytes(local_artifact.read_bytes()) != expected:
                raise ValueError(f"{name}: preregistered source/binary digest mismatch: {artifact}")
    instances = manifest.get("instances", [])
    ids = [entry.get("id") for entry in instances]
    if any(not isinstance(item, str) or not item for item in ids) or len(set(ids)) != len(ids):
        raise ValueError("instance ids must be unique nonempty strings")
    semantic_digests = set()
    for entry in instances:
        local = (path.parent / entry["path"]).resolve()
        content = local.read_bytes()
        if entry.get("sha256") != digest_bytes(content):
            raise ValueError(f"{entry['id']}: preregistered instance digest mismatch")
        problem = json.loads(content)
        semantic = digest_bytes(json.dumps(problem, sort_keys=True, separators=(",", ":")).encode())
        if semantic in semantic_digests:
            raise ValueError("duplicate mathematical input cannot inflate the preregistered panel")
        semantic_digests.add(semantic)
        entry["resolved_path"] = str(local)
        entry["structure"] = structural_hardness(problem)
    manifest["policy"] = policy
    manifest["manifest_sha256"] = digest_bytes(data)
    manifest["manifest_path"] = str(path)
    manifest["workdir"] = str(workdir)
    return manifest


def _limits(memory_mib, cpu):
    def configure():
        if memory_mib is not None:
            limit = int(memory_mib) * 1024 * 1024
            resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
        if cpu is not None:
            os.sched_setaffinity(0, {cpu})
    return configure


def run_process(command, *, timeout, workdir=None, env=None, memory_mib=None, cpu=None):
    """Reap one cold process with wait4, avoiding cumulative child RSS metrics.

    Output goes to temporary files, so verbose workers cannot deadlock on pipes.
    RSS is the largest individual process high-water mark, not summed tree RSS.
    Both timeout and normal exit clean up the command's process group.
    """
    started_unix = time.time()
    started = time.perf_counter()
    with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
        try:
            child = subprocess.Popen(command, cwd=workdir, env=env, stdout=stdout,
                                     stderr=stderr, start_new_session=True,
                                     preexec_fn=_limits(memory_mib, cpu))
        except (OSError, subprocess.SubprocessError) as error:
            return {"status": "launch_error", "command": command, "reason": str(error),
                    "wall_seconds": time.perf_counter() - started,
                    "started_unix": started_unix, "ended_unix": time.time()}
        timed_out = False
        while True:
            pid, status, usage = os.wait4(child.pid, os.WNOHANG)
            if pid:
                break
            if time.perf_counter() - started >= timeout:
                timed_out = True
                try:
                    os.killpg(child.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                deadline = time.perf_counter() + .20
                while time.perf_counter() < deadline:
                    pid, status, usage = os.wait4(child.pid, os.WNOHANG)
                    if pid:
                        break
                    time.sleep(.005)
                if not pid:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    pid, status, usage = os.wait4(child.pid, 0)
                break
            time.sleep(.002)
        elapsed = time.perf_counter() - started
        child.returncode = os.waitstatus_to_exitcode(status)
        # An exited wrapper must not leave a solver consuming resources.
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        stdout.seek(0)
        stderr.seek(0)
        out = stdout.read().decode("utf-8", errors="replace")
        err = stderr.read().decode("utf-8", errors="replace")
    return {"status": "timeout" if timed_out else ("ok" if child.returncode == 0 else "process_error"),
            "command": command, "exit_code": child.returncode, "wall_seconds": elapsed,
            "started_unix": started_unix, "ended_unix": time.time(), "stdout": out,
            "stderr": err, "stdout_sha256": digest_bytes(out.encode()),
            "user_seconds": usage.ru_utime, "system_seconds": usage.ru_stime,
            "peak_process_rss_kib": usage.ru_maxrss,
            "rss_scope": "maximum individual process high-water mark, not aggregate tree RSS",
            "memory_limit_scope": "per-process address space inherited by descendants",
            "minor_faults": usage.ru_minflt, "major_faults": usage.ru_majflt,
            "voluntary_switches": usage.ru_nvcsw, "involuntary_switches": usage.ru_nivcsw,
            "cpu": cpu}


def measure(manifest, *, cpu=None, invocation=None, output_path=None):
    policy = manifest["policy"]
    base_env = dict(os.environ)
    base_env.update(OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", RAYON_NUM_THREADS="1",
                    MKL_NUM_THREADS="1", PYTHONHASHSEED="0")
    records = []
    backends = manifest["backends"]

    def execute(instance, backend, round_number, kind="comparison", aa_arm=None):
        registration = backends.get(backend, {})
        command = registration.get("command")
        key = {"instance_id": instance["id"], "backend": backend, "round": round_number,
               "kind": kind, "aa_arm": aa_arm}
        if not command:
            records.append({**key, "status": "unavailable",
                            "reason": registration.get("reason", "no matched all-root backend registered")})
            return
        command = [part.replace("{python}", sys.executable).replace("{instance}", instance["resolved_path"])
                   for part in command]
        env = {**base_env, **registration.get("env", {}),
               "ROOTFINDER_INSTANCE_ID": instance["id"],
               "ROOTFINDER_INSTANCE_SHA256": instance["sha256"],
               "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "RAYON_NUM_THREADS": "1",
               "MKL_NUM_THREADS": "1", "PYTHONHASHSEED": "0"}
        result = run_process(command, timeout=policy["timeout_seconds"],
                             workdir=manifest["workdir"], env=env,
                             memory_mib=policy["memory_limit_mib"], cpu=cpu)
        if result["status"] == "ok":
            try:
                result["root_report"] = json.loads(result["stdout"])
                normalized_roots(result["root_report"], backend=registration.get("algorithm", backend), instance=instance)
                verify_report_roots(result["root_report"], json.loads(Path(instance["resolved_path"]).read_text()))
            except (ValueError, TypeError, KeyError) as error:
                result["status"] = "invalid_result"
                result["reason"] = str(error)
        records.append({**key, **result})

    # A/A precedes comparison and repeats the same command twice per round.
    # It diagnoses noise, never contributes a performance win.
    if manifest["instances"]:
        first = manifest["instances"][0]
        for backend in configuration_names(manifest):
            if backends.get(backend, {}).get("command"):
                for round_number in range(policy["repetitions"]):
                    execute(first, backend, round_number, "aa", 0)
                    execute(first, backend, round_number, "aa", 1)
    for instance in manifest["instances"]:
        for round_number in range(policy["repetitions"]):
            order = configuration_names(manifest)
            if round_number % 2:
                order.reverse()
            for backend in order:
                execute(instance, backend, round_number)
            if output_path:
                # Incremental evidence survives interruption; an incomplete
                # run can be inspected and never silently becomes a win.
                Path(output_path).write_text(json.dumps({"schema_version": 1,
                    "manifest_sha256": manifest["manifest_sha256"], "records": records,
                    "measurement_complete": False}, indent=2) + "\n")
    host = {"python": sys.version, "platform": platform.platform(), "logical_cpus": os.cpu_count(),
            "affinity": sorted(os.sched_getaffinity(0)), "benchmark_cpu": cpu}
    try:
        host["cpuinfo_sha256"] = digest_bytes(Path("/proc/cpuinfo").read_bytes())
        host["cpu_model"] = next(line.split(":", 1)[1].strip() for line in
                                Path("/proc/cpuinfo").read_text().splitlines() if line.startswith("model name"))
    except (OSError, StopIteration):
        pass
    return {"schema_version": 1, "manifest_sha256": manifest["manifest_sha256"],
            "measurement_complete": True, "invocation": invocation, "host": host,
            "accounting": "cold subprocess launch through complete JSON output; all pipeline stages included",
            "records": records}


def validate_isolation(raw, evidence):
    """Bind completed isolation evidence to this exact harness invocation."""
    if not evidence:
        return False, "completed isolated_bench evidence is missing"
    def command_identity(command):
        if not isinstance(command, list) or not command:
            return None
        executable = shutil.which(command[0])
        if executable:
            executable = str(Path(executable).resolve())
        return [executable or command[0], *command[1:]]
    for row in evidence:
        if row.get("schema") != "isolated-bench/1":
            continue
        payload = row.get("run", row)
        if command_identity(payload.get("command")) != command_identity(raw.get("invocation")):
            continue
        exit_code = payload.get("exit_status")
        contended = payload.get("contended", row.get("contended_samples", 0) > 0)
        cpus = row.get("reserved_cpus", payload.get("cpus", []))
        cpu = raw.get("host", {}).get("benchmark_cpu")
        if cpu is None or cpu not in cpus:
            return False, "harness child CPU was not pinned inside the reserved CPUs"
        if exit_code != 0 or contended:
            return False, "isolation command failed or was contended"
        occupancy = row.get("left_on_reserved")
        if (not isinstance(occupancy, dict) or
                set(occupancy) != {"user_threads", "kernel_threads"} or
                not isinstance(occupancy["user_threads"], list) or
                any(not isinstance(thread, str) for thread in occupancy["user_threads"]) or
                type(occupancy["kernel_threads"]) is not int or occupancy["kernel_threads"] < 0):
            return False, "reserved-CPU occupancy evidence is missing or has an unknown shape"
        if occupancy["user_threads"]:
            return False, "other unmovable threads remained on the benchmark CPUs"
        return True, None
    return False, "isolation evidence does not name this exact harness invocation"


def evaluate(manifest, raw, *, isolation=None):
    policy = manifest["policy"]
    incomplete, failures = [], []
    if raw.get("manifest_sha256") != manifest["manifest_sha256"]:
        failures.append("measurement manifest digest mismatch")
    if not raw.get("measurement_complete"):
        incomplete.append("measurement did not complete")
    isolated, isolation_reason = validate_isolation(raw, isolation)
    if not isolated:
        incomplete.append(isolation_reason)
    preregistration = manifest.get("preregistration", {})
    if not preregistration.get("registered_at_utc") or not preregistration.get("selection_rule"):
        incomplete.append("hard-panel preregistration timestamp and selection rule are missing")
    groups = configuration_groups(manifest)
    required = configuration_names(manifest)
    for name in required:
        if not manifest["backends"].get(name, {}).get("command"):
            incomplete.append(f"{name}: matched complete all-root backend unavailable")
    records = raw.get("records", [])
    by_key = {}
    for record in records:
        if record.get("kind") == "comparison":
            key = (record.get("instance_id"), record.get("backend"), record.get("round"))
            if key in by_key:
                failures.append(f"duplicate measurement {key}")
            by_key[key] = record
    aa_spreads = {}
    for name in required:
        if not manifest["backends"].get(name, {}).get("command"):
            continue
        arms = {}
        for record in records:
            if record.get("kind") == "aa" and record.get("backend") == name:
                arms[(record.get("round"), record.get("aa_arm"))] = record
        ratios = []
        for round_number in range(policy["repetitions"]):
            pair = [arms.get((round_number, arm)) for arm in (0, 1)]
            if any(row is None or row.get("status") != "ok" for row in pair):
                incomplete.append(f"{name}: missing/failed A/A round {round_number}")
                continue
            left, right = pair
            try:
                if normalized_roots(left["root_report"]) != normalized_roots(right["root_report"]):
                    failures.append(f"{name}: A/A exact root disagreement")
            except (ValueError, KeyError, TypeError) as error:
                failures.append(f"{name}: invalid A/A output: {error}")
            low, high = sorted([left["wall_seconds"], right["wall_seconds"]])
            if low <= 0 or not math.isfinite(high):
                failures.append(f"{name}: invalid A/A wall time")
            else:
                ratios.append(high / low - 1)
        if ratios:
            spread = max(ratios)
            aa_spreads[name] = spread
            if spread > policy["max_aa_spread"]:
                incomplete.append(f"{name}: A/A spread {spread:.3f} exceeds noise budget")
    rows, eligible = [], []
    for instance in manifest["instances"]:
        medians, minimums, root_sets, representations = {}, {}, {}, {}
        problems = []
        for name in required:
            times, roots, identities = [], [], []
            for round_number in range(policy["repetitions"]):
                record = by_key.get((instance["id"], name, round_number))
                if record is None:
                    problems.append(f"{name}: round {round_number} missing")
                    continue
                if record.get("status") != "ok":
                    status = record.get("status", "unknown")
                    problems.append(f"{name}: round {round_number} {status}")
                    if status != "unavailable":
                        failures.append(f"{instance['id']}/{name}: {status}; this run is not a speedup")
                    continue
                try:
                    report = record["root_report"]
                    algorithm = manifest["backends"].get(name, {}).get("algorithm", name)
                    result_roots = normalized_roots(report, backend=algorithm, instance=instance)
                    if "resolved_path" in instance:
                        result_roots = verify_report_roots(report, json.loads(Path(instance["resolved_path"]).read_text()))
                    wall = record["wall_seconds"]
                    if not isinstance(wall, (int, float)) or not math.isfinite(wall) or wall <= 0:
                        raise ValueError("invalid end-to-end wall time")
                    roots.append(result_roots)
                    identities.append(json.dumps([report["field"], report["variables"]], sort_keys=True))
                    times.append(wall)
                except (ValueError, TypeError, KeyError) as error:
                    failures.append(f"{instance['id']}/{name}: {error}")
                    problems.append(f"{name}: invalid exact root report")
            if len(times) == policy["repetitions"]:
                medians[name], minimums[name] = median(times), min(times)
                root_sets[name], representations[name] = roots[0], identities[0]
                if any(roots[0] != roots_i for roots_i in roots[1:]) or len(set(identities)) != 1:
                    failures.append(f"{instance['id']}/{name}: repeated outputs disagree")
        if root_sets and (len(set(root_sets.values())) != 1 or len(set(representations.values())) != 1):
            failures.append(f"{instance['id']}: exact roots or field/variable representations disagree")
        family_medians = {family: min(medians[name] for name in names if name in medians)
                          for family, names in groups.items() if any(name in medians for name in names)}
        baseline_times = [family_medians[name] for name in BASELINES if name in family_medians]
        declared_hard = instance.get("hard") is True
        structural = instance.get("structure", {}).get("coupled_nonlinear") is True
        comparable = all(name in medians for name in required) and not problems
        measured_hard = bool(baseline_times) and min(baseline_times) >= policy["min_baseline_seconds"]
        row = {"instance_id": instance["id"], "declared_hard": declared_hard,
               "coupled_nonlinear": structural, "all_baselines_comparable": comparable,
               "measured_hard_against_available_baselines": measured_hard,
               "median_e2e_seconds": medians, "minimum_e2e_seconds": minimums,
               "family_median_e2e_seconds": family_medians,
               "speedup_by_baseline": {name: family_medians[name] / medians["candidate"] for name in BASELINES
                                       if name in family_medians and "candidate" in medians},
               "speedup_by_configuration": {name: medians[name] / medians["candidate"] for name in required
                                             if name != "candidate" and name in medians and "candidate" in medians},
               "root_count": len(next(iter(root_sets.values()))) if root_sets else None,
               "problems": problems}
        if declared_hard and comparable and structural and measured_hard:
            fastest = min(family_medians[name] for name in BASELINES)
            row["speedup_vs_fastest"] = fastest / medians["candidate"]
            row["candidate_slowdown_vs_fastest"] = medians["candidate"] / fastest
            eligible.append(row)
            if row["candidate_slowdown_vs_fastest"] > policy["max_instance_slowdown"]:
                failures.append(f"{instance['id']}: candidate regresses against the fastest baseline")
        elif declared_hard:
            incomplete.append(f"{instance['id']}: preregistered hard instance lacks matched hard complete evidence")
        rows.append(row)
    if len(eligible) < policy["min_hard_instances"]:
        incomplete.append(f"only {len(eligible)} of {policy['min_hard_instances']} required hard instances qualify")
    speedup = math.exp(sum(math.log(row["speedup_vs_fastest"]) for row in eligible) / len(eligible)) if eligible else None
    if speedup is not None and speedup < policy["min_geomean_speedup"]:
        failures.append(f"geometric-mean end-to-end speedup {speedup:.4f} misses target")
    # INCOMPLETE takes priority when the comparison cannot be established.
    # Observed failures remain explicit even when another baseline is missing.
    status = "INCOMPLETE" if incomplete else ("FAIL" if failures else "PASS")
    return {"schema_version": 1, "status": status, "release_approved": status == "PASS",
            "policy": policy, "required_baselines": list(BASELINES),
            "required_configurations": required,
            "manifest_sha256": manifest["manifest_sha256"], "qualified_hard_instances": len(eligible),
            "geomean_speedup_vs_fastest_baseline": speedup, "aa_relative_spread": aa_spreads,
            "incomplete_reasons": list(dict.fromkeys(incomplete)),
            "observed_failures": list(dict.fromkeys(failures)), "instances": rows,
            "accounting": "whole cold subprocess, complete exact root tuples and JSON output",
            "isolation_verified": isolated,
            "claim_scope": "preregistered measured workloads on the recorded host; no universal speedup claim"}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="operation", required=True)
    run = commands.add_parser("run")
    run.add_argument("manifest")
    run.add_argument("--output", required=True)
    run.add_argument("--cpu", type=int)
    judge = commands.add_parser("evaluate")
    judge.add_argument("manifest")
    judge.add_argument("measurements")
    judge.add_argument("--isolation")
    judge.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    manifest = read_manifest(args.manifest)
    if args.operation == "run":
        raw = measure(manifest, cpu=args.cpu,
                      invocation=[sys.executable, *sys.argv],
                      output_path=args.output)
        Path(args.output).write_text(json.dumps(raw, indent=2) + "\n")
        print(json.dumps({"measurement_complete": True, "output": args.output,
                          "gate_status": "UNEVALUATED"}))
        return 0
    raw = json.loads(Path(args.measurements).read_text())
    evidence = [json.loads(line) for line in Path(args.isolation).read_text().splitlines() if line.strip()] if args.isolation else None
    report = evaluate(manifest, raw, isolation=evidence)
    Path(args.output).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "release_approved": report["release_approved"],
                      "qualified_hard_instances": report["qualified_hard_instances"], "output": args.output}))
    return 0 if report["release_approved"] else 3


if __name__ == "__main__":
    raise SystemExit(main())
