from pathlib import Path
import os,json,hashlib,subprocess,sys,re
r=Path('/workspace/generalized_roots');os.chdir(r);c=r/'research/autolab_cycle_20261109_v4';phase=sys.argv[1];pr=json.load(open('lab/research_program.json'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
 with p.open('x')as f:json.dump(x,f,indent=2);f.write('\n')
if phase=='primal':
 d='research/primal_enum_20261109_v4';rev='research/primal_enum_review_20261109_v4';eid='primal-enum-20261109-v4';cmd=[sys.executable,'-m','research.primal_enum_20261109_v4.worker',eid];arts=[d+'/raw.json.gz'];deps=[];inputs=['research/dual_ladder_20261109_v3/planted_inputs.json'];hyp='Exactbounded4Dprimalaffinelatticeenumeration+independentFractionenum, V=S²andboundedcubicrootfilter, allorderedresidualtriplesonall5plantedNISTcharts. Unknownoncaps/unsupportedrootheight;notoriginalglobalrootsorperformanceclaim.'
else:
 d='research/dual_ladder_20261109_v3';rev='research/dual_ladder_review_20261109_v3';eid='dual-ladder-'+phase+'-20261109-v3';cmd=[sys.executable,'-m','research.dual_ladder_20261109_v3.worker',eid,phase];arts=[d+'/raw-'+phase+'.json.gz']+([d+'/planted_inputs.json']if phase=='profile'else[]);deps=[]if phase=='controls'else['dual-ladder-controls-20261109-v3'];inputs=['lab/research/nist_presets.json'];hyp='Freshfixed320line5NIST8pair8hdualcertifiedladder repeated3cold withpaidsetup;verifiedplantedpositiveactualNISTnormsmustnotbeexcluded. Originalglobalrootsnull,nogenuineGBspeedclaim.'
assert(r/rev/'CODE_REVIEW.md').exists()and(r/rev/'SOURCE_PINS.json').exists();x=json.load(open(r/rev/'SOURCE_PINS.json'));pins=x.get('source_sha256',x.get('sha256',x.get('pins',{})));assert pins;sources={'lab/runner.py','performance_gate.py','performance/GATE.md'}
for p,h in pins.items():
 if isinstance(h,str)and len(h)==64:
  assert sha(r/p)==h,(p,h,sha(r/p))
  if not Path(p).is_absolute():sources.add(p)
for dr in [d,rev]:sources.update(str(p.relative_to(r))for p in(r/dr).iterdir()if p.suffix in('.cpp','.hpp','.py','.json','.md')and not p.name.startswith(('RESULTS','raw','planted_inputs')))
seen=set()
def include(path):
 if path in seen:return
 seen.add(path);p=(r/path).resolve();assert p.is_relative_to(r);sources.add(path)
 if p.suffix not in('.cpp','.hpp','.h'):return
 for q in re.findall(r'^\s*#include\s+"([^"]+)"',p.read_text(),re.M):
  dest=(p.parent/q).resolve()
  if dest.is_relative_to(r):include(str(dest.relative_to(r)))
  else:assert dest.is_file(),str(dest)
for p in list(sources):
 if Path(p).suffix in('.cpp','.hpp','.h'):include(p)
if(r/d/'PROVENANCE.json').exists():inputs.append(d+'/PROVENANCE.json')
pr['experiments'].append(dict(id=eid,hypothesis=hyp,command=cmd,source_paths=sorted(sources),input_paths=inputs,artifact_paths=arts,depends_on=deps,timeout_seconds=90,memory_limit_mb=4096,cpu=0,expected_sha256={p:sha(r/p)for p in sorted(sources|set(inputs))}));assert len(pr['experiments'])<=3
put(c/('PROGRAM_'+phase.upper()+'_FROZEN.json'),pr);q=r/'lab/research_program.json';q.unlink();put(q,pr);a=json.loads(subprocess.check_output([sys.executable,'-m','lab.runner','resume','--ledger','lab/ledger','--manifest','lab/research_program.json']));put(c/('RESUME_'+phase.upper()+'.json'),a);print(json.dumps(dict(registered=eid,ready=a.get('ready'),source_files=len(sources))))
