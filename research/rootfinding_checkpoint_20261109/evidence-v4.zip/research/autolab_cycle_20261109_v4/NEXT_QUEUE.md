1. Prove and independently test seven-feature equivalence, signed feature heights and dependency-aware h-block ranges before an actual complete NIST block panel.
2. Exercise quadratic/constant leaf branches beyond tiny controls, raise source heights with exact cubic recovery and restore every original root branch.
3. Read full recent Dual Coppersmith paper; distinguish hidden-root and all-roots contracts.
4. Complete genuine full-width matched baseline interfaces and required field-family evidence.
