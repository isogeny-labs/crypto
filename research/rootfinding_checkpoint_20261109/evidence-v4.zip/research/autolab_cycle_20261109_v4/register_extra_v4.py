from pathlib import Path
import json,hashlib,subprocess,sys,os,re
r=Path('/workspace/generalized_roots');os.chdir(r);c=r/'research/autolab_cycle_20261109_v4';kind=sys.argv[1]
if kind=='outer':
 d='research/outer_leads_20261109_v4';rev='research/outer_leads_review_20261109_v4';eid='outer-h-oracle-20261109-v4';cmd=[sys.executable,'-m','research.outer_leads_20261109_v4.oracle',eid];inputs=[];arts=[];hyp='Fixed two-anchor/h elimination uses nine weighted-degree4 monomials; whole h-block certificates preserve every supported residual triple, including repeated roots, with kappa zero unresolved. Independent 4x4 literal norm oracle exercises char3. No global search or speedup claim.'
else:
 d='research/primal_parabola_20261109_v5';rev='research/primal_parabola_review_20261109_v5';eid='primal-parabola-20261109-v5';cmd=[sys.executable,'-m','research.primal_parabola_20261109_v5.worker',eid];inputs=['research/dual_ladder_20261109_v3/planted_inputs.json'];arts=[d+'/raw.json.gz'];hyp='Exact quadratic final-leaf constraint V=S² reduces lattice visits with all degenerate branches preserved; same five planted positive inputs, complete conditional tuple sets versus independent full-box Fraction enumeration. Compare work only; no qualified timingratio.'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
 with p.open('x')as f:json.dump(x,f,indent=2);f.write('\n')
x=json.load(open(r/rev/'SOURCE_PINS.json'));pins=x.get('sha256',x.get('source_sha256',{}));assert pins
sources={'lab/runner.py','performance_gate.py','performance/GATE.md'}
for p,h in pins.items():
 assert sha(Path(p) if Path(p).is_absolute() else r/p)==h,p
 if not Path(p).is_absolute():sources.add(p)
for dr in [d,rev]:sources.update(str(p.relative_to(r))for p in (r/dr).iterdir()if p.suffix in ('.cpp','.hpp','.py','.json','.md')and not p.name.startswith(('RESULT','raw')))
seen=set()
def include(path):
 if path in seen:return
 seen.add(path);p=(r/path).resolve();assert p.is_relative_to(r);sources.add(path)
 if p.suffix not in ('.cpp','.hpp','.h'):return
 for q in re.findall(r'^\s*#include\s+"([^"]+)"',p.read_text(),re.M):
  target=(p.parent/q).resolve()
  if target.is_relative_to(r):include(str(target.relative_to(r)))
  else:assert target.is_file()
for p in list(sources):
 if Path(p).suffix in ('.cpp','.hpp','.h'):include(p)
pr=json.load(open('lab/research_program.json'));assert len(pr['experiments'])<3
pr['experiments'].append(dict(id=eid,hypothesis=hyp,command=cmd,source_paths=sorted(sources),input_paths=inputs,artifact_paths=arts,depends_on=[],timeout_seconds=90,memory_limit_mb=4096,cpu=0,expected_sha256={p:sha(r/p)for p in sorted(sources|set(inputs))}))
put(c/('PROGRAM_'+kind.upper()+'_FROZEN.json'),pr);path=r/'lab/research_program.json';path.unlink();put(path,pr)
out=json.loads(subprocess.check_output([sys.executable,'-m','lab.runner','resume','--ledger','lab/ledger','--manifest','lab/research_program.json']));put(c/('RESUME_'+kind.upper()+'.json'),out);print(json.dumps({'registered':eid,'sources':len(sources)}))
