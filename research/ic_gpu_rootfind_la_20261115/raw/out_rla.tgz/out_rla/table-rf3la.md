| session | arm | method | curve | log2 r | verified | mean S | 95% interval | theory S | S / theory | S / floor | S / reference | lower bound | med wall ms | levels | flags |
|---|---|---|---|---:|---:|---:|---|---:|---:|---:|---:|---|---:|---|---|
| ECBS1h5d935fcbaf36 | rho-neg | rho.negation | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 0.858 (heavy tail; more runs needed) | [0.225, 3.275] indicative | 0.886 | 0.968 | 0.968 | 1.000 | yes | 44.706 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rho-neg | rho.negation | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 0.770 | [0.290, 2.048] indicative | 0.886 | 0.869 | 0.869 | 1.000 | yes | 96.771 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-cpu-gauss-F2048 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 291.931 | [289.350, 294.534] indicative | – | – | 329.408 | 340.378 | yes | 5698.021 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-cpu-gauss-F2048 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 568.103 | [562.297, 573.970] indicative | – | – | 641.036 | 737.477 | yes | 20385.805 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-cpu-echelon-F2048 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 291.931 | [289.350, 294.534] indicative | – | – | 329.408 | 340.378 | yes | 5418.355 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-cpu-echelon-F2048 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 568.103 | [562.297, 573.970] indicative | – | – | 641.036 | 737.477 | yes | 19926.229 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-gpup-gauss-F2048 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 291.931 | [289.350, 294.534] indicative | – | – | 329.408 | 340.378 | yes | 291.635 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-gpup-gauss-F2048 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 568.103 | [562.297, 573.970] indicative | – | – | 641.036 | 737.477 | yes | 395.277 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-gpup-echelon-F2048 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 291.931 | [289.350, 294.534] indicative | – | – | 329.408 | 340.378 | yes | 127.032 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-gpup-echelon-F2048 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 568.103 | [562.297, 573.970] indicative | – | – | 641.036 | 737.477 | yes | 240.007 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-cpu-gauss-F4096 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 166.602 | [164.371, 168.863] indicative | – | – | 187.990 | 194.250 | yes | 8143.935 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-cpu-gauss-F4096 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 295.200 | [292.666, 297.756] indicative | – | – | 333.097 | 383.210 | yes | 20095.274 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-cpu-echelon-F4096 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 166.602 | [164.371, 168.863] indicative | – | – | 187.990 | 194.250 | yes | 6417.715 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-cpu-echelon-F4096 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 295.200 | [292.666, 297.756] indicative | – | – | 333.097 | 383.210 | yes | 17969.055 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-gpup-gauss-F4096 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 166.602 | [164.371, 168.863] indicative | – | – | 187.990 | 194.250 | yes | 1559.567 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-gpup-gauss-F4096 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 295.200 | [292.666, 297.756] indicative | – | – | 333.097 | 383.210 | yes | 1568.183 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-gpup-echelon-F4096 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 166.602 | [164.371, 168.863] indicative | – | – | 187.990 | 194.250 | yes | 283.076 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-gpup-echelon-F4096 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 295.200 | [292.666, 297.756] indicative | – | – | 333.097 | 383.210 | yes | 306.735 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-gpup-echelon-aa-F4096 | ic.pipeline | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 166.602 | [164.371, 168.863] indicative | – | – | 187.990 | 194.250 | yes | 283.889 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rf3-gpup-echelon-aa-F4096 | ic.pipeline | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 295.200 | [292.666, 297.756] indicative | – | – | 333.097 | 383.210 | yes | 309.901 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rho-neg-aa | rho.negation | icv1-fp38-tm68843-fe40d997 | 37.39 | 6/6 | 0.858 (heavy tail; more runs needed) | [0.225, 3.275] indicative | 0.886 | 0.968 | 0.968 | 1.000 | yes | 43.340 | L0×6 | – |
| ECBS1h5d935fcbaf36 | rho-neg-aa | rho.negation | icv1-fp40-tm106485-8d2c6f92 | 39.34 | 6/6 | 0.770 | [0.290, 2.048] indicative | 0.886 | 0.869 | 0.869 | 1.000 | yes | 97.131 | L0×6 | – |
