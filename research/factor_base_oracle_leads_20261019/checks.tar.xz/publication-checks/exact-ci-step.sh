set -euo pipefail
study=research/factor_base_oracle_leads_20261019
manifest="$study/audit/Cargo.toml"
cargo fmt --manifest-path "$manifest" -- --check
cargo test --locked --release --manifest-path "$manifest"
cargo clippy --locked --release --manifest-path "$manifest" --all-targets -- -D warnings
cargo build --locked --release --manifest-path "$manifest"
replay="$RUNNER_TEMP/factor-base-oracle-evidence"
mkdir -p "$replay"
sha256sum -c "$study/SOURCE_SHA256SUMS"
(cd "$study" && sha256sum -c runs.tar.xz.sha256)
tar -xJf "$study/runs.tar.xz" -C "$replay"
(cd "$replay" && sha256sum -c runs/SHA256SUMS)
"$CARGO_TARGET_DIR/release/factor-base-sweep" verify --run "$replay/runs/experiment"
"$CARGO_TARGET_DIR/release/factor-base-oracle-audit" "$replay/runs/experiment" "$study/inputs/models.json" > "$replay/independent-audit.json"
cmp "$study/analysis.json" "$replay/independent-audit.json"
