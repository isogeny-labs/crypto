import json,hashlib,re,shlex
from pathlib import Path
root=Path('/workspace/crypto-pr2134-head819-review')
records=Path('/workspace/fb-oracle-leads-20261019')
before=json.loads((records/'native-inputs-frozen.json').read_text())
after=json.loads((records/'native-inputs-after.json').read_text())
assert before==after
known={e['path']:e for e in before['entries']}
for p,e in known.items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==e['sha256'],p
text=re.sub(r'\x1b\[[0-9;]*m','',(records/'library.log').read_text())
m=re.search(r'Running unittests src/lib.rs \(([^)]+)\)',text)
assert m,'unit binary path in actual command log'
binary=Path(m[1]);binary=binary if binary.is_absolute() else root/binary
assert binary.is_file(),binary
dep=binary.with_suffix('.d')
if not dep.exists():dep=binary.parent/(binary.name+'.d')
first=dep.read_text().splitlines()[0].split(': ',1)[1]
inputs=shlex.split(first)
matched=[];generated=[]
for item in inputs:
 p=Path(item);p=(p if p.is_absolute() else root/p).resolve()
 rel=p.relative_to(root).as_posix() if p.is_relative_to(root) else None
 if rel in known:
  assert hashlib.sha256(p.read_bytes()).hexdigest()==known[rel]['sha256'],rel
  matched.append(rel)
 else:generated.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
fixture=(root/'docs/curves/traits.json').read_bytes()
raw=binary.read_bytes();offset=raw.find(fixture);assert offset>=0,'exact trait literal binding'
result={'source':before['head'],'frozen_native_inputs_unchanged':len(known),'unit_binary':str(binary),'binary_sha256':hashlib.sha256(raw).hexdigest(),'compiled_tracked_dependencies_match':len(set(matched)),'generated_dependencies':generated,'traits_fixture_sha256':hashlib.sha256(fixture).hexdigest(),'traits_literal_offset':offset,'note':'Build provenance only. Actual library command log and exit determine its pass/fail.'}
(records/'library-binding.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
