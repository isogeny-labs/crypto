| session | arm | method | curve | log2 r | verified | mean S | 95% interval | theory S | S / theory | S / floor | S / reference | lower bound | med wall ms | levels | flags |
|---|---|---|---|---:|---:|---:|---|---:|---:|---:|---:|---|---:|---|---|
| ECBS1h02eab8adbf52 | rho-neg | rho.negation | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 0.712 | [0.253, 2.002] indicative | 0.886 | 0.803 | 0.803 | 1.000 | yes | 3.088 | L0×4 | – |
| ECBS1h02eab8adbf52 | rho-neg | rho.negation | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 1.237 | [0.863, 1.774] indicative | 0.886 | 1.396 | 1.396 | 1.000 | yes | 12.951 | L0×4 | – |
| ECBS1h02eab8adbf52 | rho-neg | rho.negation | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 1.102 | [0.284, 4.279] indicative | 0.886 | 1.244 | 1.244 | 1.000 | yes | 16.748 | L0×4 | – |
| ECBS1h02eab8adbf52 | rf2-cpu-F4096 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 6028.349 | [1047.641, 34688.402] indicative | – | – | 6802.263 | 8467.837 | yes | 3081.554 | L0×4 | – |
| ECBS1h02eab8adbf52 | rf2-cpu-F4096 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 13432.811 | [407.575, 442716.830] indicative | – | – | 15157.304 | 10858.435 | yes | 16966.790 | L0×4 | – |
| ECBS1h02eab8adbf52 | rf2-cpu-F4096 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 25111.488 | [15225.634, 41416.129] indicative | – | – | 28335.280 | 22784.015 | yes | 40621.138 | L0×4 | – |
| ECBS1h02eab8adbf52 | rf2-mt-F4096 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 6028.349 | [1047.641, 34688.402] indicative | – | – | 6802.263 | 8467.837 | yes | 624.128 | L0×4 | – |
| ECBS1h02eab8adbf52 | rf2-mt-F4096 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 13432.811 | [407.575, 442716.830] indicative | – | – | 15157.304 | 10858.435 | yes | 3334.076 | L0×4 | – |
| ECBS1h02eab8adbf52 | rf2-mt-F4096 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 25111.488 | [15225.634, 41416.129] indicative | – | – | 28335.280 | 22784.015 | yes | 8003.894 | L0×4 | – |
| ECBS1h02eab8adbf52 | rf2-gpud-F4096 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 6028.349 | [1047.641, 34688.402] indicative | – | – | 6802.263 | 8467.837 | yes | 158.848 | L0×4 | – |
| ECBS1h02eab8adbf52 | rf2-gpud-F4096 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 13432.811 | [407.575, 442716.830] indicative | – | – | 15157.304 | 10858.435 | yes | 228.622 | L0×4 | – |
| ECBS1h02eab8adbf52 | rf2-gpud-F4096 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 25111.488 | [15225.634, 41416.129] indicative | – | – | 28335.280 | 22784.015 | yes | 336.910 | L0×4 | – |
