# cpu profile: unlabelled

- status: **ok**
- command: `/workspace/ic-frozen-20261025/ic_quartic_core_probe-before narrow 6`
- binary: `/workspace/ic-frozen-20261025/ic_quartic_core_probe-before` sha256 `81ab248653df3b5d…`
- commit: `674350451829` (0 dirty tracked files)
- host: AMD EPYC 9V74 80-Core Processor, 1 logical CPUs, kernel 6.18.55, PMU absent, perf_event_paranoid 2
- valgrind: valgrind-3.24.0
- isolation: none; wall 0.194 s (profiled run: not a timing measurement)
- started: 2026-10-25T19:31:14Z

## Hotspots (callgrind, self Ir)

Total: 8774220 Ir (deterministic, simulated; not cycles).

| # | self % | Ir | function | object |
|---|---:|---:|---|---|
| 1 | 53.09 | 4658283 | `<crypto_lib::cryptanalysis::gaudry_quartic_bin::Fq4>::new` | ic_quartic_core_probe-before |
| 2 | 24.08 | 2113080 | `<crypto_lib::cryptanalysis::gaudry_quartic_bin::Fq4>::reduce` | ic_quartic_core_probe-before |
| 3 | 11.39 | 999664 | `<crypto_lib::cryptanalysis::gaudry_quartic_bin::Fq4>::mul_impl` | ic_quartic_core_probe-before |
| 4 | 3.86 | 338619 | `<alloc::vec::Vec<[u16; 4]> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<[u16; 4], core::iter::adapters::map::Map<core::ops::range::Range<usize>, <crypto_lib::cryptanalysis::gaudry_quartic_bin::Fq4>::mat_rank::{closure#0}>>>::from_iter` | ic_quartic_core_probe-before |
| 5 | 2.06 | 181063 | `free` | libc.so.6 |
| 6 | 1.3 | 114209 | `malloc` | libc.so.6 |
| 7 | 0.55 | 48464 | `0x000000000000a220` | ld-linux-x86-64.so.2 |
| 8 | 0.5 | 43761 | `0x000000000000e870` | ld-linux-x86-64.so.2 |
| 9 | 0.49 | 42568 | `0x0000000000064ff0` | libc.so.6 |
| 10 | 0.35 | 30922 | `0x000000000000ae90` | ld-linux-x86-64.so.2 |
| 11 | 0.29 | 25020 | `__rustc::__rdl_alloc` | ic_quartic_core_probe-before |
| 12 | 0.26 | 23226 | `0x0000000000013780` | ld-linux-x86-64.so.2 |
| 13 | 0.24 | 20988 | `__strtoul_internal` | libc.so.6 |
| 14 | 0.2 | 17276 | `0x0000000000024740` | ld-linux-x86-64.so.2 |
| 15 | 0.11 | 9253 | `0x000000000000a0a0` | ld-linux-x86-64.so.2 |
| 16 | 0.09 | 7938 | `0x0000000000013e00` | ld-linux-x86-64.so.2 |
| 17 | 0.06 | 5366 | `0x0000000000015f00` | ld-linux-x86-64.so.2 |
| 18 | 0.05 | 4745 | `0x00000000000a0fe0` | libc.so.6 |
| 19 | 0.04 | 3750 | `0x0000000000007cb0` | ld-linux-x86-64.so.2 |
| 20 | 0.04 | 3520 | `_IO_sputbackc` | libc.so.6 |
| 21 | 0.04 | 3339 | `getdelim` | libc.so.6 |
| 22 | 0.04 | 3238 | `core::slice::memchr::memrchr_aligned` | ic_quartic_core_probe-before |
| 23 | 0.03 | 2782 | `__rustc::__rust_no_alloc_shim_is_unstable_v2` | ic_quartic_core_probe-before |
| 24 | 0.03 | 2780 | `__rustc::__rdl_dealloc` | ic_quartic_core_probe-before |
| 25 | 0.03 | 2780 | `__rustc::__rust_alloc` | ic_quartic_core_probe-before |

## Files

- `annotate-inclusive.txt`
- `annotate.txt`
- `callgrind.out`
- `command.stderr`
- `command.stdout`
- `hotspots.json`
- `hotspots.svg`
- `manifest.json`

Raw profiler output (perf.data, *.ncu-rep, *.nsys-rep, callgrind.out) is large: push it with `crypto store push` (AGENTS.md section 13) rather than committing it.
