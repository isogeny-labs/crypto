"""Try FLINT on the smaller composite cofactors exposed by the first retry.

All new factors are product-checked and primality-proven. The first retry
records remain unchanged. A timeout retains their certified partial factors.
"""
import hashlib
import json
import multiprocessing
from pathlib import Path
import time

from sage.all import ZZ, prod
from dissect.utils.utils import timeout

ROOT=Path(__file__).resolve().parent
LIMIT=120


def run(r):
    started=time.monotonic()
    original=[ZZ(q) for q in r['proven_prime_factors']]
    composites=[]
    attempts=[]
    for text in r['unresolved_composite_factors']:
        n=ZZ(text)
        result=timeout(n.factor,kwargs={'algorithm':'flint'},timeout_duration=LIMIT)
        if isinstance(result,str):
            composites.append(n)
            attempts.append({'input':text,'algorithm':'FLINT','budget_seconds':LIMIT,'outcome':result})
        else:
            fs=[ZZ(q) for q,e in result for _ in range(e)]
            assert prod(fs)==n
            for q in fs:
                (original if q.is_prime(proof=True) else composites).append(q)
            attempts.append({'input':text,'algorithm':'FLINT','budget_seconds':LIMIT,
                             'output_factors':[str(q) for q in fs]})
    assert prod(original+composites)==ZZ(r['integer'])
    assert all(q.is_prime(proof=True) for q in original)
    updated={'id':r['id'],'integer':r['integer'],'requests':r['requests'],
        'source_factor_record_sha256':hashlib.sha256((ROOT/(r['id']+'.json')).read_bytes()).hexdigest(),
        'attempts':attempts,'complete':not composites,
        'proven_prime_factors':[str(q) for q in sorted(original)],
        'unresolved_composite_factors':[str(q) for q in sorted(composites)],
        'elapsed_seconds':time.monotonic()-started}
    (ROOT/(r['id']+'-residual.json')).write_text(json.dumps(updated,indent=2)+'\n')
    print(r['id'],'FLINT complete='+str(updated['complete']),flush=True)


def main():
    data=json.loads((ROOT/'factorization-results.json').read_text())
    pending=[r for r in data['results'] if not r['complete']]
    ctx=multiprocessing.get_context('fork')
    workers=[ctx.Process(target=run,args=(r,)) for r in pending]
    for p in workers:p.start()
    for p in workers:p.join()
    assert all(p.exitcode==0 for p in workers)
    results=[json.loads((ROOT/(r['id']+'-residual.json')).read_text()) for r in pending]
    (ROOT/'residual-factorization-results.json').write_text(json.dumps(results,indent=2)+'\n')


if __name__=='__main__':
    main()
