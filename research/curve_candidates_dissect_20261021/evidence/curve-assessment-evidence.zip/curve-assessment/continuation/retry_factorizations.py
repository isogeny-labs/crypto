"""Resolve the original missing factorizations without altering the raw run.

Deduplicates identical integer targets, reuses already certified trace factors,
then applies a longer PARI factor budget and bounded, deterministic GMP-ECM.
Every reported prime is independently proven, and every product is checked.
"""
import collections
import datetime
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import re
import subprocess
import time
import traceback

from sage.all import ZZ, factor, prod, proof
from sympy import factorint
from dissect.utils.utils import timeout

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
PARI_SECONDS=120
ECM_SECONDS=120
WORKERS=4


def save(path,value):
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value,indent=2)+'\n')
    temp.replace(path)


def solve_target(task):
    os.setsid()
    proof.arithmetic(True)
    started=time.monotonic()
    target=ZZ(task['value'])
    path=ROOT/(task['id']+'.json')
    r={'id':task['id'],'integer':str(target),'requests':task['requests'],
       'pari_budget_seconds':PARI_SECONDS,'ecm_budget_seconds':ECM_SECONDS,
       'methods':[],'complete':False,'proven_prime_factors':[],
       'unresolved_composite_factors':[]}
    def checkpoint(parts):
        assert prod(parts)==target
        primes=[];composites=[]
        for q in sorted(parts):
            (primes if q.is_prime(proof=True) else composites).append(str(q))
        r.update(proven_prime_factors=primes,unresolved_composite_factors=composites,
                 complete=not composites,elapsed_seconds=round(time.monotonic()-started,6))
        save(path,r)
    try:
        small=factorint(int(target),limit=10000,use_ecm=False)
        parts=[ZZ(q) for q,e in small.items() for _ in range(e)]
        r['methods'].append({'method':'SymPy bounded small-factor search','limit':10000})
        checkpoint(parts)
        pending=[q for q in parts if not q.is_prime(proof=True)]
        if pending:
            # Normally there is a single composite after bounded preprocessing.
            for n in pending:
                fs=timeout(factor,args=[n],kwargs={'proof':True},timeout_duration=PARI_SECONDS)
                if isinstance(fs,str):
                    r['methods'].append({'method':'Sage/PARI factor','integer':str(n),'outcome':fs})
                else:
                    flat=[ZZ(q) for q,e in fs for _ in range(e)]
                    assert prod(flat)==n and all(q.is_prime(proof=True) for q in flat)
                    parts.remove(n);parts.extend(flat)
                    r['methods'].append({'method':'Sage/PARI factor','integer':str(n),'outcome':'complete'})
                checkpoint(parts)
        deadline=time.monotonic()+ECM_SECONDS
        curve_index=0
        while not r['complete'] and time.monotonic()<deadline:
            n=max(q for q in parts if not q.is_prime(proof=True))
            B1=20000 if curve_index<30 else (100000 if curve_index<90 else 1000000)
            seed=hashlib.sha256((task['id']+':'+str(curve_index)).encode()).digest()
            sigma=6+int.from_bytes(seed[:8],'big')%((1<<32)-6)
            cmd=['ecm','-one','-sigma',str(sigma),str(B1)]
            attempt={'method':'GMP-ECM','curve':curve_index,'B1':B1,'sigma':sigma,'integer':str(n)}
            try:
                out=subprocess.run(cmd,input=str(n)+'\n',text=True,capture_output=True,
                                   timeout=max(0.1,deadline-time.monotonic()))
                attempt.update(returncode=out.returncode,stdout=out.stdout,stderr=out.stderr)
                found=re.findall(r'Factor found in step \d+: (\d+)',out.stdout)
                for s in found:
                    q=ZZ(s)
                    if 1<q<n and n%q==0:
                        parts.remove(n);parts.extend([q,n//q]);break
            except subprocess.TimeoutExpired as e:
                attempt['timeout']=True
                attempt['stdout']=(e.stdout.decode() if isinstance(e.stdout,bytes) else e.stdout) or ''
                attempt['stderr']=(e.stderr.decode() if isinstance(e.stderr,bytes) else e.stderr) or ''
            r['methods'].append(attempt)
            checkpoint(parts)
            curve_index+=1
        checkpoint(parts)
    except BaseException as e:
        r.update(error=type(e).__name__+': '+str(e),traceback=traceback.format_exc())
        save(path,r)
    print(task['id'],'complete='+str(r['complete']),'primes='+str(r['proven_prime_factors']),
          'remaining='+str(r['unresolved_composite_factors']),flush=True)


def main():
    raw=json.loads((BASE/'dissect-results.json').read_text())
    curves=json.loads((BASE/'curves.icv1.json').read_text())['curves']
    lookup={r['curve_id']['slug']:r for r in curves}
    missing=[r for r in raw['data'] if not r['complete']]
    targets={}
    algebra=[]
    for r in missing:
        row=lookup[r['curve']]
        p,n=[ZZ(row['parameters'][k]) for k in ('p','n')]
        t=p+1-n
        request={'curve':r['curve'],'source_label':row['source_label'],'trait':r['trait'],'params':r['params']}
        def register(value,field):
            value=int(value)
            target=targets.setdefault(value,{'id':'factor-'+hashlib.sha256(str(value).encode()).hexdigest()[:12],
                                             'value':str(value),'requests':[]})
            target['requests'].append(dict(request,field=field))
        if r['trait']=='twist_order':
            value=(p-1)**2+t*t
            assert value==r['result']['twist_cardinality']
            register(value,'factorization')
        elif r['trait']=='kn_factorization':
            register(4*n+1,'(+)factorization');register(4*n-1,'(-)factorization')
        elif r['trait']=='square_4p1':
            register(4*p-1,'p');register(4*n-1,'order')
        elif r['trait']=='conductor':
            assert r['params']=={'deg':4}
            t2=t*t-2*p
            ratio=abs(t*t2)
            assert ratio==r['result']['ratio_sqrt']
            fs=[]
            for d in [1,2]:
                tr=[q for q in raw['data'] if q['curve']==r['curve'] and q['trait']=='trace_factorization' and q['params']=={'deg':d}][0]
                factors=[ZZ(q) for q in tr['result']['trace_factorization']]
                assert prod(factors)==abs(t if d==1 else t2)
                fs.extend(factors)
            assert prod(fs)==ratio and all(q.is_prime(proof=True) for q in fs)
            algebra.append(dict(request,complete=True,ratio_sqrt=str(ratio),
                prime_factorization=[str(q) for q in sorted(fs)],
                method='Identity sqrt(D_4/D_1)=|t*(t^2-2p)| and re-use of both proven trace factorizations.',
                prime_factors_proven=True))
    save(ROOT/'algebraic-resolutions.json',algebra)
    tasks=list(targets.values())
    meta={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'base_results_sha256':hashlib.sha256((BASE/'dissect-results.json').read_bytes()).hexdigest(),
          'base_input_sha256':hashlib.sha256((BASE/'input.json').read_bytes()).hexdigest(),
          'unique_integer_targets':tasks,'missing_base_calls':len(missing),
          'algebraically_resolved_calls':len(algebra)}
    save(ROOT/'factor-plan.json',meta)
    print('Algebraically resolved',len(algebra),'call;',len(tasks),'unique integer targets for remaining calls.',flush=True)
    ctx=multiprocessing.get_context('fork')
    queue=collections.deque(tasks)
    active=[]
    while queue or active:
        while queue and len(active)<WORKERS:
            task=queue.popleft()
            existing=ROOT/(task['id']+'.json')
            if existing.exists() and json.loads(existing.read_text()).get('complete'):
                continue
            p=ctx.Process(target=solve_target,args=(task,));p.start()
            active.append((p,time.monotonic(),task))
        pending=[]
        for p,started,task in active:
            if not p.is_alive():p.join()
            elif time.monotonic()-started>PARI_SECONDS+ECM_SECONDS+60:
                try:os.killpg(p.pid,9)
                except ProcessLookupError:pass
                p.join()
                path=ROOT/(task['id']+'.json')
                record=json.loads(path.read_text()) if path.exists() else task
                record.update(outer_watchdog=True,complete=False)
                save(path,record)
            else:pending.append((p,started,task))
        active=pending
        if active:time.sleep(0.1)
    results=[json.loads((ROOT/(task['id']+'.json')).read_text()) for task in tasks]
    save(ROOT/'factorization-results.json',dict(meta,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              algebraic_resolutions=algebra,results=results))
    print('Finished:',sum(r['complete'] for r in results),'of',len(results),'integer targets complete.',flush=True)


if __name__=='__main__':
    main()
