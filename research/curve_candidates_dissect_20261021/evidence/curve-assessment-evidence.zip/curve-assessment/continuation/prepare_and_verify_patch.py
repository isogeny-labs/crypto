"""Prepare a minimal local upstream patch and verify affected results.

The pinned DiSSECT checkout remains unchanged. The patched copies are loaded
as separate modules and compared with the independently derived certificates.
"""
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import time

from sage.all import ZZ
from dissect.utils.custom_curve import CustomCurve

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
SOURCE=Path('/workspace/tools/DiSSECT')


def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    changes=[
      ('torsion_extension.py','        k2 = l\n','        k2 *= l\n'),
      ('trace_factorization.py','"trace": curve.trace(),','"trace": trace,'),
    ]
    patches=[];paths=[]
    for filename,old,new in changes:
        source=SOURCE/'dissect/traits'/filename
        before=source.read_text()
        assert before.count(old)==1
        after=before.replace(old,new)
        target=ROOT/'fixed-traits'/filename
        target.parent.mkdir(exist_ok=True)
        target.write_text(after)
        patches.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
                       fromfile='a/dissect/traits/'+filename,tofile='b/dissect/traits/'+filename))
        paths.append((filename,target))
    (ROOT/'dissect-corrections.patch').write_text(''.join(patches))
    torsion=load_module('dissect_torsion_corrected',paths[0][1]).TorsionExtensionTrait()
    trace=load_module('dissect_trace_corrected',paths[1][1]).TraceFactorizationTrait()
    curves={c['name']:c for c in json.loads((BASE/'curves.dissect.json').read_text())['curves']}
    coordinate=json.loads((ROOT/'coordinate-torsion-certificates.json').read_text())
    assert coordinate['complete']
    output=[]
    for c in coordinate['results']:
        started=time.monotonic()
        corrected=torsion(CustomCurve(curves[c['curve']]),l=c['l'])
        corrected={k:int(v) for k,v in corrected.items()}
        assert corrected==c['verified_corrected']
        output.append({'curve':c['curve'],'trait':'torsion_extension','params':{'l':c['l']},
                       'patched_result':corrected,'matches_coordinate_certificate':True,
                       'elapsed_seconds':round(time.monotonic()-started,6)})
        print(c['curve'],'torsion',c['l'],corrected,flush=True)
    for slug,c in curves.items():
        # Both degree 1 and 2 are checked: the patch must preserve the base trace.
        p=ZZ(c['field']['p']);n=ZZ(c['order']);t=p+1-n
        for deg in [1,2]:
            started=time.monotonic()
            returned=trace(CustomCurve(c),deg=deg)
            wanted=t if deg==1 else t*t-2*p
            assert returned['trace']==wanted
            fs=returned['trace_factorization']
            fact_complete=isinstance(fs,list)
            if fact_complete:
                product=ZZ(1)
                for q in fs:product*=q
                assert product==abs(wanted)
            output.append({'curve':slug,'trait':'trace_factorization','params':{'deg':deg},
                'patched_trace':str(returned['trace']),
                'factorization':[str(q) for q in fs] if fact_complete else fs,
                'factorization_completed':fact_complete,'trace_matches_recurrence':True,
                'elapsed_seconds':round(time.monotonic()-started,6)})
            print(slug,'trace',deg,'matches recurrence; factors complete='+str(fact_complete),flush=True)
    (ROOT/'patch-verification.json').write_text(json.dumps({
        'source_commit':'8edc3030fb91411a55aa6c07d050507d840c5e55',
        'original_checkout_unchanged':True,'results':output,
        'patch_sha256':hashlib.sha256((ROOT/'dissect-corrections.patch').read_bytes()).hexdigest(),
        'all_affected_fields_match_independent_certificates':True,
    },indent=2)+'\n')


if __name__=='__main__':
    main()
