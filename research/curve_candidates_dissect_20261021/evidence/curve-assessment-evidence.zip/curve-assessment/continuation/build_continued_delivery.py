"""Create a separately labeled assessed-data view and an updated archive.

The first release and native outputs remain unchanged. Every derived field
in the assessed view names its correction or factorization certificate.
"""
import collections
import copy
import datetime
import hashlib
import json
import math
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
WORKSPACE=BASE.parent


def key(r):
    return r['curve'],r['trait'],json.dumps(r['params'],sort_keys=True)


def available(v):
    if v is None or isinstance(v,str):return False
    if isinstance(v,dict):return all(available(x) for x in v.values())
    if isinstance(v,list):return all(available(x) for x in v)
    return True


def main():
    raw_path=BASE/'dissect-results.json'
    raw=json.loads(raw_path.read_text())
    identities=json.loads((BASE/'curves.icv1.json').read_text())['curves']
    label={r['curve_id']['slug']:r['source_label'] for r in identities}
    issue_doc=json.loads((BASE/'dissect-output-audit.json').read_text())
    coordinates=json.loads((ROOT/'coordinate-torsion-certificates.json').read_text())
    patch=json.loads((ROOT/'patch-verification.json').read_text())
    factoring=json.loads((ROOT/'factorization-results.json').read_text())
    residuals=json.loads((ROOT/'residual-factorization-results.json').read_text())
    validation=json.loads((ROOT/'continuation-validation.json').read_text())
    assert validation['all_checks_passed']
    for name,sha in validation['source_sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha
    assert factoring['base_results_sha256']==hashlib.sha256(raw_path.read_bytes()).hexdigest()
    assert coordinates['complete'] and len(coordinates['results'])==6
    assert patch['all_affected_fields_match_independent_certificates'] and len(patch['results'])==14
    assert all(r.get('factorization_completed',True) for r in patch['results'])
    output=[]
    for r in raw['data']:
        output.append({'curve':r['curve'],'trait':r['trait'],'params':r['params'],
            'original_call':{k:r[k] for k in ['status','complete','elapsed_seconds','random_seed']},
            'raw_result':copy.deepcopy(r['result']),
            'assessed_result':copy.deepcopy(r['result']),'changes':[]})
    lookup={key(r):r for r in output}
    for issue in issue_doc['mismatches']:
        dest=lookup[key(issue)]
        if issue['trait']=='torsion_extension':
            coord=[c for c in coordinates['results'] if c['curve']==issue['curve'] and c['l']==issue['params']['l']]
            assert len(coord)==1 and coord[0]['verified_corrected']==issue['independent']
            dest['assessed_result']=copy.deepcopy(issue['independent'])
            refs=['coordinate-torsion-certificates.json','patch-verification.json']
        elif issue['trait']=='trace_factorization':
            dest['assessed_result']['trace']=int(issue['independent'])
            refs=['../dissect-output-audit.json','patch-verification.json']
        else:raise AssertionError(issue)
        dest['changes'].append({'kind':'upstream bug correction','evidence':refs})
    factors={r['id']:r for r in factoring['results']}
    residual_index={r['id']:r for r in residuals}
    for ident,r in factors.items():
        latest=residual_index.get(ident,r)
        primes=[int(q) for q in latest['proven_prime_factors']]
        composites=[int(q) for q in latest['unresolved_composite_factors']]
        assert math.prod(primes+composites)==int(latest['integer'])
        assert latest['complete']==(not composites)
        evidence=ident+('-residual.json' if ident in residual_index else '.json')
        for request in r['requests']:
            dest=lookup[key(request)]
            field=request['field']
            if not latest['complete']:
                dest.setdefault('partial_factorizations',{})[field]={
                    'integer':latest['integer'],'proven_prime_factors':[str(q) for q in primes],
                    'unresolved_composite_factors':[str(q) for q in composites],
                    'evidence':evidence}
                continue
            if request['trait']=='square_4p1':
                powers=collections.Counter(primes)
                dest['assessed_result'][field]=math.prod(q**(e//2) for q,e in powers.items())
            else:
                dest['assessed_result'][field]=primes
                if request['trait']=='kn_factorization':
                    largest_field=field.replace('factorization','largest_factor_bitlen')
                    dest['assessed_result'][largest_field]=max(primes).bit_length()
            dest['changes'].append({'kind':'factorization completed after the original timeout',
                                    'field':field,'evidence':[evidence]})
    for r in factoring['algebraic_resolutions']:
        dest=lookup[key(r)]
        assert r['complete'] and r['prime_factors_proven']
        fs=[int(q) for q in r['prime_factorization']]
        assert math.prod(fs)==int(r['ratio_sqrt'])
        dest['assessed_result'].update(factorization=fs,ratio_sqrt=int(r['ratio_sqrt']))
        dest['changes'].append({'kind':'exact algebraic factorization recovery',
                               'evidence':['algebraic-resolutions.json']})
    for r in output:r['all_fields_available']=available(r['assessed_result'])
    recovered=[r for r in output if not r['original_call']['complete'] and r['all_fields_available']]
    pending=[r for r in output if not r['all_fields_available']]
    summary={
      'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'base_results_sha256':hashlib.sha256(raw_path.read_bytes()).hexdigest(),
      'original_default_calls':len(output),'original_incomplete_calls':5,
      'newly_resolved_calls':len(recovered),'remaining_incomplete_calls':len(pending),
      'assessed_records_with_all_fields':sum(r['all_fields_available'] for r in output),
      'corrected_original_records':len(issue_doc['mismatches']),
      'coordinate_verified_torsion_corrections':6,
      'patched_implementation_checks':len(patch['results']),
      'remaining':[{'curve':r['curve'],'source_label':label[r['curve']],'trait':r['trait'],
                    'params':r['params'],'partial_factorizations':r.get('partial_factorizations',{})} for r in pending],
      'recovered':[{'curve':r['curve'],'source_label':label[r['curve']],'trait':r['trait'],
                    'params':r['params'],'assessed_result':r['assessed_result']} for r in recovered],
    }
    (ROOT/'continuation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    view={'kind':'Postprocessed assessment; source results remain preserved separately.',
          'base_results_sha256':summary['base_results_sha256'],'summary':summary,'data':output}
    (ROOT/'assessed-results.json').write_text(json.dumps(view,indent=2)+'\n')
    text=[
      'Continued assessment: supplied elliptic-curve candidates',
      '',
      'The ICV1 identities, exact models, certified full group orders, base-field',
      'twist factorizations and endomorphism conductors from the first assessment',
      'remain as recorded. This continuation resolves missing auxiliary fields',
      'and directly verifies the reported upstream DiSSECT defects.',
      '',
      f'{len(recovered)} of the five original incomplete parameter results are now complete.',
      f'The assessed view has {summary["assessed_records_with_all_fields"]} of {len(output)} records with every field available.',
      'It is a labeled postprocessed view, not a claim that native default runs',
      'were repeated with those outputs. Each changed field links its evidence.',
      '',
      'Newly completed results:',
    ]
    for r in recovered:
        text.append(f'  {label[r["curve"]]}: {r["trait"]} {json.dumps(r["params"],sort_keys=True)}')
    text += [
      '',
      'The degree-4 conductor-ratio factorization was recovered using',
      'sqrt(D_4/D_1)=|t*(t^2-2p)| and the proven existing trace factors.',
      'The 256-bit candidate has square_4p1 p=1 and order=1: both 4p-1 and',
      '4n-1 are now completely factored into distinct, proven primes.',
      'Both signs of 4n +/- 1 are completely factored in the assessed view.',
      '',
      'Remaining incomplete results:',
    ]
    for r in pending:
        text.append(f'  {label[r["curve"]]}: {r["trait"]} {json.dumps(r["params"],sort_keys=True)}')
        for part in r.get('partial_factorizations',{}).values():
            text.append('    Proven prime factors: '+', '.join(part['proven_prime_factors']))
            for q in part['unresolved_composite_factors']:
                text.append(f'    Unresolved composite ({int(q).bit_length()} bits): {q}')
    text += [
      'These remaining integers are twist cardinalities over Fp^2. The',
      'base-field curve and twist cardinalities are already fully certified.',
      'Further prime factors were recovered with GMP-ECM. Residual composites',
      'were also tried with FLINT; no unresolved composite is labeled prime.',
      'Exact budgets, seeds, factors and proof-enabled primality checks are retained.',
      '',
      'Direct confirmation of the DiSSECT corrections:',
      'All six torsion corrections were independently verified by factoring the',
      'actual division polynomial and checking the square character of each',
      'y-coordinate right-hand side in every irreducible residue field.',
      'This accounts for every nonidentity l-torsion point, without relying on',
      'DiSSECT torsion_finder or the earlier companion-matrix calculation.',
      '',
      'Corrected least/full/relative point-field degrees:',
    ]
    for r in coordinates['results']:
        d=r['verified_corrected']
        text.append(f'  {r["source_label"]}, l={r["l"]}: {d["least"]}/{d["full"]}/{d["relative"]}')
    text += [
      '',
      'dissect-corrections.patch changes two lines in the pinned upstream source:',
      '  torsion_extension.py: multiply k2 by l in the nontrivial Jordan case.',
      '  trace_factorization.py: return the actual extension trace.',
      'The patched copies pass all six coordinate checks and eight trace checks',
      '(degrees 1 and 2 on each curve). The patch applies cleanly to the pinned',
      'checkout. It has not been posted upstream or applied to the original source.',
      '',
      'Reproduction in the original SageMath/PYTHONPATH environment:',
      '  sage -python continuation/retry_factorizations.py',
      '  sage -python continuation/retry_residuals.py',
      '  sage -python continuation/verify_torsion_coordinates.py',
      '  sage -python continuation/prepare_and_verify_patch.py',
      '  python3 continuation/build_continued_delivery.py',
      '',
      'The original archive, raw outputs and initial manifest remain unchanged.',
      'The updated archive includes both releases and a new complete hash manifest.',
    ]
    (ROOT/'assessment-update.txt').write_text('\n'.join(text)+'\n')
    index=(
      'Start with continuation/assessment-update.txt for the latest findings.\n'
      'curves.icv1.json contains the canonical identities and exact input models.\n'
      'continuation/assessed-results.json contains the labeled corrected/extended view.\n'
      'dissect-results.json and assessment.txt are the frozen original run and report.\n'
      'continuation/dissect-corrections.patch is the independently verified two-line fix.\n'
      'manifest-continued.json hashes every member except itself and binds the original ZIP.\n'
    )
    (BASE/'START-HERE-continued.txt').write_text(index)
    first=WORKSPACE/'curve-assessment.zip'
    with zipfile.ZipFile(first) as z:
        assert z.testzip() is None
        members={name:z.read(name) for name in z.namelist()}
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and not path.name.endswith('.tmp'):
            members['curve-assessment/'+str(path.relative_to(BASE))]=path.read_bytes()
    members['curve-assessment/START-HERE-continued.txt']=index.encode()
    manifest={'original_archive_sha256':hashlib.sha256(first.read_bytes()).hexdigest(),
      'continuation_summary':summary,
      'files':{name:{'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b)} for name,b in sorted(members.items())}}
    manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode()
    (BASE/'manifest-continued.json').write_bytes(manifest_bytes)
    members['curve-assessment/manifest-continued.json']=manifest_bytes
    dest=WORKSPACE/'curve-assessment-continued.zip'
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,b in sorted(members.items()):z.writestr(name,b)
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        for name,entry in manifest['files'].items():
            assert hashlib.sha256(z.read(name)).hexdigest()==entry['sha256']
    print('Newly completed calls',len(recovered),'remaining',len(pending))
    print('Created',dest,dest.stat().st_size,'bytes;',len(members),'files; all member hashes verified.')


if __name__=='__main__':
    main()
