"""Verify the six corrected torsion records directly from point coordinates.

Factor the actual l-division polynomial. For each irreducible x-factor of
degree d, Euler's criterion in Fp[x]/(f) shows whether y already lies in
Fp^d or needs Fp^(2d). This proves least/full point degrees without using
DiSSECT torsion_finder or the earlier companion-matrix calculation.
"""
import datetime
import hashlib
import json
import math
from pathlib import Path
import time

from sage.all import EllipticCurve, GF, ZZ, factor, power_mod, prod, proof

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent


def main():
    proof.arithmetic(True)
    rows=json.loads((BASE/'curves.icv1.json').read_text())['curves']
    meta={r['curve_id']['slug']:r for r in rows}
    issues=json.loads((BASE/'dissect-output-audit.json').read_text())['mismatches']
    issues=[r for r in issues if r['trait']=='torsion_extension']
    results=[]
    for issue in issues:
        started=time.monotonic()
        row=meta[issue['curve']]
        p,a,b=[ZZ(row['parameters'][k]) for k in ('p','a','b')]
        l=issue['params']['l']
        E=EllipticCurve(GF(p),[a,b])
        f=E.division_polynomial(l).monic()
        x=f.parent().gen()
        fs=list(f.factor())
        assert prod(g**e for g,e in fs)==f and all(e==1 for g,e in fs)
        components=[]
        for g,e in fs:
            assert g.is_irreducible()
            d=int(g.degree())
            rhs=(x**3+a*x+b)%g
            char=power_mod(rhs,(p**d-1)//2,g)
            assert char in [f.parent()(1),f.parent()(-1)]
            point_degree=d if char==1 else 2*d
            components.append({'irreducible_x_polynomial_coefficients':[str(ZZ(v)) for v in g.list()],
                'x_degree':d,'y_rhs_quadratic_character':1 if char==1 else -1,
                'point_degree':point_degree})
        least=min(c['point_degree'] for c in components)
        full=math.lcm(*(c['point_degree'] for c in components))
        expected={'least':least,'full':full,'relative':full//least}
        assert expected==issue['independent']
        assert sum(2*c['x_degree'] for c in components)==l*l-1
        r={'curve':issue['curve'],'source_label':row['source_label'],'l':l,
           'raw_dissect':issue['raw'],'verified_corrected':expected,
           'nonidentity_torsion_points_accounted_for':l*l-1,
           'division_polynomial_squarefree':True,'irreducibility_proven':True,
           'components':components,'elapsed_seconds':round(time.monotonic()-started,6),
           'method':'Exact division-polynomial factorization and Euler criterion in every irreducible residue field.'}
        results.append(r)
        (ROOT/'coordinate-torsion-certificates.json').write_text(json.dumps({'complete':len(results)==len(issues),'results':results},indent=2)+'\n')
        print(row['source_label'],'l='+str(l),expected,'x-degrees='+str([c['x_degree'] for c in components]),flush=True)
    print('All',len(results),'corrections independently verified from coordinates.',flush=True)


if __name__=='__main__':
    main()
