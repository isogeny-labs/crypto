"""Proof-check every recovered prime factor and retained composite cofactor."""
import hashlib
import json
import math
from pathlib import Path

from sage.all import ZZ

ROOT=Path(__file__).resolve().parent


def main():
    first=json.loads((ROOT/'factorization-results.json').read_text())
    later=json.loads((ROOT/'residual-factorization-results.json').read_text())
    by_id={r['id']:r for r in later}
    checks=[]
    for previous in first['results']:
        r=by_id.get(previous['id'],previous)
        primes=[ZZ(x) for x in r['proven_prime_factors']]
        composites=[ZZ(x) for x in r['unresolved_composite_factors']]
        assert math.prod(primes+composites)==ZZ(r['integer'])
        assert all(q.is_prime(proof=True) for q in primes)
        assert all(not q.is_prime(proof=True) for q in composites)
        assert r['complete']==(not composites)
        checks.append({'target_id':r['id'],'product_exact':True,'prime_factors_proven':True,
            'remaining_cofactors_proven_composite':True,'complete':r['complete'],
            'remaining_cofactor_bits':[int(q.nbits()) for q in composites]})
    algebra=json.loads((ROOT/'algebraic-resolutions.json').read_text())
    for r in algebra:
        fs=[ZZ(q) for q in r['prime_factorization']]
        assert math.prod(fs)==ZZ(r['ratio_sqrt']) and all(q.is_prime(proof=True) for q in fs)
    coordinates=json.loads((ROOT/'coordinate-torsion-certificates.json').read_text())
    assert coordinates['complete'] and len(coordinates['results'])==6
    for r in coordinates['results']:
        cs=r['components']
        assert all(c['y_rhs_quadratic_character'] in (-1,1) for c in cs)
        assert all(c['point_degree']==c['x_degree']*(1 if c['y_rhs_quadratic_character']==1 else 2) for c in cs)
        assert min(c['point_degree'] for c in cs)==r['verified_corrected']['least']
        assert math.lcm(*(c['point_degree'] for c in cs))==r['verified_corrected']['full']
        assert sum(2*c['x_degree'] for c in cs)==r['l']**2-1
    refs=['factorization-results.json','residual-factorization-results.json',
          'algebraic-resolutions.json','coordinate-torsion-certificates.json','patch-verification.json']
    result={'all_checks_passed':True,'factor_checks':checks,
            'algebraic_resolutions_checked':len(algebra),'coordinate_records_checked':6,
            'source_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in refs}}
    (ROOT/'continuation-validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print('All recovered prime factors proven; all products exact; retained residuals proven composite.')
    print('Residual bit lengths:',[r['remaining_cofactor_bits'] for r in checks if not r['complete']])


if __name__=='__main__':
    main()
