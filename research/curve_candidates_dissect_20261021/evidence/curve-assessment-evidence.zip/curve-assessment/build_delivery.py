"""Build the readable assessment, CSV and hash-bound delivery archive."""
import collections
import csv
import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent
SOURCE=Path('/workspace/tools/DiSSECT')


def main():
    records=json.loads((ROOT/'curves.icv1.json').read_text())
    certs=json.loads((ROOT/'assessment-certificates.json').read_text())
    raw=json.loads((ROOT/'dissect-results.json').read_text())
    audit=json.loads((ROOT/'dissect-output-audit.json').read_text())
    cert_by_slug={c['curve']:c for c in certs}
    timeouts=[r for r in raw['data'] if not r['complete']]
    lines=[
      'Assessment of four supplied elliptic-curve candidates',
      '',
      'All four supplied parameter sets are arithmetically consistent. SageMath',
      'proves p and n prime. Independent affine arithmetic and SageMath both',
      'verify nG=O. Since n is the unique multiple of n in the Hasse interval,',
      'each full group has order n and cofactor 1. All four curves are ordinary,',
      'nonsingular and non-anomalous. The generator and seed rules match.',
      '',
      'ICV1 identities use the byte-verified reference from aburan28/crypto.',
      'The supplied equations and b signs are preserved. All four Frobenius',
      'discriminants are proven fundamental, so End(E)=Z[pi]=O_K; the',
      'endomorphism conductor is exactly 1 for every supplied curve.',
      'The certified discriminants are recorded in the full ICV1 strings.',
      'No volcano placement is asserted: level=unk and path=r.',
      '',
      'Input-label crosswalk and generic DLP work estimates (log2 group steps):',
      'Input label | model hash8 | curve estimate | largest twist prime bits | twist estimate',
    ]
    output=[]
    for row in records['curves']:
        ident=row['curve_id']; c=cert_by_slug[ident['slug']]
        lines.append(f'{row["source_label"]} | {ident["model_sha256"][:8]} | {c["generic_curve_security_bits_approx"]:.1f} | {c["largest_twist_prime_bits"]} | {c["generic_twist_security_bits_approx"]:.1f}')
        output.append({
            'input_label':row['source_label'],'icv1_slug':ident['slug'],'icv1':ident['icv1'],
            'order_bits':c['order_bits'],'trace':c['trace'],
            'endomorphism_conductor':c['endomorphism_conductor'],
            'endomorphism_discriminant':c['endomorphism_discriminant'],
            'embedding_degree':c['embedding_degree'],
            'embedding_degree_complement':c['embedding_degree_complement'],
            'generic_curve_work_log2_approx':round(c['generic_curve_security_bits_approx'],3),
            'largest_twist_prime':c['largest_twist_prime'],
            'largest_twist_prime_bits':c['largest_twist_prime_bits'],
            'generic_twist_work_log2_approx':round(c['generic_twist_security_bits_approx'],3),
        })
    lines += [
      '',
      'Twist estimates concern a DLP on the quadratic twist. Proper point',
      'validation keeps protocol operations in the supplied curve subgroup.',
      'The relatively small twist primes, especially the 83-bit prime for the',
      'input labelled 777, matter if a protocol can accept twist points.',
      'These are generic mathematical work estimates, not attack measurements.',
      '',
      'Embedding degrees are proven minimal and are very large:',
    ]
    for row in output:
        lines.append(f'{row["input_label"]}: k = {row["embedding_degree"]} = (n-1)/{row["embedding_degree_complement"]}')
    lines += [
      '',
      'Seed derivation and root conventions:',
      'Each 160-bit seed reproduces c from the X9.62 SHA-1 expansion, and',
      'b^2*c = a^3 mod p. Each 224-bit b is the smaller root. The 256-bit b',
      'equals (a^3/c)^((p+1)/4) mod p, including its larger-root sign.',
      'For the 224-bit field p=1 mod 4: b and -b are Fp-isomorphic via',
      '(x,y) -> (-x,i*y), i^2=-1. For the 256-bit field p=3 mod 4: changing',
      'b to -b gives its quadratic twist, so its supplied sign is significant.',
      'The first nonnegative x with a point and the smaller y match every G.',
      'The search iterations and rejection history were not reconstructed.',
      '',
      f'DiSSECT {raw["tool_commit"]}; {raw["sage_version"]}.',
      f'All {raw["recorded_calls"]} default calls across {len(raw["trait_default_params"])} traits were executed in {raw["elapsed_seconds"]:.1f} seconds.',
      f'{raw["recorded_calls"]-len(timeouts)} calls returned every field; {len(timeouts)} returned upstream internal factorization timeouts.',
      'No outer watchdog termination or uncaught trait error occurred.',
      'Incomplete calls, retained exactly in the raw results:',
    ]
    label={r['curve_id']['slug']:r['source_label'] for r in records['curves']}
    for r in timeouts:
        lines.append(f'  {label[r["curve"]]}: {r["trait"]} {json.dumps(r["params"],sort_keys=True)}')
    lines += [
      '',
      'Independent output audit:',
      'Six torsion-extension records have an upstream repeated-eigenvalue bug.',
      'For l=3 the correct least/full/relative degrees are 2/6/3 on all four',
      'curves, instead of the raw 2/3/1. Input 777 at l=5 has 2/10/5;',
      'input 5736 at l=13 has 3/39/13. Exact Frobenius matrix iteration',
      'checks these corrections and all 28 returned torsion-extension records.',
      'Four degree-2 trace fields incorrectly repeat the base trace. Their',
      'factorizations apply to the correct extension trace t^2-2p.',
      'The raw output is preserved. dissect-output-audit.json contains all',
      f'{audit["checked_records"]} independent comparisons and {audit["mismatch_records"]} mismatches with corrections.',
      'The principal order, endomorphism-ring, embedding and twist claims above',
      'have separate proof-enabled certificates and do not rely on those fields.',
      '',
      'No comparison to a simulated reference population was run; this does',
      'not establish a statistical outlier result or a security certification.',
      '',
      'Canonical identities:',
    ]
    for row in records['curves']:
        lines += ['',row['source_label'],row['curve_id']['slug'],row['curve_id']['icv1']]
    lines += ['',
      'Sources: https://github.com/aburan28/crypto/blob/main/docs/curves/ICV1.md',
      'https://github.com/aburan28/crypto/blob/main/scripts/curve_id.py',
      'https://github.com/crocs-muni/DiSSECT/tree/'+raw['tool_commit'],
    ]
    (ROOT/'assessment.txt').write_text('\n'.join(lines)+'\n')
    with (ROOT/'assessment.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(output[0]));w.writeheader();w.writerows(output)
    grouped=collections.defaultdict(list)
    for r in raw['data']:grouped[(r['curve'],r['trait'])].append(r)
    with (ROOT/'trait-coverage.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['curve','trait','calls','all_fields_returned','incomplete','errors'])
        for (slug,trait),rs in sorted(grouped.items()):
            w.writerow([slug,trait,len(rs),sum(r['complete'] for r in rs),sum(not r['complete'] for r in rs),sum(r['status']=='error' for r in rs)])
    names=[
      'input.json','curves.icv1.json','curves.dissect.json','validation-python.json',
      'validation-sage.json','assessment-certificates.json','dissect-results.json',
      'dissect-results.jsonl','dissect-native-cli-x962.json','dissect-native-cli-cofactor.json',
      'dissect-output-audit.json','assessment.txt','assessment.csv','trait-coverage.csv',
      'dissect-run.log','certification.log','validation-python.log','REPRODUCE.txt',
      'sage-environment.explicit.txt','validate_python.py','convert_icv1.py',
      'run_dissect.py','certify_assessment.py','audit_dissect.py','build_delivery.py',
      'reference/curve_id.py','reference/ICV1.md',
    ]
    members={name:(ROOT/name).read_bytes() for name in names}
    for p in ROOT.glob('*.model.json'):members[p.name]=p.read_bytes()
    source_paths=subprocess.check_output(['git','-C',str(SOURCE),'ls-files'],text=True).splitlines()
    assert not subprocess.check_output(['git','-C',str(SOURCE),'diff','--name-only'],text=True).strip()
    for name in source_paths:
        p=SOURCE/name
        if p.is_file():members['source/DiSSECT/'+name]=p.read_bytes()
    provenance={
      'dissect_source_url':'https://github.com/crocs-muni/DiSSECT',
      'dissect_commit':raw['tool_commit'],
      'icv1_spec_git_blob_sha':'8aaee561c69a0f681e1fcb7851eb00ae15ce61d8',
      'icv1_reference_git_blob_sha':'97e76f4e8ec6852e4f3ca838c14e8bbae85fcfc3',
      'files':{name:{'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b)} for name,b in sorted(members.items())},
    }
    manifest=json.dumps(provenance,indent=2)+'\n'
    (ROOT/'manifest.json').write_text(manifest)
    members['manifest.json']=manifest.encode()
    dest=ROOT.parent/'curve-assessment.zip'
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,b in sorted(members.items()):z.writestr('curve-assessment/'+name,b)
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        for name,entry in provenance['files'].items():
            assert hashlib.sha256(z.read('curve-assessment/'+name)).hexdigest()==entry['sha256']
    print('Created',dest,dest.stat().st_size,'bytes;',len(members),'files; archive hashes verified.')


if __name__=='__main__':
    main()
