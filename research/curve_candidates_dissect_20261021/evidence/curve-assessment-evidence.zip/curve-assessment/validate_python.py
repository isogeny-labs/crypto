"""Independent, affine EC arithmetic and parameter checks (Python + SymPy).

Full order is certified by a prime n, a nonidentity G annihilated by n,
and n being the unique multiple of n in the Hasse interval. Sage separately
performs proof-enabled primality checks.
"""
import hashlib
import json
import math
import sys
from pathlib import Path

from sympy import isprime

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'reference'))
import curve_id


def add(P, Q, p, a):
    if P is None:
        return Q
    if Q is None:
        return P
    x, y = P
    u, v = Q
    if x == u and (y + v) % p == 0:
        return None
    m = ((v - y) * pow(u - x, -1, p) if x != u else
         (3 * x * x + a) * pow(2 * y, -1, p)) % p
    X = (m * m - x - u) % p
    return X, (m * (x - X) - y) % p


def mul(k, P, p, a):
    R = None
    while k:
        if k & 1:
            R = add(R, P, p, a)
        P = add(P, P, p, a)
        k >>= 1
    return R


def x962_c(seed, bits):
    """X9.62 SHA-1 expansion, truncating the high bit of the first block."""
    v = (bits - 1) // 160
    w = bits - 160 * v - 1
    z = int(seed, 16)
    hs = [int.from_bytes(hashlib.sha1(((z + i) % (1 << 160)).to_bytes(20, 'big')).digest(), 'big')
          for i in range(v + 1)]
    c = hs[0] & ((1 << w) - 1)
    for block in hs[1:]:
        c = (c << 160) | block
    return c


def main():
    raw = json.loads((ROOT / 'input.json').read_text())
    results, dissect = [], []
    for source in raw['curves']:
        p, a, b, x, y, n = [int(source[k], 16) for k in ('p', 'a', 'b', 'Gx', 'Gy', 'n')]
        radius = math.isqrt(4 * p)
        lo, hi = p + 1 - radius, p + 1 + radius
        t = p + 1 - n
        seed_c = x962_c(source['seed'], p.bit_length())
        on_curve = (y*y - (x*x*x + a*x + b)) % p == 0
        nG = mul(n, (x, y), p, a) if on_curve else 'not_on_curve'
        checks = {
            'p_prime_sympy': bool(isprime(p)),
            'n_prime_sympy': bool(isprime(n)),
            'parameters_in_range': all(0 <= v < p for v in (a,b,x,y)),
            'a_equals_minus_3': a == p-3,
            'nonsingular': (4*a**3 + 27*b**2) % p != 0,
            'G_on_curve': on_curve,
            'G_nonidentity': True,
            'n_times_G_is_identity': nG is None,
            'G_first_nonnegative_x': all(pow((xx**3 + a*xx + b) % p,(p-1)//2,p) == p-1 for xx in range(x)),
            'G_smaller_y': y <= p-y,
            'order_in_Hasse_interval': lo <= n <= hi,
            'unique_multiple_of_n_in_Hasse_interval': (lo+n-1)//n == hi//n == 1,
            'h_equals_1': source['h'] == 1,
            'seed_X962_invariant_matches': (b*b*seed_c - a**3) % p == 0,
            'b_is_smaller_root': b <= p-b,
            'b_matches_supplied_sign_convention': (b <= p-b if p.bit_length() == 224 else
                pow((a**3 * pow(seed_c,-1,p)) % p,(p+1)//4,p) == b),
        }
        result = {
            'name': source['name'], 'checks': checks,
            'trace_decimal': str(t), 'trace_hex': hex(t),
            'j_invariant': hex((1728*4*a**3*pow((4*a**3+27*b**2)%p,-1,p))%p),
            'curve_discriminant': hex((-16*(4*a**3+27*b**2))%p),
            'frobenius_discriminant': str(t*t-4*p),
            'quadratic_twist_order': str(2*(p+1)-n),
            'x962_c': hex(seed_c),
            'seed_20_byte_hex': f'{int(source["seed"],16):040X}',
            'nG': nG,
            'cardinality_certificate_pending_proven_primality': all(checks[k] for k in (
                'p_prime_sympy','n_prime_sympy','nonsingular','G_on_curve',
                'n_times_G_is_identity','unique_multiple_of_n_in_Hasse_interval')),
        }
        results.append(result)
        identity = curve_id.prime_id(p,a,b,n*source['h'])
        dissect.append({
            'name': identity['slug'], 'category': 'user-supplied-simulation',
            'form': 'Weierstrass', 'field': {'type':'Prime','p':source['p']},
            'params': {'a':{'raw':source['a']},'b':{'raw':source['b']}},
            'generator': {'x':{'raw':source['Gx']},'y':{'raw':source['Gy']}},
            'order': source['n'], 'cofactor':source['h'],
            'standard':False,
            'simulation': {'seed':result['seed_20_byte_hex']},
            'desc': 'User supplied candidate; exact model retained; candidate label '+source['candidate_label'],
        })
        print(source['name'], json.dumps(result), flush=True)
    (ROOT/'validation-python.json').write_text(json.dumps(results,indent=2)+'\n')
    (ROOT/'curves.dissect.json').write_text(json.dumps({'curves':dissect},indent=2)+'\n')


if __name__ == '__main__':
    main()
