"""Execute unmodified DiSSECT traits with per-call watchdogs and raw results.

Use a SageMath Python, and set PYTHONPATH to the pinned DiSSECT checkout.
All of the upstream default parameter combinations are scheduled. Each
worker has its own process group; the watchdog also stops its descendants.
"""
import collections
import datetime
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback

from sage.all import EllipticCurve, GF, ZZ, proof, set_random_seed, version
from sage.rings.integer import Integer
from dissect.traits import TRAITS
from dissect.utils.custom_curve import CustomCurve

ROOT = Path(__file__).resolve().parent
LIMIT = 90
WORKERS = 4


def cast(x):
    if isinstance(x, dict):
        return {str(k): cast(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):
        return [cast(v) for v in x]
    if isinstance(x, Integer):
        return int(x)
    if x is None or isinstance(x,(bool,int,float,str)):
        return x
    return float(x)


def incomplete(x):
    if x is None:
        return True
    if isinstance(x, str):
        return True
    if isinstance(x, dict):
        return any(incomplete(v) for v in x.values())
    if isinstance(x,(list,tuple)):
        return any(incomplete(v) for v in x)
    return False


def job(conn, curve, trait, params, seed):
    os.setsid()
    set_random_seed(seed)
    started = time.monotonic()
    result = {'curve':curve['name'],'trait':trait,'params':params,'random_seed':seed}
    try:
        c = CustomCurve(curve)
        value = cast(TRAITS[trait](c,**params))
        result.update(status='returned',result=value,complete=not incomplete(value))
    except BaseException as e:
        result.update(status='error',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc(),complete=False)
    result['elapsed_seconds'] = round(time.monotonic()-started,6)
    conn.send(result)
    conn.close()


def certify(curves):
    proof.arithmetic(True)
    certs=[]
    for c in curves:
        p,n = ZZ(c['field']['p']),ZZ(c['order'])
        a,b=ZZ(c['params']['a']['raw']),ZZ(c['params']['b']['raw'])
        x,y=ZZ(c['generator']['x']['raw']),ZZ(c['generator']['y']['raw'])
        pp,np = bool(p.is_prime(proof=True)),bool(n.is_prime(proof=True))
        assert pp and np
        E=EllipticCurve(GF(p),[a,b])
        G=E(x,y)
        annihilates = bool(n*G == E(0))
        radius=(4*p).isqrt()
        lo,hi=p+1-radius,p+1+radius
        only_multiple = bool((lo+n-1)//n == hi//n == 1)
        assert G != E(0) and annihilates and only_multiple
        certs.append({
            'curve':c['name'],'p_prime_proof':pp,'n_prime_proof':np,
            'G_nonidentity':bool(G!=E(0)),'n_times_G_is_identity':annihilates,
            'Hasse_lower':str(lo),'Hasse_upper':str(hi),
            'unique_multiple_of_n_in_Hasse_interval':only_multiple,
            'certified_cardinality':str(n),'certified_cofactor':1,
            'ordinary':bool((p+1-n)%p != 0),
            'anomalous':bool(n==p),'supersingular':bool((p+1-n)%p == 0),
            'method':'Proven prime n, nonidentity point killed by n, Lagrange and the unique multiple in the Hasse interval; no asserted order was set before multiplication.',
        })
        print('CERTIFIED',c['name'],flush=True)
    (ROOT/'validation-sage.json').write_text(json.dumps(certs,indent=2)+'\n')


def main():
    curves=json.loads((ROOT/'curves.dissect.json').read_text())['curves']
    certify(curves)
    # Run quick traits first so the streamed output has useful early results.
    heavy={'kn_factorization','conductor','trace_factorization','twist_order',
           'discriminant','class_number','square_4p1','embedding','small_prime_order'}
    jobs=[]
    for name,trait in TRAITS.items():
        for params in trait.params_iter():
            for c in curves:
                priority=2 if name in heavy else (3 if name=='hamming_x' and params['weight']==3 else 1)
                jobs.append((priority,c,name,params))
    jobs=collections.deque(sorted(jobs,key=lambda j:j[0]))
    expected=len(jobs)
    context=multiprocessing.get_context('fork')
    results=[]
    active=[]
    started=time.monotonic()
    started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
    record_file=ROOT/'dissect-results.jsonl'
    # Exclusive output creation prevents accidentally overwriting a prior run.
    with record_file.open('x') as out:
        while jobs or active:
            while jobs and len(active)<WORKERS:
                _,c,name,params=jobs.popleft()
                seed=int.from_bytes(hashlib.sha256((c['name']+name+json.dumps(params,sort_keys=True)).encode()).digest()[:4],'big')
                read,write=context.Pipe(False)
                proc=context.Process(target=job,args=(write,c,name,params,seed))
                proc.start()
                write.close()
                active.append((proc,read,time.monotonic(),c['name'],name,params,seed))
            pending=[]
            for proc,conn,t,c,name,params,seed in active:
                r=None
                if conn.poll():
                    try:
                        r=conn.recv()
                    except EOFError:
                        r={'curve':c,'trait':name,'params':params,'status':'error','error':'Worker exited without a result','exitcode':proc.exitcode,'complete':False}
                elif time.monotonic()-t > LIMIT:
                    r={'curve':c,'trait':name,'params':params,'status':'timeout','watchdog_seconds':LIMIT,'complete':False}
                    try:
                        os.killpg(proc.pid,signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                elif not proc.is_alive():
                    r={'curve':c,'trait':name,'params':params,'status':'error','error':'Worker exited without a result','exitcode':proc.exitcode,'complete':False}
                if r is None:
                    pending.append((proc,conn,t,c,name,params,seed))
                    continue
                r.setdefault('random_seed',seed)
                r.setdefault('elapsed_seconds',round(time.monotonic()-t,6))
                results.append(r)
                out.write(json.dumps(r,sort_keys=True)+'\n')
                out.flush()
                proc.join(timeout=1)
                if proc.is_alive():
                    try:
                        os.killpg(proc.pid,signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    proc.join()
                conn.close()
                print(f'{len(results)}/{expected} {c} {name} {params} {r["status"]} complete={r["complete"]}',flush=True)
            active=pending
            if active:
                time.sleep(0.05)
    doc={'tool':'crocs-muni/DiSSECT','tool_commit':subprocess.check_output(['git','-C','/workspace/tools/DiSSECT','rev-parse','HEAD'],text=True).strip(),
         'sage_version':version(),'started_utc':started_utc,
         'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'input_sha256':hashlib.sha256((ROOT/'curves.dissect.json').read_bytes()).hexdigest(),
         'workers':WORKERS,'watchdog_seconds_per_call':LIMIT,'elapsed_seconds':time.monotonic()-started,
         'expected_calls':expected,'recorded_calls':len(results),
         'trait_default_params':{name:trait.DEFAULT_PARAMS for name,trait in TRAITS.items()},
         'data':results}
    (ROOT/'dissect-results.json').write_text(json.dumps(doc,indent=2)+'\n')
    print('FINISHED',expected,'calls',flush=True)


if __name__=='__main__':
    main()
