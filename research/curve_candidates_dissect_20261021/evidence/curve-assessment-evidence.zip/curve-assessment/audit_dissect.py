"""Check the returned torsion degrees and extension traces independently.

The proof-checked fundamental Frobenius discriminants give End(E)=Z[pi].
For l != p, Frobenius on E[l] therefore has the cyclic companion action
of X^2-tX+p (a scalar repeated-root action would force l^2 | D).
Direct small-matrix iteration gives the first fixed vector and full torsion
extension, without calling DiSSECT's torsion_finder.
"""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def multiply(A,B,l):
    return ((A[0]*B[0]+A[1]*B[2])%l,
            (A[0]*B[1]+A[1]*B[3])%l,
            (A[2]*B[0]+A[3]*B[2])%l,
            (A[2]*B[1]+A[3]*B[3])%l)


def main():
    certs=json.loads((ROOT/'assessment-certificates.json').read_text())
    identities=json.loads((ROOT/'curves.icv1.json').read_text())['curves']
    meta={r['curve_id']['slug']:r for r in identities}
    cs={c['curve']:c for c in certs}
    raw=json.loads((ROOT/'dissect-results.json').read_text())
    comparisons=[]
    for r in raw['data']:
        slug=r['curve']; c=cs[slug]
        p=int(meta[slug]['parameters']['p'],16)
        t=int(c['trace'])
        if r['trait']=='torsion_extension' and r['complete']:
            l=r['params']['l']
            assert c['frobenius_discriminant_squarefree'] and c['endomorphism_conductor']==1 and p!=l
            M=(0,-p%l,1,t%l)
            I=(1,0,0,1)
            A=I
            least=None
            for k in range(1,l*(l*l-1)+1):
                A=multiply(A,M,l)
                if least is None and ((A[0]-1)*(A[3]-1)-A[1]*A[2])%l==0:
                    least=k
                if A==I:
                    full=k
                    break
            else:
                raise RuntimeError('Matrix-order bound exceeded')
            assert least and full%least==0
            expected={'least':least,'full':full,'relative':full//least}
            comparisons.append({'curve':slug,'trait':r['trait'],'params':r['params'],
                'raw':r['result'],'independent':expected,'matches':r['result']==expected,
                'method':'Exact companion Frobenius matrix iteration modulo l, with certified End(E)=Z[pi] and squarefree discriminant.'})
        if r['trait']=='trace_factorization' and r['params']=={'deg':2} and r['complete']:
            ext_t=t*t-2*p
            factors=r['result']['trace_factorization']
            product=1
            for q in factors:product*=q
            assert product==abs(ext_t)
            comparisons.append({'curve':slug,'trait':r['trait'],'params':r['params'],
                'raw':r['result']['trace'],'independent':str(ext_t),
                'matches':r['result']['trace']==ext_t,
                'absolute_factorization_matches_extension_trace':True,
                'method':'Trace recurrence t_2=t^2-2p and exact product of returned factors.'})
    mismatches=[r for r in comparisons if not r['matches']]
    result={'raw_results_preserved':True,'checked_records':len(comparisons),
            'mismatch_records':len(mismatches),'mismatches':mismatches,'all_checks':comparisons,
            'upstream_issues':[
              {'source':'dissect/traits/torsion_extension.py','issue':'In the repeated-eigenvalue branch, full degree is overwritten by l; for these cases it must be k1*l. The supplied full and least fields can even fail divisibility.'},
              {'source':'dissect/traits/trace_factorization.py','issue':'The returned trace field always uses curve.trace(), even for deg=2; the factorization uses the correct extension trace. The factor list has no signed unit.'}
            ]}
    (ROOT/'dissect-output-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Checked',len(comparisons),'records; mismatches',len(mismatches))
    for r in mismatches:
        print(r['curve'],r['trait'],r['params'],'raw:',r['raw'],'corrected:',r['independent'])


if __name__=='__main__':
    main()
