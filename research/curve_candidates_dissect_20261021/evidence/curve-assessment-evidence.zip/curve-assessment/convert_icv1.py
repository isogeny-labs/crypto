"""Convert the supplied exact models with the repository's ICV1 reference."""
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'reference'))
import curve_id


def main():
    rows=[]
    for c in json.loads((ROOT/'input.json').read_text())['curves']:
        p,a,b,n=[int(c[k],16) for k in ('p','a','b','n')]
        identity=curve_id.prime_id(p,a,b,n*c['h'])
        rows.append({'source_label':c['name'],'curve_id':identity,'parameters':c})
        (ROOT/(identity['slug']+'.model.json')).write_text(identity['model_json']+'\n')
    out={'schema':'ICV1','identity_source':'aburan28/crypto/scripts/curve_id.py',
         'reference_git_blob_sha':'97e76f4e8ec6852e4f3ca838c14e8bbae85fcfc3',
         'input_sha256':hashlib.sha256((ROOT/'input.json').read_bytes()).hexdigest(),'curves':rows}
    (ROOT/'curves.icv1.json').write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':
    main()
