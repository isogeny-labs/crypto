"""Proof-check the principal DiSSECT findings and attach certified ICV1 end.

For an ordinary curve, a squarefree Frobenius discriminant congruent to
1 modulo 4 is fundamental. Z[pi] is then maximal, so End(E) has that same
discriminant. This proves the ring; it does not identify a path in a graph.
"""
import json
import math
from pathlib import Path
import sys
from sage.all import ZZ, factor, prod, proof

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'reference'))
import curve_id


def main():
    proof.arithmetic(True)
    records=[json.loads(s) for s in (ROOT/'dissect-results.jsonl').read_text().splitlines()]
    identities=json.loads((ROOT/'curves.icv1.json').read_text())
    certs=[]
    for row in identities['curves']:
        c=row['parameters']
        slug=row['curve_id']['slug']
        p,a,b,n=[ZZ(c[k]) for k in ('p','a','b','n')]
        t=p+1-n
        D=t*t-4*p
        def find(trait,params):
            r=[r for r in records if r['curve']==slug and r['trait']==trait and r['params']==params]
            assert len(r)==1 and r[0]['complete'],(slug,trait)
            return r[0]['result']
        disc=find('discriminant',{})
        fs=[ZZ(q) for q in disc['factorization']]
        assert prod(fs)==-D and all(q.is_prime(proof=True) for q in fs)
        assert len(set(fs))==len(fs) and D%4==1
        assert disc['max_conductor']==1 and disc['cm_disc']==D and t%p!=0
        twist=find('twist_order',{'deg':1})
        nt=ZZ(twist['twist_cardinality'])
        qs=[ZZ(q) for q in twist['factorization']]
        assert nt==2*(p+1)-n and prod(qs)==nt
        assert all(q.is_prime(proof=True) for q in qs)
        comp=ZZ(find('embedding',{})['embedding_degree_complement'])
        assert (n-1)%comp==0
        k=(n-1)//comp
        kfac=list(factor(k,proof=True))
        assert pow(int(p),int(k),int(n))==1
        assert all(q.is_prime(proof=True) and pow(int(p),int(k//q),int(n))!=1 for q,_ in kfac)
        assert prod(q**e for q,e in kfac)==k
        row['curve_id']=curve_id.prime_id(int(p),int(a),int(b),int(n),end=str(D))
        row['certified_end_evidence']='assessment-certificates.json'
        rs=max(qs)
        cert={
            'source_label':c['name'],'curve':slug,'full_icv1':row['curve_id']['icv1'],
            'field_bits':int(p.nbits()),'order_bits':int(n.nbits()),
            'generic_curve_security_bits_approx':math.log2(int(n))/2,
            'trace':str(t),'frobenius_discriminant':str(D),
            'frobenius_discriminant_abs_prime_factorization':[str(q) for q in fs],
            'frobenius_discriminant_prime_factors_proven':True,
            'frobenius_discriminant_squarefree':True,
            'frobenius_discriminant_is_fundamental':True,
            'frobenius_conductor':1,'endomorphism_conductor':1,
            'endomorphism_discriminant':str(D),
            'endomorphism_ring_certificate':'Ordinary curve: Z[pi] is contained in End(E), which is contained in O_K. Proven fundamental discriminant of Z[pi] implies all three orders are equal.',
            'embedding_degree':str(k),'embedding_degree_bits':int(k.nbits()),
            'embedding_degree_complement':str(comp),
            'embedding_degree_factorization':[[str(q),int(e)] for q,e in kfac],
            'embedding_degree_minimality_proven':True,
            'twist_order':str(nt),'twist_order_prime_factorization':[str(q) for q in qs],
            'twist_prime_factors_proven':True,
            'largest_twist_prime':str(rs),'largest_twist_prime_bits':int(rs.nbits()),
            'twist_cofactor_for_largest_prime':str(nt//rs),
            'generic_twist_security_bits_approx':math.log2(int(rs))/2,
        }
        certs.append(cert)
        print(c['name'],'End conductor 1; embedding degree',k,'twist largest prime',rs.nbits(),'bits',flush=True)
    identities['endomorphism_certification']='assessment-certificates.json'
    (ROOT/'curves.icv1.json').write_text(json.dumps(identities,indent=2)+'\n')
    (ROOT/'assessment-certificates.json').write_text(json.dumps(certs,indent=2)+'\n')


if __name__=='__main__':
    main()
