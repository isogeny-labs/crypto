#set page(width: 1200pt,height:390pt,margin:0pt)
#image("/home/ec2-user/crypto-twist-zero-fiber/research/twist_index_calculus_20261020/zero_fiber_collector/runs/degree-closure-probe-layout-v1/source/figures/flow.svg",width:100%)
