#!/usr/bin/env python3
"""Build the index-calculus leaderboard from frozen evidence.

    python3 scripts/build_ic_leaderboard.py                 # write the three outputs
    python3 scripts/build_ic_leaderboard.py --check         # fail if any is stale
    python3 scripts/build_ic_leaderboard.py --artifact P    # also a publishable copy

Outputs, all derived and never measured here:

- docs/ic/leaderboard.json    the rows, with the SHA-256 of every source file
- docs/ic/LEADERBOARD.md      the same tables in Markdown
- docs/ic-leaderboard.html    the page

The board has no single unit.  It is three tables (A, B, C), each priced in
its own unit against its own reference and floor, and the outputs state
those at the head of each table; see FAMILIES.

Every curve is named by its ICV1 slug (docs/curves/ICV1.md) through the
curve registry.  Every number is read from a frozen file named in
`SOURCES`; the only arithmetic here is averaging the repetitions a report
already holds, dividing a phase's operations by sqrt(r) to express it in S,
and taking a phase's share of its row's total.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import math
import re
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import curve_id as cid  # noqa: E402

REPO = cid.REPO
OUT_JSON = REPO / "docs/ic/leaderboard.json"
OUT_MD = REPO / "docs/ic/LEADERBOARD.md"
OUT_HTML = REPO / "docs/ic-leaderboard.html"

# The ledger section the page is current through (AGENTS.md §7b).  A round
# that adds a later section must update the page, or confirm that the round
# changes nothing on it, and then raise this number; `--check` fails until it
# does, because it cannot otherwise see evidence the builder does not read.
LEDGER = "research/notes/index-calculus/RESEARCH_IC_BOUNDARY_LEDGER.md"
LEDGER_COVERED_THROUGH = 23

SOURCES = {
    "round5": "docs/ic/runs/ic-boundary-ledger-round5-2026-09-22.json",
    "matched_rho": "research/ic_rho_reference_20260923/reprice/ic-boundary-ledger-round5-2026-09-22.json",
    "matched_rho_analysis": "research/ic_rho_reference_20260923/analysis.json",
    "koblitz_s20": "research/ic_exponent_20260926/analysis.json",
    "koblitz_s21": "research/ic_constructions_20260926/analysis.json",
    "koblitz_s22": "research/ic_descent_20260930/analysis-isolated.json",
    "koblitz_s23": "research/ic_single_target_20260930/analysis.json",
    "koblitz_rule_v3": "research/ic_tool_program/rule/v3/analysis.json",
    "oracles": "docs/ic/runs/ic-oracle-pricing-lifted-2026-09-21.json",
    "n37_rank_columns": "research/ecbench_n37_rank_columns_20261004/RESULT.json",
    "n37_k8_k16": "research/ecbench_n37_k8_k16_20261004/DECISION.json",
    "n37_online_ir": "research/ecbench_n37_online_ir_20261004/DECISION.json",
    "n37_online_k8_claim": "research/ecbench_n37_online_ir_20261004/candidate_claims/ic-k8-0.json",
    "n37_online_k16_claim": "research/ecbench_n37_online_ir_20261004/candidate_claims/ic-k16-0.json",
    "n37_native_wall": "research/ecbench_n37_native_online_wall_20261004/DECISION.json",
    "n37_native_wall_evidence": "research/ecbench_n37_native_online_wall_20261004/EVIDENCE.json",
    "f6_small_cold_rows": "research/f6_ic_geometric_closure_20261003/small_cold/measurements.jsonl",
    "f6_small_cold_replay": "research/f6_ic_geometric_closure_20261003/small_cold/replay-certificate.json",
    "f6_ecbench_ladder": "research/f6_ic_ecbench_ladder_20261005/ANALYSIS.json",
    "f4_f5_f6_cross_family": "research/f4_f5_f6_cross_family_20261011/ANALYSIS.json",
    "n41_n53_counted": "research/ecbench_n41_n53_shared_rank_20261005/DECISION.json",
    "conductor_gap_counts": "research/ecbench_conductor_gap_20261012/analysis.json",
    "frontier_audit": "research/ecbench_frontier_20261013/frontier-data.json",
    "n83_matched": "research/n83_matched_20261014/records/postprocess-20261015T0018Z/statistics.json",
    "n83_matched_replay": "research/n83_matched_20261014/records/postprocess-20261015T0018Z/independent_replay_v3_receipt.json",
    "n83_matched_supplement": "research/n83_matched_20261014/records/postprocess-20261015T0018Z/presentation_supplement.json",
    "registry": "docs/curves/registry.json",
    "curves_schema": "docs/curves/ic/curves.schema.json",
    "curves_yaml": "docs/curves/ic/curves.yaml",
}
GITHUB = "https://github.com/aburan28/crypto/blob/main/"
S22_RUNS = "research/ic_descent_20260930/runs-isolated/main"
S23_RUNS = "research/ic_single_target_20260930/runs"
RULE_V3_RUNS = "research/ic_tool_program/rule/v3/runs"

# Phases, in pipeline order, as the page groups them.
PHASES = [
    ("precomputation", "Reusable set-up", "Base, pair table, relations and logs, built once and reusable across targets (one-target Koblitz rows, §23)"),
    ("setup", "Curve and subgroup", "Point count, factoring #E, generator, cofactor clearing"),
    ("constructions", "Workflow constructions", "Orbit maps, point index, collectors and solvers built around the work (Koblitz rows)"),
    ("factor_base", "Factor base", "Choose and materialise the base points, or their orbit representatives"),
    ("table", "Pair table", "Every pair sum of the base, stored for meet-in-the-middle lookups"),
    ("relations", "Relations (PDP)", "Draw targets and decompose each over the base: the point decomposition problem"),
    ("linear_algebra", "Linear algebra", "Eliminate over Z/rZ until the target's column, or every base log, is pinned"),
    ("descent", "Descent", "Decompose each target over the logged base (Koblitz rows; the ladder puts the target in the matrix)"),
    ("verify", "Verification", "Re-add every relation and check [d]G = Q"),
]

VARIANTS = {
    "semaev_s3_roots_m2": "Semaev S3 roots, m = 2",
    "direct_subtraction_m2": "direct subtraction, m = 2",
    "semaev_s4_pairs_and_solve_m3": "Semaev S4 pairs-and-solve, m = 3",
    "mitm_m2": "pair table, m = 2",
    "mitm_m3": "pair table, m = 3",
    "mitm_m2_negfold": "negation-folded table, m = 2",
    "mitm_m3_negfold": "negation-folded table, m = 3",
    "mitm_m2_negfold_walk": "folded table, walked targets, m = 2",
    "mitm_m3_negfold_walk": "folded table, walked targets, m = 3",
    "mitm_m2_negfold_walk_balanced": "folded, walked, base at the family optimum, m = 2",
}
REGIME_NAME = {"prime": "Prime field", "char2": "Random binary", "koblitz": "Koblitz",
               "koblitz_batch": "Koblitz, 32-target batch"}

# The board mixes three unit families.  Their S, × reference and × floor are
# different quantities: a different unit (a count of group-addition
# equivalents, or a clock reading in batched additions), a different
# reference (one-target rho on the matched instance, one-target rho measured
# as built, or 32-target batch rho) and a different floor (a one-target
# bound in additions, a one-target bound in steps, or its 32-target batch
# share).  Every table, chart and summary below reads inside one family.
# The texts are the unit and reference definitions of the sources named in
# SOURCES: ledger §12 and §18 (table B), §20 and §22 (table C), §23 (table A);
# research/ic_exponent_20260926/PROTOCOL.md and
# research/ic_single_target_20260930/PROTOCOL.md.
FAMILY_OF = {"koblitz": "A", "prime": "B", "char2": "B", "koblitz_batch": "C"}
FAMILIES = {
    "A": {
        "title": "Koblitz, one target", "regimes": ["koblitz"], "section": "§23, re-run at baseline v3",
        "status": "primary comparison: one target, as AGENTS.md's one-target rule requires",
        "targets": "one unseen public point per process, 64 per size; §23's figures on the same curve are the before marks",
        "unit": "one batched affine addition (`add_many` over 1,024 subgroup points), per √r",
        "unit_how": "A clock reading, not a count: `ic price` times each phase exclusively, on one thread, "
                    "and divides by this unit, measured around each repetition (§20, §23). Each process measures its own "
                    "unit, which is 2.3–3.2 times cheaper at baseline v3 than in §23's processes, so S here is not "
                    "compared with §23's; the ratios carry no unit (research/ic_tool_program/rule/v3/README.md).",
        "reference": "One-target rho on the same point, measured as built (its set-up plus its walk), "
                     "in the same unit and the same process; its answer replayed and verified (§23; rule v3 at baseline v3).",
        "floor": "√(π/4n) rho steps per √r: generic, one target, no precomputation, A = 2n by signed "
                 "Frobenius and negation, n the extension degree. Stated in steps and not rescaled to "
                 "units, so × floor here divides units by steps.",
        "unit_short": "batched-addition units", "ref_short": "one-target rho",
    },
    "B": {
        "title": "Prime and random-binary ladder", "regimes": ["prime", "char2"], "section": "§18",
        "status": "primary comparison: one target per instance",
        "targets": "one planted target per instance",
        "unit": "one group-addition equivalent (GAE), per √r",
        "unit_how": "A count, not a clock: exact native operation counts converted to additions at the "
                    "dimensionless ratios pinned per instance in `docs/ic/calibration.json` (ns per native "
                    "operation over ns per group addition; all 13 instances used the pinned ratios; "
                    "`ic boundary`, ledger §12). No conversion to table A's or C's unit is applied or "
                    "claimed.",
        "reference": "Matched Pollard rho on the same instance, one target: the negation-map r-adding "
                     "walk (A = 2), counted in GAE, verified [d]G = Q (§18).",
        "floor": "√(π/4) ≈ 0.886 GAE per √r: generic, one target, no precomputation, A = 2 usable "
                 "automorphisms (negation).",
        "unit_short": "GAE", "ref_short": "matched negation-map rho",
    },
    "C": {
        "title": "Koblitz, 32-target batch", "regimes": ["koblitz_batch"], "section": "§19–§22",
        "status": "historical diagnostic under AGENTS.md's one-target rule: 32 targets solved together",
        "targets": "32 targets solved together, priced per target",
        "unit": "one batched affine addition (`add_many` over 1,024 subgroup points), per √r, per target",
        "unit_how": "A clock reading, not a count: `ic price` times each phase exclusively, on one thread, "
                    "and divides by this unit (§20, §22 isolated re-run).",
        "reference": "Batch rho on the same 32 targets (signed Frobenius and negation), its counted "
                     "operations priced at the canonical step, one batched addition plus the table "
                     "canonicalisation, in the same process (§20). Collisions shared across the 32 "
                     "targets are in its cost per target.",
        "floor": "L(32)·√(π/4n) steps per √r per target, with L(32) = 0.19869: the one-target floor of "
                 "table A times Kuhn–Struik's batch share. Stated in steps and not rescaled to units, "
                 "and a smaller object than table A's floor, so × floor in C and in A do not compare.",
        "unit_short": "batched-addition units, per target", "ref_short": "32-target batch rho",
    },
}


def rng(lo: float, hi: float) -> str:
    return g3(lo) if lo == hi else f"{g3(lo)}–{g3(hi)}"


def step_line(f: dict) -> str | None:
    """What one rho step costs in the family's unit, where the unit prices a step."""
    parts = []
    if f.get("rho_step_units_as_built"):
        parts.append(f"rho's walk as built costs {rng(*f['rho_step_units_as_built'])} units a step")
    if f.get("canonical_step_units"):
        parts.append(f"the canonical step costs {rng(*f['canonical_step_units'])}")
    return "; ".join(parts) or None


def sha256(rel: str) -> str:
    return hashlib.sha256((REPO / rel).read_bytes()).hexdigest()


def load(rel: str):
    return json.loads((REPO / rel).read_text())


class Names:
    def __init__(self) -> None:
        self.reg = load(SOURCES["registry"])
        self.by = {}
        for c in self.reg["curves"]:
            for a in c["aliases"] + c["standard_names"] + [c["slug"]]:
                self.by[cid.normalise_alias(a)] = c

    def __call__(self, legacy: str) -> dict:
        c = self.by.get(cid.normalise_alias(legacy))
        if c is None:
            raise SystemExit(f"{legacy!r} is not in docs/curves/registry.json")
        return c


def curve_records() -> dict:
    """The IC curve records in docs/curves/ic/curves.yaml, keyed by ICV1 slug.

    The CI interpreter has no YAML parser, so this reads only the fields the
    page cites (record key, ICV1 slug, factor-base references and their link
    status) from the file's fixed two-space layout, and refuses to build if
    the layout is not the one it expects.
    """
    lines = (REPO / SOURCES["curves_yaml"]).read_text().splitlines()
    if "schema_version: 1" not in lines or "curves:" not in lines:
        raise SystemExit(f"{SOURCES['curves_yaml']}: expected schema_version 1 with a top-level curves map")
    recs, cur, in_icv1, in_refs = [], None, False, False
    for line in lines[lines.index("curves:") + 1:]:
        if line and not line.startswith(" "):
            break
        m = re.fullmatch(r"  ([A-Za-z0-9_]+):", line)
        if m:
            cur = {"key": m.group(1), "slug": None, "factor_base_refs": None, "factor_base_link_status": None}
            recs.append(cur)
            in_icv1 = in_refs = False
            continue
        if cur is None:
            continue
        if re.fullmatch(r"    [A-Za-z_]+:.*", line):
            in_icv1 = line == "    icv1_identity:"
            in_refs = False
            m = re.fullmatch(r"    factor_base_refs:(.*)", line)
            if m:
                v = m.group(1).strip()
                if v == "[]":
                    cur["factor_base_refs"] = []
                elif v == "":
                    cur["factor_base_refs"], in_refs = [], True
                else:
                    raise SystemExit(f"{SOURCES['curves_yaml']}: unreadable factor_base_refs for {cur['key']}")
            m = re.fullmatch(r"    factor_base_link_status: (\S+)", line)
            if m:
                cur["factor_base_link_status"] = m.group(1)
        elif in_icv1 and (m := re.fullmatch(r"      slug: (\S+)", line)):
            cur["slug"] = None if m.group(1) == "null" else m.group(1)
        elif in_refs and (m := re.fullmatch(r"    - (.+)", line)):
            cur["factor_base_refs"].append(m.group(1).strip().strip("'\""))
    if not recs or any(r["factor_base_refs"] is None or r["factor_base_link_status"] is None for r in recs):
        raise SystemExit(f"{SOURCES['curves_yaml']}: every record needs factor_base_refs and factor_base_link_status")
    return {r["slug"]: r for r in recs if r["slug"]}, len(recs)


def curve_record(records: dict, slug: str) -> dict:
    """Where a curve's identity and factor base are recorded."""
    rec = records.get(slug)
    return {"registry": SOURCES["registry"], "schema": SOURCES["curves_schema"],
            "curves_yaml": SOURCES["curves_yaml"], "curves_yaml_key": rec["key"] if rec else None,
            "factor_base_refs": rec["factor_base_refs"] if rec else [],
            "factor_base_link_status": rec["factor_base_link_status"] if rec else "no_curves_yaml_record"}


def ec1_of(c: dict) -> str | None:
    reps = c.get("representations") or []
    return reps[0]["ec1"] if reps else None


# ---------------------------------------------------------------------------
# The prime and random-binary ladder: Round 5, priced against the matched rho.
# ---------------------------------------------------------------------------


def ladder_rows(names: Names) -> list[dict]:
    r5 = load(SOURCES["round5"])
    mr = {i["instance"]: i for i in load(SOURCES["matched_rho"])["instances"]
          if i["regime"] in ("prime", "char2")}
    rows = []
    for inst in r5["ledger"]["instances"]:
        if inst["regime"] not in ("prime", "char2"):
            continue
        legacy = inst["curve"]["name"]
        c = names(legacy)
        ref = mr[legacy]
        rho_s = ref["matched_reference"]["mean_s"]
        sqrt_r = math.sqrt(inst["r"])
        by_variant: dict[str, list] = {}
        for v in inst["variants"]:
            by_variant.setdefault(v["name"], []).append(v)
        recipes = []
        for name, reps in by_variant.items():
            mean = lambda f: statistics.fmean(f(x) for x in reps)  # noqa: E731
            phases = {
                "factor_base": mean(lambda x: x["factor_base"]["gae"]) / sqrt_r,
                "relations": mean(lambda x: x["relations"]["gae"]) / sqrt_r,
                "linear_algebra": mean(lambda x: x["linear_algebra"]["gae"]) / sqrt_r,
                "verify": mean(lambda x: x["verify"]["gae"]) / sqrt_r,
            }
            s = mean(lambda x: x["s"])
            recipes.append({
                "variant": name, "label": VARIANTS.get(name, name),
                "m": reps[0]["summands"], "base_points": reps[0]["signed_points"],
                "columns": reps[0]["columns"], "table": reps[0]["table"],
                "targets": reps[0]["targets"], "trials": mean(lambda x: x["trials"]),
                "relations": mean(lambda x: x["relations_found"]),
                "yield_over_ceiling": mean(lambda x: x["yield_over_ceiling_exact"]),
                "s": s, "phases_s": phases, "ratio_rho": s / rho_s,
                "ratio_floor": s / math.sqrt(math.pi / 4),
                "verified": all(x["verified"] for x in reps), "repetitions": len(reps),
            })
        recipes.sort(key=lambda x: x["s"])
        rows.append({
            "regime": inst["regime"], "slug": c["slug"], "ec1": ec1_of(c),
            "legacy": legacy, "log2_r": inst["log2_r"], "cofactor": inst["cofactor"],
            "reference": "matched rho, negation map (A = 2), one target",
            "reference_s": rho_s, "floor_s": math.sqrt(math.pi / 4),
            "targets": 1, "recipes": recipes, "best": recipes[0],
            "source": SOURCES["round5"], "round": "Round 5 (2026-09-22), reference §18 (2026-09-23)",
            "class": "accounting",
        })
    return rows


# ---------------------------------------------------------------------------
# The Koblitz thread: §20's sweep at nine sizes, §21's constructions built once.
# ---------------------------------------------------------------------------

KOBLITZ_GROUPS = {
    "setup": ("setup",),
    "constructions": ("select_projection", "collect_setup", "logs_setup", "descent_setup"),
    "factor_base": ("select",),
    "table": ("build",),
    "relations": ("collect",),
    "linear_algebra": ("la",),
    "descent": ("descent",),
    "verify": ("verify", "verify_final", "other"),
}


def koblitz_phase_shares(a: int, n: int) -> tuple[dict, dict]:
    """Shares of each phase in §22's candidate reports (the isolated
    re-run): the median over five rounds within each set, then the mean
    over the four sets."""
    per_set = []
    counts = None
    for s in ("M1", "M2", "M3", "M4"):
        d = REPO / S22_RUNS / f"k{a}n{n}" / s
        reports = sorted(d.glob("r*-candidate.price.json"))
        if not reports:
            continue
        docs = [json.loads(p.read_text()) for p in reports]
        counts = counts or docs[0]["counts"]
        med = {}
        for g, keys in KOBLITZ_GROUPS.items():
            med[g] = statistics.median(sum(x["median"]["phases_units"].get(k, 0.0) for k in keys)
                                       for x in docs)
        tot = sum(med.values())
        per_set.append({g: v / tot for g, v in med.items()})
    shares = {g: statistics.fmean(p[g] for p in per_set) for g in KOBLITZ_GROUPS}
    return shares, counts or {}


def koblitz_rows(names: Names) -> list[dict]:
    """The Koblitz thread on current evidence (§22, isolated), with §21 and
    §22's own baseline as the before marks and §20's one-target cold ratio.

    These rows solve 32 targets together and are priced per target against
    batch rho on the same 32.  AGENTS.md ("Primary comparison uses one
    target") makes that a historical diagnostic, not a primary comparison,
    so each row carries its target count and the one-target figure §20
    measured beside it."""
    s20 = {x["curve"]: x for x in load(SOURCES["koblitz_s20"])["sizes"]}
    s21 = {x["curve"]: x for x in load(SOURCES["koblitz_s21"])["sizes"]}
    rows = []
    for x in load(SOURCES["koblitz_s22"])["sizes"]:
        c = names(x["curve"])
        a, n = x["a"], x["n"]
        before = s20[x["curve"]]
        shares, counts = koblitz_phase_shares(a, n)
        s = x["s_after"]
        floor_s = before["sets"][0]["floor"]  # L(32)·√(π/4n), per target
        logs = counts.get("logs", {})
        la = logs.get("linear_algebra", {})
        recipe = {
            "variant": "koblitz_collection_m3_aimed",
            "label": f"aimed m = 3 collection, m = {before['chosen']['descent_summands']} descent",
            "m": 3, "descent_summands": before["chosen"]["descent_summands"],
            "base_points": before["sets"][0]["points"], "columns": before["chosen"]["columns"],
            "table": before["sets"][0]["tier"], "stored_pairs": before["sets"][0]["stored_pairs"],
            "targets": "32 targets, batch", "relations": before["sets"][0]["relations"],
            "summands_scanned": before["sets"][0]["summands_scanned"],
            "descent_trials_per_target": before["sets"][0]["descent_trials"] / 32,
            "la_rows_in": la.get("filter", {}).get("rows_in"),
            "la_core_dimension": la.get("core_dimension"),
            "trials": counts.get("collect", {}).get("trials"),
            "s": s, "s_before": x["s_before"],
            "phases_s": {g: shares[g] * s for g in shares},
            "ratio_rho": x["ratio_after"],
            "ratio_rho_ci": [x["ratio_after_ci"]["lo"], x["ratio_after_ci"]["hi"]],
            "ratio_rho_before": x["ratio_before"],
            "ratio_rho_section21": s21[x["curve"]]["ratio_after"],
            "ratio_rho_section20": before["ratio"],
            "one_target_cold_ratio_section20": before["cold_ratio_M1"],
            "speedup": x["speedup"]["geomean"], "speedup_ci": [x["speedup"]["lo"], x["speedup"]["hi"]],
            "canonical_step_units": before["canonical_step_units"],
            "ratio_floor": s / floor_s, "verified": bool(x["pins"] and x["control1"]),
        }
        rows.append({
            "regime": "koblitz_batch", "slug": c["slug"], "ec1": ec1_of(c), "legacy": x["curve"],
            "log2_r": x["log2_r"], "cofactor": None,
            "reference": "batch rho, signed Frobenius and negation, the same 32 targets "
                         "(a 32-target batch: a historical diagnostic under AGENTS.md's one-target rule)",
            "reference_s": x["s_rho_s20"], "floor_s": floor_s, "targets": 32,
            "recipes": [recipe], "best": recipe, "source": SOURCES["koblitz_s22"],
            "round": "§22 isolated re-run (2026-09-30); before marks §21 and §22's baseline on main",
            "class": "engineering",
        })
    return rows


def koblitz_one_target_rows(names: Names) -> list[dict]:
    """Ledger §23's comparison: one unseen public point per process, 64 per
    size, re-run at the IC tool programme's baseline v3 as rule v3.  The
    primary comparison under AGENTS.md's one-target rule.  S here is cold,
    the reusable set-up plus the online interval, against one-target rho's
    set-up plus its walk; the online speedup, the canonical-step reading and
    the Bernstein–Lange precomputation model ride beside it, never alone.
    §23's figures on the same curve are the row's before marks.  Each
    process prices S in its own batched addition, so a row's S is not
    compared with §23's; the ratios carry no unit."""
    rows = []
    s23 = {(x["a"], x["n"]): x for x in load(SOURCES["koblitz_s23"])["sizes"]}
    for x in load(SOURCES["koblitz_rule_v3"])["sizes"]:
        a, n = x["a"], x["n"]
        before = s23[(a, n)]
        c = names(before["curve"])
        if c["slug"] != x["curve"]:
            raise SystemExit(f"rule v3's {x['curve']} is not §23's {before['curve']}")
        par = json.loads((REPO / RULE_V3_RUNS / f"k{a}n{n}" / "T01.params.json").read_text())
        columns = int(re.search(r"-c(\d+)-", par["name"]).group(1))
        d = x["diagnostics"]
        sh = d["online_phase_shares"]
        online, setup = x["s_ic_online_mean"], x["s_setup"]
        s = setup + online
        floor_s = math.sqrt(math.pi / (4 * n))
        artefact = d["s_curve_construction"] > x["s_rho_online_mean"]
        recipe = {
            "variant": "koblitz_one_target",
            "label": f"aimed m = {par['summands']} collection, m = {par['descent_summands']} descent; one target",
            "m": par["summands"], "descent_summands": par["descent_summands"],
            "base_points": par["factor_base"]["spec"]["points"], "columns": columns,
            "targets": "one public point per process, 64 per size",
            "s": s, "s_online": online, "s_setup": setup,
            "phases_s": {"precomputation": setup,
                         "descent": online * (sh["target_query"] + sh["target_pdp"]
                                              + sh["target_descent"] + sh["target_relation_check"]),
                         "verify": online * sh["recovery_check"]},
            "ratio_rho": x["cold_ratio_ic_over_rho"]["value"],
            "ratio_rho_ci": list(x["cold_ratio_ic_over_rho"]["ci95"]),
            "ratio_rho_section23": before["cold_ratio_ic_over_rho"]["value"],
            "online_speedup_section23": before["online_speedup"]["mean_ratio"],
            "online_speedup": x["online_speedup"]["mean_ratio"],
            "online_speedup_ci": list(x["online_speedup"]["ci95"]),
            "online_speedup_canonical_step": x["online_speedup_rho_model"]["mean_ratio"],
            "ic_online_over_precomputation_model": x["precomputation_boundary_model"]["ic_online_over_bl"],
            "break_even_targets": x["break_even_targets"]["value"],
            "construction_artefact": artefact,
            "canonical_step_units": x["canonical_step_units"],
            "rho_step_units_as_built": x["rho_units_per_step_median"],
            "cold_ratio_without_curve_construction": d["cold_ratio_without_curve_construction"],
            "ratio_floor": s / floor_s,
            "verified": bool(x["all_rows_pass_the_check"]),
        }
        rows.append({
            "regime": "koblitz", "slug": c["slug"], "ec1": x.get("curve_id") or ec1_of(c),
            "legacy": before["curve"], "log2_r": x["log2_r"], "cofactor": None,
            "reference": "one-target rho on the same point, its set-up plus its walk (§23's rule, at baseline v3)",
            "reference_s": x["s_rho_online_mean"] + x["s_rho_setup"], "floor_s": floor_s,
            "targets": 1, "recipes": [recipe], "best": recipe, "source": SOURCES["koblitz_rule_v3"],
            "before_source": SOURCES["koblitz_s23"],
            "round": "rule v3: §23's comparison at baseline v3 (2026-10-06); before marks §23 (2026-09-30)",
            "class": "accounting",
        })
    return rows


# ---------------------------------------------------------------------------
# The decomposition oracles, per target.
# ---------------------------------------------------------------------------

ORACLE_LABEL = {
    "enumerate_m2": "enumerate", "enumerate_m3": "enumerate",
    "meet_in_the_middle_m2": "pair table", "meet_in_the_middle_m3": "pair table",
    "semaev_s4_pairs_and_solve": "S4 pairs-and-solve",
    "matrix_f4_splitting": "matrix F4", "cdcl_sat_native_xor": "CDCL SAT",
}


def oracle_rows(names: Names) -> list[dict]:
    rows = []
    for cell in load(SOURCES["oracles"])["oracle_pricing"]["cells"]:
        c = names(cell["curve"]["name"])
        rows.append({
            "slug": c["slug"], "n": cell["n"], "m": cell["m"], "dimension": cell["dimension"],
            "unknowns": cell["unknowns"], "equations": cell["equations"],
            "ffd": [cell["ffd_min"], cell["ffd_max"]], "hit_rate": cell["hit_rate"],
            "log2_r": cell["log2_r"], "disagreements": cell["disagreements"],
            "oracles": {ORACLE_LABEL.get(o["oracle"], o["oracle"]): {
                "gae_per_target": o["gae_per_target_mean"], "found": o["found"],
                "refuted": o.get("refuted", 0), "inconclusive": o.get("inconclusive", 0)}
                for o in cell["oracles"]},
        })
    return rows


# ---------------------------------------------------------------------------
# Exponents.
# ---------------------------------------------------------------------------


def exponents() -> dict:
    fits = load(SOURCES["round5"])["ledger"]["fits"]
    lead = {"prime": "mitm_m2_negfold_walk_balanced", "char2": "mitm_m2_negfold_walk_balanced"}
    out: dict = {}
    for regime, variant in lead.items():
        ph = {f["phase"]: {"alpha": f["alpha"], "r2": f["r_squared"], "points": f["points"]}
              for f in fits if f["regime"] == regime and f["variant"] == variant}
        out[regime] = {"variant": variant, "phases": ph,
                       "variants_total": {f["variant"]: {"alpha": f["alpha"], "r2": f["r_squared"]}
                                          for f in fits if f["regime"] == regime
                                          and f["phase"] == "total" and f["variant"] != "rho_reference"}}
    rho = load(SOURCES["matched_rho_analysis"])["tables"]["rho_exponent_round5_ladder"]
    for regime in ("prime", "char2"):
        out[regime]["rho_matched"] = {"alpha": rho[f"{regime}/rho_matched"]["alpha"],
                                      "r2": rho[f"{regime}/rho_matched"]["r_squared"]}
    s22 = load(SOURCES["koblitz_s22"])["exponent_refit"]
    out["koblitz"] = {"quantity": "ratio to batch rho times sqrt(n), against r, four largest sizes",
                      "beta": s22["after"]["beta"], "ci": [s22["after"]["lo"], s22["after"]["hi"]],
                      "points": s22["after"]["points"], "law": 1 / 6, "model": 0.141}
    return out


def roster(names: Names, measured: set[str]) -> list[dict]:
    out = []
    for c in names.reg["curves"]:
        p = c["params"]
        if c["family"] == "prime":
            field = f"GF(p), p = {p['p']}" if len(p["p"]) < 40 else f"GF(p), {int(p['p']).bit_length()}-bit p"
            coeff = f"a = {p['a']}, b = {p['b']}" if len(p["p"]) < 40 else "standard coefficients"
        else:
            m = p.get("n", p.get("m"))
            field = f"GF(2^{m})"
            a = p.get("a")
            coeff = (f"a = {a}, b = 1" if c["family"] == "koblitz"
                     else f"a = {a}, b = {p.get('b')}")
        out.append({
            "slug": c["slug"], "family": c["family"], "field": field, "coefficients": coeff,
            "order_bits": int(c["order"]).bit_length(), "standard": c["standard_names"],
            "ec1": [r["ec1"] for r in c.get("representations", [])],
            "ec1_unresolved": c.get("ec1_unresolved"), "legacy": c["aliases"][:4],
            "on_board": c["slug"] in measured,
        })
    return out


def families(board: list[dict]) -> dict:
    out = {}
    for code, f in FAMILIES.items():
        rows = [r for r in board if r["family"] == code]
        canon = [r["best"]["canonical_step_units"] for r in rows if "canonical_step_units" in r["best"]]
        built = [r["best"]["rho_step_units_as_built"] for r in rows if "rho_step_units_as_built" in r["best"]]
        out[code] = {**f, "rows": len(rows),
                     "canonical_step_units": [min(canon), max(canon)] if canon else None,
                     "rho_step_units_as_built": [min(built), max(built)] if built else None}
    return out


def latest_frontier_audit() -> dict:
    """Copy the accounting-only frontier synthesis into the generated board.

    This record is deliberately separate from the ranked curve rows: its source
    says that no admitted whole-pipeline measurement, reference, or curve moved.
    """
    audit = load(SOURCES["frontier_audit"])
    effect = audit.get("leaderboard_effect", {})
    cold = audit.get("canonical_koblitz_medium", {}).get("ops_leader", {})
    online = {row.get("label"): row for row in audit.get("online_boundary", [])}
    n61 = online.get("n61 compact orbit", {})
    n83 = online.get("n83 dense K1798", {})
    failed = next((r for r in audit.get("current_replay_audit", {}).get("receipts", [])
                   if r.get("file") == "audits/rootfind-n13-replay-all-failed.json"), {})
    if (audit.get("schema") != "crypto.ecbench_frontier_synthesis/v1"
            or audit.get("classification") != "evidence synthesis; no new bound or challenge verdict"
            or effect.get("ranked_rows_changed") is not False
            or effect.get("generated_audit_record_required") is not True
            or cold.get("method") != "rho.signed_frobenius_strong"
            or cold.get("bound_id") != "ECBND1h05a2ea918f3c"
            or n61.get("status") != "admitted online"
            or n61.get("targets") != 64
            or n83.get("status") != "exploratory one point"
            or n83.get("targets") != 1
            or "not a matched cold ratio" not in n83.get("setup_inclusive_class", "")
            or failed.get("ok") is not False
            or failed.get("replays_identical") != 120
            or failed.get("replays_total") != 168
            or failed.get("failures") != 48):
        raise SystemExit("review the ECBench frontier audit before updating the leaderboard")
    return {
        "date": audit["date"],
        "source": SOURCES["frontier_audit"],
        "classification": audit["classification"],
        "ranked_rows_changed": effect["ranked_rows_changed"],
        "reason": effect["reason"],
        "cold": {
            "method": cold["method"], "bound_id": cold["bound_id"],
            "ops_over_floor": cold["ops_over_floor"], "ops_ci95": cold["ops_ci95"],
            "runs": cold["runs"], "sizes": cold["sizes"],
        },
        "admitted_online": {
            "label": n61["label"], "rho_over_ic": n61["online_rho_over_ic"],
            "ci95": n61["online_ci95"], "targets": n61["targets"],
            "setup_seconds_approx": n61["setup_seconds_approx"], "status": n61["status"],
        },
        "exploratory_online": {
            "label": n83["label"], "rho_over_ic": n83["online_rho_over_ic"],
            "targets": n83["targets"], "complete_process_seconds": n83["complete_process_seconds"],
            "setup_inclusive_class": n83["setup_inclusive_class"],
            "first_integer_break_even_under_model": n83["first_integer_break_even_under_model"],
            "status": n83["status"],
        },
        "replay_block": {
            "identical": failed["replays_identical"], "total": failed["replays_total"],
            "failures": failed["failures"], "scope": failed["failure_scope"],
        },
    }


def matched_n83_diagnostic() -> dict:
    """Quote native local-process observations outside every ranked table."""
    result = load(SOURCES["n83_matched"])
    replay = load(SOURCES["n83_matched_replay"])
    supplement = load(SOURCES["n83_matched_supplement"])
    if (result.get("schema") != "n83_matched_statistics_v1"
            or result.get("all_required_rows_valid") is not True
            or result.get("overall_primary_winner_eligible") is not True
            or replay.get("status") != "PASS"
            or replay.get("complete_panel_gate") is not True
            or replay.get("completed_verified_processes") != 32
            or replay.get("checked_target_rows") != 218
            or replay.get("IC_four_point_witness_replays") != 104
            or replay.get("checked_aa_semantic_pairs") != 5
            or replay.get("invalid_rows") != 0
            or supplement.get("schema") != "n83_matched_supplement_v1"
            or supplement.get("counts") != {"ic_targets": 104, "rho_targets": 114,
                                             "all_targets": 218, "processes": 32}
            or supplement["provenance"]["frozen_statistics"]["sha256"]
            != sha256(SOURCES["n83_matched"])
            or result["input_metadata"]["independent_verification_receipt_sha256"]
            != sha256(SOURCES["n83_matched_replay"])):
        raise SystemExit("matched N83 diagnostic requires the complete bound native replay and analysis")
    return {
        "source": SOURCES["n83_matched"],
        "replay_source": SOURCES["n83_matched_replay"],
        "presentation_source": SOURCES["n83_matched_supplement"],
        "curve": "icv1-f2m83-t6151469093347-9eba6cd5",
        "measurement_date": "2026-10-14",
        "class": "accounting",
        "admission": "local diagnostic only; no ranked recipe or ledger promotion",
        "S": None,
        "ratio_to_floor": None,
        "controlled_speedup": None,
        "cold": result["primary_actual_cold_singleton_process_wall"],
        "batch": result["primary_prepared_batch_process_wall"],
        "online": result["secondary_prepared_online_target_means"],
        "costs": result["costs"],
        "observed_counts": result["observed_counts"],
        "verification": {k: replay[k] for k in (
            "completed_verified_processes", "checked_target_rows",
            "IC_scalar_replays", "rho_scalar_replays", "IC_four_point_witness_replays",
            "checked_aa_semantic_pairs", "aa_semantic_gate", "invalid_rows", "missing_target_rows")},
        "limits": (
            "Eight actual one-target cold pairs and three actual 32-target shared-setup pairs, "
            "given retained K600; original base construction and OS-cold caching are unmeasured. "
            "Rho reuses curve/basis preparation with fresh seed-specific jumps and fresh DP state. "
            "Online is secondary because IC omits validation/output intervals charged by rho. "
            "One VM, three preparation clusters, fixed IC rank seed 29; no common S, "
            "sealed legacy-wide ecbench admission, physical-host or independent-host claim. "
            "Modeled workloads beyond 32 are not measured crossovers."
        ),
    }


def build() -> dict:
    names = Names()
    frontier_audit = latest_frontier_audit()
    small_rows = [json.loads(line) for line in (REPO / SOURCES["f6_small_cold_rows"]).read_text().splitlines() if line]
    small_replay = load(SOURCES["f6_small_cold_replay"])
    small_by_arm = {row["arm"]: row for row in small_rows}
    if (len(small_rows) != 3
            or set(small_by_arm) != {"inherited_f4", "f6_ic", "f5"}
            or small_replay["status"] != "verified"
            or len(small_replay["runs"]) != 3
            or any(row["status"] != "complete" or row["exit_status"] != 0
                   or row["workload_id"] != "f6d79f6dd9f2"
                   or row["target"] != [305, 466]
                   or row["recovered"] != "4"
                   or row["actual_usable_base_points"] != 14
                   or row["folded_columns"] != 2
                   or row["verified_relations"] != 8
                   or row["cold_inside_worker_ns"] != row["cold_phase_sum_ns"]
                   or row["online_wall_ns"] != row["online_phase_sum_ns"]
                   for row in small_rows)
            or any(not all(replay[key] for key in (
                "group_replay", "phase_closure", "relation_certified",
                "relations_replayed", "column_logs_replayed"))
                for replay in small_replay["runs"])):
        raise SystemExit("review the n9 F6-IC cold result before updating the leaderboard")
    for arm, row in small_by_arm.items():
        replay = next((r for r in small_replay["runs"]
                       if r["run_file"].endswith(f"R1-{arm}.stdout.json")), None)
        if (replay is None or replay["cold_inside_worker_ns"] != row["cold_inside_worker_ns"]
                or replay["online_ns"] != row["online_wall_ns"]):
            raise SystemExit("n9 F6-IC replay and measurement disagree")
    small_cold_diagnostic = {
        "curve": names("icv1-f2m9-tm5-4a3ea183")["slug"],
        "source": SOURCES["f6_small_cold_rows"],
        "replay": SOURCES["f6_small_cold_replay"],
        "workload_id": "f6d79f6dd9f2",
        "target": [305, 466],
        "usable_points": 14,
        "folded_columns": 2,
        "verified_relations": 8,
        "arms": {arm: {"candidate_id": row["candidate_id"],
                       "cold_inside_worker_ns": row["cold_inside_worker_ns"],
                       "online_wall_ns": row["online_wall_ns"]}
                 for arm, row in small_by_arm.items()},
        "rho_online_ms": None,
        "online_speedup": None,
        "cpu_isolation": "L0-unverified-mac",
    }
    ladder = load(SOURCES["f6_ecbench_ladder"])
    if (ladder["schema"] != "f6-ic-ladder-analysis/v2"
            or not ladder["decision"].startswith("not decidable")):
        raise SystemExit("review the F6-IC ladder decision before updating the leaderboard")
    ladder_diagnostic = {
        "source": SOURCES["f6_ecbench_ladder"],
        "decision": ladder["decision"],
        "class": "relabelling; stage diagnostic with solver word XORs unpriced (S is a lower bound)",
        "sizes": [
            {
                "m": z["m"],
                "curve": names(z["slug"])["slug"],
                "targets": z["targets_completed_both_ic_arms"],
                "rho_s": z["rho_median_s"],
                "f4_s_lower_over_rho": z["arms"]["ic-f4"]["median_s_lower_over_rho"],
                "f6_s_lower_over_rho": z["arms"]["ic-f6"]["median_s_lower_over_rho"],
                "median_log2_w4_over_w6": z["median_log2_w4_over_w6"],
            }
            for z in ladder["per_size"] if z["targets_completed_both_ic_arms"] > 0
        ],
        "online_speedup": None,
        "fully_priced_cold_speedup": None,
    }
    cross = load(SOURCES["f4_f5_f6_cross_family"])
    if cross["schema"] != "f4f5f6-cross-family-analysis/v1":
        raise SystemExit("review the F4/F5/F6 cross-family analysis before updating the leaderboard")

    def med(arms: dict, arm: str, field: str):
        v = (arms.get(arm) or {}).get(field)
        return v["median"] if v else None

    cross_rows = []
    for key in ("K13", "R13", "K19", "R19"):
        for c in cross["sessions"][key]["cells"]:
            q = c["questions"]
            cross_rows.append({
                "session": key,
                "family": c["family"],
                "m": c["m"],
                "curve": names(c["slug"])["slug"],
                "base_points": (c["arms"].get("f6-ic") or {}).get("base_points"),
                "rho_negation_s": med(c["arms"], "rho-negation", "s"),
                "rho_strong_s": med(c["arms"], "rho-strong", "s"),
                "inherited_s": med(c["arms"], "inherited-f4", "s"),
                "f6_s": med(c["arms"], "f6-ic", "s"),
                "f5_over_f4_w": (q.get("q1_f5_over_f4_word_xors") or {}).get("ratio", {}).get("median"),
                "matrix_f4_over_inherited_w": (q.get("q2_matrix_f4_over_inherited_word_xors") or {}).get("ratio", {}).get("median"),
                "log2_inherited_over_f6_w": q["q3_log2_inherited_over_f6_word_xors"]["log2_ratio"]["median"],
                "f6_verdict": q["q3_log2_inherited_over_f6_word_xors"]["verdict"],
            })
    cross_diagnostic = {
        "source": SOURCES["f4_f5_f6_cross_family"],
        "class": "relabelling; stage diagnostic with solver word XORs unpriced (S is a lower bound)",
        "rows": cross_rows,
        "online_speedup": None,
        "fully_priced_cold_speedup": None,
    }
    rank_columns = load(SOURCES["n37_rank_columns"])
    if (rank_columns["status"] != "independently_replayed_l0_bounded_diagnostic"
            or rank_columns["selection"]["decision"] != "COUNTED_ENGINEERING_LEAD"
            or rank_columns["selection"]["selected_k"] != 16
            or rank_columns["online_speedup"] is not None
            or rank_columns["fully_priced_cold_speedup"] is not None):
        raise SystemExit("review the n37 bounded result before updating the leaderboard")
    selected = next(c for c in rank_columns["candidates"] if c["folded_columns"] == 16)
    bounded_diagnostic = {
        "curve": names("icv1-f2m37-tm534059-32aad96b")["slug"],
        "source": SOURCES["n37_rank_columns"],
        "class": "counted engineering lead over K42; no admitted IC/rho speedup",
        "candidate_id": selected["candidate_id"],
        "usable_points": selected["usable_points"],
        "folded_columns": selected["folded_columns"],
        "measured_runs": selected["measured_runs"],
        "mean_cold_s_lower_bound": selected["mean_cold_s_lower_bound"],
        "cold_counted_over_rho_diagnostic": selected["cold_counted_over_rho_diagnostic"],
        "cold_counted_over_k42_diagnostic": selected["cold_counted_over_k42_diagnostic"],
        "online_speedup": None,
        "fully_priced_cold_speedup": None,
    }
    k8_decision = load(SOURCES["n37_k8_k16"])
    if (k8_decision["schema"] != "ecbench.k8_k16_callgrind_decision/v1"
            or k8_decision["decision"] != "select_k8_for_larger_field_gate"
            or k8_decision["workloads"] != 16
            or k8_decision["profiles"] != 64
            or not k8_decision["all_archived_and_profiled_scalars_verified"]
            or k8_decision["comparisons"][0]["numerator"] != "ic-k16"
            or k8_decision["comparisons"][0]["denominator"] != "ic-k8"
            or k8_decision["comparisons"][1]["denominator"] != "rho-strong"):
        raise SystemExit("review the untouched K8/K16 instruction result before updating the leaderboard")
    k8_prior = next(c for c in rank_columns["candidates"] if c["folded_columns"] == 8)
    k8_confirmation = {
        "curve": names("icv1-f2m37-tm534059-32aad96b")["slug"],
        "source": SOURCES["n37_k8_k16"],
        "candidate_id": k8_prior["candidate_id"],
        "usable_points": k8_prior["usable_points"],
        "folded_columns": k8_prior["folded_columns"],
        "workloads": k8_decision["workloads"],
        "profiles": k8_decision["profiles"],
        "decision": k8_decision["decision"],
        "k16_over_k8_ir": k8_decision["comparisons"][0]["ratio_of_sums"],
        "k16_over_k8_ir_ci95": k8_decision["comparisons"][0]["bootstrap_95"],
        "k8_over_rho_ir": k8_decision["comparisons"][1]["ratio_of_sums"],
        "k8_over_rho_ir_ci95": k8_decision["comparisons"][1]["bootstrap_95"],
        "online_speedup": None,
        "cold_wall_speedup": None,
    }
    online_ir_decision = load(SOURCES["n37_online_ir"])
    online_k8_claim = load(SOURCES["n37_online_k8_claim"])
    online_k16_claim = load(SOURCES["n37_online_k16_claim"])
    if (online_ir_decision["schema"] != "ecbench.n37_online_ir_decision/v1"
            or online_ir_decision["decision"] != "prioritize_k16_for_isolated_n37_online_wall_gate"
            or online_ir_decision["workloads"] != 16
            or online_ir_decision["profiles"] != 64
            or not online_ir_decision["all_archived_and_profiled_scalars_verified"]
            or online_ir_decision["online"]["aa_max_absolute_relative_deviation"] != 0
            or online_ir_decision["online"]["comparisons"][0]["numerator"] != "ic-k8"
            or online_ir_decision["online"]["comparisons"][0]["denominator"] != "ic-k16"
            or online_ir_decision["online"]["comparisons"][2]["denominator"] != "rho-strong"
            or online_ir_decision["online"]["comparisons"][0]["bootstrap_95"][0] <= 1.10):
        raise SystemExit("review the target-only n37 instruction decision before updating the leaderboard")
    for claim, count, columns in [(online_k8_claim, 592, 8), (online_k16_claim, 1184, 16)]:
        fb = claim["candidate_manifest"]["factor_base"]["inventory"]
        if (not claim["independent_validation"] or not claim["ic_scalar_verified"]
                or not claim["rho_scalar_verified"]
                or claim["isolation_levels"]["ic"] != "L0"
                or claim["isolation_levels"]["rho"] != "L0"
                or fb["usable_point_count"] != count
                or fb["effective_columns"] != columns):
            raise SystemExit("review the exact n37 IC1 claims before updating the leaderboard")
    online_ir_diagnostic = {
        "curve": names("icv1-f2m37-tm534059-32aad96b")["slug"],
        "source": SOURCES["n37_online_ir"],
        "k8_candidate_id": online_k8_claim["candidate_id"],
        "k16_candidate_id": online_k16_claim["candidate_id"],
        "workloads": online_ir_decision["workloads"],
        "profiles": online_ir_decision["profiles"],
        "decision": online_ir_decision["decision"],
        "k8_over_k16_online_ir": online_ir_decision["online"]["comparisons"][0]["ratio_of_sums"],
        "k8_over_k16_online_ir_ci95": online_ir_decision["online"]["comparisons"][0]["bootstrap_95"],
        "k16_over_rho_online_ir": online_ir_decision["online"]["comparisons"][2]["ratio_of_sums"],
        "k16_over_rho_online_ir_ci95": online_ir_decision["online"]["comparisons"][2]["bootstrap_95"],
        "k8_over_k16_cold_ir": online_ir_decision["complete_solve"]["comparisons"][0]["ratio_of_sums"],
        "online_wall_speedup": None,
    }
    native_wall_decision = load(SOURCES["n37_native_wall"])
    native_wall_evidence = load(SOURCES["n37_native_wall_evidence"])
    if (native_wall_decision["schema"] != "ecbench.native_online_wall_decision/v1"
            or native_wall_decision["status"] != "complete_exploratory_hosted"
            or native_wall_decision["decision"] != "carry_both_host_noise_exceeds_gate"
            or native_wall_decision["measured_verified_runs"] != 320
            or native_wall_decision["same_target_paired_rounds"] != 80
            or native_wall_decision["isolation_levels"] != {"L1": 320}
            or native_wall_decision["all_measured_L2"]
            or native_wall_decision["online_speedup"] is not None
            or native_wall_decision["k16_aa_max_relative_deviation"] <= .05
            or native_wall_decision["primary_one_target"]["target_index"] != 0
            or native_wall_decision["candidate_ids"]["ic-k8"] != online_k8_claim["candidate_id"]
            or native_wall_decision["candidate_ids"]["ic-k16"] != online_k16_claim["candidate_id"]
            or native_wall_evidence["decision_sha256"] != sha256(SOURCES["n37_native_wall"])
            or native_wall_evidence["records_sha256"] != native_wall_decision["records_sha256"]
            or native_wall_evidence["independent_receipt_sha256"] != native_wall_decision["independent_receipt_sha256"]):
        raise SystemExit("review the L1 native wall decision before updating the leaderboard")
    native_wall_diagnostic = {
        "curve": names("icv1-f2m37-tm534059-32aad96b")["slug"],
        "source": SOURCES["n37_native_wall"],
        "evidence": SOURCES["n37_native_wall_evidence"],
        "k8_candidate_id": native_wall_decision["candidate_ids"]["ic-k8"],
        "k16_candidate_id": native_wall_decision["candidate_ids"]["ic-k16"],
        "primary_workload_id": native_wall_decision["primary_one_target"]["workload_id"],
        "measured_verified_runs": native_wall_decision["measured_verified_runs"],
        "isolation_levels": native_wall_decision["isolation_levels"],
        "decision": native_wall_decision["decision"],
        "aa_max_relative_deviation": native_wall_decision["k16_aa_max_relative_deviation"],
        "primary_rho_over_k16_online_wall": native_wall_decision["primary_one_target"]["descriptive_rho_over_k16"],
        "panel_k8_over_k16_online_wall": native_wall_decision["panel_descriptive_ratios"]["k8_over_k16"]["ratio_of_sums"],
        "panel_k8_over_k16_online_wall_ci95": native_wall_decision["panel_descriptive_ratios"]["k8_over_k16"]["target_block_bootstrap_95"],
        "admitted_online_speedup": None,
    }
    n4153 = load(SOURCES["n41_n53_counted"])
    if (n4153["schema"] != "ecbench.n41_n53_shared_rank_decision/v1"
            or n4153["status"] != "complete_l0_counted_diagnostic"
            or n4153["online_speedup"] is not None
            or n4153["fully_priced_cold_speedup"] is not None
            or n4153["all_measured_L2"]
            or n4153["measured_runs"] != 640):
        raise SystemExit("review the n41/n53 counted decision before updating the leaderboard")

    def quotient(c: dict, key: str) -> dict:
        q = c["secondary_counted"][key]
        return {"ratio_of_sums": q["ratio_of_sums"], "ci95": q["ci95"], "pairs": q["pairs"]}
    n41_n53_diagnostic = {
        "source": SOURCES["n41_n53_counted"],
        "decision": n4153["decision"],
        "class": "accounting; counted lower bounds with native work unpriced, L0 wall exploratory, "
                 "L2 host run pending",
        "measured_runs": n4153["measured_runs"],
        "measured_verified_runs": n4153["measured_verified_runs"],
        "isolation_levels": n4153["isolation_levels"],
        "curves": [
            {"curve": names(c["curve"])["slug"], "log2_r": c["log2_r"],
             "primary_workload_id": c["primary_workload_id"],
             "arms": [{"arm": a["arm"], "measured": a["measured"], "verified": a["verified"],
                       "timeouts": a["timeouts"], "errors": a["errors"],
                       "usable_points": a.get("usable_points"), "folded_columns": a.get("folded_columns"),
                       "mean_cold_s_lower_bound": a["mean_cold_s_lower_bound"]} for a in c["arms"]],
             "k8_over_rho": quotient(c, "ic-k8_over_rho-strong"),
             "k16_over_rho": quotient(c, "ic-k16_over_rho-strong"),
             "k16_over_k8": quotient(c, "ic-k16_over_ic-k8"),
             "h1": c["h1_counted_ic_over_rho_above_one"],
             "h2_verdict": c["h2_target_only_counted_k16_over_k8"]["verdict"]}
            for c in n4153["curves"]],
        "online_speedup": None,
        "fully_priced_cold_speedup": None,
    }
    ladder, kob, kob1 = ladder_rows(names), koblitz_rows(names), koblitz_one_target_rows(names)
    board = ladder + kob1 + kob
    for r in board:
        r["family"] = FAMILY_OF[r["regime"]]
    measured = {r["slug"] for r in board}
    records, n_records = curve_records()
    for r in board:
        r["curve_record"] = curve_record(records, r["slug"])
        r["factor_base"] = {"points": r["best"]["base_points"], "recipe": r["best"]["label"],
                            "variant": r["best"].get("variant"), "source": r["source"],
                            "refs": r["curve_record"]["factor_base_refs"],
                            "link_status": r["curve_record"]["factor_base_link_status"]}
    leaders = {}
    for regime in ("prime", "char2", "koblitz", "koblitz_batch"):
        rows = [r for r in board if r["regime"] == regime]
        ranked = [r for r in rows if not r["best"].get("construction_artefact")] or rows
        best = min(ranked, key=lambda r: r["best"]["ratio_rho"])
        top = max(rows, key=lambda r: r["log2_r"])
        leaders[regime] = {"slug": best["slug"], "log2_r": best["log2_r"],
                           "ratio_rho": best["best"]["ratio_rho"], "s": best["best"]["s"],
                           "recipe": best["best"]["label"],
                           "one_target": best["best"].get("one_target_cold_ratio_section20"),
                           "online_speedup": best["best"].get("online_speedup"),
                           "largest": {"slug": top["slug"], "log2_r": top["log2_r"],
                                       "ratio_rho": top["best"]["ratio_rho"]}}
    return {
        "schema_version": 1,
        "generated_by": "scripts/build_ic_leaderboard.py",
        "unit": "none: the board has three families, each with its own unit, reference and floor "
                "(families[*].unit, .reference, .floor); S, ratio to reference and ratio to floor "
                "are comparable within a family and nowhere else",
        "what_this_is": "A view of frozen whole-pipeline ECDLP measurements, curve by curve, "
                        "each against its own family's matched reference and generic floor. "
                        "No new measurement.",
        "what_this_is_not": ["a measurement", "a speedup", "a claim about any curve not on it"],
        "class": "accounting",
        "sources": {k: {"path": v, "sha256": sha256(v)} for k, v in SOURCES.items()},
        "families": families(board),
        "leaders": leaders, "board": board, "oracles": oracle_rows(names),
        "bounded_diagnostics": [bounded_diagnostic],
        "n37_k8_k16_confirmation": k8_confirmation,
        "n37_online_ir_diagnostic": online_ir_diagnostic,
        "n37_native_wall_diagnostic": native_wall_diagnostic,
        "f6_small_cold_diagnostic": small_cold_diagnostic,
        "f6_ecbench_ladder_diagnostic": ladder_diagnostic,
        "f4_f5_f6_cross_family_diagnostic": cross_diagnostic,
        "latest_frontier_audit": frontier_audit,
        "n83_matched_process_diagnostic": matched_n83_diagnostic(),
        "curve_records": {
            "registry": SOURCES["registry"], "schema": SOURCES["curves_schema"], "yaml": SOURCES["curves_yaml"],
            "yaml_records": n_records,
            "board_curves": len(measured),
            "board_curves_in_yaml": sum(s in records for s in measured),
            "board_curves_factor_base_reconciled": sum(
                1 for s in measured if s in records and records[s]["factor_base_refs"]),
        },
        "exponents": exponents(), "roster": [
            {**c, "curves_yaml_key": (records.get(c["slug"]) or {}).get("key"),
             "factor_base_link_status": (records.get(c["slug"]) or {}).get(
                 "factor_base_link_status", "no_curves_yaml_record")}
            for c in roster(names, measured)],
        "n41_n53_counted_diagnostic": n41_n53_diagnostic,
        # Native analysis computes these observations; this view only copies
        # and renders them, outside the fully priced rankings.
        "conductor_gap_count_diagnostic": load(SOURCES["conductor_gap_counts"]),
        "phases": [{"id": i, "name": n, "what": w} for i, n, w in PHASES],
    }


# ---------------------------------------------------------------------------
# Rendering.
# ---------------------------------------------------------------------------


def g3(v: float | None) -> str:
    if v is None:
        return "—"
    if v == 0:
        return "0"
    if abs(v) >= 1000:
        return f"{v:,.0f}"
    return f"{v:.3g}"


def times(v: float) -> str:
    return f"{g3(v)}×"


def esc(s) -> str:
    return html.escape(str(s))


def gh(path: str, text: str | None = None) -> str:
    return f'<a href="{esc(GITHUB + path)}"><code>{esc(text or path)}</code></a>'


def record_cell(r: dict) -> str:
    """The curve's registry, curves.yaml and factor-base references under its slug."""
    cr, fb = r["curve_record"], r["factor_base"]
    yml = (gh(cr["curves_yaml"], f'curves.yaml#{cr["curves_yaml_key"]}') if cr["curves_yaml_key"]
           else f'{gh(cr["curves_yaml"], "curves.yaml")}: no record')
    refs = (", ".join(f"<code>{esc(x)}</code>" for x in fb["refs"]) if fb["refs"]
            else "none" if not cr["curves_yaml_key"] else f'none ({esc(fb["link_status"])})')
    # |F| and the recipe have their own columns; this names where the base was defined.
    return (f'<br><span class="muted">{gh(cr["registry"], "registry")} · {yml}</span>'
            f'<br><span class="muted" title="{fb["points"]:,} points, {esc(fb["variant"] or fb["recipe"])}">'
            f'factor base: {gh(fb["source"], fb["source"].rsplit("/", 1)[-1])} · refs {refs}</span>')


def rich(s) -> str:
    """Escaped text with `code` spans, for the family definitions shared with the Markdown."""
    return re.sub(r"`([^`]+)`", r"<code>\1</code>", esc(s))


def markdown(doc: dict) -> str:
    fams = doc["families"]
    L = ["# Index-calculus leaderboard", "",
         "Generated by `scripts/build_ic_leaderboard.py` from frozen evidence; the page is "
         "[`docs/ic-leaderboard.html`](../ic-leaderboard.html).  Curves are named by ICV1 slug "
         "([`docs/curves/ICV1.md`](../curves/ICV1.md)).  No row is below its reference.", "",
         "**There is no single unit on this page.**  The board is three tables, A, B and C.  Each is "
         "priced in its own unit, against its own reference and floor, stated at its head.  `S`, "
         "`× reference` and `× floor` are comparable within a table and nowhere else.  The same slug "
         "can appear in two tables with different `S`, because the unit, the reference and the number "
         "of targets differ.", ""]
    matched = doc["n83_matched_process_diagnostic"]
    L += ["## Matched legacy degree-83 local process diagnostic (measured 2026-10-14)", "",
          f"`{matched['curve']}`; accounting only, outside tables A–C. "
          "Ratios are native IC/rho costs; below 1 favors IC. No S, floor or admitted-best promotion.", "",
          "| Workload | Mean IC seconds | Mean rho seconds | Native IC/rho [95%] |",
          "|:--|--:|--:|:--|"]
    for label, key in (("8 actual cold singleton pairs", "cold"),
                       ("3 actual shared-setup pairs, 32 targets each", "batch"),
                       ("32 target online means, 3 repeats; secondary", "online")):
        row = matched[key]
        L.append(f"| {label} | {row['arithmetic_mean_ic_s']:.6f} | "
                 f"{row['arithmetic_mean_rho_s']:.6f} | {row['ic_over_rho']:.6f} "
                 f"[{row['interval_95'][0]:.6f}, {row['interval_95'][1]:.6f}] |")
    L += ["", "32 processes, 218 replayed scalar answers, 104 IC witnesses and five exact-work A/A pairs; "
          "no failed or omitted cases. " + matched["limits"], "",
          f"[Native statistics](../../{matched['source']}); "
          f"[independent replay](../../{matched['replay_source']}); "
          f"[native phases and resource records](../../{matched['presentation_source']}).", ""]
    audit = doc["latest_frontier_audit"]
    cold = audit["cold"]
    admitted = audit["admitted_online"]
    exploratory = audit["exploratory_online"]
    replay = audit["replay_block"]
    L += [f"## Latest frontier audit ({audit['date']})", "",
          "This accounting synthesis is published on every performance handoff. It does not replace the "
          "curve-by-curve tables: the frozen source records that no ranked row changed.", "",
          "| boundary | observed result | leaderboard treatment |",
          "|:--|:--|:--|",
          f"| Canonical medium-tier Koblitz cold operations | `{cold['method']}` / "
          f"`{cold['bound_id']}`: {cold['ops_over_floor']:.3f}× floor "
          f"[{cold['ops_ci95'][0]:.3f}, {cold['ops_ci95'][1]:.3f}], "
          f"{cold['runs']} runs at {cold['sizes']} sizes | Standing rho boundary; not an IC row |",
          f"| Retained-setup online, `{admitted['label']}` | rho/IC "
          f"{admitted['rho_over_ic']:.1f}× [{admitted['ci95'][0]:.1f}, "
          f"{admitted['ci95'][1]:.1f}], {admitted['targets']} unseen targets; about "
          f"{admitted['setup_seconds_approx']:.0f} s setup excluded | Admitted online result; "
          "kept separate from cold ranked rows |",
          f"| Retained-setup online, `{exploratory['label']}` | rho/IC "
          f"{exploratory['rho_over_ic']:.6f}× on {exploratory['targets']} public point; complete IC "
          f"process {exploratory['complete_process_seconds']:.3f} s | Exploratory shared-host result; "
          "no matched cold ratio and no rank promotion |",
          f"| Current-binary root-finder replay-all | {replay['identical']}/{replay['total']} identical; "
          f"{replay['failures']} inherited-F4 counter mismatches | Failed replay retained; affected "
          "stage counters blocked from promotion |", "",
          f"[Frozen synthesis data](../../{audit['source']}). {audit['reason']}", ""]
    for code in ("A", "B", "C"):
        f = fams[code]
        rows = [r for r in doc["board"] if r["family"] == code]
        multi = len(f["regimes"]) > 1
        L += [f"## Table {code}: {f['title']} ({f['section']})", "",
              f"- **Unit:** {f['unit']}.  {f['unit_how']}",
              f"- **Reference:** {f['reference']}",
              f"- **Floor:** {f['floor']}",
              f"- **Targets:** {f['targets']}",
              f"- **Status:** {f['status']}"]
        steps = step_line(f)
        if steps:
            L.append(f"- **Rho step:** {steps}")
        head = (["regime"] if multi else []) + ["curve", "log₂ r", "recipe", "S, IC", "S, reference",
                                                "× reference", "S, floor", "× floor", "ok"]
        align = (([":--"] if multi else []) + [":--", "--:", ":--", "--:", "--:", "--:", "--:", "--:", ":--"])
        L += ["", "| " + " | ".join(head) + " |", "|" + "|".join(align) + "|"]
        for r in rows:
            b = r["best"]
            cells = ([REGIME_NAME[r["regime"]]] if multi else []) + [
                f"`{r['slug']}`", f"{r['log2_r']:.1f}", b["label"], g3(b["s"]), g3(r["reference_s"]),
                f"**{times(b['ratio_rho'])}**" + (f" (was {times(b['ratio_rho_section23'])}, §23)"
                                                   if "ratio_rho_section23" in b else ""),
                g3(r["floor_s"]), times(b["ratio_floor"]),
                "✓" if b["verified"] else "✗"]
            L.append("| " + " | ".join(cells) + " |")
        L.append("")
    L += ["## Phases, as a share of S", "",
          "Shares are fractions of each row's own `S`, so they carry no unit; read each row in the "
          "table named in its first column.", "",
          "| table | curve | " + " | ".join(n for _, n, _ in PHASES) + " |",
          "|:--|:--|" + "--:|" * len(PHASES)]
    for code in ("A", "B", "C"):
        for r in (r for r in doc["board"] if r["family"] == code):
            ph, s = r["best"]["phases_s"], r["best"]["s"]
            L.append(f"| {code} | `{r['slug']}` | " + " | ".join(
                (f"{100 * ph[i] / s:.1f}%" if i in ph else "—") for i, _, _ in PHASES) + " |")
    cr = doc["curve_records"]
    L += ["", "## Curve records and factor bases", "",
          f"Identity: [`{cr['registry']}`](../../{cr['registry']}). IC curve records: schema "
          f"[`{cr['schema']}`](../../{cr['schema']}), records [`{cr['yaml']}`](../../{cr['yaml']}) "
          f"({cr['yaml_records']} records). {cr['board_curves_in_yaml']} of the {cr['board_curves']} board curves "
          f"have a record there; {cr['board_curves_factor_base_reconciled']} have a reconciled factor base.", "",
          "| table | curve | curves.yaml record | factor base (points, recipe) | factor-base source | refs |",
          "|:--|:--|:--|:--|:--|:--|"]
    for code in ("A", "B", "C"):
        for r in (r for r in doc["board"] if r["family"] == code):
            fb, key = r["factor_base"], r["curve_record"]["curves_yaml_key"]
            L.append(f"| {code} | `{r['slug']}` | {('`' + key + '`') if key else 'none'} | "
                     f"{fb['points']:,}, {fb['variant'] or fb['recipe']} | `{fb['source']}` | "
                     + (", ".join(f"`{x}`" for x in fb["refs"]) or f"none ({fb['link_status']})") + " |")
    d = doc["bounded_diagnostics"][0]
    L += ["", "## Bounded n37 diagnostic outside tables A–C", "",
          f"The separately calibrated `{d['curve']}` shared-rank K16 candidate "
          f"(`{d['candidate_id']}`) has {d['usable_points']:,} usable points and "
          f"{d['folded_columns']} folded columns. Across {d['measured_runs']} verified "
          f"one-target runs, its mean cold counted `S` lower bound is "
          f"{d['mean_cold_s_lower_bound']:.3f}; its counted IC/rho quotient is "
          f"{d['cold_counted_over_rho_diagnostic']:.3f} and K16/K42 is "
          f"{d['cold_counted_over_k42_diagnostic']:.3f}. Native work is unpriced "
          "for both arms, and L0 timing cannot establish an online speedup. "
          "This row is intentionally outside the three fully priced unit families; "
          f"read the [frozen decision](../../{d['source']}).", ""]
    c = doc["n37_k8_k16_confirmation"]
    L += [f"The untouched {c['workloads']}-target K8/K16 confirmation selected "
          f"`{c['candidate_id']}` for the cold implementation route: K16/K8 "
          f"whole-solve Callgrind Ir is {c['k16_over_k8_ir']:.3f} "
          f"[{c['k16_over_k8_ir_ci95'][0]:.3f}, {c['k16_over_k8_ir_ci95'][1]:.3f}], "
          f"and K8/rho is {c['k8_over_rho_ir']:.3f} "
          f"[{c['k8_over_rho_ir_ci95'][0]:.3f}, {c['k8_over_rho_ir_ci95'][1]:.3f}]. "
          "All 64 profiles and 320 independent measured replays verified. "
          "The unit is simulated whole-solve instructions, not isolated online "
          "wall time; K16 remains a target-only candidate. "
          f"Read the [raw instruction decision](../../{c['source']}).", ""]
    q = doc["n37_online_ir_diagnostic"]
    L += [f"The fresh {q['workloads']}-target panel reverses the base choice inside "
          "the **target-only simulated-instruction** interval: "
          f"`{q['k16_candidate_id']}` is prioritized for an isolated n37 online "
          f"wall test because K8/K16 target-only Callgrind Ir is "
          f"{q['k8_over_k16_online_ir']:.3f} "
          f"[{q['k8_over_k16_online_ir_ci95'][0]:.3f}, "
          f"{q['k8_over_k16_online_ir_ci95'][1]:.3f}]. "
          f"K16/rho is {q['k16_over_rho_online_ir']:.3f} "
          f"[{q['k16_over_rho_online_ir_ci95'][0]:.3f}, "
          f"{q['k16_over_rho_online_ir_ci95'][1]:.3f}] in the same instruction "
          f"unit, while K8/K16 complete-solve Ir is {q['k8_over_k16_cold_ir']:.3f}. "
          "All 64 profile scalars and 320 independent measured replays verified. "
          "Mac L0 timing leaves the primary online wall speedup unknown; both "
          "bases remain live at n41/n53. "
          f"Read the [raw target-only decision](../../{q['source']}).", ""]
    w = doc["n37_native_wall_diagnostic"]
    L += [f"The next native hosted n37 screen independently replayed "
          f"{w['measured_verified_runs']}/{w['measured_verified_runs']} measured executions. "
          f"For preregistered one-target workload `{w['primary_workload_id']}`, "
          f"descriptive rho/K16 online wall is {w['primary_rho_over_k16_online_wall']:.3f}. "
          f"The separate 16-target panel has K8/K16 online wall "
          f"{w['panel_k8_over_k16_online_wall']:.3f} "
          f"[{w['panel_k8_over_k16_online_wall_ci95'][0]:.3f}, "
          f"{w['panel_k8_over_k16_online_wall_ci95'][1]:.3f}]. "
          f"All measured rows earned L1 and the identical K16 A/A maximum "
          f"deviation was {100*w['aa_max_relative_deviation']:.2f}%, above "
          "the frozen 5% gate. The admitted online speedup remains unknown; "
          "both K8 and K16 carry to the L2 host gate and n41/n53. "
          f"Read the [sealed native decision](../../{w['source']}).", ""]
    z = doc["f6_small_cold_diagnostic"]
    f4, f6, f5 = (z["arms"][arm] for arm in ("inherited_f4", "f6_ic", "f5"))
    L += ["## Complete n9 F6-IC control outside tables A–C", "",
          f"The preregistered one-target workload `{z['workload_id']}` on "
          f"`{z['curve']}` recovered the logarithm of public point "
          f"`{z['target']}` with inherited F4, F6-IC and matrix F5. "
          f"Each cold run built {z['usable_points']} usable base points, "
          f"collected {z['verified_relations']} verified ordinary relations, "
          f"solved {z['folded_columns']} folded columns and independently replayed "
          "the scalar, relations, column logs and phase totals. "
          f"Inside-worker cold times were {f4['cold_inside_worker_ns']/1e6:.3f}, "
          f"{f6['cold_inside_worker_ns']/1e6:.3f} and "
          f"{f5['cold_inside_worker_ns']/1e6:.3f} ms respectively; one-target "
          f"online times were {f4['online_wall_ns']/1e6:.3f}, "
          f"{f6['online_wall_ns']/1e6:.3f} and "
          f"{f5['online_wall_ns']/1e6:.3f} ms. These are exploratory L0 Mac "
          "wall observations on a tiny subgroup. No same-target rho reference "
          "or fully priced operation count exists, so IC/rho speedup and `S` "
          "are unknown; this control cannot enter tables A–C. "
          f"Read the [keyed measurements](../../{z['source']}) and "
          f"[independent replay](../../{z['replay']}).", ""]
    L += ["| solver | candidate | cold ms | online ms |",
          "|:--|:--|--:|--:|"]
    for arm, label in (("inherited_f4", "Inherited F4"), ("f6_ic", "F6-IC"), ("f5", "Matrix F5")):
        row = z["arms"][arm]
        L.append(f"| {label} | `{row['candidate_id']}` | "
                 f"{row['cold_inside_worker_ns']/1e6:.3f} | "
                 f"{row['online_wall_ns']/1e6:.3f} |")
    L.append("")
    y = doc["f6_ecbench_ladder_diagnostic"]
    L += ["## F6-IC E_0 ladder in ecbench, outside tables A–C", "",
          "#1333's inherited-F4 and F6-IC decomposers ran unmodified in `ic.pipeline` "
          "beside same-target strong rho on eight public one-target workloads per size. "
          "IC `S` is a lower bound: the solver's word XORs are counted but unpriced, and "
          "F6-IC's geometric point additions are charged. The F6-IC word-XOR saving "
          "vanishes once the base exceeds #1333's 256-point closure cap; charging its "
          "geometry makes the trade a relabelling. "
          f"Decision: {y['decision']} (m = 31 incomplete). "
          f"Read the [analysis](../../{y['source']}).", "",
          "| m | curve | targets | rho S | F4 S/rho (lower bound) | F6-IC S/rho (lower bound) | median log2(W4/W6) |",
          "|--:|:--|--:|--:|--:|--:|--:|"]
    for z in y["sizes"]:
        L.append(f"| {z['m']} | `{z['curve']}` | {z['targets']} | {z['rho_s']:.3f} | "
                 f"{z['f4_s_lower_over_rho']:.3f} | {z['f6_s_lower_over_rho']:.3f} | "
                 f"{z['median_log2_w4_over_w6']:.3f} |")
    L.append("")
    y = doc["f4_f5_f6_cross_family_diagnostic"]

    def f3(v):
        return "—" if v is None else f"{v:.3f}"
    L += ["## F4, F5 and F6-IC on Koblitz and generic binary curves, outside tables A–C", "",
          "Matrix F4, matrix F5, inherited F4 and F6-IC through `pdp3-binary` on eight public "
          "one-target workloads per cell, beside same-target rho. IC `S` is a lower bound "
          "(solver word XORs unpriced; F6-IC's geometric additions charged). `W` is counted "
          "solver word XORs. Prime curves have no algebraic oracle in `ecbench`. "
          f"Read the [analysis](../../{y['source']}).", "",
          "| family | m | curve | base points | rho-negation S | strong rho S | inherited F4 S | F6-IC S "
          "| W F5/F4 | W F4 matrix/inherited | median log2(W inh/W F6) |",
          "|:--|--:|:--|--:|--:|--:|--:|--:|--:|--:|--:|"]
    for z in y["rows"]:
        L.append(f"| {z['family']} | {z['m']} | `{z['curve']}` | {z['base_points']} | "
                 f"{f3(z['rho_negation_s'])} | {f3(z['rho_strong_s'])} | {f3(z['inherited_s'])} | "
                 f"{f3(z['f6_s'])} | {f3(z['f5_over_f4_w'])} | {f3(z['matrix_f4_over_inherited_w'])} | "
                 f"{f3(z['log2_inherited_over_f6_w'])} |")
    L.append("")
    v = doc["n41_n53_counted_diagnostic"]

    def qmd(q: dict) -> str:
        if q["ratio_of_sums"] is None:
            return f"unknown ({q['pairs']} verified pairs)"
        ci = q["ci95"]
        return (f"{q['ratio_of_sums']:.3f} [{ci[0]:.3f}, {ci[1]:.3f}]" if ci
                else f"{q['ratio_of_sums']:.3f} (no interval)")
    L += ["## n41/n53 shared-rank counted panel, outside tables A–C", "",
          "The four n37 arms (strong signed-Frobenius rho, K8, K16 and an identical K16 control, "
          "method parameters unchanged) ran on 16 new public one-target workloads on each of the next "
          "two registered sizes, five paired rounds each, on macOS at L0. Counted cold IC/rho is a "
          "quotient of two lower bounds (native work unpriced); a cell whose arm never verifies under "
          "the frozen parameters is unknown, not a cost. "
          f"{v['measured_verified_runs']} of {v['measured_runs']} measured runs verified; "
          f"decision `{v['decision']}`; the L2 host run is pending. "
          f"Read the [frozen decision](../../{v['source']}).", "",
          "| curve | log2 r | arm | verified / measured | usable points | columns | mean cold S (lower bound) | counted IC/rho [95%] |",
          "|:--|--:|:--|--:|--:|--:|--:|:--|"]
    for c in v["curves"]:
        for a in c["arms"]:
            q = {"ic-k8": c["k8_over_rho"], "ic-k16": c["k16_over_rho"]}.get(a["arm"])
            s_txt = f"{a['mean_cold_s_lower_bound']:.3f}" if a["mean_cold_s_lower_bound"] is not None else "—"
            L.append(f"| `{c['curve']}` | {c['log2_r']:.2f} | {a['arm']} | {a['verified']}/{a['measured']} | "
                     f"{a['usable_points'] if a['usable_points'] is not None else '—'} | "
                     f"{a['folded_columns'] if a['folded_columns'] is not None else '—'} | {s_txt} | "
                     f"{qmd(q) if q else ('reference' if a['arm'] == 'rho-strong' else 'A/A control')} |")
        L.append(f"| `{c['curve']}` | {c['log2_r']:.2f} | K16 / K8 | — | — | — | — | {qmd(c['k16_over_k8'])} |")
    L.append("")
    L += ["## Large-prime conductor-gap counted diagnostics", "",
          "Copied from native analysis: eight independent one-target workloads per fixed curve; "
          "no transported targets. Counted S has unpriced native work. These observations do "
          "not enter tables A–C or change a full-cost ranking.", "",
          "| ell | IC floor/crater | 99% interval |", "|---:|---:|---|"]
    for session in doc["conductor_gap_count_diagnostic"]["sessions"]:
        observed = session["arms"]["ic-mitm"]["cross_curve"]
        L.append(f"| {session['ell']} | {observed['ratio_floor_over_crater']:.6f} | "
                 f"{observed['ci99'][0]:.6f} to {observed['ci99'][1]:.6f} |")
    L += ["", "## Sources", ""]
    for k, v in doc["sources"].items():
        L.append(f"- `{v['path']}` — sha256 `{v['sha256'][:16]}…`")
    return "\n".join(L) + "\n"


STYLE = """
/* Layout: one reading column; the board and the step table are the page, everything else hangs off them. */
:root {
  --ground: #e7ebef; --surface: #fbfcfd; --sunk: #f0f3f6; --ink: #0e1922; --ink-2: #354855;
  --muted: #576976; --rule: #ccd5dc; --data: #1f6fd0; --data-soft: #d7e4f6; --bound: #b3372a;
  --bound-soft: #f3dcd8;
  --ph-precomputation: #b9c3cb; --ph-setup: #9aa7b1; --ph-constructions: #c4a35a; --ph-factor_base: #2f8f83; --ph-table: #6fb7a8;
  --ph-relations: #1f6fd0; --ph-linear_algebra: #8b5bc4; --ph-descent: #d0782f; --ph-verify: #4d5b66;
  --serif: "Newsreader", "Iowan Old Style", Georgia, serif;
  --sans: "IBM Plex Sans", system-ui, -apple-system, "Segoe UI", sans-serif;
  --mono: "IBM Plex Mono", ui-monospace, "SF Mono", Menlo, monospace;
}
@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) {
  --ground: #0d1318; --surface: #151d24; --sunk: #101820; --ink: #e3eaef; --ink-2: #b6c5cf;
  --muted: #8799a6; --rule: #25323a; --data: #4e92de; --data-soft: #1c2e42; --bound: #d9604e;
  --bound-soft: #38221f;
  --ph-precomputation: #3d4a54; --ph-setup: #6c7a85; --ph-constructions: #b8954a; --ph-factor_base: #3aa698; --ph-table: #7cc4b5;
  --ph-relations: #4e92de; --ph-linear_algebra: #a57ad8; --ph-descent: #e08c45; --ph-verify: #93a3ae;
  color-scheme: dark; } }
:root[data-theme="dark"] {
  --ground: #0d1318; --surface: #151d24; --sunk: #101820; --ink: #e3eaef; --ink-2: #b6c5cf;
  --muted: #8799a6; --rule: #25323a; --data: #4e92de; --data-soft: #1c2e42; --bound: #d9604e;
  --bound-soft: #38221f;
  --ph-precomputation: #3d4a54; --ph-setup: #6c7a85; --ph-constructions: #b8954a; --ph-factor_base: #3aa698; --ph-table: #7cc4b5;
  --ph-relations: #4e92de; --ph-linear_algebra: #a57ad8; --ph-descent: #e08c45; --ph-verify: #93a3ae;
  color-scheme: dark; }
* { box-sizing: border-box; }
body { margin: 0; padding-inline: 16px; padding-block: 36px 64px; background: var(--ground); color: var(--ink);
  font-family: var(--sans); font-size: 15px; line-height: 1.55; }
.wrap { max-width: 1080px; margin: 0 auto; display: flex; flex-direction: column; gap: 28px; }
header { display: flex; flex-direction: column; gap: 12px; }
.eyebrow { font-family: var(--mono); font-size: 11px; letter-spacing: .13em; text-transform: uppercase; color: var(--muted); }
h1 { font-family: var(--serif); font-weight: 500; font-size: clamp(30px, 5.2vw, 44px); line-height: 1.08; margin: 0; text-wrap: balance; }
h2 { font-family: var(--serif); font-weight: 500; font-size: 22px; margin: 0; text-wrap: balance; }
.verdict { font-family: var(--serif); font-size: clamp(17px, 2.2vw, 20px); line-height: 1.45; color: var(--ink-2); max-width: 64ch; margin: 0; }
.facts { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1px; background: var(--rule);
  border: 1px solid var(--rule); border-radius: 3px; overflow: hidden; }
.fact { background: var(--surface); padding: 14px 16px; display: flex; flex-direction: column; gap: 3px; min-width: 0; }
.fact dt { font-family: var(--mono); font-size: 10.5px; letter-spacing: .1em; text-transform: uppercase; color: var(--muted); }
.fact dd { margin: 0; font-family: var(--mono); font-size: 20px; font-weight: 500; font-variant-numeric: tabular-nums; }
.fact p { margin: 0; font-size: 12.5px; color: var(--muted); line-height: 1.4; overflow-wrap: anywhere; }
.panel { background: var(--surface); border: 1px solid var(--rule); border-radius: 4px; display: flex; flex-direction: column; gap: 12px; padding-block: 18px; }
.panel > * { padding-inline: 20px; }
.panel p { margin: 0; max-width: 72ch; color: var(--ink-2); font-size: 14px; }
.scroll { overflow-x: auto; padding-inline: 0; }
table { border-collapse: collapse; width: 100%; font-size: 13px; font-variant-numeric: tabular-nums; }
th, td { padding: 7px 10px; text-align: left; border-bottom: 1px solid var(--rule); vertical-align: top; }
th { font-family: var(--mono); font-size: 10.5px; font-weight: 500; letter-spacing: .06em; text-transform: uppercase; color: var(--muted); white-space: nowrap; }
td.n, th.n { text-align: right; white-space: nowrap; }
td.recipe { min-width: 210px; }
tr.lead td { background: var(--data-soft); }
code, .slug { font-family: var(--mono); font-size: 12px; }
.slug { white-space: nowrap; }
.chip { display: inline-block; font-family: var(--mono); font-size: 10px; letter-spacing: .08em; text-transform: uppercase;
  padding: 1px 6px; border: 1px solid var(--rule); border-radius: 2px; color: var(--ink-2); white-space: nowrap; }
.ratio { font-family: var(--mono); font-weight: 600; color: var(--bound); }
.bar { display: flex; height: 12px; min-width: 160px; border-radius: 2px; overflow: hidden; background: var(--sunk); }
.bar span { display: block; height: 100%; }
.legend { display: flex; flex-wrap: wrap; gap: 6px 16px; font-size: 12px; color: var(--ink-2); }
.legend i { display: inline-block; width: 10px; height: 10px; border-radius: 2px; margin-right: 6px; vertical-align: -1px; }
.muted { color: var(--muted); }
.defs { margin-block: 0; display: flex; flex-direction: column; gap: 6px; }
.defs div { display: grid; grid-template-columns: 84px 1fr; gap: 12px; }
.defs dt { font-family: var(--mono); font-size: 10.5px; letter-spacing: .08em; text-transform: uppercase; color: var(--muted); padding-top: 2px; }
.defs dd { margin: 0; font-size: 13px; color: var(--ink-2); max-width: 90ch; }
@media (max-width: 560px) { .defs div { grid-template-columns: 1fr; gap: 1px; } }
svg text { fill: var(--ink-2); font-family: var(--mono); font-size: 10px; }
svg .axis { stroke: var(--rule); }
svg .rho { stroke: var(--bound); stroke-width: 1.5; }
details summary { cursor: pointer; font-family: var(--mono); font-size: 12px; color: var(--data); }
details summary:focus-visible, a:focus-visible { outline: 2px solid var(--data); outline-offset: 2px; }
a { color: var(--data); }
footer { font-size: 12.5px; color: var(--muted); display: flex; flex-direction: column; gap: 6px; }
.site-nav { display: flex; flex-wrap: wrap; gap: 4px 18px; padding-block: 2px 10px; border-bottom: 1px solid var(--rule);
  font-family: var(--mono); font-size: 12px; letter-spacing: .02em; }
.site-nav a { color: var(--ink-2); text-decoration: none; padding-block: 4px; }
.site-nav a:hover { color: var(--data); }
.site-nav a[aria-current="page"] { color: var(--ink); border-bottom: 2px solid var(--data); }
footer p { margin: 0; max-width: 90ch; }
"""


def phase_bar(ph: dict, s: float) -> str:
    segs = []
    for pid, name, _ in PHASES:
        v = ph.get(pid)
        if not v:
            continue
        pct = 100 * v / s
        segs.append(f'<span style="width:{pct:.2f}%;background:var(--ph-{pid})" '
                    f'title="{esc(name)}: {pct:.1f}%"></span>')
    return f'<div class="bar" role="img" aria-label="phase shares">{"".join(segs)}</div>'


def ratio_chart(board: list[dict]) -> str:
    """Each curve's best recipe on a log axis of ratio to its reference."""
    W, H, left, right = 980, 60 + 26 * 3, 150, 20
    lo, hi = 0.0, 3.0   # log10 of 1x .. 1000x
    x = lambda r: left + (math.log10(r) - lo) / (hi - lo) * (W - left - right)  # noqa: E731
    out = [f'<svg viewBox="0 0 {W} {H}" width="100%" role="img" '
           f'aria-label="Ratio to reference per curve, log scale" style="min-width:640px">']
    for t in (1, 3, 10, 30, 100, 300, 1000):
        out.append(f'<line class="axis" x1="{x(t):.1f}" y1="18" x2="{x(t):.1f}" y2="{H - 18}"/>'
                   f'<text x="{x(t):.1f}" y="{H - 4}" text-anchor="middle">{t}×</text>')
    out.append(f'<line class="rho" x1="{x(1):.1f}" y1="14" x2="{x(1):.1f}" y2="{H - 18}"/>'
               f'<text x="{x(1) + 4:.1f}" y="12">reference = 1×</text>')
    for i, regime in enumerate(("koblitz", "prime", "char2")):
        y = 36 + i * 26
        out.append(f'<text x="0" y="{y + 4}">{esc(REGIME_NAME[regime])} ({FAMILY_OF[regime]})</text>')
        for r in (r for r in board if r["regime"] == regime):
            v = r["best"]["ratio_rho"]
            out.append(f'<circle cx="{x(v):.1f}" cy="{y}" r="5" fill="var(--data)" fill-opacity=".55" '
                       f'stroke="var(--data)"><title>{esc(r["slug"])}: {times(v)} at 2^{r["log2_r"]:.1f}</title></circle>')
    out.append("</svg>")
    return "".join(out)


def page(doc: dict, standalone: bool) -> str:
    board = doc["board"]
    L = doc["leaders"]
    by_regime = {g: sorted((r for r in board if r["regime"] == g), key=lambda r: r["best"]["ratio_rho"])
                 for g in ("koblitz", "prime", "char2", "koblitz_batch")}
    head = ('<title>Index Calculus Leaderboard</title>\n'
            '<link rel="preconnect" href="https://fonts.googleapis.com">\n'
            '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
            '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Newsreader:opsz,wght@6..72,400;6..72,500'
            '&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500;600&display=swap">\n'
            f"<style>{STYLE}</style>\n")
    P = []
    K1 = L["koblitz"]
    kob_rows = by_regime["koblitz"]
    online_lo = min(r["best"]["online_speedup"] for r in kob_rows)
    online_hi = max(r["best"]["online_speedup"] for r in kob_rows)
    cold = [r["best"]["ratio_rho"] for r in kob_rows if not r["best"]["construction_artefact"]]
    model = [r["best"]["ic_online_over_precomputation_model"] for r in kob_rows]
    site = "https://aburan28.github.io/crypto/"
    nav = [("Overview", site), ("Scoreboard", site + "scoreboard/"),
           ("Leaderboard", None), ("Where things stand", site + "scoreboard/ic-current-state.html"),
           ("Algorithm lab", site + "scoreboard/algorithm-lab.html"), ("Campaign status", site + "status/"),
           ("Repository", "https://github.com/aburan28/crypto")]
    P.append('<div class="wrap"><nav class="site-nav" aria-label="Site">' + "".join(
        f'<a href="#board" aria-current="page">{esc(t)}</a>' if u is None else f'<a href="{esc(u)}">{esc(t)}</a>'
        for t, u in nav) + '</nav>')
    P.append('<header>'
             '<span class="eyebrow">ECDLP · index calculus · whole pipeline · accounting view, no new measurement</span>'
             '<h1>Index Calculus Leaderboard</h1>'
             '<p class="verdict">Every curve this repository has priced end to end, with the best index-calculus '
             'recipe measured on it, against Pollard rho on the same curve and the same point. <strong>The units '
             'differ between the three tables below, and so do the references and the floors: S and the ratios '
             'are comparable inside a table and nowhere else.</strong> <strong>Cold, set-up included, no row is '
             'below its reference.</strong> On one unseen point of a Koblitz curve (table A) '
             f'the index calculus\'s online interval is {g3(online_lo)}–{g3(online_hi)}× faster than rho once '
             'its reusable set-up exists, but the set-up is paid first: cold it is '
             f'{g3(min(cold))}–{g3(max(cold))}× slower, and a generic walk given the same precomputation would be '
             f'{g3(min(model))}–{g3(max(model))}× faster online again (a model). Prime and random-binary curves (table B), '
             f'one target each: {times(L["prime"]["ratio_rho"])} to {times(L["prime"]["largest"]["ratio_rho"])} and '
             f'{times(L["char2"]["ratio_rho"])} to {times(L["char2"]["largest"]["ratio_rho"])}.</p>'
             '<dl class="facts">')
    def unit_ref(code: str) -> str:
        f = doc["families"][code]
        return f'<br>× {esc(f["ref_short"])}, in {esc(f["unit_short"])} (table {code})'

    P.append(f'<div class="fact"><dt>Koblitz · one point, cold</dt><dd>{times(K1["ratio_rho"])}</dd>'
             f'<p>at log₂ r = {K1["log2_r"]:.1f}, <span class="slug">{esc(K1["slug"])}</span>; online alone '
             f'{times(K1["online_speedup"])} faster than rho; largest size {times(K1["largest"]["ratio_rho"])} cold'
             f'{unit_ref("A")}</p></div>')
    for g in ("prime", "char2"):
        ld = L[g]
        big = ld["largest"]
        P.append(f'<div class="fact"><dt>Closest · {esc(REGIME_NAME[g])}</dt><dd>{times(ld["ratio_rho"])}</dd>'
                 f'<p>at log₂ r = {ld["log2_r"]:.1f}, <span class="slug">{esc(ld["slug"])}</span>; '
                 f'at the largest size, log₂ r = {big["log2_r"]:.1f}: {times(big["ratio_rho"])}'
                 f'{unit_ref("B")}</p></div>')
    P.append(f'<div class="fact"><dt>Curves</dt><dd>{len({r["slug"] for r in board})} priced</dd>'
             f'<p>of {len(doc["roster"])} named in the repository; every one by its ICV1 slug</p></div></dl></header>')
    matched = doc["n83_matched_process_diagnostic"]
    P.append('<section class="panel" id="n83-matched-process-diagnostic">'
             '<h2>Matched legacy degree-83 local process diagnostic · measured 2026-10-14 '
             '<span class="chip">accounting</span></h2>'
             f'<p><code>{esc(matched["curve"])}</code>. Native IC/rho costs; below 1 favors IC. '
             'Outside the ranked tables: S, floor and admitted-best fields remain unset.</p>'
             '<div class="scroll"><table><thead><tr><th>Workload</th><th>Mean IC seconds</th>'
             '<th>Mean rho seconds</th><th>Native IC/rho [95%]</th></tr></thead><tbody>')
    for label, key in (("8 actual cold singleton pairs", "cold"),
                       ("3 actual shared-setup pairs, 32 targets each", "batch"),
                       ("32 target online means, 3 repeats; secondary", "online")):
        row = matched[key]
        P.append(f'<tr><td>{esc(label)}</td><td>{row["arithmetic_mean_ic_s"]:.6f}</td>'
                 f'<td>{row["arithmetic_mean_rho_s"]:.6f}</td><td>{row["ic_over_rho"]:.6f} '
                 f'[{row["interval_95"][0]:.6f}, {row["interval_95"][1]:.6f}]</td></tr>')
    P.append('</tbody></table></div><p>32 processes, 218 independently replayed scalar answers, '
             '104 IC witnesses and five exact-work A/A pairs; no failed or omitted cases.</p>'
             f'<p>{esc(matched["limits"])} {gh(matched["source"], "Native statistics")} · '
             f'{gh(matched["replay_source"], "Independent replay")} · '
             f'{gh(matched["presentation_source"], "Native phases and resource records")}.</p></section>')
    audit = doc["latest_frontier_audit"]
    acold = audit["cold"]
    admitted = audit["admitted_online"]
    exploratory = audit["exploratory_online"]
    replay = audit["replay_block"]
    P.append(f'<section class="panel" id="frontier-audit"><h2>Latest frontier audit · '
             f'{esc(audit["date"])} <span class="chip">accounting</span></h2>'
             '<p>This synthesis is carried on the leaderboard even though it changes no ranked curve row. '
             'Cold, retained-setup online, exploratory and failed-replay evidence remain separate.</p>'
             '<div class="scroll"><table><thead><tr><th>Boundary</th><th>Observed result</th>'
             '<th>Leaderboard treatment</th></tr></thead><tbody>'
             '<tr><td>Canonical medium-tier Koblitz cold operations</td>'
             f'<td><code>{esc(acold["method"])}</code> / <code>{esc(acold["bound_id"])}</code>: '
             f'{acold["ops_over_floor"]:.3f}× floor [{acold["ops_ci95"][0]:.3f}, '
             f'{acold["ops_ci95"][1]:.3f}], {acold["runs"]} runs at {acold["sizes"]} sizes</td>'
             '<td>Standing rho boundary; not an IC row</td></tr>'
             f'<tr><td>Retained-setup online · <code>{esc(admitted["label"])}</code></td>'
             f'<td>rho/IC {admitted["rho_over_ic"]:.1f}× [{admitted["ci95"][0]:.1f}, '
             f'{admitted["ci95"][1]:.1f}], {admitted["targets"]} unseen targets; about '
             f'{admitted["setup_seconds_approx"]:.0f} s setup excluded</td>'
             '<td>Admitted online result; separate from cold ranked rows</td></tr>'
             f'<tr><td>Retained-setup online · <code>{esc(exploratory["label"])}</code></td>'
             f'<td>rho/IC {exploratory["rho_over_ic"]:.6f}× on {exploratory["targets"]} public point; '
             f'complete IC process {exploratory["complete_process_seconds"]:.3f} s</td>'
             '<td>Exploratory shared-host result; no matched cold ratio and no rank promotion</td></tr>'
             f'<tr><td>Current-binary root-finder replay-all</td><td>{replay["identical"]}/'
             f'{replay["total"]} identical; {replay["failures"]} inherited-F4 counter mismatches</td>'
             '<td>Failed replay retained; affected stage counters blocked from promotion</td></tr>'
             '</tbody></table></div>'
             f'<p>{esc(audit["reason"])} {gh(audit["source"], "Frozen synthesis data")}.</p></section>')
    d = doc["bounded_diagnostics"][0]
    P.append(f'<section class="card" id="bounded-n37-diagnostic"><h2>New n37 counted diagnostic, outside the priced tables</h2>'
             f'<p>On <code>{esc(d["curve"])}</code>, shared-rank K16 has {d["usable_points"]:,} actual usable '
             f'points and {d["folded_columns"]} folded columns. In {d["measured_runs"]} verified '
             f'one-target runs, mean cold counted S is {d["mean_cold_s_lower_bound"]:.3f} as a lower '
             f'bound; its counted IC/rho quotient is {d["cold_counted_over_rho_diagnostic"]:.3f}, '
             f'and K16/K42 is {d["cold_counted_over_k42_diagnostic"]:.3f}. Both arms leave native '
             'work unpriced, and L0 timing gives no admitted online speedup. These figures are not '
             'comparable to tables A–C. '
             f'<a href="https://github.com/aburan28/crypto/blob/main/{esc(d["source"])}">Frozen decision</a>. '
             'A separate whole-solve Callgrind census finds K16/K42 = 0.367 and K16/rho = 4.461 '
             'in simulated instructions on eight paired points; native wall and online speed remain unknown. '
             '<a href="https://github.com/aburan28/crypto/blob/main/research/ecbench_callgrind_solve_20261004/RESULT.md">Raw instruction replay</a>.</p></section>')
    c = doc["n37_k8_k16_confirmation"]
    P.append(f'<section class="card" id="bounded-n37-k8-confirmation"><h2>Untouched n37 K8/K16 instruction confirmation</h2>'
             f'<p>On <code>{esc(c["curve"])}</code>, K8 has {c["usable_points"]:,} usable points '
             f'and {c["folded_columns"]} folded columns. Across {c["workloads"]} new same-point '
             f'public workloads, K16/K8 whole-solve Callgrind Ir is {c["k16_over_k8_ir"]:.3f} '
             f'[{c["k16_over_k8_ir_ci95"][0]:.3f}, {c["k16_over_k8_ir_ci95"][1]:.3f}], '
             f'selecting K8 for the cold implementation route. K8/rho is '
             f'{c["k8_over_rho_ir"]:.3f} [{c["k8_over_rho_ir_ci95"][0]:.3f}, '
             f'{c["k8_over_rho_ir_ci95"][1]:.3f}] in the same instruction unit. '
             'All 64 profiles and 320 independently replayed measured records verified. '
             'This is not isolated online wall speed; K16 remains a target-only candidate. '
             f'<a href="https://github.com/aburan28/crypto/blob/main/{esc(c["source"])}">Frozen decision</a>.</p></section>')
    q = doc["n37_online_ir_diagnostic"]
    P.append(f'<section class="card" id="bounded-n37-online-ir"><h2>Fresh n37 K8/K16 target-only instruction gate</h2>'
             f'<p>On <code>{esc(q["curve"])}</code>, K8/K16 target-only Callgrind Ir is '
             f'{q["k8_over_k16_online_ir"]:.3f} '
             f'[{q["k8_over_k16_online_ir_ci95"][0]:.3f}, '
             f'{q["k8_over_k16_online_ir_ci95"][1]:.3f}], so the frozen gate '
             'prioritizes K16 for an isolated n37 online wall test. K16/rho '
             f'target-only Ir is {q["k16_over_rho_online_ir"]:.3f} '
             f'[{q["k16_over_rho_online_ir_ci95"][0]:.3f}, '
             f'{q["k16_over_rho_online_ir_ci95"][1]:.3f}], but K8/K16 '
             f'complete-solve Ir is {q["k8_over_k16_cold_ir"]:.3f}. '
             'All 64 profiles and 320 independent native replays verified. '
             'Callgrind Ir is simulated instruction work, not isolated wall '
             'speed; n41/n53 and ECC2K-130 transfer stay open. '
             f'<a href="https://github.com/aburan28/crypto/blob/main/{esc(q["source"])}">Frozen decision and raw replay</a>.</p></section>')
    w = doc["n37_native_wall_diagnostic"]
    P.append(f'<section class="card" id="bounded-n37-native-wall"><h2>Hosted n37 native wall screen: L1 diagnostic</h2>'
             f'<p>On <code>{esc(w["curve"])}</code>, all {w["measured_verified_runs"]} measured '
             f'executions replayed on another host class. For preregistered one-target workload '
             f'<code>{esc(w["primary_workload_id"])}</code>, descriptive rho/K16 online wall is '
             f'{w["primary_rho_over_k16_online_wall"]:.3f}. Across the separate 16-target panel, '
             f'K8/K16 online wall is {w["panel_k8_over_k16_online_wall"]:.3f} '
             f'[{w["panel_k8_over_k16_online_wall_ci95"][0]:.3f}, '
             f'{w["panel_k8_over_k16_online_wall_ci95"][1]:.3f}]. '
             f'All rows earned L1, and the identical K16 A/A maximum deviation was '
             f'{100*w["aa_max_relative_deviation"]:.2f}%, above the frozen 5% gate. '
             'No online speedup is admitted; carry K8 and K16 to an L2 host and n41/n53. '
             f'<a href="https://github.com/aburan28/crypto/blob/main/{esc(w["source"])}">Frozen decision</a>.</p></section>')
    z = doc["f6_small_cold_diagnostic"]
    f4, f6, f5 = (z["arms"][arm] for arm in ("inherited_f4", "f6_ic", "f5"))
    P.append(f'<section class="card" id="bounded-f6-small-cold"><h2>Complete n9 F6-IC control, outside the priced tables</h2>'
             f'<p>On <code>{esc(z["curve"])}</code>, all three arms recovered the logarithm of '
             f'public point <code>{esc(z["target"])}</code> after building {z["usable_points"]} usable '
             f'base points, collecting {z["verified_relations"]} verified ordinary relations and '
             f'solving {z["folded_columns"]} folded columns. Inherited F4, F6-IC and matrix F5 '
             f'inside-worker cold times were {f4["cold_inside_worker_ns"]/1e6:.3f}, '
             f'{f6["cold_inside_worker_ns"]/1e6:.3f} and {f5["cold_inside_worker_ns"]/1e6:.3f} ms; '
             f'their one-target online times were {f4["online_wall_ns"]/1e6:.3f}, '
             f'{f6["online_wall_ns"]/1e6:.3f} and {f5["online_wall_ns"]/1e6:.3f} ms. '
             'Independent replay checked all scalars, relations, column logs and phase totals. '
             'These are exploratory L0 Mac wall observations on a tiny subgroup. With no '
             'same-target rho reference or fully priced operation count, IC/rho speedup and S '
             'remain unknown. '
             f'<a href="https://github.com/aburan28/crypto/blob/main/{esc(z["source"])}">Keyed measurements</a> · '
             f'<a href="https://github.com/aburan28/crypto/blob/main/{esc(z["replay"])}">independent replay</a>.</p>')
    P.append('<table><thead><tr><th>Solver</th><th>Candidate ID</th><th>Cold ms</th><th>Online ms</th></tr></thead><tbody>')
    for arm, label in (("inherited_f4", "Inherited F4"), ("f6_ic", "F6-IC"), ("f5", "Matrix F5")):
        row = z["arms"][arm]
        P.append(f'<tr><td>{label}</td><td><code>{esc(row["candidate_id"])}</code></td>'
                 f'<td>{row["cold_inside_worker_ns"]/1e6:.3f}</td>'
                 f'<td>{row["online_wall_ns"]/1e6:.3f}</td></tr>')
    P.append('</tbody></table></section>')
    y = doc["f6_ecbench_ladder_diagnostic"]
    P.append(f'<section class="card" id="bounded-f6-ecbench-ladder"><h2>F6-IC E_0 ladder in ecbench, outside the priced tables</h2>'
             '<p>#1333\'s inherited-F4 and F6-IC decomposers ran unmodified in <code>ic.pipeline</code> '
             'beside same-target strong rho on eight public one-target workloads per size. IC S is a '
             'lower bound: the solver\'s word XORs are counted but unpriced, and F6-IC\'s geometric point '
             'additions are charged. The F6-IC word-XOR saving vanishes once the base exceeds #1333\'s '
             '256-point closure cap; charging its geometry makes the trade a relabelling. '
             f'Decision: {esc(y["decision"])} (m = 31 incomplete). '
             f'<a href="https://github.com/aburan28/crypto/blob/main/{esc(y["source"])}">Analysis</a>.</p>')
    P.append('<table><thead><tr><th>m</th><th>Curve</th><th>Targets</th><th>Rho S</th>'
             '<th>F4 S/rho (lower bound)</th><th>F6-IC S/rho (lower bound)</th><th>Median log₂(W4/W6)</th></tr></thead><tbody>')
    for z in y["sizes"]:
        P.append(f'<tr><td>{z["m"]}</td><td><code>{esc(z["curve"])}</code></td><td>{z["targets"]}</td>'
                 f'<td>{z["rho_s"]:.3f}</td><td>{z["f4_s_lower_over_rho"]:.3f}</td>'
                 f'<td>{z["f6_s_lower_over_rho"]:.3f}</td><td>{z["median_log2_w4_over_w6"]:.3f}</td></tr>')
    P.append('</tbody></table></section>')
    y = doc["f4_f5_f6_cross_family_diagnostic"]

    def h3(v):
        return "—" if v is None else f"{v:.3f}"
    P.append(f'<section class="card" id="bounded-f4-f5-f6-cross-family"><h2>F4, F5 and F6-IC on Koblitz and generic binary curves, outside the priced tables</h2>'
             '<p>Matrix F4, matrix F5, inherited F4 and F6-IC through <code>pdp3-binary</code> on eight public '
             'one-target workloads per cell, beside same-target rho. IC S is a lower bound: solver word XORs '
             'are unpriced and F6-IC\'s geometric additions are charged. W is counted solver word XORs. '
             'Prime curves have no algebraic oracle in <code>ecbench</code>. '
             f'<a href="https://github.com/aburan28/crypto/blob/main/{esc(y["source"])}">Analysis</a>.</p>')
    P.append('<table><thead><tr><th>Family</th><th>m</th><th>Curve</th><th>Base points</th><th>Rho-negation S</th>'
             '<th>Strong rho S</th><th>Inherited F4 S</th><th>F6-IC S</th><th>W F5/F4</th>'
             '<th>W matrix F4/inherited</th><th>Median log₂(W inh/W F6)</th></tr></thead><tbody>')
    for z in y["rows"]:
        P.append(f'<tr><td>{esc(z["family"])}</td><td>{z["m"]}</td><td><code>{esc(z["curve"])}</code></td>'
                 f'<td>{z["base_points"]}</td><td>{h3(z["rho_negation_s"])}</td><td>{h3(z["rho_strong_s"])}</td>'
                 f'<td>{h3(z["inherited_s"])}</td><td>{h3(z["f6_s"])}</td><td>{h3(z["f5_over_f4_w"])}</td>'
                 f'<td>{h3(z["matrix_f4_over_inherited_w"])}</td><td>{h3(z["log2_inherited_over_f6_w"])}</td></tr>')
    P.append('</tbody></table></section>')
    v = doc["n41_n53_counted_diagnostic"]

    def qhtml(q: dict) -> str:
        if q["ratio_of_sums"] is None:
            return f'unknown ({q["pairs"]} verified pairs)'
        ci = q["ci95"]
        return (f'{q["ratio_of_sums"]:.3f} <span class="muted">[{ci[0]:.3f}, {ci[1]:.3f}]</span>' if ci
                else f'{q["ratio_of_sums"]:.3f} <span class="muted">(no interval)</span>')
    P.append(f'<section class="card" id="bounded-n41-n53-counted"><h2>n41/n53 shared-rank counted panel, outside the priced tables</h2>'
             '<p>The four n37 arms, method parameters unchanged, on 16 new public one-target workloads '
             'on each of the next two registered sizes, five paired rounds each, on macOS at L0. '
             'Counted cold IC/rho is a quotient of two lower bounds with native work unpriced; a cell '
             'whose arm never verifies under the frozen parameters is unknown, not a cost. '
             f'{v["measured_verified_runs"]} of {v["measured_runs"]} measured runs verified; decision '
             f'<code>{esc(v["decision"])}</code>; the L2 host run is pending. '
             f'<a href="https://github.com/aburan28/crypto/blob/main/{esc(v["source"])}">Frozen decision</a>.</p>')
    P.append('<table><thead><tr><th>Curve</th><th class="n">log₂ r</th><th>Arm</th><th class="n">Verified / measured</th>'
             '<th class="n">Usable points</th><th class="n">Columns</th><th class="n">Mean cold S (lower bound)</th>'
             '<th>Counted IC/rho [95%]</th></tr></thead><tbody>')
    for c in v["curves"]:
        for a in c["arms"]:
            q = {"ic-k8": c["k8_over_rho"], "ic-k16": c["k16_over_rho"]}.get(a["arm"])
            s_txt = f'{a["mean_cold_s_lower_bound"]:.3f}' if a["mean_cold_s_lower_bound"] is not None else "—"
            P.append(f'<tr><td><code>{esc(c["curve"])}</code></td><td class="n">{c["log2_r"]:.2f}</td><td>{esc(a["arm"])}</td>'
                     f'<td class="n">{a["verified"]}/{a["measured"]}</td>'
                     f'<td class="n">{a["usable_points"] if a["usable_points"] is not None else "—"}</td>'
                     f'<td class="n">{a["folded_columns"] if a["folded_columns"] is not None else "—"}</td>'
                     f'<td class="n">{s_txt}</td>'
                     f'<td>{qhtml(q) if q else ("reference" if a["arm"] == "rho-strong" else "A/A control")}</td></tr>')
        P.append(f'<tr><td><code>{esc(c["curve"])}</code></td><td class="n">{c["log2_r"]:.2f}</td><td>K16 / K8</td>'
                 f'<td class="n">—</td><td class="n">—</td><td class="n">—</td><td class="n">—</td><td>{qhtml(c["k16_over_k8"])}</td></tr>')
    P.append('</tbody></table></section>')

    head_cells = ('<th class="n">#</th><th>curve</th><th class="n">log₂ r</th><th>recipe</th>'
                  '<th class="n">m</th><th class="n">|F|</th><th class="n">K</th><th class="n">S, IC</th>'
                  '<th class="n">S, ref</th><th class="n">× ref</th><th class="n">S, floor</th>'
                  '<th class="n">× floor</th><th>phases</th><th>ok</th>')
    ncols = 14

    def board_rows(g: str) -> None:
        for i, r in enumerate(by_regime[g], 1):
            b = r["best"]
            ci = (f'<br><span class="muted">[{g3(b["ratio_rho_ci"][0])}, {g3(b["ratio_rho_ci"][1])}]</span>'
                  if "ratio_rho_ci" in b else "")
            if "online_speedup" in b:
                ci += (f'<br><span class="muted">online {g3(b["online_speedup"])}× faster '
                       f'[{g3(b["online_speedup_ci"][0])}, {g3(b["online_speedup_ci"][1])}]; '
                       f'{g3(b["online_speedup_canonical_step"])}× at the canonical step</span>'
                       f'<br><span class="muted">model: {g3(b["ic_online_over_precomputation_model"])}× slower online '
                       f'than a generic walk with the same set-up; break-even {g3(b["break_even_targets"])} targets</span>')
                if b["construction_artefact"]:
                    ci += (f'<br><span class="muted">curve construction exceeds rho\'s walk here (§23.9); '
                           f'without it {times(b["cold_ratio_without_curve_construction"])}</span>')
            if "ratio_rho_section23" in b:
                ci += (f'<br><span class="muted">was {times(b["ratio_rho_section23"])} cold, '
                       f'{g3(b["online_speedup_section23"])}× faster online (§23, at v0)</span>')
            if "ratio_rho_section21" in b:
                ci += (f'<br><span class="muted">was {times(b["ratio_rho_section21"])} (§21)</span>'
                       f'<br><span class="muted">derived one-target cold estimate: {times(b["one_target_cold_ratio_section20"])} '
                     f'(§20; not table A\'s measurement)</span>')
            rank = "—" if b.get("construction_artefact") else i
            P.append(f'<tr class="{"lead" if r["slug"] == L[g]["slug"] else ""}"><td class="n">{rank}</td>'
                     f'<td><span class="slug">{esc(r["slug"])}</span>{record_cell(r)}</td><td class="n">{r["log2_r"]:.1f}</td>'
                     f'<td class="recipe">{esc(b["label"])}</td><td class="n">{b["m"]}</td><td class="n">{b["base_points"]:,}</td>'
                     f'<td class="n">{b["columns"]:,}</td><td class="n">{g3(b["s"])}</td>'
                     f'<td class="n">{g3(r["reference_s"])}</td><td class="n"><span class="ratio">{times(b["ratio_rho"])}</span>{ci}</td>'
                     f'<td class="n">{g3(r["floor_s"])}</td><td class="n">{times(b["ratio_floor"])}</td><td>{phase_bar(b["phases_s"], b["s"])}</td>'
                     f'<td>{"✓" if b["verified"] else "✗"}</td></tr>')


    def family_defs(code: str) -> str:
        f = doc["families"][code]
        defs = [("Unit", f"{f['unit']}. {f['unit_how']}"), ("Reference", f["reference"]),
                ("Floor", f["floor"]), ("Targets", f["targets"]), ("Status", f["status"])]
        steps = step_line(f)
        if steps:
            defs.append(("Rho step", steps))
        return ('<dl class="defs">' + "".join(
            f'<div><dt>{esc(k)}</dt><dd>{rich(v)}</dd></div>' for k, v in defs) + '</dl>'
            f'<p class="muted">Read S, × ref and × floor in table {code} only.</p>')

    def family_table(code: str) -> None:
        f = doc["families"][code]
        multi = len(f["regimes"]) > 1
        P.append(f'<div class="scroll"><table><thead><tr>{head_cells}</tr></thead><tbody>')
        for g in f["regimes"]:
            if multi:
                P.append(f'<tr><td colspan="{ncols}"><span class="chip">{esc(REGIME_NAME[g])}</span></td></tr>')
            board_rows(g)
        P.append('</tbody></table></div>')

    # The board: the index, the chart, and what the three tables are.
    P.append('<section class="panel" id="board"><h2>The board</h2>'
             '<p>One row per curve: its best recipe, ranked within its table by the cold ratio to that table\'s '
             'reference, the whole method from set-up to a verified logarithm. <strong>There is no single unit '
             'here.</strong> Tables A, B and C below are priced in different units against different references '
             'and floors, stated at the head of each; S, × ref and × floor are comparable inside a table and '
             'nowhere else. Tables A and B solve one target per row, as AGENTS.md\'s one-target rule requires: '
             'A on one unseen public point per process against one-target rho on the same point (§23\'s comparison, '
             're-run at the ic tool programme\'s baseline v3, 64 points per size, §23\'s figures kept as the '
             'before marks), B against the matched negation-map rho (ledger §18). Table C is a historical 32-target '
             'diagnostic. For the Koblitz rows of A the online interval, the reading with rho at the canonical '
             'step and the generic-precomputation model sit beside the cold ratio, as §23 requires. The bar '
             'splits S into phases. A walked-target row on the ladder is resolved to about a factor 1.8 either '
             'way at three repetitions (ledger §13.7).</p>'
             f'<div class="scroll">{ratio_chart(board)}</div>'
             '<p class="muted">Each dot is a ratio to its own table\'s reference, in that table\'s unit; the '
             'three rows of dots are not comparable with one another.</p>'
             '<div class="legend">' + "".join(
                 f'<span><i style="background:var(--ph-{pid})"></i>{esc(n)}</span>' for pid, n, _ in PHASES)
             + '</div></section>')
    for code, anchor, title in (("A", "board-A", "Table A · Koblitz, one target"),
                                ("B", "board-B", "Table B · prime and random-binary ladder")):
        f = doc["families"][code]
        P.append(f'<section class="panel" id="{anchor}"><h2>{esc(title)} <span class="chip">{esc(f["section"])}</span></h2>'
                 + family_defs(code))
        family_table(code)
        P.append('</section>')

    # Table C: the Koblitz batch, a historical diagnostic.
    fc = doc["families"]["C"]
    P.append(f'<section class="panel" id="batch"><h2>Table C · Koblitz, 32 targets in a batch '
             f'<span class="chip">{esc(fc["section"])}</span></h2>'
             '<p>The collection thread\'s rounds before §23 solved 32 targets together and priced them per target '
             'against batch rho on the same 32 (§19–§22). Under the one-target rule that is a historical '
             'diagnostic, not a primary comparison; it is kept here with its §21 figure as the before mark and '
             'the one-target cold ratio §20 derived from this run (shared phases plus one mean descent, against '
             'single-target rho), which table A\'s measured figure replaces. The phase split is the most detailed '
             'the thread has.</p>'
             + family_defs("C"))
    family_table("C")
    P.append('</section>')

    # Every recipe, every curve (the ladder).
    ladder = [r for r in board if r["regime"] in ("prime", "char2")]
    variants = []
    for r in ladder:
        for v in r["recipes"]:
            if v["variant"] not in variants:
                variants.append(v["variant"])
    P.append('<section class="panel" id="recipes"><h2>Every recipe on every ladder curve</h2>'
             '<p>Table B only: ratio to the matched rho for each variant the ladder ran, three repetitions averaged. '
             'The minimum per curve is the row on the board. The balanced recipe sizes the base at the '
             'family optimum F = (c·#E·t/k)<sup>1/3</sup>, which is 0.75·r<sup>1/6</sup> in S on a '
             'prime-order curve (ledger §11.2): a rising cost against a flat reference, so this family '
             'has no crossover to find at any size.</p><div class="scroll"><table><thead><tr><th>recipe</th>')
    for r in ladder:
        P.append(f'<th class="n" title="{esc(r["slug"])}">{"p" if r["regime"] == "prime" else "b"}·{r["log2_r"]:.1f}</th>')
    P.append('</tr></thead><tbody>')
    for vname in variants:
        P.append(f'<tr><td>{esc(VARIANTS.get(vname, vname))}</td>')
        for r in ladder:
            v = next((x for x in r["recipes"] if x["variant"] == vname), None)
            best = v == r["best"]
            cell = times(v["ratio_rho"]) if v else "—"
            P.append(f'<td class="n">{"<strong>" + cell + "</strong>" if best else cell}</td>')
        P.append('</tr>')
    P.append('</tbody></table></div><p class="muted">Column heads: p = prime field, b = random binary, '
             'then log₂ r. Hover a head for the curve\'s slug.</p></section>')

    # Step by step.
    ex = doc["exponents"]
    head_kob = next(r for r in board if r["regime"] == "koblitz_batch"
                    and r["slug"] == L["koblitz_batch"]["slug"])["best"]
    head_pr = next(r for r in board if r["slug"] == L["prime"]["slug"])["best"]
    rows_steps = [
        ("setup", "#E by Schoof / Koblitz recurrence, factor, clear the cofactor", "one-off; Koblitz: 25–171 units a base point at 2^27.8 and up", "—", "—"),
        ("factor_base", "Base of |F| points: small abscissae (prime), a subspace (binary), Frobenius orbits (Koblitz)", "|F|; the balanced optimum puts |F| ∝ r^{1/3}", "prime", "factor_base"),
        ("constructions", "Orbit map, point index and decomposition classes around the work (Koblitz); built once per base since §21", "per base point; 0.4–16% of S after §21 (ledger §21.3)", "—", "—"),
        ("table", "All |F|(|F|+1)/2 pair sums, folded by negation or by ⟨σ, −1⟩; on the ladder counted inside the factor base", "|F|² / (4t) stored pairs, t the fold", "—", "—"),
        ("relations", "Draw a target, ask the PDP oracle whether it is a sum of m base points, keep verified hits", "trials ≈ (K+1) / ceiling; per trial one table probe (m = 2) or |F| (m = 3)", "prime", "relations"),
        ("linear_algebra", "Relations as rows over Z/rZ; dense Gauss–Jordan (ladder) or filter + block Wiedemann (Koblitz)", "dense K³, sparse ~K·weight", "prime", "linear_algebra"),
        ("descent", "Each target decomposed over the logged base: an m = 2 or 3 whole-base scan", "≈ 2r / |F|² probes per target; does not amortise over targets", "—", "—"),
        ("verify", "Re-add every relation; check [d]G = Q for every target", "one scalar multiplication per target", "—", "—"),
    ]
    P.append('<section class="panel" id="steps"><h2>The ECDLP, step by step</h2>'
             '<p>What each phase computes, what it costs, and how fast it grows. The exponent α is the fit of that '
             'phase\'s operations to r<sup>α</sup> on the Round-5 ladder (table B, in GAE) for the balanced recipe; rho grows as '
             'r<sup>1/2</sup>, so a phase with α above ½ loses ground at every size. The share columns are the '
             'phase\'s part of S on each family\'s leading row.</p><div class="scroll"><table><thead><tr>'
             '<th>phase</th><th>what it does</th><th>cost model</th><th class="n">α prime</th><th class="n">α binary</th>'
             f'<th class="n">share · Koblitz batch 2^{L["koblitz_batch"]["log2_r"]:.0f} (§22)</th><th class="n">share · prime 2^{L["prime"]["log2_r"]:.1f}</th></tr></thead><tbody>')
    for pid, what, model, _, fitkey in rows_steps:
        name = next(n for i, n, _ in PHASES if i == pid)
        ap = ex["prime"]["phases"].get(fitkey, {}).get("alpha") if fitkey != "—" else None
        ab = ex["char2"]["phases"].get(fitkey, {}).get("alpha") if fitkey != "—" else None
        sk = head_kob["phases_s"].get(pid)
        sp = head_pr["phases_s"].get(pid)
        share_k = f"{100 * sk / head_kob['s']:.1f}%" if sk else "—"
        share_p = f"{100 * sp / head_pr['s']:.1f}%" if sp else "—"
        P.append(f'<tr><td><i style="display:inline-block;width:9px;height:9px;border-radius:2px;background:var(--ph-{pid});margin-right:6px"></i>{esc(name)}</td>'
                 f'<td>{esc(what)}</td><td>{esc(model)}</td>'
                 f'<td class="n">{g3(ap) if ap is not None else "—"}</td><td class="n">{g3(ab) if ab is not None else "—"}</td>'
                 f'<td class="n">{share_k}</td><td class="n">{share_p}</td></tr>')
    P.append(f'<tr><td><strong>Whole method</strong></td><td>all of the above, cold</td><td>family optimum S ∝ r<sup>1/6</sup></td>'
             f'<td class="n"><strong>{g3(ex["prime"]["phases"]["total"]["alpha"])}</strong></td>'
             f'<td class="n"><strong>{g3(ex["char2"]["phases"]["total"]["alpha"])}</strong></td><td class="n">100%</td><td class="n">100%</td></tr>'
             f'<tr><td>Matched rho</td><td>negation-map r-adding walk, distinguished points</td><td>√(πr/2A)</td>'
             f'<td class="n">{g3(ex["prime"]["rho_matched"]["alpha"])}</td><td class="n">{g3(ex["char2"]["rho_matched"]["alpha"])}</td><td class="n">—</td><td class="n">—</td></tr>')
    P.append('</tbody></table></div>'
             f'<p>At the Koblitz batch headline (§22) the pipeline stored {head_kob["stored_pairs"]:,} pairs, collected '
             f'{head_kob["relations"]:,} relations from {head_kob["summands_scanned"]:,} scanned summands, reduced '
             f'{head_kob["la_rows_in"]} rows to a Wiedemann core of dimension {head_kob["la_core_dimension"]}, and '
             f'spent {g3(head_kob["descent_trials_per_target"])} descent trials per target. Koblitz top-end exponent, '
             f'ratio·√n against r over the four largest sizes: β = {g3(ex["koblitz"]["beta"])} '
             f'[{g3(ex["koblitz"]["ci"][0])}, {g3(ex["koblitz"]["ci"][1])}], against the law\'s 1/6 and the model\'s '
             f'{ex["koblitz"]["model"]}; it cannot yet tell them apart. The ladder\'s rho fits sit under ½ because '
             'set-up still shows at these sizes (ledger §18.5).</p></section>')

    # PDP oracles.
    oracle_names = []
    for o in doc["oracles"]:
        for k in o["oracles"]:
            if k not in oracle_names:
                oracle_names.append(k)
    P.append('<section class="panel" id="pdp"><h2>The point decomposition problem, per target</h2>'
             '<p>Every oracle answers the same question on the same Semaev systems: is this target a sum of m base '
             'points? Cost is group-addition equivalents per target, found and refuted averaged; FFD is the first '
             'fall degree of the Weil-restricted system. The pair table answers in 0–25 units where F4 needs 10<sup>2</sup>–10<sup>6</sup> '
             'and SAT more, which is why the board\'s recipes use it. Zero disagreements on every cell.</p>'
             '<div class="scroll"><table><thead><tr><th>curve</th><th class="n">n</th><th class="n">m</th>'
             '<th class="n">ℓ</th><th class="n">unknowns</th><th class="n">FFD</th><th class="n">hit rate</th>'
             + "".join(f'<th class="n">{esc(k)}</th>' for k in oracle_names) + '</tr></thead><tbody>')
    for o in doc["oracles"]:
        ffd = "—" if o["ffd"][0] is None else (str(o["ffd"][0]) if o["ffd"][0] == o["ffd"][1] else f"{o['ffd'][0]}–{o['ffd'][1]}")
        P.append(f'<tr><td><span class="slug">{esc(o["slug"])}</span></td><td class="n">{o["n"]}</td><td class="n">{o["m"]}</td>'
                 f'<td class="n">{o["dimension"]}</td><td class="n">{o["unknowns"]}</td><td class="n">{ffd}</td>'
                 f'<td class="n">{o["hit_rate"]:.2f}</td>')
        for k in oracle_names:
            v = o["oracles"].get(k)
            if v is None:
                P.append('<td class="n">—</td>')
            elif v["inconclusive"] and not (v["found"] or v["refuted"]):
                P.append('<td class="n muted">no answer</td>')
            else:
                P.append(f'<td class="n">{g3(v["gae_per_target"])}</td>')
        P.append('</tr>')
    P.append(f'</tbody></table></div><p class="muted">Source: <code>{esc(SOURCES["oracles"])}</code>, a stage '
             'diagnostic: one phase priced alone is not a speed (AGENTS.md §2).</p></section>')

    # The curve roster.
    fam_order = ("koblitz", "subfield", "binary", "prime")
    P.append('<section class="panel" id="curves"><h2>Every curve the repository names</h2>'
             '<p>From the curve registry. The slug is the curve\'s name in text; the EC1 alias identifies the exact '
             'representation measured (subgroup and generator included) for comparisons across repositories. '
             'Legacy spellings are what older notes and frozen reports called the curve.</p>')
    cr = doc["curve_records"]
    P.append(f'<p id="curve-records"><strong>Curve records.</strong> Identity comes from {gh(cr["registry"])}. '
             f'IC curve records follow the schema {gh(cr["schema"])} and live in {gh(cr["yaml"])} '
             f'({cr["yaml_records"]} records), which carries each curve\'s <code>factor_base_refs</code> and '
             f'<code>factor_base_link_status</code>. {cr["board_curves_in_yaml"]} of the {cr["board_curves"]} curves '
             f'on the board have a record there, and {cr["board_curves_factor_base_reconciled"]} have a reconciled '
             'factor base; each board row shows its own record and the factor base its source file used.</p>')
    for fam in fam_order:
        rows = [c for c in doc["roster"] if c["family"] == fam]
        if not rows:
            continue
        P.append(f'<details {"open" if fam == "koblitz" else ""}><summary>{esc(fam)} · {len(rows)} curves · '
                 f'{sum(c["on_board"] for c in rows)} on the board</summary><div class="scroll"><table><thead><tr>'
                 '<th>slug</th><th>field</th><th>coefficients</th><th class="n">#E bits</th><th>EC1</th>'
                 '<th>also called</th><th>curves.yaml</th><th>board</th></tr></thead><tbody>')
        for c in rows:
            ec1 = ", ".join(c["ec1"]) if c["ec1"] else f'<span class="muted">{esc(c["ec1_unresolved"])}</span>'
            also = ", ".join(c["standard"] + c["legacy"])
            P.append(f'<tr><td><span class="slug">{esc(c["slug"])}</span></td><td>{esc(c["field"])}</td>'
                     f'<td>{esc(c["coefficients"])}</td><td class="n">{c["order_bits"]}</td>'
                     f'<td><code>{ec1 if c["ec1"] else ""}</code>{"" if c["ec1"] else ec1}</td>'
                     f'<td>{esc(also)}</td><td>{esc(c["curves_yaml_key"] or "—")}</td>'
                     f'<td>{"✓" if c["on_board"] else ""}</td></tr>')
        P.append('</tbody></table></div></details>')
    P.append('</section>')

    # Native observations are rendered without recomputing a comparison.
    P.append('<section id="conductor-gap-counts"><h2>Large-prime conductor-gap counted diagnostics</h2>'
             '<p>Eight independent one-target workloads per fixed curve, no transported targets. '
             'Counted S leaves native work unpriced. These observations remain outside tables A–C '
             'and the full-cost rankings.</p><table><thead><tr><th>ell</th><th>IC floor/crater</th>'
             '<th>99% interval</th></tr></thead><tbody>')
    for session in doc["conductor_gap_count_diagnostic"]["sessions"]:
        observed = session["arms"]["ic-mitm"]["cross_curve"]
        P.append(f'<tr><td>{session["ell"]}</td><td>{observed["ratio_floor_over_crater"]:.6f}</td>'
                 f'<td>{observed["ci99"][0]:.6f} to {observed["ci99"][1]:.6f}</td></tr>')
    P.append('</tbody></table>' + gh(SOURCES["conductor_gap_counts"], 'Native analysis and source records') + '</section>')

    # Footer.
    P.append('<footer><p><strong>What this is not.</strong> A view of frozen measurements, class accounting: no row '
             'here was measured for this page, and nothing is a speedup. Records kept in other units, wall-clock '
             'panels and batched producers awaiting independent replay, are in '
             '<a href="https://github.com/aburan28/crypto/blob/main/docs/ic/BOUNDARY_TARGETS.md">docs/ic/BOUNDARY_TARGETS.md</a>; the canonical page is the '
             '<a href="https://aburan28.github.io/crypto/scoreboard/">index-calculus scoreboard</a>. No IC pipeline has been priced '
             'end to end on ECC2K-130 or on the m = 83 confidence gate (AGENTS.md §8a).</p>'
             f'<p>Current through ledger §{LEDGER_COVERED_THROUGH}; latest frontier audit '
             f'{esc(doc["latest_frontier_audit"]["date"])}. Built by '
             '<code>scripts/build_ic_leaderboard.py</code> from: '
             + ", ".join(f'<code>{esc(v["path"])}</code> ({v["sha256"][:12]})' for v in doc["sources"].values())
             + '. Curves are named by ICV1 slug (<a href="https://github.com/aburan28/crypto/blob/main/docs/curves/ICV1.md">docs/curves/ICV1.md</a>); '
             f'curve records: {gh(SOURCES["curves_schema"])} and {gh(SOURCES["curves_yaml"])} '
             '(<a href="#curve-records">coverage</a>).</p></footer></div>')
    body = "\n".join(P)
    if standalone:
        return ('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
                '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
                '<meta name="description" content="Every curve priced end to end by index calculus in this '
                'repository, with the best recipe, the phase split and the ratio to matched Pollard rho.">\n'
                f"{head}</head>\n<body>\n{body}\n</body>\n</html>\n")
    return head + body + "\n"


def stable(o):
    """Round every float to 12 significant figures.

    Phase totals are sums and means of many frozen readings, and their last
    one or two digits differ between Python builds (summation and mean
    rounding), which made `--check` call the committed file stale on a
    runner whose interpreter differed from the author's.  Twelve figures is
    far below anything the page or a ratio reads, and identical everywhere.
    """
    if isinstance(o, float):
        return float(f"{o:.12g}") if math.isfinite(o) else o
    if isinstance(o, dict):
        return {k: stable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [stable(v) for v in o]
    return o


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--artifact", type=Path)
    args = ap.parse_args()
    doc = build()
    # Round only the JSON: rendering compares recipe rows by identity.
    serialized = stable(doc)
    # This diagnostic copies native results without Python-derived arithmetic;
    # preserve their full binary64 values instead of rounding their evidence.
    serialized["n83_matched_process_diagnostic"] = doc["n83_matched_process_diagnostic"]
    outs = {OUT_JSON: json.dumps(serialized, indent=1, ensure_ascii=False) + "\n",
            OUT_MD: markdown(doc), OUT_HTML: page(doc, standalone=True)}
    if args.check:
        sections = [int(m) for m in re.findall(r"^## (\d+)\.", (REPO / LEDGER).read_text(), re.M)]
        latest = max(sections, default=0)
        if latest > LEDGER_COVERED_THROUGH:
            print(f"{LEDGER} has §{latest}; the leaderboard is current through §{LEDGER_COVERED_THROUGH}. "
                  "Point SOURCES at the round's frozen files and regenerate, or confirm the round "
                  "changes nothing on the page; then raise LEDGER_COVERED_THROUGH (AGENTS.md §7b).",
                  file=sys.stderr)
            return 1
        stale = [str(p.relative_to(REPO)) for p, t in outs.items()
                 if not p.exists() or p.read_text() != t]
        for s in stale:
            print(f"{s} is stale; run scripts/build_ic_leaderboard.py", file=sys.stderr)
        return 1 if stale else 0
    for p, t in outs.items():
        p.write_text(t)
        print(f"wrote {p.relative_to(REPO)}")
    if args.artifact:
        args.artifact.write_text(page(doc, standalone=False))
        print(f"wrote {args.artifact}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
