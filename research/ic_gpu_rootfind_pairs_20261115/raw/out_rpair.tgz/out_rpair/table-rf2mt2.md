| session | arm | method | curve | log2 r | verified | mean S | 95% interval | theory S | S / theory | S / floor | S / reference | lower bound | med wall ms | levels | flags |
|---|---|---|---|---:|---:|---:|---|---:|---:|---:|---:|---|---:|---|---|
| ECBS1he70e7170135d | rho-neg | rho.negation | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 1.219 | [0.018, 81.080] indicative | 0.886 | 1.376 | 1.376 | 1.000 | yes | 1.852 | L0×4 | – |
| ECBS1he70e7170135d | rho-neg | rho.negation | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 0.781 | [0.281, 2.176] indicative | 0.886 | 0.882 | 0.882 | 1.000 | yes | 2.964 | L0×4 | – |
| ECBS1he70e7170135d | rho-neg | rho.negation | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 1.124 | [0.063, 19.921] indicative | 0.886 | 1.268 | 1.268 | 1.000 | yes | 8.384 | L0×4 | – |
| ECBS1he70e7170135d | rf2-cpu-F4096 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 6465.729 | [4770.598, 8763.191] indicative | – | – | 7295.794 | 5303.302 | yes | 2336.042 | L0×4 | – |
| ECBS1he70e7170135d | rf2-cpu-F4096 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 15237.389 | [3559.855, 65221.199] indicative | – | – | 17193.552 | 19501.276 | yes | 13120.350 | L0×4 | – |
| ECBS1he70e7170135d | rf2-cpu-F4096 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 24747.410 | [3491.325, 175416.009] indicative | – | – | 27924.462 | 22022.761 | yes | 34297.495 | L0×4 | – |
| ECBS1he70e7170135d | rf2-mt-F4096 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 6465.729 | [4770.598, 8763.191] indicative | – | – | 7295.794 | 5303.302 | yes | 318.244 | L0×4 | – |
| ECBS1he70e7170135d | rf2-mt-F4096 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 15237.389 | [3559.855, 65221.199] indicative | – | – | 17193.552 | 19501.276 | yes | 1323.345 | L0×4 | – |
| ECBS1he70e7170135d | rf2-mt-F4096 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 24747.410 | [3491.325, 175416.009] indicative | – | – | 27924.462 | 22022.761 | yes | 3271.747 | L0×4 | – |
| ECBS1he70e7170135d | rf2-gpud-F4096 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 6465.729 | [4770.598, 8763.191] indicative | – | – | 7295.794 | 5303.302 | yes | 102.222 | L0×4 | – |
| ECBS1he70e7170135d | rf2-gpud-F4096 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 15237.389 | [3559.855, 65221.199] indicative | – | – | 17193.552 | 19501.276 | yes | 159.811 | L0×4 | – |
| ECBS1he70e7170135d | rf2-gpud-F4096 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 24747.410 | [3491.325, 175416.009] indicative | – | – | 27924.462 | 22022.761 | yes | 296.045 | L0×4 | – |
