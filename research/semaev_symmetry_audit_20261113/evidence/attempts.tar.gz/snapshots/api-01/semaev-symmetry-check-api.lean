import ThreeActions
#check Polynomial.mapEquiv_apply
#check Polynomial.mapEquiv_C
#check AlgEquiv.coe_toRingEquiv
#check RingEquiv.coe_toRingHom
#check Polynomial.C_add
#check Equiv.Perm.mclosure_swap_castSucc_succ
