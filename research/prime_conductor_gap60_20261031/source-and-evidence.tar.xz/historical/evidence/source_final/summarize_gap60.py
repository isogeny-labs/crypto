#!/usr/bin/env python3
"""Publish an honest, hash-linked summary of the bounded recovery work."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile
from datetime import datetime,timezone

r=Path('/workspace/artifacts/gap60_recovery')
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
certificate=read('sage_certificate/worker_receipt.json')
attempt=read('explicit_attempt_001/execution.json')
failure=read('explicit_attempt_001/worker_receipt.json')
memory=read('standard_memory_lower_bound.json')
small=read('blocked_velu_v3_selftest_retry.json')
actual=read('exact60_tile_crosscheck_v3.json')
probe=read('prime_exact60_probe_131072.json')
assert certificate['status']=='certificate_verified'
assert failure['status']=='exception' and failure['error']=='MemoryError()' and attempt['exit_status']==1
assert memory['minimum_xJ_object_and_pointer_bytes']>memory['host_memory_bytes']
assert small['status']==actual['status']=='pass'
assert read('prime_probe_131072/receipt.json')['exit_status']==0
assert probe['status']=='partial_tile_only'
assert read('flint_exact60_probe_16384.json')['partial_log_jets']==read('prime_exact60_probe_16384.json')['partial_log_jets']
for name,digest in actual['sources'].items():assert sha(Path('/workspace',name))==digest
for folder in ('sage_certificate','explicit_attempt_001'):
    receipt=read(folder+'/worker_receipt.json')
    assert sha(r/folder/'source.py')==receipt['source_sha256']
    assert sha(r/folder/'parameters.json')==receipt['parameters_sha256']

files=['gap60_parameters.json','run_gap60.py','blocked_velu.py','prime_poly_trace.py',
       'prime_poly_trace.c','libprime_poly_trace.so','build_prime_poly.sh',
       'verify_gap60_blocks.py','run_capture.py','summarize_gap60.py']
src=r/'source_final';src.mkdir(exist_ok=True)
for name in files:shutil.copyfile(Path('/workspace',name),src/name)
(r/'pip_requirements.txt').write_text('python-flint==0.9.0\n')
report={
 'schema':'gap60-recovery-results-v1','created_utc':datetime.now(timezone.utc).isoformat(),
 'requested_goal':'Prime conductor gap of at least 60 bits crossed by an explicitly evaluated ordinary elliptic-curve isogeny, with matched endpoint ECDLP trials.',
 'goal_complete':False,'status':'partial_with_memory_and_implementation_scaling_blockers',
 'parameters_file':'source_final/gap60_parameters.json','prime_gap':certificate['prime_gap'],
 'prime_gap_bits':certificate['prime_gap_bits'],
 'requirements':[
  {'requirement':'Proven field and 60-bit prime, ordinary CM source, rational kernel and conductor argument','status':'verified','evidence':'sage_certificate/worker_receipt.json'},
  {'requirement':'Explicit quotient equation','status':'not_obtained','evidence':'explicit_attempt_001/worker_receipt.json','blocker':'Standard Sage path raised MemoryError; its xJ list alone exceeds host memory.'},
  {'requirement':'Non-kernel point images on complete 60-bit isogeny','status':'not_obtained','blocker':'Complete quotient and all required sums remain uncomputed.'},
  {'requirement':'Matched endpoint ECDLP measurements','status':'not_attempted','blocker':'Destination curve and transported base are not available.'}
 ],
 'standard_attempt':{'outer_wall_seconds':attempt['outer_wall_seconds'],
   'exit_status':attempt['exit_status'],'address_space_budget_GiB':attempt['memory_limit_gib'],
   'observed_peak_RSS_KiB':attempt['observed_peak_worker_rss_kib'],
   'exception':failure['error'],'failure_phase':failure['phase'],
   'minimum_coordinate_list_GiB':memory['minimum_xJ_GiB'],'host_GiB':memory['host_memory_bytes']/1024**3,
   'bound_scope':memory['scope']},
 'alternative':{'description':'Streaming polynomial products and bounded I/J tiles; exact log-norm jets computed with prime-field FLINT routines.',
   'complete_fixture_comparisons':small,'actual_target_small_tile_check':actual,
   'largest_completed_target_tile':probe,
   'full_target_maps_completed':0,
   'uncomputed_work':'All remaining rectangular tiles and leftover roots must contribute before quotient coefficients or complete point images can be recovered.',
   'scaling_status':'Memory reduction demonstrated on bounded tiles. End-to-end feasibility not demonstrated. No completed 60-bit map or end-to-end speedup is claimed.'},
 'source_ECDLP_worker_check':{'expected_scalar':'1234567','returned_scalar':json.loads((r/'log_worker_selftest.stdout').read_text())['answer'],
    'scope':'One source-only synthetic 41-bit-subgroup solve. Not a matched-endpoint experiment.'},
 'environment':{'conda_lock':'sage_environment_explicit.txt','pip_requirements':'pip_requirements.txt','sage':'10.9',
    'old_workspace_artifacts_present':False,'historical_note':'The old dataset is not part of this fresh workspace; exact 60-bit parameters were reconstructed from the conversation.'},
 'verification_limits':['CM/volcano structural argument and executable arithmetic checks, not proof-assistant certification.',
    'Some diagnostic timings overlapped the standard attempt; no controlled backend speedup claim.',
    'Source/kernel certification and partial polynomial sums do not constitute a fully evaluated isogeny.',
    'The memory obstruction is specific to the standard Sage implementation, not a mathematical impossibility result.'],
 'next_obligation':'A method with feasible total work and memory must complete every required sum or otherwise construct the quotient and non-kernel images; preserve the 60-bit target.',
 'sources':{name:sha(src/name) for name in files}}
(r/'results.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
manifest={str(p.relative_to(r)):sha(p) for p in sorted(r.rglob('*')) if p.is_file() and p.name!='input_manifest.json'}
(r/'input_manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
archive=Path('/workspace/artifacts/gap60_recovery_evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(r.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(r.parent))
print(json.dumps({'results':str(r/'results.json'),'archive':str(archive),'archive_sha256':sha(archive),'goal_complete':False}))
