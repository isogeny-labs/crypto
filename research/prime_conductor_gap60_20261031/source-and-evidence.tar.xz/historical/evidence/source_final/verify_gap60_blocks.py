#!/usr/bin/env python3
"""Independent direct-root check for a tile at the exact target parameters."""
import hashlib
import json
from pathlib import Path
from sage.all import EllipticCurve, GF, ZZ
from blocked_velu import tile, _choose_IJK

p=json.loads(Path('/workspace/gap60_parameters.json').read_text())
F=GF(ZZ(p['p']));E=EllipticCurve(F,list(map(ZZ,p['source_coefficients'])))
K=E(tuple(map(ZZ,p['kernel'])));ell=ZZ(p['ell']);assert ell*K==E(0);K.set_order(ell)
G=E(tuple(map(ZZ,p['generator'])));I,J,_=_choose_IJK(ell);I=I[:8];J=J[:8]
roots=[((i+s*j)*K)[0] for i in I for j in J for s in (1,-1)]
assert len(roots)==128 and len(set(roots))==128
expected=[(-sum(roots),-sum(x*x for x in roots)/2,-sum(x*x*x for x in roots)/3)]
for alpha in (G[0],(7*G)[0]):
    ratios=[1/(alpha-x) for x in roots]
    expected.append((sum(ratios),-sum(r*r for r in ratios)/2,sum(r*r*r for r in ratios)/3))
for backend in ('sage','flint','prime'):
    assert tile(E,K,I,J,[None,G[0],(7*G)[0]],backend)==expected

from flint import fmpz_mod_poly_ctx
from prime_poly_trace import log_norm_jet
R=fmpz_mod_poly_ctx(int(F.order()));Z=R.gen()
try:log_norm_jet((Z-1)*(Z-2),(Z-1,R.one(),R.zero(),R.zero()))
except ValueError:negative_control=True
else:raise AssertionError('noninvertible polynomial accepted')

out={'status':'pass','degree':str(ell),'field':str(F.order()),'tile_dimension':8,
     'independent_explicit_roots':128,'backends':['sage','flint','prime'],
     'noninvertible_polynomial_negative_control':negative_control,
     'scope':'Actual 60-bit kernel; a small tile checked against direct enumeration. Not a complete isogeny evaluation.',
     'sources':{name:hashlib.sha256(Path('/workspace',name).read_bytes()).hexdigest()
                for name in ('blocked_velu.py','prime_poly_trace.c','prime_poly_trace.py','libprime_poly_trace.so')}}
Path('/workspace/artifacts/gap60_recovery/exact60_tile_crosscheck_v3.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
