"""Checked text boundary to prime-field FLINT polynomial trace routines."""
import ctypes
from pathlib import Path

_lib=ctypes.CDLL(str(Path(__file__).with_name('libprime_poly_trace.so')))
_lib.prime_log_norm_jet.argtypes=[ctypes.c_char_p]*6
_lib.prime_log_norm_jet.restype=ctypes.c_void_p
_lib.prime_log_norm_free.argtypes=[ctypes.c_void_p]
_lib.prime_log_norm_free.restype=None


def log_norm_jet(h,jet):
    def encode(f):
        cs=f.coeffs()
        return (str(len(cs))+'  '+' '.join(str(int(c)) for c in cs)).encode()
    p=str(h.modulus()).encode()
    ptr=_lib.prime_log_norm_jet(p,encode(h),*(encode(g) for g in jet))
    if not ptr:raise ValueError('Prime FLINT log-norm computation failed: modulus, parsing, or noninvertible polynomial')
    try:return tuple(int(v) for v in ctypes.string_at(ptr).decode().split())
    finally:_lib.prime_log_norm_free(ptr)
