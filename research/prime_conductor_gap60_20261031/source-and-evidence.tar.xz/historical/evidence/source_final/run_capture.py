#!/usr/bin/env python3
"""Capture a bounded synthetic computation, preserving all terminal outcomes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time
from datetime import datetime, timezone

p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True)
p.add_argument('--seconds',type=float,required=True);p.add_argument('--memory-gib',type=int,default=4)
p.add_argument('--cpu',type=int,default=1);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
cmd=a.command[1:] if a.command[:1]==['--'] else a.command
a.root.mkdir(parents=True,exist_ok=False)
def stamp():return datetime.now(timezone.utc).isoformat()
def save(row):
 tmp=a.root/'receipt.tmp';tmp.write_text(json.dumps(row,indent=2,sort_keys=True)+'\n');os.replace(tmp,a.root/'receipt.json')
row={'status':'running','command':cmd,'seconds_budget':a.seconds,'memory_gib':a.memory_gib,'cpu':a.cpu,'started_utc':stamp(),'source_files':{}}
for arg in cmd:
 if arg.endswith('.py') and Path(arg).is_file():
  data=Path(arg).read_bytes();row['source_files'][arg]=hashlib.sha256(data).hexdigest();(a.root/Path(arg).name).write_bytes(data)
save(row)
def setup():
 resource.setrlimit(resource.RLIMIT_AS,(a.memory_gib*1024**3,)*2);os.sched_setaffinity(0,{a.cpu})
start=time.perf_counter();peak=0
with (a.root/'stdout.log').open('w') as stdout,(a.root/'stderr.log').open('w') as stderr,(a.root/'samples.jsonl').open('w') as samples:
 proc=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,preexec_fn=setup,start_new_session=True)
 row['worker_pid']=proc.pid;save(row)
 while True:
  try:
   vals={ln.split(':',1)[0]:ln.split(':',1)[1].strip() for ln in Path(f'/proc/{proc.pid}/status').read_text().splitlines() if ':' in ln}
   rss=int(vals.get('VmRSS','0 kB').split()[0]);peak=max(peak,rss)
   samples.write(json.dumps({'elapsed_seconds':time.perf_counter()-start,'rss_kib':rss})+'\n');samples.flush()
  except FileNotFoundError:pass
  try:code=proc.wait(timeout=min(2,max(.01,a.seconds-(time.perf_counter()-start))));break
  except subprocess.TimeoutExpired:
   if time.perf_counter()-start>=a.seconds:
    os.killpg(proc.pid,signal.SIGKILL);proc.wait();code=124;break
row.update(status='finished',exit_status=code,elapsed_seconds=time.perf_counter()-start,peak_observed_rss_kib=peak,finished_utc=stamp());save(row)
raise SystemExit(code)
