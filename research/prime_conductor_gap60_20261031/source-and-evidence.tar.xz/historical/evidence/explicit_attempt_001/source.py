#!/usr/bin/env python3
"""Exact synthetic source certificate and resource-bounded explicit isogeny run."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone


def stamp():
    return datetime.now(timezone.utc).isoformat()


def save(path, row):
    tmp=path.with_suffix('.tmp')
    with tmp.open('w') as h:
        json.dump(row,h,indent=2,sort_keys=True);h.write('\n');h.flush();os.fsync(h.fileno())
    os.replace(tmp,path)


def worker(a):
    resource.setrlimit(resource.RLIMIT_AS,(a.memory_gib*1024**3,)*2)
    from sage.all import EllipticCurve,GF,ZZ,pari,set_random_seed
    import sage.version
    set_random_seed(20261031)
    d=json.loads(a.parameters.read_text())
    out=a.root/'worker_receipt.json'
    row={'status':'running','started_utc':stamp(),'phase':'certificate','phases':{},
         'sage_version':sage.version.version,'platform':platform.platform(),
         'affinity':sorted(os.sched_getaffinity(0)),'memory_limit_gib':a.memory_gib,
         'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'parameters_sha256':hashlib.sha256(a.parameters.read_bytes()).hexdigest()}
    def phase(name,fn):
        row['phase']=name;save(out,row);w=time.perf_counter();c=time.process_time()
        val=fn();row['phases'][name]={'wall_seconds':time.perf_counter()-w,
             'cpu_seconds':time.process_time()-c,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
        save(out,row);return val
    def pt(P):return None if P.is_zero() else [str(ZZ(P[0])),str(ZZ(P[1]))]
    try:
        p,q,ell,k,t,n=[ZZ(d[key]) for key in ['p','q','ell','k','trace','ambient_order']]
        def cert():
            assert p.is_prime(proof=True) and q.is_prime(proof=True) and ell.is_prime(proof=True)
            assert ell.nbits()>=60 and q.nbits()==41
            assert p==(1+k*ell)**2+7*ell**2 and q==(k*k+7)//8
            assert t==2+2*k*ell and n==p+1-t==8*q*ell**2
            assert t*t-4*p==-7*(2*ell)**2 and t.gcd(p)==1
            assert ZZ(-7).kronecker(ell)==-1
            factors=list(map(ZZ,d['pocklington_factors']));F=factors[0]*factors[1]
            assert F*F>p and (p-1)%F==0
            for r,b in zip(factors,map(ZZ,d['pocklington_witnesses'])):
                assert r.is_prime(proof=True) and pow(b,p-1,p)==1
                assert ZZ(pow(b,(p-1)//r,p)-1).gcd(p)==1
            E=EllipticCurve(GF(p),list(map(ZZ,d['source_coefficients'])))
            assert E.j_invariant()==E.base_field()(-3375)
            P=E(tuple(map(ZZ,d['trace_witness'])))
            assert n*P==E(0) and 2*t*P!=E(0)
            # CM discriminant -7 has class number one; the point witness
            # distinguishes the two possible CM traces without trusting set_order.
            assert E.trace_of_frobenius()==t
            E.set_order(n,num_checks=5)
            K=E(tuple(map(ZZ,d['kernel'])));G=E(tuple(map(ZZ,d['generator'])))
            assert K!=E(0) and ell*K==E(0) and G!=E(0) and q*G==E(0)
            K.set_order(ell);G.set_order(q)
            return E,K,G
        E,K,G=phase('certificate',cert)
        row.update(certificate_status='pass',prime_gap=str(ell),prime_gap_bits=int(ell.nbits()),
                   conductor_argument='Source CM order is maximal (-7); ell is inert, so no horizontal ell-isogeny exists; the rational ell-kernel quotient has conductor ell.')
        save(out,row)
        if a.action=='verify':
            row.update(status='certificate_verified',phase='done');save(out,row);return 0
        phi=phase('construct_quotient',lambda:E.isogeny(K,algorithm='velusqrt'))
        C=phi.codomain()
        assert phi.degree()==ell and phi.is_separable() and C.j_invariant()!=E.j_invariant()
        row.update(quotient_coefficients=[str(ZZ(c)) for c in C.a_invariants()],quotient_j=str(C.j_invariant()),quotient_conductor=str(ell))
        save(out,row)
        H=phase('evaluate_generator',lambda:phi(G))
        assert H!=C(0) and q*H==C(0);H.set_order(q)
        J=phase('evaluate_7G',lambda:phi(7*G))
        assert J==7*H
        row.update(generator_image=pt(H),seven_generator_image=pt(J),crossing_status='verified')
        save(out,row)
        # Fresh solver processes preserve individual timeout/failure boundaries.
        row['ecdlp_pairs']=[]
        for i in range(a.targets):
            secret=ZZ(1+int.from_bytes(hashlib.sha256(f'gap60-target-{i}'.encode()).digest(),'big')%(int(q)-1))
            pair={'target_id':i,'expected_scalar':str(secret),'endpoints':{}}
            for name,D,B in ([('top',E,G),('floor',C,H)] if i%2==0 else [('floor',C,H),('top',E,G)]):
                payload={'p':str(p),'q':str(q),'seed':20261031+i,'coefficients':[str(ZZ(c)) for c in D.a_invariants()],
                         'base':pt(B),'target':pt(secret*B)}
                job=a.root/f'log-{i}-{name}';save(job.with_suffix('.input.json'),payload)
                start=time.perf_counter()
                with job.with_suffix('.stdout').open('w') as stdout,job.with_suffix('.stderr').open('w') as stderr:
                    proc=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--log-worker'],stdin=subprocess.PIPE,
                         stdout=stdout,stderr=stderr,text=True,start_new_session=True)
                    try:proc.communicate(json.dumps(payload),timeout=180)
                    except subprocess.TimeoutExpired:
                        import signal
                        os.killpg(proc.pid,signal.SIGKILL);proc.wait()
                        raise TimeoutError(f'ECDLP {i}/{name} exceeded 180 seconds')
                assert proc.returncode==0, f'ECDLP worker exit {proc.returncode}'
                answer=json.loads(job.with_suffix('.stdout').read_text())
                assert ZZ(answer['answer'])==secret and ZZ(answer['answer'])*B==secret*B
                pair['endpoints'][name]=dict(answer,outer_wall_seconds=time.perf_counter()-start,correct=True)
            row['ecdlp_pairs'].append(pair);save(out,row)
        row.update(status='verified',phase='done',finished_utc=stamp(),
                   limitation='Synthetic 41-bit subgroup; one field and one kernel; no world record or speedup claim.')
    except BaseException as exc:
        row.update(status='exception',error=repr(exc),traceback=traceback.format_exc(),finished_utc=stamp())
    save(out,row)
    return 0 if row['status']=='verified' else 1


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path)
    ap.add_argument('--parameters',type=Path,default=Path('/workspace/gap60_parameters.json'))
    ap.add_argument('--worker',action='store_true');ap.add_argument('--log-worker',action='store_true')
    ap.add_argument('--action',choices=['verify','build'],default='build')
    ap.add_argument('--seconds',type=int,default=600);ap.add_argument('--memory-gib',type=int,default=8)
    ap.add_argument('--targets',type=int,default=24)
    a=ap.parse_args()
    if a.log_worker:
        from sage.all import pari,ZZ
        d=json.load(sys.stdin);p,q=ZZ(d['p']),ZZ(d['q'])
        start=time.perf_counter();pari.allocatemem(256*1024**2,silent=True)
        pari.setrand(d.get('seed',20261031))
        E=pari.ellinit(list(map(ZZ,d['coefficients'])),p)
        prep=time.perf_counter()-start;start=time.perf_counter()
        ans=E.elllog(list(map(ZZ,d['target'])),list(map(ZZ,d['base'])),q)
        print(json.dumps({'answer':str(ans),'solve_seconds':time.perf_counter()-start,'preprocessing_seconds':prep,
                          'seed':d.get('seed',20261031),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}))
        return 0
    if a.worker:return worker(a)
    if a.root is None:ap.error('--root required')
    a.root.mkdir(parents=True,exist_ok=False)
    source=a.root/'source.py';source.write_bytes(Path(__file__).read_bytes())
    params=a.root/'parameters.json';params.write_bytes(a.parameters.read_bytes())
    cmd=['/workspace/env/sage/bin/python','-u',str(source),'--worker','--root',str(a.root),
         '--parameters',str(params),'--action',a.action,'--memory-gib',str(a.memory_gib),'--targets',str(a.targets)]
    state={'status':'running','started_utc':stamp(),'command':cmd,'budget_seconds':a.seconds,
           'memory_limit_gib':a.memory_gib,'pid':os.getpid()}
    save(a.root/'execution.json',state);start=time.perf_counter()
    with (a.root/'stdout.log').open('w') as stdout,(a.root/'stderr.log').open('w') as stderr:
        proc=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True)
        state['worker_pid']=proc.pid;save(a.root/'execution.json',state)
        peak=0
        with (a.root/'resource_samples.jsonl').open('w') as samples:
            while True:
                try:
                    values={line.split(':',1)[0]:line.split(':',1)[1].strip()
                            for line in Path(f'/proc/{proc.pid}/status').read_text().splitlines() if ':' in line}
                    rss=int(values.get('VmRSS','0 kB').split()[0]);peak=max(peak,rss)
                    samples.write(json.dumps({'elapsed_seconds':time.perf_counter()-start,'rss_kib':rss,'utc':stamp()})+'\n');samples.flush()
                except FileNotFoundError:pass
                try:code=proc.wait(timeout=min(5,max(.01,a.seconds-(time.perf_counter()-start))));break
                except subprocess.TimeoutExpired:
                    if time.perf_counter()-start>=a.seconds:
                        import signal
                        os.killpg(proc.pid,signal.SIGKILL);proc.wait();code=124;break
        state['observed_peak_worker_rss_kib']=peak
    state.update(status='finished',exit_status=code,outer_wall_seconds=time.perf_counter()-start,finished_utc=stamp())
    save(a.root/'execution.json',state)
    return code


if __name__=='__main__':sys.exit(main())
