#!/bin/sh
set -eu
GAP60_SAGE_PREFIX=${GAP60_SAGE_PREFIX:-/workspace/env/sage}
gcc -shared -O3 -fPIC -std=c11 \
    -I"$GAP60_SAGE_PREFIX/include" /workspace/prime_poly_trace.c \
    -L"$GAP60_SAGE_PREFIX/lib" -Wl,-rpath,"$GAP60_SAGE_PREFIX/lib" \
    -lflint -lgmp -o /workspace/libprime_poly_trace.so
