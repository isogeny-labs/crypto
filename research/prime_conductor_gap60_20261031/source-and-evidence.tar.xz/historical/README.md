# Experiments on a 60-bit prime conductor gap

This repository contains exact synthetic parameters, construction attempts, and
bounded-memory Vélu prototypes for ordinary elliptic curves over a finite field.

**The full 60-bit crossing has not been computed.** The source and rational
kernel are verified. An explicit quotient equation, complete non-kernel point
images, and matched endpoint ECDLP measurements remain outstanding. No world
record or end-to-end speedup is claimed.

The conductor here is the conductor of a finite-field endomorphism order,
not the arithmetic conductor of an elliptic curve over a number field.

## Parameters

The prime gap is `576460755499654231` (60 bits). Let `k = 3000031` and
`p = (1 + k*ell)^2 + 7*ell^2`, a proven 162-bit prime. The source curve is
`y^2 = x^3 - 140*x - 784` over `F_p`, with endomorphism conductor 1.
The certified rational kernel has prime order `ell`. Since `ell` is inert in
`Q(sqrt(-7))`, its quotient has endomorphism conductor `ell`.
The source also has a subgroup of prime order `1125023250121` (41 bits).

See [the exact parameters](gap60_parameters.json) and
[the Sage certificate](evidence/sage_certificate/worker_receipt.json).

## Observed results

| Experiment | Outcome |
| --- | --- |
| Independent Sage replay of field, source, kernel and conductor argument | Passed |
| Standard Sage square-root Vélu construction | MemoryError after 443 seconds, with an 8 GiB address-space limit |
| Standard implementation's coordinate-list lower bound | 22.6 GiB, excluding polynomial trees and other data; host memory was 16 GiB |
| Bounded-block implementation, complete small examples | Exact quotient and point-image agreement with traditional Vélu |
| Actual 60-bit kernel, small-tile direct-root crosscheck | Passed across three backends |
| Actual 60-bit kernel, 131072-by-131072 partial tile | Completed in 179 seconds, about 1.03 GiB observed peak RSS |
| Full 60-bit quotient and non-kernel images | Not computed |
| Matched endpoint ECDLP experiment | Not attempted; destination curve unavailable |

A partial tile contributes polynomial sums. It is not a completed isogeny
evaluation. Some diagnostics overlapped other work; these are not controlled
backend speedup measurements. Small correctness fixtures do not establish
end-to-end feasibility at 60 bits.

[Machine-readable results](evidence/results.json) link the evidence and limits.
[The evidence archive](gap60_recovery_evidence.zip) preserves code snapshots,
failed attempts, stdout/stderr, resource samples, and manifests. The older
workspace's data was unavailable after environment replacement; it is not
included here.

## Alternative-route assessment

[The route assessment](research/route_assessment.json) records a follow-up review
of higher-dimensional representations, Kani reconstruction, and Frobenius-based
evaluation. Their prerequisites matter: the inspected efficient-representation
conversion requires initial isogeny images; the inspected Kani reconstruction
algorithm takes both endpoints; and the current kernel is already rational, so
its Frobenius extension-orbit length is one. These checks do not rule out future
algorithms or a newly certified parameter family. No new full crossing was
computed in this review.

## Reproduction

The recorded scripts use absolute `/workspace` paths. To reproduce them without
changing the source, place this checkout at `/workspace`, with a Sage 10.9 Python
environment at `/workspace/env/sage`. Use the exact Conda package list in
`evidence/sage_environment_explicit.txt`, plus `python-flint==0.9.0`.

Set writable runtime directories and limit background library threading:

```sh
export DOT_SAGE=/workspace/sage-user
export XDG_CACHE_HOME=/workspace/cache
export MPLCONFIGDIR=/workspace/cache/matplotlib
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
```

Compile the prime-field helper and run correctness checks:

```sh
sh /workspace/build_prime_poly.sh
/workspace/env/sage/bin/python /workspace/blocked_velu.py --selftest --output /workspace/selftest.json
/workspace/env/sage/bin/python /workspace/verify_gap60_blocks.py
```

The direct-root verification script writes its result under
`/workspace/artifacts/gap60_recovery`; create that directory first when using a
fresh checkout. All run directories must be new, so failed evidence is preserved.

Replay the source certificate:

```sh
python3 /workspace/run_gap60.py --root /workspace/replay-certificate --action verify --seconds 180
```

The following command reproduces a **resource-bounded attempt**, not a promise
that the quotient construction will finish:

```sh
python3 /workspace/run_gap60.py --root /workspace/replay-build --action build --seconds 600 --memory-gib 8 --targets 24
```

The ECDLP stage runs only if construction and complete point-map checks succeed.
The recorded direct attempt failed before that stage. The 41-bit subgroup is
synthetic and is not a cryptographic-size hardness experiment.

## Method and provenance

The block prototype uses the I/J/K indexing and elliptic biquadratic identity
from Sage's square-root Vélu implementation, accumulating log-norm jets through
polynomial traces. The compiled helper calls prime-field FLINT operations through
a text boundary rather than relying on Python-FLINT's private object ABI.

The executable CM/volcano argument and arithmetic checks are not proof-assistant
certification. The standard implementation's memory bound does not prove that
all algorithms for this problem require that memory.

See [NOTICE](NOTICE) and the retained source snapshots for provenance and license
information.
