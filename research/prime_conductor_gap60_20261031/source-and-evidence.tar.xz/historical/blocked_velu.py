# SPDX-License-Identifier: GPL-2.0-or-later
"""Bounded-memory prototype for normalized Velu maps via polynomial traces.

The I,J,K index system and biquadratic identity follow Sage 10.9's
hom_velusqrt.py (https://github.com/sagemath/sage/blob/10.9/src/sage/schemes/elliptic_curves/hom_velusqrt.py).
This implementation sums log jets over bounded I/J tiles instead of retaining
a global product tree. A tile receipt is NOT a completed isogeny evaluation.
"""
import argparse
import json
from pathlib import Path
import resource
import time
from sage.all import EllipticCurve, GF, ZZ, set_random_seed
from sage.schemes.elliptic_curves.hom_velusqrt import _choose_IJK, _points_range


def product_stream(items, multiply, identity):
    bins=[]
    for val in items:
        level=0
        while level<len(bins) and bins[level] is not None:
            val=multiply(bins[level],val);bins[level]=None;level+=1
        if level==len(bins):bins.append(val)
        else:bins[level]=val
    result=identity
    for val in reversed(bins):
        if val is not None:result=multiply(result,val)
    return result


def jet_multiply(a,b):
    return tuple(sum(a[j]*b[i-j] for j in range(i+1)) for i in range(4))


def log_norm_jet(h,jet):
    """Coefficients of T,T^2,T^3 in log Norm(jet(T)), exactly in Fp."""
    g0,g1,g2,g3=jet
    gi=g0.inverse_mod(h)
    u=(g1*gi)%h;v=(g2*gi)%h;w=(g3*gi)%h
    dh=h.derivative();n=h.degree()
    def tr(f):return ((f*dh)%h)[n-1]
    # For monic separable h, Tr(f mod h) is the Z^(n-1) coefficient
    # of f*h' mod h. Coefficients are log(1+uT+vT^2+wT^3).
    return (tr(u),tr((v-u*u/2)%h),tr((w-u*v+u*u*u/3)%h))


def tile(E,K,ir,jr,alphas,backend='sage'):
    """Return log-jet sums for one rectangle; None denotes infinity jets."""
    F=E.base_field()
    if backend in ('flint','prime'):
        from flint import fmpz_mod_poly_ctx
        R=fmpz_mod_poly_ctx(int(F.cardinality()));cast=int
        alphas=[None if x is None else int(x) for x in alphas]
    else:R=F['Z'];cast=F
    Z=R.gen();zero=R.zero();one=R.one()
    h=product_stream((Z-cast(P[0]) for P in _points_range(ir,K)),lambda a,b:a*b,one)
    a,b=map(cast,E.a_invariants()[-2:])
    bins=[[] for _ in alphas]
    def ingest(bins,val):
        level=0
        while level<len(bins) and bins[level] is not None:
            val=jet_multiply(bins[level],val);bins[level]=None;level+=1
        if level==len(bins):bins.append(val)
        else:bins[level]=val
    for P in _points_range(jr,K):
        x=cast(P[0])
        f0=(Z-x)**2
        f1=-2*(Z*x+a)*(Z+x)-4*b
        f2=(Z*x-a)**2-4*b*(Z+x)
        for alpha,stack in zip(alphas,bins):
            jet=(f0,f1,f2,zero) if alpha is None else (
                f0*alpha**2+f1*alpha+f2,2*alpha*f0+f1,f0,zero)
            ingest(stack,jet)
    answer=[]
    for stack in bins:
        jet=(one,zero,zero,zero)
        for val in reversed(stack):
            if val is not None:jet=jet_multiply(jet,val)
        if backend=='prime':
            from prime_poly_trace import log_norm_jet as prime_log_norm_jet
            values=prime_log_norm_jet(h,jet)
        else:values=log_norm_jet(h,jet)
        answer.append(tuple(F(int(v)) for v in values))
    return answer


def pieces(rr,size):
    for pos in range(0,len(rr),size):yield rr[pos:pos+size]


def full_map(E,K,points,block=16,backend='sage'):
    """Complete prototype; intended for bounded correctness fixtures."""
    ell=ZZ(K.order());I,J,L=_choose_IJK(ell);F=E.base_field()
    alphas=[None]+[P[0] for P in points]
    sums=[[F(0),F(0),F(0)] for _ in alphas]
    for ir in pieces(I,block):
        for jr in pieces(J,block):
            vals=tile(E,K,ir,jr,alphas,backend)
            for total,values in zip(sums,vals):
                for i in range(3):total[i]+=values[i]
    s1,s2,s3=-sums[0][0],-2*sums[0][1],-3*sums[0][2]
    for P in _points_range(L,K):
        x=P[0];s1+=x;s2+=x*x;s3+=x*x*x
        for alpha,total in zip(alphas[1:],sums[1:]):
            r=1/(alpha-x)
            total[0]+=r;total[1]-=r*r/2;total[2]+=r*r*r/3
    a,b=E.a_invariants()[-2:];m=(ell-1)//2
    C=EllipticCurve(F,[a-5*(6*s2+2*m*a),b-7*(10*s3+6*a*s1+4*m*b)])
    outputs=[]
    for P,(d1,d2,d3) in zip(points,sums[1:]):
        x,y=P[0],P[1];fx=x**3+a*x+b;df=3*x*x+a
        u=ell*x-2*s1-2*df*d1-8*fx*d2
        v=y*(ell-12*x*d1-12*df*d2-24*fx*d3)
        outputs.append(C((u,v)))
    return C,outputs


def selftest():
    set_random_seed(20261031);rows=[]
    for p,coeff,xy,block in [(71,[5,5],[4,35],2),(6666679,[5,5],[9970,1003793],17)]:
        E=EllipticCurve(GF(p),coeff);K=E(xy);ell=K.order()
        points=[]
        for _ in range(6):
            while True:
                P=E.random_point()
                if not P.is_zero() and not (ell*P).is_zero():break
            points.append(P)
        phi=E.isogeny(K,algorithm='traditional')
        for backend in ['sage','flint','prime']:
            before=time.perf_counter();C,images=full_map(E,K,points,block,backend)
            assert C==phi.codomain()
            assert images==[phi(P) for P in points]
            rows.append({'p':p,'degree':str(ell),'points':len(points),'block':block,'backend':backend,
                         'wall_seconds':time.perf_counter()-before,'exact_match_to_traditional_velu':True})
    return {'status':'pass','fixtures':rows,'scope':'Complete small-fixture coefficient and non-kernel point agreement; no 60-bit map claim.'}


def probe(parameters,block,backend='sage'):
    d=json.loads(Path(parameters).read_text());p,ell=ZZ(d['p']),ZZ(d['ell'])
    E=EllipticCurve(GF(p),list(map(ZZ,d['source_coefficients'])))
    K=E(tuple(map(ZZ,d['kernel'])));assert K!=E(0) and ell*K==E(0);K.set_order(ell)
    G=E(tuple(map(ZZ,d['generator'])));I,J,L=_choose_IJK(ell)
    start=time.perf_counter();values=tile(E,K,I[:block],J[:block],[None,G[0],(7*G)[0]],backend)
    elapsed=time.perf_counter()-start
    return {'status':'partial_tile_only','degree':str(ell),'block_size':block,'backend':backend,
            'I_size':len(I),'J_size':len(J),'leftover_size':len(L),
            'rectangular_tiles_at_this_block_size':((len(I)+block-1)//block)*((len(J)+block-1)//block),
            'wall_seconds':elapsed,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            'partial_log_jets':[[str(v) for v in row] for row in values],
            'scope':'One actual tile at the exact 60-bit kernel. Full quotient and map not computed. Not an end-to-end runtime estimate.'}


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--selftest',action='store_true')
    ap.add_argument('--parameters',default='/workspace/gap60_parameters.json');ap.add_argument('--block',type=int,default=4096)
    ap.add_argument('--backend',choices=['sage','flint','prime'],default='sage')
    ap.add_argument('--output',required=True);a=ap.parse_args()
    result=selftest() if a.selftest else probe(a.parameters,a.block,a.backend)
    Path(a.output).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
