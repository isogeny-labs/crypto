set -euo pipefail
VALIDATION_DIR="${VALIDATION_DIR:-$RUNNER_TEMP/native-library-validation}"
mkdir -p "$VALIDATION_DIR"
parent_payload=null
parent_receipt_present=false
if test -f "$VALIDATION_DIR/parent-exit.json"; then
  parent_payload=$(cat "$VALIDATION_DIR/parent-exit.json")
  parent_receipt_present=true
fi
jq -n --arg source "$SOURCE_REVISION" --arg outcome "$LIBRARY_STEP_OUTCOME" \
  --argjson parent "$parent_payload" --argjson present "$parent_receipt_present" \
  'if $present and $parent.source_revision != $source then
     error("parent receipt source does not match the requested source")
   else
     {schema:"crypto.native-library-completion/v1",source_revision:$source,
      test_step_outcome:$outcome,parent_exit_receipt_present:$present,
      cargo_parent_exit_code:($parent.cargo_parent_exit_code // null),
      log_writer_exit_code:($parent.log_writer_exit_code // null),
      parent_summary_requires_separate_verification:true,
      scientific_measurement:false}
   end' > "$VALIDATION_DIR/completion.json"
if test -d .git; then
  git status --porcelain --untracked-files=no > "$VALIDATION_DIR/post-run-status.txt"
fi
if test -f "$VALIDATION_DIR/source.sha256"; then
  sha256sum -c "$VALIDATION_DIR/source.sha256" > "$VALIDATION_DIR/post-run-source-check.txt"
fi
if test -f "$VALIDATION_DIR/library.log"; then
  sha256sum "$VALIDATION_DIR/library.log" > "$VALIDATION_DIR/library-log.sha256"
fi
