"""Independent document-retention check; reads Git and working-tree text."""
import collections
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path('/workspace/crypto-point-leads')
OUT = Path(__file__).resolve().parent
REFS = ['3b9dc1ce556199c00f21439c15e2b235417c6f1e', '730e036d50adc86c77d0a826564aa828bae02deb']


def parts(raw):
    clean = re.sub(rb'(?m)^(?:<<<<<<< .*|=======|>>>>>>> .*|\|\|\|\|\|\|\| .*)\r?\n?', b'', raw)
    return [p.strip(b'\r\n') for p in re.split(rb'(?m)(?=^#{1,2} [^#])', clean) if p.strip(b'\r\n')]


def main():
    records = []
    for date, extras in [('2026-11-15', 0), ('2026-11-16', 1)]:
        path = 'docs/session-logs/' + date + '.md'
        raw = (ROOT / path).read_bytes()
        actual = parts(raw)
        counts = collections.Counter(actual)
        required = collections.Counter()
        source_records = []
        for ref in REFS:
            source = subprocess.check_output(['git', '-C', str(ROOT), 'show', ref + ':' + path])
            blocks = parts(source)
            required |= collections.Counter(blocks)
            missing = collections.Counter(blocks) - counts
            assert not missing, (ref, path, 'missing full body/multiplicity')
            iterator = iter(actual)
            assert all(any(block == candidate for candidate in iterator) for block in blocks), (ref, path, 'parent order')
            source_records.append({'ref': ref, 'sha256': hashlib.sha256(source).hexdigest(),
                                   'blocks': len(blocks), 'missing_instances': 0, 'order_retained': True})
        assert sum((counts - required).values()) == extras
        assert not re.search(rb'(?m)^(?:<<<<<<< |=======|>>>>>>> |\|\|\|\|\|\|\| )', raw)
        records.append({'path': path, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw),
                        'blocks': len(actual), 'new_handoff_blocks': extras, 'parents': source_records,
                        'full_bodies_exact_parent_max_multiplicities_and_orders_retained': True})
    (OUT / 'final-journal-audit.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(records, indent=2))


if __name__ == '__main__':
    main()
