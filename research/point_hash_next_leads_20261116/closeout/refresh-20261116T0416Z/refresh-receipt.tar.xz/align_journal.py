"""Exact alignment of full document blocks; no cryptographic computation."""
import argparse
import collections
import datetime
import hashlib
import json
import re
import subprocess
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blocks(raw):
    clean = re.sub(rb'(?m)^(?:<<<<<<< .*|=======|>>>>>>> .*|\|\|\|\|\|\|\| .*)\r?\n?', b'', raw)
    return [p.strip(b'\r\n') for p in re.split(rb'(?m)(?=^#{1,2} [^#])', clean) if p.strip(b'\r\n')]


def is_subsequence(source, result):
    iterator = iter(result)
    return all(any(part == candidate for candidate in iterator) for part in source)


def align(repo, path, refs, output, receipt):
    sources = []
    sequences = []
    for ref in refs:
        raw = subprocess.check_output(['git', '-C', str(repo), 'show', ref + ':' + path])
        parts = blocks(raw)
        sequences.append(parts)
        sources.append({'ref': ref, 'path': path,
                        'blob': subprocess.check_output(['git', '-C', str(repo), 'rev-parse', ref + ':' + path], text=True).strip(),
                        'raw_sha256': sha(raw), 'raw_bytes': len(raw), 'blocks': len(parts)})
    a, b = sequences
    table = [[0] * (len(b) + 1) for _ in range(len(a) + 1)]
    for i, left in enumerate(a, 1):
        for j, right in enumerate(b, 1):
            table[i][j] = table[i-1][j-1] + 1 if left == right else max(table[i-1][j], table[i][j-1])
    required = collections.Counter(a) | collections.Counter(b)
    bound = sum((collections.Counter(a) & collections.Counter(b)).values())
    if table[-1][-1] != bound:
        raise RuntimeError('No alignment attains the multiset intersection bound; refuse to reorder/drop/inflate occurrences')
    i, j = len(a), len(b)
    matched = []
    while i and j:
        if a[i-1] == b[j-1]:
            matched.append((i-1, j-1))
            i -= 1
            j -= 1
        elif table[i-1][j] >= table[i][j-1]:
            i -= 1
        else:
            j -= 1
    matched.reverse()
    result = []
    left_start = right_start = 0
    for left, right in matched:
        result.extend(a[left_start:left])
        result.extend(b[right_start:right])
        result.append(a[left])
        left_start, right_start = left + 1, right + 1
    result.extend(a[left_start:])
    result.extend(b[right_start:])
    assert collections.Counter(result) == required
    assert all(is_subsequence(source, result) for source in sequences)
    raw = b'\n\n'.join(result) + b'\n'
    assert blocks(raw) == result
    assert not re.search(rb'(?m)^(?:<<<<<<< |=======|>>>>>>> |\|\|\|\|\|\|\| )', raw)
    Path(output).write_bytes(raw)
    record = {'schema': 'point-hash-journal-alignment/v1',
              'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'standing': 'producer document provenance, not scientific standing',
              'method': 'Exact LCS over complete byte-equal normalized H1/H2 blocks; shared occurrences chosen by sequence context rather than ordinal label alone.',
              'normalization': 'Only conflict-marker lines and outer block newlines; every other block byte retained.',
              'sources': sources, 'multiset_intersection_bound': bound,
              'exact_lcs': table[-1][-1], 'matched_source_positions': matched,
              'result_blocks': len(result), 'result_bytes': len(raw), 'result_sha256': sha(raw),
              'complete_bodies_exact_max_multiplicities_and_both_orders_retained': True}
    Path(receipt).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({k: record[k] for k in ('exact_lcs', 'multiset_intersection_bound', 'result_blocks', 'result_bytes', 'complete_bodies_exact_max_multiplicities_and_both_orders_retained')}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True)
    parser.add_argument('--path', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--receipt', required=True)
    parser.add_argument('refs', nargs=2)
    args = parser.parse_args()
    align(args.repo, args.path, args.refs, args.output, args.receipt)
