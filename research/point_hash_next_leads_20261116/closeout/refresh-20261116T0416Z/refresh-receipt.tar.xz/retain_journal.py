"""Retain complete document blocks and occurrence counts; metadata only."""
import argparse
import collections
import datetime
import hashlib
import heapq
import json
import re
import subprocess
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def normalize_blocks(raw):
    text = raw.decode('utf-8')
    text = re.sub(r'(?m)^(?:<<<<<<< .*|=======|>>>>>>> .*|\|\|\|\|\|\|\| .*)\r?\n?', '', text)
    return [b.strip('\r\n') for b in re.split(r'(?m)(?=^#{1,2} [^#])', text) if b.strip('\r\n')]


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def retain(repo, path, refs, dest, receipt):
    texts = {}
    edges = collections.defaultdict(set)
    incoming = collections.Counter()
    ranks = {}
    sources = []
    nodes = set()
    required = collections.Counter()
    for source_index, ref in enumerate(refs):
        raw = git(repo, 'show', ref + ':' + path)
        parts = normalize_blocks(raw)
        counts = collections.Counter()
        sequence = []
        for position, part in enumerate(parts):
            sha = digest(part.encode())
            counts[sha] += 1
            node = (sha, counts[sha])
            if sha in texts and texts[sha] != part:
                raise RuntimeError('block digest collision')
            texts[sha] = part
            nodes.add(node)
            sequence.append(node)
            ranks.setdefault(node, (source_index, position))
        required |= counts
        for left, right in zip(sequence, sequence[1:]):
            if right not in edges[left]:
                edges[left].add(right)
                incoming[right] += 1
        sources.append({'ref': ref, 'path': path,
                        'blob': git(repo, 'rev-parse', ref + ':' + path).decode().strip(),
                        'raw_sha256': digest(raw), 'raw_bytes': len(raw),
                        'blocks': len(parts), 'sequence': sequence})

    def priority(node):
        heading = texts[node[0]].splitlines()[0]
        match = re.search(r'(?<!\d)([0-2]?\d):([0-5]\d)(?!\d)', heading)
        minutes = int(match[1]) * 60 + int(match[2]) if match else -1
        return (minutes, *ranks[node], node)

    ready = [priority(n) for n in nodes if incoming[n] == 0]
    heapq.heapify(ready)
    ordered = []
    while ready:
        node = heapq.heappop(ready)[-1]
        ordered.append(node)
        for child in edges[node]:
            incoming[child] -= 1
            if incoming[child] == 0:
                heapq.heappush(ready, priority(child))
    if len(ordered) != len(nodes):
        unresolved = [texts[n[0]].splitlines()[0] for n in nodes if incoming[n] > 0]
        raise RuntimeError('incompatible source block orders; refuse to select/reorder: ' + repr(unresolved[:12]))
    positions = {node: i for i, node in enumerate(ordered)}
    for source in sources:
        indexes = [positions[node] for node in source.pop('sequence')]
        source['complete_order_retained'] = all(a < b for a, b in zip(indexes, indexes[1:]))
        assert source['complete_order_retained']
    result = '\n\n'.join(texts[n[0]] for n in ordered) + '\n'
    actual = collections.Counter(digest(b.encode()) for b in normalize_blocks(result.encode()))
    assert actual == required, 'full block/multiplicity mismatch'
    assert not re.search(r'(?m)^(?:<<<<<<< |=======|>>>>>>> |\|\|\|\|\|\|\| )', result)
    Path(dest).write_bytes(result.encode())
    record = {'schema': 'point-hash-journal-retention/v1',
              'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope': 'producer document provenance, not scientific evidence',
              'normalization': 'Only conflict-marker lines and outer H1/H2 block newlines; all other block bytes retained.',
              'ordering': 'Stable topological union of complete occurrence sequences; timestamp preference only between independent ready blocks.',
              'sources': sources, 'result_blocks': len(ordered), 'result_bytes': len(result.encode()),
              'result_sha256': digest(result.encode()), 'complete_bodies_multiplicities_orders_retained': True}
    Path(receipt).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', required=True)
    p.add_argument('--path', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--receipt', required=True)
    p.add_argument('refs', nargs='+')
    a = p.parse_args()
    retain(a.repo, a.path, a.refs, a.output, a.receipt)
