"""Document/Git provenance audit only; no solver or scientific computation."""
import collections
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path('/workspace/crypto-point-leads')
OUT = Path(__file__).resolve().parent
UPLOADED = 'd3c38247a2a4fab01116f51279207a3111614894'
HEAD = '403f5770600a6ade4adb5e984d8213670831632e'
MAIN_PARENT = '33d7a50f0597596c47828b68ad8b3fe2adbd8123'
MERGE = '69674b9276a1c1a35c00550f0d264f80b80ab118'
STUDY = 'research/point_hash_next_leads_20261116'
JOURNAL = 'docs/session-logs/2026-11-16.md'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def oid(ref, path):
    return git('rev-parse', ref + ':' + path).decode().strip()


def blocks(data):
    text = data.decode()
    text = re.sub(r'(?m)^(?:<<<<<<< .*|=======|>>>>>>> .*|\|\|\|\|\|\|\| .*)\n?', '', text)
    return [b.strip('\n') for b in re.split(r'(?m)(?=^## [^#])', text) if b.strip('\n')]


def subsequence(wanted, actual):
    current = iter(actual)
    return all(any(item == candidate for candidate in current) for item in wanted)


def main():
    parents = git('show', '-s', '--format=%P', MERGE).decode().split()
    assert parents == [MAIN_PARENT, HEAD], parents
    refresh_parents = git('show', '-s', '--format=%P', HEAD).decode().split()
    assert refresh_parents == [UPLOADED, MAIN_PARENT], refresh_parents
    merge_tree = git('rev-parse', MERGE + '^{tree}').decode().strip()
    assert merge_tree == git('rev-parse', HEAD + '^{tree}').decode().strip()
    main = git('rev-parse', 'origin/main').decode().strip()
    subprocess.run(['git', '-C', str(ROOT), 'merge-base', '--is-ancestor', MERGE, main], check=True)
    trees = {ref: oid(ref, STUDY) for ref in (UPLOADED, HEAD, MERGE, main)}
    assert len(set(trees.values())) == 1, trees
    changed = git('diff', '--name-only', MAIN_PARENT, HEAD).decode().splitlines()
    assert all(p.startswith((STUDY + '/', 'docs/lessons/entries/')) or p == JOURNAL for p in changed)
    assert len(changed) == 17, changed
    actual = git('show', MERGE + ':' + JOURNAL)
    results = {}
    for ref in (UPLOADED, MAIN_PARENT, HEAD, MERGE):
        data = git('show', ref + ':' + JOURNAL)
        (OUT / ('journal-' + ref[:12] + '.md')).write_bytes(data)
        source_blocks = blocks(data)
        actual_blocks = blocks(actual)
        missing = collections.Counter(source_blocks) - collections.Counter(actual_blocks)
        results[ref] = {
            'blob': oid(ref, JOURNAL),
            'sha256': hashlib.sha256(data).hexdigest(),
            'blocks': len(source_blocks),
            'missing_block_instances': sum(missing.values()),
            'missing_block_sha256': [hashlib.sha256(b.encode()).hexdigest() for b in missing.elements()],
            'complete_block_order_retained': subsequence(source_blocks, actual_blocks),
        }
    checks = json.loads((OUT / 'head-check-runs.json').read_text())
    summary = collections.Counter(c['conclusion'] for c in checks['check_runs'])
    result = {
        'scope': 'producer Git/API/document verification, no scientific standing',
        'merge_commit': MERGE, 'merge_parents': parents, 'merge_tree': merge_tree,
        'final_head': HEAD, 'refresh_parents': refresh_parents,
        'observed_main': main, 'main_reachable': True,
        'study_trees': trees, 'changed_paths_against_merge_base': changed,
        'journals': results, 'check_summary': dict(summary),
        'failed_checks': [{k: c[k] for k in ('id', 'name', 'started_at', 'completed_at', 'details_url')}
                          for c in checks['check_runs'] if c['conclusion'] == 'failure'],
        'ci_green_at_merge': False,
        'ci_note': 'Actual merge preceded completion of several final-head checks; later artifacts and validation-gate failures remain failures.',
    }
    (OUT / 'terminal-verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'merge': MERGE, 'tree': merge_tree, 'main': main, 'study_tree': next(iter(trees.values())),
                      'journals': results, 'checks': dict(summary)}, indent=2))


if __name__ == '__main__':
    main()
