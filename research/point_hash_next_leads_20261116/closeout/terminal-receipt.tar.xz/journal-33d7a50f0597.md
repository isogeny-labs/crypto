




# Session log — 2026-11-16

## OpenResearch integration — source review and scope

### What was done (commands, files, features)

- Read repository instructions, the newest session log, `docs/CONDUCTOR.md`,
  the shared lab contract and OpenResearch's official README, CLI skill,
  skill installer and v0.2.27 release metadata.
- Sources checked (KB): KB unavailable; no MCP tools loaded and
  `scripts/research-kb status` reports no executable. Used the primary
  repository files and https://github.com/alphaXiv/OpenResearch instead.
- The supplied research-vault credential was used only outside the repositories.

### Decisions made (and why)

- Add `scripts/openresearch.sh`, its focused shell checks,
  `docs/openresearch.md`, and an `orx` skill on both existing agent surfaces.
  Keep one canonical skill body and one relative symlink.
- This is a tooling integration, with no scientific run, benchmark or claim.
  Existing repository authority, compute, custody and publication rules apply.
- `conductor check` could not run because Conductor is not installed; the
  documented unconfigured-environment fallback applies. No shared ownership
  or control-plane reservation is asserted.

### Open threads (unfinished, pick up next time)

- Implement, run shell and CLI checks, commit and open a regular pull request.
- Check hosted gates before merge; Rust and cryptographic sources are outside scope.

### Errors (what went wrong, how it was handled)

- Initial sparse setup needed `git read-tree -mu HEAD` to populate the empty
  index. `sparse-checkout add` uses the existing non-cone configuration rather
  than accepting a `--no-cone` flag.
- Disabled recursive submodule fetching locally after an unrelated submodule
  fetch error; the main ref fetched successfully and was fast-forwarded.

## OpenResearch integration — implementation and local checks

### What was done (commands, files, features)

- Added the pinned v0.2.27 installer wrapper, local guide, README link,
  focused shell checks and a single canonical `orx` skill with a directory
  symlink on the other agent surface. [pcc:unverified]
- `bash scripts/test-openresearch.sh` returned exit 0, covering argument
  boundaries and working directory, telemetry-off setup, an incompatible CLI,
  and rejection of a modified installer without executing it. [pcc:unverified]
- A fresh installation through the versioned official installer and pinned
  digest returned exit 0 in a separate scratch prefix; the installed CLI's
  doctor and the local dashboard health endpoint returned normally.
  These are producer checks, not independently signed execution evidence.
  [pcc:unverified]

### Decisions made (and why)

- Keep application and cryptographic sources, run commands, lab contracts,
  compute settings and scientific ledgers outside the change. Run focused
  shell integration checks; no research, benchmark, Sage or Rust workload
  was launched.
- Preserve encrypted Git storage in crypto-autoresearcher via its required
  vault filter; no key or plaintext research export is part of this change.
- Empty Otto and Autoresearcher remotes receive an initial README commit so
  the integration can be reviewed in a normal pull request.

### Open threads (unfinished, pick up next time)

- Commit the integration, open regular PRs, and inspect applicable hosted gates.
- Credential rotation is separate from this tooling integration; no vault
  history rewrite or key rotation was attempted.

### Errors (what went wrong, how it was handled)

- The lab parity checker recognizes skill-directory symlinks, so the runtime
  adapter links the directory rather than duplicating the skill body.

- Local dashboard registration now includes all five checkouts, with GitHub sync disabled and no run command configured. Its Codex harness reports installed, authenticated and ready. These are local producer observations. [pcc:unverified]

## OpenResearch integration — published for hosted gates

### What was done (commands, files, features)

- Committed and pushed the integration and opened regular PR
  https://github.com/isogeny-labs/crypto/pull/4370. Auto-merge was requested
  through the normal merge flow. [pcc:unverified]
- All five local repository skills resolve to one canonical body per
  repository. The installed version is v0.2.27; Codex is available in the
  dashboard. Focused checks returned exit 0. [pcc:unverified]

### Decisions made (and why)

- Leave hosted validation and review in force; do not treat local self-checks
  as an independent scientific or execution certificate.
- Keep this change scoped to the OpenResearch tooling and its handoff.

### Open threads (unfinished, pick up next time)

- Hosted gates and any review feedback on the PR; merge only through the
  repository's ordinary required-check and review rules.

### Errors (what went wrong, how it was handled)

- The crypto-autoresearcher broad benchrec gate reports historical payload
  and manifest paths absent from the sparse checkout (429 diagnostics across
  21 records after loading metadata). Its tool, config, record and progress
  paths are unchanged from origin/main. No historical record was repaired,
  regenerated or bypassed for this unrelated integration. [pcc:unverified]

# Session log 2026-11-16

## 2026-11-16 — ECC2K-130 follow-ups F1–F3 in parallel (start, Claude)

### What was done
- PR isogeny-labs/crypto#4112 (seven-lane sweep) merged 2026-11-14 10:09Z. Branch
  `claude/ecc-discrete-log-open-3n28i1` restarted from origin/main.
- User: run the sweep's three follow-ups in parallel:
  - F1: cold SAT solve with warm heuristic state;
  - F2: GF(2^n) w_cal instrument;
  - F3: complete m=83 counted IC row against matched rho.
- `research/ecc2k130_followups_20261116/COMMON.md` written; three lanes dispatched.

### Decisions made
- F2 is a timing calibration, so it gets core 3 exclusively and F1 and F3 run on cores 0–2.
  F2's local numbers are provisional.
- F3: the latest log (2026-11-15) says paid EKS is blocked on fresh live budget, and this
  container has no AWS CLI. F3 prepares and smoke-tests a frozen launch, and dispatches only
  if a live budget is recorded.

### Open threads
- Collect F1–F3; README, figure, PDF; PR.

### Errors
- None yet.


# Session log — 2026-11-16 UTC

## 2026-11-16T00:55Z — target-dependent prime31 S4/S3-chain Rust pilot [pcc:unverified]

### What was done (commands, files, features)
- Read the current AGENTS.md and the last dated session log (2026-11-15), checked the actual recently merged crypto PR #4188 and its exact F4 errors, #4228 (merged certified quotient), #4349 (open compact actual-root worker), cryptanalysis #1536, and crypto-autoresearcher lead-atlas prior #3305. Checked PKM 2016 / APS 2018 publication records. KB status/search MCP and Conductor/EKS tools were absent; repo KB wrapper and cargo checkout/toolchain were unavailable, so primary files/published metadata were the bounded fallback. No novelty claim.
- Created branch `research/prime31-s4-split-20261116` from current main after #4188 merged, instead of modifying/deleting the old PR. Extended the original Rust `research/prime31_ic_20261115/native/examples/prime31_m8_balanced_f4_input.rs` with `--split-s4-f4` (three-fibre original S4 vs each of three regular-branch chained-S3 encodings) and `--m8-s3chain-f4` (full target-dependent five-polynomial m8 conditional w-specialization with six Dickson fibres and four free variables).
- Reused `Arithmetic`, `Base`, `Polynomial::s3/s4`, `TowerRing` and `f4_tower`. The positive witness is used for soundness validation only; the seven Q branches are not labeled positive/negative to F4. Every censored return stays `undetermined`; no generic point-sum table is used in F4. Exact finite-rational equivalence/saturation of special branches is explicitly not assumed.
- Added scoped `.github/workflows/prime31-s4-split-20261116.yml` with Rust release library tests and both bounded examples on branch push and PR. Added `native/S4_S3_CHAIN_TARGET_DEPENDENT_GATE_20261116.md` with mathematical contract, references, factorial stage coverage risk, and IC-frontier comparison and full cold criteria.
- Commits: `129dce5` (single-S4 split source), `3976a2e` (mutable-add fix), `6f0fdd8` (initial focused CI), `68aa293` (full m8 S3 chain), `26f11b5` (both CI modes plus PR trigger), `5f5b465` (experiment report). No measured F4 result is inferred from these commits.

### Decisions made (and why)
- The fixed pair H2(w) exact rational roots (961, 930 distinct-index) already exist. Specialized full-m8 chained-S3 has exactly **four free variables**, within the packed native F4 limit; it removes high-degree left/right S4 resultants in favor of two S3 per side. This is a syntactically sound regular-branch construction for known affine positive points but is not yet a complete relation oracle.
- Compare first with same-ideal m8 algebraic IC inputs (PKM/APS and certified/dense/tower F4), not BSGS. Optimized rho belongs to the separately measured complete cold solver criterion, not an unfinished F4 stage denominator.
- No paid compute, new leaderboard row, merge, CI success, independent PCC verdict or cheaper complete solver assertion. Use Rust only.

### Open threads (unfinished, pick up next time)
- Inspect actual source-specific GitHub CI compilation/stdout for the two new modes, correct errors and record frozen JSON counters; require no invalid F4 refutation of the natural positive.
- If any split chain F4 completes the matched caps, test exact original-ideal rational root equivalence for regular and exceptional branches, then **all 930 distinct w specializations** without secret-dependent preselection and actual target-dependent signed root extraction. Charge every negative/censored call and independently useful rank.
- Build whole-call cold prime31 IC with existing Rust linear algebra and 12 public held-out scalars, compare complete PKM/APS and optimized rho after source-bound/independent verification.

### Errors (what went wrong, how it was handled)
- Attempt to clone private GitHub repo in this runtime failed because DNS/network access was unavailable, and there was no local cargo/rustc. Commit+hosted CI is the only compiler route in this session. A nested mutable call in the first source draft was proactively rewritten to sequential calls before the focused workflow. No claim that compilation succeeded yet.

## 2026-11-16T01:01Z — source-qualified Rust S3-chain F4 comparison: negative [pcc:unverified]

### What was done (commands, files, features)
- Opened regular PR #4373 from the new branch. GitHub-hosted Rust release [run 43783635698](https://github.com/isogeny-labs/crypto/actions/runs/43783635698), job133026303660, PR head b4b19f5, merge 4991909c, **passed** all 40 focused library tests and both new executable flags. This is producer development CI, not independently signed PCC.
- Measured same-source 3-tower original S4: oversize degree10, partial 14129 F4 muladds. Three chained-S3 pair choices: all oversize degree6, partial 30993 muladds each, attempted dense reducers 30969/30966/30964. All known regular S3 witnesses checked with zero polynomial residual.
- Measured full conditional 6-tower m8 original S4/S4/target positive: oversize degree10, partial 56211 muladds; four-S3/target m8 positive and **all seven** registered Q-w branches: oversize degree5, partial 41032 each, attempted 17433 reduced-block entries above cap15000. No actual F4 relation roots or scalar were extracted; public-Q branches remain **undetermined**, not negative. All executed Rust programs returned successfully as semantic/censor checks.
- Frozen actual original CI stdout-derived JSON and source pins in `native/S4_S3_CHAIN_CI_EVIDENCE_20261116.json`. Updated mathematical report with the exact-source tables, caveats and next target-dependent quotient gate. No Python/C++ code or measurements used.

### Decisions made (and why)
- This direct low-degree S3-chain presentation did not break the fixed-side F4 bottleneck under the exact registered 15k caps. Do not multiply the failed branch count to 930 or increase resources without a changed algorithmic mechanism. Neither censored partial muladd comparison is a completed-ideal speed ratio.
- Prioritize the now-merged #4228 / open #4349 **actual-root certified quotient** integration with 31-bit field support and target-dependent filtering before fixed-basis expansion, then real natural-positive independent rank and full cold-cost against PKM/APS. Keep rho separate as final whole-call comparator.
- PR remains open pending applicable CI and independent validation; no claimed cheaper complete ECDLP or accepted leaderboard result.

### Open threads (unfinished, pick up next time)
- Obtain a genuine target-conditioned rational finite-field root extractor with source-certified complete coverage/exceptional branches; use the same frozen natural masks, then full 32-column modular rank and 12 held-out unknown scalar recoveries in Rust. Compare a completed IC frontier oracle, not partial F4 clocks.
- Review new-PR check status for other applicable gates; do not merge before green checks and scientific review.

### Errors (what went wrong, how it was handled)
- No source compilation error in successful dedicated Rust CI. All experimental arms exceeded the explicit F4 dense cap: properly recorded `undetermined`; no negative relation verdict or false speedup was emitted.

## 2026-11-16T01:03Z — Prime-field arbitrary-point transfer goal

### What was done (commands, files, features)

- Activated the explicit user goal with acceptance criteria for an efficient,
  scalar-blind map and a demonstrated easier target; novelty and cold costs
  remain obligations, not assumed results.
- Refreshed main to 0ead8ca49 and confirmed PR 4308 merged at 00:09:29Z.
  Started branch codex/prime-field-transfer-goal-20261116 from main.
- Sources checked (KB): KB unavailable, wrapper exits 127. Read the committed
  transfer obstruction, open-case review, CT83–85/93–94 and primary Silverman,
  GHS and Cremona texts. Source receipt is in the new GOAL.md.

### Decisions made (and why)

- Investigate compressed global torsion recognition and a split multiplicative
  component-group target. Retain existing negative results at their actual scope.
- Before running native code, freeze the compressed model and fixed kernel
  counterexample protocol. Local correctness checks only; no cloud spend or
  wall-clock benchmark is requested by this checkpoint.

### Open threads (unfinished, pick up next time)

- Implement and run the fixed development checks, then follow their evidence
  to the next candidate. No arbitrary-point efficient map exists in this work yet.
- Record the merged example's required autonomy outcome and retire its monitor.
  The new research goal stays active.

### Errors (what went wrong, how it was handled)

- The original feature branch was deleted after merge; fetched main directly.
- Conductor is absent. An initial sparse-checkout command incorrectly named
  a file as a directory; retried with directory paths. Rust is absent, so
  use the installed native C++ toolchain for the isolated correctness checks.

## 2026-11-16T01:06Z — inherited workflow policy failure on this PR

### What was done (commands, files, features)
- Reviewed source-specific PR head 3728a7e CI: dedicated Rust S3-chain job, all-target Rust compile, Rust lint, workflow syntax and ecbench green. The `Workflow files parse` run [43784105704](https://github.com/isogeny-labs/crypto/actions/runs/43784105704), job133027762138, failed on `check-pr-budgets.py` with three `gb-baseline-rebench.yml` pull_request/opened/synchronize/reopened budget conditions. Confirmed exact offending workflow file has identical blob `7400cb8d` on current main and this PR head; no project-file change caused the issue.
- Annotated PR #4373 with this inherited blocking check, its exact run and file receipt. Did not suppress or modify the workflow gate.

### Decisions made (and why)
- Keep research PR unmerged pending owner reconciliation of inherited CI workflow-policy violation and remaining reviews. Scientific Rust gate succeeded, but whole PR is not globally green.

### Open threads (unfinished, pick up next time)
- Resolve upstream PR budget-parse failure in its owning scope, not by weakening policy in an unrelated IC PR; then confirm PR #4373 current-head checks and scientific independent validation.

### Errors (what went wrong, how it was handled)
- Inherited unrelated workflow-parse failure preserved explicitly instead of conflating it with Rust F4 compile or hiding it.

## 2026-11-16T01:09Z — Candidate model and kernel control implemented

### What was done (commands, files, features)

- Added the fixed native correctness driver for compressed model projection,
  exact local invariants, coefficient/parity controls and an arbitrary-lift
  kernel test. No native arithmetic call has succeeded yet.
- Read Cremona's component-map formulas and their sign convention directly.
  The target is a classical component quotient, not an asserted new map.

### Decisions made (and why)

- Keep curve construction and point transport as separate obligations. A
  compact source-compatible model does not establish a scalar-preserving map.
- Retain the first compiler failure and recover the missing header dependency
  outside the repository before making any observation claim.

### Open threads (unfinished, pick up next time)

- Complete native build and fixed checks; inspect the actual kernel witness.
- Formalize any concrete incompatible point labels using existing Mathlib laws.
  Do not count a failed shortcut or target constructor as goal completion.

### Errors (what went wrong, how it was handled)

- Build 01 fails because Boost headers are absent. Dependency recovery is
  attempted without changing the study's mathematical contracts or using Python.

## 2026-11-16T01:17Z — literature-first APS one-relation control chosen; before implementing [pcc:unverified]

### What was done (commands, files, features)
- Re-read latest branch #4373 log/PR, #4188 merged m8 and root-index evidence, #4349 certified quotient status, #4311 one-relation selector conditions, #3305 autoresearcher atlas, `research/classical_ecdlp_20261028/README.md`, `native/M3_RANK_EARLY.md` and native source. Queried GitHub for APS, one-relation, McGuire–Mueller and prior implementation paths before selecting another experiment.
- Read actual accepted APS 2018 manuscript at https://pure.tue.nl/ws/portalfiles/portal/91158650/609.pdf, particularly §§3–3.2 (random labelled dynamic factor base, one S_m zero-sum relation, no factor-base LA, partitioned f_i constraints), not merely an abstract. Also checked PKM 2016 and repository McGuire–Mueller/Kudo–Yokota reports. KB MCP is absent and no full checked-out wrapper, Conductor or local Rust toolchain is available.

### Decisions made (and why)
- Do **not** repeat the censored S3-chain F4 presentations. Test a distinct *published*, not novel, APS-style labelled one-relation prime31 solver: three disjoint dynamic public `aG+bQ` lists, polynomial-only S3 finite-field pair-root search against third-list x membership, recover a scalar from one checked signed zero-sum. Price complete generation and each failed algebraic candidate. Run a matched direct group-sum join as a separate **generic-equivalence control**, not as an oracle or hidden fallback.
- This is an index-calculus *methodology control*, not evidence of a non-generic complexity improvement: computing every S3 quadratic for a list-pair is meet-in-the-middle in disguise. It may eliminate 32-row rank work versus the prior 46s Rust S3-index solver, but a speed claim needs actual source-specific cold timings.
- Keep same ordinary cofactor-one prime31 p=2147483647, n=2147446831 and existing Rust Arithmetic; no Python/C++, hardware rental, PCC/leaderboard promotion or PR merge.

### Open threads (unfinished, pick up next time)
- Implement a Rust-only `prime31_aps_one_relation` example with exact signed witness checks, explicit exceptional/canceling treatment, reproducible public target and a source-matched algebraic-vs-generic control, then run focused exact-head Rust CI. Record actual cold timings and no-solution outcomes; compare to published APS/McGuire–Mueller frontier as a method classification.
- Continue actual certified m8 target-dependent root extraction after this bounded control if it does not qualify as non-generic.

### Errors (what went wrong, how it was handled)
- No research-KB/Conductor/EKS/cargo binaries exposed in this connector session; bounded primary-source GitHub and accepted-paper fallback noted. No test or timing has yet executed for this selected control.

## 2026-11-16T01:30Z — APS labelled m3 Rust solver completed a cold prime31 scalar [pcc:unverified]

### What was done (commands, files, features)
- Implemented the Rust-only APS-style one-relation algorithm in `native/examples/prime31_aps_one_relation.rs`, with full finite-field S3 quadratic root discovery, per-row batch inversions, public-label generator, full signed EC candidate checks and scalar replay; no known log supplied. Added focused CI and `native/APS_ONE_RELATION_PRIME31_RUST_20261116.md` with prior-art audit.
- Inspected [GitHub Actions 43786504359](https://github.com/isogeny-labs/crypto/actions/runs/43786504359), job 133035251870 (PR head source at report commit 90a0314, GitHub checkout PR merge). Exact Rust release lib tests and **both new example unit tests passed**, executable `--one` recovered `log_G(1477799919,824532935)=1038579171` with `[k]G=Q` and full signed zero-relation verification. This is one source-specific development measurement, **not independent PCC**.
- Same run: cold program-measured wall 327525503 ns; 135786811 ns public-labelled-base construction; 191380563 ns target-dependent algebraic pair-root discovery including signed validation; 672768 S3 quadratic pairs, 672768 Fp square roots, 438 batch inversions, 1 coordinate candidate and 1 signed candidate, 57 postdiscovery validation group additions. Three distinct 1536-point lists, first deterministic round, no rejected identity or duplicate x. Signed relation indices [437,1247,879], signs [-1,+1,-1], scalar equation A=1144570523, B=2011873483 nonzero. Subsequent rounds not needed.
- This first source-qualified execution was not a matched completed APS-versus-group-join speed comparison; `--compare` mode exists but not yet executed. The other already-measured S3-root-index/LA 46.2s and 0.0236s BSGS belong to a different source-host run. Inherited PR-wide Workflow files parse failure persists from identical main workflow; focused Rust scientific CI is green.

### Decisions made (and why)
- A **complete Rust prime31 labelled one-relation scalar solver has been executed** in the m3 finite-field polynomial model, with no factor-base log linear algebra. However, exhaustive S3 pair quadratics over a finite labelled list are generic pair-MITM-equivalent; do not claim a novel **non-generic** complexity or a frontier-winning ECDLP break.
- Next perform same-public-list direct group join control on the identical Rust source/host before drawing any cost conclusion; then redirect effort to a genuinely nonenumerative target-conditioned m8 certified quotient and original-ideal rational-root evidence. No leaderboard, merge or PCC promotion.

### Open threads (unfinished, pick up next time)
- Execute Rust `--compare` and keep actual generic control result/timing, preserving all setup costs and explicit seeded labelled sets. Correct one unused-binding compiler warning in the new example and preserve exact-head test qualification.
- Independently replay signed relations and replicate on 12 public held-out Qs, then test real PKM/APS m4/m8 polynomial solver frontier and complete cold cost on source-matched host; retain known generic-equivalence classification.

### Errors (what went wrong, how it was handled)
- The first implementation had a source-only illegal or-pattern binding and potential overlapping borrow, corrected before CI. The executed compiler showed only an unused `a` binding warning (not a failed test); repair in next source edit. Cargo toolchain, EKS/Conductor and research-KB unavailable locally, so source-bound GitHub Rust CI is the only execution evidence.


## 2026-11-16T02:05Z — fes-f2-gpu on an A100: current main is about 2.5 times shorter per call; the remaining time is not pipe latency [pcc:unverified] (Claude)

### What was done (commands, files, features)

- Corrected my own timer on 13 November (the worker's "read" phase included the wait for the next request) and dropped the request-parse lead; then found `main` already carried PR #4101 (binary `--serve-bin` protocol, single-copy CUDA upload). Details of the correction are in the 2026-11-13 log.
- Host: with `--serve-bin`, a null worker (parse, answer no solutions) gives a round trip of 28 us per call; the real host worker 0.45 to 0.52 ms (walk compute included). [pcc:unverified]
- One Modal A100 80GB PCIe job (`research/ic_gpu_ipc_split_20261116/`: `job_ipc.sh`, `run_arms.sh`, `null_bin.cpp`, `modal_ipc.py`, `analyze.py`, `make_fig.py`), three interleaved arms, three runs each, koblitz n23 (24 unknowns) and char2 n25 (26 unknowns); record `20261116T0058Z-ic-gpu-ipc-split-a100` (closed, measured), report, figure and 51 raw files in the directory. Before the arms: text and binary smoke tests CUDA equals host, selftest ran. A dry run of `run_arms.sh` on the host (host worker standing in for CUDA) caught no script errors. [pcc:unverified]
- Results (mean of 3 runs per arm): whole solver call, `ic` before the direct pack with the text protocol to current `main` with the binary protocol, 0.5009 to 0.2028 ms at 24 unknowns and 0.6310 to 0.2753 ms at 26 (59.5 and 56.4 percent less); counted answers identical in 5 of 5 compared runs. On `main` at 24 unknowns: kernel 0.069 ms, worker busy 0.093 ms, round trip 0.192 ms, null-worker pipe floor 0.0135 ms, so about 0.085 ms of the round trip is in none of those phases (0.079 ms at 26 unknowns). [pcc:unverified]

### Decisions made (and why)

- The 2026-11-13 guess that the unlocated time was pipe wake-up latency is not supported: the floor is 13.5 us in the container and 28 us on the host. The remainder is not yet identified; candidates (worker thread waking cold between requests, `cudaStreamSynchronize` yielding rather than spinning, first-launch latency after idle) are untested.
- The A to B difference is not attributed to one change: it spans PR #4062, PR #4101 and whatever else reached `main` between the two `ic` builds. Only the phase table attributes it.
- Did not edit `.resume/RESUME.md`: it is tracked and holds another session's handoff (the rho study, PR #4237). The S3 checkpoint gate was waived by the owner for this one run (answer to a question, 2026-11-16); `CHECKPOINT_SKIP` reason recorded in the launch command's environment.
- No `benchmarks/README.md` or leaderboard row: wall time only, counted cost unchanged, no validator report or matched rho (validation gate).

### Open threads (unfinished, pick up next time)

- A second A100 job to A/B the candidates for the 0.085 ms remainder against arm B (opt-in worker flags: spin-wait sync via `cudaSetDeviceFlags(cudaDeviceScheduleSpin)`, a short `poll()` spin before blocking on stdin). Needs another waiver or a checkpoint token, and the flag code is not written.
- The kernel is 34 percent of a call at 24 unknowns; beyond the per-call floor the lever is batching several systems per launch (#4101's timers were added for that bound).
- `docs/session-logs/2026-11-15.md` on `main` contains 10 unresolved merge-conflict marker lines from other sessions; I left it as it is.

### Errors (what went wrong, how it was handled)

- The launching Modal client was stopped at its background time limit before the job finished, so `benchrec run` never wrote its entry and `benchrec close` refused. The job ran to completion on Modal; I fetched it by token (twice; the second fetch reproduced the archived raw file byte for byte) and recorded the fetch command under `benchrec run`, saying so in the record's summary.
- The 2026-11-15 session-log conflicted on rebase because other sessions append to it; I kept `main`'s version of that file and wrote this entry in the 2026-11-16 file instead.




## 00:45 UTC — PR #2609: merge main, drop stale CI workarounds (Claude)

**What was done**
- The PR head `d9103f8` (owner's 2026-10-30 merge of main) failed four checks:
  - `current` and `artifacts`: `docs/backend-leaderboard/.artifacts.json` held two `leaderboard.json` keys (this branch's `671728f2…` and main's `cf1ca93d…`), so it was invalid JSON.
  - `parity`: `tools/artifacts/artifacts.py` no longer matched the lab-parity lock.
  - `size`: `docs/backend-leaderboard/index.html` was 16.9 MB.
- Merged `origin/main` with `git merge-tree` (no conflicts). Restored the seven shared files this branch had changed to main's versions:
  - `docs/backend-leaderboard/{.artifacts.json,index.html,reproduction.lock.json}`
  - `tools/artifacts/{artifacts.py,test_artifacts.py,wire_workflows.py}`
  - `tools/backend-leaderboard/src/main.rs`
- The PR diff against main is now additive only: `research/nist_skip_mechanism_20261026/` plus session-log entries.

**Decisions made**
- The 2026-10-27 CI workarounds (lock reseals, awscli bootstrap, sparse-checkout wiring, test adapter) fixed breakages on main that main has since fixed its own way. Main's backend-leaderboard push runs are green. Carrying stale copies is what broke the merge.

**Open threads**
- CI on the new head. The Codex P1 thread (draft protocol record, no export) is still the owner's decision.

**Errors**
- The first local `git merge` filled the disk partway through checkout (per-session allowance). It wrote no MERGE_HEAD, so the working tree holds partial main files; nothing was committed from it. Freed 1.6 GB by deleting build output and caches, then merged with `merge-tree` and a temporary index.
- The auto-mode classifier refused a `git reset --hard`/`clean`; that working tree is left as is.

## 00:55 UTC — PR #2609: CI on 99a421e (Claude)

**What was done**
- `artifacts` failed with `Extra data` in `research/nist_skip_mechanism_20261026/.artifacts.json`. The 2026-10-30 union merge had stacked main's manifest (old `report.pdf`, `fd908b3c…`) above this branch's (`18fd1ee7…`), and had re-added the old `report.pdf` as a tracked binary. Restored the manifest from `1ae6131` (rebuilt PDF) and untracked `report.pdf`. Checked the other 3,758 manifests in the tree: all parse.
- `gate` (pcc prose lint) flagged "breaks" in the PR description. Rewrote the description and tagged unfiled results `[pcc:unverified]`. Main's `pcc.py lint-prose` reports 0 findings on the rewritten passages.
- `records` fails on main's open record `benchmarks/records/20261115T0609Z-genus-ladder-sge-scale.json` (2b6141b). Not this PR's; commented.
- `factor-base sweep CLI` fails on main's E0308 at `src/cryptanalysis/koblitz_index_calculus.rs:1646` (`lift_x_packed` returns a `Vec` in its cached branch, from merge 16aa662). Not this PR's; a two-line patch is proposed in a comment.

**Decisions made**
- Main-side failures are left unfixed here, to keep the PR additive.

**Open threads**
- The Codex P1 thread (owner). Main's open bench record and compile error.

**Errors**
- None new.


# Session log 2026-11-16

## 00:30Z: Auxiliary-curve search, Amendment A1 (exact prediction and confirmatory run)

### What was done (commands, files, features)
- `auxsearch/exact/hurwitz.c`: Hurwitz class numbers from reduced forms. The exact P_accept formula matches a full
  enumeration of every curve at p = 257, 263 and 769. At P1 the predicted tries are 0.992–1.025 × 2^t for t ≤ 14.
- Froze `AMENDMENT_A1.md` (commit `1eb46c2a0f`), then ran 2,200 fresh searches locally: t = 12..14 × 600 and
  t = 15, 16 × 200.
- Result: the exact model holds at every t. Pooled z (t = 12..14) is −1.28. The first sweep's +13% did not recur, so
  it reads as chance. `[pcc:unverified]`
### Decisions made (and why)
- Owner: "Keep testing". The open question was the first sweep's t = 12..14 excess. PARI was refused earlier, so the
  class numbers were computed in C.
- While the run was in progress I committed partial outputs as labelled checkpoints, because the stop hook requires
  a clean tree.
### Open threads (unfinished, pick up next time)
- None for the search itself. The search is now characterised, and its cost is outside the criteria (SUCCESS_CRITERIA
  rev 3).
### Errors (what went wrong, how it was handled)
- The session machine restarted mid-run. The processes resumed, and the outputs were checked to be exact in-order
  prefixes of their shards: no loss, no duplicates.


# 2026-11-16

## 00:13 UTC — native point-table current-main refresh

### What was done (commands, files, features)
Read both exact PR heads, actual review/thread lists and applicable checks.
Successor e5c52eb5 now has hosted PCC/lesson success; an older same-head PCC
run was cancelled and is not counted as passed. Parent2615f313 remains dirty,
and its unrelated genus-ladder benchmark record remains open on main.
Normal-merge main556ea9b7 and retain complete normalized old-date journal
blocks, multiplicities and each source order, with raw Git blobs pinned.
These are producer observations, not signed verdicts. [pcc:unverified]

### Decisions made (and why)
Preserve main's new admission/dimension audit/control files without changing
the point-table algorithm. Native inputs differ from old frozen manifests;
generate a fresh complete manifest and rerun all-target validation. Keep all
old archives/manifests and canonical ledger/claim histories intact. Documented
Copilot fallback was already used after unanswered requests; no new response
or racing resolver appears. Auto-merge remains off under actual gates.

### Open threads (unfinished, pick up next time)
Qualify combined source, then normally refresh successor bottom-up. No study,
benchmark, image build, scientific workflow, old study edit or global setting
change. Sources checked (KB): unavailable (wrapper lacks executable, no MCP);
reviewed prior receipts, root rules, retention method and actual source diff.
No new mechanism or novelty/absence claim. Conductor remains unavailable.

### Errors (what went wrong, how it was handled)
Merge guard stopped on an additional problems-index conflict before edits.
Standard three-way union retains both conflicting additions and every actual
head-added row plus current main rows. An initial overstrict assertion also
required a stale baseline row legitimately updated by main; inspected that
update before accepting normal nonconflicting main changes. This is an ordinary
problem index, not a protected ledger or frozen-evidence side selection.
Native-only checks began on the staged combined code while doc conflicts were
pending; source manifest is checked again afterward. Needs-human autofix label
comes from a scheduled queue missing its provider secret; no label/setting
was changed, and no automatic approval review rejection occurred.

## 00:15 UTC — parent combined audit-source qualification

### What was done (commands, files, features)
All 167 locked release all-target cases, formatting, strict all-target clippy
and Rust1.78 compile pass on the combined native source. Main's four audit/
dimension file changes are preserved byte-for-byte; the point-table algorithm
is unchanged. Canonical ledger1157 rows equals incoming main and retains old
head as a full byte prefix;111 lesson entries check clean. [pcc:unverified]

### Decisions made (and why)
Record a fresh complete native manifest, including Rust examples, rather than
calling old source manifests current. Keep all original reports/archives intact.
Upload one normal expected-head-guarded refresh, then validate the successor.
User's all-applicable-CI/review rule still holds beyond the minimum ruleset.

### Open threads (unfinished, pick up next time)
Hosted checks on the actual new heads, current main conflict and unrelated open
benchmark record. No native measurement, image build or scientific workflow.

### Errors (what went wrong, how it was handled)
Classic branch-protection API returns403; actual branch-rules API succeeds and
requires MERGE, resolved review threads and gate/size/artifacts. No bypass.
Autofix queue's needs-human label is a missing provider secret on an older
scheduled main run; no secret/label/global setting change was made.




## 00:17 UTC — joint-target qualified-base refresh

### What was done (commands, files, features)
Normal-merge qualified parentaac194f7010c into successor e5c52eb5. Preserve
main's four native audit/control changes and the existing joint algorithm.
Complete normalized old-date journal blocks/multiplicities/order and today's
incoming parent journal are retained; original Git blobs remain pinned.
Canonical PCC equals the incoming base and keeps old head as full byte prefix.
These are producer source/history observations. [pcc:unverified]

### Decisions made (and why)
Generate a new complete native manifest and full checks; old frozen manifests
and archives stay untouched. Actual hosted checks on old e5c52eb5 were green
for PCC/learning and other applicable jobs, with an older cancelled PCC run
retained separately; no new-head hosted pass is inferred. Auto-merge remains
off on feature base; land bottom-up and never bypass actual protection/review.

### Open threads (unfinished, pick up next time)
Current combined native tests/fmt/strict clippy/MSRV and new-head CI/reviews.
Parent still depends on current-main conflict and unrelated open record.
No scientific run, image build, old study edit or runtime-gain claim.

### Errors (what went wrong, how it was handled)
No algorithm edit or history rechain is used to fix a verifier/status.
Any unexpected protected conflict stops the merge rather than picking sides.

## 00:23 UTC — joint combined audit-source qualification

### What was done (commands, files, features)
Combined source passes174 release all-target cases, formatting, strict all-target
clippy and Rust1.78 compile. New complete source manifest retains main's four
audit/control file changes; prepared/joint algorithms are byte-identical to
previous feature head. PCC1157 rows and lesson114 entries check clean against
incoming qualified base. These are producer controls, not signed verdicts.
[pcc:unverified]

### Decisions made (and why)
Upload the normal base merge with fresh source/log/retention receipts. Keep
old frozen manifests/archives/proposals unchanged. Auto-merge stays off under
actual new-head CI/reviews and bottom-up parent disposition. Source refresh
activity resets tracking counters; no foreground CI wait or repeated main loop.

### Open threads (unfinished, pick up next time)
Parent aac194f7 is dirty again after further main activity; its actual review/
migration jobs pass, but required/applicable qualification is incomplete.
Inherited genus-ladder record remains open. New successor hosted checks remain
pending; no merge or runtime/significance verdict is inferred.

### Errors (what went wrong, how it was handled)
Git push warned about an84MB browser-data blob already in incoming main, not
a changed point-table artifact. Owned-file artifact/size checks pass; the
unrelated main blob was neither rewritten nor migrated. No experiment,
benchmark, image build, old study edit or global authentication setting change.



## 2026-11-16T01:36Z — PR #4373 merged; preserve prime31 APS evidence in #4374 [pcc:unverified]

### What was done (commands, files, features)
- Learned that #4373 merged into main during ongoing Rust-only APS work and its feature branch was deleted, invalidating a subsequent file-create attempt on that old branch; did not restore/rewrite it.
- Confirmed the merged main contains the APS Rust example, fixed compiler-warning binding, same-input `--compare` implementation, `--one` workflow and the experiment report. Started new branch `research/prime31-aps-result-20261116` from current main and opened [PR #4374](https://github.com/isogeny-labs/crypto/pull/4374).
- Recorded exact CI evidence for `--one` in `native/APS_ONE_RELATION_PRIME31_RUST_CI_20261116.json`; extended the report with full first source-bound 327525503 ns result and all scoped limitations. Extended existing Rust example with `--holdouts`: twelve deterministic distinct public caller-generated points Q=[k]G; the known k values are used only by independent caller verifier *after* the unknown-scalar algebraic search. Added exact-head Rust CI step for 12 heldouts. The existing PR's `--compare` CI step runs a fully separate direct group join control on identical public labels, no hidden solver fallback.
- Initial Rust source had 2/2 APS tests and one full log replay green. New `--holdouts` source and all new comparison steps are not yet claimed compiled or executed on current head.

### Decisions made (and why)
- Keep existing APS one-relation solver evidence as a completed published-method correctness and cold component. Its direct S3 quadratic scanning is generic group-MITM equivalent, so no novel non-generic or frontier-win claim.
- Next scientific gate remains **nonenumerative** target-dependent quotient/root extraction for original m8 prime31 ideal with original-ideal proof and signed natural outputs. The Rust heldout panel will decide whether the simpler complete published APS control is robust across publicly generated Qs.
- PR #4374 is evidence/replay and a new holdout experiment on main; no rewrite of #4373/4188, no paid compute, independent PCC promotion or merge requested.

### Open threads (unfinished, pick up next time)
- Inspect and freeze exact-head `--compare` and 12-heldout Rust CI stdout. If a control fails, correct source, keep full failure receipt and rerun; no false completeness or speed ratio.
- Obtain matched source/host full cold APS/PKM IC frontier and mature CAS controls; separately evaluate optimized negation-map rho only after a complete non-generic solver exists, with 12 heldouts/independent PCC gate.

### Errors (what went wrong, how it was handled)
- Attempt to write `native/APS_ONE_RELATION_PRIME31_RUST_CI_20261116.json` into deleted #4373 branch returned GitHub 404; resolved by creating #4374 from main. GitHub Actions CI for new source steps is still pending; no local Rust/EKS toolchain was available.


## 2026-11-16T01:39Z — same-host APS algebraic-vs-generic and twelve heldout Rust solves [pcc:unverified]

### What was done (commands, files, features)
- Inspected exact [GitHub Actions #43787167910](https://github.com/isogeny-labs/crypto/actions/runs/43787167910), job133037288540 at tested source-report head 6b2c38de: Rust library, new example tests and all three `--one`, `--compare`, `--holdouts` programs **passed**. Full original stdout-derived JSON and source pin committed to `native/APS_ONE_RELATION_PRIME31_MATCHED_CI_20261116.json`, report updated.
- Matched single-public-Q same-run result: complete algebraic APS one-relation path 268610255 ns in-process cold (source setup 98874119 ns, 169421471 ns Fp algebraic discovery and verification); separate direct group join on identical labelled public sets 325897345 ns join, source+join 424771464 ns, with 1345017 group additions. Both independently verified log 1038579171, neither uses target secret. Algebraic pair S3 computations 672768, 438 batch inversions. This one sequential A/B is not a signed/isolated speed ratio; measured cost ratio of those two Rust implementations is ~1.581.
- Twelve caller-generated independent public Q=[k]G held-outs: **12/12 complete correct target scalar recovery**, all in first natural-labelled round, each solver reconstructed its own 3x1536 labelled points, total per-target cold walls 2271161215 ns and total S3 pair queries 4368384. Per-Q timings, known-answer-only scalars, actual recovered scalars and all source-query counts retained in JSON. No Python/C++ code or measurements.
- PR #4374 contains completed source-bound evidence, actual Rust `--holdouts` source/CI, corrected report and log. Previous #4373 was merged before evidence publication; both histories preserved.

### Decisions made (and why)
- Record a **real complete Rust index-calculus-derived published APS one-relation solver on prime31**, with 12 heldouts and same-input generic control. However pair-root enumeration is generic MITM-equivalent, so no novelty, non-generic complexity break, or superiority over the strongest external IC frontier is asserted.
- Retain optimized rho as separate final security comparison, not as the index-calculus frontier denominator. Next mathematical dependency: target-conditioned rational-root certified quotient for m8 without enumerating finite pair supports. Both actual natural complete rows and same-original-ideal proof required.
- Development CI [pcc:unverified] and no isolated A/A, independent PCC signer, leaderboard, paid EKS, or general curve-scaling measurement. PR check/merge ownership remains independent.

### Open threads (unfinished, pick up next time)
- Independent replay 12 heldouts with a second Rust implementation or a signed PCC verifier; A/A randomized same-run repetitions, matched APS/PKM / external CAS. Specific engineering opportunity: certify an 8-variable-or-fewer quotient shape equivalent to the 36-tower-variable m8 target ideal before attempting to transplant #4349 selected-root worker; current worker input caps preclude a direct call.
- Assess whether an algebraic target-dependent m8 oracle yields naturally useful projectively independent rows at total cost below all completed IC arms. Maintain all failed/censored outcomes.

### Errors (what went wrong, how it was handled)
- Initial file-create to deleted #4373 branch was resolved by a new feature branch/PR #4374. The successful Rust run has no source compilation or scalar replay errors; inherited workflow policy failure from unchanged main workflow file is a separate PR-wide check and remains documented. No claim of independent PCC.


## 2026-11-16T02:00Z — prime31 m8 rational-base quotient bridge (Rust only) [pcc:unverified]

### What was done (commands, files, features)
- Re-read AGENTS.md, current 2026-11-16 session log, #4374 complete APS control, merged #4373 censored S3-chain m8 F4, #4349 selected-root state, #4228 and original #4188 quotient evidence. Cross-checked the primary PKM 2016 and APS 2018 works. KB, Conductor, EKS and local cargo toolchain unavailable; bounded GitHub/source fallback, no novelty assertion.
- Added `research/prime31_ic_20261115/native/examples/prime31_m8_quotient_bridge.rs` to #4374, reusing Rust `Arithmetic`, `Base`, `PRIME31` and `check_curve`. Constructs an exact rational factor-base polynomial H(X) of degree 31 and a pair-sum coordinate polynomial K(U) of degree 961 from S3 quadratics, **without ordinates or group additions in algebraic construction**. Its Rust test checks H roots/derivatives against all 64 Dickson abscissae; checks all 465 off-diagonal quadratics plus 31 diagonal linear factors and 961 signed pair-sum x semantic controls with group arithmetic **after** construction.
- Added source-only CI test/run to the existing Rust workflow; added `native/M8_RATIONAL_QUOTIENT_BRIDGE_20261116.md` with precise finite-rational-root vs ideal equivalence scope, dimension 31^8 = 961^4 = 852891037441, cancellation exceptions and an exact target-dependent quotient experiment.
- No local Rust execution or paid benchmark performed; all numerical checks in new source are expectations/assertions pending exact-head CI. The previous 12/12 APS complete-solve results remain historical and are not reclassified as non-generic.

### Decisions made (and why)
- Use the degree-31 H constraint to replace each six-level base tower **for rational admitted x membership**, but do not claim polynomial-ideal equivalence over algebraic closure or reduce the 8-leaf quotient tensor size. Four pair-sum coordinates plus implicit S5 is a candidate selected-root interface, not a completed polynomial oracle.
- Focus future Rust work on certified *target-conditioned* S5 resultant/subresultant in a selected-root quotient avoiding dense 961^4 materialization. Reject a full generic pair-root enumeration as a non-generic advancement.
- Benchmark completed algebraic relation oracles against PKM/APS and native F4/quotient first; optimized rho remains the separate complete cold security comparison. No merge, new leaderboard row, PCC standing, or EKS spend.

### Open threads (unfinished, pick up next time)
- Inspect source-pinned CI compilation and H/K semantic test output; fix any Rust errors on the same PR head.
- Prove or refute feasibility of a compact selected-root S5 original-ideal certificate with the current #4349 root worker; implement B4/B8 positive/negative natural target equivalence and full exceptional handling first.
- If non-enumerative roots emerge, record actual useful signed relations, independent rank, complete prime31 unknown scalar recovery, matched IC-frontier and independent PCC validation.

### Errors (what went wrong, how it was handled)
- GitHub-only session cannot run cargo or EKS; source-level Rust checks have not been promoted to executed evidence.


## 2026-11-16 — prime31 rational quotient CI replay and Rust APS size sweep [pcc:unverified]

### What was done (commands, files, features)
- Reviewed AGENTS.md, this session log, merged #4188/#4373, current #4374, and recent #4349 selected-root worker updates; checked prior F4/IC gate and squarefree B31 K report before choosing any novel direction. Shared research-KB tools/wrapper unavailable in this tool runtime; fallback primary GitHub sources plus published PKM 2016 and APS 2018 records (10.1007/978-3-662-49387-8_1; 10.1016/j.ffa.2018.01.009), no exhaustive novelty clearance.
- Fetched **actual exact-source GitHub Actions run 43788581330**, job 133041649132, at source fa6f90d7337ad16475f139b140484a827dfb1bb6. Release Rust development CI PASS: 40 library tests, 1 new quotient-bridge example test. The executed binary confirmed 31 admitted/64 Dickson x, squarefree H degree31, K degree961 (465 quadratic S3 factors +31 diagonal linear), and 961 independent signed affine pair-coordinate semantic checks. Frozen unedited parsed source output in `native/M8_RATIONAL_QUOTIENT_BRIDGE_CI_20261116.json`; not a new m8 target-conditioned oracle or complete scalar recovery. Separate repo workflow-policy and PCC gates fail and are not bypassed.
- Extended existing `native/examples/prime31_aps_one_relation.rs` with a fully Rust `--size-sweep`: 12 identical public heldout Q across five preselected labelled-partition sizes T=768,1024,1536,2048,3072 with max rounds 12,8,3,3,2. Preserved default T1536 paths, and added a small test of sized source generation, per-arm exact scalar replay, every censored/missed case, all cold setup and source/field-pair work. User scalar never enters solver; only caller-side verifier compares after recovery.
- Wired the new Rust mode into existing GitHub release workflow, plus `native/APS_PARTITION_SIZE_SWEEP_PROTOCOL_20261116.md` with full cost, coverage and falsification requirements. No Python or C++ code/benchmark. The source was committed, but no exact-head Rust sweep execution receipt was available at this log entry.

### Decisions made (and why)
- The APS-style one-relation solver is a **published IC methodology control but generic pair-MITM equivalent**; a measured T-size tuning cannot be promoted as a novel algebraic ECDLP break or fastest external PKM/APS computation. Its benefit is a better internally complete Rust comparator; assess all failure-limited cases on unconditional charged cost, not just successful-only latencies.
- Rational H31/K961 quotient bridge now has an actual Rust green *construction equivalence* receipt, not equality of ideals over algebraic closure or root-extraction progress. Do not repeat the earlier completed B31 K squarefreeness experiment; focus new m8 work on target-dependent selected-root S5 and original-ideal certificates, if feasible.
- No independent PCC or promotion, no merge and no paid compute or infrastructure changes.

### Open threads (unfinished, pick up next time)
- Inspect exact-head new Rust sweep CI; on compiler/test failure correct source and keep failing receipt. Freeze source-bound outputs and compare complete paid cost and observed failures against the T1536 control; do not infer results from heuristic T-size expectations.
- Integrate #4349's supported selected-root/compact certificate with a small-B original-ideal-equivalent target-dependent m8 polynomial system; avoid generic support lookups. Require complete rational roots/signed y replay, then natural B31 relations, rank or APS one-relation recovery, matched external F4 and PKM/APS completed controls before a novel speed claim.

### Errors (what went wrong, how it was handled)
- No local Rust compiler or authenticated EKS/checkpoint route in this session; GitHub Rust CI is the only executed toolchain. New sweep completion was unobserved at log time and explicitly marked pending. Historical PR-wide workflow-parse/PCC failures remain out-of-scope; do not weaken gates.


## 2026-11-16 — K961 radical gate and certified-root cost correction [pcc:unverified]

### What was done (commands, files, features)
- Extended the existing Rust m8 quotient-bridge example with an Fp Euclidean polynomial gcd test: require `deg gcd(K(U),K'(U))=0` for the full B31 degree-961 pair-support polynomial. This independently retests previous #4188 B31 squarefreeness, without Python arithmetic and before any group-sum semantics. New Rust source commit 0928e630; exact-head execution not yet observed. The previous fa6f90d quotient semantic CI success remains frozen and does **not** cover this new gcd.
- Added the precise split-semisimple-coordinate-quotient interpretation and generic-MITM support-enumeration obstruction to `native/M8_RATIONAL_QUOTIENT_BRIDGE_20261116.md`.
- Re-read the newer #4349 PR report at head 9c31116. The currently measured six-variable compact-certificate pilot **does not beat optimized native F4**; its full-cost relative gain 2.43–2.99× is against expanded certificates, not F4. Added this negative cost gate to the APS sweep protocol so m8 port priority requires a genuinely different target ideal and completed equal-root-set comparison.

### Decisions made (and why)
- The K-root split quotient, even if the new squarefreeness gate passes, is not a fast/non-generic solver by itself: explicitly accessing its 961 roots as a generic support table defeats the cryptanalytic novelty target. Only target-conditioned compact elimination that does not list all roots can qualify.
- Do not imply #4349 has a 15× full-cost or native-F4 win on prime31; its L0 pilot is a different small-system family with producer-only PCC.
- New APS partition-size sweep remains a published generic-equivalent IC control and requires exact-source Rust execution before any numbers are published. No extra paid compute/merge or validation weakening.

### Open threads (unfinished, pick up next time)
- Inspect focused Rust workflow on the latest source. If it is not triggered or compilation fails, preserve the source-only boundary and fix the defect before claiming success; freeze emitted per-target T sweep output if executed.
- Construct and compare a small-B genuine target-dependent S5/selected-root original-ideal certified oracle against optimized F4/PKM/APS, including all exceptional signed branches.

### Errors (what went wrong, how it was handled)
- Latest commit-workflow association returned no new pull-request-triggered runs for recent head commits at check time; new Rust size sweep and K-gcd assertion therefore remain *unverified*. Previous exact-source CI success is retained with original source SHA.


## 2026-11-16 — Genus-3 positive control: Cardano–Lucas splitting test ported, re-measured against matched rho (Claude, branch claude/hyperelliptic-index-calculus-td1fdn)

### What was done
- Prior-art check: the Stickelberger pre-filter (round 3 R1) and the full Cardano–Lucas test (round 4 C1,
  `examples/ic_improve4_01_genus3_rel.rs`) already existed, measured without a rho arm. The positive control
  (`research/ic_positive_control_20261112`) still used `x^p mod u`. research-kb MCP not available here; repo grep used instead.
- Ported C1 into `src/cryptanalysis/chained_transfer/ic_control.rs` (`SplitOracle::{Frobenius, Lucas, LucasRoots}`,
  `run_ic_oracle`); arms L and M in `src/bin/ic_positive_control.rs`. Tests: every monic cubic over 12 primes and a
  trajectory test, `cargo test --release --lib chained_transfer::ic_control`: 6 passed.
- Protocol frozen before data (commit 4feb188f47). Run: 696 runs, all certified, 583 s. Gates G1 (C and R reproduce
  11-12 bit for bit), G2 (L pairs exactly with C), G3: pass. `research/ic_positive_control_lucas_20261116/`.
- Bench record `benchmarks/records/20261116T0122Z-ic-positive-control-lucas.json` closed (measured); figures in
  `benchmarks/20261116-ic-positive-control-lucas/`; progress report regenerated.
- Fixed `main`'s compile break in `koblitz_index_calculus.rs::lift_x_packed` (stale `Vec` return after a merge).

### Decisions made
- Port rather than reinvent: round 4 already had the test; the missing piece was a matched rho.
- No leaderboard / benchmarks/README row: no validator report yet (validation gate).
- Local run instead of isolab-eks: no AWS identity in this container; counts are deterministic in the seed. Disclosed in PROTOCOL §8.

### Results [pcc:unverified]
- Relation multiplications per trial: L/C 0.45–0.52 (exact pairing), M/C 0.20–0.22 where a single-exponent cube root exists.
- Distance to matched rho at p = 32771: w=0.1 7.44 → 3.69; w=1 40.2 → 19.6. At 65537 (M = L): 5.82 → 3.97, 31.5 → 21.3.
- §5a verdict unchanged: unresolved. LA is now 54–74% of native multiplications.

### Open threads
- Independent validator replay of run.json (needed for any leaderboard row).
- Next levers: LA (SGE + block Wiedemann, FB/large-prime rebalance), cube roots when 3 | n/3, genus 4.
- Round 17 (ecbench ic.hyperelliptic vs rho.negation) still not run.

### Errors
- `main` did not compile (koblitz_index_calculus.rs); fixed minimally in this PR.
- Prediction P1 for M missed the 3 | n/3 fallback at 65537 (scored as failed in RESULTS.md).
- S3 checkpoint push impossible here (no AWS profile/token).


## 2026-11-16 ~02:30Z — ECC2K-130 follow-ups F1–F3: all lanes reported (Claude)

### What was done
- Consolidated `research/ecc2k130_followups_20261116/`: `README.md` and `REPORT.pdf`. Each
  lane has `RESULTS.md`, `results.json`, figures and `raw/SHA256SUMS`, all verified by the main
  session. Everything is `[pcc:unverified]`.
- **F1:** primary NO-CHANGE. Warm-phase seeding WP/A0 = 1.006 [0.986, 1.025] at m=23; random
  phases do as well, and the same-target positive control also fails. Secondary lead:
  carrying target-free learnt clauses (WL) gives 0.903 [0.883, 0.922] in conflicts and 0.852
  in propagations, with 2,394 carried clauses rechecked against the core and 0 failures. B
  (L3's persistent solver) reads 1.02 on positions 1–39 and 0.74 on 40–79, so L3's NO-CHANGE
  was a 40-target artefact. Freeze verified: `cee8ccfb` committed 01:09:02Z, before data.
- **F2:** GF(2^n) w_cal instrument (`binwcal`, Rust, core 3 only); all controls pass in
  11/11 cells. At measured prices, L2's m=2 filter loses in every cell. L4's G vs I order now
  hinges on whether multiplications are latency- or throughput-bound. Provisional; the isolab
  task card is in RESULTS.md §7. The freeze is not verifiable from Git: the frozen version was
  committed 40 s after the first data, and the earlier draft differs only by disclosed pre-data
  changes from an unscored smoke run.
- **F3:** the m=83 counted row is blocked on method. ecbench has no IC method at n ≥ 64, and
  the planner arm projects about 1.1 PiB of table and 10^3–10^5× rho. Launch specs and requests
  are frozen; the n=41/53/61 smoke run is verified (IC/rho 14.96, 19.38, 24.42). Freeze
  verified: `5d14d9bb` committed 01:09Z.
- Lessons recorded: L-d22d5c64bf45, L-9e6d28a2c381, L-22ccc8e9ca35; outcome O-c3349862b5f9.

### Decisions made
- WL is reported as a secondary lead, not an improvement. It needs a pre-registered
  confirmatory run (200+ targets, k=3, a clause-quality filter).
- The `main` build fix and the `pcc-gate.yml` pull step are proposed on #4371 and not pushed,
  because both are outside this PR's scope and the second hands secrets to the integrity gate.
- PR #4371 was merged by hand mid-run. The rebase onto `main` was pushed with
  `merge -s ours`, because a force-push was refused by the auto-mode classifier. The rest of
  the work went to #4376.

### Open threads
- WL confirmatory run. A B and WL panel over 200+ targets.
- Isolated (isolab) calibration of F2; a three-word ecbench instance at n=131.
- F3: an owner decision on a better-scaling wide IC method or another §8a reading; the cheap
  rate probe needs a live budget readback.
- `main` blockers on #4376: build break at `koblitz_index_calculus.rs:1646`, the tolerance cap
  rejecting `20261029-ic-packed-filter`, the `pcc-gate.yml` pull step, and an open record
  `20261115T0609Z-genus-ladder-sge-scale`.

### Errors
- A second `main` checkout for a CI check filled the disk allowance. It was removed at once,
  and no lane files were affected.
- A rebase with `--autostash` at 01:34Z rewrote F1's live raw files and very likely stopped
  F1's p3 process. The rerun matched every counted field.
- The sync script still pointed at the 11-14 folder after the new lanes started, so one
  checkpoint pushed nothing. Fixed.
- The #4376 PR body had an untagged claim word ("broken"); the lint failed and the body was
  fixed.
- `migrate` push races at 240 s push spacing; widened to 420 s.


## 2026-11-16T01:49:17Z — Component-target round validated; goal remains active

### What was done (commands, files, features)

- Native GMP/OpenSSL checks cover three compact-model instances, six rejected mutations and a 256-bit source-model projection. An independent-lift shortcut fails on an order-five subgroup over F59; the exact rational kernel witness and separate modular checks are retained. [pcc:unverified]
- A separate classical Tate encoding control checks nine order/precision cases; fixed low absolute precision merges target labels. The auditor's known labels are not an arbitrary-point evaluator. [pcc:unverified]
- The unchanged local Lean gate passes 16 theorems, zero failing and zero trusted native exceptions; explicit axioms use standard foundations. Source-linked two-page A4 report and both diagrams were inspected. Claims PCC-20261116-a3e9e1, PCC-20261116-4d7a4e, PCC-20261116-3bd2b2 remain unsigned. [pcc:unverified]
- Recorded merged PR4308's partial autonomy outcome E-084895121e13 and retired its monitor. Post-merge gate/artifact failures and missing original intervention timestamps are recorded without inventing green CI or an unsupervised-success score.

### Decisions made (and why)

- Reject independent local/global lifts and the tested flat-precision encoding. Keep the candidate target and investigate a component extractor tied to one consistent torsion branch. No general obstruction or novel efficient transfer is asserted.
- Keep the research goal active with its original arbitrary-point, novelty, scaling and full-cost acceptance criteria.

### Open threads (unfinished, pick up next time)

- Publish the round and focused correctness CI, inspect final-head checks, then continue the actual torsion-branch component extractor. No point evaluator or demonstrated easier total solve exists in this checkpoint.
- Future admitted experiments need immutable pre-call qualifiers, separate manifests and budget/isolation admission; this round contains development correctness only.

### Errors (what went wrong, how it was handled)

- Missing Boost resolved by using installed GMP; misleading indentation fixed with braces. Three Lean development failures were resolved with existing laws and explicit field denominators. Raw attempts are preserved.
- An orphaned report paragraph was removed by adjusting the page layout; both final pages were inspected. Conductor and root Cargo remain absent.

