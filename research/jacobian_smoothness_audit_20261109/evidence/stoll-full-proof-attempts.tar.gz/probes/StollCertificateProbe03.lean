import MumfordStollGeneral

/-! Candidate certificates are accepted only by the Lean kernel below.
Bezout choices are fixed before defining the deterministic arithmetic. -/
namespace MumfordStollFullCertificatesAudit
noncomputable section
open Polynomial MumfordStollAudit MumfordStollGeneralAudit
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1200000

attribute [local simp] Polynomial.coeff_C Polynomial.coeff_one Polynomial.coeff_zero
  Polynomial.coeff_X_pow Polynomial.coeff_X Polynomial.coeff_mul_C Polynomial.coeff_C_mul
  Polynomial.coeff_add Polynomial.coeff_sub Polynomial.coeff_neg
  MumfordStollCantorAudit.coefficient_constant_power

def repPerm (i : Fin 10) : Fin 10 :=
  match i with
  | 0 => 0
  | 1 => 6
  | 2 => 2
  | 3 => 8
  | 4 => 4
  | 5 => 5
  | 6 => 1
  | 7 => 9
  | 8 => 3
  | _ => 7

def expectedIndex (i j : Fin 10) : Fin 10 := repPerm (repPerm i+repPerm j)

@[local simp] theorem coeff_constant_product (a b : K) (p : K[X]) (n : ℕ) :
    (Polynomial.C a*Polynomial.C b*p).coeff n=a*(b*p.coeff n) := by
  simp only [mul_assoc,Polynomial.coeff_C_mul]

@[local simp] theorem coeff_right_constant_power (p : K[X]) (a : K) (m n : ℕ) :
    (p*(Polynomial.C a)^m).coeff n=p.coeff n*a^m := by
  rw [←map_pow,Polynomial.coeff_mul_C]

@[local simp] theorem coeff_left_constant_power (p : K[X]) (a : K) (m n : ℕ) :
    ((Polynomial.C a)^m*p).coeff n=a^m*p.coeff n := by
  rw [←map_pow,Polynomial.coeff_C_mul]

-- Candidate Bezout choices only. Their equations must be proved by Lean.
def bezoutA (i j : Fin 10) : K[X] :=
  match i,j with
  | 0,0 => 0
  | 0,1 => 0
  | 0,2 => 0
  | 0,3 => 0
  | 0,4 => 0
  | 0,5 => (1)
  | 0,6 => (1)
  | 0,7 => (1)
  | 0,8 => (1)
  | 0,9 => (1)
  | 1,0 => 0
  | 1,1 => 0
  | 1,2 => 0
  | 1,3 => (1)
  | 1,4 => 0
  | 1,5 => 0
  | 1,6 => (1)
  | 1,7 => 0
  | 1,8 => (1+X)
  | 1,9 => (1+X)
  | 2,0 => 0
  | 2,1 => 0
  | 2,2 => 0
  | 2,3 => 0
  | 2,4 => 0
  | 2,5 => 0
  | 2,6 => (Polynomial.C (2:K))
  | 2,7 => 0
  | 2,8 => (Polynomial.C (2:K)+X)
  | 2,9 => (Polynomial.C (2:K)+X)
  | 3,0 => 0
  | 3,1 => 0
  | 3,2 => 0
  | 3,3 => 0
  | 3,4 => 0
  | 3,5 => 0
  | 3,6 => 0
  | 3,7 => (Polynomial.C (2:K))
  | 3,8 => (Polynomial.C (2:K)+X)
  | 3,9 => (Polynomial.C (2:K)+X)
  | 4,0 => 0
  | 4,1 => 0
  | 4,2 => (1)
  | 4,3 => 0
  | 4,4 => 0
  | 4,5 => 0
  | 4,6 => 0
  | 4,7 => (1)
  | 4,8 => (1+X)
  | 4,9 => (1+X)
  | 5,0 => 0
  | 5,1 => 0
  | 5,2 => 0
  | 5,3 => 0
  | 5,4 => 0
  | 5,5 => 0
  | 5,6 => 0
  | 5,7 => 0
  | 5,8 => (X)
  | 5,9 => (X)
  | 6,0 => 0
  | 6,1 => 0
  | 6,2 => (1)
  | 6,3 => 0
  | 6,4 => 0
  | 6,5 => 0
  | 6,6 => 0
  | 6,7 => 0
  | 6,8 => (1)
  | 6,9 => 0
  | 7,0 => 0
  | 7,1 => 0
  | 7,2 => 0
  | 7,3 => (1)
  | 7,4 => 0
  | 7,5 => 0
  | 7,6 => 0
  | 7,7 => 0
  | 7,8 => 0
  | 7,9 => (1)
  | 8,0 => 0
  | 8,1 => (Polynomial.C (2:K))
  | 8,2 => (Polynomial.C (2:K)+Polynomial.C (2:K)*X)
  | 8,3 => (Polynomial.C (2:K)+Polynomial.C (2:K)*X)
  | 8,4 => (Polynomial.C (2:K))
  | 8,5 => (Polynomial.C (2:K))
  | 8,6 => (Polynomial.C (2:K))
  | 8,7 => 0
  | 8,8 => 0
  | 8,9 => 0
  | 9,0 => 0
  | 9,1 => (Polynomial.C (2:K))
  | 9,2 => (Polynomial.C (2:K)+Polynomial.C (2:K)*X)
  | 9,3 => (Polynomial.C (2:K)+Polynomial.C (2:K)*X)
  | 9,4 => (Polynomial.C (2:K))
  | 9,5 => (Polynomial.C (2:K))
  | 9,6 => 0
  | 9,7 => (Polynomial.C (2:K))
  | 9,8 => 0
  | _,_ => 0

def bezoutB (i j : Fin 10) : K[X] :=
  match i,j with
  | 0,0 => (1)
  | 0,1 => 0
  | 0,2 => 0
  | 0,3 => 0
  | 0,4 => 0
  | 0,5 => 0
  | 0,6 => 0
  | 0,7 => 0
  | 0,8 => 0
  | 0,9 => 0
  | 1,0 => 0
  | 1,1 => 0
  | 1,2 => 0
  | 1,3 => 0
  | 1,4 => (1)
  | 1,5 => 0
  | 1,6 => 0
  | 1,7 => 0
  | 1,8 => (Polynomial.C (2:K))
  | 1,9 => (Polynomial.C (2:K))
  | 2,0 => 0
  | 2,1 => 0
  | 2,2 => 0
  | 2,3 => (1)
  | 2,4 => (1)
  | 2,5 => 0
  | 2,6 => (1)
  | 2,7 => 0
  | 2,8 => (Polynomial.C (2:K)+Polynomial.C (2:K)*X)
  | 2,9 => (Polynomial.C (2:K)+Polynomial.C (2:K)*X)
  | 3,0 => 0
  | 3,1 => (1)
  | 3,2 => (1)
  | 3,3 => 0
  | 3,4 => 0
  | 3,5 => 0
  | 3,6 => 0
  | 3,7 => (1)
  | 3,8 => (Polynomial.C (2:K)+Polynomial.C (2:K)*X)
  | 3,9 => (Polynomial.C (2:K)+Polynomial.C (2:K)*X)
  | 4,0 => 0
  | 4,1 => (1)
  | 4,2 => 0
  | 4,3 => 0
  | 4,4 => 0
  | 4,5 => 0
  | 4,6 => 0
  | 4,7 => 0
  | 4,8 => (Polynomial.C (2:K))
  | 4,9 => (Polynomial.C (2:K))
  | 5,0 => (1)
  | 5,1 => 0
  | 5,2 => 0
  | 5,3 => 0
  | 5,4 => 0
  | 5,5 => (1)
  | 5,6 => 0
  | 5,7 => 0
  | 5,8 => (Polynomial.C (2:K))
  | 5,9 => (Polynomial.C (2:K))
  | 6,0 => (1)
  | 6,1 => (1)
  | 6,2 => (Polynomial.C (2:K))
  | 6,3 => 0
  | 6,4 => 0
  | 6,5 => 0
  | 6,6 => 0
  | 6,7 => (1)
  | 6,8 => (Polynomial.C (2:K))
  | 6,9 => 0
  | 7,0 => (1)
  | 7,1 => 0
  | 7,2 => 0
  | 7,3 => (Polynomial.C (2:K))
  | 7,4 => (1)
  | 7,5 => 0
  | 7,6 => (1)
  | 7,7 => 0
  | 7,8 => 0
  | 7,9 => (Polynomial.C (2:K))
  | 8,0 => (1)
  | 8,1 => (1+X)
  | 8,2 => (Polynomial.C (2:K)+X)
  | 8,3 => (Polynomial.C (2:K)+X)
  | 8,4 => (1+X)
  | 8,5 => (X)
  | 8,6 => (1)
  | 8,7 => 0
  | 8,8 => (Polynomial.C (2:K))
  | 8,9 => (1)
  | 9,0 => (1)
  | 9,1 => (1+X)
  | 9,2 => (Polynomial.C (2:K)+X)
  | 9,3 => (Polynomial.C (2:K)+X)
  | 9,4 => (1+X)
  | 9,5 => (X)
  | 9,6 => 0
  | 9,7 => (1)
  | 9,8 => (1)
  | _,_ => (Polynomial.C (2:K))

def bezoutC (i j : Fin 10) : K[X] :=
  match i,j with
  | 0,0 => 0
  | 0,1 => (1)
  | 0,2 => (1)
  | 0,3 => (Polynomial.C (2:K))
  | 0,4 => (Polynomial.C (2:K))
  | 0,5 => 0
  | 0,6 => 0
  | 0,7 => 0
  | 0,8 => 0
  | 0,9 => 0
  | 1,0 => (1)
  | 1,1 => (Polynomial.C (2:K))
  | 1,2 => (Polynomial.C (2:K))
  | 1,3 => 0
  | 1,4 => 0
  | 1,5 => (1)
  | 1,6 => (Polynomial.C (2:K))
  | 1,7 => (Polynomial.C (2:K))
  | 1,8 => 0
  | 1,9 => 0
  | 2,0 => (1)
  | 2,1 => (Polynomial.C (2:K))
  | 2,2 => (Polynomial.C (2:K))
  | 2,3 => 0
  | 2,4 => 0
  | 2,5 => (1)
  | 2,6 => (Polynomial.C (2:K))
  | 2,7 => (Polynomial.C (2:K))
  | 2,8 => 0
  | 2,9 => 0
  | 3,0 => (Polynomial.C (2:K))
  | 3,1 => 0
  | 3,2 => 0
  | 3,3 => (1)
  | 3,4 => (1)
  | 3,5 => (Polynomial.C (2:K))
  | 3,6 => (1)
  | 3,7 => (1)
  | 3,8 => 0
  | 3,9 => 0
  | 4,0 => (Polynomial.C (2:K))
  | 4,1 => 0
  | 4,2 => 0
  | 4,3 => (1)
  | 4,4 => (1)
  | 4,5 => (Polynomial.C (2:K))
  | 4,6 => (1)
  | 4,7 => (1)
  | 4,8 => 0
  | 4,9 => 0
  | 5,0 => 0
  | 5,1 => (1)
  | 5,2 => (1)
  | 5,3 => (Polynomial.C (2:K))
  | 5,4 => (Polynomial.C (2:K))
  | 5,5 => 0
  | 5,6 => (1)
  | 5,7 => (Polynomial.C (2:K))
  | 5,8 => 0
  | 5,9 => 0
  | 6,0 => 0
  | 6,1 => (Polynomial.C (2:K))
  | 6,2 => (Polynomial.C (2:K))
  | 6,3 => (1)
  | 6,4 => (1)
  | 6,5 => (1)
  | 6,6 => (Polynomial.C (2:K))
  | 6,7 => 0
  | 6,8 => 0
  | 6,9 => (1)
  | 7,0 => 0
  | 7,1 => (Polynomial.C (2:K))
  | 7,2 => (Polynomial.C (2:K))
  | 7,3 => (1)
  | 7,4 => (1)
  | 7,5 => (Polynomial.C (2:K))
  | 7,6 => 0
  | 7,7 => (1)
  | 7,8 => (Polynomial.C (2:K))
  | 7,9 => 0
  | 8,0 => 0
  | 8,1 => 0
  | 8,2 => 0
  | 8,3 => 0
  | 8,4 => 0
  | 8,5 => 0
  | 8,6 => 0
  | 8,7 => (Polynomial.C (2:K))
  | 8,8 => (Polynomial.C (2:K)+Polynomial.C (2:K)*X)
  | 8,9 => 0
  | 9,0 => 0
  | 9,1 => 0
  | 9,2 => 0
  | 9,3 => 0
  | 9,4 => 0
  | 9,5 => 0
  | 9,6 => (1)
  | 9,7 => 0
  | 9,8 => 0
  | _,_ => (1+X)

macro "stoll_full_poly" : tactic =>
  `(tactic| (ring_nf <;> ((try simp only [←map_ofNat (Polynomial.C : K →+* K[X]),←map_mul (Polynomial.C : K →+* K[X]),←map_pow (Polynomial.C : K →+* K[X])]) <;> (ext n <;> ((try simp) <;> ((try split_ifs) <;> norm_num <;> (try simp_all) <;> decide))))))

theorem cert_0_0 : GeneralCantorRun (bezoutA 0 0)
    (bezoutB 0 0) (bezoutC 0 0) (point 0) (point 0)
    (point (expectedIndex 0 0)) := by
  refine ⟨(1),(1),0,0,(1),(1),0,(1+X^5),
    (by
      apply Polynomial.monic_of_degree_le 0
      · compute_degree!
      · norm_num),(by
      apply Polynomial.monic_of_degree_le 0
      · compute_degree!
      · norm_num),?_,?_,?_,?_,?_,?_,(by
      have hU : ((1):K[X]).degree=(0:WithBot ℕ) := by
        apply Polynomial.degree_eq_of_le_of_coeff_ne_zero
        · compute_degree!
        · norm_num
      rw [hU]
      simp),?_,Or.inl ⟨(by
      have hU : ((1):K[X]).natDegree=0 := by
        apply Polynomial.natDegree_eq_of_le_of_coeff_ne_zero
        · compute_degree!
        · norm_num
      rw [hU]
      norm_num),?_,?_⟩⟩
  all_goals norm_num [bezoutA,bezoutB,bezoutC,expectedIndex,repPerm,
    point,candidatePair,representative,uPolynomial,vPolynomial,curvePolynomial]
  all_goals stoll_full_poly

theorem cert_2_6 : GeneralCantorRun (bezoutA 2 6)
    (bezoutB 2 6) (bezoutC 2 6) (point 2) (point 6)
    (point (expectedIndex 2 6)) := by
  refine ⟨(1),(X^3+X^4),(1+X^3),(1+Polynomial.C (2:K)*X),(X^2),(X+X^2),(Polynomial.C (2:K)+X),(1+Polynomial.C (2:K)*X+Polynomial.C (2:K)*X^2),
    (by
      apply Polynomial.monic_of_degree_le 0
      · compute_degree!
      · norm_num),(by
      apply Polynomial.monic_of_degree_le 4
      · compute_degree!
      · norm_num),?_,?_,?_,?_,?_,?_,(by
      have hU : ((X^3+X^4):K[X]).degree=(4:WithBot ℕ) := by
        apply Polynomial.degree_eq_of_le_of_coeff_ne_zero
        · compute_degree!
        · norm_num
      rw [hU]
      apply lt_of_le_of_lt (show ((1+X^3):K[X]).degree≤(3:WithBot ℕ) from by compute_degree!)
      norm_num),?_,Or.inr ⟨(by
      have hU : ((X^3+X^4):K[X]).natDegree=4 := by
        apply Polynomial.natDegree_eq_of_le_of_coeff_ne_zero
        · compute_degree!
        · norm_num
      rw [hU]
      norm_num),(2:K),(1+Polynomial.C (2:K)*X),(by decide),?_,?_⟩⟩
  all_goals norm_num [bezoutA,bezoutB,bezoutC,expectedIndex,repPerm,
    point,candidatePair,representative,uPolynomial,vPolynomial,curvePolynomial]
  all_goals stoll_full_poly

theorem cert_9_9 : GeneralCantorRun (bezoutA 9 9)
    (bezoutB 9 9) (bezoutC 9 9) (point 9) (point 9)
    (point (expectedIndex 9 9)) := by
  refine ⟨(1),(1+X+Polynomial.C (2:K)*X^2+Polynomial.C (2:K)*X^3+X^4),(1+X+Polynomial.C (2:K)*X^2),(Polynomial.C (2:K)*X+X^2),(Polynomial.C (2:K)+X+X^2),(Polynomial.C (2:K)+X+X^2),(X),(X),
    (by
      apply Polynomial.monic_of_degree_le 0
      · compute_degree!
      · norm_num),(by
      apply Polynomial.monic_of_degree_le 4
      · compute_degree!
      · norm_num),?_,?_,?_,?_,?_,?_,(by
      have hU : ((1+X+Polynomial.C (2:K)*X^2+Polynomial.C (2:K)*X^3+X^4):K[X]).degree=(4:WithBot ℕ) := by
        apply Polynomial.degree_eq_of_le_of_coeff_ne_zero
        · compute_degree!
        · norm_num
      rw [hU]
      apply lt_of_le_of_lt (show ((1+X+Polynomial.C (2:K)*X^2):K[X]).degree≤(2:WithBot ℕ) from by compute_degree!)
      norm_num),?_,Or.inr ⟨(by
      have hU : ((1+X+Polynomial.C (2:K)*X^2+Polynomial.C (2:K)*X^3+X^4):K[X]).natDegree=4 := by
        apply Polynomial.natDegree_eq_of_le_of_coeff_ne_zero
        · compute_degree!
        · norm_num
      rw [hU]
      norm_num),(1:K),(Polynomial.C (2:K)+X),(by decide),?_,?_⟩⟩
  all_goals norm_num [bezoutA,bezoutB,bezoutC,expectedIndex,repPerm,
    point,candidatePair,representative,uPolynomial,vPolynomial,curvePolynomial]
  all_goals stoll_full_poly


#print axioms cert_0_0
#print axioms cert_2_6
#print axioms cert_9_9
end
end MumfordStollFullCertificatesAudit
