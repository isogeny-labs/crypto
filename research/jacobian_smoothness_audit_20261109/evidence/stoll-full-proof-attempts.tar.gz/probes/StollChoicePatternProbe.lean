import MumfordStollGeneral

/-! Candidate certificates are accepted only by the Lean kernel below.
Bezout choices are fixed before defining the deterministic arithmetic. -/
namespace MumfordStollFullCertificatesAudit
noncomputable section
open Polynomial MumfordStollAudit MumfordStollGeneralAudit
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1200000

attribute [local simp] Polynomial.coeff_C Polynomial.coeff_one Polynomial.coeff_zero
  Polynomial.coeff_X_pow Polynomial.coeff_X Polynomial.coeff_mul_C Polynomial.coeff_C_mul
  Polynomial.coeff_add Polynomial.coeff_sub Polynomial.coeff_neg
  MumfordStollCantorAudit.coefficient_constant_power

def repPerm (i : Fin 10) : Fin 10 :=
  match i with
  | 0 => 0
  | 1 => 6
  | 2 => 2
  | 3 => 8
  | 4 => 4
  | 5 => 5
  | 6 => 1
  | 7 => 9
  | 8 => 3
  | _ => 7

def expectedIndex (i j : Fin 10) : Fin 10 := repPerm (repPerm i+repPerm j)

-- Candidate Bezout choices only. Their equations must be proved by Lean.
def bezoutA (i j : Fin 10) : K[X] :=
  match i,j with
  | 0,0 => 0
  | 0,1 => 0
  | 0,2 => 0
  | 0,3 => 0
  | 0,4 => 0
  | 0,5 => (1)
  | 0,6 => (1)
  | 0,7 => (1)
  | 0,8 => (1)
  | 0,9 => (1)
  | 1,0 => 0
  | 1,1 => 0
  | 1,2 => 0
  | 1,3 => (1)
  | 1,4 => 0
  | 1,5 => 0
  | 1,6 => (1)
  | 1,7 => 0
  | 1,8 => (1+X)
  | 1,9 => (1+X)
  | 2,0 => 0
  | 2,1 => 0
  | 2,2 => 0
  | 2,3 => 0
  | 2,4 => 0
  | 2,5 => 0
  | 2,6 => (Polynomial.C (2:K))
  | 2,7 => 0
  | 2,8 => (Polynomial.C (2:K)+X)
  | 2,9 => (Polynomial.C (2:K)+X)
  | 3,0 => 0
  | 3,1 => 0
  | 3,2 => 0
  | 3,3 => 0
  | 3,4 => 0
  | 3,5 => 0
  | 3,6 => 0
  | 3,7 => (Polynomial.C (2:K))
  | 3,8 => (Polynomial.C (2:K)+X)
  | 3,9 => (Polynomial.C (2:K)+X)
  | 4,0 => 0
  | 4,1 => 0
  | 4,2 => (1)
  | 4,3 => 0
  | 4,4 => 0
  | 4,5 => 0
  | 4,6 => 0
  | 4,7 => (1)
  | 4,8 => (1+X)
  | 4,9 => (1+X)
  | 5,0 => 0
  | 5,1 => 0
  | 5,2 => 0
  | 5,3 => 0
  | 5,4 => 0
  | 5,5 => 0
  | 5,6 => 0
  | 5,7 => 0
  | 5,8 => (X)
  | 5,9 => (X)
  | 6,0 => 0
  | 6,1 => 0
  | 6,2 => (1)
  | 6,3 => 0
  | 6,4 => 0
  | 6,5 => 0
  | 6,6 => 0
  | 6,7 => 0
  | 6,8 => (1)
  | 6,9 => 0
  | 7,0 => 0
  | 7,1 => 0
  | 7,2 => 0
  | 7,3 => (1)
  | 7,4 => 0
  | 7,5 => 0
  | 7,6 => 0
  | 7,7 => 0
  | 7,8 => 0
  | 7,9 => (1)
  | 8,0 => 0
  | 8,1 => (Polynomial.C (2:K))
  | 8,2 => (Polynomial.C (2:K)+Polynomial.C (2:K)*X)
  | 8,3 => (Polynomial.C (2:K)+Polynomial.C (2:K)*X)
  | 8,4 => (Polynomial.C (2:K))
  | 8,5 => (Polynomial.C (2:K))
  | 8,6 => (Polynomial.C (2:K))
  | 8,7 => 0
  | 8,8 => 0
  | 8,9 => 0
  | 9,0 => 0
  | 9,1 => (Polynomial.C (2:K))
  | 9,2 => (Polynomial.C (2:K)+Polynomial.C (2:K)*X)
  | 9,3 => (Polynomial.C (2:K)+Polynomial.C (2:K)*X)
  | 9,4 => (Polynomial.C (2:K))
  | 9,5 => (Polynomial.C (2:K))
  | 9,6 => 0
  | 9,7 => (Polynomial.C (2:K))
  | 9,8 => 0
  | _,_ => 0


#check bezoutA
end
end MumfordStollFullCertificatesAudit
