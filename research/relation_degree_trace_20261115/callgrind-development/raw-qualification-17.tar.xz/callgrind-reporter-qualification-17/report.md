# Native candidate instruction diagnosis

Qualification only: **true**. qualification-only. One whole-process guest-instruction profile; generation/preparation and parent capture excluded. No native time/cycle estimate, speed ratio, A/A admission, confidence interval, new target or degree-of-regularity conclusion. [pcc:unverified]

The complete checked canonical answer equals the frozen uninstrumented candidate. Executable/runtime hashes are unchanged. Total guest Ir: **23765993**, across700 attributed functions. Rust recomputation matches both raw summary/totals, every function row and the independent-format Collected line in the profiler log. This is producer recomputation, not signed independent execution verification. [pcc:unverified]

Self costs are exclusive and add to total. Inclusive costs include callees, overlap and must not be added across functions. Inlined instructions belong to their containing compiled functions. Startup, libraries, allocation and exact checking remain included; instrumented dispatch can differ from native hardware dispatch. [pcc:unverified]

## Largest self costs

| Rank | Function | Self Ir | Fraction of all Ir | Inclusive Ir (overlaps) |
|---:|---|---:|---:|---:|
| 1 | certified_relations::axpy::<alloc::vec::Vec<usize>> | 3288644 | 13.838% | 8212393 |
| 2 | free | 2405008 | 10.120% | 2915593 |
| 3 | <alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::insert | 2367992 | 9.964% | 3386179 |
| 4 | malloc | 1536944 | 6.467% | 2265509 |
| 5 | <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<usize>, core::slice::iter::Iter<usize>>, certified_relations::plus::{closure#0}>>>::from_iter | 1105442 | 4.651% | 2005504 |
| 6 | <alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Owned, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::LeafOrInternal>>::bulk_push::<alloc::collections::btree::dedup_sorted_iter::DedupSortedIter<alloc::vec::Vec<usize>, u64, alloc::vec::into_iter::IntoIter<(alloc::vec::Vec<usize>, u64)>>, alloc::alloc::Global> | 799344 | 3.363% | 1173176 |
| 7 | 0x00000000000a0fe0 | 695047 | 2.925% | 850121 |
| 8 | <core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<(alloc::vec::Vec<usize>, u64), <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)>>::extend_trusted<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}> | 675397 | 2.842% | 2469828 |
| 9 | <core::iter::adapters::map::Map<alloc::collections::btree::map::Keys<alloc::vec::Vec<usize>, u64>, certified_relations::degree::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::cmp::Ord>::max> | 653115 | 2.748% | 653115 |
| 10 | certified_relations::lead | 573221 | 2.412% | 573221 |
| 11 | certified_relations::quotient::rewrite | 529398 | 2.228% | 9103455 |
| 12 | <alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64>>::remove::<alloc::vec::Vec<usize>> | 514417 | 2.165% | 1113192 |
| 13 | 0x00000000000a02e0 | 499307 | 2.101% | 513777 |
| 14 | <alloc::collections::btree::map::IntoIter<alloc::vec::Vec<usize>, u64>>::dying_next | 482629 | 2.031% | 600726 |
| 15 | relation_replay_checker::add_term | 376545 | 1.584% | 954576 |
| 16 | core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(alloc::vec::Vec<usize>, u64), <[(alloc::vec::Vec<usize>, u64)]>::sort_by<<alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64> as core::iter::traits::collect::FromIterator<(alloc::vec::Vec<usize>, u64)>>::from_iter<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}> | 347355 | 1.462% | 347355 |
| 17 | 0x0000000000162880 | 344056 | 1.448% | 344056 |
| 18 | __rustc::__rdl_alloc | 335844 | 1.413% | 2598830 |
| 19 | certified_relations::axpy::<(usize, alloc::vec::Vec<usize>)> | 313140 | 1.318% | 703965 |
| 20 | 0x0000000000162120 | 247919 | 1.043% | 247919 |
| 21 | <alloc::collections::btree::map::BTreeMap<(usize, alloc::vec::Vec<usize>), u64>>::insert | 210928 | 0.888% | 304034 |
| 22 | <alloc::collections::btree::node::Handle<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Dying, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::Leaf>, alloc::collections::btree::node::marker::Edge>>::deallocating_next::<alloc::alloc::Global> | 205868 | 0.866% | 205868 |
| 23 | __umodti3 | 202300 | 0.851% | 202300 |
| 24 | certified_relations::normal_form | 185349 | 0.780% | 2021272 |
| 25 | <alloc::collections::btree::node::Handle<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut, alloc::vec::Vec<usize>, u64, alloc::collections::btree::node::marker::Leaf>, alloc::collections::btree::node::marker::Edge>>::insert_recursing::<alloc::alloc::Global, <alloc::collections::btree::map::entry::VacantEntry<alloc::vec::Vec<usize>, u64>>::insert_entry::{closure#0}> | 181714 | 0.765% | 253795 |

## Native constructor and separate checker: largest inclusive counts

| Function | Self Ir | Inclusive Ir (overlaps) |
|---|---:|---:|
| certified_relations::replay::produce_native_for_rust | 135 | 20374187 |
| certified_relations::replay::native_product_impl | 250 | 20001187 |
| certified_relations::quotient::compact::solve_sparse_impl | 36 | 18449848 |
| certified_relations::quotient::compact::solve_impl | 3469 | 18449783 |
| certified_relations::quotient::rewrite | 529398 | 9103455 |
| certified_relations::axpy::<alloc::vec::Vec<usize>> | 3288644 | 8212393 |
| <alloc::collections::btree::map::BTreeMap<alloc::vec::Vec<usize>, u64> as core::iter::traits::collect::FromIterator<(alloc::vec::Vec<usize>, u64)>>::from_iter::<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>> | 129953 | 4452781 |
| certified_relations::verify | 178813 | 4429911 |
| certified_relations::projection::subset_quadratic | 2252 | 4006316 |
| certified_relations::row_shift | 99172 | 3209439 |
| certified_relations::quotient::compact::verify_impl | 6566 | 2824878 |
| relation_replay_checker::verify_json | 7119 | 2717923 |
| <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)> as alloc::vec::spec_from_iter::SpecFromIter<(alloc::vec::Vec<usize>, u64), core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>>::from_iter | 116759 | 2702650 |
| <core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<(alloc::vec::Vec<usize>, u64), <alloc::vec::Vec<(alloc::vec::Vec<usize>, u64)>>::extend_trusted<core::iter::adapters::map::Map<alloc::collections::btree::map::Iter<alloc::vec::Vec<usize>, u64>, certified_relations::shift::{closure#0}>>::{closure#0}>::{closure#0}> | 675397 | 2469828 |
| certified_relations::normal_form | 185349 | 2021272 |
| <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<usize>, core::slice::iter::Iter<usize>>, certified_relations::plus::{closure#0}>>>::from_iter | 1105442 | 2005504 |
| <relation_replay_checker::Arithmetic>::identity | 171813 | 1591612 |
| certified_relations::projection::quadratic_resultant | 9026 | 1399943 |
| certified_relations::check_reference_impl | 1157 | 1370774 |
| <certified_relations::quotient::compact::Chain>::push | 443 | 1361303 |
| certified_relations::replay::complete_impl | 2203 | 1305934 |
| certified_relations::replay::quotient_witness | 5918 | 1046785 |
| certified_relations::projection::times | 41998 | 1037626 |
| relation_replay_checker::add_term | 376545 | 954576 |
| certified_relations::quotient::coordinate | 4568 | 928705 |

All functions, object paths, counters, raw call graph and exact answer remain in the raw archive and functions.json. Counts describe this compiled binary/input under Callgrind. They can guide a subsequent explicitly qualified optimization; they do not predict its native gain. [pcc:unverified]

![Largest exclusive guest instruction counts](self.svg){width=95%}

Numbers on the vertical axis map to the self-cost table.
