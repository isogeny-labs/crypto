# Direct two-cubic repeated comparison

Fixed development seed7 at p2147483647. Common original reference/generation/preparation fees and all per-route identity/full-basis checks are paid. Ratios are control/direct-prefix; above1 favors prefix. A/A rejections remain descriptive, never admitted. Unsigned producer evidence. [pcc:unverified]

|n|Control|Work median|Work adjusted lower|Paid median|Paid adjusted lower|All A/A pass|
|---|---|---:|---:|---:|---:|---|

Replayed answers:4. Monitor valid:true. Sustained gain across all cases and all controls/scopes:false. No pooling or replacement. Every panel, phase, failed attempt, identity and native replay wire remains in raw records. Phase clocks are descriptive; parent remainder has no established physical attribution. [pcc:unverified]
