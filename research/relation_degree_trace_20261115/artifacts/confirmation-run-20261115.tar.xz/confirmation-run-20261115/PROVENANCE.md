Measured worker and campaign are immutable byte copies of source commit
2471e4c16bbcb85410017bf8ea5d05703f5ce215, matching the final exploration.
Fresh exporter and seed protocol were published at
4418b8da6ed9604d15ffce7034c208429000a131 before final projected observations.
Seeds 1009/2003/3001; four variables; both original primes. Entire six-case
panel retained, no replacements or sample pooling. Local L0, same CPU and
charges, same 21 pairs/seven controls/threshold. Every field/ideal check remains.
Raw host.json's legacy SPEED_PROTOCOL label is the shared driver's label;
CONFIRMATION_PROTOCOL.md is the actual contract for this run. No compiler or
CAS workload is run during this timed confirmation. Producer-only observation,
no signed independent verdict.
