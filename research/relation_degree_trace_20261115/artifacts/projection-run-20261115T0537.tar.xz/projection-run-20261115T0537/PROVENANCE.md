Source commit: 3519e454bccefcba31d1be485bf4d943472e8dd8.
Protocol: PROJECTION_PROTOCOL.md, same committed 24 known-answer fixtures.
Backend: explicitly proceeding with the offered local workspace option after
user's Continue. No cloud resources. One allowed CPU; raw host/affinity in
host.json. Worker address-space cap 2 GiB, 30 seconds; global 20-minute cap.
All construction and membership checking charged; failed cases stop without
retry. Exact basis equality checked against the paired native baseline.
No compiler or concurrent CAS benchmark is run during the timed campaign.
Initial cubic-only campaign remains separately preserved and interrupted.
Numerical observations are producer-only, with no independent signed verdict.
