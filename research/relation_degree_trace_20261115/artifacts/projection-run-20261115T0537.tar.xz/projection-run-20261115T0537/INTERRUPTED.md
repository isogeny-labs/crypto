Stopped at approximately 05:42 UTC after completing the two-, three-, and
four-variable panel on both fields. Static review found that the old failure
stop still entered A/A after a failed first pair; that would repeat the known
six-variable timeout. Parent 14809 and its six-variable worker 15892 were
terminated before that repeated failure path. All completed results and the
partial attempt remain. The full 24-case campaign is incomplete; no missing
six-variable sample is a win. Corrected controls only start after successful
arms, with a regression test. This is a disclosed harness interruption.

Correction from process/file inspection: worker 15892 had already exited before
the kill command. The old driver had entered aa-00-first, leaving orphan worker
15899 when its parent was killed. That worker was also terminated. The empty
A/A files and original timed-out baseline are retained. The intended stop was
not early enough to prevent the first control retry; no such run is admitted.
