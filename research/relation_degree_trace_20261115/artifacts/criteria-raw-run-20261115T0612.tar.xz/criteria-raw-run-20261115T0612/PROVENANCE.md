Source 2471e4c16bbcb85410017bf8ea5d05703f5ce215. CRITERIA_PROTOCOL.md.
Local L0, full fixed case roster, raw-input engine ablation. Common lean final
checker on both arms; old S-pair construction on baseline, initial
interreduction/product criterion on candidate. Every membership and final
S-pair check remains. No build/CAS workload runs during measurement.
Results are exploratory producer observations without signed validation.
