Campaign stopped on 2026-11-15 at approximately 05:34 UTC after identifying
repeated worker timeouts in the first six-variable case. The old driver did
not stop a case after a failed attempt. Parent PID 13599 and current worker
14211 were sent SIGTERM; outputs and completed summaries are preserved.
There is no completed whole-campaign summary. Missing cases/samples are not
successful observations. This interruption is a disclosed harness correction.
The successor protocol preserves the same per-case thresholds and charges,
interleaves fields, and stops deterministic failures without retries.
