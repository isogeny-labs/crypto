# Fixed development relation ablations

Single bounded calls on public known-answer seed7 fixtures. No statistical speedup admission. Exact F4 observed degree, affine closure threshold, and top-form Hilbert first vanishing are different quantities. Missing/capped values remain null. Unsigned localL0. [pcc:unverified]

| n | Class | Added | Same ideal | F4 degree | Max rows | Max columns | Affine closure | Top-form vanishing | Paid ms |
|---|---|---:|---|---:|---:|---:|---:|---:|---:|
|3|star|0|true|5|34|37|5|null|80.316548|
|3|root-projection|1|true|5|29|37|5|null|53.810703|
|3|nonroot-projections|0|true|5|34|37|5|null|46.698476|
|3|all-projections|1|true|5|29|37|5|null|56.742450|
|3|leaf-closure|0|true|5|33|43|5|null|57.529967|
|3|clique|0|true|5|33|43|5|null|53.147501|

Flow: planned 6, attempted 6, cells with recorded failures 0. All rows retained; no statistical pooling. [pcc:unverified]

Paid costs include generation, preparation, full projection construction even for subset arms, exact identity checking, fresh3CAS references and the complete checked F4 call. Reference/oracle construction and separate diagnostic costs are retained in audit.json; diagnostic time is not production solver speed. F4 matrix nonzeros/fill are unavailable when the unchanged worker does not emit them; affine diagnostic nonzeros are not substitutes. Geometric additions may change the ideal; equal checked complete canonical bases determine the label. Capped closure/Hilbert is not an intrinsic regularity or impossibility result. Star leaf projections may be absent; duplicate/effectively identical arms remain. [pcc:unverified]
