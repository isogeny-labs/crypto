# Recorded "graph-screen"

18 declared cases. Selected follow-up: null. Unsigned producer L0 single-call evidence; no interval, independent execution coverage or confirmed 10x/15x gain. All preparation, mature references and per-call checking are paid. Missing/failed arms have no numeric win. [pcc:unverified]

| Case | Outcome | F4 degree | F4 max columns | Compact proof terms | Paid F4/compact | Paid expanded/compact |
|---|---|---:|---:|---:|---:|---:|
| path-n6-s7 | "screen_complete" | 5 | 174 | 442 | 0.907x | 3.110x |
| balanced-n6-s7 | "screen_complete" | 5 | 171 | 442 | 0.902x | 1.815x |
| star-n6-s7 | "screen_complete" | 5 | 175 | 226 | 0.983x | 1.485x |
| permuted-cycle-n6-s7 | "screen_complete" | 5 | 193 | 442 | 0.887x | 3.984x |
| path-n7-s7 | "screen_complete" | 5 | 265 | 537 | 0.936x | 8.024x |
| balanced-n7-s7 | "screen_complete" | 5 | 271 | 537 | 1.098x | 1.685x |
| star-n7-s7 | "screen_complete" | 5 | 245 | 249 | 0.937x | 1.302x |
| permuted-cycle-n7-s7 | "screen_complete" | 5 | 316 | 537 | 0.892x | 4.743x |
| path-n8-s7 | "screen_complete" | 5 | 375 | 632 | 0.882x | 18.826x |
| balanced-n8-s7 | "screen_complete" | 5 | 345 | 632 | 0.856x | 4.460x |
| star-n8-s7 | "screen_complete" | 5 | 327 | 272 | 0.942x | 1.292x |
| permuted-cycle-n8-s7 | "screen_complete" | 5 | 423 | 632 | 0.995x | 10.071x |
| star-first-n6-s7 | "screen_complete" | 5 | 279 | 251 | 0.935x | 1.319x |
| balanced-first-n6-s7 | "screen_complete" | 5 | 196 | 442 | 0.884x | 2.713x |
| star-first-n7-s7 | "screen_complete" | 5 | 435 | 275 | 0.887x | 1.186x |
| balanced-first-n7-s7 | "screen_complete" | 5 | 291 | 537 | 0.947x | 2.718x |
| star-first-n8-s7 | "screen_complete" | 5 | 641 | 299 | 0.981x | 1.295x |
| balanced-first-n8-s7 | "screen_complete" | 5 | 415 | 632 | 0.911x | 13.376x |

F4 degree is the completed worker's observed productive degree, not intrinsic regularity. The native packed grevlex path is used only through15 variables;16 uses its existing vector fallback. No solver path was disabled or retuned. [pcc:unverified]

![Paid single-call ratios](ratios.svg){width=80%}

Blue=F4/compact; orange=expanded/compact. No point is drawn for an incomplete comparison. Each point is one planned call, with no confidence interval. The original null-selection screen and its frozen protocols remain intact. [pcc:unverified]
