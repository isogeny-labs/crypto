# Fresh matched native comparison

PCC-20261116-f350ed. Qualification:true; monitor admission:true. Three native routes use identical complete proof checking and identical common fees. Prior fastest is the primary comparison; matched same-source39 is the secondary control. Unsigned localL0; original family holdouts remain untouched. [pcc:unverified]

| Case | Control | Work median | Paid median | Work adjusted lower | Paid adjusted lower | Paid/shared ceiling |
|---|---|---:|---:|---:|---:|---:|

## Separate phase diagnostics (milliseconds)

| Case | Mode | Input parse | Construction/wire | Wire write | Root replay | Parent remainder |
|---|---|---:|---:|---:|---:|---:|
| qualification-n3-s7 | streamed | 0.036084 | 2.605311 | 0.046731 | 0.407501 | 7.669846 |
| qualification-n3-s7 | frontier | 0.034963 | 1.943452 | 0.150096 | 0.289695 | 5.377023 |

3 captured uninstrumented answers replayed from original bytes/wires; all-case increment flag:false. Monitor-valid result requires:true. A rejected/incomplete case is never pooled away. [pcc:unverified]

Generation/preparation and complete fresh3CAS references are fully charged to every route without amortization; native work already includes construction/full native checks/root replay/output consumption. The conditional ceiling assumes only candidate work becomes free while the same shared fee remains; it is not a global complexity bound. Instrumented phase calls and capture/report/statistic overhead are separate study costs and never mixed into these ratios. All raw calls/failures/AA/main/phase details remain. [pcc:unverified]

![Paid ratios](ratios.svg){width=90%}
