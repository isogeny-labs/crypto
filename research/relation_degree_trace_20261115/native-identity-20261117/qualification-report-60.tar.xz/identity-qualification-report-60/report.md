# Native identity-check repeated comparison

Fixed development seed7 at p2147483647. Common original reference/generation/preparation fees and all per-route identity/full-basis checks are paid. Ratios are prefix-Singular/prefix-Rust,frontier-Rust/prefix-Rust,and frontier-Singular/frontier-Rust. A/A rejections remain descriptive, never admitted. Unsigned producer evidence. [pcc:unverified]

|n|Control|Work median|Work adjusted lower|Paid median|Paid adjusted lower|Simultaneous A/A pass|
|---|---|---:|---:|---:|---:|---|

Replayed answers:4. Monitor valid:true. Sustained primary gain across all cases/scopes:false. No pooling or replacement. Every panel, phase, failed attempt, identity and native replay wire remains in raw records. Phase clocks are descriptive; parent remainder has no established physical attribution. [pcc:unverified]
