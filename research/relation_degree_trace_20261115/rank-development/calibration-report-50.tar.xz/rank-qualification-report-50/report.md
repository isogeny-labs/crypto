# Budgeted early-rank relation study

Fixed development p2147483647,seed7. Rank gain is a proxy; actual F4, affine closure and top-form Hilbert remain separate. Single-call times descriptive, no speedup admission. [pcc:unverified]

|n|Class|Rows added|Early rank gain|F4 degree|Max rows|Max columns|Affine threshold|Top-form vanishing|Build ms|Paid ms|
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|3|star|0|null|5|34|37|5|null|5.016404|124.239047|
|3|differences|2|null|5|34|37|5|null|5.805410|56.691379|
|3|syzygies|2|null|4|26|30|4|6|7.230241|62.296533|
|3|both|4|null|4|26|30|4|5|6.147674|58.611373|
|3|rank-budget|2|8|4|26|30|4|6|5.221232|57.063756|
|3|count-control|2|0|5|34|37|5|null|6.409528|57.369708|

Flow:planned/attempted 6, cells with recorded failures 0. All retained. [pcc:unverified]

|n|Class|Generation ms|Build/selection ms|Prepare ms|Identity check ms|All3 refs ms|Checked F4 ms|Separate diagnostic ms|
|---|---|---:|---:|---:|---:|---:|---:|---:|
|3|star|0.048022|5.016404|0.156745|29.958124|83.394613|5.665139|37.069821|
|3|differences|0.029394|5.805410|0.535605|12.590627|32.635600|5.094743|29.792600|
|3|syzygies|0.029494|7.230241|0.655625|13.462782|35.990690|4.927701|23.321329|
|3|both|0.028103|6.147674|0.334001|12.637312|33.722523|5.741760|18.571020|
|3|rank-budget|0.028082|5.221232|0.638529|11.711822|34.367652|5.096439|23.058706|
|3|count-control|0.028503|6.409528|0.542385|13.150292|32.357277|4.881723|35.148946|

Early rank gain is for the actually exported rows. The count-control pays the identical selector but exports differences; hypothetical winning gains remain separately archived. Full discovery/selection/serialization/process/native/external checks and all3 reference fees are paid. Separate affine/Hilbert diagnostics are outside the paid F4 clock; reference/oracle fees remain in it. F4 nonzeros/fill absent, not zero. No intrinsic regularity or15x claim. [pcc:unverified]
