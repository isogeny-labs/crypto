# Native candidate instruction diagnosis

Qualification only: **true**. PCC-20261116-20de46. One whole-process guest-instruction profile; generation/preparation and parent capture excluded. No native time/cycle estimate, speed ratio, A/A admission, confidence interval, new target or degree-of-regularity conclusion. [pcc:unverified]

The complete checked canonical answer equals the frozen uninstrumented candidate. Executable/runtime hashes are unchanged. Total guest Ir: **20525131**, across707 attributed functions. Rust recomputation matches both raw summary/totals, every function row and the separately formatted Collected line from the same profiler. This is producer recomputation, not signed independent execution verification. [pcc:unverified]

Self costs are exclusive and add to total. Inclusive costs include callees, overlap and must not be added across functions. Inlined instructions belong to their containing compiled functions. Startup, libraries, allocation and exact checking remain included; instrumented dispatch can differ from native hardware dispatch. [pcc:unverified]

Function names longer than110 characters are abbreviated in tables; full names and object paths remain in functions.json.

## Largest self costs

| Rank | Function | Self Ir | Fraction of all Ir | Inclusive Ir (overlaps) |
|---:|---|---:|---:|---:|
| 1 | certified_relations::axpy_in_place::&lt;alloc::vec::Vec&lt;usize&gt;&gt; | 3011170 | 14.671% | 5382089 |
| 2 | free | 1852837 | 9.027% | 2352960 |
| 3 | malloc | 1187980 | 5.788% | 1910212 |
| 4 | &lt;alloc::vec::Vec&lt;usize&gt; as alloc::vec::spec_from_iter_nested::SpecFromIterNested&lt;usize, core::iter::adapter... | 1105442 | 5.386% | 1998745 |
| 5 | &lt;alloc::collections::btree::map::BTreeMap&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;&gt;::insert | 898018 | 4.375% | 1374436 |
| 6 | &lt;alloc::collections::btree::node::NodeRef&lt;alloc::collections::btree::node::marker::Owned, alloc::vec::Vec&lt;u... | 799344 | 3.894% | 1169911 |
| 7 | 0x00000000000a0fe0 | 687733 | 3.351% | 841500 |
| 8 | &lt;core::iter::adapters::map::Map&lt;alloc::collections::btree::map::Iter&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;, certifie... | 675397 | 3.291% | 2467673 |
| 9 | &lt;core::iter::adapters::map::Map&lt;alloc::collections::btree::map::Keys&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;, certifie... | 653115 | 3.182% | 653115 |
| 10 | certified_relations::quotient::rewrite | 529398 | 2.579% | 7893969 |
| 11 | &lt;alloc::collections::btree::map::BTreeMap&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;&gt;::remove::&lt;alloc::vec::Vec&lt;usize&gt;&gt; | 514417 | 2.506% | 1112046 |
| 12 | 0x00000000000a02e0 | 488996 | 2.382% | 503238 |
| 13 | &lt;alloc::collections::btree::map::IntoIter&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;&gt;::dying_next | 482629 | 2.351% | 600750 |
| 14 | relation_replay_checker::add_term | 376545 | 1.835% | 954576 |
| 15 | core::slice::sort::shared::smallsort::insertion_sort_shift_left::&lt;(alloc::vec::Vec&lt;usize&gt;, u64), &lt;[(alloc::... | 347355 | 1.692% | 347355 |
| 16 | certified_relations::axpy_in_place::&lt;(usize, alloc::vec::Vec&lt;usize&gt;)&gt; | 298332 | 1.453% | 497030 |
| 17 | __rustc::__rdl_alloc | 259254 | 1.263% | 2166943 |
| 18 | 0x0000000000162880 | 258409 | 1.259% | 258409 |
| 19 | 0x0000000000162120 | 244731 | 1.192% | 244731 |
| 20 | certified_relations::lead | 216945 | 1.057% | 216945 |
| 21 | &lt;alloc::collections::btree::node::Handle&lt;alloc::collections::btree::node::NodeRef&lt;alloc::collections::btree... | 205868 | 1.003% | 205868 |
| 22 | certified_relations::normal_form | 184597 | 0.899% | 1542366 |
| 23 | &lt;alloc::collections::btree::node::Handle&lt;alloc::collections::btree::node::NodeRef&lt;alloc::collections::btree... | 181714 | 0.885% | 253855 |
| 24 | certified_relations::verify | 178813 | 0.871% | 3388086 |
| 25 | &lt;alloc::collections::btree::node::Handle&lt;alloc::collections::btree::node::NodeRef&lt;alloc::collections::btree... | 178359 | 0.869% | 290572 |

## Native constructor and separate checker: largest inclusive counts

| Function | Self Ir | Inclusive Ir (overlaps) |
|---|---:|---:|
| certified_relations::replay::produce_native_for_rust_with_kernels | 34 | 17122057 |
| certified_relations::replay::produce_native_for_rust | 135 | 17122018 |
| certified_relations::replay::native_product_impl | 250 | 16748797 |
| certified_relations::quotient::compact::solve_sparse_impl | 36 | 15423744 |
| certified_relations::quotient::compact::solve_impl | 3469 | 15423679 |
| certified_relations::quotient::rewrite | 529398 | 7893969 |
| certified_relations::axpy::&lt;alloc::vec::Vec&lt;usize&gt;&gt; | 69390 | 5451479 |
| certified_relations::axpy_in_place::&lt;alloc::vec::Vec&lt;usize&gt;&gt; | 3011170 | 5382089 |
| &lt;alloc::collections::btree::map::BTreeMap&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt; as core::iter::traits::collect::From... | 129953 | 4447094 |
| certified_relations::verify | 178813 | 3388086 |
| certified_relations::row_shift | 99172 | 3204932 |
| certified_relations::projection::subset_quadratic | 2252 | 3197784 |
| relation_replay_checker::verify_json | 7119 | 2721890 |
| &lt;alloc::vec::Vec&lt;(alloc::vec::Vec&lt;usize&gt;, u64)&gt; as alloc::vec::spec_from_iter::SpecFromIter&lt;(alloc::vec::Ve... | 116759 | 2700709 |
| &lt;core::iter::adapters::map::Map&lt;alloc::collections::btree::map::Iter&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;, certifie... | 675397 | 2467673 |
| certified_relations::quotient::compact::verify_impl | 6566 | 2227247 |
| &lt;alloc::vec::Vec&lt;usize&gt; as alloc::vec::spec_from_iter_nested::SpecFromIterNested&lt;usize, core::iter::adapter... | 1105442 | 1998745 |
| &lt;relation_replay_checker::Arithmetic&gt;::identity | 171813 | 1591732 |
| certified_relations::normal_form | 184597 | 1542366 |
| certified_relations::projection::quadratic_resultant | 9026 | 1160593 |
| certified_relations::check_reference_impl | 1157 | 1083261 |
| certified_relations::replay::complete_impl | 2203 | 1080181 |
| &lt;certified_relations::quotient::compact::Chain&gt;::push | 443 | 1052403 |
| relation_replay_checker::add_term | 376545 | 954576 |
| certified_relations::projection::times | 41998 | 853533 |

All functions, object paths, counters, raw call graph and exact answer remain in the raw archive and functions.json. Counts describe this compiled binary/input under Callgrind. They can guide a subsequent explicitly qualified optimization; they do not predict its native gain. [pcc:unverified]

![Largest exclusive guest instruction counts](self.svg){width=95%}

Numbers on the vertical axis map to the self-cost table.
