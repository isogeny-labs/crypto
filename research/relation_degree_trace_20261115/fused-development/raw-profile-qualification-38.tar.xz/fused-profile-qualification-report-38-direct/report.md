# Native candidate instruction diagnosis

Qualification only: **true**. PCC-20261116-20de46. One whole-process guest-instruction profile; generation/preparation and parent capture excluded. No native time/cycle estimate, speed ratio, A/A admission, confidence interval, new target or degree-of-regularity conclusion. [pcc:unverified]

The complete checked canonical answer equals the frozen uninstrumented candidate. Executable/runtime hashes are unchanged. Total guest Ir: **19950080**, across708 attributed functions. Rust recomputation matches both raw summary/totals, every function row and the separately formatted Collected line from the same profiler. This is producer recomputation, not signed independent execution verification. [pcc:unverified]

Self costs are exclusive and add to total. Inclusive costs include callees, overlap and must not be added across functions. Inlined instructions belong to their containing compiled functions. Startup, libraries, allocation and exact checking remain included; instrumented dispatch can differ from native hardware dispatch. [pcc:unverified]

Function names longer than110 characters are abbreviated in tables; full names and object paths remain in functions.json.

## Largest self costs

| Rank | Function | Self Ir | Fraction of all Ir | Inclusive Ir (overlaps) |
|---:|---|---:|---:|---:|
| 1 | certified_relations::axpy_in_place::&lt;alloc::vec::Vec&lt;usize&gt;&gt; | 2936977 | 14.722% | 5245107 |
| 2 | free | 1751228 | 8.778% | 2232298 |
| 3 | malloc | 1122846 | 5.628% | 1826866 |
| 4 | &lt;alloc::vec::Vec&lt;usize&gt; as alloc::vec::spec_from_iter_nested::SpecFromIterNested&lt;usize, core::iter::adapter... | 1035906 | 5.192% | 1877277 |
| 5 | &lt;alloc::collections::btree::map::BTreeMap&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;&gt;::insert | 898018 | 4.501% | 1374500 |
| 6 | &lt;alloc::collections::btree::node::NodeRef&lt;alloc::collections::btree::node::marker::Owned, alloc::vec::Vec&lt;u... | 728624 | 3.652% | 1065724 |
| 7 | 0x00000000000a0fe0 | 669591 | 3.356% | 822330 |
| 8 | &lt;core::iter::adapters::map::Map&lt;alloc::collections::btree::map::Keys&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;, certifie... | 653115 | 3.274% | 653115 |
| 9 | &lt;core::iter::adapters::map::Map&lt;alloc::collections::btree::map::Iter&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;, certifie... | 615064 | 3.083% | 2259058 |
| 10 | certified_relations::quotient::rewrite | 529398 | 2.654% | 7893969 |
| 11 | &lt;alloc::collections::btree::map::BTreeMap&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;&gt;::remove::&lt;alloc::vec::Vec&lt;usize&gt;&gt; | 514417 | 2.579% | 1114420 |
| 12 | &lt;alloc::collections::btree::map::IntoIter&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;&gt;::dying_next | 470695 | 2.359% | 588703 |
| 13 | 0x00000000000a02e0 | 470106 | 2.356% | 484299 |
| 14 | relation_replay_checker::add_term | 376545 | 1.887% | 954576 |
| 15 | core::slice::sort::shared::smallsort::insertion_sort_shift_left::&lt;(alloc::vec::Vec&lt;usize&gt;, u64), &lt;[(alloc::... | 320976 | 1.609% | 320976 |
| 16 | certified_relations::axpy_in_place::&lt;(usize, alloc::vec::Vec&lt;usize&gt;)&gt; | 292146 | 1.464% | 482658 |
| 17 | 0x0000000000162880 | 257252 | 1.289% | 257252 |
| 18 | __rustc::__rdl_alloc | 245016 | 1.228% | 2069359 |
| 19 | 0x0000000000162120 | 226084 | 1.133% | 226084 |
| 20 | certified_relations::normal_form | 223809 | 1.122% | 967925 |
| 21 | certified_relations::lead | 216945 | 1.087% | 216945 |
| 22 | &lt;alloc::collections::btree::node::Handle&lt;alloc::collections::btree::node::NodeRef&lt;alloc::collections::btree... | 181714 | 0.911% | 253855 |
| 23 | certified_relations::verify | 178813 | 0.896% | 3388086 |
| 24 | &lt;alloc::collections::btree::node::Handle&lt;alloc::collections::btree::node::NodeRef&lt;alloc::collections::btree... | 178359 | 0.894% | 290572 |
| 25 | &lt;alloc::collections::btree::node::Handle&lt;alloc::collections::btree::node::NodeRef&lt;alloc::collections::btree... | 173160 | 0.868% | 173160 |

## Native constructor and separate checker: largest inclusive counts

| Function | Self Ir | Inclusive Ir (overlaps) |
|---|---:|---:|
| certified_relations::replay::produce_native_for_rust_with_kernels | 34 | 16547572 |
| certified_relations::replay::produce_native_for_rust | 135 | 16547533 |
| certified_relations::replay::native_product_impl | 250 | 16174262 |
| certified_relations::quotient::compact::solve_sparse_impl | 36 | 15155762 |
| certified_relations::quotient::compact::solve_impl | 3469 | 15155697 |
| certified_relations::quotient::rewrite | 529398 | 7893969 |
| certified_relations::axpy_in_place::&lt;alloc::vec::Vec&lt;usize&gt;&gt; | 2936977 | 5245107 |
| certified_relations::axpy::&lt;alloc::vec::Vec&lt;usize&gt;&gt; | 62760 | 5041837 |
| &lt;alloc::collections::btree::map::BTreeMap&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt; as core::iter::traits::collect::From... | 116914 | 4059665 |
| certified_relations::verify | 178813 | 3388086 |
| certified_relations::projection::subset_quadratic | 2252 | 3197784 |
| relation_replay_checker::verify_json | 7119 | 2721972 |
| certified_relations::row_shift | 85367 | 2718924 |
| &lt;alloc::vec::Vec&lt;(alloc::vec::Vec&lt;usize&gt;, u64)&gt; as alloc::vec::spec_from_iter::SpecFromIter&lt;(alloc::vec::Ve... | 105046 | 2468652 |
| &lt;core::iter::adapters::map::Map&lt;alloc::collections::btree::map::Iter&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;, certifie... | 615064 | 2259058 |
| certified_relations::quotient::compact::verify_impl | 6566 | 1959265 |
| &lt;alloc::vec::Vec&lt;usize&gt; as alloc::vec::spec_from_iter_nested::SpecFromIterNested&lt;usize, core::iter::adapter... | 1035906 | 1877277 |
| &lt;relation_replay_checker::Arithmetic&gt;::identity | 171813 | 1591720 |
| certified_relations::projection::quadratic_resultant | 9026 | 1160593 |
| &lt;certified_relations::quotient::compact::Chain&gt;::push | 443 | 1052403 |
| certified_relations::normal_form | 223809 | 967925 |
| relation_replay_checker::add_term | 376545 | 954576 |
| certified_relations::projection::times | 41998 | 853533 |
| certified_relations::check_reference_impl | 1157 | 815279 |
| certified_relations::quotient::coordinate | 4568 | 794544 |

All functions, object paths, counters, raw call graph and exact answer remain in the raw archive and functions.json. Counts describe this compiled binary/input under Callgrind. They can guide a subsequent explicitly qualified optimization; they do not predict its native gain. [pcc:unverified]

![Largest exclusive guest instruction counts](self.svg){width=95%}

Numbers on the vertical axis map to the self-cost table.
