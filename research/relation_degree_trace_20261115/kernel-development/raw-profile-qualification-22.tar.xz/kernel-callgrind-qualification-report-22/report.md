# Native candidate instruction diagnosis

Qualification only: **true**. PCC-20261116-5c9573. One whole-process guest-instruction profile; generation/preparation and parent capture excluded. No native time/cycle estimate, speed ratio, A/A admission, confidence interval, new target or degree-of-regularity conclusion. [pcc:unverified]

The complete checked canonical answer equals the frozen uninstrumented candidate. Executable/runtime hashes are unchanged. Total guest Ir: **23450221**, across705 attributed functions. Rust recomputation matches both raw summary/totals, every function row and the separately formatted Collected line from the same profiler. This is producer recomputation, not signed independent execution verification. [pcc:unverified]

Self costs are exclusive and add to total. Inclusive costs include callees, overlap and must not be added across functions. Inlined instructions belong to their containing compiled functions. Startup, libraries, allocation and exact checking remain included; instrumented dispatch can differ from native hardware dispatch. [pcc:unverified]

Function names longer than110 characters are abbreviated in tables; full names and object paths remain in functions.json.

## Largest self costs

| Rank | Function | Self Ir | Fraction of all Ir | Inclusive Ir (overlaps) |
|---:|---|---:|---:|---:|
| 1 | certified_relations::axpy::&lt;alloc::vec::Vec&lt;usize&gt;&gt; | 3288644 | 14.024% | 8213459 |
| 2 | free | 2407322 | 10.266% | 2916966 |
| 3 | &lt;alloc::collections::btree::map::BTreeMap&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;&gt;::insert | 2367992 | 10.098% | 3386471 |
| 4 | malloc | 1538221 | 6.560% | 2268816 |
| 5 | &lt;alloc::vec::Vec&lt;usize&gt; as alloc::vec::spec_from_iter_nested::SpecFromIterNested&lt;usize, core::iter::adapter... | 1105442 | 4.714% | 2005402 |
| 6 | &lt;alloc::collections::btree::node::NodeRef&lt;alloc::collections::btree::node::marker::Owned, alloc::vec::Vec&lt;u... | 799344 | 3.409% | 1173281 |
| 7 | 0x00000000000a0fe0 | 693896 | 2.959% | 848611 |
| 8 | &lt;core::iter::adapters::map::Map&lt;alloc::collections::btree::map::Iter&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;, certifie... | 675397 | 2.880% | 2469340 |
| 9 | &lt;core::iter::adapters::map::Map&lt;alloc::collections::btree::map::Keys&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;, certifie... | 653115 | 2.785% | 653115 |
| 10 | certified_relations::quotient::rewrite | 529398 | 2.258% | 9103269 |
| 11 | &lt;alloc::collections::btree::map::BTreeMap&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;&gt;::remove::&lt;alloc::vec::Vec&lt;usize&gt;&gt; | 514417 | 2.194% | 1113190 |
| 12 | 0x00000000000a02e0 | 498761 | 2.127% | 512908 |
| 13 | &lt;alloc::collections::btree::map::IntoIter&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;&gt;::dying_next | 482629 | 2.058% | 600726 |
| 14 | relation_replay_checker::add_term | 376545 | 1.606% | 954723 |
| 15 | core::slice::sort::shared::smallsort::insertion_sort_shift_left::&lt;(alloc::vec::Vec&lt;usize&gt;, u64), &lt;[(alloc::... | 347355 | 1.481% | 347355 |
| 16 | 0x0000000000162880 | 343538 | 1.465% | 343538 |
| 17 | __rustc::__rdl_alloc | 336114 | 1.433% | 2602407 |
| 18 | certified_relations::axpy::&lt;(usize, alloc::vec::Vec&lt;usize&gt;)&gt; | 313140 | 1.335% | 703993 |
| 19 | 0x0000000000162120 | 248122 | 1.058% | 248122 |
| 20 | certified_relations::lead | 211785 | 0.903% | 211785 |
| 21 | &lt;alloc::collections::btree::map::BTreeMap&lt;(usize, alloc::vec::Vec&lt;usize&gt;), u64&gt;&gt;::insert | 210928 | 0.899% | 304032 |
| 22 | &lt;alloc::collections::btree::node::Handle&lt;alloc::collections::btree::node::NodeRef&lt;alloc::collections::btree... | 205868 | 0.878% | 205868 |
| 23 | __umodti3 | 202300 | 0.863% | 202300 |
| 24 | certified_relations::normal_form | 187568 | 0.800% | 1726592 |
| 25 | &lt;alloc::collections::btree::node::Handle&lt;alloc::collections::btree::node::NodeRef&lt;alloc::collections::btree... | 181714 | 0.775% | 253795 |

## Native constructor and separate checker: largest inclusive counts

| Function | Self Ir | Inclusive Ir (overlaps) |
|---|---:|---:|
| certified_relations::replay::produce_native_for_rust_with_kernels | 32 | 20053387 |
| certified_relations::replay::produce_native_for_rust | 135 | 20053350 |
| certified_relations::replay::native_product_impl | 250 | 19679450 |
| certified_relations::quotient::compact::solve_sparse_impl | 36 | 18263220 |
| certified_relations::quotient::compact::solve_impl | 3469 | 18263155 |
| certified_relations::quotient::rewrite | 529398 | 9103269 |
| certified_relations::axpy::&lt;alloc::vec::Vec&lt;usize&gt;&gt; | 3288644 | 8213459 |
| &lt;alloc::collections::btree::map::BTreeMap&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt; as core::iter::traits::collect::From... | 129953 | 4451969 |
| certified_relations::verify | 178813 | 4429674 |
| certified_relations::projection::subset_quadratic | 2252 | 4006316 |
| certified_relations::row_shift | 99172 | 3209244 |
| relation_replay_checker::verify_json | 7119 | 2719923 |
| &lt;alloc::vec::Vec&lt;(alloc::vec::Vec&lt;usize&gt;, u64)&gt; as alloc::vec::spec_from_iter::SpecFromIter&lt;(alloc::vec::Ve... | 116759 | 2701733 |
| certified_relations::quotient::compact::verify_impl | 6566 | 2663906 |
| &lt;core::iter::adapters::map::Map&lt;alloc::collections::btree::map::Iter&lt;alloc::vec::Vec&lt;usize&gt;, u64&gt;, certifie... | 675397 | 2469340 |
| &lt;alloc::vec::Vec&lt;usize&gt; as alloc::vec::spec_from_iter_nested::SpecFromIterNested&lt;usize, core::iter::adapter... | 1105442 | 2005402 |
| certified_relations::normal_form | 187568 | 1726592 |
| &lt;relation_replay_checker::Arithmetic&gt;::identity | 171813 | 1591771 |
| certified_relations::projection::quadratic_resultant | 9026 | 1399943 |
| &lt;certified_relations::quotient::compact::Chain&gt;::push | 443 | 1361303 |
| certified_relations::check_reference_impl | 1157 | 1210668 |
| certified_relations::replay::complete_impl | 2203 | 1172843 |
| certified_relations::projection::times | 41998 | 1037626 |
| relation_replay_checker::add_term | 376545 | 954723 |
| certified_relations::quotient::coordinate | 4568 | 928705 |

All functions, object paths, counters, raw call graph and exact answer remain in the raw archive and functions.json. Counts describe this compiled binary/input under Callgrind. They can guide a subsequent explicitly qualified optimization; they do not predict its native gain. [pcc:unverified]

![Largest exclusive guest instruction counts](self.svg){width=95%}

Numbers on the vertical axis map to the self-cost table.
