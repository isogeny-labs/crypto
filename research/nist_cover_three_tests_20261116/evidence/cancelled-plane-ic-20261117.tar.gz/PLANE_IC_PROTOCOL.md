# Plane-quartic relation rank and individual descent

Frozen 2026-11-17 before new arithmetic output. This follows the completed
same-field polarized quotient, rather than modifying its pinned evidence.
The requested next component is index-calculus scalar recovery. Two distinct
functional qualifiers address relation collection and recovery; neither is a
performance experiment or a replacement for the original P-192 target.

## Sources and development boundary

Reviewed the existing BACKMAP_RELATIONS_PROTOCOL.md, backmap_relations.cpp,
BACKMAP.md, README.md and POLARIZED_QUOTIENT.md. The relevant primary algorithm
is C. Diem and E. Thome, Journal of Cryptology 21 (2008), 593-611,
<https://doi.org/10.1007/s00145-007-9014-6>. Crossref identifies this reference;
the author's root/index/papers routes were inaccessible or returned 404.
Tian's primary manuscript, <https://arxiv.org/abs/2007.03172>, introduction and
reference list, supplies context already reviewed in the preceding work.
The complete Diem-Thome paper has not been read in this runtime. Consequently
this unit implements elementary split-line relations and projected descent,
not the paper's optimized algorithm or its asymptotic complexity. No novelty
claim is made. KB unavailable: no MCP tool is loaded and the maintained
scripts/research-kb wrapper reports no executable. Conductor, Cargo and Lean
are unavailable; checkpoint.sh is absent. Native local build/correctness
checks remain development work under isolab-eks; paid campaigns remain stopped
because remaining budget is unknown. No times, costs or speed ratios recorded.

## Fixed P-192 audit

Use the existing kernel3 quartic, 226-point affine pool, seven full vertical
fibers and degree6 backmap, unchanged. Enumerate all 25425 unordered pairs and
226 tangents. Deduplicate lines by canonical coefficients. A vertical line is
x=c; otherwise y=m*x+t. Exact quartic restriction, division by the two known
roots (twice for a tangent), and quadratic completion determine its entire
finite intersection including multiplicities. Replay the full polynomial
factorization and curve membership. A degree drop is recorded as an infinity
chart outside this affine-only audit. Admit a relation only if all four roots
belong to the original pool. The first retained vertical fiber is reference.

Re-evaluate all point images with BRMap, compare the earlier projected receipt,
check the P-192 equation and order, fold by negation and merge identical images.
Subtract reference support, check the resulting elliptic sum is zero, then
compute exact rank modulo r. Preserve every pair/tangent decision, all supported
line coefficients, multiplicities and sparse rows. Codes: 0 duplicate;
1 infinity chart; 2 nonsplit residual; 3 rational complement outside base;
4 supported dependent; 5 supported rank increase. Completeness is only for
lines with all intersection support in this retained affine pool. All such
lines contain two distinct pool points or are tangent at a pool point.
No conclusion about larger bases, higher-degree functions or large-prime
cycles is authorized by this audit. Baseline is 225 columns and rank6;
rank224 leaves the expected single scaling freedom.

## Fixed genuine genus3 recovery controls

Use C: w^4=x^3+a*x+b, the smooth plane quartic
W^4=X^3*Z+a*X*Z^3+b*Z^4, with unique infinity (1:0:0).
The degree2 map (x,w)->(x,w^2) lands on E: y^2=x^3+a*x+b.
Nonzero elliptic discriminant implies affine smoothness; the infinity
derivative in Z is nonzero. Its genus is3 and it is nonhyperelliptic.
This is a separate control family, not a reconstructed 3-kernel quotient.

Fixtures are (p,a,b,#E,r,h)=(109,8,52,99,11,9) and
(1009,145,438,981,109,9). Enumerate all rational affine C points, cofactor
project their norms to E[r], fold by negation and merge. Reference divisor is
4*infinity, whose norm is zero. Horizontal degree3 restrictions have one
infinity intersection, explicitly allowed here. Other lines have degree4.
Collect pair/tangent split-line relations until rank B-1 or enumeration ends.
Solve the homogeneous kernel and normalize its first column to1. Check all
derived logs by scalar multiplication; do not construct them by scalar search.

Choose public G as the first nonzero cofactor image in lexicographic E-point
enumeration, independently of base logs. To reflect the geometric pullback,
descend 2G and 2Q: the closed fiber is x=x_T,w^2=y_T and its norm is2T.
For T in {2G,2Q}, try s=0..16 until T+s*A has a rational C lift. Lookup the
cofactor-projected norm log L and set log_A(T)=h^-1*L-s mod r.
Return log_A(2Q)/log_A(2G). The solver receives public G,Q and setup data,
never the witness scalar. Exhaust all r targets as a functional correctness
panel; primary scalars are7 and37 respectively. Do not report amortization.

Reject a false relation coefficient, a changed scalar answer, off-curve input
(0,0), and a corrupted line-factorization replay. Retain relation witnesses,
derived logs, individual descent records and answers. Failure of a fixture or
rank target is retained, not replaced with a different curve.

## Limits and records

Each native invocation: at most600 seconds and1GiB address space; deterministic
inputs and no random search. Separate immutable source/header/protocol/binary
pre-call manifests, build logs, raw stdout/stderr, exit and post-call source
manifest in fresh evidence directories. Preserve failed attempts separately.
All numerical outcomes need PCC registration before citation and remain
producer-unverified. No independent verifier or compiled formalization is
claimed. Report/PDF/diagram and follow-up regular PR are required deliverables.
