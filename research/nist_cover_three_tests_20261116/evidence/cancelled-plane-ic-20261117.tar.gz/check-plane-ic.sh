#!/bin/sh
set -eu
cd "$(dirname "$0")"
out=${1:?Specify NEW evidence directory}
shift
mkdir "$out"
out=$(cd "$out" && pwd)
mkdir "$out/source"
cp plane_ic.cpp PLANE_IC_PROTOCOL.md "$out/source/"
for item in point cover kernel_point module quotient weil3 quotient_theta2 riemann quartic_descent elliptic_backmap backmap_relations; do
    case "$item" in
        point) source=point_replay.cpp; dest=point_arithmetic ;;
        cover) source=cover_replay.cpp; dest=cover_arithmetic ;;
        kernel_point) source=kernel_point_replay.cpp; dest=kernel_arithmetic ;;
        module) source=module_audit.cpp; dest=module_arithmetic ;;
        quotient) source=quotient_replay.cpp; dest=quotient_arithmetic ;;
        riemann) source=riemann_quartic.cpp; dest=riemann_arithmetic ;;
        *) source=$item.cpp; dest=${item}_arithmetic ;;
    esac
    { printf '#pragma once\n'; sed '/^int main(/,$d' "$source"; } > "$out/source/$dest.hpp"
done
cp json.hpp "$out/source/"
sha256sum "$out/source/"* > "$out/build-input-manifest.sha256"
set +e
${CXX:-c++} -std=c++17 -O2 -Wall -Wextra -Werror -pedantic -I "$out/source" "$out/source/plane_ic.cpp" -lgmpxx -lgmp -lcrypto -o "$out/qualifier" 2> "$out/build.stderr"
build_exit=$?
set -e
printf '%s\n' "$build_exit" > "$out/BUILD_EXIT_CODE.txt"
test "$build_exit" -eq 0
chmod 0555 "$out/qualifier"
sha256sum "$out/source/"* "$out/qualifier" > "$out/pre-call-manifest.sha256"
printf '%s\n' "$@" > "$out/arguments.txt"
if test "$1" = p192; then
    sha256sum "$2/inputs/p192-d7-prym.json" "$2/evidence/p192-d7-kernel3-plane-quartic.json" "$2/evidence/destination-relations-v2/result.json" "$3" "$4" > "$out/input-manifest.sha256"
fi
set +e
(ulimit -v 1048576; timeout 600 "$out/qualifier" "$@") > "$out/result.json" 2> "$out/stderr.txt"
run_exit=$?
set -e
printf '%s\n' "$run_exit" > "$out/EXIT_CODE.txt"
sha256sum plane_ic.cpp PLANE_IC_PROTOCOL.md > "$out/post-call-source-manifest.sha256"
exit "$run_exit"
