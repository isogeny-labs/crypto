use smith_resume_validation::cryptanalysis::{smith_elliptic_walk as w, smith_prop24 as sp};
fn main() {
 let k=w::Fp3::new(61); let mut rng=sp::SplitMix64(8); let mut cur=w::random_full2_start(&k,&mut rng); let tab=w::Tables::new(&k);
 for i in 0..12 {
  println!("node {i} key={:?} back={:?} weak={}",w::class_key(&k,&tab,&cur.a,&cur.b),cur.back,w::jv_weak_from_norms(61,&w::jv_norms(&k,&cur.roots)));
  match w::step(&k,&cur,&mut rng) {Some((n,_))=>cur=n,None=>{println!("reflect");cur.back=None;cur=w::step(&k,&cur,&mut rng).unwrap().0;}}
 }
 let mut seen=std::collections::BTreeSet::new(); let mut rng=sp::SplitMix64(8);let mut queue=vec![w::random_full2_start(&k,&mut rng)];
 while let Some(n)=queue.pop() {
  let key=w::class_key(&k,&tab,&n.a,&n.b).unwrap(); if !seen.insert(key){continue;} assert!(seen.len()<100);
  let mut admissible=0;
  for i in 0..3 {let (j,l)=((i+1)%3,(i+2)%3); let fp=k.mul(&k.sub(&n.roots[i],&n.roots[j]),&k.sub(&n.roots[i],&n.roots[l]));if k.chi(&fp)!=1{continue;}admissible+=1;let r=n.roots[i];let s=k.sqrt(&fp).unwrap();let (a,b)=w::velu2(&k,&n.a,&n.b,&r);let two=k.add(&s,&s);queue.push(w::WalkNode{a,b,roots:[k.neg(&k.add(&r,&r)),k.add(&r,&two),k.sub(&r,&two)],back:None});}
  println!("closed-component key={key:?} edges={admissible} weak={}",w::jv_weak_from_norms(61,&w::jv_norms(&k,&n.roots)));
 }
 println!("component closed with {} classes",seen.len());
 for seed in 0..8 {let mut rng=sp::SplitMix64(seed);let start=w::random_full2_start(&k,&mut rng);let r=w::walk(&k,start,&mut rng,2000,100_000_000,false,true);println!("fixture seed={seed} passed={} nodes={} hits={}",r.passed,r.nodes_tested,r.jv_weak_hits);}
 for p in [7,11] { let k=w::Fp3::new(p);let models=w::reduced_models(&k);let mut rng=sp::SplitMix64(5);let mut counts=[0;3];for _ in 0..24 {counts[models[rng.below(models.len() as u64) as usize].kind as usize]+=1;}println!("p={p} sampled kind counts={counts:?}"); }
}
