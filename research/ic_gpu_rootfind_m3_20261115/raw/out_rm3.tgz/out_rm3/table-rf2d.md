| session | arm | method | curve | log2 r | verified | mean S | 95% interval | theory S | S / theory | S / floor | S / reference | lower bound | med wall ms | levels | flags |
|---|---|---|---|---:|---:|---:|---|---:|---:|---:|---:|---|---:|---|---|
| ECBS1hc81c69dfa91e | rho-neg | rho.negation | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 1.104 | [0.011, 109.090] indicative | 0.886 | 1.246 | 1.246 | 1.000 | yes | 1.889 | L0×4 | – |
| ECBS1hc81c69dfa91e | rho-neg | rho.negation | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 1.226 | [0.095, 15.759] indicative | 0.886 | 1.383 | 1.383 | 1.000 | yes | 5.568 | L0×4 | – |
| ECBS1hc81c69dfa91e | rho-neg | rho.negation | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 1.088 (heavy tail; more runs needed) | [0.020, 58.417] indicative | 0.886 | 1.228 | 1.228 | 1.000 | yes | 6.846 | L0×4 | – |
| ECBS1hc81c69dfa91e | rf2-cpu-F4096 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 6456.896 | [1489.978, 27981.286] indicative | – | – | 7285.827 | 5846.640 | yes | 2192.370 | L0×4 | – |
| ECBS1hc81c69dfa91e | rf2-cpu-F4096 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 13965.108 | [6723.714, 29005.436] indicative | – | – | 15757.937 | 11392.737 | yes | 11208.375 | L0×4 | – |
| ECBS1hc81c69dfa91e | rf2-cpu-F4096 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 24151.390 | [13576.414, 42963.454] indicative | – | – | 27251.925 | 22197.805 | yes | 27852.701 | L0×4 | – |
| ECBS1hc81c69dfa91e | rf2-gpu-F4096 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 6456.896 | [1489.978, 27981.286] indicative | – | – | 7285.827 | 5846.640 | yes | 398.782 | L0×4 | – |
| ECBS1hc81c69dfa91e | rf2-gpu-F4096 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 13965.108 | [6723.714, 29005.436] indicative | – | – | 15757.937 | 11392.737 | yes | 382.816 | L0×4 | – |
| ECBS1hc81c69dfa91e | rf2-gpu-F4096 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 24151.390 | [13576.414, 42963.454] indicative | – | – | 27251.925 | 22197.805 | yes | 427.288 | L0×4 | – |
| ECBS1hc81c69dfa91e | rf2-gpud-F4096 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 6456.896 | [1489.978, 27981.286] indicative | – | – | 7285.827 | 5846.640 | yes | 105.495 | L0×4 | – |
| ECBS1hc81c69dfa91e | rf2-gpud-F4096 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 13965.108 | [6723.714, 29005.436] indicative | – | – | 15757.937 | 11392.737 | yes | 144.273 | L0×4 | – |
| ECBS1hc81c69dfa91e | rf2-gpud-F4096 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 24151.390 | [13576.414, 42963.454] indicative | – | – | 27251.925 | 22197.805 | yes | 216.573 | L0×4 | – |
| ECBS1hc81c69dfa91e | rf2-gpuaa-F4096 | ic.pipeline | icv1-fp28-t7531-5f8c6474 | 27.48 | 4/4 | 6456.896 | [1489.978, 27981.286] indicative | – | – | 7285.827 | 5846.640 | yes | 339.175 | L0×4 | – |
| ECBS1hc81c69dfa91e | rf2-gpuaa-F4096 | ic.pipeline | icv1-fp30-tm15113-0b67ffcf | 29.99 | 4/4 | 13965.108 | [6723.714, 29005.436] indicative | – | – | 15757.937 | 11392.737 | yes | 443.843 | L0×4 | – |
| ECBS1hc81c69dfa91e | rf2-gpuaa-F4096 | ic.pipeline | icv1-fp32-tm9515-ee9bd0a2 | 31.26 | 4/4 | 24151.390 | [13576.414, 42963.454] indicative | – | – | 27251.925 | 22197.805 | yes | 535.203 | L0×4 | – |
