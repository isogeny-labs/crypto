#!/usr/bin/env bash
set -u
target=$1
attempt=$2
project=/workspace/crypto-audit/research/three_torsion_rank_audit_20261114/lean
record=/workspace/scratch/three-torsion-rank-attempts/$target-$attempt
mkdir -p "$record"
cd "$project" || exit 1
cp -- *.lean lakefile.toml lake-manifest.json lean-toolchain "$record/"
lake build "$target" > "/workspace/scratch/three-torsion-rank-$target-build$attempt.log" 2>&1
result=$?
printf '%s\n' "$result" > "/workspace/scratch/three-torsion-rank-$target-build$attempt.exit"
tail -n 65 "/workspace/scratch/three-torsion-rank-$target-build$attempt.log"
exit "$result"
