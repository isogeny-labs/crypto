import DivisionQuartic
import Mathlib.SetTheory.Cardinal.NatCard

namespace ThreeTorsionRankAudit
open Polynomial
noncomputable section
variable {K : Type*} [Field K] [DecidableEq K]

def Root (a b : K) := {x : K // (psi a b).IsRoot x}

def polynomialRootFintype (p : K[X]) (hp : p ≠ 0) : Fintype {x : K // p.IsRoot x} :=
  Fintype.ofFinset p.roots.toFinset (by
    intro x
    rw [Multiset.mem_toFinset]
    exact Polynomial.mem_roots hp)

theorem psi_nonzero [NeZero (3 : K)] (a b : K) : psi a b ≠ 0 := by
  apply Polynomial.ne_zero_of_natDegree_gt
  rw [psi_degree]
  norm_num

instance rootFintype [NeZero (3 : K)] (a b : K) : Fintype (Root a b) :=
  polynomialRootFintype (psi a b) (psi_nonzero a b)

theorem root_card_four [IsAlgClosed K] [NeZero (2 : K)] [NeZero (3 : K)]
    (a b : K) (hΔ : (short a b).Δ ≠ 0) : Nat.card (Root a b) = 4 := by
  rw [Nat.card_eq_fintype_card]
  change @Fintype.card (Root a b) (polynomialRootFintype (psi a b) (psi_nonzero a b)) = 4
  rw [Fintype.card_ofFinset,Multiset.toFinset_card_of_nodup (psi_separable a b hΔ).nodup_roots]
  rw [← (IsAlgClosed.splits (psi a b)).natDegree_eq_card_roots,psi_degree]

def squareRootEquiv (c : K) : {y : K // y^2=c} ≃
    {y : K // ((X : K[X])^2-C c).IsRoot y} where
  toFun y := ⟨y.val,by simpa [Polynomial.IsRoot.def] using sub_eq_zero.mpr y.property⟩
  invFun y := ⟨y.val,by simpa [Polynomial.IsRoot.def] using y.property⟩
  left_inv := by intro y; rfl
  right_inv := by intro y; rfl

instance squareFintype (c : K) : Fintype {y : K // y^2=c} :=
  Fintype.ofEquiv {y : K // ((X : K[X])^2-C c).IsRoot y}
    (squareRootEquiv c).symm
    (fintype := polynomialRootFintype ((X : K[X])^2-C c) (Polynomial.X_pow_sub_C_ne_zero (by decide) c))

theorem square_card_two [IsAlgClosed K] [NeZero (2 : K)] (c : K) (hc : c ≠ 0) :
    Nat.card {y : K // y^2=c} = 2 := by
  rw [Nat.card_congr (squareRootEquiv c)]
  let p : K[X] := X^2-C c
  letI := polynomialRootFintype p (Polynomial.X_pow_sub_C_ne_zero (by decide) c)
  rw [Nat.card_eq_fintype_card]
  change @Fintype.card {y : K // p.IsRoot y}
    (polynomialRootFintype p (Polynomial.X_pow_sub_C_ne_zero (by decide) c)) = 2
  rw [Fintype.card_ofFinset,Multiset.toFinset_card_of_nodup
    (Polynomial.separable_X_pow_sub_C c (NeZero.ne (2 : K)) hc).nodup_roots]
  rw [← (IsAlgClosed.splits p).natDegree_eq_card_roots]
  exact Polynomial.natDegree_X_pow_sub_C

def Fibers (a b : K) := Σ x : Root a b, {y : K // y^2=curveValue a b x.val}

instance fibersFintype [NeZero (3 : K)] (a b : K) : Fintype (Fibers a b) :=
  inferInstanceAs (Fintype (Σ x : Root a b, {y : K // y^2=curveValue a b x.val}))

theorem fibers_card_eight [IsAlgClosed K] [NeZero (2 : K)] [NeZero (3 : K)]
    (a b : K) (hΔ : (short a b).Δ ≠ 0) : Nat.card (Fibers a b) = 8 := by
  rw [Nat.card_eq_fintype_card]
  change Fintype.card (Σ x : Root a b, {y : K // y^2=curveValue a b x.val}) = 8
  rw [Fintype.card_sigma]
  have hf (x : Root a b) : Fintype.card {y : K // y^2=curveValue a b x.val} = 2 := by
    rw [← Nat.card_eq_fintype_card]
    exact square_card_two _ (psi_root_curve_value_nonzero a b hΔ x.property)
  simp_rw [hf]
  simp only [Finset.sum_const,Finset.card_univ,smul_eq_mul]
  rw [← Nat.card_eq_fintype_card,root_card_four a b hΔ]

end
end ThreeTorsionRankAudit
