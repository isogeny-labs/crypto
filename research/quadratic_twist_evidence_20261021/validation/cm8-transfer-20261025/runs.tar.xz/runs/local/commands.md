# Executed native and proof commands

From repository root with supported Cargo/Lean homes/cache and two build workers.
STUDY=research/quadratic_twist_evidence_20261021. Protocol4784fea4c and compiled
source11c2a73f5 precede first native execution;3c9cba48e freezes final proof/audit
before fresh final replay. Native command caps600s, focused iteration3600s,
existing local resources only.

- c++ -std=c++17 -O2 -Wall -Wextra -Werror STUDY/native/cm8-transfer.cpp -lcrypto -o OUTPUT/producer
- cargo build --release --locked --manifest-path STUDY/native/cm8-transfer-audit/Cargo.toml
- timeout 600 OUTPUT/producer /workspace/crypto-next OUTPUT/cases
- timeout 600 AUDITOR audit /workspace/crypto-next OUTPUT/cases OUTPUT/audit.json
- AUDITOR certificate issue /workspace/crypto-next STUDY/native/cm8-transfer-20261025/certificate
- bash research/quadratic_twist_evidence_20261021/run-cm8-transfer.sh /workspace/twist-cm8-next/fresh-final
- bash research/quadratic_twist_evidence_20261021/run-cm8-transfer.sh /workspace/twist-cm8-next/fresh-phase-counts
- bash tools/lean/proof-gate.sh --out /workspace/twist-cm8-next/lean-gate-final STUDY/lean STUDY/lean-reduced STUDY/lean-adaptive STUDY/lean-phase STUDY/lean-known-roots STUDY/lean-signed-cache STUDY/lean-cm8
- cargo test --release --locked --lib --quiet (network permission for existing loopback tests)
- python3 scripts/test_workflows_parse.py
- python3 scripts/check_curve_names.py
- target/release/backlog validate XP-20261025-cm8-quadratic-transfer XP-20261025-cm8-explicit-dual
- make check (reports/cm8-transfer-20261025); pdftoppm -scale-to1400 -png report.pdf ...

Native producer and all independent arithmetic pass on first execution. First
Rust build failed on a closure borrowing a moved base; source/log retained;
iterating copied entries fixes ownership without arithmetic changes. Initial
Lean cache clone lacked network permission; pinned existing local dependency
symlinks/manifest reuse supported cache, no gate patch. First actual Lean build
failed in reverse rewrite of the source theorem; exact source/log retained,
correcting rewrite orientation builds. A duplicate successful build after a
wrong-working-directory edit attempt changed no source. First polynomial
certificate check requested17 extra points while expecting16; it failed before
writing any certificate. Correct16 replay points passes. Empty failed output
not claimed as a certificate. First card protocol reference failed schema;
exact payload/log retained, protocol remains a study reference and draft card
protocol null, no task-state promotion or weakened validator.

Eleven rehashed semantic controls each reject101/no receipt. No failed online
shift exists; that control is explicit null and missing-query removes a real
successful query. Both final report pages were rendered/inspected. A final metadata-only audit addition records exact20setup queries/72online queries/36online forward-map calls; pre-addition source/receipt and fresh final replay retained, no curve/polynomial arithmetic changed. Diagnostic
build/test elapsed values are not research timings. Conductor exits127/no lease;
no new profile (historical missinggawk), upload, paid compute or credential reuse.
The explicit dual coordinates in the draft/report are unexecuted planning.
