# Exact command record

From the repository root with the supported local Cargo/Lean homes and cache,
CARGO_BUILD_JOBS=2, source unchanged after pre-execution commita150b288c.
STUDY means research/quadratic_twist_evidence_20261021; all native runs use a
600-second timeout and a fresh output directory.

- c++ -std=c++17 -O2 -Wall -Wextra -Werror STUDY/native/signed-cache.cpp -lcrypto -o OUTPUT/producer
- cargo build --release --locked --manifest-path STUDY/native/signed-cache-audit/Cargo.toml
- OUTPUT/producer STUDY/native/reduced-s3-20261025/cases STUDY/native/adaptive-s3-20261025/cases STUDY/native/known-roots-20261025/cases OUTPUT/cases
- AUDITOR audit REDUCED_CASES ADAPTIVE_CASES KNOWN_CASES OUTPUT/cases OUTPUT/audit.json
- bash research/quadratic_twist_evidence_20261021/run-signed-cache.sh /workspace/twist-cache-next/fresh-final
- bash tools/lean/proof-gate.sh --out /workspace/twist-cache-next/lean-gate-final STUDY/lean STUDY/lean-reduced STUDY/lean-adaptive STUDY/lean-phase STUDY/lean-known-roots STUDY/lean-signed-cache
- cargo test --release --locked --lib --quiet (network permission for existing loopback tests)
- python3 scripts/test_workflows_parse.py
- target/release/backlog validate XP-20261025-signed-base-cache XP-20261025-direct-sign-reference
- python3 scripts/check_curve_names.py
- make check (reports/signed-cache-20261025); pdftoppm -scale-to1400 -png report.pdf ...
- bash current-main-profile.sh probe --out /workspace/twist-cache-next/profile-probe (missing gawk, no profile)

The first compiled Lean draft covered fixed columns; it passed. Before native
execution the theorem was generalized to arbitrary/repeated indices and actual
F43 base logs were kernel checked. Both sources/build receipts remain. Initial
and fresh final native runs pass; no unexpected failure, timeout or cap occurred.
Seven semantic rejection controls intentionally exit101 with no receipt.
Build/test elapsed times are diagnostic, not isolated research timings. Request
counts include unused binary-loop doublings and are not hardware instructions.
