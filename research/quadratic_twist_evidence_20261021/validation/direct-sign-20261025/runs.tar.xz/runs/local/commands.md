# Executed commands

From repository root with supported Cargo/Lean homes/cache and two build workers.
STUDY=research/quadratic_twist_evidence_20261021. Native commands capped600s,
fresh directories, compiled source frozen atd303efaee before first execution.

- c++ -std=c++17 -O2 -Wall -Wextra -Werror STUDY/native/direct-sign.cpp -lcrypto -o OUTPUT/producer
- cargo build --release --locked --manifest-path STUDY/native/direct-sign-audit/Cargo.toml
- OUTPUT/producer STUDY/native/reduced-s3-20261025/cases STUDY/native/adaptive-s3-20261025/cases STUDY/native/signed-cache-20261025/cases OUTPUT/cases
- AUDITOR audit REDUCED_CASES ADAPTIVE_CASES SIGNED_CASES OUTPUT/cases OUTPUT/audit.json
- bash research/quadratic_twist_evidence_20261021/run-direct-sign.sh /workspace/twist-direct-next/fresh-final
- bash tools/lean/proof-gate.sh --out /workspace/twist-direct-next/lean-gate-final STUDY/lean STUDY/lean-reduced STUDY/lean-adaptive STUDY/lean-phase STUDY/lean-known-roots STUDY/lean-signed-cache
- cargo test --release --locked --lib --quiet (network permission for existing loopback tests)
- python3 scripts/test_workflows_parse.py
- target/release/backlog validate XP-20261025-direct-sign-reference XP-20261025-j0-cubic-twist-transfer XP-20261025-cm8-quadratic-transfer
- python3 scripts/check_curve_names.py
- make check (reports/direct-sign-20261025); pdftoppm -scale-to1400 -png report.pdf ...

The first and fresh final native runs pass with identical outputs; no native
failure/cap occurred. Seven intentionally corrupted/rehashed payloads reject101.
First PDF text-equality check failed because large fraction/bracket extraction
changed order under Ghostscript. Exact source/log/before-after text retained;
flat coordinate notation fixes it. Both final pages rendered/inspected. The proposed next F13 route uses three existing registered models; it is metadata/mathematical planning, not an executed transfer. A standard-font layout preserves the final report below64KiB without deleting data or changing result text.
Existing faithful proofs and16 identity records are reused unchanged. No profile
was rerun during this immediate continuation; previously missinggawk remains a
profiling gate, not cost evidence. Conductor still unavailable, no task lease.
Build/test elapsed numbers are diagnostics, never isolated research timings.
