diff -ru research/quadratic_twist_evidence_20261021/native/cm8-transfer-20261025/cases /workspace/pr2381-cm8-dual-20261029/attempt-01/cases/reference 
