c++ -std=c++17 -O2 -Wall -Wextra -Werror research/quadratic_twist_evidence_20261021/native/cm8-dual.cpp -lcrypto -o /workspace/pr2381-cm8-dual-20261029/attempt-01/producer 
