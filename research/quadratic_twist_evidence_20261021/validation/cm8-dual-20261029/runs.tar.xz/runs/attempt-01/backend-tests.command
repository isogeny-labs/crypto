cargo test --release --locked --manifest-path research/quadratic_twist_evidence_20261021/native/cm8-dual-audit/Cargo.toml 
