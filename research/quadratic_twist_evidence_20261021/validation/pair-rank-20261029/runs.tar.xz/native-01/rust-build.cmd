cargo build --release --locked --offline --manifest-path research/quadratic_twist_evidence_20261021/native/pair-rank-audit/Cargo.toml 
