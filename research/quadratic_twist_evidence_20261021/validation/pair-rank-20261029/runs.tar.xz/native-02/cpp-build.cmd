c++ -std=c++17 -O2 -Wall -Wextra -Werror research/quadratic_twist_evidence_20261021/native/pair-rank.cpp -lcrypto -o /workspace/pr2381-pair-rank-20261029/native-02/producer 
