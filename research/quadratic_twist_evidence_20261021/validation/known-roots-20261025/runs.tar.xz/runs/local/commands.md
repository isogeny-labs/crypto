# Executed commands

From repository root, with pinned Cargo/Lean homes and MATHLIB_CACHE_DIR in the
supported local workspace. All native producer/auditor commands use timeout600.

- c++ -std=c++17 -O2 -Wall -Wextra -Werror research/quadratic_twist_evidence_20261021/native/known-roots.cpp -lcrypto -o OUTPUT/producer
- cargo build --release --locked --manifest-path research/quadratic_twist_evidence_20261021/native/known-roots-audit/Cargo.toml
- OUTPUT/producer STUDY/native/reduced-s3-20261025/cases STUDY/native/adaptive-s3-20261025/cases STUDY/native/phase-demand-20261025/cases OUTPUT/cases
- AUDITOR audit REDUCED_CASES ADAPTIVE_CASES PHASE_CASES OUTPUT/cases OUTPUT/audit.json
- bash research/quadratic_twist_evidence_20261021/run-known-roots.sh /workspace/twist-known-next/fresh-final
- bash tools/lean/proof-gate.sh --out /workspace/twist-known-next/lean-gate-final STUDY/lean STUDY/lean-reduced STUDY/lean-adaptive STUDY/lean-phase STUDY/lean-known-roots
- cargo test --release --locked --lib --quiet
- python3 scripts/test_workflows_parse.py
- cargo run --release --locked --bin backlog -- validate XP-20261025-known-factor-base-roots XP-20261025-signed-base-cache
- make check (in reports/known-roots-20261025); pdftoppm -scale-to1400 -png report.pdf ...
- bash current-main-tools-profile.sh probe --out /workspace/twist-known-next/profile-probe (exit2, missing gawk; no profile produced)

STUDY expands to research/quadratic_twist_evidence_20261021. Independent audit
receives no known scalar as an input to recovery. Raw fields and canonical hashes
bind the complete 80/800 comparison. First run at3ad11f812 rejects ordering;
corrected source83941917e precedes every successful execution. Build/test elapsed
numbers are diagnostics, not isolated research timings.
