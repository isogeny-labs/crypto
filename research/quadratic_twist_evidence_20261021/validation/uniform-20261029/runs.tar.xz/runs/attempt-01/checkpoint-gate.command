bash scripts/checkpoint.sh gate 
