c++ -std=c++17 -O2 -Wall -Wextra -Werror research/quadratic_twist_evidence_20261021/native/uniform-yield-v2.cpp -lcrypto -lgmpxx -lgmp -o /workspace/pr2381-uniform-20261029/attempt-02/producer 
