/workspace/pr2381-uniform-20261029/attempt-03/cargo-target/release/quadratic-twist-uniform-yield-audit corrupt false-degree /workspace/pr2381-uniform-20261029/attempt-03/controls/false-degree 
