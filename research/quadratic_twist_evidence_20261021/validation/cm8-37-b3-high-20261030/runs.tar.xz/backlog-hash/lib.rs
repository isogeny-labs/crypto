pub mod hash {
#[path="/workspace/crypto-pr2381-current/src/hash/sha1.rs"] pub mod sha1;
#[path="/workspace/crypto-pr2381-current/src/hash/sha256.rs"] pub mod sha256;
}
