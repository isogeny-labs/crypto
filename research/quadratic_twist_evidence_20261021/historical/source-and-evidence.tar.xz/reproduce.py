#!/usr/bin/env python3
"""Run the complete suite with a transcript, provenance, and result comparison."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import platform
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE_FILES = ['experiments.py', 'report.py', 'reproduce.py',
                'verify_evidence.py', 'requirements.txt', 'RUN.txt', 'README.md']


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def scientific_results(value):
    """Ignore only measured durations when comparing deterministic outputs."""
    if isinstance(value, dict):
        return {key: scientific_results(item) for key, item in value.items()
                if not key.endswith('seconds')}
    if isinstance(value, list):
        return [scientific_results(item) for item in value]
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--accept-results', action='store_true',
                        help='Regenerate the reference results after an intentional source change.')
    args = parser.parse_args()
    if not __debug__ or sys.flags.optimize:
        parser.error('Assertions are required; do not run with python -O.')
    results = ROOT/'results'
    results.mkdir(exist_ok=True)
    reference_file = results/'results.json'
    reference = json.loads(reference_file.read_text()) if reference_file.exists() else None
    hashes_before = {name: sha256(ROOT/name) for name in SOURCE_FILES}
    metadata = dict(started_at_utc=utc_now(), python=sys.version,
                    sympy=importlib.metadata.version('sympy'), platform=platform.platform(),
                    assertions_enabled=True, input_sha256=hashes_before,
                    reference_results_sha256=sha256(reference_file) if reference is not None else None,
                    reference_update_requested=args.accept_results)
    status = 1
    with (results/'run.log').open('w') as log:
        def emit(text):
            print(text, flush=True)
            log.write(text+'\n')
            log.flush()

        emit('Started UTC: '+metadata['started_at_utc'])
        emit('Python: '+platform.python_version())
        emit('SymPy: '+metadata['sympy'])
        emit('Experiment SHA-256: '+hashes_before['experiments.py'])
        try:
            with tempfile.TemporaryDirectory(prefix='twist-experiments-') as temporary:
                command = [sys.executable, '-u', str(ROOT/'experiments.py'), '--out', temporary]
                metadata['command_argv'] = command
                emit('Command: '+json.dumps(command))
                process = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE,
                                           stderr=subprocess.STDOUT, text=True, bufsize=1)
                for line in process.stdout:
                    emit(line.rstrip('\n'))
                metadata['experiment_exit_code'] = process.wait()
                emit('Experiment exit code: '+str(metadata['experiment_exit_code']))
                if process.returncode:
                    raise RuntimeError('Experiment process failed.')
                current = json.loads((Path(temporary)/'results.json').read_text())
                if current['source_sha256'] != hashes_before['experiments.py']:
                    raise RuntimeError('Result source hash does not match the executed source.')
                same = reference is not None and scientific_results(reference) == scientific_results(current)
                metadata['scientific_results_match_reference'] = same if reference is not None else None
                emit('Scientific results match previous reference: '+str(metadata['scientific_results_match_reference']))
                if reference is not None and not same and not args.accept_results:
                    shutil.copyfile(Path(temporary)/'results.json', results/'failed-results.json')
                    raise RuntimeError('Scientific results differ from the reference; inspect results/failed-results.json.')
                for name in ['results.json','relation_collection.csv']:
                    shutil.copyfile(Path(temporary)/name,results/name)
            emit('Command: '+json.dumps([sys.executable,str(ROOT/'report.py')]))
            rendered = subprocess.run([sys.executable,str(ROOT/'report.py')],cwd=ROOT,
                                      capture_output=True,text=True)
            for line in (rendered.stdout+rendered.stderr).splitlines():
                emit(line)
            if rendered.returncode:
                raise RuntimeError('Report generation failed.')
            hashes_after = {name: sha256(ROOT/name) for name in SOURCE_FILES}
            metadata['sources_unchanged_during_run'] = hashes_before == hashes_after
            if not metadata['sources_unchanged_during_run']:
                raise RuntimeError('An input file changed while the suite was running.')
            counts = current['exhaustive']['counts']
            metadata['summary'] = dict(curve_models=counts['curve_models'],
                                      s3_triples=counts['s3_ordered_triples_checked'],
                                      s4_quadruples=counts['s4_ordered_quadruples_checked'],
                                      complete_dlp_recoveries=sum(p['all_logs_recovered'] for p in current['pairings']))
            emit('Verified summary: '+json.dumps(metadata['summary'],sort_keys=True))
            status = 0
        except Exception as error:
            metadata['failure'] = f'{type(error).__name__}: {error}'
            emit(metadata['failure'])
        metadata['finished_at_utc'] = utc_now()
        metadata['runner_exit_code'] = status
        emit('Finished UTC: '+metadata['finished_at_utc'])
        emit('Runner exit code: '+str(status))
    metadata['output_sha256'] = {name: sha256(ROOT/name) for name in
                                ['results/results.json','results/relation_collection.csv',
                                 'results/run.log','report.html'] if (ROOT/name).exists()}
    (results/'run-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    manifest = SOURCE_FILES+list(metadata['output_sha256'])+['results/run-metadata.json']
    (ROOT/'SHA256SUMS').write_text(''.join(f'{sha256(ROOT/name)}  {name}\n' for name in manifest))
    return status


if __name__ == '__main__':
    sys.exit(main())
