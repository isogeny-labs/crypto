#!/usr/bin/env python3
"""Exact, reproducible experiments on quadratic twists and index calculus.

Run: python experiments.py --out results
Only the symbolic certificates require SymPy; all finite-field experiments use
the Python standard library. No secret keys, real targets, or external services.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import time
from collections import Counter
from itertools import product
from pathlib import Path


def prime_factors(n):
    factors = {}
    d = 2
    while d * d <= n:
        while n % d == 0:
            factors[d] = factors.get(d, 0) + 1
            n //= d
        d += 1
    if n > 1:
        factors[n] = factors.get(n, 0) + 1
    return factors


def nonsquare(p):
    return next(d for d in range(2, p) if pow(d, (p - 1) // 2, p) == p - 1)


class Field:
    """Fp or Fp[u]/(u^2-d), with a+b*u encoded as a+p*b."""

    def __init__(self, p, d=None):
        self.p, self.d = p, d
        self.size = p if d is None else p * p
        self.roots = {}
        for y in range(self.size):
            self.roots.setdefault(self.mul(y, y), []).append(y)

    def add(self, x, y):
        p = self.p
        if self.d is None:
            return (x + y) % p
        return ((x % p + y % p) % p) + p * ((x // p + y // p) % p)

    def neg(self, x):
        p = self.p
        if self.d is None:
            return -x % p
        return (-x % p) + p * (- (x // p) % p)

    def sub(self, x, y):
        return self.add(x, self.neg(y))

    def mul(self, x, y):
        p = self.p
        if self.d is None:
            return x * y % p
        a, b, c, e = x % p, x // p, y % p, y // p
        return (a * c + self.d * b * e) % p + p * ((a * e + b * c) % p)

    def inv(self, x):
        if not x:
            raise ZeroDivisionError
        p = self.p
        if self.d is None:
            return pow(x, -1, p)
        a, b = x % p, x // p
        norm_inv = pow((a * a - self.d * b * b) % p, -1, p)
        return a * norm_inv % p + p * (-b * norm_inv % p)

    def div(self, x, y):
        return self.mul(x, self.inv(y))

    def pow(self, x, n):
        if n < 0:
            x, n = self.inv(x), -n
        ans = 1
        while n:
            if n & 1:
                ans = self.mul(ans, x)
            x = self.mul(x, x)
            n >>= 1
        return ans

    def frob(self, x):
        if self.d is None:
            return x
        return x % self.p + self.p * (- (x // self.p) % self.p)

    def fmt(self, x):
        if self.d is None or x < self.p:
            return str(x)
        return f"{x % self.p}+{x // self.p}u"


class Tower(Field):
    """K[v]/(v^2-delta), relative Frobenius over K, for the subfield test."""

    def __init__(self, base, delta):
        self.base, self.p, self.q, self.d = base, base.p, base.size, delta
        assert base.pow(delta, (base.size-1)//2) == base.neg(1)
        self.size = self.q*self.q
        self.roots = {}
        for x in range(self.size):
            self.roots.setdefault(self.mul(x,x), []).append(x)

    def add(self, x, y):
        f, q = self.base, self.q
        return f.add(x % q, y % q) + q*f.add(x//q, y//q)

    def neg(self, x):
        f, q = self.base, self.q
        return f.neg(x % q) + q*f.neg(x//q)

    def mul(self, x, y):
        f, q = self.base, self.q
        a,b,c,e = x % q, x//q, y % q, y//q
        return f.add(f.mul(a,c), f.mul(self.d,f.mul(b,e))) + q*f.add(f.mul(a,e),f.mul(b,c))

    def inv(self, x):
        if not x:
            raise ZeroDivisionError
        f, q = self.base, self.q
        a,b = x % q, x//q
        ni = f.inv(f.sub(f.mul(a,a),f.mul(self.d,f.mul(b,b))))
        return f.mul(a,ni) + q*f.neg(f.mul(b,ni))

    def frob(self, x):
        return x % self.q + self.q*self.base.neg(x//self.q)

    def fmt(self, x):
        if x < self.q:
            return self.base.fmt(x)
        return f"({self.base.fmt(x % self.q)})+({self.base.fmt(x//self.q)})v"


class PolyField(Field):
    """Fp[w]/(monic irreducible polynomial); used to enumerate T_2,T_3,T_5."""

    def __init__(self,p,modulus):
        import sympy as s
        self.p,self.modulus,self.n = p,modulus,len(modulus)-1
        self.size = p**self.n
        w = s.symbols('w')
        assert modulus[-1] == 1
        assert s.Poly(sum(c*w**i for i,c in enumerate(modulus)),w,modulus=p).is_irreducible
        self.digits = []
        for value in range(self.size):
            digits = []
            for _ in range(self.n):
                digits.append(value % p)
                value //= p
            self.digits.append(digits)
        self.roots = {}
        for x in range(self.size):
            self.roots.setdefault(self.mul(x,x),[]).append(x)

    def encode(self,cs):
        ans = 0
        for c in reversed(cs):
            ans = ans*self.p+c % self.p
        return ans

    def add(self,x,y):
        return self.encode([a+b for a,b in zip(self.digits[x],self.digits[y])])

    def neg(self,x):
        return self.encode([-a for a in self.digits[x]])

    def mul(self,x,y):
        cs = [0]*(2*self.n-1)
        for i,a in enumerate(self.digits[x]):
            for j,b in enumerate(self.digits[y]):
                cs[i+j] += a*b
        for i in range(len(cs)-1,self.n-1,-1):
            c = cs[i] % self.p
            for j in range(self.n):
                cs[i-self.n+j] -= c*self.modulus[j]
        return self.encode(cs[:self.n])

    def inv(self,x):
        if not x:
            raise ZeroDivisionError
        return self.pow(x,self.size-2)

    def frob(self,x):
        return self.pow(x,self.p)

    def fmt(self,x):
        return '+'.join(f'{a}w^{i}' for i,a in enumerate(self.digits[x]) if a) or '0'


class Curve:
    """c*y^2=x^3+a*x+b, char>3. Infinity is None."""

    def __init__(self, field, a, b, c=1):
        self.f, self.a, self.b, self.c = field, a, b, c
        self.additions = 0
        f = field
        discr = f.add(f.mul(4 % f.p, f.pow(a, 3)),
                      f.mul(27 % f.p, f.pow(b, 2)))
        if not c or not discr:
            raise ValueError("singular curve or zero twist parameter")

    def rhs(self, x):
        f = self.f
        return f.add(f.add(f.pow(x, 3), f.mul(self.a, x)), self.b)

    def contains(self, point):
        return point is None or self.f.mul(self.c, self.f.pow(point[1], 2)) == self.rhs(point[0])

    def points(self, xs=None):
        f = self.f
        ans = [None]
        ci = f.inv(self.c)
        for x in range(f.size) if xs is None else xs:
            for y in f.roots.get(f.mul(ci, self.rhs(x)), []):
                ans.append((x, y))
        return ans

    def neg(self, point):
        return None if point is None else (point[0], self.f.neg(point[1]))

    def frob(self, point):
        return None if point is None else tuple(self.f.frob(x) for x in point)

    def add(self, P, Q):
        self.additions += 1
        if P is None:
            return Q
        if Q is None:
            return P
        f = self.f
        x, y = P
        z, w = Q
        if x == z:
            if f.add(y, w) == 0:
                return None
            slope = f.div(f.add(f.mul(3 % f.p, f.mul(x, x)), self.a),
                          f.mul(2 % f.p, f.mul(self.c, y)))
        else:
            slope = f.div(f.sub(w, y), f.sub(z, x))
        nx = f.sub(f.sub(f.mul(self.c, f.mul(slope, slope)), x), z)
        ny = f.sub(f.mul(slope, f.sub(x, nx)), y)
        return nx, ny

    def mul(self, n, P):
        if n < 0:
            return self.mul(-n, self.neg(P))
        ans = None
        while n:
            if n & 1:
                ans = self.add(ans, P)
            P = self.add(P, P)
            n >>= 1
        return ans

    def order(self, P, group_order):
        n = group_order
        for ell in prime_factors(n):
            while n % ell == 0 and self.mul(n // ell, P) is None:
                n //= ell
        assert self.mul(n, P) is None
        return n

    def fmt(self, P):
        return "O" if P is None else f"({self.f.fmt(P[0])}, {self.f.fmt(P[1])})"


def image(P, extension):
    return None if P is None else (P[0], extension.mul(extension.p, P[1]))


def character_count(p, a, b):
    count = p + 1
    for x in range(p):
        rhs = (x * x * x + a * x + b) % p
        if rhs:
            count += 1 if pow(rhs, (p - 1) // 2, p) == 1 else -1
    return count


def summation3(p, a, b, x, y, z):
    return (((x-y)**2 * z*z - 2*((x+y)*(x*y+a)+2*b)*z
             + (x*y-a)**2 - 4*b*(x+y)) % p)


def x_relations(C, p):
    """All ordered affine x-triples over Fp lifting to P+Q+R=O."""
    pts = C.points(range(p))[1:]
    triples = set()
    for P, Q in product(pts, repeat=2):
        R = C.add(P, Q)
        if R is not None and R[0] < p:
            triples.add((P[0], Q[0], R[0]))
    return triples


def summation4_checks(C,p,a,b):
    """Check resultant-defined S4 against all four-point lift relations."""
    by_x = {x:[] for x in range(p)}
    for P in C.points(range(p))[1:]:
        by_x[P[0]].append(P)
    sums = {(x,y): {C.add(P,Q) for P in by_x[x] for Q in by_x[y]}
            for x,y in product(range(p),repeat=2)}
    coeffs = {(x,y): ((x-y)**2 % p,
                     -2*((x+y)*(x*y+a)+2*b) % p,
                     ((x*y-a)**2-4*b*(x+y)) % p)
              for x,y in product(range(p),repeat=2)}
    count = 0
    for x,y,z,w in product(range(p),repeat=4):
        A,B,C0 = coeffs[x,y]
        D,F,G = coeffs[z,w]
        resultant = ((A*G-C0*D)**2-(A*F-B*D)*(B*G-C0*F)) % p
        # Each pair-sum set is invariant under negation.
        lifts = not sums[x,y].isdisjoint(sums[z,w])
        assert (resultant == 0) == lifts
        count += 1
    return count


def field_checks(fields):
    checked = 0
    for f in fields:
        for x in range(f.size):
            assert f.add(x, f.neg(x)) == 0
            assert f.frob(x) == f.pow(x, f.p)
            if x:
                assert f.mul(x, f.inv(x)) == 1
                assert f.inv(x) == f.pow(x, f.size - 2)
            checked += 1
        rng = random.Random(f.size)
        for _ in range(300):
            a, b, c = [rng.randrange(f.size) for _ in range(3)]
            assert f.mul(a, f.add(b, c)) == f.add(f.mul(a, b), f.mul(a, c))
    return checked


def exhaustive(primes):
    counts = Counter()
    examples = {}
    per_prime = []
    start = time.perf_counter()
    for p in primes:
        d = nonsquare(p)
        k, K = Field(p), Field(p, d)
        counts['field_elements_checked'] += field_checks([k, K])
        curve_count = 0
        for a, b in product(range(p), repeat=2):
            if (4*a**3 + 27*b*b) % p == 0:
                continue
            E, T = Curve(k, a, b), Curve(k, a, b, d)
            L, LT = Curve(K, a, b), Curve(K, a, b, d)
            base, twist, extension = E.points(), T.points(), L.points()
            base_set = set(base)
            anti = set(image(P, K) for P in twist)
            n, nt = len(base), len(twist)
            assert n == character_count(p, a, b)
            assert n + nt == 2*(p+1)
            assert len(extension) == n * nt
            plus_computed = {P for P in extension if L.frob(P) == P}
            minus_computed = {P for P in extension if L.frob(P) == L.neg(P)}
            assert plus_computed == base_set
            assert minus_computed == anti
            shared = base_set & anti
            assert shared == {P for P in base if E.mul(2, P) is None}
            for P in extension:
                assert L.contains(P)
                assert L.frob(L.frob(P)) == P
                # Trace and anti-trace land in the respective eigenspaces.
                A = L.add(P, L.frob(P))
                B = L.add(P, L.neg(L.frob(P)))
                assert A in base_set and B in anti
                assert L.add(A, B) == L.mul(2, P)
                counts['extension_points_checked'] += 1
            for U, V in product(twist, repeat=2):
                assert image(T.add(U, V), K) == L.add(image(U, K), image(V, K))
                counts['twist_group_law_checks'] += 1
            for P in twist:
                for scalar in range(6):
                    assert image(T.mul(scalar, P), K) == L.mul(scalar, image(P, K))
                    counts['scalar_preservation_checks'] += 1
            for A, B in product(base, anti):
                R = L.add(A, B)
                if R in base_set:
                    assert L.mul(2, B) is None
                    counts['mixed_sums_landing_in_plus'] += 1
                    if (B is not None and A is not None and R is not None
                            and 'two_torsion_exception' not in examples):
                        examples['two_torsion_exception'] = dict(
                            p=p, a=a, b=b, d=d, A=L.fmt(A), B=L.fmt(B),
                            R=L.fmt(R), B_order=2)
                if B is not None and L.order(B, nt) % 2 == 1:
                    assert R not in base_set
                    counts['nonzero_odd_twist_exclusions'] += 1
            triples = x_relations(L, p)
            twist_triples = x_relations(LT, p)
            assert triples == twist_triples
            for x, y, z in product(range(p), repeat=3):
                assert (summation3(p, a, b, x, y, z) == 0) == ((x, y, z) in triples)
                counts['s3_ordered_triples_checked'] += 1
            if p <= 7:
                counts['s4_ordered_quadruples_checked'] += summation4_checks(L,p,a,b)
            # Check every shared odd prime, including cases with nonzero trace.
            t = p + 1 - n
            for ell in prime_factors(math.gcd(n, nt)):
                if ell == 2:
                    continue
                assert t % ell == 0 and (p + 1) % ell == 0
                assert p % ell != 1 and p*p % ell == 1
                counts['shared_odd_prime_cases'] += 1
                if t and 'shared_prime_nonzero_trace' not in examples:
                    examples['shared_prime_nonzero_trace'] = dict(
                        p=p, a=a, b=b, r=ell, trace=t, n=n, twist_order=nt)
            # A full integral direct-product assertion need not hold at 2.
            if 'two_primary_product_failure' not in examples:
                e2 = sum(L.mul(2, P) is None for P in extension)
                product_e2 = len(shared)**2
                if e2 != product_e2:
                    examples['two_primary_product_failure'] = dict(
                        p=p, a=a, b=b, d=d, n=n, twist_order=nt,
                        extension_order=len(extension), extension_2_torsion=e2,
                        product_2_torsion=product_e2)
            # Independent associativity checks: exhaustive at p=5, sampled later.
            rng = random.Random(p*10000 + a*p + b)
            samples = product(base, repeat=3) if p == 5 else (
                tuple(rng.choice(base) for _ in range(3)) for _ in range(12))
            for A, B, C in samples:
                assert E.add(E.add(A, B), C) == E.add(A, E.add(B, C))
                counts['associativity_checks'] += 1
            curve_count += 1
            counts['curve_models'] += 1
        per_prime.append(dict(p=p, nonsquare=d, nonsingular_models=curve_count))
        print(f"exhaustive p={p}: {curve_count} nonsingular models checked", flush=True)
    return dict(counts=counts, examples=examples, per_prime=per_prime,
                elapsed_seconds=time.perf_counter()-start)


def symbolic_certificates():
    import sympy as s
    x, y, z, a, b, d, m, n, u = s.symbols('x y z a b d m n u')
    s1, s2, s3 = x+y+z, x*y+x*z+y*z, x*y*z
    canonical = (x-y)**2*z*z - 2*((x+y)*(x*y+a)+2*b)*z + (x*y-a)**2-4*b*(x+y)
    symmetric = (s2-a)**2 - 4*s1*(s3+b)
    assert s.expand(canonical-symmetric) == 0
    # Vieta for f(X)-d(mX+n)^2: s1=d*m^2, s2=a-2*d*m*n,
    # s3=d*n^2-b. This checks cancellation over the integer polynomial ring.
    assert s.expand(((a-2*d*m*n)-a)**2-4*(d*m*m)*(d*n*n-b+b)) == 0
    # Direct substitution for the isomorphism's curve equation.
    assert s.expand((u*u*(x**3+a*x+b)/d-(x**3+a*x+b)).subs(u*u, d)) == 0
    return dict(sympy_version=s.__version__,
                canonical_equals_symmetric=True, twist_parameter_cancels=True,
                isomorphism_equation=True,
                symmetric_s3='(s2-a)^2 - 4*s1*(s3+b)',
                vieta={'s1':'d*m^2', 's2':'a-2*d*m*n', 's3':'d*n^2-b'})


def bsgs_curve(C, P, Q, r):
    width = math.isqrt(r) + 1
    table, R = {}, None
    for j in range(width):
        table.setdefault(R, j)
        R = C.add(R, P)
    giant = C.neg(C.mul(width, P))
    R = Q
    for i in range(width+1):
        if R in table:
            answer = (i*width + table[R]) % r
            assert C.mul(answer, P) == Q
            return answer
        R = C.add(R, giant)
    raise AssertionError('no discrete logarithm')


def no_transfer_examples():
    # A prime-order curve with a 13-smooth twist; both groups are intentionally tiny.
    p, k = 1009, Field(1009)
    chosen = None
    for a, b in product(range(30), range(1009)):
        if (4*a**3+27*b*b) % p and character_count(p, a, b) == 1019:
            chosen = a, b
            break
    assert chosen is not None
    a, b = chosen
    d = nonsquare(p)
    E, T = Curve(k, a, b), Curve(k, a, b, d)
    base, twist = E.points(), T.points()
    assert len(base) == 1019 and len(twist) == 1001
    assert prime_factors(1019) == {1019:1}
    assert prime_factors(1001) == {7:1, 11:1, 13:1}
    P = base[1]
    secret = 617
    Q = E.mul(secret, P)
    assert bsgs_curve(E, P, Q, 1019) == secret
    assert all(T.mul(1019, R) is not None for R in twist[1:])
    K, L = Field(p, d), None
    L = Curve(K, a, b)
    assert all(L.mul(1001, image(R, K)) is None for R in twist)
    assert L.mul(1001, P) is not None
    smooth = dict(p=p, a=a, b=b, d=d, curve_order=1019, twist_order=1001,
                  twist_factorization=prime_factors(1001), P=E.fmt(P), Q=E.fmt(Q),
                  recovered_log=secret, twist_r_torsion_points=1,
                  theorem='Every homomorphism from the order-1019 group to the order-1001 group is zero.')
    # An anomalous twist does not make the original curve anomalous.
    p, k = 11, Field(11)
    for a, b in product(range(p), repeat=2):
        if (4*a**3+27*b*b) % p and character_count(p, a, b) == 13:
            break
    T = Curve(k, a, b, nonsquare(p))
    assert len(T.points()) == p
    anomalous = dict(p=p, a=a, b=b, curve_order=13, twist_order=11,
                     trace=-1, original_anomalous=False)
    return dict(smooth_twist=smooth, anomalous_twist=anomalous)


def subfield_descent_example():
    """A model descends after twisting; its DLP subgroup does not become rational."""
    p = 7
    K = Field(p, nonsquare(p))
    delta = next(z for z in range(p,K.size) if K.pow(z,(K.size-1)//2) == K.neg(1))
    F = Tower(K,delta)
    a,b = 1,1
    aa,bb = K.mul(a,K.pow(delta,2)),K.mul(b,K.pow(delta,3))
    E0, E0K, E0F = Curve(Field(p),a,b),Curve(K,a,b),Curve(F,a,b)
    twisted = Curve(K,aa,bb)
    pts = twisted.points()
    assert len(E0.points()) == 5 and len(E0K.points()) == 55 and len(pts) == 45
    assert aa >= p or bb >= p
    # j=1728*4a^3/(4a^3+27b^2); coefficients may leave Fp while j stays.
    def j_invariant(C):
        f = C.f
        numerator = f.mul(1728 % p, f.mul(4 % p,f.pow(C.a,3)))
        denominator = f.add(f.mul(4 % p,f.pow(C.a,3)),f.mul(27 % p,f.pow(C.b,2)))
        return f.div(numerator,denominator)
    assert j_invariant(twisted) == j_invariant(E0K) < p
    v = K.size
    assert F.pow(v,2) == delta
    ix,iy = F.inv(delta),F.inv(F.mul(delta,v))
    def psi(P):
        return None if P is None else (F.mul(P[0],ix),F.mul(P[1],iy))
    images = {psi(P) for P in pts}
    full = E0F.points()
    anti = {P for P in full if E0F.frob(P) == E0F.neg(P)}
    assert images == anti
    assert len(full) == 55*45
    for P in full:
        assert F.frob(P[0]) == F.pow(P[0],K.size) if P is not None else True
    for P,Q in product(pts,repeat=2):
        assert psi(twisted.add(P,Q)) == E0F.add(psi(P),psi(Q))
    U = next(P for P in pts[1:] if twisted.order(P,len(pts)) % 3 == 0)
    P = twisted.mul(twisted.order(U,len(pts))//3,U)
    mapped = psi(P)
    assert E0F.mul(3,mapped) is None and mapped is not None
    assert mapped not in set(E0K.points())
    return dict(p=p,base_quadratic_nonsquare=K.d,delta=K.fmt(delta),
                source_a=K.fmt(aa),source_b=K.fmt(bb),subfield_a=a,subfield_b=b,
                j=j_invariant(twisted),source_order=len(pts),
                subfield_order=5,subfield_model_over_K_order=55,
                subgroup_order=3,source_point=twisted.fmt(P),
                mapped_point=E0F.fmt(mapped),mapped_point_K_rational=False,
                splitting_field_size=F.size,group_law_checks=len(pts)**2,
                trace_zero_points_checked=len(images))


def trace_zero_experiments():
    rows = []
    for p,modulus in [(5,[3,0,1]),(5,[1,1,0,1]),
                      (5,[1,4,0,0,0,1]),(7,[1,1,0,1])]:
        field = PolyField(p,modulus)
        C,base = Curve(field,1,1),Curve(Field(p),1,1)
        pts,base_pts = C.points(),base.points()
        kernel,trace_image,anti_image = set(),set(),set()
        for P in pts:
            trace,U = None,P
            for _ in range(field.n):
                trace = C.add(trace,U)
                U = C.frob(U)
            assert U == P
            assert trace in set(base_pts)
            trace_image.add(trace)
            if trace is None:
                kernel.add(P)
            anti_image.add(C.add(C.frob(P),C.neg(P)))
        assert kernel == anti_image
        assert trace_image == set(base_pts)
        assert len(kernel)*len(base_pts) == len(pts)
        # Integer Frobenius recurrence independently predicts all point counts.
        t = p+1-len(base_pts)
        s0,s1 = 2,t
        for _ in range(2,field.n+1):
            s0,s1 = s1,t*s1-p*s0
        assert len(pts) == p**field.n+1-s1
        dimension = field.n-1
        rows.append(dict(p=p,extension_degree=field.n,modulus=modulus,
                         base_order=len(base_pts),extension_order=len(pts),
                         trace_zero_order=len(kernel),dimension=dimension,
                         trace_surjective=True,frobenius_minus_identity_image_equals_kernel=True,
                         ic_q_exponent=None if dimension<2 else 2-2/dimension,
                         generic_q_exponent=dimension/2,
                         exponent_values_are_theoretical_not_runtime_measurements=True))
        print(f"trace-zero p={p}, n={field.n}: kernel order {len(kernel)}, dimension {dimension}",flush=True)
    return rows


def line_quotient(C, A, B, X):
    """Miller g_(A,B)(X), using affine functions on a monic Weierstrass model."""
    assert C.c == 1 and A is not None and B is not None and X is not None
    f = C.f
    if A[0] == B[0] and f.add(A[1], B[1]) == 0:
        return f.sub(X[0], A[0])
    if A == B:
        slope = f.div(f.add(f.mul(3 % f.p, f.pow(A[0], 2)), C.a),
                      f.mul(2 % f.p, A[1]))
    else:
        slope = f.div(f.sub(B[1], A[1]), f.sub(B[0], A[0]))
    numerator = f.sub(f.sub(X[1], A[1]), f.mul(slope, f.sub(X[0], A[0])))
    AB = C.add(A, B)
    denominator = 1 if AB is None else f.sub(X[0], AB[0])
    return f.div(numerator, denominator)


def miller(C, P, X, n):
    f, value, V = C.f, 1, P
    for bit in bin(n)[3:]:
        value = f.mul(f.mul(value, value), line_quotient(C, V, V, X))
        V = C.add(V, V)
        if bit == '1':
            value = f.mul(value, line_quotient(C, V, P, X))
            V = C.add(V, P)
    assert V is None
    return value


def weil(C, P, S, r):
    if P is None or S is None:
        return 1
    ans = C.f.div(miller(C, P, S, r), miller(C, S, P, r))
    return C.f.neg(ans) if r % 2 else ans


class LinearSystem:
    def __init__(self, modulus, width):
        self.p, self.width, self.rows = modulus, width, {}

    def insert(self, row, rhs):
        p = self.p
        row = [v % p for v in row] + [rhs % p]
        for pivot in sorted(self.rows):
            c = row[pivot]
            row = [(x-c*y) % p for x, y in zip(row, self.rows[pivot])]
        pivot = next((i for i, x in enumerate(row[:-1]) if x), None)
        if pivot is None:
            assert row[-1] == 0, 'inconsistent relation system'
            return False
        scale = pow(row[pivot], -1, p)
        row = [x*scale % p for x in row]
        for i, old in list(self.rows.items()):
            c = old[pivot]
            self.rows[i] = [(x-c*y) % p for x,y in zip(old,row)]
        self.rows[pivot] = row
        return True

    def solution(self):
        assert len(self.rows) == self.width
        return [self.rows[i][-1] for i in range(self.width)]


def finite_field_index_calculus(K, g, target, r, seed):
    """Polynomial factor base u+c; actual relation collection and modular linear algebra.

    This is a deliberately small degree-two-field demonstration. Constants die
    under z -> z^h, h=(p^2-1)/r. It is not an asymptotic benchmark.
    """
    p, h = K.p, (K.size-1)//r
    assert math.gcd(h, r) == 1
    cs = list(range(1, min(7, p)))
    elements = [p+c for c in cs]
    system = LinearSystem(r, len(cs))
    rng = random.Random(seed)
    relations, attempts, independent_relations = 0, 0, []

    def smooth(z):
        leading = z // p
        if not leading:
            return -1  # nonzero constant
        c = z % p * pow(leading, -1, p) % p
        return cs.index(c) if c in cs else None

    def random_product(z):
        exps = [0]*len(cs)
        for _ in range(rng.randrange(1, len(cs)+1)):
            i, exponent = rng.randrange(len(cs)), rng.choice([-3,-2,-1,1,2,3])
            exps[i] += exponent
            z = K.mul(z, K.pow(elements[i], exponent))
        return z, exps

    while len(system.rows) < len(cs) and attempts < 100000:
        attempts += 1
        exponent = rng.randrange(r)
        z, exps = random_product(K.pow(g, exponent))
        j = smooth(z)
        if j is None:
            continue
        row = [-e for e in exps]
        if j != -1:
            row[j] += 1
        relations += 1
        if system.insert(row, exponent*h):
            independent_relations.append(dict(coefficients=row, rhs=exponent*h % r))
    logs = system.solution()
    for elem, log in zip(elements, logs):
        assert K.pow(g, log) == K.pow(elem, h)
    descent_attempts = 0
    while descent_attempts < 100000:
        descent_attempts += 1
        exponent = rng.randrange(r)
        z, exps = random_product(K.mul(target, K.pow(g, exponent)))
        j = smooth(z)
        if j is None:
            continue
        value = (0 if j == -1 else logs[j])-exponent*h-sum(e*l for e,l in zip(exps,logs))
        answer = value*pow(h, -1, r) % r
        assert K.pow(g, answer) == target
        return dict(recovered_log=answer, factor_base=[f'u+{c}' for c in cs],
                    projected_factor_base_logs=logs, projection_exponent=h,
                    relation_attempts=attempts, smooth_relations=relations,
                    relation_rank=len(system.rows), independent_relations=independent_relations,
                    individual_log_attempts=descent_attempts)
    raise AssertionError('individual logarithm did not descend')


def restricted_relation_family(K,g,r):
    """Exhaust every g^a*(u+i)^(+-1)*(u+j)^(+-1), i,j=1,...,6."""
    p,h = K.p,(K.size-1)//r
    cs = list(range(1,7))
    system = LinearSystem(r,len(cs))
    relations = attempts = 0
    for a,i,j,e1,e2 in product(range(r),range(6),range(6),[-1,1],[-1,1]):
        z = K.mul(K.pow(g,a),K.mul(K.pow(p+cs[i],e1),K.pow(p+cs[j],e2)))
        attempts += 1
        lead = z//p
        c = None if not lead else z % p*pow(lead,-1,p) % p
        if lead and c not in cs:
            continue
        row = [0]*6
        row[i] -= e1
        row[j] -= e2
        if lead:
            row[cs.index(c)] += 1
        relations += 1
        system.insert(row,a*h)
    return dict(attempts=attempts,smooth_relations=relations,
                rank=len(system.rows),unknowns=6,
                exhaustive_within_stated_family=True)


def pairing_experiment(p, r):
    assert p % 4 == 3 and (p+1) % r == 0
    d = nonsquare(p)
    k, K = Field(p), Field(p, d)
    E, T, L = Curve(k, 1, 0), Curve(k, 1, 0, d), Curve(K, 1, 0)
    base, twist = E.points(), T.points()
    assert len(base) == len(twist) == p+1
    P = next(R for U in base[1:] if (R := E.mul((p+1)//r, U)) is not None)
    S0 = next(R for U in twist[1:] if (R := T.mul((p+1)//r, U)) is not None)
    S = image(S0, K)
    assert L.mul(r, P) is None and L.mul(r, S) is None
    assert L.frob(P) == P and L.frob(S) == L.neg(S)
    g = weil(L, P, S, r)
    assert g != 1 and K.pow(g, r) == 1 and K.pow(g, p) == K.inv(g)
    bilinear = 0
    for a, b in product(range(r), repeat=2):
        assert weil(L, L.mul(a, P), L.mul(b, S), r) == K.pow(g, a*b)
        bilinear += 1
    secret = (r*2//3) or 1
    Q = L.mul(secret, P)
    target = weil(L, Q, S, r)
    ic = finite_field_index_calculus(K, g, target, r, p*1000+r)
    assert ic['recovered_log'] == secret
    assert bsgs_curve(L, P, Q, r) == secret
    # Check all possible toy logarithms through the actual reduction and solver.
    all_logs = 0
    for a in range(r):
        reduced = weil(L, L.mul(a, P), S, r)
        assert finite_field_index_calculus(K, g, reduced, r, 10000*p+a)['recovered_log'] == a
        all_logs += 1
    print(f"pairing/index calculus p={p}, r={r}: all {r} logs recovered", flush=True)
    restricted = restricted_relation_family(K,g,r) if p == 67 else None
    if restricted:
        assert restricted['rank'] == 5
    return dict(p=p, d=d, a=1, b=0, r=r, embedding_degree=2,
                P=L.fmt(P), S0=T.fmt(S0), S=L.fmt(S), Q=L.fmt(Q),
                pairing_generator=K.fmt(g), pairing_target=K.fmt(target),
                secret=secret, bilinearity_checks=bilinear, all_logs_recovered=all_logs,
                index_calculus=ic,restricted_two_factor_family=restricted)


def relation_collection_benchmark():
    """Controlled twist-vs-original experiment, fixed prime-order subgroup.

    E/Fp is embedded in Fp^2; its image in the twist is restricted to the
    isomorphic subgroup. Enumeration cost is held equal by transporting the
    same x factor base. We count ordered 2-sums, rather than time noisy solvers.
    """
    rows = []
    for p in [101, 211, 401, 809]:
        k, K = Field(p), Field(p, nonsquare(p))
        chosen = None
        for a,b in product(range(20), range(p)):
            if (4*a**3+27*b*b) % p:
                n = character_count(p,a,b)
                if n != p and n > p//2 and prime_factors(n) == {n:1}:
                    chosen = a,b,n
                    break
        assert chosen
        a,b,r = chosen
        E, T = Curve(K,a,b), Curve(K,a,b,K.d)
        points = Curve(k,a,b).points()
        P = points[1]
        target = E.mul(r//3,P)
        invu = K.inv(p)
        to_twist = lambda R: None if R is None else (R[0],K.mul(invu,R[1]))
        # Use a deterministic x-restricted factor base, invariant under negation.
        bound = math.isqrt(p)
        B = [R for R in points[1:] if R[0] < bound]
        BT = list(map(to_twist,B))
        hits, thits, checks = 0, 0, 0
        full_relation_hist, twist_relation_hist = Counter(), Counter()
        t0 = time.perf_counter()
        for i,j in product(range(len(B)), repeat=2):
            A = E.add(B[i], B[j])
            C = T.add(BT[i], BT[j])
            assert to_twist(A) == C
            full_relation_hist[A] += 1
            twist_relation_hist[C] += 1
            hits += A == target
            thits += C == to_twist(target)
            checks += 1
        elapsed = time.perf_counter()-t0
        assert hits == thits
        assert {to_twist(A): v for A,v in full_relation_hist.items()} == dict(twist_relation_hist)
        rows.append(dict(p=p,a=a,b=b,r=r,x_bound=bound,factor_base_size=len(B),
                         ordered_pairs=checks,original_target_hits=hits,
                         transported_twist_target_hits=thits,
                         full_relation_histograms_equal=True,
                         total_verification_seconds=elapsed))
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=Path(__file__).parent/'results')
    parser.add_argument('--primes', default='5,7,11,13,17,19')
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    result = dict(scope='quadratic twists, characteristic > 3; all points valid',
                  seed_policy='fixed integer seeds embedded in source',
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  symbolic=symbolic_certificates())
    result['exhaustive'] = exhaustive([int(p) for p in args.primes.split(',')])
    result['no_transfer'] = no_transfer_examples()
    result['subfield_descent'] = subfield_descent_example()
    result['trace_zero'] = trace_zero_experiments()
    result['pairings'] = [pairing_experiment(p,r) for p,r in [(43,11),(67,17),(211,53)]]
    result['transported_relation_collection'] = relation_collection_benchmark()
    result['total_seconds'] = time.perf_counter()-started
    (args.out/'results.json').write_text(json.dumps(result, indent=2)+'\n')
    with (args.out/'relation_collection.csv').open('w', newline='') as stream:
        rows = result['transported_relation_collection']
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(dict(curves=result['exhaustive']['counts']['curve_models'],
                         s3_triples=result['exhaustive']['counts']['s3_ordered_triples_checked'],
                         pairing_logs=sum(x['all_logs_recovered'] for x in result['pairings']),
                         seconds=round(result['total_seconds'],2)), indent=2))
    print(f"Results: {args.out/'results.json'}")


if __name__ == '__main__':
    main()
