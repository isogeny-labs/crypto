#!/usr/bin/env python3
"""Independently validate saved hashes and finite-field DLP certificates."""

import hashlib
import json
from pathlib import Path

import sympy


ROOT = Path(__file__).resolve().parent


def require(condition,message):
    if not condition:
        raise SystemExit(message)


def mul(x,y,p,d):
    """Separate tuple representation, independent of the experiment engine."""
    a,b = x
    c,e = y
    return ((a*c+d*b*e) % p,(a*e+b*c) % p)


def power(x,n,p,d):
    ans = (1,0)
    while n:
        if n & 1:
            ans = mul(ans,x,p,d)
        x = mul(x,x,p,d)
        n //= 2
    return ans


def parse_element(text):
    if text.endswith('u'):
        a,b = text[:-1].split('+')
        return int(a),int(b)
    return int(text),0


def main():
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        expected,name = line.split('  ',1)
        actual = hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
        require(actual == expected,f'Checksum mismatch: {name}')
    metadata = json.loads((ROOT/'results/run-metadata.json').read_text())
    require(metadata['experiment_exit_code'] == 0,'The recorded experiment failed.')
    require(metadata['runner_exit_code'] == 0,'The recorded runner failed.')
    require(metadata['sources_unchanged_during_run'],'Inputs changed during the run.')
    results = json.loads((ROOT/'results/results.json').read_text())
    require(results['source_sha256'] == metadata['input_sha256']['experiments.py'],
            'Source hash mismatch between results and provenance.')
    checked = 0
    for case in results['pairings']:
        p,r,d = case['p'],case['r'],case['d']
        ic = case['index_calculus']
        rows = ic['independent_relations']
        matrix = sympy.Matrix([row['coefficients'] for row in rows])
        require(matrix.rows == matrix.cols == len(ic['factor_base']),
                'Relation certificate has unexpected dimensions.')
        require(int(matrix.det()) % r != 0,'Relation matrix is singular modulo r.')
        logs = ic['projected_factor_base_logs']
        for row in rows:
            require(sum(a*b for a,b in zip(row['coefficients'],logs)) % r == row['rhs'],
                    'A factor-base log does not satisfy a saved relation.')
        g = parse_element(case['pairing_generator'])
        target = parse_element(case['pairing_target'])
        require(g != (1,0) and power(g,r,p,d) == (1,0),'Pairing generator has incorrect order.')
        require(power(g,ic['recovered_log'],p,d) == target,'The saved DLP certificate is false.')
        for name,log in zip(ic['factor_base'],logs):
            c = int(name.split('+')[1])
            require(power((c,1),ic['projection_exponent'],p,d) == power(g,log,p,d),
                    'Projected factor-base logarithm is false.')
        checked += 1
    print('PASS: all SHA-256 checksums match.')
    print('PASS: successful execution and unchanged input hashes are recorded.')
    print(f'PASS: independently verified {checked} full-rank relation matrices and finite-field DLP certificates.')


if __name__ == '__main__':
    main()
