#!/usr/bin/env python3
"""Build an offline HTML report from the exact experiment output."""

import html
import json
from pathlib import Path


ROOT = Path(__file__).parent
DATA = ROOT/'results'/'results.json'
r = json.loads(DATA.read_text())
c = r['exhaustive']['counts']


def esc(value):
    return html.escape(str(value))


def table(headings, rows):
    return ('<div class="table-wrap"><table><thead><tr>'
            + ''.join(f'<th>{esc(h)}</th>' for h in headings)
            + '</tr></thead><tbody>'
            + ''.join('<tr>'+''.join(f'<td>{esc(v)}</td>' for v in row)+'</tr>' for row in rows)
            + '</tbody></table></div>')


coverage = table(['Exact check','Count'], [
    ('Nonsingular short Weierstrass models',f"{c['curve_models']:,}"),
    ('Extension-field points enumerated',f"{c['extension_points_checked']:,}"),
    ('Twist group-law comparisons',f"{c['twist_group_law_checks']:,}"),
    ('Scalar-preservation comparisons',f"{c['scalar_preservation_checks']:,}"),
    ('Ordered S3 x-coordinate triples',f"{c['s3_ordered_triples_checked']:,}"),
    ('Ordered S4 x-coordinate quadruples',f"{c['s4_ordered_quadruples_checked']:,}"),
    ('Nonzero odd-order twist contributions excluded',f"{c['nonzero_odd_twist_exclusions']:,}"),
    ('Shared odd-prime cases',f"{c['shared_odd_prime_cases']:,}"),
    ('Pairing bilinearity comparisons',sum(x['bilinearity_checks'] for x in r['pairings'])),
    ('DLPs recovered through pairing + finite-field index calculus',
     sum(x['all_logs_recovered'] for x in r['pairings'])),
])

verdicts = table(['Precise statement','Verdict','Reason'],[
    ('The splitting-field twist isomorphism preserves a DLP.','Proved',
     'An elliptic-curve isomorphism preserves addition and scalar multiplication.'),
    ('Twist-rational points become the minus Frobenius eigenspace.','Proved',
     'Frobenius sends sqrt(d) to -sqrt(d); the converse follows coordinatewise.'),
    ('Curve and twist have the same geometric x-coordinate relation conditions.','Proved',
     'The isomorphism fixes x. S3 is also certified by a polynomial identity.'),
    ('Adding pure twist points provides new relations in the odd-order plus component.',
     'False in this precise sense','The twist sum must be 2-torsion, hence its odd part vanishes.'),
    ('All nonzero twist contributions are impossible.','False',
     'A concrete nonzero 2-torsion exception is exhibited below.'),
    ('The quadratic trace-zero construction produces dimension greater than one.',
     'False','Its dimension is exactly one.'),
    ('A model over a smaller field automatically moves the DLP into its rational-point group.',
     'False','The explicit F49 example maps the target into E(F2401), outside E(F49).'),
    ('A shared odd prime on a curve and its quadratic twist gives embedding degree 2.',
     'Proved','The two point orders imply q=-1 modulo that prime.'),
    ('A smooth twist order implies a smooth original order or a rational homomorphic transfer.',
     'False','Orders 1019 and 1001=7*11*13 give a counterexample.'),
    ('These experiments prove general prime-field ECDLP hardness or exclude every twist-assisted algorithm.',
     'Not established','Finite experiments and the stated obstructions do not prove a general lower bound.'),
])

prime_rows = table(['p','Chosen nonsquare d','Models checked'],[
    (row['p'],row['nonsquare'],row['nonsingular_models']) for row in r['exhaustive']['per_prime']])

trace_rows = table(['q','Extension degree n','|E(Fq)|','|E(Fqⁿ)|','|Tn|','Dimension'],[
    (row['p'],row['extension_degree'],row['base_order'],row['extension_order'],
     row['trace_zero_order'],row['dimension']) for row in r['trace_zero']])

transport_rows = table(['p','Target prime r','Factor-base points','Ordered pairs','All target histograms equal'],[
    (row['p'],row['r'],row['factor_base_size'],row['ordered_pairs'],
     row['full_relation_histograms_equal']) for row in r['transported_relation_collection']])

pairing_rows = table(['p','r','e(P,S)','Displayed log recovered','All logs recovered',
                      'Relation attempts / rank'],[
    (row['p'],row['r'],row['pairing_generator'],row['index_calculus']['recovered_log'],
     row['all_logs_recovered'],f"{row['index_calculus']['relation_attempts']} / {row['index_calculus']['relation_rank']}")
    for row in r['pairings']])

report = '''<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Twists, ECDLP, and index calculus: experiments and proofs</title>
<style>
:root { color-scheme: light; --ink:#142335; --muted:#45576d; --line:#dce3eb; --accent:#136a63; }
body { margin:0; color:var(--ink); background:#f5f7fa; font:17px/1.6 system-ui,sans-serif; }
main { max-width:1050px; margin:0 auto; padding:48px 26px 80px; background:white; }
h1 { line-height:1.15; font-size:36px; max-width:850px; margin:0 0 20px; }
h2 { font-size:25px; margin-top:48px; padding-top:14px; border-top:1px solid var(--line); }
h3 { font-size:19px; margin-top:30px; }
p { max-width:950px; } a { color:#075cb0; }
.lead { font-size:20px; } .small { color:var(--muted); font-size:14px; }
.notice { background:#eef7f5; border-left:4px solid var(--accent); padding:12px 18px; }
.table-wrap { overflow:auto; margin:20px 0; }
table { border-collapse:collapse; width:100%; font-size:15px; text-align:left; }
th,td { padding:11px 12px; vertical-align:top; border-bottom:1px solid var(--line); }
th { background:#edf2f7; } tr:nth-child(even) td { background:#fafbfd; }
code,pre { font-family:ui-monospace,monospace; }
code { font-size:.9em; background:#f0f3f6; padding:2px 4px; border-radius:3px; }
pre { white-space:pre-wrap; overflow-wrap:anywhere; background:#f1f5f9; padding:15px 18px; font-size:15px; }
li { margin:7px 0; } .proof { border-left:3px solid #c7d8e8; padding-left:18px; }
@media print { body { background:white; } main { padding:0; } table { font-size:11px; } h2 { break-after:avoid; } }
</style>
<main>
<p class="small">Reproducible finite-field research · all points valid · characteristic greater than 3</p>
<h1>Twists, ECDLP, and index calculus: experiments and proofs</h1>
<p class="lead">The structural claims hold with precise subgroup restrictions. A twist supplies a genuine
pairing reduction in the examples below. Directly mixing curve and twist factor bases supplies no
new contribution to the odd-order plus component.</p>
<div class="notice"><strong>What “prove or disprove” means here.</strong> General statements below have
algebraic proofs or explicit counterexamples. Exhaustive computations verify finite cases.
The computations do not prove a general lower bound for ECDLP, an asymptotic speedup, or the
nonexistence of other twist-assisted algorithms. All DLP instances are small and intentionally solvable.</div>

<h2>Results at a glance</h2>
VERDICTS
<h2>Scope and coverage</h2>
<p>For every p below, the program enumerates every pair (a,b) with 4a³+27b² ≠ 0 modulo p,
using one nonsquare d. These are curve models, not distinct isomorphism classes. All nonsquares
define the same quadratic-twist class: their ratios are squares. S3 is checked on every ordered
base-field x-triple for every model. S4 is checked on every ordered x-quadruple for p=5 and p=7.</p>
PRIMES
COVERAGE
<p>Field operations are exact integer operations. Independent checks include a character-sum
point count, a Frobenius point-count recurrence, Fermat inverse comparisons, and associativity
checks. The full symbolic identities are checked over the integer polynomial ring using SymPy.</p>

<h2>1. Splitting-field isomorphism and rationality</h2>
<p>Let k=Fq have odd characteristic, let d be a nonsquare, and write</p>
<pre>E: y²=f(x),      Eᵈ: d y²=f(x),      f(x)=x³+a x+b.
K=Fq²=k(u),      u²=d.
φ:Eᵈ→E,         φ(x,y)=(x,u y).</pre>
<div class="proof"><p><strong>Proof.</strong> This is an invertible change of projective coordinates
fixing the point at infinity. It is therefore an isomorphism of elliptic curves, hence
φ(U+V)=φ(U)+φ(V) and φ([m]U)=[m]φ(U). In coordinates, a chord of slope s on Eᵈ has
x(U+V)=d s²−x(U)−x(V), while its image chord has slope u s and the same resulting x.
The same calculation covers tangents; infinity and vertical chords follow directly.</p>
<p>Thus Q=[a]P transfers to an equivalent DLP on Eᵈ(K). It does not automatically transfer
to Eᵈ(k). This field-of-definition distinction is essential.</p></div>
<h3>Point-count identities</h3>
<div class="proof"><p>For each x∈k, E has 1+χ(f(x)) affine lifts and Eᵈ has
1+χ(f(x)/d)=1−χ(f(x)), where χ is the quadratic character with χ(0)=0.
Summing over x and adding the two points at infinity gives
|E(k)|+|Eᵈ(k)|=2q+2. If |E(k)|=q+1−t, the twist order is q+1+t.
The Frobenius roots α,β satisfy α+β=t and αβ=q, so α²+β²=t²−2q.
Consequently |E(Fq²)|=q²+1−(t²−2q)=(q+1−t)(q+1+t).
These identities are checked for every enumerated model.</p></div>

<h2>2. Frobenius eigenspaces and mixed relations</h2>
<p>Let π be q-power Frobenius on E. Since uᵠ=−u,</p>
<pre>E(k)=ker(π−1),       φ(Eᵈ(k))=ker(π+1) ⊂ E(K).
E(k) ∩ φ(Eᵈ(k)) = E(k)[2].</pre>
<div class="proof"><p><strong>Proof of the converse.</strong> If π(x,y)=(x,−y), then x∈k and
(y/u)ᵠ=y/u. Therefore (x,y/u)∈Eᵈ(k). A point in both eigenspaces equals its negative,
so it is 2-torsion; conversely a rational 2-torsion point lies in both.</p>
<p><strong>Mixed-relation obstruction.</strong> Suppose a relation has the form R=A+B, where
R and A are in E(k) and B is a sum of embedded twist-rational points. Frobenius gives
R=A−B, so [2]B=O. After projection to any odd-primary component, B=O.
Equivalently, a zero-sum mixed relation splits into separate plus and minus relations up to
shared 2-torsion. This argument applies to arbitrary numbers of summands and coefficients.</p></div>
<p>This rules out a specific proposed gain: adding pure minus-eigenspace points to a plus-eigenspace
factor base creates no new odd-order twist contribution. It does not rule out factor bases of
general extension-field points or every possible use of auxiliary twist computations.</p>
<h3>Counterexample to “all nonzero mixed contributions are impossible”</h3>
<pre>Over F5: E:y²=x³+1,  Eᵈ:2y²=x³+1.
A=(0,1),  B=(4,0),  A+B=(2,2).
B is a nonzero 2-torsion point belonging to both eigenspaces.</pre>
<h3>Counterexample to an unqualified full direct-product claim</h3>
<pre>Over F5: E:y²=x³+x,  d=2.
|E(F5)|=4,   |Eᵈ(F5)|=8,   |E(F25)|=32.
E(F25)[2] has 4 points, but (E(F5) × Eᵈ(F5))[2] has 16 points.</pre>
<p>Thus the full groups need not be abstractly isomorphic. Their odd-primary components do split:
for an odd-order R, use (R+πR)/2 and (R−πR)/2. The associated algebraic varieties are isogenous;
the obstruction at 2 must be retained.</p>

<h2>3. Summation polynomials and transported factor bases</h2>
<p>The geometric relation condition for any m is invariant because φ fixes every x-coordinate:
there exist lifts with P₁+⋯+Pₘ=O on E if and only if such lifts exist on Eᵈ over the algebraic closure.
For S3, there is also a direct polynomial proof. Put s₁=x₁+x₂+x₃,
s₂=x₁x₂+x₁x₃+x₂x₃, and s₃=x₁x₂x₃. Then</p>
<pre>S3 = (s₂−a)² − 4 s₁(s₃+b).
   = (x₁−x₂)²x₃² − 2[(x₁+x₂)(x₁x₂+a)+2b]x₃
     + (x₁x₂−a)² − 4b(x₁+x₂).</pre>
<div class="proof"><p><strong>Proof that d cancels.</strong> Intersect the line y=m x+n with
d y²=x³+a x+b. Vieta gives s₁=d m², s₂=a−2d mn, s₃=d n²−b. Therefore
(s₂−a)²−4s₁(s₃+b)=4d²m²n²−4d²m²n²=0. Conversely, over the algebraic closure
these identities recover a line, including horizontal lines, from a vanishing S3.
The displayed polynomial identity and its substitution are certified symbolically. S4 is built
as the resultant of two S3 polynomials and compared with actual four-point lifts.</p></div>
<p>The shared geometric equations do not remove the eigenspace restriction on rational lifts.</p>
<p>The defining geometric property and resultant construction are due to
<a href="https://eprint.iacr.org/2004/031">Semaev</a>.</p>
<h3>Controlled relation-collection experiment</h3>
<p>For four prime-field, prime-order curves, the program transports the original target and the
same x-restricted factor base through the splitting-field isomorphism, then enumerates every
ordered pair sum. The complete target histograms coincide, including multiplicities.</p>
TRANSPORT
<div class="proof"><p><strong>General proof.</strong> For any coefficient vector (c₁,…,cₘ),
Σ[cᵢ]Pᵢ=Q if and only if Σ[cᵢ]φ(Pᵢ)=φ(Q). The relation vectors and hence matrix ranks
are identical for a transported base. A different choice of base or polynomial representation
could have different computational costs; this experiment does not exclude that possibility.</p></div>

<h2>4. Trace-zero dimension and the descent trap</h2>
<p>For E/Fq and extension degree n, define Tn as the kernel of 1+π+⋯+πⁿ⁻¹ on E(Fqⁿ).</p>
<div class="proof"><p><strong>Dimension proof.</strong> Over the algebraic closure, the Weil
restriction becomes Eⁿ and trace becomes the addition map Eⁿ→E. Its kernel is isomorphic
to Eⁿ⁻¹ via (P₁,…,Pₙ₋₁)↦(P₁,…,Pₙ₋₁,−ΣPᵢ). Thus dim(Tn)=n−1.
In particular T2 is an elliptic curve, namely the quadratic twist.</p>
<p><strong>Order proof.</strong> On E(Fqⁿ), π−1 has kernel E(Fq) and image Tn.
For surjectivity onto Tn, solve (π−1)X=Y over the algebraic closure; this is possible
because π−1 is an isogeny. If Tr(Y)=O, then (πⁿ−1)X=Tr(Y)=O, so X∈E(Fqⁿ).
Consequently |Tn|=|E(Fqⁿ)|/|E(Fq)|.</p></div>
<p>The program enumerates these trace-zero kernels completely and verifies that they equal
the image of π−1:</p>
TRACE
<p>Known index-calculus estimates for suitable fixed-dimension abelian varieties have the form
q^(2−2/dim), under the relevant relation-generation assumptions. The generic prime-subgroup
comparison is approximately q^(dim/2) when the subgroup has size comparable to the whole variety.
Dimension 2 gives equal exponents, while dimension 4 gives 3/2 versus 2. The formula for
dimension at least 2 must not be extrapolated to dimension 1. These are theoretical comparisons;
this suite does not implement the higher-dimensional index-calculus algorithm or measure its scaling.
See <a href="https://arxiv.org/abs/1405.1059">Gorla–Massierer</a>.</p>

<h3>An explicit model that descends, with a subgroup that does not</h3>
<pre>K=F49=F7(u),  u²=3,  δ=1+u is a nonsquare in K.
E0:y²=x³+x+1 over F7.
Eδ:y²=x³+(4+2u)x+(3+6u) over K.
j(Eδ)=j(E0)=1 in F7.
|E0(F7)|=5,  |E0(K)|=55,  |Eδ(K)|=45.</pre>
<p>In F2401=K(v), v²=δ, the inverse twisting map is
ψ(X,Y)=(X/δ,Y/(δv)). It takes Eδ(K) exactly onto the relative minus eigenspace
in E0(F2401). All 45 image points and all 2,025 group-law comparisons were checked.</p>
<pre>An order-3 source point is (3,3+2u).
Its image is (2+5u,4u v), outside E0(K).</pre>
<p>Thus revealing the subfield model does not move this target into E0(F7) or even E0(F49).
A favorable GHS or other cover attack needs a computable map preserving the target subgroup,
a suitable field and genus, and cheaper relation collection on the target variety. The experiment
tests the subfield shortcut, not a complete GHS construction. The existence of a twist alone
proves none of those cost conditions. The relevant original framework is
<a href="https://www.kantmath.de/publications/papers/weil_descent.pdf">Gaudry–Hess–Smart</a>.</p>

<h2>5. Pairing reduction followed by actual finite-field index calculus</h2>
<p>Let N=q+1−t and Nᵈ=q+1+t. If an odd prime r divides both, subtraction and addition give</p>
<pre>r | t,     r | (q+1),     q ≡ −1 (mod r).</pre>
<div class="proof"><p><strong>Proof of the reduction.</strong> Since r is odd, −1≠1 modulo r,
so the embedding degree is exactly 2. Choose nonzero r-torsion P from the plus eigenspace and
S from the minus eigenspace. They are independent: an intersection point is 2-torsion.
The nondegenerate Weil pairing therefore gives g=eᵣ(P,S) of order r. If Q=[a]P,
then eᵣ(Q,S)=gᵃ, an equivalent finite-field DLP. Conversely, a determines Q directly.
This is the <a href="https://doi.org/10.1145/103418.103434">MOV reduction</a> in this special setting.</p></div>
<p>The implementation computes the Weil pairing with Miller's algorithm. It then solves the
finite-field DLP by collecting factor-base relations and reducing a matrix modulo r.
No exhaustive field-DLP lookup is used to obtain the answer. BSGS on the elliptic curve is
used only as a separate verification.</p>
PAIRINGS
<h3>Exact finite-field relation scheme</h3>
<p>For the toy examples K=Fp(u), u²=2. The factor base is Lᵢ=u+i for i=1,…,6.
Set h=(p²−1)/r and βᵢ=Lᵢʰ. Here h is divisible by p−1 and coprime to r,
so projection kills all nonzero base-field constants and is invertible on the order-r subgroup.</p>
<pre>Find z = gᵃ · ∏ Lᵢ^eᵢ = b (u+j),  b∈Fp*,  j in the factor base.
Then βⱼ = g^(a h) · ∏ βᵢ^eᵢ.
Unknowns: ℓᵢ=log_g βᵢ.
Relation: ℓⱼ − Σ eᵢℓᵢ = a h (mod r).</pre>
<p>Nonzero constant z gives the same relation without the ℓⱼ term. Gaussian elimination solves
the six unknown logs. To recover a target log, collect a similar relation containing the target
and divide its exponent by h modulo r. The actual six independent rows are saved in results.json.</p>
<pre>Displayed example over F43, u²=2:
E:y²=x³+x,       P=(31,18),       S=(39,3u),       Q=(13,24).
g=e₁₁(P,S)=2+25u.
e₁₁(Q,S)=11+19u=g⁷.
The relation collector and individual logarithm step recover a=7.</pre>
<p>Every possible secret a was tested for r=11,17,53, for a total of 81 complete reductions
and recoveries. All r² bilinearity pairs were checked in each example.</p>
<h3>A failed relation family, exhaustively diagnosed</h3>
<p>At p=67,r=17, using only candidates gᵃ Lᵢ^(±1)Lⱼ^(±1), with 1≤i,j≤6,
does not produce a full-rank system. All 2,448 candidates yield 272 smooth relations of rank 5
for 6 unknowns. This is a counterexample to assuming that many smooth relations guarantee
enough independent equations. Allowing broader products produces rank 6 and completes the DLP.
The failure concerns this specified finite relation family, not finite-field index calculus generally.</p>
<h3>Shared r does not always force trace zero</h3>
<p>Over F5, E:y²=x³+x+1 has order 9 and its d=2 twist has order 3. Their shared r=3
has embedding degree 2, while t=−3. This is an ordinary curve. If instead r&gt;2√q,
Hasse's bound and r|t force t=0. The size condition matters.</p>

<h2>6. Weak-twist implications: explicit counterexamples</h2>
<pre>Over F1009: E:y²=x³+x+206,   d=11.
|E(F1009)|=1019 (prime).
|Eᵈ(F1009)|=1001=7·11·13.
P=(0,288), Q=(521,596)=[617]P.</pre>
<div class="proof"><p><strong>Proof of the transfer obstruction.</strong> For any group homomorphism
f from the order-1019 subgroup into the order-1001 twist group, f(P) is killed by 1019 and by 1001.
Because these integers are coprime, f(P)=O. Every such homomorphism is zero.
Also, multiplication by 1001 kills all embedded twist-rational points while remaining nonzero
on this prime-order curve subgroup. Both facts were checked explicitly.</p></div>
<p>This disproves the implications “smooth twist ⇒ smooth original group” and “the twist's
rational group automatically offers a nontrivial homomorphic transfer.” It does not prove that
the original DLP is hard: the example is deliberately small, and BSGS recovers 617.</p>
<pre>An anomalous twist example over F11:
E:y²=x³+x+6 has order 13.
Its quadratic twist has order 11 and is anomalous.
The original curve is not anomalous.</pre>
<p>Again the point orders are coprime, so a nontrivial rational homomorphic transfer cannot exist.</p>

<h2>Limits and remaining research questions</h2>
<ul>
<li>No general ECDLP hardness theorem follows from these calculations.</li>
<li>No comparison of small timings can establish an asymptotic advantage. Recorded times are
reproducibility metadata, not a security estimate.</li>
<li>A different factor base, endomorphism, auxiliary cover, or use of extension-field points may
behave differently. The proofs rule out only the stated direct constructions.</li>
<li>The computational suite concerns quadratic twists and characteristic greater than 3.
Quartic and sextic pairing twists, and characteristic-2 twist equations, require separate experiments.</li>
<li>Higher-dimensional trace-zero kernels were enumerated, but their index-calculus scaling
and general GHS cover construction were not implemented. Those claims retain their published
hypotheses; no experimental speedup is claimed here.</li>
</ul>

<h2>Reproduce and inspect</h2>
<pre>cd experiments/quadratic_twists
python -m pip install -r requirements.txt
python reproduce.py
python verify_evidence.py</pre>
<p>The experiment script does not need Sage or network access. The default suite uses fixed seeds
and prints each completed stage. It raises an assertion on a failed identity or recovery.
Exact results are deterministic; elapsed times vary.</p>
<p><a href="experiments.py">Experiment source</a> · <a href="results/results.json">Raw results and relation matrices</a> ·
<a href="results/relation_collection.csv">Relation-collection CSV</a> ·
<a href="requirements.txt">Dependency</a></p>
<p><a href="results/run.log">Execution transcript</a> ·
<a href="results/run-metadata.json">Run provenance and hashes</a> ·
<a href="SHA256SUMS">Checksum manifest</a> ·
<a href="reproduce.py">Audited runner</a> ·
<a href="verify_evidence.py">Independent certificate verifier</a></p>
<p class="small">Experiment-source SHA-256: SOURCE_HASH<br>
Full run: RUN_TIME seconds. Symbolic engine: SymPy SYMPY_VERSION.</p>
</main></html>'''

for key,value in {
    'VERDICTS':verdicts,'PRIMES':prime_rows,'COVERAGE':coverage,
    'TRACE':trace_rows,'TRANSPORT':transport_rows,'PAIRINGS':pairing_rows,
    'SOURCE_HASH':r['source_sha256'],'RUN_TIME':f"{r['total_seconds']:.2f}",
    'SYMPY_VERSION':esc(r['symbolic']['sympy_version']),
}.items():
    report = report.replace(key,value)

destination = ROOT/'report.html'
destination.write_text(report)
print(destination)
