# Quadratic twists, ECDLP, and index calculus

Executable finite-field experiments, algebraic proofs, and explicit counterexamples
for the relationship between quadratic twists and index-calculus approaches.
All points are valid; invalid-curve attacks are excluded. The examples are toy
instances in characteristic greater than 3.

## Reproduce the execution

```sh
python -m pip install -r requirements.txt
python reproduce.py
python verify_evidence.py
```

The full suite takes about 30 seconds in the recorded Python 3.12 environment.
`reproduce.py` enables assertions, streams and saves stdout/stderr, verifies the
executed source hash, compares all deterministic outputs with the committed
reference, and regenerates the report. Only measured durations are excluded
from the comparison. Dependencies are pinned.

## Review the evidence

- [Complete execution transcript](results/run.log): UTC start/end times, executed
  command, completed stages, exit codes, and reference-comparison result.
- [Run provenance](results/run-metadata.json): Python/SymPy versions, source hashes,
  output hashes, timestamps, and summary counts.
- [Raw results](results/results.json): explicit points, group orders, finite-field
  pairing values, independent relation rows, and recovered logarithms.
- [SHA-256 manifest](SHA256SUMS): binds source files, transcript, results, and report.
- [Independent certificate verifier](verify_evidence.py): checks the manifest,
  exact determinants modulo the subgroup primes, relation equations, and field
  logarithms using a separate tuple representation of the quadratic field.
- [Full report](report.html): claims, proofs, counterexamples, limitations, and
  links to the relevant papers. Download/open the HTML file in a browser.

The GitHub Actions workflow reruns the same commands and uploads the transcript,
provenance, raw results, manifest, and report as an artifact.

## Recorded coverage

| Check | Cases |
| --- | ---: |
| Nonsingular short Weierstrass models over primes 5, 7, 11, 13, 17, 19 | 942 |
| Enumerated extension-field points | 260,064 |
| Twist group-law comparisons | 289,440 |
| Ordered S3 triples | 4,188,162 |
| Ordered S4 quadruples over primes 5 and 7 | 113,342 |
| Pairing bilinearity comparisons | 3,219 |
| Complete pairing-to-index-calculus DLP recoveries | 81 |

These count models, not distinct isomorphism classes. S3/S4 are checked against
actual point lifts rather than against another copy of the polynomial formula.

## What is established

1. The splitting-field twist isomorphism preserves addition, scalar multiplication,
   and geometric x-coordinate relations.
2. Twist-rational points map to the minus Frobenius eigenspace. A mixed relation
   `R=A+B` with rational `R,A` and a pure twist contribution `B` satisfies `2B=O`.
   Its odd-primary twist component vanishes; a nonzero 2-torsion exception is shown.
3. The quadratic trace-zero variety has dimension one. Degree-3 and degree-5
   trace-zero kernels are also enumerated and their orders checked independently.
4. Twisting to a subfield model does not automatically move a target subgroup
   into that model's rational-point group. An explicit F49/F2401 example is given.
5. A shared odd prime on a curve and its quadratic twist gives embedding degree
   two. Miller pairing and actual finite-field relation collection/linear algebra
   recover all logs for subgroup orders 11, 17, and 53.
6. A smooth twist need not imply a smooth original group order: one example has
   curve order 1019 and twist order `1001=7*11*13`. Every homomorphism between those
   rational groups is zero because their orders are coprime.
7. Many smooth relations need not have full rank: all 2,448 candidates in one
   restricted family give 272 smooth relations of rank 5 for 6 unknowns. A broader
   relation family reaches full rank.

The suite does **not** prove general ECDLP hardness or exclude every possible
twist-assisted method. General GHS cover construction and higher-dimensional
index-calculus scaling are discussed as theory, not claimed as implemented attacks
or measured speedups.

To intentionally update the reference after changing the experiment source:

```sh
python reproduce.py --accept-results
python verify_evidence.py
```
