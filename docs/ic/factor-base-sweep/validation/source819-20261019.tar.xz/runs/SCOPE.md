# PR #2134 source review scope, 2026-10-19

This directory records software validation of source 819d6b172c8a58983bf1b2463fe24576f3f58094. It is not a new factor-base research campaign or performance comparison. No historical sealed attempt or protocol is edited.

The source merges f84e9a26b2a68da3046d7ae94bd8580d408049d4 and main 1e2bf0715a2a927afc92e6730d6e65b59f15ab9e. Copilot request6254099148 ended in explicit failure at2026-10-18T19:22:31Z. Another session subsequently published this merge; this session did not overwrite it or resolve conflicted files.

Review against main shows only the existing observer/progress instrumentation and its additive tests in f4_fp.rs. The main packed-set/replay test block and feature observer module are byte-exact. All196 protected prior evidence/documentation blobs,2572models,6143aliases,26store entries and both parents' entries are retained. CLI/plugin/integration-test/release/CLI-workflow blobs remain exact. Ten previously condition-checked skip workflow files are byte-exact to f84.

Requested validation:
- Full serial locked release-library tests on current native sources.
- Current CLI unit/integration/build/strict lint.
- Current all-target compilation and independent native audit tests/lint/build.
- Extract a separate copy of the sealed archive; verify all8546 members/64seals/1008point witnesses and compare frozen observations/coverage without rerunning F4.
- Pin all1632 native source/config/embedded inputs before compilation and check them afterward; bind actual unit binary and trait literal to this input set.
- Preserve actual failures and incomplete attempts, never translate launches into passes.
- Do not alter budgets, assertions, ignore lists, coverage, historical locks or evidence.

Conductor check returned127; pinned .conductor/WORKFLOW.md returned404. Neither passed. Only the existing managed workspace is used, no paid cloud launch.

CI snapshot at00:43UTC is deliberately partial:123 checks (62success24failure2cancelled11condition-justifiedskips22queued2neutral),50 workflow runs. Pending source-dependent CLI/Rust/release/normalCodeQL checks are not passes. All26 completed failed/cancelled job logs are in ci/. No retries were requested. GitHub CI is not polled in the foreground.
