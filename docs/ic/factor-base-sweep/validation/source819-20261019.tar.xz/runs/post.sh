#!/bin/bash
set -uo pipefail
cd /workspace/crypto-pr2134-head819-review
export CARGO_HOME=/workspace/pr1963-toolchain/cargo RUSTUP_HOME=/workspace/pr1963-toolchain/rustup CARGO_TARGET_DIR=/workspace/crypto-pr1963/target CARGO_BUILD_JOBS=2 RAYON_NUM_THREADS=2
export PATH="$CARGO_HOME/bin:$PATH"
records=/workspace/pr2134-review-819-20261019
run() { name="$1"; shift; printf '%q ' "$@" > "$records/$name.command"; printf '\n' >> "$records/$name.command"; "$@" > "$records/$name.log" 2>&1; result=$?; printf '%s\n' "$result" > "$records/$name.exit"; printf '%s exit=%s\n' "$name" "$result"; return "$result"; }
run all-targets cargo check --locked --all-targets || exit "$?"
run audit-unit cargo test --locked --release --manifest-path research/factor_base_shape_leads_20261018/analysis/Cargo.toml || exit "$?"
run audit-clippy cargo clippy --locked --all-targets --manifest-path research/factor_base_shape_leads_20261018/analysis/Cargo.toml -- -D warnings || exit "$?"
run audit-build cargo build --locked --release --manifest-path research/factor_base_shape_leads_20261018/analysis/Cargo.toml || exit "$?"
export RUNNER_TEMP="$records/replay" GITHUB_WORKSPACE="$PWD"
mkdir -p "$RUNNER_TEMP"
run sealed-replay bash "$records/sealed-replay.sh" || exit "$?"
run inputs-final node "$records/capture.mjs" "$records/inputs-final.json" || exit "$?"
cmp "$records/inputs-before.json" "$records/inputs-final.json" || exit "$?"
printf '0\n' > "$records/post.exit"
