# Setup observations retained

- Initial read-only git diff commands ran without the explicit network grant. Lazy blob fetching failed with "Failed to connect to proxy port 8080 ... Could not connect to server". The task's still-running read-only process was terminated, and the exact Git comparisons were rerun successfully with the existing granted-network context. No source or evidence bytes were changed. The completed comparisons are f4-vs-main.diff and f4-vs-feature.diff; the restricted attempt was not a successful comparison.
- The initial rustc metadata probe omitted the task RUSTUP_HOME selector and failed against the read-only default home. Its separate diagnostic and corrected toolchain metadata are retained in build-context/. The actual validation pipeline used the correct selectors from its first command.
- Conductor check returned127; fetching the pinned workflow returned404. Neither is a pass.
- Two attempts to read direct /actions/jobs/ID metadata through the connector returned an unsupported-endpoint400. The supported /actions/runs/ID/jobs collection was then used. No CI retry or workflow change was made.
- No new source generation, frozen fixture regeneration, historical Python crypto execution, live S3 operation or cloud-host launch occurred.
