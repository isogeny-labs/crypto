#!/bin/bash
set -uo pipefail
cd /workspace/crypto-pr2134-head819-review
export CARGO_HOME=/workspace/pr1963-toolchain/cargo RUSTUP_HOME=/workspace/pr1963-toolchain/rustup CARGO_TARGET_DIR=/workspace/crypto-pr1963/target CARGO_BUILD_JOBS=2 RAYON_NUM_THREADS=2
export PATH="$CARGO_HOME/bin:$PATH"
records=/workspace/pr2134-review-819-20261019
run() { name="$1"; shift; printf '%q ' "$@" > "$records/$name.command"; printf '\n' >> "$records/$name.command"; "$@" > "$records/$name.log" 2>&1; result=$?; printf '%s\n' "$result" > "$records/$name.exit"; printf '%s exit=%s\n' "$name" "$result"; return "$result"; }
run inputs-before node "$records/capture.mjs" "$records/inputs-before.json" || exit "$?"
run library cargo test --locked --release --lib -- --test-threads=1 || exit "$?"
run cli-unit cargo test --locked --release --bin factor-base-sweep || exit "$?"
run cli-integration cargo test --locked --release --test factor_base_sweep_cli -- --test-threads=1 || exit "$?"
run cli-build cargo build --locked --release --bin factor-base-sweep || exit "$?"
run cli-clippy cargo clippy --locked --release --bin factor-base-sweep -- -D warnings || exit "$?"
run inputs-after node "$records/capture.mjs" "$records/inputs-after.json" || exit "$?"
cmp "$records/inputs-before.json" "$records/inputs-after.json" || exit "$?"
printf '0\n' > "$records/pipeline.exit"
