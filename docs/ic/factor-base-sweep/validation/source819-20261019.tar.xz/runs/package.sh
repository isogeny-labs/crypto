#!/bin/bash
set -euo pipefail
records=/workspace/pr2134-review-819-20261019
python3 - <<'PY'
import json,hashlib,shutil
from pathlib import Path
r=Path('/workspace/pr2134-review-819-20261019')
expected=['pipeline','post','inputs-before','library','cli-unit','cli-integration','cli-build','cli-clippy','inputs-after','all-targets','audit-unit','audit-clippy','audit-build','sealed-replay','inputs-final','scope']
exits={k:int((r/(k+'.exit')).read_text()) for k in expected}
assert all(v==0 for v in exits.values()),exits
assert (r/'library-binding.json').is_file()
stage=r.parent/'pr2134-review-819-export-20261019'
assert not stage.exists(),'do not overwrite a prior export'
runs=stage/'runs';runs.mkdir(parents=True)
for p in r.iterdir():
 if p.is_file():shutil.copy2(p,runs/p.name)
for d in ['ci','build-context']:shutil.copytree(r/d,runs/d)
for name in ['observations.json','coverage.json','guard-coverage.json']:
 shutil.copy2(r/'replay'/'factor-base-shape-evidence'/name,runs/('reproduced-'+name))
files=sorted(p for p in runs.rglob('*') if p.is_file())
lines=[hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(stage).as_posix() for p in files]
(stage/'MEMBERS.sha256').write_text('\n'.join(lines)+'\n')
print(json.dumps({'files':len(files),'expected_exits':exits}))
PY
stage=/workspace/pr2134-review-819-export-20261019
(cd "$stage" && sha256sum -c MEMBERS.sha256 > member-check.log)
tar --sort=name --mtime='2026-10-19 00:00:00Z' --owner=0 --group=0 --numeric-owner --mode='u+rwX,go+rX,go-w' --format=gnu -cf - -C "$stage" runs MEMBERS.sha256 | xz -6 -T1 > "$records/validated-runs.tar.xz"
mkdir "$stage/extracted"
tar -xJf "$records/validated-runs.tar.xz" -C "$stage/extracted"
(cd "$stage/extracted" && sha256sum -c MEMBERS.sha256 > ../extracted-member-check.log)
tar --sort=name --mtime='2026-10-19 00:00:00Z' --owner=0 --group=0 --numeric-owner --mode='u+rwX,go+rX,go-w' --format=gnu -cf - -C "$stage/extracted" runs MEMBERS.sha256 | xz -6 -T1 > "$stage/repacked.tar.xz"
cmp "$records/validated-runs.tar.xz" "$stage/repacked.tar.xz"
sha256sum "$records/validated-runs.tar.xz" > "$records/validated-runs.sha256"
printf '0\n' > "$records/package.exit"
