import {sourceFiles,embeddedInputs} from '/workspace/crypto-pr2134-head819-review/.github/scripts/ci-scope.mjs';
import {createHash} from 'node:crypto';import {readFileSync,writeFileSync} from 'node:fs';import {execFileSync} from 'node:child_process';
const cwd=process.cwd(),sources=sourceFiles(cwd),tracked=new Set(execFileSync('git',['ls-files','-z'],{encoding:'utf8',maxBuffer:32*1024*1024}).split('\0')),embedded=[...embeddedInputs(cwd,sources)];
const deps=execFileSync('git',['ls-files','tools/volcano-cli','isogeny_algos'],{encoding:'utf8'}).trim().split('\n').filter(p=>p.endsWith('.rs')||p.endsWith('Cargo.toml')||p.endsWith('Cargo.lock'));
const paths=[...new Set([...sources,...embedded.filter(p=>tracked.has(p)),'Cargo.toml','Cargo.lock',...deps])].sort();
const entries=paths.map(path=>{const b=readFileSync(path);return {path,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex')};});writeFileSync(process.argv[2],JSON.stringify({head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),untrackedLiteralMatches:embedded.filter(p=>!tracked.has(p)),entries},null,2)+'\n');console.log('captured '+entries.length+' native inputs');
