import json,subprocess
from pathlib import Path
parents=['f84e9a26b2a68da3046d7ae94bd8580d408049d4','1e2bf0715a2a927afc92e6730d6e65b59f15ab9e']
head='819d6b172c8a58983bf1b2463fe24576f3f58094'
def tree(ref):
 out={}
 for row in subprocess.check_output(['git','ls-tree','-r','-z',ref]).split(b'\0'):
  if row:
   info,path=row.split(b'\t',1);out[path.decode()]=info.split()[2].decode()
 return out
trees=[tree(r) for r in [*parents,head]]
scopes=['research/factor_base_shape_leads_20261018/','docs/ic/factor-base-sweep/','benchmarks/20261018-factor-base-shape-leads/','research/factor_base_traces_20261016/','research/factor_base_evaluation']
protected={p:h for p,h in trees[0].items() if any(p.startswith(s) for s in scopes)}
assert all(trees[2].get(p)==h for p,h in protected.items())
report={'head':head,'parents':parents,'protected_prior_payload_blobs_exact':len(protected)}
for path,kind,key in [('docs/curves/registry.json','curves','slug'),('src/cryptanalysis/curve_aliases.json','aliases',None),('store/index.json','entries',None)]:
 rows=[]
 for r in [*parents,head]:
  v=json.loads(subprocess.check_output(['git','show',f'{r}:{path}']))[kind]
  rows.append({x[key]:x for x in v} if key else v)
 for r,data in zip(parents,rows):
  assert set(data)<=set(rows[2]),(path,r)
  for k,v in data.items():
   newer=rows[2][k]
   if v!=newer:
    if kind!='curves':raise AssertionError((path,k))
    for f,value in v.items():
     assert (all(x in newer.get(f,[]) for x in value) if isinstance(value,list) else value==newer.get(f)),(path,k,f)
 report[path]={'entries':len(rows[2]),'both_parents_preserved':True,'exact_main':rows[2]==rows[1]}
cli=[p for p in trees[0] if p.startswith('src/bin/factor_base_sweep') or p in ['tests/factor_base_sweep_cli.rs','src/cryptanalysis/ic_framework/plugins.rs','.github/workflows/ecbench.yml','.github/workflows/release.yml']]
assert all(trees[2].get(p)==trees[0][p] for p in cli)
report['cli_plugin_tests_release_workflows_byte_exact']=len(cli)
main_f4=subprocess.check_output(['git','show',f'{parents[1]}:src/cryptanalysis/f4_fp.rs']).decode()
head_f4=subprocess.check_output(['git','show',f'{head}:src/cryptanalysis/f4_fp.rs']).decode()
# Exact upstream test block retained while original observer tests are additive.
main_block=main_f4[main_f4.index('/// `interreduce`, `autoreduce`'):]
head_block=head_f4[head_f4.index('/// `interreduce`, `autoreduce`'):]
assert main_block==head_block
report['upstream_f4_packed_tests_exact']=True
Path('/workspace/pr2134-review-819-20261019/preservation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
