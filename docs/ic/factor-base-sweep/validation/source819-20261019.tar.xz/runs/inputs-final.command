node /workspace/pr2134-review-819-20261019/capture.mjs /workspace/pr2134-review-819-20261019/inputs-final.json 
