cargo build --locked --release --manifest-path research/factor_base_shape_leads_20261018/analysis/Cargo.toml 
