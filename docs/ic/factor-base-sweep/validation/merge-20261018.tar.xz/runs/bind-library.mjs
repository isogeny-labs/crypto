// Source/dependency metadata only; no mathematical or benchmark computation.
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import path from 'node:path';
const records='/workspace/pr2134-merge-20261018/';
const root='/workspace/crypto-fb-sweeper/';
const binary='/workspace/crypto-pr1963/target/release/deps/crypto_lib-1e046689120d033d';
const before=JSON.parse(readFileSync(records+'inputs-before.json'));
const hashes=new Map(before.entries.map(v=>[v.path,v.sha256]));
const first=readFileSync(records+'library-dependencies.d','utf8').split('\n')[0];
const paths=[...new Set(first.slice(first.indexOf(': ')+2).trim().split(/\s+/).map(p=>path.posix.normalize(p.replace(root,''))))];
const entries=paths.map(p=>{const bytes=readFileSync(root+p);const sha256=createHash('sha256').update(bytes).digest('hex');if(hashes.get(p)!==sha256)throw Error('Compiled dependency differs from frozen source: '+p);return {path:p,sha256,bytes:bytes.length};});
const bytes=readFileSync(binary),fixture=readFileSync(root+'docs/curves/traits.json');
const offset=bytes.indexOf(fixture);
if(offset<0)throw Error('Exact trait fixture bytes not found in unit binary');
const result={source_tree:before.source_tree,binary,binary_sha256:createHash('sha256').update(bytes).digest('hex'),dependency_entries:entries.length,all_compiled_dependencies_match_frozen_inputs:true,traits_fixture_sha256:createHash('sha256').update(fixture).digest('hex'),traits_literal_offset:offset,note:'Build/input provenance only. The separate full-command test log and exit determine pass/fail.',entries};
writeFileSync(records+'library-binary-input-binding.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({...result,entries:undefined},null,2));
