#!/usr/bin/env bash
set -u
cd /workspace/crypto-fb-sweeper
export CARGO_HOME=/workspace/pr1963-toolchain/cargo
export RUSTUP_HOME=/workspace/pr1963-toolchain/rustup
export CARGO_TARGET_DIR=/workspace/crypto-pr1963/target
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_BUILD_JOBS=2 RAYON_NUM_THREADS=2 CARGO_INCREMENTAL=0
records=/workspace/pr2134-merge-20261018
run() {
  local label=$1
  shift
  printf '%q ' "$@" > "$records/$label.command"
  printf '\n' >> "$records/$label.command"
  "$@" > "$records/$label.log" 2>&1
  local code=$?
  printf '%s\n' "$code" > "$records/$label.exit"
  printf '%s exit=%s\n' "$label" "$code"
}
run library cargo test --locked --release --lib -- --test-threads=1
run cli-unit cargo test --locked --release --bin factor-base-sweep
run cli-integration cargo test --locked --release --test factor_base_sweep_cli -- --test-threads=1
run cli-build cargo build --locked --release --bin factor-base-sweep
run cli-clippy cargo clippy --locked --release --bin factor-base-sweep -- -D warnings
run all-targets cargo check --locked --all-targets
run audit-unit cargo test --locked --release --manifest-path research/factor_base_shape_leads_20261018/analysis/Cargo.toml
run audit-clippy cargo clippy --locked --all-targets --manifest-path research/factor_base_shape_leads_20261018/analysis/Cargo.toml -- -D warnings
run audit-build cargo build --locked --release --manifest-path research/factor_base_shape_leads_20261018/analysis/Cargo.toml
export RUNNER_TEMP="$records/replay"
export GITHUB_WORKSPACE=/workspace/crypto-fb-sweeper
run sealed-replay bash /workspace/fb-shape-leads-packaging-20261018/ci-replay-final.sh
run scope node --test .github/scripts/test-ci-scope.mjs
printf 'completed\n' > "$records/pipeline.done"
