from pathlib import Path
import yaml, subprocess, json

class Unique(yaml.SafeLoader):
    pass
def mapping(loader,node,deep=False):
    out={}
    for k,v in node.value:
        key=loader.construct_object(k,deep=deep)
        if key in out: raise ValueError(f'duplicate YAML key {key!r} at line {k.start_mark.line+1}')
        out[key]=loader.construct_object(v,deep=deep)
    return out
Unique.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,mapping)
paths=['.github/workflows/codeql.yml','.github/workflows/curve-covers.yml','.github/workflows/weak-curve-database.yml','.github/workflows/ecbench.yml','.github/workflows/release.yml']
for path in paths:
    data=yaml.load(Path(path).read_text(),Loader=Unique)
    assert isinstance(data,dict)
    print(path+': unique mapping keys and YAML parse pass')
for path in paths[-2:]:
    data=yaml.load(Path(path).read_text(),Loader=Unique)
    for job,body in data['jobs'].items():
        for i,step in enumerate(body.get('steps',[])):
            run=step.get('run')
            if run and ('factor-base' in run or 'factor_base' in run):
                p=subprocess.run(['bash','-n'],input=run,text=True,capture_output=True)
                assert p.returncode==0,(path,job,i,p.stderr)
                print(f'{path}:{job}:{i}: bash syntax pass (no GitHub expression evaluation)')
print('Syntax checks only; not CodeQL analysis or GitHub validation.')
