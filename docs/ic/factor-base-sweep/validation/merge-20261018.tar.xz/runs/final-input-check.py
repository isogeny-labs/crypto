import json,hashlib
from pathlib import Path

records=Path('/workspace/pr2134-merge-20261018')
root=Path('/workspace/crypto-fb-sweeper')
before=json.loads((records/'inputs-before.json').read_text())
for e in before['entries']:
    assert hashlib.sha256((root/e['path']).read_bytes()).hexdigest()==e['sha256'],e['path']
binary=Path('/workspace/crypto-pr1963/target/release/deps/crypto_lib-1e046689120d033d')
binding=json.loads((records/'library-binary-input-binding.json').read_text())
assert hashlib.sha256(binary.read_bytes()).hexdigest()==binding['binary_sha256']
result={'source_tree':before['source_tree'],'frozen_native_inputs_unchanged':len(before['entries']),'library_binary_unchanged':True,'checks':{}}
for p in sorted(records.glob('*.exit')):
    result['checks'][p.stem]=int(p.read_text().strip())
expected={'library','cli-unit','cli-integration','cli-build','cli-clippy','all-targets','audit-unit','audit-clippy','audit-build','sealed-replay','scope','input-recapture'}
assert expected.issubset(result['checks']),sorted(expected-set(result['checks']))
assert all(v==0 for v in result['checks'].values()),result['checks']
result['note']='Every individual recorded validation exit is checked; pipeline.done alone is not a pass.'
(records/'final-inputs-and-exits.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
