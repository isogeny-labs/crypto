cargo check --locked --all-targets 
