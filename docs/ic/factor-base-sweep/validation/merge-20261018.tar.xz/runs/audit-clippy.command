cargo clippy --locked --all-targets --manifest-path research/factor_base_shape_leads_20261018/analysis/Cargo.toml -- -D warnings 
