node --test .github/scripts/test-ci-scope.mjs 
