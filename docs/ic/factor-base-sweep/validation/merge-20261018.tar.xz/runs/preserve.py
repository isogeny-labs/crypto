import json, subprocess, hashlib
from pathlib import Path

parents=['381aa0b3a1fbae21e5d23edaeb3bb516005ca3a8','b7cafe04485eb97d873dffef698e7337cfb38cfe']
def blob(ref,path):
    return subprocess.check_output(['git','show',f'{ref}:{path}'])
def obj(ref,path):
    return json.loads(blob(ref,path))
def tree(ref):
    out={}
    for row in subprocess.check_output(['git','ls-tree','-r','-z',ref]).split(b'\0'):
        if not row: continue
        info,path=row.split(b'\t',1)
        out[path.decode()]=info.split()[2].decode()
    return out
current=subprocess.check_output(['git','write-tree']).decode().strip()
trees=[tree(x) for x in [*parents,current]]
scopes=['research/factor_base_shape_leads_20261018/','docs/ic/factor-base-sweep/','benchmarks/20261018-factor-base-shape-leads/','research/factor_base_traces_20261016/','research/factor_base_evaluation']
protected={p:h for p,h in trees[0].items() if any(p.startswith(prefix) for prefix in scopes)}
changed=[p for p,h in protected.items() if trees[2].get(p)!=h]
assert not changed,changed
report={'parents':parents,'merged_tree':current,'immutable_feature_and_historical_blobs':len(protected),'all_immutable_blobs_exact':True}
for path,kind,key in [('docs/curves/registry.json','curves','slug'),('src/cryptanalysis/curve_aliases.json','aliases',None),('store/index.json','entries',None)]:
    rows=[obj(ref,path)[kind] for ref in [*parents,current]]
    if key:
        rows=[{v[key]:v for v in r} for r in rows]
    merged=rows[2]
    details=[]
    for parent,items in zip(parents,rows):
        missing=sorted(set(items)-set(merged))
        differing=[k for k,v in items.items() if merged.get(k)!=v]
        assert not missing,(path,parent,missing)
        if kind!='curves': assert not differing,(path,parent,differing)
        details.append({'parent':parent,'entries':len(items),'missing':missing,'changed_shared':differing})
        if kind=='curves':
            for k in differing:
                # Upstream metadata additions are permitted; model identity is not.
                for field in ['icv1','model_json','order','trace','j']:
                    assert items[k].get(field)==merged[k].get(field),(k,field)
                for field,value in items[k].items():
                    newer=merged[k].get(field)
                    if isinstance(value,list):
                        assert isinstance(newer,list) and all(x in newer for x in value),(k,field)
                    else:
                        assert value==newer,(k,field)
    report[path]={'merged_entries':len(merged),'parents':details,'exact_main_payload':rows[1]==merged}
# All feature source files and observer/plugin additions remain byte-exact.
for p in trees[0]:
    if p.startswith('src/bin/factor_base_sweep') or p in ['src/cryptanalysis/f4_fp.rs','src/cryptanalysis/ic_framework/plugins.rs']:
        assert trees[0][p]==trees[2][p],p
report['native_cli_and_observer_plugin_blobs_exact']=True
Path('/workspace/pr2134-merge-20261018/preservation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
