// Restore exact committed file bytes for metadata audit; never generate evidence.
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {dirname} from 'node:path';
import {createHash} from 'node:crypto';
const root='/workspace/unified-fb-sweeper-validation-20261017/';
const audit=JSON.parse(readFileSync(root+'naming-baseline-provenance.json'));
const missing=JSON.parse(readFileSync(root+'missing-naming-pins.json')).missing;
const ancestors=new Set(['.']);
for(const path of audit.diagnostic_paths_and_checker_inputs){let d=dirname(path);while(d!=='.'){ancestors.add(d);d=dirname(d);}}
const selected=missing.filter(p=>ancestors.has(dirname(p)));
writeFileSync(root+'diagnostic-pins-selected.json',JSON.stringify(selected,null,2)+'\n');
const restored=[];
for(const path of selected){const bytes=execFileSync('git',['show',`HEAD:${path}`],{maxBuffer:128*1024*1024});mkdirSync(dirname(path),{recursive:true});writeFileSync(path,bytes,{flag:'wx'});restored.push({path,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}
writeFileSync(root+'diagnostic-pins-restored.json',JSON.stringify(restored,null,2)+'\n');
console.log(`restored ${restored.length} exact tracked pin files in diagnostic ancestor directories`);
