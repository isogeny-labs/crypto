// File/dependency metadata only; does not run research mathematics.
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import path from 'node:path';
const records='/workspace/unified-fb-sweeper-validation-20261017/';
const binary='/workspace/crypto-pr1963/target/release/deps/crypto_lib-1e046689120d033d';
const before=JSON.parse(readFileSync(records+'inputs-before-feature-validation.json'));
const hashes=new Map(before.entries.map(v=>[v.path,v.sha256]));
const first=readFileSync(binary+'.d','utf8').split('\n')[0];
const paths=[...new Set(first.slice(first.indexOf(': ')+2).trim().split(/\s+/).map(p=>path.posix.normalize(p.replace('/workspace/crypto-fb-sweeper/',''))))];
const entries=paths.map(path=>{const bytes=readFileSync(path);const sha256=createHash('sha256').update(bytes).digest('hex');if(hashes.get(path)!==sha256)throw Error('Library dependency differs from captured source: '+path);return {path,sha256,bytes:bytes.length};});
const bytes=readFileSync(binary),fixture=readFileSync('docs/curves/traits.json');
const offset=bytes.indexOf(fixture);
if(offset<0)throw Error('Exact trait fixture bytes not found in unit binary');
const result={binary,binary_sha256:createHash('sha256').update(bytes).digest('hex'),dependency_entries:entries.length,all_compiled_library_dependencies_match_captured_source:true,traits_fixture_sha256:createHash('sha256').update(fixture).digest('hex'),traits_literal_offset:offset,note:'Final CLI-only edits are not library inputs. The library command failed four unchanged upstream cases; this binding does not turn failures into passes.',entries};
writeFileSync(records+'library-binary-input-binding.json',JSON.stringify(result,null,2)+'\n');
console.log(`${entries.length} library dependencies unchanged; exact trait fixture embedded; binary SHA256 ${result.binary_sha256}`);
