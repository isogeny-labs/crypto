# Managed workspace interruption

At approximately 2026-10-17 23:40 UTC, command execution failed with an
exec-server transport disconnection. The managed environment status reported
`connectivity=offline`, `observed_phase=starting`, desired phase running. A
readiness wait returned ready before command execution actually recovered.
Access recovered by the observed 23:45:18 UTC command. Source commits and
workspace files survived, but no Cargo or rustc process survived.

`library-initial.log` records a completed 17m25s release build followed by only
a partial 4,501-test run; its last observed test was
`binary_small_x::tests::raw_base_fraction_on_toy_binary_curves`. There is no
observed final exit/result. It is not a full library pass. The initial
`feature-unit.log` records a blocked build then an interrupted regular-library
compile, also without a final exit/result. Both logs are retained.

An attempted command to pause the overlapping feature compiler failed while
creating its exec process. No coordination log was found after recovery; no
successful pause or resume is claimed. Subsequent library and feature commands
were launched sequentially instead.

`library-recovery.log` and `.exit` contain the complete unchanged-assertion
retry: 4,380 passed, four failed, 117 existing ignores; exit101. Three failures
parse the unchanged committed traits JSON without its required `levels` field.
The fourth gets `Boundary` rather than `FormulaMarginal` for c2pnb304w1 in the
unchanged Jacobian classification test. These are failures, not ignored gates.
The exact current trait file is embedded in the retained unit binary; the
successful normalized dependency audit records its hash and all 731 inputs.
The first dependency audit failed to normalize relative `../` paths, and its
failed log is retained separately from the successful retry.

The metadata naming check initially reports 4,042 problems. Diagnostic source,
checker, registry and alias inputs match pinned main. Sparse manifests were
then investigated: 1,340 of 3,422 global pin files were off cone, but zero were
in ancestor directories that could exempt the diagnostic files. No pins were
invented or evidence regenerated. This is a metadata provenance audit, not a
second execution of the check on a separate baseline worktree.

No cloud host was launched, no S3 operation occurred, and no chat credential or
conversation transcript was copied into these records.
