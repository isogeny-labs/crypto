// File metadata only; all curve construction, solving and tests are native.
import {sourceFiles, embeddedInputs} from '/workspace/crypto-fb-sweeper/.github/scripts/ci-scope.mjs';
import {createHash} from 'node:crypto';
import {readFileSync, writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
const cwd=process.cwd();
const sources=sourceFiles(cwd);
const tracked=new Set(execFileSync('git',['ls-files','-z'],{encoding:'utf8',maxBuffer:16*1024*1024}).split('\0'));
const embedded=[...embeddedInputs(cwd,sources)];
// The discovery regex also sees include_str! in generated-source literals.
// Never invent a missing historical file to satisfy such a literal.
const untrackedLiteralMatches=embedded.filter(path=>!tracked.has(path));
const dependencies=execFileSync('git',['ls-files','tools/volcano-cli','isogeny_algos'],{encoding:'utf8'}).trim().split('\n').filter(p=>p.endsWith('.rs')||p.endsWith('Cargo.toml')||p.endsWith('Cargo.lock'));
const paths=[...new Set([...sources,...embedded.filter(path=>tracked.has(path)),'Cargo.toml','Cargo.lock',...dependencies])].sort();
const entries=paths.map(path=>{const bytes=readFileSync(path);return {path,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};});
writeFileSync(process.argv[2],JSON.stringify({base:'c6d64436a33359320ad9d5b42c4acebee2968b9a',untrackedLiteralMatches,entries},null,2)+'\n');
console.log(`captured ${entries.length} native source/config/embedded inputs`);
