# Exact authoring and validation commands

Working source `/workspace/crypto-fb-sweeper`; initial base
`c6d64436a33359320ad9d5b42c4acebee2968b9a`. Pinned main
`50f56d6a2e5a3ce04d16a1d02f2dbc3faa0aa3d4` was merged normally; its only
additional working-tree change was the unrelated ECC2K status page. The
independent CI-scope duplicate fix matched the local one exactly. Final native
CLI source `b3ed888964100f1bce4780a4c0500a399c7aee50`.

Native build environment:

```sh
export CARGO_HOME=/workspace/pr1963-toolchain/cargo
export RUSTUP_HOME=/workspace/pr1963-toolchain/rustup
export CARGO_TARGET_DIR=/workspace/crypto-pr1963/target
export PATH=/workspace/pr1963-toolchain/cargo/bin:$PATH
export CARGO_BUILD_JOBS=2
```

Networking, including loopback, was enabled for native validation. No general
environment dump, credential, transcript, S3 operation or paid cloud launch was
part of this work. Conductor command exit127 and pinned workflow404 are not
passed checks.

Before final native validation, changed Rust files were formatted with Rust
1.98 and `rustfmt --edition 2021 --config skip_children=true`. Native sparse
inputs were restored with `node .github/scripts/ci-scope.mjs --materialize`;
the initial duplicate declaration prevented this before its minimal repair.
All initial build/sparse failures are retained. `capture-inputs.mjs` records
actual working bytes and excludes four nonexistent, untracked protocol names
found inside generated-source literals, without inventing historical files.

The initial complete release build was followed by an interrupted library run.
Its final outcome is unknown. Recovery retried:

```sh
RAYON_NUM_THREADS=2 cargo test --locked --release --lib -- --test-threads=1
```

See `library-recovery.log` and `.exit`: 4,380 passes, four failures, 117 existing
ignores, exit101. Direct unchanged-binary diagnostic:

```sh
/workspace/crypto-pr1963/target/release/deps/crypto_lib-1e046689120d033d \
  --exact cryptanalysis::curve_traits::query::tests::unknown_values_never_match --nocapture
```

`audit-library-inputs.mjs` checks actual `.d` dependencies against captured
working bytes, hashes the exact binary and finds the full current traits
literal inside it. The first path-normalization error and successful retry
are separate retained logs. The completed library inputs are unchanged by
the later CLI-only fixes.

Final touched checks:

```sh
SWEEP_VALIDATION_RECORDS=/workspace/unified-fb-sweeper-validation-20261017/final-acceptance \
  bash /workspace/unified-fb-sweeper-validation-20261017/validate-feature.sh
```

That thin shell driver records every exact argv and exit in
`final-acceptance/acceptance-commands.txt`, with `CARGO_INCREMENTAL=0` and
`RAYON_NUM_THREADS=2`. It passes CLI type/build checks, five CLI unit tests,
six executable integration tests, all-targets compilation, strict touched-bin
Clippy and four existing progress integration tests. It then records the
unchanged historical trace unit failure (two pass, two registration failures),
exits101, and does not claim the following command ran automatically.
The complete historical verification was therefore invoked separately:

```sh
/workspace/crypto-pr1963/target/release/factor_base_trace verify \
  /workspace/factor_base_evaluation/results/generic.json \
  /workspace/factor-base-trace-registered
```

It fails the unchanged registration guard. `historical-registration-blocker.json`
records all 48 missing registry rows with retained alias targets. It is a
metadata audit, not historical RNG generation or live S3 verification.

The new CLI's retained public functional run and independent replay:

```sh
/workspace/crypto-pr1963/target/release/factor-base-sweep run \
  --out /workspace/unified-fb-sweeper-validation-20261017/functional-both-run \
  --preset both --train 4 --holdout 2 --candidate-seconds 30 --heartbeat-seconds 0.1
/workspace/crypto-pr1963/target/release/factor-base-sweep verify \
  --run /workspace/unified-fb-sweeper-validation-20261017/functional-both-run
```

Both exit0. Sixteen configurations, fifteen completed and one inapplicable;
all sixteen sealed attempts and twenty-nine point witnesses verify. Native
worker thread count is one in the frozen plan. A Clippy process overlapped
this functional run; wall rates are operational telemetry, not performance
evidence. F4 is not rerun by verification.

Broader unchanged-source diagnostics, retained as failures:

```sh
cargo clippy --locked --all-targets -- -D warnings
bash scripts/clippy-maintained.sh
python3 scripts/check_curve_names.py --diff 50f56d6a2e5a3ce04d16a1d02f2dbc3faa0aa3d4
```

Both Clippy commands fail unchanged `volcano-ic-driver`; canonical maintained
Clippy additionally flags `examples/n83_precomputed_rho.rs`. Naming reports
4,042 problems. Diagnostic and applicable pin provenance is in the metadata
audit files. No check, coverage, budget, assertion or ignore was weakened.

Metadata/report operations: `extract-functional-observations.mjs` copies Rust
counts and independently checks the executable hash. Python only installs or
runs Typst/Matplotlib to render recorded values and reports, never curve math
or a research harness. `render-functional-plot.py`, `architecture.dot` and
`report.typ` are committed beside their outputs. The final four-page PDF was
rebuilt and every page visually inspected; the initial orphan-page version is
retained separately. See `VISUAL_REVIEW.md`.

All 1,629 captured native source/config/fixture inputs remain byte-identical
across final CLI checks. Frozen research/backlog/registry/alias/store trees
remain identical to pinned main; that does not restore its existing missing
historical model rows. The experiment card stays draft, unrun, zero-funded,
unleased and without protocol/checkpoint/runnable argv.
