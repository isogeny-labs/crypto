// Copy recorded native fields into a plotting document; no curve mathematics.
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const records='/workspace/unified-fb-sweeper-validation-20261017/';
const read=p=>JSON.parse(readFileSync(p,'utf8'));
const run=records+'functional-both-run/';
const manifest=read(run+'manifest.json'),summary=read(run+'summary-0001.json');
const binary='/workspace/crypto-pr1963/target/release/factor-base-sweep';
const actual=createHash('sha256').update(readFileSync(binary)).digest('hex');
if(actual!==manifest.binary_sha256)throw Error('Functional run executable changed');
const first=readFileSync(run+'events.jsonl','utf8').trim().split('\n').map(JSON.parse).find(v=>v.event==='start');
const candidates=[],panel_titles={};
for(const item of summary.candidates){
  const req=read(item.attempt+'/request.json');
  const panel=req.candidate.curve.kind.startsWith('prime')?'prime':'binary';
  const row={id:item.id,label:item.label,panel,outcome:item.outcome,raw_attempt:item.attempt.replace(records,'')};
  if(item.outcome==='completed'){
    const base=read(item.attempt+'/base.json');
    panel_titles[panel]=base.curve.slug;
    row.curve_slug=base.curve.slug;row.columns=base.factor_base.columns;
    row.train_verified=item.measurement.phase_summary.train.verified;
    row.holdout_verified=item.measurement.phase_summary.holdout.verified;
  }
  candidates.push(row);
}
const data={schema:'factor_base_sweep.functional_plot/v1',run_id:'functional-'+new Date(first.unix_ms).toISOString().replace(/[-:]/g,'').slice(0,13)+'Z',source_commit:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),binary_sha256:actual,raw_records:'validation/runs.tar.xz: functional-both-run/',train_requested:manifest.plan.train,holdout_requested:manifest.plan.holdout,seed:manifest.plan.seed,panel_titles,candidates,verification:read(records+'functional-verify.stdout.json'),scope:'Native functional fixtures, not an accepted speed comparison. Counts copied without recomputing cryptographic results.'};
writeFileSync('docs/ic/factor-base-sweep/functional-fixture-observations.json',JSON.stringify(data,null,2)+'\n');
console.log(`${candidates.length} native candidate outcomes copied for plotting; executable hash matches run manifest`);
