# Visual review

The four-page final Typst PDF was rebuilt and all four rendered pages were
opened and read. Text, validation counts, both registered curve IDs, point-count
axes, failed/inapplicable distinctions, diagram labels, source links and scope
qualifiers are legible. No clipped labels or orphan page remains.

The first five-page PDF left two raw-record reference lines on an otherwise
empty page. That non-final PDF and its five previews remain preserved as
`report-initial-orphan.pdf` and `report-page-*.png`; the source was tightened
and the final four-page PDF was rendered to `report-final-page-*.png` and
inspected separately. The functional graph's inapplicable row was also given
explicit axis space so its label does not cross the bottom axis.

The SVG/DOT architecture is explanatory. The quantitative figure only renders
counts copied from the native functional run; no new cryptographic calculation,
uncertainty estimate, accepted timing comparison or shape ranking is performed
by Python. Native run and verification results remain the source of truth.
