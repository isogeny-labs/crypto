# Packaging record

The first manifest command created a relative output directory in the raw
record directory, then attempted to write the manifest to the repository's
absolute documentation directory, which did not yet exist. It failed with
`No such file or directory` and a downstream sort broken pipe; no manifest or
archive was published from that attempt. Only empty accidental directories
were removed. The corrected command creates the absolute output directory,
hashes every raw file into its detached SHA256SUMS, then seals a deterministic
tar/xz archive. Subsequent extraction/hash/repack receipts sit outside this
raw snapshot so sealing does not change its own members.
