// Metadata provenance for the unmodified upstream naming diagnostics.
import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
const base='50f56d6a2e5a3ce04d16a1d02f2dbc3faa0aa3d4';
const text=readFileSync('/workspace/unified-fb-sweeper-validation-20261017/naming.log','utf8');
const paths=new Set(['scripts/check_curve_names.py','scripts/curve_id.py','docs/curves/registry.json','src/cryptanalysis/curve_aliases.json']);
for(const line of text.split('\n')) {const m=line.match(/^([^:]+):\d+:/);if(m)paths.add(m[1]);}
const changed=execFileSync('git',['diff','--name-only',base,'HEAD','--',...[...paths].sort()],{encoding:'utf8'}).trim();
if(changed)throw new Error('A naming diagnostic input changed: '+changed);
const result={base,feature:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),observed_result:'4042 problems, including missing registered slugs and alias-map mismatch',diagnostic_paths_and_checker_inputs:[...paths].sort(),all_listed_paths_unchanged_from_base:true,frozen_research_registry_and_alias_trees_unchanged:true,note:'Metadata comparison, not a second baseline execution. No naming error was fixed by rewriting historical evidence.'};
writeFileSync('/workspace/unified-fb-sweeper-validation-20261017/naming-baseline-provenance.json',JSON.stringify(result,null,2)+'\n');
console.log(`${paths.size} diagnostic/checker inputs match upstream main; no diagnostic file changed in this feature`);
