#!/usr/bin/env bash
# Thin native build/test driver. No research mathematics runs in this script.
set -eu
cd /workspace/crypto-fb-sweeper
export CARGO_HOME=/workspace/pr1963-toolchain/cargo
export RUSTUP_HOME=/workspace/pr1963-toolchain/rustup
export CARGO_TARGET_DIR=/workspace/crypto-pr1963/target
export PATH=/workspace/pr1963-toolchain/cargo/bin:$PATH
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 RAYON_NUM_THREADS=2
records=${SWEEP_VALIDATION_RECORDS:-/workspace/unified-fb-sweeper-validation-20261017}
mkdir -p "$records"
run() {
  local label=$1
  shift
  printf '%q ' "$@" >> "$records/acceptance-commands.txt"
  printf '\n' >> "$records/acceptance-commands.txt"
  set +e
  "$@" > "$records/$label.log" 2>&1
  local result=$?
  set -e
  printf '%s\n' "$result" > "$records/$label.exit"
  return "$result"
}
run feature-types cargo check --locked --bin factor-base-sweep --test factor_base_sweep_cli
run feature-unit cargo test --locked --release --bin factor-base-sweep
run production-build cargo build --locked --release --bin factor-base-sweep
run cli-integration cargo test --locked --release --test factor_base_sweep_cli -- --test-threads=1
run all-targets cargo check --locked --all-targets
run clippy cargo clippy --locked --release --bin factor-base-sweep --bin ecbench --bin ic -- -D warnings
run existing-progress cargo test --locked --release --test ic_progress -- --test-threads=1
run trace-build cargo build --locked --release --bin factor_base_trace
run trace-tests cargo test --locked --release --bin factor_base_trace
run historical-trace-verify /workspace/crypto-pr1963/target/release/factor_base_trace verify /workspace/factor_base_evaluation/results/generic.json /workspace/factor-base-trace-registered
printf '0\n' > "$records/acceptance.exit"
