# CI repair validation, 2026-10-18 ~11:04 UTC

Head inspected: 94e80844c600c503b51718b5066c33c51af6aef9. All 131 current-head checks and 50 workflow runs were inspected once, including the second check page. All 34 failed/cancelled job logs and the relevant successful release/review logs are retained. No CI rerun was requested or foreground-polled.

The only workflow edit adds `with: { components: clippy }` to the existing dtolnay/rust-toolchain@1.98 install in the factor-base-sweep job. Parsed workflow comparison proves every other property, command, coverage selection and the 25-minute limit unchanged. YAML unique-key and relevant Bash syntax checks pass; these are not GitHub Actions or security analysis.

Local controlled reproduction used a real newly installed minimal Rust 1.98.1 toolchain, not a mocked toolchain. Explicit environment:

```
CARGO_HOME=/workspace/pr1963-toolchain/cargo
RUSTUP_HOME=/workspace/pr2134-check-20261018T1104/rustup-minimal
PATH=$CARGO_HOME/bin:$PATH
CARGO_TARGET_DIR=/workspace/pr2134-check-20261018T1104/audit-target
CARGO_BUILD_JOBS=2
```

Commands, in order:

```
rustup toolchain install 1.98.1 --profile minimal
cargo clippy --locked --all-targets --manifest-path research/factor_base_shape_leads_20261018/analysis/Cargo.toml -- -D warnings
rustup component add clippy --toolchain 1.98.1
cargo clippy --locked --all-targets --manifest-path research/factor_base_shape_leads_20261018/analysis/Cargo.toml -- -D warnings
cargo test --locked --release --manifest-path research/factor_base_shape_leads_20261018/analysis/Cargo.toml
cargo build --locked --release --manifest-path research/factor_base_shape_leads_20261018/analysis/Cargo.toml
"$CARGO_TARGET_DIR/release/factor-base-lead-audit" --coverage /workspace/pr2134-merge-20261018/replay/factor-base-shape-evidence/runs docs/curves/registry.json primary secondary confirmation representation > /workspace/pr2134-check-20261018T1104/reproduction/coverage.json
cmp research/factor_base_shape_leads_20261018/exact-coverage.json /workspace/pr2134-check-20261018T1104/reproduction/coverage.json
```

The first lint command failed as expected with cargo-clippy missing. The component install and same strict lint then passed; all eight audit tests passed and coverage matched the frozen output. The auditor executable was under the explicit CARGO_TARGET_DIR above, not the checkout's default target directory. The SDK/target build trees are not included in this small evidence archive.

Nine unchanged CI-scope tests passed with the existing granted-network execution context. The first restricted `node --test .github/scripts/test-ci-scope.mjs` invocation returned a test-process failure without further diagnostics; its log is retained separately. No test or assertion changed on retry.

The pinned-base manifest control uses b7cafe04485eb97d873dffef698e7337cfb38cfe's exact Cargo.toml with a copy of the previously recorded historical compact lockfile in a separate control directory. `cargo metadata --locked --offline --format-version 1 --manifest-path baseline-lock-control/Cargo.toml` returned101. No original lockfile was edited. Parsed manifest comparison shows the feature only adds the CLI bin entry, with no dependency-graph changes. base-equivalence.json binds unaffected blocker source/catalog/card blobs to pinned main.

All 1629 native source/config/fixture inputs and the previous test binary remain unchanged. The prior single-command 4384-pass full library result applies to those same native inputs; no fresh full-library run is claimed for this workflow-only edit. No historical research/evidence, registry/alias/store container, assertion, budget or ignore annotation was changed. Both cards stay draft/unrun; no new campaign, S3 operation or paid host.

Conductor check returned127 and pinned .conductor/WORKFLOW.md404 before edits; neither passed. Report-evidence rules remain in force. The neutral CodeQL aggregate is a check, not a workflow job; a job-log probe for its ID returned404, and its actual check summary is retained separately. The Rust scan remains blocked by the cancelled25-minute cache-warm job; no successful Rust scan or manual substitute is claimed.
