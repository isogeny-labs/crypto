#!/usr/bin/env python3
"""Check archive bytes and paths only; never execute archived programs."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

p = argparse.ArgumentParser()
p.add_argument('archive', type=Path)
p.add_argument('output', type=Path)
p.add_argument('--keep', type=Path)
a = p.parse_args()
actual = {}
manifest = None
unsafe = []
duplicates = []
members = 0
expanded = 0
kept = []
with tarfile.open(a.archive, 'r|xz') as archive:
    for member in archive:
        members += 1
        name = member.name.removeprefix('./')
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or not (member.isdir() or member.isfile()):
            unsafe.append(name)
            continue
        if not member.isfile():
            continue
        if name in actual:
            duplicates.append(name)
        source = archive.extractfile(member)
        digest = hashlib.sha256()
        retain = name in {'MANIFEST.sha256', 'README.txt', 'DELIVERY_NOTE.md',
                           'summary/summary.json', 'campaign/campaign.json'}
        data = bytearray() if retain else None
        while block := source.read(1048576):
            digest.update(block)
            expanded += len(block)
            if data is not None:
                data.extend(block)
        actual[name] = digest.hexdigest()
        if name == 'MANIFEST.sha256':
            manifest = bytes(data).decode('utf-8')
        elif retain and a.keep:
            destination = a.keep / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
            kept.append(name)
if manifest is None:
    raise SystemExit('Missing MANIFEST.sha256')
expected = {}
for line in manifest.splitlines():
    digest, name = line.split(maxsplit=1)
    name = name.removeprefix('*').removeprefix('./')
    if name in expected:
        duplicates.append('manifest:' + name)
    expected[name] = digest
missing = sorted(set(expected) - set(actual))
mismatches = sorted(name for name in expected.keys() & actual.keys() if expected[name] != actual[name])
extras = sorted(set(actual) - set(expected) - {'MANIFEST.sha256'})
outer = hashlib.sha256()
with a.archive.open('rb') as source:
    while block := source.read(1048576):
        outer.update(block)
receipt = {'archive': a.archive.name, 'archive_bytes': a.archive.stat().st_size,
           'archive_sha256': outer.hexdigest(), 'tar_members': members,
           'regular_files': len(actual), 'expanded_regular_bytes': expanded,
           'manifest_entries': len(expected), 'checked': len(expected) - len(missing),
           'manifest_sha256': hashlib.sha256(manifest.encode()).hexdigest(),
           'missing': missing, 'mismatches': mismatches, 'extra_files': extras,
           'unsafe_members': unsafe, 'duplicates': duplicates, 'kept_inert_files': kept,
           'verification': 'byte-manifest integrity only; no code execution, solver or mathematical replay'}
a.output.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
if missing or mismatches or extras or unsafe or duplicates:
    raise SystemExit(1)
