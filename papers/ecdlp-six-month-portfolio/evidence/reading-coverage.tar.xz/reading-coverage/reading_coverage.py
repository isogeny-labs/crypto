#!/usr/bin/env python3
"""Record source-reading coverage, without mistaking indexing for reading.

This is documentation tooling. It performs no cryptographic experiment.
An emitted batch is not read until an explicit acknowledgement is recorded.
"""
import argparse
import collections
import csv
import datetime
import hashlib
import json
from pathlib import Path
import sqlite3

BASE = Path('/workspace/ecdlp-audit')
EVIDENCE = BASE / 'evidence'
ROOT = EVIDENCE / 'reading-coverage'
ROOT.mkdir(exist_ok=True)
DB = ROOT / 'coverage.sqlite'

def connect():
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    db.executescript('''
      CREATE TABLE IF NOT EXISTS files (
        repo TEXT, revision TEXT, path TEXT, object TEXT, kind TEXT,
        extension TEXT, materialized INTEGER, bytes INTEGER,
        machine_index TEXT, PRIMARY KEY(repo,path));
      CREATE TABLE IF NOT EXISTS reads (
        id INTEGER PRIMARY KEY, repo TEXT, path TEXT, revision TEXT,
        object TEXT, sha256 TEXT, start_line INTEGER, end_line INTEGER,
        total_lines INTEGER, bytes INTEGER, status TEXT, note TEXT,
        recorded_at TEXT);
    ''')
    return db

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def inventory(db):
    docs = {(r['repo'], r['path']) for r in csv.DictReader(open(EVIDENCE/'document_catalogue.csv'))}
    ledgers = {('crypto-autoresearcher', r['path']) for r in csv.DictReader(open(EVIDENCE/'ledger_catalogue.csv'))}
    rows = []
    for r in csv.DictReader(open(EVIDENCE/'tracked_files.csv')):
        p = BASE/'repos'/r['repo']/r['path']
        materialized = p.is_file() and not p.is_symlink()
        key = (r['repo'], r['path'])
        indexed = 'document_heading_index' if key in docs else ('ledger_fields_parsed' if key in ledgers else 'tree_metadata_only')
        rows.append((r['repo'],r['commit'],r['path'],r['git_object'],r['kind'],r['extension'],int(materialized),p.stat().st_size if materialized else None,indexed))
    db.executemany('INSERT OR REPLACE INTO files VALUES (?,?,?,?,?,?,?,?,?)',rows)
    db.commit()
    print(json.dumps({'inventory_rows':len(rows),'materialized':sum(r[6] for r in rows),'machine_index_counts':dict(collections.Counter(r[8] for r in rows))}))

def emit(db,args):
    r = db.execute('SELECT * FROM files WHERE repo=? AND path=?',(args.repo,args.path)).fetchone()
    if not r:
        raise SystemExit('Path is outside the pinned-tree inventory.')
    p = BASE/'repos'/args.repo/args.path
    raw = p.read_bytes()
    obj = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    if obj != r['object']:
        raise SystemExit('Local bytes do not match the pinned Git object; do not record a source read.')
    lines = raw.decode('utf-8').splitlines(keepends=True)
    start,end = args.start,args.end or len(lines)
    if not (1 <= start <= end <= len(lines)):
        raise SystemExit('Invalid line range.')
    body = ''.join(lines[start-1:end])
    if len(body.encode()) > args.max_bytes:
        raise SystemExit(f'Range is {len(body.encode())} bytes; split into smaller line ranges. Nothing recorded.')
    sha=hashlib.sha256(raw).hexdigest()
    rid=db.execute('INSERT INTO reads (repo,path,revision,object,sha256,start_line,end_line,total_lines,bytes,status,note,recorded_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
        (args.repo,args.path,r['revision'],obj,sha,start,end,len(lines),len(raw),'emitted_unacknowledged','',now())).lastrowid
    db.commit()
    print(json.dumps({'read_id':rid,'repo':args.repo,'path':args.path,'revision':r['revision'],'sha256':sha,'lines':[start,end],'total_lines':len(lines),'bytes':len(raw)}))
    print('BEGIN SOURCE TEXT')
    print(body,end='' if body.endswith('\n') else '\n')
    print(f'END SOURCE TEXT read_id={rid}')

def ack(db,args):
    for rid in args.ids:
        r=db.execute('SELECT * FROM reads WHERE id=?',(rid,)).fetchone()
        if not r or r['status']!='emitted_unacknowledged':
            raise SystemExit(f'Read {rid} is not awaiting acknowledgement.')
        db.execute('UPDATE reads SET status=?,note=?,recorded_at=? WHERE id=?',('model_read',args.note,now(),rid))
    db.commit()
    print(json.dumps({'acknowledged':args.ids,'note':args.note}))

def record_previous(db,args):
    r=db.execute('SELECT * FROM files WHERE repo=? AND path=?',(args.repo,args.path)).fetchone()
    p=BASE/'repos'/args.repo/args.path
    raw=p.read_bytes(); n=len(raw.decode().splitlines())
    obj=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    if not r or obj!=r['object']:
        raise SystemExit('Pinned object mismatch.')
    db.execute('INSERT INTO reads (repo,path,revision,object,sha256,start_line,end_line,total_lines,bytes,status,note,recorded_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
        (args.repo,args.path,r['revision'],obj,hashlib.sha256(raw).hexdigest(),1,n,n,len(raw),args.status,args.note,now()))
    db.commit(); print(json.dumps({'recorded':args.repo+':'+args.path,'status':args.status}))

def export(db):
    reads=[dict(r) for r in db.execute('SELECT * FROM reads ORDER BY id')]
    by_object=collections.defaultdict(list)
    for r in reads:
        if r['status']=='model_read': by_object[r['object']].append(r)
    complete=set(); partial=set()
    for obj,rs in by_object.items():
        intervals=sorted((r['start_line'],r['end_line']) for r in rs)
        covered=0
        for lo,hi in intervals:
            if lo>covered+1: break
            covered=max(covered,hi)
        if covered>=rs[0]['total_lines']: complete.add(obj)
        else: partial.add(obj)
    totals=collections.Counter(); docs=collections.Counter(); per_repo=collections.defaultdict(collections.Counter)
    cited={(r['repo'],r['path']) for r in reads if r['status']=='prior_targeted_review'}
    allrows=[]
    for row in db.execute('SELECT * FROM files ORDER BY repo,path'):
        r=dict(row); obj=r['object']
        if obj in complete:
            direct=any(x['repo']==r['repo'] and x['path']==r['path'] for x in by_object[obj])
            status='read_in_full' if direct else 'identical_content_read_elsewhere'
        elif obj in partial: status='partly_read'
        elif (r['repo'],r['path']) in cited: status='prior_focused_review_only'
        else: status='not_recorded_as_read'
        r['reading_status']=status
        if r['extension'] in {'.md','.tex','.rst','.bib'}: category='narrative_or_manuscript'
        elif r['extension']=='.lean': category='formal_proof_source'
        elif r['extension'] in {'.json','.yaml','.yml'}: category='structured_record_or_configuration'
        elif r['extension'] in {'.rs','.py','.c','.h','.cpp','.cc','.cu','.cuh','.sage','.gp','.go','.sh','.jl','.hpp'}: category='implementation_or_script'
        elif r['extension'] in {'.txt','.log','.jsonl','.csv','.tsv','.out','.err','.stdout','.stderr'}: category='record_table_log_or_plaintext'
        else: category='other_or_binary'
        r['source_class']=category
        totals[status]+=1; per_repo[r['repo']][status]+=1
        if r['extension']=='.md': docs[status]+=1
        allrows.append(r)
    with open(ROOT/'file-reading-coverage.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(allrows[0]));w.writeheader();w.writerows(allrows)
    (ROOT/'reading-events.json').write_text(json.dumps(reads,indent=2)+'\n')
    summary={'recorded_at':now(),'boundary':'Nineteen pinned repository trees in tracked_files.csv; this does not include every historical blob, branch tree, archive member or inaccessible artifact.',
        'definitions':{'read_in_full':'All source lines explicitly acknowledged as read in model context, possibly over several ranges.',
          'identical_content_read_elsewhere':'The exact same Git blob was read at another path; local surrounding context may differ.',
          'partly_read':'Some source lines explicitly acknowledged; remaining lines not acknowledged.',
          'prior_focused_review_only':'Cited in the first selective review; no complete line-by-line reading receipt is asserted.',
          'not_recorded_as_read':'No complete full-text receipt. Prior selective reads are not retroactively assumed to be full reads.',
          'machine_index':'Parsing, indexing and hashing are recorded separately and never count as reading.'},
        'file_count':len(allrows),'unique_blob_count':len({r['object'] for r in allrows if r['kind']=='blob'}),
        'reading_status_counts':dict(totals),'markdown_counts':dict(docs),'full_read_unique_blobs':len(complete),
        'full_read_unique_bytes':sum(by_object[x][0]['bytes'] for x in complete),'by_repository':{k:dict(v) for k,v in per_repo.items()},
        'by_source_class':{c:dict(collections.Counter(r['reading_status'] for r in allrows if r['source_class']==c)) for c in sorted({r['source_class'] for r in allrows})},
        'narrative_groups':{},
        'unacknowledged_emissions':[r['id'] for r in reads if r['status']=='emitted_unacknowledged'],
        'literal_everything_read':False}
    predicates={
        'crypto_root_research_notes':lambda r:r['repo']=='crypto' and '/' not in r['path'] and (r['path'].startswith('RESEARCH_') or r['path']=='SPARSE_ALGEBRA_FOLLOWUP.md') and r['extension']=='.md',
        'ml_pinned_tree_markdown':lambda r:r['repo']=='ml-cryptanalysis' and r['extension']=='.md',
        'ten_lead_claims':lambda r:r['repo']=='crypto-autoresearcher' and r['path'].startswith('research/ten-lead-evidence/claims/'),
        'ten_lead_descriptions':lambda r:r['repo']=='crypto-autoresearcher' and r['path'].startswith('research/ten-lead-evidence/leads/'),
    }
    for name,predicate in predicates.items():
        selected=[r for r in allrows if predicate(r)]
        summary['narrative_groups'][name]={'total_files':len(selected),'reading_status':dict(collections.Counter(r['reading_status'] for r in selected))}
    indexed=list(csv.DictReader(open(EVIDENCE/'document_catalogue.csv')))
    summary['materialized_markdown_catalogue']={'files':len(indexed),'bytes':sum(int(r['bytes']) for r in indexed),'unique_sha256':len({r['sha256'] for r in indexed})}
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))

def main():
    p=argparse.ArgumentParser();s=p.add_subparsers(dest='cmd',required=True)
    s.add_parser('inventory');s.add_parser('export')
    e=s.add_parser('emit');e.add_argument('repo');e.add_argument('path');e.add_argument('--start',type=int,default=1);e.add_argument('--end',type=int);e.add_argument('--max-bytes',type=int,default=26000)
    a=s.add_parser('ack');a.add_argument('ids',type=int,nargs='+');a.add_argument('--note',required=True)
    r=s.add_parser('record');r.add_argument('repo');r.add_argument('path');r.add_argument('--status',choices=['model_read','prior_targeted_review'],required=True);r.add_argument('--note',required=True)
    args=p.parse_args();db=connect()
    if args.cmd=='inventory':inventory(db)
    elif args.cmd=='emit':emit(db,args)
    elif args.cmd=='ack':ack(db,args)
    elif args.cmd=='record':record_previous(db,args)
    else:export(db)

if __name__=='__main__':main()
