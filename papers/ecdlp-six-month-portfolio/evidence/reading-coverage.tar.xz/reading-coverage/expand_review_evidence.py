#!/usr/bin/env python3
"""Freeze retrospective metadata and copied historical values; no cryptography."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile
import io

BASE = Path('/workspace/ecdlp-audit')
PAPER = BASE / 'repos/crypto/papers/ecdlp-six-month-portfolio'
EV = BASE / 'evidence'
sources = json.loads((PAPER/'evidence/sources.json').read_text())
pins = {s['repo']: s['commit'] for s in sources if 'repo' in s and 'commit' in s}
additions = [
 ('VOL-REPL','crypto-autoresearcher','research/isogeny_volcano_level_replication_20261013/README.md','Degree-37/41 conductor-level rho replication'),
 ('VOL-51','crypto-autoresearcher','research/isogeny_volcano_m51_rho_20261013/README.md','Degree-51 matched-action rho controls'),
 ('VOL-DEEP','crypto-autoresearcher','research/isogeny_volcano_m51_deep_rho_20261013/RESULTS.md','Deep degree-51 results with inference withheld'),
 ('VOL-DEEP-AUDIT','crypto-autoresearcher','research/isogeny_volcano_m51_deep_rho_20261013/AUDIT.md','Deep degree-51 audit and replay limits'),
 ('CONDUCTOR-PANEL','crypto-autoresearcher','research/conductor_gap_panel_20261014/REPORT.md','Forty-three conductor directions and kernel-construction stages'),
 ('ML-LAB','ml-cryptanalysis','docs/LAB.md','Streaming datasets and arithmetic feature-selection experiments'),
 ('ML-PLAN','ml-cryptanalysis','docs/PLAN.md','Learning controls, held-out panels and remaining plans'),
 ('ML-TWIST-THEORY','ml-cryptanalysis','docs/twist_bit_law.md','Rational twist-law argument and conditional family descent'),
 ('KOBLITZ-ARITH','crypto','src/cryptanalysis/koblitz_fast_arith.rs','Word arithmetic, degenerate S3 roots and complete test source'),
 ('S3-COST','crypto','src/cryptanalysis/semaev_s3_cost.rs','Prime/binary decision kernels and the timing-model boundary'),
 ('LEADS10','crypto','RESEARCH_IC_LEADS_AND_CONNECTIONS_20261010.md','Earlier IC lead classifications and their logical scope'),
 ('PDP-ISO','crypto','RESEARCH_PDP_SPEEDUP_AND_ISOGENY.md','Early PDP/isogeny claims requiring later qualifications'),
 ('ENDRING','crypto','RESEARCH_ENDRING_PKE_STRATEGY.md','Endomorphism-ring encryption strategy and failed public-walk prototype'),
]
new = []
for key, repo, path, title in additions:
    data = (BASE/'repos'/repo/path).read_bytes()
    new.append(dict(key=key, repo=repo, commit=pins[repo], path=path, title=title,
                    bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                    url=f'https://github.com/aburan28/{repo}/blob/{pins[repo]}/{path}'))

events = json.loads((EV/'drive/expanded-reading/events-unhashed.json').read_text())
for event in events:
    data = (EV/'drive/expanded-reading'/event['text_path']).read_bytes()
    event.update(retained_text_sha256=hashlib.sha256(data).hexdigest(), retained_text_bytes=len(data))
(EV/'drive/expanded-reading/events.json').write_text(json.dumps(events, indent=2)+'\n')
(PAPER/'evidence/external-reading.json').write_text(json.dumps(events, indent=2)+'\n')
external = [
 ('VOL-V7-GUIDE','1Tm1_reS7F8XAuifUeVUi7geFO3Cr8Xf9'),
 ('VOL-V7-REPORT','1ZJBwj-a0ayAUmqkUvKsfcBVw-W0K5ywQ'),
 ('VOL-C-REPORT','1Gdrpkb8n8XhBoO8Sdr3JKl_VIPMUgqdZ'),
 ('PRIME61-REPORT','1LN7HqkBkLOihsZsH4sW9ZBph8o-49MT4'),
 ('FIELD-EFFECTS','1f0i878HXHUBhIXJGFqfRU19wuxTTdFUs'),
 ('AUTO-RETROSPECTIVE','1z9JchzKARo_3gziwGTPX24yJMPFD1kF3y5aw0i-RSMw'),
 ('RHO-COMMUNICATION','172YnCS6udP9Dn9WGb-dpiyp2X19ak20zXDHmm_l0dSA'),
]
for key, identity in external:
    event = next(e for e in events if e['drive_id']==identity)
    new.append(dict(key=key,title=event['title'],url=f'https://drive.google.com/file/d/{identity}/view',
                    drive_id=identity,modified_at=event['modified_at'],
                    retained_text_sha256=event['retained_text_sha256'],
                    retained_text_bytes=event['retained_text_bytes'],
                    hash_scope='retained connector text, not the raw native document or PDF',
                    reading_status=event['reading_status'],limitation=event['limitation']))
for key, identity, name in [('VOL-V7','149AA7SRHzkHWQCp3rXS7iXI6FBLoaBfn','v7-archive-integrity-review.json'),
                            ('VOL-C-FULL','1HHlPDmGzwSopnwMGQ4vgvcGSH0WRa0BO','full-c-archive-integrity-review.json')]:
    receipt=json.loads((EV/'drive'/name).read_text())
    new.append(dict(key=key,title=receipt['archive'],url=f'https://drive.google.com/file/d/{identity}/view',
                    bytes=receipt['archive_bytes'],sha256=receipt['archive_sha256'],
                    status=f"all {receipt['checked']:,} manifest entries freshly hash-checked; no solver replay"))
    shutil.copy2(EV/'drive'/name,PAPER/'evidence'/name)

old_keys={s['key'] for s in sources}
append=[s for s in new if s['key'] not in old_keys]
sources.extend(append)
(PAPER/'evidence/sources.json').write_text(json.dumps(sources,indent=2)+'\n')
def escape(text):
    return text.replace('&',r'\&').replace('_',r'\_').replace('%',r'\%').replace('#',r'\#')
with (PAPER/'sections/source-register.tex').open('a') as out:
    for s in append:
        out.write('\n'+r'\par\noindent\begin{minipage}{\linewidth}\small'+'\n')
        out.write(r'\subsubsection*{['+s['key']+'] '+escape(s['title'])+'}'+r'\label{art:'+s['key']+'}\n')
        if 'repo' in s:
            out.write(escape(s['repo'])+r': \path{'+s['path']+'}.\n')
        out.write(r'\url{'+s['url']+'}\n')
        if 'commit' in s: out.write(r'\par Revision: \path{'+s['commit']+'}.\n')
        if 'sha256' in s: out.write(r'\par SHA-256: \path{'+s['sha256']+'}.\n')
        if 'retained_text_sha256' in s:
            out.write(r'\par Retained extracted-text SHA-256: \path{'+s['retained_text_sha256']+'}.\n')
            out.write(r'\par Provider modified time: \path{'+s['modified_at']+'}. Raw document hash not asserted.\n')
        out.write(r'\end{minipage}\par\medskip'+'\n')

d=json.loads((PAPER/'figures/recorded-data.json').read_text())
v7=json.loads((EV/'drive/checked-v7/summary/summary.json').read_text())
d['volcano_v7']={k:v for k,v in v7.items() if k!='groups'}
d['volcano_v7']['source_key']='VOL-V7'
d['conductor_controls']={
 'interpretation':'Copied recorded intervals; no new fitting, resampling or performance experiment.',
 'replication':[
  {'label':'m37 / 73','effect':.002917,'low':-.027519,'high':.034966},
  {'label':'m37 / 2663','effect':.008627,'low':-.027028,'high':.045977},
  {'label':'m37 / bottom','effect':-.008978,'low':-.042598,'high':.026042},
  {'label':'m41 / 409','effect':-.001430,'low':-.064901,'high':.060353},
  {'label':'m41 / 1721','effect':.016988,'low':-.045113,'high':.078181},
  {'label':'m41 / bottom','effect':.014691,'low':-.048873,'high':.077866}],
 'matched51':[{'label':'tau17 floor/crater','effect':.005762506,'low':-.032170483,'high':.043374391}],
 'deep51_diagnostic':[
  {'label':'A minus crater','effect':-.013566257,'low':-.074242757,'high':.047110242},
  {'label':'P minus crater','effect':-.026350098,'low':-.081553057,'high':.028852860},
  {'label':'Bottom minus crater','effect':-.000024033,'low':-.051809003,'high':.051760936}],
 'source_keys':['VOL-REPL','VOL-51','VOL-DEEP'],
 'deep_inference_status':'WITHHELD_AA_ALERT'}
(PAPER/'figures/recorded-data.json').write_text(json.dumps(d,indent=2)+'\n')

shutil.copy2(EV/'reading-coverage/summary.json',PAPER/'evidence/reading-coverage-summary.json')
payload={
 'summary.json':(EV/'reading-coverage/summary.json').read_bytes(),
 'file-reading-coverage.csv':(EV/'reading-coverage/file-reading-coverage.csv').read_bytes(),
 'reading-events.json':(EV/'reading-coverage/reading-events.json').read_bytes(),
 'external-reading.json':(PAPER/'evidence/external-reading.json').read_bytes(),
 'reading_coverage.py':(BASE/'scripts/reading_coverage.py').read_bytes(),
 'check_delivery_archive.py':(BASE/'scripts/check_delivery_archive.py').read_bytes(),
 'expand_review_evidence.py':(BASE/'scripts/expand_review_evidence.py').read_bytes(),
}
manifest=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(payload.items()))
payload['MANIFEST.sha256']=manifest.encode()
archive=PAPER/'evidence/reading-coverage.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
    for name,data in sorted(payload.items()):
        info=tarfile.TarInfo('reading-coverage/'+name)
        info.size=len(data);info.mode=0o644;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
(PAPER/'evidence/reading-coverage.tar.xz.sha256').write_text(digest+'  reading-coverage.tar.xz\n')
print(json.dumps({'source_entries':len(sources),'new_source_entries':len(append),
                  'reading_archive_bytes':archive.stat().st_size,'reading_archive_sha256':digest}))
