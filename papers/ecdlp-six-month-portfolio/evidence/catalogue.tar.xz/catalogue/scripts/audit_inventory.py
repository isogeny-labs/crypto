"""Catalogue repository records for a retrospective; does not run cryptography."""
from pathlib import Path
from collections import Counter, defaultdict
import csv
import hashlib
import json
import re
import subprocess
import yaml

BASE = Path('/workspace/ecdlp-audit')
OUT = BASE / 'evidence'
SINCE = '2026-04-19T00:00:00Z'
UNTIL = '2026-10-19T23:59:59Z'
CODE_EXTS = {'.rs', '.py', '.c', '.cpp', '.h', '.cu', '.cuh', '.lean', '.sage', '.vhd'}
TOPICS = {
    'Koblitz/binary/Frobenius': r'koblitz|binary|f2m|n83|n53|n61|n71|n73|frobenius|ecc2k',
    'Prime fields/coordinate structure': r'prime|p256|p-256|secp256|nist|smallness|coppersmith|pkm|kummer',
    'Extension fields/Weil descent': r'gaudry|joux|vitse|quintic|quartic|weil|ghs|fpn|fp6|genus',
    'Isogenies/CM/endomorphisms': r'isogen|volcano|conductor|endomorph|torsion|glv|gls|fiber|fibre|cm[_-]',
    'Decomposition/root finding': r'root.?find|rootfind|semaev|pdp|pair.?table|decomp|summation',
    'Groebner/SAT/algebra': r'groebner|gröbner|\bf4\b|\bf5\b|\bf6|macaulay|cdcl|wdsat|sat[_-]|refutation',
    'Linear algebra/relations': r'linear|linalg|wiedemann|lanczos|free.?rel|rank|harvest|2lp|large.?prime',
    'Measurement/reproducibility': r'ecbench|icms|bound|frontier|audit|replay|isola|calibrat|fidelity|benchmark',
    'GPU/FPGA/CPU arithmetic': r'gpu|cuda|blackwell|ptx|fpga|avx|pclmul|itoh|graviton|metal|kernel',
    'ML/learned discovery': r'learn|machine|neural|predict|humbert|symbol|gnn|transformer|hardness',
    'Formalization/certificates': r'lean|formal|certificate|proof.?gate',
    'Research orchestration': r'harness|coordinat|runbook|autolab|cairn|conductor|agent|dispatch|ledger',
    'Other cryptography': r'aes|rsa|pqc|kem|symmetric|sha|md5|hash|kyber|dilithium|ecdsa|lattice|lll|snfs|gnfs',
}

def write_csv(name, rows, fields=None):
    if not rows: return
    with (OUT / name).open('w', newline='') as f:
        w=csv.DictWriter(f, fieldnames=fields or list(rows[0])); w.writeheader();w.writerows(rows)

def tags(text):
    return '; '.join(k for k,p in TOPICS.items() if re.search(p,text,re.I))

repos=[]; tracked=[]; commits=[]; studies=[]; docs=[]; all_shas=set(); monthly=[]
for root in sorted((BASE/'repos').iterdir()):
    if not (root/'.git').exists(): continue
    repo=root.name
    sha=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
    branch=subprocess.check_output(['git','-C',str(root),'branch','--show-current'],text=True).strip()
    raw=subprocess.check_output(['git','-C',str(root),'ls-tree','-r','HEAD'],text=True)
    (OUT/(repo+'-tree.tsv')).write_text(raw)
    paths=[]; unique=set(); codes=Counter(); materialized=0; nbytes=0
    for line in raw.splitlines():
        meta,path=line.split('\t',1);mode,kind,blob=meta.split();paths.append(path);unique.add(blob)
        p=root/path; exists=p.is_file()
        if exists: materialized+=1;nbytes+=p.stat().st_size
        tracked.append({'repo':repo,'commit':sha,'path':path,'git_object':blob,'kind':kind,
                        'extension':Path(path).suffix,'materialized':exists,
                        'materialized_bytes':p.stat().st_size if exists else '', 'topics_by_path':tags(path)})
        if Path(path).suffix in CODE_EXTS: codes[Path(path).suffix]+=1
        if path.endswith('.md') and exists and p.stat().st_size<2*1024*1024:
            content=p.read_text(errors='replace'); headings=re.findall(r'^#{1,3}\s+(.+)',content,re.M)
            docs.append({'repo':repo,'commit':sha,'path':path,'bytes':p.stat().st_size,
                         'title':headings[0] if headings else '', 'topics_by_path_and_title':tags(path+' '+(' '.join(headings[:3]))),
                         'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    log=subprocess.check_output(['git','-C',str(root),'log','HEAD','--since-as-filter='+SINCE,'--until='+UNTIL,
             '--format=%H%x09%P%x09%cI%x09%aI%x09%an%x09%s'],text=True)
    (OUT/(repo+'-commits.tsv')).write_text(log)
    counts=Counter(); merge=0
    for line in log.splitlines():
        fields=line.split('\t',5)
        if len(fields)!=6:continue
        ch,parents,cd,ad,author,subject=fields;is_merge=len(parents.split())>1;merge+=is_merge;counts[cd[:7]]+=1
        commits.append({'repo':repo,'commit':ch,'committer_date':cd,'author_date':ad,'author_name':author,
                        'is_merge':is_merge,'subject':subject,'topics_by_subject':tags(subject)})
        all_shas.add(ch)
    for month,n in sorted(counts.items()):monthly.append({'repo':repo,'month':month,'reachable_commits':n})
    source_roots=['research','experiments','benchmarks','papers']
    for directory in source_roots:
        group=defaultdict(list)
        for path in paths:
            parts=path.split('/')
            if len(parts)>2 and parts[0]==directory:group[parts[1]].append(path)
        for name,group_paths in sorted(group.items()):
            readmes=[p for p in group_paths if Path(p).name.lower() in {'readme.md','result.md','report.md','findings.md'}]
            readmes.sort(key=lambda p:(p.count('/'),p))
            title=''
            if readmes and (root/readmes[0]).is_file():
                text=(root/readmes[0]).read_text(errors='replace')
                h=re.search(r'^#\s+(.+)',text,re.M);title=h.group(1) if h else ''
            studies.append({'repo':repo,'commit':sha,'category':directory,'directory':directory+'/'+name,
                            'tracked_files':len(group_paths),'summary_path':readmes[0] if readmes else '',
                            'title':title,'topics_by_name_and_title':tags(name+' '+title),
                            'unit_of_count':'directory, not an independent experiment'})
    repos.append({'repo':repo,'commit':sha,'checked_out_branch':branch or 'detached',
                  'tracked_entries':len(paths),'unique_git_objects':len(unique),'materialized_files':materialized,
                  'materialized_bytes':nbytes,'window_reachable_commits':len(log.splitlines()),'merge_commits':merge,
                  'code_files_by_extension':dict(codes)})
    print('catalogued',repo,len(paths),'entries',flush=True)

write_csv('repository_inventory.csv',[{k:v for k,v in r.items() if k!='code_files_by_extension'} for r in repos])
write_csv('tracked_files.csv',tracked)
write_csv('commit_catalogue.csv',commits)
write_csv('monthly_activity.csv',monthly)
write_csv('study_catalogue.csv',studies)
write_csv('document_catalogue.csv',docs)
write_csv('topic_definitions.csv',[{'topic':k,'regex':v,'interpretation':'overlapping textual tags; not scientific validation'} for k,v in TOPICS.items()])

ledger_root=BASE/'repos/crypto-autoresearcher/ledger'
ledger=[];failures=[]
for path in sorted(ledger_root.rglob('*.yaml')):
    if '.index' in path.parts:continue
    try:
        data=yaml.safe_load(path.read_text())
        if not isinstance(data,dict):continue
        kind=next(iter(data));rec=data[kind]
        if not isinstance(rec,dict):rec=data;kind=path.parent.name
        ledger.append({'path':str(path.relative_to(ledger_root.parent)), 'record_type':kind,
                       'id':rec.get('id',''),'title':str(rec.get('title','')),'status':str(rec.get('status','')),
                       'direction':str(rec.get('direction','')),'strength':str(rec.get('strength','')),
                       'claim_tier':str(rec.get('claim_tier','')),'proof_status':str(rec.get('proof_status','')),
                       'topics_by_title':tags(str(rec.get('title',''))),
                       'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    except Exception as e:failures.append({'path':str(path),'error':str(e)[:500]})
write_csv('ledger_catalogue.csv',ledger)
summary={kind:{'records':len(rows),'status':dict(Counter(r['status'] or '(not specified)' for r in rows)),
               'proof_status':dict(Counter(r['proof_status'] or '(not specified)' for r in rows))}
         for kind in sorted({r['record_type'] for r in ledger}) for rows in [[r for r in ledger if r['record_type']==kind]]}
(OUT/'ledger_summary.json').write_text(json.dumps({'by_type':summary,'parse_failures':failures},indent=2))
portfolio={'period_start_utc':SINCE,'period_end_date_utc':'2026-10-19',
           'repositories':repos,'repository_count':len(repos),'tracked_entries':len(tracked),
           'unique_reachable_commits_in_union':len(all_shas),'sum_reachable_commit_entries':len(commits),
           'study_directories':len(studies),'catalogued_markdown_documents':len(docs),
           'ledger_records_parsed':len(ledger),'ledger_parse_failures':len(failures),
           'caveats':['Snapshots are pinned independently, not an atomic portfolio snapshot.',
                      'Reachable commit histories include merges, imports and upstream fork history.',
                      'A directory, ledger row, file, or commit is not an independent experiment or discovery.',
                      'Sparse materialization is disclosed per file; omitted bytes are not absent evidence.']}
(OUT/'portfolio_summary.json').write_text(json.dumps(portfolio,indent=2))
print(json.dumps({k:v for k,v in portfolio.items() if k!='repositories'}),flush=True)
