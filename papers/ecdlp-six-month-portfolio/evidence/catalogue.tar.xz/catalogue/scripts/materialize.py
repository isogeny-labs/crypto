"""Acquire review material without running experiments or modifying evidence."""
from pathlib import Path
import concurrent.futures
import json
import subprocess

BASE = Path('/workspace/ecdlp-audit')
REPOS = ['crypto', 'cryptanalysis', 'crypto-autoresearcher']

def materialize(repo):
    root = BASE / 'repos' / repo
    # The default cryptanalysis branch is an active development branch. Preserve
    # it as a separate snapshot and review landed main for cross-repo results.
    if repo == 'cryptanalysis':
        subprocess.run(['git', '-C', str(root), 'checkout', '--detach', 'origin/main'], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    sha = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
    tree = subprocess.check_output(['git', '-C', str(root), 'ls-tree', '-r', 'HEAD'], text=True)
    (BASE / 'evidence' / (repo + '-tree.tsv')).write_text(tree)
    api = json.loads((BASE / 'evidence' / (repo + '-api-tree.json')).read_text())
    patterns = ['/*', '!/*/', '*.md', '*.json', '*.yaml', '*.yml', '*.csv', '*.tsv',
                '*.tex', '*.bib', '*.lean', '/src/', '/include/', '/tests/', '/tools/',
                '/scripts/', '/examples/', '/benches/', '/bindings/', '/papers/', '/docs/',
                '/formal/', '/claims/', '/config/', '/schemas/',
                '!/inputs/', '!/third_party/', '!**/node_modules/', '!**/vendor/']
    large = [x for x in api.get('tree', []) if x.get('size', 0) > 2 * 1024 * 1024]
    patterns += ['!/' + x['path'] for x in large]
    (BASE / 'evidence' / (repo + '-sparse-patterns.txt')).write_text('\n'.join(patterns) + '\n')
    log = BASE / 'evidence' / (repo + '-acquisition.log')
    print(repo, 'materializing', sha, 'known large exclusions', len(large), flush=True)
    with log.open('w') as f:
        run = subprocess.run(['git', '-C', str(root), 'sparse-checkout', 'set', '--no-cone', '--stdin'],
                             input='\n'.join(patterns)+'\n', text=True, stdout=f, stderr=f)
        if run.returncode:
            return {'repo': repo, 'sha': sha, 'status': 'failed', 'log': str(log)}
        run = subprocess.run(['git', '-C', str(root), 'checkout', '--detach', sha], stdout=f, stderr=f)
    paths = [p for p in root.rglob('*') if p.is_file() and '.git' not in p.relative_to(root).parts]
    data = {'repo': repo, 'sha': sha, 'status': 'acquired' if run.returncode == 0 else 'failed',
            'materialized_files': len(paths), 'materialized_bytes': sum(p.stat().st_size for p in paths),
            'known_large_exclusions': len(large), 'api_tree_truncated': api.get('truncated'),
            'api_tree_sha': api.get('sha')}
    (BASE / 'evidence' / (repo + '-acquisition.json')).write_text(json.dumps(data, indent=2))
    return data

if __name__ == '__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        for result in executor.map(materialize, REPOS):
            print(json.dumps(result), flush=True)
