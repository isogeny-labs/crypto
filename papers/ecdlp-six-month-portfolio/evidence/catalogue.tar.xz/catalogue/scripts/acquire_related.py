"""Read-only snapshots of adjacent repositories for the portfolio review."""
from pathlib import Path
import concurrent.futures
import json
import subprocess
import urllib.request

BASE = Path('/workspace/ecdlp-audit')
REPOS = ['ml-cryptanalysis', 'crypto-lean', 'ecdlp-cost-challenge',
         'ecdlp-prime-field-smallness', 'ecc-challenges', 'rho-blackwell', 'ecbench',
         'ghs-trapdoor', 'eigenx', 'isogeny-labs', 'WDSat', 'the-sqisign',
         'ecdsafail-challenge', 'cairn', 'autolab', 'cryptologic-archives']

def acquire(repo):
    try:
        with urllib.request.urlopen('https://api.github.com/repos/aburan28/' + repo, timeout=30) as r:
            meta = json.load(r)
        (BASE / 'evidence' / (repo + '-metadata.json')).write_text(json.dumps(meta, indent=2))
        root = BASE / 'repos' / repo
        log = BASE / 'evidence' / (repo + '-acquisition.log')
        with log.open('w') as f:
            if not (root / '.git').exists():
                subprocess.run(['git', 'clone', '--filter=blob:none', '--no-checkout',
                                '--single-branch', meta['clone_url'], str(root)],
                               stdout=f, stderr=f, check=True, timeout=180)
            patterns = ['/*', '!/*/', '*.md', '*.tex', '*.bib', '*.lean',
                        '/src/', '/include/', '/tests/', '/scripts/', '/tools/', '/docs/',
                        '/formal/', '/proofs/', '/papers/', '/results/',
                        '!/third_party/', '!/inputs/', '!**/node_modules/']
            subprocess.run(['git', '-C', str(root), 'sparse-checkout', 'set', '--no-cone', '--stdin'],
                           input='\n'.join(patterns)+'\n', text=True, stdout=f, stderr=f, check=True, timeout=180)
            subprocess.run(['git', '-C', str(root), 'checkout'], stdout=f, stderr=f, check=True, timeout=180)
        sha = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
        tree = subprocess.check_output(['git', '-C', str(root), 'ls-tree', '-r', 'HEAD'], text=True)
        (BASE / 'evidence' / (repo + '-tree.tsv')).write_text(tree)
        return {'repo': repo, 'sha': sha, 'tracked_files': len(tree.splitlines()),
                'created_at': meta['created_at'], 'fork': meta['fork'], 'status': 'acquired'}
    except Exception as e:
        return {'repo': repo, 'status': 'unavailable', 'error': str(e)}

if __name__ == '__main__':
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        for result in executor.map(acquire, REPOS):
            results.append(result)
            print(json.dumps(result), flush=True)
    (BASE / 'evidence' / 'related-acquisition.json').write_text(json.dumps(results, indent=2))
