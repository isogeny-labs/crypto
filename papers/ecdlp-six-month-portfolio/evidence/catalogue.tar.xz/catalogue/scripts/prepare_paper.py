"""Lay out recorded retrospective data and source provenance for the paper."""
from pathlib import Path
import csv
import hashlib
import json
import shutil
import subprocess

BASE=Path('/workspace/ecdlp-audit')
PAPER=BASE/'repos/crypto/papers/ecdlp-six-month-portfolio'
EV=BASE/'evidence'
portfolio=json.loads((EV/'portfolio_summary.json').read_text())
pins={r['repo']:r['commit'] for r in portfolio['repositories']}

# Citation keys identify exact source bytes, not an assessment of their truth.
SOURCES=[
('C-README','crypto','README.md','Implementation inventory and public interfaces'),
('C-RULES','crypto','AGENTS.md','Evidence, cost, identity and manuscript contracts'),
('CA-README','cryptanalysis','README.md','Native C and Rust cryptanalysis toolkit'),
('AR-README','crypto-autoresearcher','README.md','Research orchestration and scope'),
('PRIOR','crypto','papers/ecdlp-index-calculus-program/README.md','Earlier index-calculus programme synthesis'),
('AUTOLOG','crypto','research/notes/index-calculus/RESEARCH_AUTOLAB_LOG.md','Earlier experimental work log'),
('HNP','crypto','research/notes/lattice-hnp/RESEARCH_GLV_HNP.md','GLV and hidden-number research'),
('LLL','crypto','papers/lll-degeneracy-note/README.md','Corrected floating-point LLL note'),
('MIGRATION','crypto-autoresearcher','docs/autolab-migration-20260802.md','Historical archive migration and access boundary'),
('BOUNDARY','crypto','docs/ic/boundary_targets.json','Binary, Koblitz and prime stage ledger'),
('LEADER','crypto','docs/ic/LEADERBOARD.md','Historical leaderboard with accounting boundaries'),
('TIMELINE','crypto','docs/ic/progress-timeline.json','Typed progress timeline and superseded results'),
('FRONTIER','crypto','research/ic_frontier_campaign_20261015/README.md','Controlled cross-method campaign'),
('BAND','crypto','research/ic_frontier_campaign_20261015/analysis/ratios_to_rho.tsv','Campaign ratios at three native-operation weights'),
('RF-AUDIT','crypto','research/ecbench_rootfinding_assessment_20261012/REPORT.md','Root-finding source and measurement audit'),
('RF-PROOF','crypto','papers/rootfinding-decomposition/lean/S3Roots.lean','Affine Semaev factorization proof source'),
('RF-PDP','crypto','research/pdp_root_finder_20261012/README.md','PDP root-finding oracle family'),
('RF-GPU','crypto','RESEARCH_GPU_ROOTFIND_DECOMPOSITION.md','GPU root-finding implementation and emulation scope'),
('GB','crypto','docs/ic/GROEBNER_F4F5F6_AUDIT_20261010.md','Groebner engine audit'),
('FP-F4','crypto','research/f4_fp_msolve_parity_20261011/README.md','Prime-field F4 and external-CAS comparison'),
('F4-GPU','cryptanalysis','experiments/f4-gpu-runpod-20261006/RESULT.md','Actual RTX 5090 F4 matrix and oracle measurements'),
('F4-PANEL','cryptanalysis','experiments/f4-gpu-panel-20261007/README.md','Kept and reverted H100 panel experiments'),
('KOBLITZ','crypto','RESEARCH_KOBLITZ_INDEX_CALCULUS.md','Koblitz invariant-base programme'),
('COMPACT','crypto','docs/ic/COMPACT_ORBIT_PRODUCER.md','Compact signed-Frobenius orbit implementation'),
('N83','crypto','research/n83_e2e_holdout_20261016/RESULT.md','Five-point N83 cold holdout'),
('N83-ROWS','crypto','research/n83_e2e_holdout_20261016/ic1_rows_38955665283.json','Exact holdout rows and paired intervals'),
('EQUAL','crypto','research/ic_next10_20261014/09-equal-advice/README.md','Equal-advice rho control and free-relation census'),
('EQUAL83','crypto','research/20261016-n83-precomputed-rho-control/README.md','N83 time- and RSS-matched preprocessing control'),
('WIDE','crypto','research/equal_advice_wide_20261018/README.md','Frozen unrun equal-bytes wide protocol'),
('ROUND1','crypto','research/ic_improve_20261014/README.md','First IC improvement round and corrections'),
('ROUND2','crypto','research/ic_improve_20261015/README.md','Production free relations, row harvesting and genus-3 work'),
('D4','crypto','research/d4_symmetrised_s5_20261015/README.md','Weighted four-variable D4 formulation'),
('PKM','crypto','research/pkm_tower_ecbench_20261013/README.md','Prime Kummer-base end-to-end panels'),
('SMALL','ecdlp-prime-field-smallness','README.md','Prime-coordinate smallness experiments'),
('PRIME','crypto','RESEARCH_PRIME_FIELD_BREAKTHROUGH_PROGRAM.md','Prime-field leads and obligations'),
('RESIDUAL','crypto','research/notes/index-calculus/RESEARCH_RESIDUAL_WALKS.md','Residual-walk costs and corrected phase accounting'),
('PARITY','crypto','research/notes/index-calculus/RESEARCH_RHO_PARITY_PROGRAMME.md','Extension-field parity ledger'),
('QUINTIC','crypto','research/notes/index-calculus/RESEARCH_K5_TORSION_JOUX_VITSE.md','Quintic torsion route and corrections'),
('COVER','crypto','research/notes/index-calculus/RESEARCH_COVER_DECOMPOSITION_LEDGER.md','Weak-class cover, decomposition and navigation costs'),
('DREG','crypto','research/dreg_closure_driver_20261016/RESULTS.md','Degree-closure discriminating cells and unfinished boundary'),
('HEUR','cryptanalysis','experiments/pdp-degree-heuristics/README.md','Factor-base product profiles and empirical degree rule'),
('TRANSFER','crypto','docs/ic/RESEARCH_TRANSFER_AWARE_IC_20261010.md','Transport conservation and its hypotheses'),
('FIBRES','crypto','RESEARCH_ISOGENY_FIBERS_ECDLP.md','Isogeny-fibre mechanisms and obligations'),
('CONDUCTOR','crypto','research/ecbench_conductor_gap_20261012/README.md','Counted conductor-gap comparison'),
('FIBRE-SCALE','crypto','research/fiber_ic_scaling_20261011/README.md','Fibre-aware IC scaling'),
('VOLCANO','crypto','research/full_volcano_graphwide_ic_20261017/START_HERE.md','Graph construction, checkpoints and measured coverage'),
('STRUCTURAL','crypto','papers/structural-completeness/README.md','Structural-completeness draft and proof-scope correction'),
('ML','ml-cryptanalysis','README.md','Learning and symbolic-discovery programme'),
('ML-HARD','ml-cryptanalysis','experiments/hardness-m9/report.md','Hardness, controls and within-class prediction'),
('ML-GHS','ml-cryptanalysis','experiments/ghs-descent/report.md','Binary GHS isogeny-class labels'),
('ML-FPN','ml-cryptanalysis','experiments/fpn-degrees/report.md','Extension-field degree measurements'),
('ML-SMITH','ml-cryptanalysis','experiments/smith-isogeny/report.md','Genus-3 Smith isogenies and symbolic rules'),
('ML-TWIST','ml-cryptanalysis','experiments/twist-bit-law/report.md','Twist-bit identity and finite certificates'),
('ML-HUMBERT','ml-cryptanalysis','experiments/humbert-surfaces/report.md','Humbert-equation recovery and validation'),
('LEAN','crypto-lean','README.md','Shared proof library, trust gate and missing bridges'),
('TEN','crypto-autoresearcher','research/ten-lead-evidence/README.md','Ten open leads and imported advisory evidence'),
('TORSION','crypto-autoresearcher','research/ten-lead-evidence/torsion-proof-note.md','Odd-torsion translation statement and formal scope'),
('RHO-GPU','rho-blackwell','README.md','Blackwell rho throughput and release provenance'),
('ECC-SERVICE','ecc-challenges','README.md','Distributed challenge archive and verification service'),
('EIGEN','eigenx','README.md','Eigen-Seta implementation and conjectural security tiers'),
('GHS-MAIN','ghs-trapdoor','README.md','Main-branch scaffold'),
('COST','ecdlp-cost-challenge','README.md','Executable generic-group cost challenge'),
('QUANTUM','crypto','quantum_circuit_secp256k1/README.md','Quantum point-addition work log and validation boundary'),
('ARCHIVES','cryptologic-archives','README.md','Historical cryptologic source archive'),
('LEADS18','crypto','research/ic_leads_review_20261018/README.md','Recent desk review and its recorded corrections'),
]

sources=[]
for key,repo,path,title in SOURCES:
    p=BASE/'repos'/repo/path
    if not p.is_file():
        print('MISSING SOURCE',key,repo,path,flush=True);continue
    sources.append({'key':key,'repo':repo,'commit':pins[repo],'path':path,'title':title,
                    'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                    'url':f'https://github.com/aburan28/{repo}/blob/{pins[repo]}/{path}'})

for rec in json.loads((EV/'selected-open-pr-snapshots.json').read_text()):
    sources.append({'key':'PR'+str(rec['number']),'repo':rec['repo'],'commit':rec['head_sha'],
                    'path':'pull/'+str(rec['number']),'title':rec['title']+' (open PR snapshot)',
                    'url':rec['url'],'status':'open, unmerged at read; claims are author-reported'})
sources.append({'key':'GHS-BRANCH','repo':'ghs-trapdoor','commit':'7c27311b25144c83071a18e3e638c8a2847b4126','path':'README.md',
                'title':'GHS mechanism prototype on a separate branch',
                'url':'https://github.com/aburan28/ghs-trapdoor/blob/7c27311b25144c83071a18e3e638c8a2847b4126/README.md'})
sources.append({'key':'VOL-ARCHIVE','title':'Downloaded 2,935-vertex checkpoint archive',
                'url':'https://drive.google.com/file/d/1IoPt5C-EYlo488pPVWPx-qpDHo7t1GwY/view',
                'sha256':'10f63f511b17b0f0ae7af5ed7470bafcf861e672036cbe37428369e43d0f4109',
                'bytes':37926124,'status':'all 29,409 manifest entries freshly checked; no solver replay'})
(PAPER/'evidence/sources.json').write_text(json.dumps(sources,indent=2))
(PAPER/'evidence/portfolio_summary.json').write_text(json.dumps(portfolio,indent=2))
for name in ['repository_inventory.csv','monthly_activity.csv','all-repository-branch-summary.json',
             'frontier-record-review.json','ledger_summary.json','ref-coverage.json']:
    shutil.copy2(EV/name,PAPER/'evidence'/name)
shutil.copy2(EV/'drive/archive-integrity-review.json',PAPER/'evidence/volcano-archive-review.json')

def esc(s):
    return str(s).replace('\\',r'\textbackslash{}').replace('&',r'\&').replace('%',r'\%').replace('_',r'\_').replace('#',r'\#')

lines=[r'\begin{longtable}{@{}p{3.5cm}r r p{3.1cm}@{}}',r'\toprule Repository & Entries & Window commits & Pinned commit \\',r'\midrule\endhead']
for r in portfolio['repositories']:
    lines.append(esc(r['repo'])+' & '+f"{r['tracked_entries']:,}"+' & '+f"{r['window_reachable_commits']:,}"+' & '+r'\texttt{'+r['commit'][:12]+r'} \\')
lines += [r'\bottomrule\end{longtable}']
(PAPER/'sections/repository-table.tex').write_text('\n'.join(lines)+'\n')

lines=[]
for s in sources:
    lines.append(r'\subsubsection*{['+s['key']+'] '+esc(s['title'])+r'}\label{art:'+s['key']+'}')
    if 'repo' in s:lines.append(esc(s['repo'])+': '+r'\path{'+s['path']+'}'+'. ')
    lines.append(r'\url{'+s['url'].replace(' ','%20')+'}')
    if 'commit' in s:lines.append(r'\par Revision: \path{'+s['commit']+'}.')
    if 'sha256' in s:lines.append(r'\par SHA-256: \path{'+s['sha256']+'}.')
    if 'status' in s:lines.append(r'\par '+esc(s['status'])+'.')
(PAPER/'sections/source-register.tex').write_text('\n'.join(lines)+'\n')

data={'portfolio':portfolio,'all_branches':json.loads((EV/'all-repository-branch-summary.json').read_text()),
      'monthly':list(csv.DictReader((EV/'monthly_activity.csv').open())),
      'frontier':list(csv.DictReader((BASE/'repos/crypto/research/ic_frontier_campaign_20261015/analysis/ratios_to_rho.tsv').open(),delimiter='\t')),
      'n83':json.loads((BASE/'repos/crypto/research/n83_e2e_holdout_20261016/ic1_rows_38955665283.json').read_text()),
      'volcano':json.loads((EV/'drive/checked/summary/summary.json').read_text()),
      'source_keys':[s['key'] for s in sources]}
(PAPER/'figures/recorded-data.json').write_text(json.dumps(data,indent=2))
print('paper sources',len(sources),'data bytes',(PAPER/'figures/recorded-data.json').stat().st_size,flush=True)
